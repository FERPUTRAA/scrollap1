.class Lcom/alibaba/fastjson/parser/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static a:Lcom/alibaba/fastjson/parser/k;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lcom/alibaba/fastjson/parser/k;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/alibaba/fastjson/parser/k;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static c(Lcom/alibaba/fastjson/parser/b;Ljava/util/Map;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    iget-object v4, v1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    iget v5, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    const/16 v6, 0xc

    const/16 v7, 0x10

    if-eq v5, v6, :cond_1

    if-ne v5, v7, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "cxsreur,ap ssaoenx{r tceta t , "

    const-string/jumbo v2, "t sx{rrpaa  , utscr,noaeteycxe "

    const-string/jumbo v2, "rl ma xptc ,ttasee ,orn {arxceu"

    const-string/jumbo v2, "syntax error, expect {, actual "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v5}, Lcom/alibaba/fastjson/parser/f;->a(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    iget-object v5, v1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    invoke-virtual {v5, v2}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object v5

    iget-object v6, v1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    invoke-virtual {v6, v3}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object v6

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->t()V

    iget-object v8, v1, Lcom/alibaba/fastjson/parser/b;->f:Lcom/alibaba/fastjson/parser/l;

    :goto_1
    :try_start_0
    iget v9, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    const/16 v10, 0xd

    if-ne v9, v10, :cond_2

    invoke-virtual {v4, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1, v8}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    return-object v0

    :cond_2
    const/16 v11, 0x3a

    const/4 v13, 0x1

    const/4 v14, 0x4

    if-ne v9, v14, :cond_8

    :try_start_1
    iget v15, v4, Lcom/alibaba/fastjson/parser/e;->h:I

    if-ne v15, v14, :cond_8

    iget-object v15, v4, Lcom/alibaba/fastjson/parser/e;->q:Ljava/lang/String;

    const-string v12, "$fer"

    const-string v12, "erf$"

    const-string/jumbo v12, "rfe$"

    const-string v12, "$ref"

    iget v7, v4, Lcom/alibaba/fastjson/parser/e;->k:I

    add-int/2addr v7, v13

    invoke-virtual {v15, v12, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v7

    if-eqz v7, :cond_8

    sget-object v7, Lcom/alibaba/fastjson/parser/d;->p:Lcom/alibaba/fastjson/parser/d;

    invoke-virtual {v4, v7}, Lcom/alibaba/fastjson/parser/e;->n(Lcom/alibaba/fastjson/parser/d;)Z

    move-result v7

    if-nez v7, :cond_8

    invoke-virtual {v4, v11}, Lcom/alibaba/fastjson/parser/e;->v(C)V

    iget v0, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    if-ne v0, v14, :cond_7

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v0

    const-string v2, ".."

    const-string v2, ".."

    const-string v2, ".."

    const-string v2, ".."

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    iget-object v0, v8, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    iget-object v12, v0, Lcom/alibaba/fastjson/parser/l;->a:Ljava/lang/Object;

    goto :goto_3

    :cond_3
    const-string v2, "$"

    const-string v2, "$"

    const-string v2, "$"

    const-string v2, "$"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    :goto_2
    iget-object v2, v0, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    if-eqz v2, :cond_4

    move-object v0, v2

    move-object v0, v2

    goto :goto_2

    :cond_4
    iget-object v12, v0, Lcom/alibaba/fastjson/parser/l;->a:Ljava/lang/Object;

    goto :goto_3

    :cond_5
    new-instance v2, Lcom/alibaba/fastjson/parser/b$a;

    invoke-direct {v2, v8, v0}, Lcom/alibaba/fastjson/parser/b$a;-><init>(Lcom/alibaba/fastjson/parser/l;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/alibaba/fastjson/parser/b;->b(Lcom/alibaba/fastjson/parser/b$a;)V

    iput v13, v1, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v12, 0x0

    :goto_3
    invoke-virtual {v4, v10}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    iget v0, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    if-ne v0, v10, :cond_6

    const/16 v0, 0x10

    invoke-virtual {v4, v0}, Lcom/alibaba/fastjson/parser/e;->u(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v1, v8}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    return-object v12

    :cond_6
    :try_start_2
    new-instance v0, Lcom/alibaba/fastjson/d;

    const-string v2, "efm olgrlle"

    const-string/jumbo v2, "llimgl free"

    const-string/jumbo v2, "rflaibge el"

    const-string/jumbo v2, "illegal ref"

    invoke-direct {v0, v2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "illegal ref, "

    const-string/jumbo v3, "illegal ref, "

    const-string/jumbo v3, "illegal ref, "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v9}, Lcom/alibaba/fastjson/parser/f;->a(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    invoke-interface/range {p1 .. p1}, Ljava/util/Map;->size()I

    move-result v7

    if-nez v7, :cond_a

    if-ne v9, v14, :cond_a

    const-string/jumbo v7, "ouepy"

    const-string v7, "eytpo"

    const-string v7, "@type"

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_a

    sget-object v7, Lcom/alibaba/fastjson/parser/d;->p:Lcom/alibaba/fastjson/parser/d;

    invoke-virtual {v4, v7}, Lcom/alibaba/fastjson/parser/e;->n(Lcom/alibaba/fastjson/parser/d;)Z

    move-result v7

    if-nez v7, :cond_a

    invoke-virtual {v4, v11}, Lcom/alibaba/fastjson/parser/e;->v(C)V

    const/16 v7, 0x10

    invoke-virtual {v4, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    iget v7, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    if-ne v7, v10, :cond_9

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->t()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {v1, v8}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    return-object v0

    :cond_9
    :try_start_3
    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->t()V

    :cond_a
    const/4 v7, 0x0

    invoke-interface {v5, v1, v2, v7}, Lcom/alibaba/fastjson/parser/deserializer/f;->a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    iget v9, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    const/16 v10, 0x11

    if-ne v9, v10, :cond_d

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->t()V

    invoke-interface {v6, v1, v3, v7}, Lcom/alibaba/fastjson/parser/deserializer/f;->a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    iget v10, v1, Lcom/alibaba/fastjson/parser/b;->j:I

    if-ne v10, v13, :cond_b

    invoke-virtual {v1, v0, v7}, Lcom/alibaba/fastjson/parser/b;->d(Ljava/util/Map;Ljava/lang/Object;)V

    :cond_b
    invoke-interface {v0, v7, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget v7, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    const/16 v9, 0x10

    if-ne v7, v9, :cond_c

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->t()V

    :cond_c
    move v7, v9

    move v7, v9

    move v7, v9

    move v7, v9

    goto/16 :goto_1

    :cond_d
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " eon t pxeaelryb puca,r a,s:xtt"

    const-string/jumbo v3, "otrx beu xly aptae cr,a:nrs, te"

    const-string/jumbo v3, "xe x u aqertste,p, yatcarcnlo:r"

    const-string/jumbo v3, "syntax error, expect :, actual "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v4, Lcom/alibaba/fastjson/parser/e;->a:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    move-exception v0

    invoke-virtual {v1, v8}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    throw v0
.end method

.method public static d(Lcom/alibaba/fastjson/parser/b;Ljava/util/Map;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/util/Map;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/Map;"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "@@sa K~/ @@~ of~@1to@~@ t~~ @l i@@~@@@of~~ ~ @ um~n /loo~@r~s-~~~~c   @~4@v b~@SM d.i b@~~bo~@ i"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v10, 0x6

    iget v1, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v2, 0xc

    const/4 v9, 0x7

    move v10, v9

    if-ne v1, v2, :cond_f

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/b;->f:Lcom/alibaba/fastjson/parser/l;

    :cond_0
    :try_start_0
    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x2

    const/4 v9, 0x2

    iget-char v2, v0, Lcom/alibaba/fastjson/parser/e;->d:C

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v3, 0x2c

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ne v2, v3, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->r()C

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-char v2, v0, Lcom/alibaba/fastjson/parser/e;->d:C
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    const-string/jumbo v3, "syntax error, "

    const-string/jumbo v3, "syntax error, "

    const/4 v10, 0x5

    const-string/jumbo v3, "syntax error, "

    const-string/jumbo v3, "syntax error, "

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v4, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/16 v5, 0x3a

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/16 v6, 0x22

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/16 v7, 0x10

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-ne v2, v6, :cond_3

    :try_start_1
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/b;->a:Lcom/alibaba/fastjson/parser/o;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v2, v6}, Lcom/alibaba/fastjson/parser/e;->V(Lcom/alibaba/fastjson/parser/o;C)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-char v8, v0, Lcom/alibaba/fastjson/parser/e;->d:C

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-ne v8, v5, :cond_2

    const/4 v10, 0x6

    goto/16 :goto_1

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->j()Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    throw p1

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/16 v8, 0x7d

    if-ne v2, v8, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->r()C

    const/4 v10, 0x3

    iput v4, v0, Lcom/alibaba/fastjson/parser/e;->h:I

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object p1

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 v8, 0x27

    const/4 v10, 0x2

    if-ne v2, v8, :cond_6

    :try_start_2
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/b;->a:Lcom/alibaba/fastjson/parser/o;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v2, v8}, Lcom/alibaba/fastjson/parser/e;->V(Lcom/alibaba/fastjson/parser/o;C)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-char v8, v0, Lcom/alibaba/fastjson/parser/e;->d:C

    const/4 v10, 0x2

    const/4 v9, 0x5

    if-ne v8, v5, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_1

    :cond_5
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v10, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->j()Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    throw p1

    :cond_6
    const/4 v10, 0x5

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/b;->a:Lcom/alibaba/fastjson/parser/o;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/parser/e;->W(Lcom/alibaba/fastjson/parser/o;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-char v3, v0, Lcom/alibaba/fastjson/parser/e;->d:C

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ne v3, v5, :cond_e

    :goto_1
    const/4 v9, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->r()C

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->b0()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    iput v4, v0, Lcom/alibaba/fastjson/parser/e;->h:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string/jumbo v3, "u@tme"

    const-string v3, "@uyet"

    const/4 v10, 0x2

    const-string v3, "@tpeo"

    const-string v3, "@type"

    const/4 v9, 0x5

    and-int/2addr v10, v9

    const/16 v4, 0xd

    const/4 v9, 0x5

    move v10, v9

    const/4 v5, 0x0

    move v10, v5

    const/4 v9, 0x1

    or-int/2addr v10, v9

    if-ne v2, v3, :cond_9

    const/4 v10, 0x5

    sget-object v3, Lcom/alibaba/fastjson/parser/d;->p:Lcom/alibaba/fastjson/parser/d;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->n(Lcom/alibaba/fastjson/parser/d;)Z

    move-result v3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-nez v3, :cond_9

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/b;->a:Lcom/alibaba/fastjson/parser/o;

    const/4 v9, 0x4

    shr-int/2addr v10, v9

    invoke-virtual {v0, v2, v6}, Lcom/alibaba/fastjson/parser/e;->V(Lcom/alibaba/fastjson/parser/o;C)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget v6, v0, Lcom/alibaba/fastjson/parser/e;->c:I

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v3, v2, v5, v6}, Lcom/alibaba/fastjson/parser/m;->a(Ljava/lang/String;Ljava/lang/Class;I)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-ne v2, v3, :cond_7

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget v2, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ne v2, v4, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v0, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    return-object p1

    :cond_7
    :try_start_3
    const/4 v10, 0x0

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v10, 0x2

    invoke-virtual {p1, v2}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v0, v7}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 p2, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    iput p2, p0, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v1, :cond_8

    const/4 v9, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    instance-of p2, p3, Ljava/lang/Integer;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-nez p2, :cond_8

    const/4 v10, 0x1

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/b;->v0()V

    :cond_8
    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-interface {p1, p0, v2, p3}, Lcom/alibaba/fastjson/parser/deserializer/f;->a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    check-cast p1, Ljava/util/Map;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-object p1

    :cond_9
    :try_start_4
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget v3, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/16 v6, 0x8

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-ne v3, v6, :cond_a

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    const/4 v10, 0x7

    goto :goto_2

    :cond_a
    const/4 v10, 0x0

    invoke-virtual {p0, p2, v2}, Lcom/alibaba/fastjson/parser/b;->k0(Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    :goto_2
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-interface {p1, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget v3, p0, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v6, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-ne v3, v6, :cond_b

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p0, p1, v2}, Lcom/alibaba/fastjson/parser/b;->d(Ljava/util/Map;Ljava/lang/Object;)V

    :cond_b
    const/4 v9, 0x7

    const/4 v9, 0x5

    invoke-virtual {p0, v1, v5, v2}, Lcom/alibaba/fastjson/parser/b;->A0(Lcom/alibaba/fastjson/parser/l;Ljava/lang/Object;Ljava/lang/Object;)Lcom/alibaba/fastjson/parser/l;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget v2, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v3, 0x14

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-eq v2, v3, :cond_d

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/16 v3, 0xf

    const/4 v10, 0x0

    if-ne v2, v3, :cond_c

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto :goto_3

    :cond_c
    const/4 v9, 0x1

    move v10, v9

    if-ne v2, v4, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x4

    return-object p1

    :cond_d
    :goto_3
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    return-object p1

    :cond_e
    :try_start_5
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string p3, "ce epb /xatpt/:/"

    const-string/jumbo p3, "t/// e:px/eatcp "

    const/4 v10, 0x2

    const-string p3, "expect \':\' at "

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget p3, v0, Lcom/alibaba/fastjson/parser/e;->b:I

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string/jumbo p3, "l act,uuq"

    const-string/jumbo p3, "tla,u acq"

    const/4 v10, 0x1

    const-string p3, "c  aulapt"

    const-string p3, ", actual "

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p0, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v9, 0x1

    move v10, v9

    throw p1

    :cond_f
    const/4 v10, 0x3

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const-string/jumbo p2, "uyseaarpqx e,ctsr,rttnc{ o   la"

    const-string/jumbo p2, "tns,toa rsc yxeuxa{rlp , eatr c"

    const/4 v10, 0x7

    const-string/jumbo p2, "tosxtlcrr, e,aa{ea rysec px ut "

    const-string/jumbo p2, "syntax error, expect {, actual "

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget p2, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    shl-int/2addr v10, v9

    throw p0
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-class v0, Lcom/alibaba/fastjson/e;

    const-class v0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x2

    const-class v0, Lcom/alibaba/fastjson/e;

    const-class v0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ne p2, v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->m:Lcom/alibaba/fastjson/parser/deserializer/e;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->d0()Lcom/alibaba/fastjson/e;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget v1, v0, Lcom/alibaba/fastjson/parser/e;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v2, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne v1, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 p1, 0x10

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p1

    :cond_1
    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, p2}, Lcom/alibaba/fastjson/parser/k;->b(Ljava/lang/reflect/Type;)Ljava/util/Map;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    iget-object v1, p1, Lcom/alibaba/fastjson/parser/b;->f:Lcom/alibaba/fastjson/parser/l;

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v0, p3}, Lcom/alibaba/fastjson/parser/b;->A0(Lcom/alibaba/fastjson/parser/l;Ljava/lang/Object;Ljava/lang/Object;)Lcom/alibaba/fastjson/parser/l;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    instance-of v2, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    check-cast p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    aget-object v2, v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    aget-object p2, p2, v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne v3, v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1, v0, p2, p3}, Lcom/alibaba/fastjson/parser/k;->d(Lcom/alibaba/fastjson/parser/b;Ljava/util/Map;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object p2

    :cond_2
    :try_start_1
    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p1, v0, v2, p2, p3}, Lcom/alibaba/fastjson/parser/k;->c(Lcom/alibaba/fastjson/parser/b;Ljava/util/Map;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object p2

    :cond_3
    :try_start_2
    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1, v0, p3}, Lcom/alibaba/fastjson/parser/b;->r0(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object p2

    :catchall_0
    move-exception p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lcom/alibaba/fastjson/parser/b;->D0(Lcom/alibaba/fastjson/parser/l;)V

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p2
.end method

.method protected b(Ljava/lang/reflect/Type;)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/util/Map<",
            "**>;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-class v0, Ljava/util/Properties;

    const-class v0, Ljava/util/Properties;

    const/4 v5, 0x5

    const-class v0, Ljava/util/Properties;

    const-class v0, Ljava/util/Properties;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ne p1, v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance p1, Ljava/util/Properties;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p1}, Ljava/util/Properties;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const-class v0, Ljava/util/Hashtable;

    const-class v0, Ljava/util/Hashtable;

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-ne p1, v0, :cond_1

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance p1, Ljava/util/Hashtable;

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-direct {p1}, Ljava/util/Hashtable;-><init>()V

    const/4 v4, 0x5

    move v5, v4

    return-object p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-class v0, Ljava/util/IdentityHashMap;

    const-class v0, Ljava/util/IdentityHashMap;

    const/4 v5, 0x4

    const-class v0, Ljava/util/IdentityHashMap;

    const-class v0, Ljava/util/IdentityHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne p1, v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x6

    new-instance p1, Ljava/util/IdentityHashMap;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p1}, Ljava/util/IdentityHashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-class v0, Ljava/util/SortedMap;

    const/4 v5, 0x3

    const-class v0, Ljava/util/SortedMap;

    const-class v0, Ljava/util/SortedMap;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq p1, v0, :cond_d

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-class v0, Ljava/util/TreeMap;

    const-class v0, Ljava/util/TreeMap;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne p1, v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto/16 :goto_2

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const/4 v5, 0x2

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eq p1, v0, :cond_c

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x1

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ne p1, v0, :cond_4

    const/4 v5, 0x2

    goto/16 :goto_1

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v5, 0x7

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eq p1, v0, :cond_b

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-class v0, Ljava/util/HashMap;

    const-class v0, Ljava/util/HashMap;

    const/4 v5, 0x4

    const-class v0, Ljava/util/HashMap;

    const-class v0, Ljava/util/HashMap;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ne p1, v0, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-class v0, Ljava/util/LinkedHashMap;

    const-class v0, Ljava/util/LinkedHashMap;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne p1, v0, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p1, Ljava/util/LinkedHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p1

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-class v0, Lcom/alibaba/fastjson/e;

    const-class v0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x2

    const-class v0, Lcom/alibaba/fastjson/e;

    const-class v0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x1

    move v5, v4

    if-ne p1, v0, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance p1, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1}, Lcom/alibaba/fastjson/e;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object p1

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    instance-of v0, p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    check-cast p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-class v1, Ljava/util/EnumMap;

    const-class v1, Ljava/util/EnumMap;

    const/4 v5, 0x5

    const-class v1, Ljava/util/EnumMap;

    const-class v1, Ljava/util/EnumMap;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_8

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/util/EnumMap;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    aget-object p1, p1, v1

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    check-cast p1, Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object v0

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/parser/k;->b(Ljava/lang/reflect/Type;)Ljava/util/Map;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p1

    :cond_9
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    check-cast v0, Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->isInterface()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v2, "n tmusrutpey op"

    const-string/jumbo v2, "unsupport type "

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v1, :cond_a

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast v0, Ljava/util/Map;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1, p1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    throw v1

    :cond_a
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p1, Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object p1

    :cond_c
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1

    :cond_d
    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p1, Ljava/util/TreeMap;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p1}, Ljava/util/TreeMap;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object p1
.end method
