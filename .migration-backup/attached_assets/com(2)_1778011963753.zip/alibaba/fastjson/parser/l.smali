.class public Lcom/alibaba/fastjson/parser/l;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/Object;

.field public final b:Lcom/alibaba/fastjson/parser/l;

.field public final c:Ljava/lang/Object;

.field public d:Ljava/lang/reflect/Type;

.field private transient e:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/parser/l;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/alibaba/fastjson/parser/l;->a:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/alibaba/fastjson/parser/l;->c:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/l;->e:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "$"

    const-string v0, "$"

    const/4 v3, 0x2

    const-string v0, "$"

    const-string v0, "$"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/l;->e:Ljava/lang/String;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/l;->c:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    instance-of v0, v0, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/l;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "["

    const-string v1, "["

    const/4 v3, 0x4

    const-string v1, "["

    const-string v1, "["

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/l;->c:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/l;->e:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/l;->b:Lcom/alibaba/fastjson/parser/l;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/l;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "."

    const-string v1, "."

    const-string v1, "."

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/l;->c:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/l;->e:Ljava/lang/String;

    :cond_2
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/l;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method
