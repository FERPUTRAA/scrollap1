.class public Lcom/alibaba/fastjson/parser/c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# instance fields
.field private final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field protected final b:[Ljava/lang/Enum;

.field protected final c:[Ljava/lang/Enum;

.field protected d:[J


# direct methods
.method public constructor <init>(Ljava/lang/Class;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/c;->a:Ljava/lang/Class;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    check-cast p1, [Ljava/lang/Enum;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/c;->c:[Ljava/lang/Enum;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    array-length v0, p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-array v1, v0, [J

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    array-length p1, p1

    const/4 v10, 0x4

    new-array p1, p1, [J

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 p1, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    move v2, p1

    const/4 v10, 0x6

    move v2, p1

    move v2, p1

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/c;->c:[Ljava/lang/Enum;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    array-length v4, v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    if-ge v2, v4, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    aget-object v3, v3, v2

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v3}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-wide v4, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v4, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v10, 0x2

    const-wide v4, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v4, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    move v6, p1

    move v6, p1

    const/4 v10, 0x0

    move v6, p1

    move v6, p1

    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v10, 0x3

    const/4 v9, 0x1

    if-ge v6, v7, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v3, v6}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x4

    int-to-long v7, v7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    xor-long/2addr v4, v7

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-wide v7, 0x100000001b3L

    const-wide v7, 0x100000001b3L

    const/4 v10, 0x4

    const-wide v7, 0x100000001b3L

    const-wide v7, 0x100000001b3L

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    mul-long/2addr v4, v7

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_1

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    aput-wide v4, v1, v2

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    aput-wide v4, v3, v2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v2}, Ljava/util/Arrays;->sort([J)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/c;->c:[Ljava/lang/Enum;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    array-length v2, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-array v2, v2, [Ljava/lang/Enum;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    iput-object v2, p0, Lcom/alibaba/fastjson/parser/c;->b:[Ljava/lang/Enum;

    const/4 v10, 0x5

    const/4 v9, 0x0

    move v2, p1

    move v2, p1

    move v2, p1

    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    array-length v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-ge v2, v3, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    move v3, p1

    move v3, p1

    const/4 v10, 0x5

    move v3, p1

    move v3, p1

    :goto_3
    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-ge v3, v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v4, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    aget-wide v5, v4, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    aget-wide v7, v1, v3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    cmp-long v4, v5, v7

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-nez v4, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v4, p0, Lcom/alibaba/fastjson/parser/c;->b:[Ljava/lang/Enum;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v5, p0, Lcom/alibaba/fastjson/parser/c;->c:[Ljava/lang/Enum;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    aget-object v3, v5, v3

    const/4 v10, 0x1

    const/4 v9, 0x1

    aput-object v3, v4, v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_4

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_3

    :cond_3
    :goto_4
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    goto :goto_2

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Ms@~o~ at~ @o~@@@i @c@u~ @@lorbl~@nvbs~i ~~@~K@oy~1 o-o// S@~@ b~@4  ~~@  f~@i ~~~@.dm ~@ f ~ t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget-object p2, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget p3, p2, Lcom/alibaba/fastjson/parser/e;->a:I
    :try_end_0
    .catch Lcom/alibaba/fastjson/d; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v1, " as: er u,r relv"

    const-string v1, " error, value : "

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "unmmr esem "

    const-string v2, "a emnr sume"

    const/4 v6, 0x1

    const-string/jumbo v2, "ma eonres p"

    const-string/jumbo v2, "parse enum "

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/16 v3, 0x10

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-ne p3, v0, :cond_1

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2}, Lcom/alibaba/fastjson/parser/e;->k()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p2, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ltz p1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p2, p0, Lcom/alibaba/fastjson/parser/c;->c:[Ljava/lang/Enum;

    const/4 v6, 0x7

    const/4 v5, 0x7

    array-length p3, p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-gt p1, p3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    aget-object p1, p2, p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object p1

    :cond_0
    const/4 v6, 0x7

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    move v6, v5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/c;->a:Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p2, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    throw p2

    :cond_1
    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v0, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-ne p3, v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p2}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p2, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez p2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object v4

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-wide p2, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide p2, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v6, 0x7

    const-wide p2, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide p2, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ge v0, v1, :cond_3

    const/4 v6, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    int-to-long v1, v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    xor-long/2addr p2, v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-wide v1, 0x100000001b3L

    const-wide v1, 0x100000001b3L

    const-wide v1, 0x100000001b3L

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    mul-long/2addr p2, v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/c;->d:[J

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1, p2, p3}, Ljava/util/Arrays;->binarySearch([JJ)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    if-gez p1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x4

    return-object v4

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object p2, p0, Lcom/alibaba/fastjson/parser/c;->b:[Ljava/lang/Enum;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    aget-object p1, p2, p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p1

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v0, 0x8

    const/4 v6, 0x6

    const/4 v5, 0x1

    if-ne p3, v0, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p2, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v4

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/c;->a:Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p2, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    throw p2
    :try_end_1
    .catch Lcom/alibaba/fastjson/d; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p2, p3, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    throw p2

    :catch_1
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    throw p1
.end method
