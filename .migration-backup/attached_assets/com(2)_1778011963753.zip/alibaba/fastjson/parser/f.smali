.class public Lcom/alibaba/fastjson/parser/f;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0x1

.field public static final b:I = 0x2

.field public static final c:I = 0x3

.field public static final d:I = 0x4

.field public static final e:I = 0x5

.field public static final f:I = 0x6

.field public static final g:I = 0x7

.field public static final h:I = 0x8

.field public static final i:I = 0x9

.field public static final j:I = 0xa

.field public static final k:I = 0xb

.field public static final l:I = 0xc

.field public static final m:I = 0xd

.field public static final n:I = 0xe

.field public static final o:I = 0xf

.field public static final p:I = 0x10

.field public static final q:I = 0x11

.field public static final r:I = 0x12

.field public static final s:I = 0x14

.field public static final t:I = 0x15

.field public static final u:I = 0x16

.field public static final v:I = 0x17


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method

.method public static a(I)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sf @~~oo @dMb -m ~ /@~~@~@i@ il./@crf ~~s~ ~o@@ @@@ ny4@ @@@@K @b1@~~ t~~b ~~vS~il oa~u~~ @o~o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    packed-switch p0, :pswitch_data_0

    :pswitch_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    const-string/jumbo p0, "onnmwkn"

    const-string/jumbo p0, "nwsknon"

    const/4 v1, 0x3

    const-string/jumbo p0, "nwUnokn"

    const-string p0, "Unknown"

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0

    :pswitch_1
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    const-string p0, "euddfbine"

    const-string/jumbo p0, "undefined"

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0

    :pswitch_2
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    const-string p0, "eTtmeru"

    const-string p0, "Tetmree"

    const/4 v1, 0x0

    const-string/jumbo p0, "prtTSee"

    const-string p0, "TreeSet"

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0

    :pswitch_3
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string/jumbo p0, "tSe"

    const-string p0, "Set"

    const-string/jumbo p0, "tSe"

    const-string p0, "Set"

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0

    :pswitch_4
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    const-string p0, "EOF"

    const-string p0, "EFO"

    const/4 v1, 0x4

    const-string p0, "EFO"

    const-string p0, "EOF"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0

    :pswitch_5
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    const-string p0, "dnoqi"

    const-string/jumbo p0, "itdno"

    const/4 v1, 0x7

    const-string p0, "edsin"

    const-string/jumbo p0, "ident"

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0

    :pswitch_6
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    const-string p0, ":"

    const-string p0, ":"

    const/4 v1, 0x5

    const-string p0, ":"

    const-string p0, ":"

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0

    :pswitch_7
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    const-string p0, ","

    const-string p0, ","

    const/4 v1, 0x5

    const-string p0, ","

    const-string p0, ","

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-object p0

    :pswitch_8
    const/4 v1, 0x6

    const-string p0, "]"

    const-string p0, "]"

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0

    :pswitch_9
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    const-string p0, "["

    const-string p0, "["

    const/4 v1, 0x1

    const-string p0, "["

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0

    :pswitch_a
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    const-string/jumbo p0, "}"

    const-string/jumbo p0, "}"

    const/4 v1, 0x2

    const-string/jumbo p0, "}"

    const-string/jumbo p0, "}"

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0

    :pswitch_b
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string/jumbo p0, "{"

    const-string/jumbo p0, "{"

    const/4 v1, 0x3

    const-string/jumbo p0, "{"

    const-string/jumbo p0, "{"

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0

    :pswitch_c
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    const-string p0, ")"

    const-string p0, ")"

    const/4 v1, 0x7

    const-string p0, ")"

    const-string p0, ")"

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0

    :pswitch_d
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    const-string p0, "("

    const-string p0, "("

    const/4 v1, 0x2

    const-string p0, "("

    const-string p0, "("

    const/4 v1, 0x6

    return-object p0

    :pswitch_e
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    const-string p0, "ewn"

    const-string/jumbo p0, "wen"

    const/4 v1, 0x0

    const-string/jumbo p0, "nwe"

    const-string/jumbo p0, "new"

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0

    :pswitch_f
    const/4 v1, 0x0

    const/4 v0, 0x5

    const-string/jumbo p0, "lnlu"

    const-string/jumbo p0, "nlul"

    const/4 v1, 0x4

    const-string/jumbo p0, "lunl"

    const-string/jumbo p0, "null"

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0

    :pswitch_10
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    const-string p0, "efamb"

    const-string p0, "blaef"

    const/4 v1, 0x5

    const-string p0, "afslo"

    const-string p0, "false"

    const/4 v0, 0x7

    move v1, v0

    return-object p0

    :pswitch_11
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string/jumbo p0, "uert"

    const-string/jumbo p0, "ture"

    const/4 v1, 0x5

    const-string/jumbo p0, "uetr"

    const-string/jumbo p0, "true"

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0

    :pswitch_12
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    const-string p0, "1uis0b6"

    const-string p0, "81is06u"

    const/4 v1, 0x2

    const-string/jumbo p0, "s6180iu"

    const-string/jumbo p0, "iso8601"

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0

    :pswitch_13
    const/4 v0, 0x4

    const/4 v1, 0x7

    const-string/jumbo p0, "npripg"

    const-string p0, "gprnit"

    const/4 v1, 0x0

    const-string/jumbo p0, "itqsrn"

    const-string/jumbo p0, "string"

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-object p0

    :pswitch_14
    const/4 v1, 0x4

    const/4 v0, 0x3

    const-string/jumbo p0, "lfsao"

    const-string p0, "aolqf"

    const/4 v1, 0x2

    const-string/jumbo p0, "tflma"

    const-string p0, "float"

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0

    :pswitch_15
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    const-string/jumbo p0, "tni"

    const-string/jumbo p0, "tin"

    const/4 v1, 0x4

    const-string/jumbo p0, "int"

    const-string/jumbo p0, "int"

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0

    :pswitch_16
    const/4 v0, 0x2

    const/4 v1, 0x4

    const-string p0, "ersro"

    const/4 v1, 0x1

    const-string/jumbo p0, "rroro"

    const-string p0, "error"

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
