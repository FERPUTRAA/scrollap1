.class Lcom/alibaba/fastjson/parser/o$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alibaba/fastjson/parser/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field final a:Ljava/lang/String;

.field final b:[C

.field final c:I


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/o$a;->a:Ljava/lang/String;

    const/4 v0, 0x0

    and-int/2addr v1, v0

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/o$a;->b:[C

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput p2, p0, Lcom/alibaba/fastjson/parser/o$a;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
