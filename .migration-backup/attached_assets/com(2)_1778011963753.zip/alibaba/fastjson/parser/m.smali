.class public Lcom/alibaba/fastjson/parser/m;
.super Ljava/lang/Object;


# static fields
.field private static f:[J

.field public static g:Lcom/alibaba/fastjson/parser/m;


# instance fields
.field private final a:Lq0/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lq0/b<",
            "Lcom/alibaba/fastjson/parser/deserializer/f;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Lcom/alibaba/fastjson/parser/o;

.field public c:Ljava/lang/ClassLoader;

.field public d:Lcom/alibaba/fastjson/j;

.field public e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x87

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-array v0, v0, [J

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    fill-array-data v0, :array_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Lcom/alibaba/fastjson/parser/m;->f:[J

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lcom/alibaba/fastjson/parser/m;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/alibaba/fastjson/parser/m;-><init>()V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    sput-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    :array_0
    .array-data 8
        -0x7f2f38f433d015feL    # -9.556794763479643E-305
        -0x7903d40641508511L    # -5.085553800937495E-275
        -0x780ad5e4f815cc5aL
        -0x71522bf34d56bbbdL
        -0x708a0605f20fc080L    # -3.455901468587826E-234
        -0x6e8d5ac0ea86cf51L
        -0x6dedd28ef1c9b048L    # -1.257180119856368E-221
        -0x6be79918c4100b37L    # -7.248495544345653E-212
        -0x6bcfa3d9a7f08c3bL    # -1.943861383644949E-211
        -0x6bc886d7ce2082c1L
        -0x5edc59d06ce874e0L    # -4.802155510082355E-149
        -0x57a77d31efbb3bb0L
        -0x55c250024ef3b6c9L
        -0x539d9d0ad36755c7L    # -6.886391444241167E-95
        -0x526c85bb67ce1760L    # -3.824696155682281E-89
        -0x51af25e0529f5f6aL    # -1.3554199460470375E-85
        -0x5000b36a4665ccb3L    # -1.6894051133204177E-77
        -0x4bf0cbe38b9136b1L    # -6.213767217225293E-58
        -0x4817128a80a2ec5eL    # -2.2892361373052172E-39
        -0x467494ac696cd017L    # -1.6898413909066546E-31
        -0x4322623ed8990f32L    # -1.644030941651994E-15
        -0x41458d04e3345bdaL    # -1.5764918430089148E-6
        -0x3ff41e21450d7f75L    # -3.485288105512216
        -0x3ef795051cd19da8L    # -200031.3609283145
        -0x3d99b2f6a71301b4L    # -7.662539098639468E11
        -0x3be00836378383fbL    # -1.4742602222991634E20
        -0x399b4c9c4535faf6L    # -1.3120653062289765E31
        -0x38a661401c18dbfaL    # -5.3210898116926836E35
        -0x372b61a9fe199e57L    # -7.184498624325357E42
        -0x369c96af7d028d72L    # -3.463106763999075E45
        -0x2e10320b4cce92ccL    # -4.9428513655242083E86
        -0x2ab46e33884dc613L    # -7.718587662525667E102
        -0x2a6116e0f4f615ffL    # -2.769276834562512E104
        -0x299097546d18010bL    # -2.305158249887012E108
        -0x2735c2a6a167d454L    # -5.293540616952125E119
        -0x232729ea59bb61c2L    # -1.8485208306343955E139
        -0x21dc5f7f6574642aL    # -3.063522061072579E145
        -0x2103df70dc82befcL    # -3.5965336067206575E149
        -0x20d2200cef324c8bL    # -3.0559968239287952E150
        -0x1f651b9fb7bda7d1L    # -2.3076098125244163E157
        -0x1e6e67fb2a40b971L    # -9.894137060283861E161
        -0x1d14c5381a93b982L    # -3.211360471030518E168
        -0x19fc295ae05296d5L    # -2.6342395696172524E183
        -0x16e7b41aa4e269d6L    # -1.816185970555075E198
        -0x160df452da09f7f9L    # -2.2100835374064227E202
        -0xd67c2f662d64b89L    # -1.0343819992267985E244
        -0xc8fd5b5ab6f4718L
        -0xb8b1bbae70d98caL    # -9.573036758577548E252
        -0x816918b205a7244L
        -0x388c51df37d896fL
        -0x30c1879bb467428L    # -7.945197787260532E293
        -0x2a4039effa928e0L    # -7.14947811210233E295
        -0x5ea40fde0e1c84L
        -0x22e57f0e12cbfbL
        0x10e067cd55c5e5L
        0x761619136cc13eL
        0x22baa234c5bfb8aL
        0x3085068cb7201b8L
        0x45b11bc78a3aba3L
        0x55cfca0f2281c07L
        0xb6e292fa5955adeL
        0xee6511b66fd5ef0L    # 6.854342740564376E-237
        0x100150a253996624L    # 1.394104277479804E-231
        0x10b2bdca849d9b3eL    # 3.09032861507223E-228
        0x10dbc48446e0dae5L
        0x144277b467723158L    # 4.388573993986807E-211
        0x14db2e6fead04af0L    # 3.307156557815155E-208
        0x154b6cb22d294cfaL    # 4.271035506616844E-206
        0x17924cca5227622aL
        0x193b2697eaaed41aL    # 3.9000001662652114E-187
        0x1cd6f11c6a358bb7L    # 9.498405308272427E-170
        0x1e0a8c3358ff3daeL    # 5.762601583556236E-164
        0x24652ce717e713bbL
        0x24d2f6048fef4e49L
        0x24ec99d5e7dc5571L    # 8.058828264835688E-131
        0x25e962f1c28f71a2L
        0x275d0732b877af29L
        0x28ac82e44e933606L
        0x2ad1ce3a112f015dL
        0x2adfefbbfe29d931L
        0x2b3a37467a344cdfL
        0x2b6dd8b3229d6837L    # 1.7057077092413725E-99
        0x2d308dbbc851b0d8L    # 5.078962391870398E-91
        0x2fe950d3ea52ae0dL    # 6.832216944281275E-78
        0x313bb4abd8d4554cL    # 1.56808971921097E-71
        0x327c8ed7c8706905L    # 1.6948389662237084E-65
        0x332f0b5369a18310L
        0x339a3e0b6beebee9L    # 4.0826654570968825E-60
        0x33c64b921f523f2fL    # 2.77486720533494E-59
        0x34a81ee78429fdf1L    # 4.918595094295287E-55
        0x378307cb0111e878L    # 2.730734411398275E-41
        0x3826f4b2380c8b9bL    # 3.373058177088523E-38
        0x398f942e01920cf0L    # 1.9461954727645544E-31
        0x3a31412dbb05c7ffL    # 2.1778372103247874E-28
        0x3adba40367f73264L    # 3.5724737671988184E-25
        0x3b0b51ecbf6db221L    # 2.8248237289442712E-24
        0x42d11a560fc9fba9L    # 7.521924278884664E13
        0x43320dc9d2ae0892L    # 5.08171005500021E15
        0x440e89208f445fb9L    # 7.041042216469549E19
        0x46c808a4b5841f57L    # 9.749252615377375E32
        0x49312bdafb0077d9L    # 3.829330118647328E44
        0x4a3797b30328202cL    # 3.448058737338662E49
        0x4ba3e254e758d70dL    # 2.4377845509161763E56
        0x4bf881e49d37f530L    # 9.614713083096315E57
        0x4cf54eec05e3e818L    # 5.478576021141778E62
        0x4da972745feb30c1L    # 1.339945589251118E66
        0x4ef08c90ff16c675L    # 1.8274816638330285E72
        0x4fd10ddc6d13821fL    # 3.085523505057036E76
        0x527db6b46ce3bcbcL    # 2.3643694017797754E89
        0x535e552d6f9700c1L    # 3.954486474370437E93
        0x5728504a6d454ffcL    # 7.309005913296069E111
        0x599b5c1213a099acL    # 4.521565120980506E123
        0x5a5bd85c072e5efeL
        0x5ab0cb3071ab40d1L    # 7.275532043244496E128
        0x5b6149820275ea42L
        0x5d74d3e5b9370476L    # 1.5873759122766088E142
        0x5d92e6ddde40ed84L    # 5.762376793011253E142
        0x5f215622fb630753L    # 1.773407570959078E150
        0x61c5bdd721385107L    # 9.781342160839794E162
        0x62db241274397c34L
        0x63a220e60a17c7b9L    # 8.757288450874107E171
        0x647ab0224e149ebeL    # 1.0561215288164044E176
        0x65f81b84c1d920cdL    # 1.6005507777082922E183
        0x665c53c311193973L    # 1.2036519694555594E185
        0x6749835432e0f0d2L
        0x69b6e0175084b377L    # 1.750995289311963E201
        0x6a47501ebb2afdb2L    # 9.136601149026956E203
        0x6fcabf6fa54cafffL    # 3.244253068846464E230
        0x746bd4a53ec195fbL    # 6.376313675246868E252
        0x74b50bb9260e31ffL    # 1.5429848812177576E254
        0x75cc60f5871d0fd3L    # 2.7270901325332595E259
        0x767a586a5107feefL    # 5.184902282980218E262
        0x7aa7ee3627a19cf3L    # 6.950210684357695E282
        0x7ed9311d28bf1a65L    # 1.0797314149657436E303
        0x7ed9481d28bf417aL    # 1.0835821490243428E303
    .end array-data
.end method

.method public constructor <init>()V
    .locals 8

    const/4 v6, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x0

    or-int/2addr v7, v6

    new-instance v0, Lq0/b;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/16 v1, 0x400

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v0, v1}, Lq0/b;-><init>(I)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v1, Lcom/alibaba/fastjson/parser/o;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/16 v2, 0x4000

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-direct {v1, v2}, Lcom/alibaba/fastjson/parser/o;-><init>(I)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/m;->b:Lcom/alibaba/fastjson/parser/o;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x2

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget-object v2, Lcom/alibaba/fastjson/serializer/h;->a:Lcom/alibaba/fastjson/serializer/h;

    const-class v3, Ljava/util/Date;

    const-class v3, Ljava/util/Date;

    const/4 v7, 0x1

    const-class v3, Ljava/util/Date;

    const-class v3, Ljava/util/Date;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-class v3, Ljava/util/Calendar;

    const-class v3, Ljava/util/Calendar;

    const-class v3, Ljava/util/Calendar;

    const-class v3, Ljava/util/Calendar;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const-class v2, Ljava/util/Map;

    const-class v2, Ljava/util/Map;

    const/4 v7, 0x3

    const-class v2, Ljava/util/Map;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-class v2, Ljava/util/HashMap;

    const-class v2, Ljava/util/HashMap;

    const/4 v7, 0x1

    const-class v2, Ljava/util/HashMap;

    const-class v2, Ljava/util/HashMap;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-class v2, Ljava/util/LinkedHashMap;

    const-class v2, Ljava/util/LinkedHashMap;

    const/4 v7, 0x4

    const-class v2, Ljava/util/LinkedHashMap;

    const-class v2, Ljava/util/LinkedHashMap;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-class v2, Ljava/util/TreeMap;

    const-class v2, Ljava/util/TreeMap;

    const/4 v7, 0x0

    const-class v2, Ljava/util/TreeMap;

    const-class v2, Ljava/util/TreeMap;

    const/4 v7, 0x6

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-class v2, Ljava/util/concurrent/ConcurrentMap;

    const-class v2, Ljava/util/concurrent/ConcurrentMap;

    const/4 v7, 0x5

    const-class v2, Ljava/util/concurrent/ConcurrentMap;

    const-class v2, Ljava/util/concurrent/ConcurrentMap;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x5

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    move v7, v6

    sget-object v3, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object v2, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-class v3, Ljava/util/Collection;

    const-class v3, Ljava/util/Collection;

    const/4 v7, 0x3

    const-class v3, Ljava/util/Collection;

    const-class v3, Ljava/util/Collection;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v7, 0x3

    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-class v3, Ljava/util/ArrayList;

    const-class v3, Ljava/util/ArrayList;

    const/4 v7, 0x7

    const-class v3, Ljava/util/ArrayList;

    const-class v3, Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget-object v2, Lcom/alibaba/fastjson/parser/i;->a:Lcom/alibaba/fastjson/parser/i;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-class v3, Ljava/lang/Object;

    const-class v3, Ljava/lang/Object;

    const/4 v7, 0x4

    const-class v3, Ljava/lang/Object;

    const-class v3, Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-class v3, Ljava/lang/String;

    const/4 v7, 0x7

    const-class v3, Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    sget-object v4, Lcom/alibaba/fastjson/serializer/c0;->a:Lcom/alibaba/fastjson/serializer/c0;

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget-object v3, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Character;

    const-class v3, Ljava/lang/Character;

    const/4 v7, 0x0

    const-class v3, Ljava/lang/Character;

    const-class v3, Ljava/lang/Character;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object v3, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    sget-object v4, Lcom/alibaba/fastjson/serializer/s;->b:Lcom/alibaba/fastjson/serializer/s;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-class v3, Ljava/lang/Byte;

    const-class v3, Ljava/lang/Byte;

    const/4 v7, 0x0

    const-class v3, Ljava/lang/Byte;

    const-class v3, Ljava/lang/Byte;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object v3, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Short;

    const-class v3, Ljava/lang/Short;

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-object v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x0

    sget-object v5, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-class v3, Ljava/lang/Integer;

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Integer;

    const-class v3, Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-object v5, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    sget-object v3, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v5, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Long;

    const-class v3, Ljava/lang/Long;

    const/4 v7, 0x5

    const-class v3, Ljava/lang/Long;

    const-class v3, Ljava/lang/Long;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v5, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v3, Lcom/alibaba/fastjson/serializer/e;->a:Lcom/alibaba/fastjson/serializer/e;

    const/4 v7, 0x6

    const-class v5, Ljava/math/BigInteger;

    const-class v5, Ljava/math/BigInteger;

    const/4 v7, 0x0

    invoke-virtual {v0, v5, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-class v5, Ljava/math/BigDecimal;

    const-class v5, Ljava/math/BigDecimal;

    const-class v5, Ljava/math/BigDecimal;

    const-class v5, Ljava/math/BigDecimal;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, v5, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    sget-object v3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-class v3, Ljava/lang/Float;

    const/4 v7, 0x0

    const-class v3, Ljava/lang/Float;

    const-class v3, Ljava/lang/Float;

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    const-class v3, Ljava/lang/Double;

    const-class v3, Ljava/lang/Double;

    const/4 v7, 0x6

    const-class v3, Ljava/lang/Double;

    const-class v3, Ljava/lang/Double;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x0

    sget-object v5, Lcom/alibaba/fastjson/serializer/f;->a:Lcom/alibaba/fastjson/serializer/f;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-class v3, Ljava/lang/Boolean;

    const-class v3, Ljava/lang/Boolean;

    const/4 v7, 0x6

    const-class v3, Ljava/lang/Boolean;

    const-class v3, Ljava/lang/Boolean;

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v0, v3, v5}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-class v3, Ljava/lang/Class;

    const-class v3, Ljava/lang/Class;

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Class;

    const-class v3, Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget-object v3, Lcom/alibaba/fastjson/serializer/b;->a:Lcom/alibaba/fastjson/serializer/b;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-class v5, [C

    const-class v5, [C

    const/4 v7, 0x4

    const-class v5, [C

    const-class v5, [C

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v5, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-class v5, [Ljava/lang/Object;

    const-class v5, [Ljava/lang/Object;

    const/4 v7, 0x4

    const-class v5, [Ljava/lang/Object;

    const-class v5, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v5, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-class v3, Ljava/util/UUID;

    const-class v3, Ljava/util/UUID;

    const/4 v7, 0x2

    const-class v3, Ljava/util/UUID;

    const-class v3, Ljava/util/UUID;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-class v3, Ljava/util/TimeZone;

    const-class v3, Ljava/util/TimeZone;

    const/4 v7, 0x4

    const-class v3, Ljava/util/TimeZone;

    const-class v3, Ljava/util/TimeZone;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-class v3, Ljava/util/Locale;

    const-class v3, Ljava/util/Locale;

    const/4 v7, 0x2

    const-class v3, Ljava/util/Locale;

    const-class v3, Ljava/util/Locale;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-class v3, Ljava/util/Currency;

    const-class v3, Ljava/util/Currency;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v6, 0x0

    const-class v3, Ljava/net/URI;

    const-class v3, Ljava/net/URI;

    const/4 v7, 0x5

    const-class v3, Ljava/net/URI;

    const-class v3, Ljava/net/URI;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-class v3, Ljava/net/URL;

    const-class v3, Ljava/net/URL;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-class v3, Ljava/util/regex/Pattern;

    const-class v3, Ljava/util/regex/Pattern;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-class v3, Ljava/nio/charset/Charset;

    const-class v3, Ljava/nio/charset/Charset;

    const/4 v7, 0x1

    const-class v3, Ljava/nio/charset/Charset;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const-class v3, Ljava/lang/Number;

    const-class v3, Ljava/lang/Number;

    const-class v3, Ljava/lang/Number;

    const-class v3, Ljava/lang/Number;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, v3, v4}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-class v3, Ljava/lang/StackTraceElement;

    const-class v3, Ljava/lang/StackTraceElement;

    const/4 v7, 0x2

    const-class v3, Ljava/lang/StackTraceElement;

    const-class v3, Ljava/lang/StackTraceElement;

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const-class v1, Ljava/io/Serializable;

    const-class v1, Ljava/io/Serializable;

    const/4 v7, 0x5

    const-class v1, Ljava/io/Serializable;

    const-class v1, Ljava/io/Serializable;

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-class v1, Ljava/lang/Cloneable;

    const-class v1, Ljava/lang/Cloneable;

    const/4 v7, 0x0

    const-class v1, Ljava/lang/Cloneable;

    const-class v1, Ljava/lang/Cloneable;

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-class v1, Ljava/lang/Comparable;

    const-class v1, Ljava/lang/Comparable;

    const/4 v7, 0x7

    const-class v1, Ljava/lang/Comparable;

    const-class v1, Ljava/lang/Comparable;

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-class v1, Ljava/io/Closeable;

    const-class v1, Ljava/io/Closeable;

    const/4 v7, 0x4

    const-class v1, Ljava/io/Closeable;

    const-class v1, Ljava/io/Closeable;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method public static f()Lcom/alibaba/fastjson/parser/m;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l@s@ a@ci v~iMd@~~@@ ~~o@~K~@bo@@@~f ~os~ ~@oo4@y~ ~n@~ .@  ~ftl@@ m@  -r~~b~1oui b~~~ t ~@ S //"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public static g(Ljava/lang/Class;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-class v0, Ljava/lang/Boolean;

    const-class v0, Ljava/lang/Boolean;

    const/4 v2, 0x7

    const-class v0, Ljava/lang/Boolean;

    const-class v0, Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-class v0, Ljava/lang/Character;

    const-class v0, Ljava/lang/Character;

    const-class v0, Ljava/lang/Character;

    const-class v0, Ljava/lang/Character;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const/4 v2, 0x1

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-class v0, Ljava/lang/Short;

    const/4 v2, 0x0

    const-class v0, Ljava/lang/Short;

    const-class v0, Ljava/lang/Short;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eq p0, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v2, 0x4

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eq p0, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const/4 v2, 0x4

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const/4 v2, 0x1

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const/4 v2, 0x2

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const-class v0, Ljava/lang/Double;

    const-class v0, Ljava/lang/Double;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Double;

    const-class v0, Ljava/lang/Double;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-class v0, Ljava/math/BigInteger;

    const-class v0, Ljava/math/BigInteger;

    const/4 v2, 0x6

    const-class v0, Ljava/math/BigInteger;

    const-class v0, Ljava/math/BigInteger;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-class v0, Ljava/math/BigDecimal;

    const-class v0, Ljava/math/BigDecimal;

    const/4 v2, 0x5

    const-class v0, Ljava/math/BigDecimal;

    const-class v0, Ljava/math/BigDecimal;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eq p0, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v2, 0x7

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-class v0, Ljava/util/Date;

    const/4 v2, 0x0

    const-class v0, Ljava/util/Date;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-class v0, Ljava/sql/Date;

    const-class v0, Ljava/sql/Date;

    const/4 v2, 0x6

    const-class v0, Ljava/sql/Date;

    const-class v0, Ljava/sql/Date;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const-class v0, Ljava/sql/Time;

    const-class v0, Ljava/sql/Time;

    const/4 v2, 0x2

    const-class v0, Ljava/sql/Time;

    const-class v0, Ljava/sql/Time;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p0, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-class v0, Ljava/sql/Timestamp;

    const-class v0, Ljava/sql/Timestamp;

    const/4 v2, 0x7

    const-class v0, Ljava/sql/Timestamp;

    const-class v0, Ljava/sql/Timestamp;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-ne p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v2, 0x6

    return p0
.end method


# virtual methods
.method public a(Ljava/lang/String;Ljava/lang/Class;I)Ljava/lang/Class;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "*>;I)",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    if-nez v1, :cond_0

    const/4 v1, 0x0

    return-object v1

    :cond_0
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v3

    const/16 v4, 0x80

    const-string/jumbo v5, "snpmsp .uy taopt ioo Tetu"

    const-string/jumbo v5, "tosn suyo  t.ppiTatue ops"

    const-string v5, "autoType is not support. "

    if-ge v3, v4, :cond_d

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x3

    if-lt v3, v4, :cond_d

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v6

    int-to-long v6, v6

    const-wide v8, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v8, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v8, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v8, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    xor-long/2addr v6, v8

    const-wide v10, 0x100000001b3L

    const-wide v10, 0x100000001b3L

    const-wide v10, 0x100000001b3L

    const-wide v10, 0x100000001b3L

    mul-long/2addr v6, v10

    const-wide v12, -0x509be9b379fdb0e6L    # -2.1176223865607047E-80

    const-wide v12, -0x509be9b379fdb0e6L    # -2.1176223865607047E-80

    const-wide v12, -0x509be9b379fdb0e6L    # -2.1176223865607047E-80

    const-wide v12, -0x509be9b379fdb0e6L    # -2.1176223865607047E-80

    cmp-long v12, v6, v12

    if-eqz v12, :cond_c

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v13, 0x1

    sub-int/2addr v12, v13

    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    int-to-long v14, v12

    xor-long/2addr v6, v14

    mul-long/2addr v6, v10

    const-wide v14, 0x9198507b5af98f0L

    const-wide v14, 0x9198507b5af98f0L

    const-wide v14, 0x9198507b5af98f0L

    const-wide v14, 0x9198507b5af98f0L

    cmp-long v6, v6, v14

    if-eqz v6, :cond_b

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v6

    int-to-long v6, v6

    xor-long/2addr v6, v8

    mul-long/2addr v6, v10

    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    move-result v8

    int-to-long v8, v8

    xor-long/2addr v6, v8

    mul-long/2addr v6, v10

    const/4 v8, 0x2

    invoke-virtual {v1, v8}, Ljava/lang/String;->charAt(I)C

    move-result v8

    int-to-long v8, v8

    xor-long/2addr v6, v8

    mul-long/2addr v6, v10

    :goto_0
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v8

    if-ge v4, v8, :cond_3

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v8

    int-to-long v8, v8

    xor-long/2addr v6, v8

    mul-long/2addr v6, v10

    sget-object v8, Lcom/alibaba/fastjson/parser/m;->f:[J

    invoke-static {v8, v6, v7}, Ljava/util/Arrays;->binarySearch([JJ)I

    move-result v8

    if-ltz v8, :cond_2

    invoke-static/range {p1 .. p1}, Lq0/d;->D(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v8

    if-eqz v8, :cond_1

    goto :goto_1

    :cond_1
    new-instance v2, Lcom/alibaba/fastjson/d;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_2
    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    invoke-static/range {p1 .. p1}, Lq0/d;->D(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    if-eqz v4, :cond_4

    return-object v4

    :cond_4
    iget-object v4, v0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    invoke-virtual {v4, v1}, Lq0/b;->a(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    if-eqz v4, :cond_5

    return-object v4

    :cond_5
    iget-object v4, v0, Lcom/alibaba/fastjson/parser/m;->c:Ljava/lang/ClassLoader;

    invoke-static {v1, v4, v3}, Lq0/d;->Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;

    move-result-object v3

    if-eqz v3, :cond_7

    if-eqz v2, :cond_7

    const-class v4, Ljava/util/HashMap;

    const-class v4, Ljava/util/HashMap;

    const-class v4, Ljava/util/HashMap;

    const-class v4, Ljava/util/HashMap;

    if-eq v3, v4, :cond_7

    invoke-virtual {v2, v3}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-static {v1, v3}, Lq0/d;->a(Ljava/lang/String;Ljava/lang/Class;)V

    return-object v3

    :cond_6
    new-instance v3, Lcom/alibaba/fastjson/d;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "t .tocoe hy mpta"

    const-string/jumbo v5, "mctmoh t.tyap  e"

    const-string v5, "ctmt bh aoe.ytpn"

    const-string/jumbo v5, "type not match. "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " - >"

    const-string v1, "  >-"

    const-string v1, "  >-"

    const-string v1, " -> "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v3, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v3

    :cond_7
    const-class v2, Lp0/c;

    const-class v2, Lp0/c;

    const-class v2, Lp0/c;

    const-class v2, Lp0/c;

    invoke-virtual {v3, v2}, Ljava/lang/Class;->isAnnotationPresent(Ljava/lang/Class;)Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-static {v1, v3}, Lq0/d;->a(Ljava/lang/String;Ljava/lang/Class;)V

    return-object v3

    :cond_8
    sget-object v2, Lcom/alibaba/fastjson/parser/d;->r:Lcom/alibaba/fastjson/parser/d;

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    and-int v4, p3, v2

    if-nez v4, :cond_a

    sget v4, Lcom/alibaba/fastjson/a;->d:I

    and-int/2addr v2, v4

    if-nez v2, :cond_a

    iget-boolean v2, v0, Lcom/alibaba/fastjson/parser/m;->e:Z

    if-eqz v2, :cond_9

    goto :goto_2

    :cond_9
    new-instance v2, Lcom/alibaba/fastjson/d;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "uysuatunot itoro:p spoe pT"

    const-string/jumbo v4, "yaeTotuu on pt ir t:osspop"

    const-string/jumbo v4, "put uyppotp:e as or tnio s"

    const-string v4, "autoType is not support : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_a
    :goto_2
    invoke-static {v1, v3}, Lq0/d;->a(Ljava/lang/String;Ljava/lang/Class;)V

    return-object v3

    :cond_b
    new-instance v2, Lcom/alibaba/fastjson/d;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_c
    new-instance v2, Lcom/alibaba/fastjson/d;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_d
    new-instance v2, Lcom/alibaba/fastjson/d;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method public b(Ljava/lang/Class;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    move v2, v1

    const/4 p1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method public c(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Lq0/a;)Lcom/alibaba/fastjson/parser/deserializer/d;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/m;",
            "Ljava/lang/Class<",
            "*>;",
            "Lq0/a;",
            ")",
            "Lcom/alibaba/fastjson/parser/deserializer/d;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p3, Lq0/a;->g:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-class v1, Ljava/util/List;

    const-class v1, Ljava/util/List;

    const/4 v3, 0x3

    const-class v1, Ljava/util/List;

    const-class v1, Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-class v1, Ljava/util/ArrayList;

    const-class v1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const-class v1, Ljava/util/ArrayList;

    const-class v1, Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eq v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz v1, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/alibaba/fastjson/parser/a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, p1, p2, p3}, Lcom/alibaba/fastjson/parser/a;-><init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Lq0/a;)V

    const/4 v3, 0x4

    return-object v0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Lcom/alibaba/fastjson/parser/j;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, p1, p2, p3}, Lcom/alibaba/fastjson/parser/j;-><init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Lq0/a;)V

    const/4 v3, 0x2

    return-object v0
.end method

.method public d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/reflect/Type;",
            ")",
            "Lcom/alibaba/fastjson/parser/deserializer/f;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez p2, :cond_1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v4, 0x0

    invoke-static {p1}, Lcom/alibaba/fastjson/parser/m;->g(Ljava/lang/Class;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-class v1, Lp0/c;

    const-class v1, Lp0/c;

    const/4 v4, 0x4

    const-class v1, Lp0/c;

    const-class v1, Lp0/c;

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast v1, Lp0/c;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1}, Lp0/c;->mappingTo()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-class v2, Ljava/lang/Void;

    const-class v2, Ljava/lang/Void;

    const/4 v4, 0x3

    const-class v2, Ljava/lang/Void;

    const-class v2, Ljava/lang/Void;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq v1, v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v1}, Lcom/alibaba/fastjson/parser/m;->d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    instance-of v1, p2, Ljava/lang/reflect/WildcardType;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    instance-of v1, p2, Ljava/lang/reflect/TypeVariable;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    instance-of v1, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x3

    if-eqz v1, :cond_5

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0, p2}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object v0

    :cond_7
    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->isEnum()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_8

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Lcom/alibaba/fastjson/parser/c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Lcom/alibaba/fastjson/parser/c;-><init>(Ljava/lang/Class;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto/16 :goto_1

    :cond_8
    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Class;->isArray()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_9

    const/4 v4, 0x1

    sget-object v0, Lcom/alibaba/fastjson/serializer/b;->a:Lcom/alibaba/fastjson/serializer/b;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto/16 :goto_1

    :cond_9
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-class v0, Ljava/util/Set;

    const-class v0, Ljava/util/Set;

    const-class v0, Ljava/util/Set;

    const-class v0, Ljava/util/Set;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eq p1, v0, :cond_f

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-class v0, Ljava/util/HashSet;

    const-class v0, Ljava/util/HashSet;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eq p1, v0, :cond_f

    const/4 v4, 0x3

    const-class v0, Ljava/util/Collection;

    const/4 v4, 0x4

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eq p1, v0, :cond_f

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-class v1, Ljava/util/List;

    const/4 v4, 0x2

    const-class v1, Ljava/util/List;

    const-class v1, Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eq p1, v1, :cond_f

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-class v1, Ljava/util/ArrayList;

    const-class v1, Ljava/util/ArrayList;

    const/4 v4, 0x1

    if-ne p1, v1, :cond_a

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto/16 :goto_0

    :cond_a
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_b

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v0, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto/16 :goto_1

    :cond_b
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-class v0, Ljava/util/Map;

    const/4 v4, 0x7

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x3

    if-eqz v0, :cond_c

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Lcom/alibaba/fastjson/parser/k;->a:Lcom/alibaba/fastjson/parser/k;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_1

    :cond_c
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-class v0, Ljava/lang/Throwable;

    const-class v0, Ljava/lang/Throwable;

    const/4 v4, 0x4

    const-class v0, Ljava/lang/Throwable;

    const-class v0, Ljava/lang/Throwable;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_d

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lcom/alibaba/fastjson/parser/p;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, p0, p1}, Lcom/alibaba/fastjson/parser/p;-><init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_1

    :cond_d
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, ".oUbreiaq.dnidr"

    const-string v1, "adi.iboU.dnrenr"

    const/4 v4, 0x3

    const-string/jumbo v1, "insrtad..edonri"

    const-string v1, "android.net.Uri"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_e

    const/4 v4, 0x6

    const/4 v3, 0x5

    sget-object v0, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_1

    :cond_e
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v0, Lcom/alibaba/fastjson/parser/g;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, p0, p1, p2}, Lcom/alibaba/fastjson/parser/g;-><init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Ljava/lang/reflect/Type;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_1

    :cond_f
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v0, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, p2, v0}, Lcom/alibaba/fastjson/parser/m;->h(Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/deserializer/f;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v0
.end method

.method public e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    instance-of v0, p1, Ljava/lang/Class;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/Class;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, v0, p1}, Lcom/alibaba/fastjson/parser/m;->d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1

    :cond_1
    const/4 v2, 0x6

    const/4 v3, 0x5

    instance-of v0, p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/Class;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/Class;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, v0, p1}, Lcom/alibaba/fastjson/parser/m;->d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v0, p1, Ljava/lang/reflect/WildcardType;

    const/4 v3, 0x5

    if-eqz v0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/reflect/WildcardType;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/lang/reflect/WildcardType;->getUpperBounds()[Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    array-length v0, p1

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x1

    or-int/2addr v2, v1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    aget-object p1, p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p1, Lcom/alibaba/fastjson/parser/i;->a:Lcom/alibaba/fastjson/parser/i;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p1
.end method

.method public h(Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/deserializer/f;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {v0, p1, p2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public i(Ljava/lang/Class;)Lcom/alibaba/fastjson/parser/deserializer/f;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/alibaba/fastjson/parser/deserializer/f;"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getModifiers()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    xor-int/2addr v8, v5

    move v7, v5

    move v7, v5

    const/4 v8, 0x0

    const/4 v6, 0x1

    const/4 v8, 0x2

    move v7, v6

    move v7, v6

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual/range {v0 .. v6}, Lcom/alibaba/fastjson/parser/m;->j(Ljava/lang/Class;IZZZZ)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    return-object p1
.end method

.method public j(Ljava/lang/Class;IZZZZ)Lcom/alibaba/fastjson/parser/deserializer/f;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;IZZZZ)",
            "Lcom/alibaba/fastjson/parser/deserializer/f;"
        }
    .end annotation

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/m;->a:Lq0/b;

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/alibaba/fastjson/parser/deserializer/f;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    iget-object v8, p0, Lcom/alibaba/fastjson/parser/m;->d:Lcom/alibaba/fastjson/j;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move v4, p3

    move v4, p3

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    move v6, p5

    move v6, p5

    move v7, p6

    move v7, p6

    move v7, p6

    move v7, p6

    invoke-static/range {v1 .. v8}, Lcom/alibaba/fastjson/parser/h;->b(Ljava/lang/Class;ILjava/lang/reflect/Type;ZZZZLcom/alibaba/fastjson/j;)Lcom/alibaba/fastjson/parser/h;

    move-result-object p2

    new-instance p3, Lcom/alibaba/fastjson/parser/g;

    invoke-direct {p3, p0, p1, p1, p2}, Lcom/alibaba/fastjson/parser/g;-><init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/h;)V

    invoke-virtual {p0, p1, p3}, Lcom/alibaba/fastjson/parser/m;->h(Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/deserializer/f;)V

    return-object p3
.end method
