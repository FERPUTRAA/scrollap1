.class final Lcom/alibaba/fastjson/parser/n;
.super Lcom/alibaba/fastjson/parser/deserializer/d;


# instance fields
.field private final e:I

.field private final f:Ljava/util/List;

.field private final g:Lcom/alibaba/fastjson/parser/b;

.field private final h:Ljava/lang/Object;

.field private final i:Ljava/util/Map;

.field private final j:Ljava/util/Collection;


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/parser/b;Ljava/util/List;I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, v1, v1, v0}, Lcom/alibaba/fastjson/parser/deserializer/d;-><init>(Ljava/lang/Class;Lq0/a;I)V

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/n;->g:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput p3, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p2, p0, Lcom/alibaba/fastjson/parser/n;->f:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->h:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->i:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->j:Ljava/util/Collection;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/util/Collection;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, v1, v1, v0}, Lcom/alibaba/fastjson/parser/deserializer/d;-><init>(Ljava/lang/Class;Lq0/a;I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->g:Lcom/alibaba/fastjson/parser/b;

    const/4 v0, -0x5

    const/4 v0, -0x1

    const/4 v3, 0x5

    move v2, v0

    move v2, v0

    const/4 v3, 0x5

    iput v0, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->f:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->h:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->i:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/n;->j:Ljava/util/Collection;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/util/Map;Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x0

    or-int/2addr v3, v1

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {p0, v1, v1, v0}, Lcom/alibaba/fastjson/parser/deserializer/d;-><init>(Ljava/lang/Class;Lq0/a;I)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->g:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->f:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p2, p0, Lcom/alibaba/fastjson/parser/n;->h:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/n;->i:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/n;->j:Ljava/util/Collection;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public b(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Object;Ljava/lang/reflect/Type;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/Type;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ls@~ @i@o @b@~@4~t ~f~@@nia@~ @ ~~im o @K.1/  ~@ ~~   -@@o vucS~@bsot   @d~~o@b@~@~f/@y~Mol~~~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/n;->i:Ljava/util/Map;

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/n;->h:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1, v0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/n;->j:Ljava/util/Collection;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-interface {p1, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/n;->f:Ljava/util/List;

    const/4 v4, 0x7

    iget v0, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v4, 0x4

    invoke-interface {p1, v0, p2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/n;->f:Ljava/util/List;

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    instance-of v0, p1, Lcom/alibaba/fastjson/b;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x6

    check-cast p1, Lcom/alibaba/fastjson/b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/alibaba/fastjson/b;->J0()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v2, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-le v1, v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/alibaba/fastjson/b;->w0()Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/b;->w0()Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/n;->g:Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x4

    iget-object v1, v1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2, p1, v1}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p2

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget p1, p0, Lcom/alibaba/fastjson/parser/n;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, p1, p2}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    return-void
.end method
