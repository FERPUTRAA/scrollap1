.class public Lcom/alibaba/fastjson/k;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field static b:Ljava/util/concurrent/ConcurrentMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentMap<",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/reflect/Type;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field protected final a:Ljava/lang/reflect/Type;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x1

    shr-int/2addr v5, v2

    const/16 v3, 0x10

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0, v3, v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>(IFI)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    sput-object v0, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v5, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method protected constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    aget-object v0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v1, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    check-cast v1, Ljava/lang/reflect/Type;

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v1, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v1, v0, v0}, Ljava/util/concurrent/ConcurrentMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v1, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v1, Ljava/lang/reflect/Type;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method protected varargs constructor <init>([Ljava/lang/reflect/Type;)V
    .locals 9

    const/4 v8, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v1, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    aget-object v1, v1, v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast v1, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    array-length v5, v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge v2, v5, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    aget-object v5, v1, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    instance-of v5, v5, Ljava/lang/reflect/TypeVariable;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v5, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    array-length v5, p1

    const/4 v7, 0x7

    move v8, v7

    if-ge v4, v5, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    add-int/lit8 v5, v4, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    aget-object v4, p1, v4

    const/4 v8, 0x0

    aput-object v4, v1, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v4, v5

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    aget-object v5, v1, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    instance-of v6, v5, Ljava/lang/reflect/GenericArrayType;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v6, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    check-cast v5, Ljava/lang/reflect/GenericArrayType;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v5}, Lq0/d;->w(Ljava/lang/reflect/GenericArrayType;)Ljava/lang/reflect/Type;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v5, v1, v2

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    aget-object v5, v1, v2

    const/4 v8, 0x0

    const/4 v7, 0x4

    instance-of v6, v5, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v6, :cond_2

    const/4 v8, 0x7

    check-cast v5, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {p0, v5, p1, v4}, Lcom/alibaba/fastjson/k;->b(Ljava/lang/reflect/ParameterizedType;[Ljava/lang/reflect/Type;I)Ljava/lang/reflect/Type;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    aput-object v5, v1, v2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto :goto_0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p1, Lq0/c;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p1, v1, v0, v3}, Lq0/c;-><init>([Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    sget-object v0, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast v0, Ljava/lang/reflect/Type;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-nez v0, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget-object v0, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {v0, p1, p1}, Ljava/util/concurrent/ConcurrentMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget-object v0, Lcom/alibaba/fastjson/k;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    check-cast v0, Ljava/lang/reflect/Type;

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput-object v0, p0, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    return-void
.end method

.method private b(Ljava/lang/reflect/ParameterizedType;[Ljava/lang/reflect/Type;I)Ljava/lang/reflect/Type;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ siv/@  @@o @lM~u ~~f.o o@t n~~@t~1@~ ~b~@S o @Kl@~~~~~y@c/@~a bmd ~o@ @si~ b~@4@~  ~oi@-r @f~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    array-length v3, p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-ge v2, v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    aget-object v3, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    instance-of v3, v3, Ljava/lang/reflect/TypeVariable;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    array-length v3, p2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ge p3, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-int/lit8 v3, p3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    aget-object p3, p2, p3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    aput-object p3, p1, v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    move p3, v3

    move p3, v3

    const/4 v6, 0x5

    move p3, v3

    move p3, v3

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    aget-object v3, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    instance-of v4, v3, Ljava/lang/reflect/GenericArrayType;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast v3, Ljava/lang/reflect/GenericArrayType;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v3}, Lq0/d;->w(Ljava/lang/reflect/GenericArrayType;)Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object v3, p1, v2

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    aget-object v3, p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    instance-of v4, v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    check-cast v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p0, v3, p2, p3}, Lcom/alibaba/fastjson/k;->b(Ljava/lang/reflect/ParameterizedType;[Ljava/lang/reflect/Type;I)Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    return-object p1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance p2, Lq0/c;

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-direct {p2, p1, v0, v1}, Lq0/c;-><init>([Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object p2
.end method


# virtual methods
.method public a()Ljava/lang/reflect/Type;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
