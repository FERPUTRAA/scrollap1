.class Lcom/alibaba/fastjson/h;
.super Ljava/lang/Object;


# static fields
.field static final c:I = 0x3e9

.field static final d:I = 0x3ea

.field static final e:I = 0x3eb

.field static final f:I = 0x3ec

.field static final g:I = 0x3ed


# instance fields
.field protected final a:Lcom/alibaba/fastjson/h;

.field protected b:I


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/h;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alibaba/fastjson/h;->a:Lcom/alibaba/fastjson/h;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p2, p0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method
