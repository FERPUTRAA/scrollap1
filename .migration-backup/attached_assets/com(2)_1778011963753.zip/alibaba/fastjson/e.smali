.class public Lcom/alibaba/fastjson/e;
.super Lcom/alibaba/fastjson/a;

# interfaces
.implements Ljava/util/Map;
.implements Ljava/lang/Cloneable;
.implements Ljava/io/Serializable;
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/alibaba/fastjson/a;",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Cloneable;",
        "Ljava/io/Serializable;",
        "Ljava/lang/reflect/InvocationHandler;"
    }
.end annotation


# instance fields
.field private final map:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v0, 0x10

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, v0, v1}, Lcom/alibaba/fastjson/e;-><init>(IZ)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/alibaba/fastjson/e;-><init>(IZ)V

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(IZ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/alibaba/fastjson/a;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-instance p2, Ljava/util/LinkedHashMap;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p2, p1}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    new-instance p2, Ljava/util/HashMap;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p2, p1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/alibaba/fastjson/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/16 v0, 0x10

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0, p1}, Lcom/alibaba/fastjson/e;-><init>(IZ)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public A0(Ljava/lang/String;)Ljava/lang/Float;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "u s@@KoS~~@ /.~@om~n obs t  r  v @@a~@ @~i~b~M~o@ ~@d~@~@t@~~f@il ~1of 4i@@/~ @ y ~ ~~~~b@~@@c-o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lq0/d;->o(Ljava/lang/Object;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public B0(Ljava/lang/String;)F
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p1}, Lq0/d;->o(Ljava/lang/Object;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    return p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p1
.end method

.method public C0()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public D0(Ljava/lang/String;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lq0/d;->p(Ljava/lang/Object;)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x0

    move v1, v0

    return p1

    :cond_0
    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method public E0(Ljava/lang/String;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lq0/d;->p(Ljava/lang/Object;)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public F0(Ljava/lang/String;)Lcom/alibaba/fastjson/b;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    instance-of v0, p1, Lcom/alibaba/fastjson/b;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p1, Lcom/alibaba/fastjson/b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x5

    instance-of v0, p1, Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->d(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p1, Lcom/alibaba/fastjson/b;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p1, Lcom/alibaba/fastjson/b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method public G0(Ljava/lang/String;)Lcom/alibaba/fastjson/e;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/alibaba/fastjson/e;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p1, Lcom/alibaba/fastjson/e;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p1, Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->s(Ljava/lang/String;)Lcom/alibaba/fastjson/e;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Lcom/alibaba/fastjson/e;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method public H0(Ljava/lang/String;)Ljava/lang/Long;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p1}, Lq0/d;->t(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public I0(Ljava/lang/String;)J
    .locals 4

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1}, Lq0/d;->t(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    return-wide v0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public J0(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lq0/d;->q(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1
.end method

.method public varargs K0(Ljava/lang/String;Ljava/lang/Class;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    array-length v2, p3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ge v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    aget-object v2, p3, v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    or-int/2addr v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object p3, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1, p2, p3, v0}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p1
.end method

.method public L0(Ljava/lang/String;)Ljava/lang/Short;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lq0/d;->u(Ljava/lang/Object;)Ljava/lang/Short;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public N0(Ljava/lang/String;)S
    .locals 2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-static {p1}, Lq0/d;->u(Ljava/lang/Object;)Ljava/lang/Short;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Short;->shortValue()S

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method public O0(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1
.end method

.method public Q0(Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            "I)TT;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-ne p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "tepm@"

    const-string v0, "@pset"

    const/4 v2, 0x3

    const-string v0, "@epyo"

    const-string v0, "@type"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/e;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, p3}, Lq0/d;->s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method

.method public clear()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public clone()Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v1, Ljava/util/LinkedHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/e;-><init>(Ljava/util/Map;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method

.method public containsKey(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v1, 0x4

    move v2, v1

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1
.end method

.method public containsValue(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method public entrySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p1
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Map;->hashCode()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    array-length v0, p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v1, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-class v2, Lp0/b;

    const-class v2, Lp0/b;

    const/4 v8, 0x0

    const-class v2, Lp0/b;

    const-class v2, Lp0/b;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v3, 0x0

    const/4 v8, 0x2

    const/4 v4, 0x7

    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x1

    const/4 v8, 0x6

    move v7, v5

    move v7, v5

    const/4 v8, 0x0

    if-ne v0, v5, :cond_6

    const/4 v8, 0x1

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v0, "emlqub"

    const-string/jumbo v0, "ulsmqe"

    const/4 v8, 0x3

    const-string/jumbo v0, "ueulsa"

    const-string v0, "equals"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz p1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    aget-object p1, p3, v4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object p1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x1

    sget-object v0, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v6, "saillgep retol"

    const-string/jumbo v6, "lesloleigter a"

    const/4 v8, 0x3

    const-string v6, "eteerlalqltsig"

    const-string/jumbo v6, "illegal setter"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-ne p1, v0, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2, v2}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    check-cast p1, Lp0/b;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz p1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {p1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v0, :cond_1

    const/4 v8, 0x3

    invoke-interface {p1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-nez p1, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string p2, "ets"

    const-string p2, "ets"

    const-string/jumbo p2, "tes"

    const-string/jumbo p2, "set"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz p2, :cond_3

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz p2, :cond_2

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p1, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_1

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x7

    invoke-direct {p1, v6}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    throw p1

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x1

    invoke-direct {p1, v6}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    throw p1

    :cond_4
    :goto_1
    const/4 v8, 0x6

    iget-object p2, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    aget-object p3, p3, v4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-object v3

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {p1, v6}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    throw p1

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    array-length p1, p1

    const/4 v7, 0x7

    move v8, v7

    if-nez p1, :cond_10

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget-object p3, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string/jumbo v0, "reslbtitggllea"

    const-string v0, "eirgtbllatg le"

    const/4 v8, 0x4

    const-string/jumbo v0, "lrimelttgl aee"

    const-string/jumbo v0, "illegal getter"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eq p1, p3, :cond_f

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p2, v2}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    check-cast p1, Lp0/b;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz p1, :cond_7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-interface {p1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz p3, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-interface {p1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v3

    :cond_7
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v3, :cond_e

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string/jumbo p3, "tge"

    const-string p3, "gte"

    const/4 v8, 0x5

    const-string p3, "get"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-eqz p3, :cond_9

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz p3, :cond_8

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto/16 :goto_2

    :cond_8
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw p1

    :cond_9
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo p3, "is"

    const-string/jumbo p3, "si"

    const/4 v8, 0x5

    const-string/jumbo p3, "si"

    const-string/jumbo p3, "is"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p1, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-eqz p3, :cond_b

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 p3, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz p3, :cond_a

    const/4 v8, 0x7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p1, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_2

    :cond_a
    const/4 v8, 0x0

    const/4 v7, 0x0

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    throw p1

    :cond_b
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo p2, "usCdohah"

    const-string p2, "dCohahus"

    const/4 v8, 0x3

    const-string p2, "doehabCh"

    const-string p2, "hashCode"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz p2, :cond_c

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/alibaba/fastjson/e;->hashCode()I

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object p1

    :cond_c
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo p2, "toString"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz p1, :cond_d

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Lcom/alibaba/fastjson/a;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    return-object p1

    :cond_d
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    throw p1

    :cond_e
    :goto_2
    const/4 v8, 0x2

    iget-object p1, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getGenericReturnType()Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    sget-object p3, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1, p2, p3}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-object p1

    :cond_f
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    throw p1

    :cond_10
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->toGenericString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    throw p1
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public k0(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v3, 0x3

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v3, 0x3

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-ne p1, v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "tppe@"

    const/4 v3, 0x4

    const-string v0, "eu@tp"

    const-string v0, "@type"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/e;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/alibaba/fastjson/parser/m;->f()Lcom/alibaba/fastjson/parser/m;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, p1, v0, v1}, Lq0/d;->s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1
.end method

.method public keySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public m0(Ljava/lang/String;)Ljava/math/BigDecimal;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lq0/d;->f(Ljava/lang/Object;)Ljava/math/BigDecimal;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-object p1
.end method

.method public n0(Ljava/lang/String;)Ljava/math/BigInteger;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1}, Lq0/d;->g(Ljava/lang/Object;)Ljava/math/BigInteger;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public o0(Ljava/lang/String;)Ljava/lang/Boolean;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    return-object p1

    :cond_0
    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1}, Lq0/d;->h(Ljava/lang/Object;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    check-cast p1, Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/alibaba/fastjson/e;->P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "+",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v1, 0x3

    move v2, v1

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v2, 0x7

    return-void
.end method

.method public q0(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lq0/d;->h(Ljava/lang/Object;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public t0(Ljava/lang/String;)Ljava/lang/Byte;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1}, Lq0/d;->i(Ljava/lang/Object;)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public v0(Ljava/lang/String;)B
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1}, Lq0/d;->i(Ljava/lang/Object;)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x6

    return p1

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Byte;->byteValue()B

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method public values()Ljava/util/Collection;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/e;->map:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public w0(Ljava/lang/String;)[B
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v0, 0x0

    move v1, v0

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p1

    :cond_0
    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p1}, Lq0/d;->j(Ljava/lang/Object;)[B

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public x0(Ljava/lang/String;)Ljava/util/Date;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1}, Lq0/d;->l(Ljava/lang/Object;)Ljava/util/Date;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public y0(Ljava/lang/String;)Ljava/lang/Double;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lq0/d;->m(Ljava/lang/Object;)Ljava/lang/Double;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public z0(Ljava/lang/String;)D
    .locals 4

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1}, Lq0/d;->m(Ljava/lang/Object;)Ljava/lang/Double;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-wide v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-wide v0
.end method
