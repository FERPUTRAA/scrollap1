.class public abstract Lcom/alibaba/fastjson/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/g;
.implements Lcom/alibaba/fastjson/c;


# static fields
.field public static a:Ljava/util/TimeZone; = null

.field public static b:Ljava/util/Locale; = null

.field public static final c:Ljava/lang/String; = "@type"

.field public static d:I = 0x0

.field public static e:Ljava/lang/String; = null

.field public static f:I = 0x0

.field public static final g:Ljava/lang/String; = "1.1.72"


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object v0, Lcom/alibaba/fastjson/a;->a:Ljava/util/TimeZone;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/alibaba/fastjson/a;->b:Ljava/util/Locale;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/alibaba/fastjson/parser/d;->h:Lcom/alibaba/fastjson/parser/d;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, v0, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    or-int/lit8 v0, v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v1, Lcom/alibaba/fastjson/parser/d;->j:Lcom/alibaba/fastjson/parser/d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, v1, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    or-int/2addr v0, v1

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Lcom/alibaba/fastjson/parser/d;->i:Lcom/alibaba/fastjson/parser/d;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, v1, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v3, 0x0

    or-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sput v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, ":msH:ydHsMdmy syM-y"

    const-string v0, " ys:ydm-MdysHHmys:M"

    const-string v0, "-: ms-MyyyHysdHMmm:"

    const-string/jumbo v0, "yyyy-MM-dd HH:mm:ss"

    const/4 v3, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/alibaba/fastjson/a;->e:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/alibaba/fastjson/serializer/a0;->a:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, v0, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    or-int/lit8 v0, v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->j:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v3, 0x2

    or-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->d:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    or-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->k:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    or-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    sput v0, Lcom/alibaba/fastjson/a;->f:I

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static final varargs A(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "Lcom/alibaba/fastjson/parser/m;",
            "I[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "c~K@oio~ ~@~@b~M~-b@oi@ @v~ l~i4y@@S o   ~@  a~~ @@ so@df~m~~ @n~ ~~t~/o.@~@tbo@1@@u@r @l~~  / ~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    const/4 v3, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    move v4, p3

    move v4, p3

    const/4 v7, 0x2

    move v4, p3

    move v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->B(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;Lcom/alibaba/fastjson/parser/deserializer/g;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-object p0
.end method

.method public static final varargs B(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;Lcom/alibaba/fastjson/parser/deserializer/g;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "Lcom/alibaba/fastjson/parser/m;",
            "Lcom/alibaba/fastjson/parser/deserializer/g;",
            "I[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    array-length v0, p5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-ge v1, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    aget-object v2, p5, v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    or-int/2addr p4, v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p5, Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p5, p0, p2, p4}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    instance-of p0, p3, Lcom/alibaba/fastjson/parser/deserializer/c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p0, :cond_2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p5}, Lcom/alibaba/fastjson/parser/b;->m()Ljava/util/List;

    move-result-object p0

    move-object p2, p3

    move-object p2, p3

    move-object p2, p3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast p2, Lcom/alibaba/fastjson/parser/deserializer/c;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    instance-of p0, p3, Lcom/alibaba/fastjson/parser/deserializer/b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p5}, Lcom/alibaba/fastjson/parser/b;->l()Ljava/util/List;

    move-result-object p0

    move-object p2, p3

    move-object p2, p3

    move-object p2, p3

    move-object p2, p3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast p2, Lcom/alibaba/fastjson/parser/deserializer/b;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    instance-of p0, p3, Lcom/alibaba/fastjson/parser/deserializer/e;

    const/4 v4, 0x0

    if-eqz p0, :cond_4

    const/4 v4, 0x7

    check-cast p3, Lcom/alibaba/fastjson/parser/deserializer/e;

    const/4 v4, 0x4

    const/4 v3, 0x4

    iput-object p3, p5, Lcom/alibaba/fastjson/parser/b;->m:Lcom/alibaba/fastjson/parser/deserializer/e;

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p5, p1}, Lcom/alibaba/fastjson/parser/b;->h0(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-virtual {p5, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p5}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object p0
.end method

.method public static varargs C(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "Lcom/alibaba/fastjson/parser/m;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget v4, Lcom/alibaba/fastjson/a;->d:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->B(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;Lcom/alibaba/fastjson/parser/deserializer/g;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x3

    return-object p0
.end method

.method public static final varargs E(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/deserializer/g;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "Lcom/alibaba/fastjson/parser/deserializer/g;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    sget v4, Lcom/alibaba/fastjson/a;->d:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->B(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;Lcom/alibaba/fastjson/parser/deserializer/g;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-object p0
.end method

.method public static final varargs F(Ljava/lang/String;Ljava/lang/reflect/Type;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v3, 0x0

    invoke-static {p0, p1, v0, v1, p2}, Lcom/alibaba/fastjson/a;->A(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0
.end method

.method public static final varargs G([BLjava/lang/reflect/Type;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([B",
            "Ljava/lang/reflect/Type;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "b8FTU"

    const-string v1, "UTFm8"

    const/4 v3, 0x2

    const-string v1, "FuUT-"

    const-string v1, "UTF-8"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p1, p2}, Lcom/alibaba/fastjson/a;->F(Ljava/lang/String;Ljava/lang/reflect/Type;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p1, "FuonrptpUT8-oop t"

    const-string/jumbo p1, "poo-oFtn8p ruUstT"

    const/4 v3, 0x0

    const-string/jumbo p1, "stn8p ruqU TopFto"

    const-string p1, "UTF-8 not support"

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw p0
.end method

.method public static final varargs I([CILjava/lang/reflect/Type;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([CI",
            "Ljava/lang/reflect/Type;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    array-length v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x4

    goto :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    array-length v1, p3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ge v2, v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-object v3, p3, v2

    const/4 v5, 0x6

    iget v3, v3, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    or-int/2addr v0, v3

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p3, Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v1, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v5, 0x4

    invoke-direct {p3, p0, p1, v1, v0}, Lcom/alibaba/fastjson/parser/b;-><init>([CILcom/alibaba/fastjson/parser/m;I)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p3, p2}, Lcom/alibaba/fastjson/parser/b;->h0(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {p3, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p0

    :cond_2
    :goto_1
    const/4 v5, 0x0

    const/4 p0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object p0
.end method

.method public static final K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/alibaba/fastjson/a;->N(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static final L(Ljava/lang/Object;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    sget-object p1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/alibaba/fastjson/a;->N(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public static N(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x4

    const/4 v0, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    instance-of v1, p0, Lcom/alibaba/fastjson/a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast p0, Lcom/alibaba/fastjson/a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    instance-of v1, p0, Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v1, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast p0, Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p0}, Ljava/util/Map;->size()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    instance-of v0, p0, Ljava/util/LinkedHashMap;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0, p1}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    instance-of v0, p0, Ljava/util/TreeMap;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    new-instance v0, Ljava/util/TreeMap;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, p1}, Ljava/util/HashMap;-><init>(I)V

    :goto_0
    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/e;-><init>(Ljava/util/Map;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v1}, Lq0/d;->v(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, v1, v0}, Lcom/alibaba/fastjson/e;->P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_1

    :cond_4
    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p1

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    instance-of v1, p0, Ljava/util/Collection;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v1, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p0, Ljava/util/Collection;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance p1, Lcom/alibaba/fastjson/b;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/b;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/b;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_2

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object p1

    :cond_7
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Class;->isEnum()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v2, :cond_8

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast p0, Ljava/lang/Enum;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p0

    :cond_8
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Class;->isArray()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v2, :cond_a

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/reflect/Array;->getLength(Ljava/lang/Object;)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Lcom/alibaba/fastjson/b;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, p1}, Lcom/alibaba/fastjson/b;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_3
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ge v1, p1, :cond_9

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-static {p0, v1}, Ljava/lang/reflect/Array;->get(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v2}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/b;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_3

    :cond_9
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0

    :cond_a
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/alibaba/fastjson/parser/m;->g(Ljava/lang/Class;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v2, :cond_b

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object p0

    :cond_b
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    instance-of v1, p1, Lcom/alibaba/fastjson/serializer/n;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_d

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast p1, Lcom/alibaba/fastjson/serializer/n;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0}, Lcom/alibaba/fastjson/e;-><init>()V

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Lcom/alibaba/fastjson/serializer/n;->a(Ljava/lang/Object;)Ljava/util/Map;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_4
    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p1, :cond_c

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p1}, Lcom/alibaba/fastjson/e;->P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_4

    :cond_c
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v0

    :catch_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v0, "oJsrNSO ortb"

    const-string v0, "SNJotbr oOrr"

    const/4 v4, 0x5

    const-string v0, "NormetrorJSO"

    const-string/jumbo v0, "toJSON error"

    const/4 v4, 0x7

    invoke-direct {p1, v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    throw p1

    :cond_d
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object v0
.end method

.method public static varargs O(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;I[Lcom/alibaba/fastjson/serializer/a0;)[B
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-array v0, v0, [Lcom/alibaba/fastjson/serializer/y;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, p1, v0, p2, p3}, Lcom/alibaba/fastjson/a;->P(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;I[Lcom/alibaba/fastjson/serializer/a0;)[B

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public static varargs P(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;I[Lcom/alibaba/fastjson/serializer/a0;)[B
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v0, v1, p3, p4}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    new-instance p3, Lcom/alibaba/fastjson/serializer/m;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p3, v0, p1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x5

    if-eqz p2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    array-length p1, p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 p4, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    if-ge p4, p1, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    aget-object v1, p2, p4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/v;

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->m()Ljava/util/List;

    move-result-object v2

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v3, Lcom/alibaba/fastjson/serializer/v;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/r;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->k()Ljava/util/List;

    move-result-object v2

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast v3, Lcom/alibaba/fastjson/serializer/r;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/d0;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->n()Ljava/util/List;

    move-result-object v2

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast v3, Lcom/alibaba/fastjson/serializer/d0;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/u;

    const/4 v5, 0x5

    if-eqz v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->l()Ljava/util/List;

    move-result-object v2

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v3, Lcom/alibaba/fastjson/serializer/u;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/d;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v2, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->g()Ljava/util/List;

    move-result-object v2

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v3, Lcom/alibaba/fastjson/serializer/d;

    const/4 v4, 0x2

    const/4 v4, 0x2

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v5, 0x6

    instance-of v2, v1, Lcom/alibaba/fastjson/serializer/a;

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_6

    const/4 v5, 0x4

    invoke-virtual {p3}, Lcom/alibaba/fastjson/serializer/m;->f()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast v1, Lcom/alibaba/fastjson/serializer/a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 p4, p4, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_7
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p3, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string p0, "Uu8FT"

    const/4 v5, 0x4

    const-string p0, "-8TFo"

    const-string p0, "UTF-8"

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p0}, Lcom/alibaba/fastjson/serializer/z;->l(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v4, 0x2

    move v5, v4

    throw p0
.end method

.method public static final varargs R(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/a0;)[B
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget v2, Lcom/alibaba/fastjson/a;->f:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2, p2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance p2, Lcom/alibaba/fastjson/serializer/m;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p2, v0, p1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const-string p0, "bF8UT"

    const-string p0, "FUp8T"

    const/4 v4, 0x4

    const-string p0, "Tu-F8"

    const-string p0, "UTF-8"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p0}, Lcom/alibaba/fastjson/serializer/z;->l(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    throw p0
.end method

.method public static varargs S(Ljava/lang/Object;[Lcom/alibaba/fastjson/serializer/y;[Lcom/alibaba/fastjson/serializer/a0;)[B
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x6

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v3, 0x5

    invoke-static {p0, v0, p1, v1, p2}, Lcom/alibaba/fastjson/a;->P(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;I[Lcom/alibaba/fastjson/serializer/a0;)[B

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0
.end method

.method public static final varargs T(Ljava/lang/Object;[Lcom/alibaba/fastjson/serializer/a0;)[B
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget v2, Lcom/alibaba/fastjson/a;->f:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2, p1}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance p1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p1, v0, v1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p0, "-Fpq8"

    const-string p0, "8F-qT"

    const/4 v4, 0x5

    const-string p0, "UTF-8"

    invoke-virtual {v0, p0}, Lcom/alibaba/fastjson/serializer/z;->l(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p0
.end method

.method public static final U(Ljava/lang/Object;)Ljava/lang/String;
    .locals 8

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-array v5, v0, [Lcom/alibaba/fastjson/serializer/a0;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object p0
.end method

.method public static final varargs V(Ljava/lang/Object;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v3, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v4, p1

    move v4, p1

    const/4 v7, 0x2

    move v4, p1

    move v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    return-object p0
.end method

.method public static final varargs W(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;Lcom/alibaba/fastjson/serializer/y;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-array v3, v0, [Lcom/alibaba/fastjson/serializer/y;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x1

    xor-int/2addr v8, v7

    aput-object p2, v3, v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget v5, Lcom/alibaba/fastjson/a;->f:I

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v6}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-object p0
.end method

.method public static varargs Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-direct {v0, v1, p4, p5}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p4, Lcom/alibaba/fastjson/serializer/m;

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p4, v0, p1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    array-length p1, p5

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ge v2, p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    aget-object v4, p5, v2

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p4, v4, v3}, Lcom/alibaba/fastjson/serializer/m;->d(Lcom/alibaba/fastjson/serializer/a0;Z)V

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz p3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz p1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/m;->u(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object p1, Lcom/alibaba/fastjson/serializer/a0;->q:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p4, p1, v3}, Lcom/alibaba/fastjson/serializer/m;->d(Lcom/alibaba/fastjson/serializer/a0;Z)V

    :cond_1
    const/4 v6, 0x3

    if-eqz p2, :cond_9

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    array-length p1, p2

    :goto_1
    const/4 v6, 0x4

    if-ge v1, p1, :cond_9

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    aget-object p3, p2, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez p3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto/16 :goto_2

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/v;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz p5, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->m()Ljava/util/List;

    move-result-object p5

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v2, Lcom/alibaba/fastjson/serializer/v;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/r;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz p5, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->k()Ljava/util/List;

    move-result-object p5

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    check-cast v2, Lcom/alibaba/fastjson/serializer/r;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {p5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/d0;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz p5, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->n()Ljava/util/List;

    move-result-object p5

    move-object v2, p3

    move-object v2, p3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    check-cast v2, Lcom/alibaba/fastjson/serializer/d0;

    const/4 v5, 0x3

    move v6, v5

    invoke-interface {p5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/u;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz p5, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->l()Ljava/util/List;

    move-result-object p5

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v2, Lcom/alibaba/fastjson/serializer/u;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/d;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz p5, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->g()Ljava/util/List;

    move-result-object p5

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v2, Lcom/alibaba/fastjson/serializer/d;

    const/4 v6, 0x3

    invoke-interface {p5, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    instance-of p5, p3, Lcom/alibaba/fastjson/serializer/a;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz p5, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/m;->f()Ljava/util/List;

    move-result-object p5

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast p3, Lcom/alibaba/fastjson/serializer/a;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p5, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    goto/16 :goto_1

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p4, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    throw p0
.end method

.method public static final varargs Z(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    const/4 v3, 0x7

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    move v7, v6

    return-object p0
.end method

.method public static final varargs a0(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x5

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-object p0
.end method

.method public static final varargs b0(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/y;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-array v2, v0, [Lcom/alibaba/fastjson/serializer/y;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    aput-object p1, v2, v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    move-object v0, p0

    move-object v0, p0

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object p0
.end method

.method public static final c0(Ljava/lang/Object;Z)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-array p1, p1, [Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x0

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->m:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    aput-object v1, p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lcom/alibaba/fastjson/a;->g0(Ljava/lang/Object;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public static final d(Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/alibaba/fastjson/a;->e(Ljava/lang/String;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static final e(Ljava/lang/String;I)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    new-instance v1, Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-direct {v1, p0, v2, p1}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/alibaba/fastjson/parser/b;->v(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p0
.end method

.method public static f(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lcom/alibaba/fastjson/a;->g(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final varargs f0(Ljava/lang/Object;[Lcom/alibaba/fastjson/serializer/y;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x2

    and-int/2addr v7, v6

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x2

    return-object p0
.end method

.method public static g(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    const/4 p0, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    new-instance v0, Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1, p2}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)V

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static final varargs g0(Ljava/lang/Object;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget v0, Lcom/alibaba/fastjson/a;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0, v0, p1}, Lcom/alibaba/fastjson/a;->V(Ljava/lang/Object;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public static varargs h(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x0

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    array-length v2, p2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ge v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    aget-object v2, p2, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    or-int/2addr v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0, p1, v0}, Lcom/alibaba/fastjson/a;->g(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p0
.end method

.method public static final varargs h0(Ljava/lang/Object;Ljava/lang/String;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget v4, Lcom/alibaba/fastjson/a;->f:I

    move-object v0, p0

    move-object v0, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    return-object p0
.end method

.method public static final varargs i(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget v0, Lcom/alibaba/fastjson/a;->d:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    array-length v1, p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x7

    aget-object v3, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v3, v3, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    or-int/2addr v0, v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-static {p0, v0}, Lcom/alibaba/fastjson/a;->e(Ljava/lang/String;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p0
.end method

.method public static final varargs i0(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v2, 0x0

    and-int/2addr v7, v2

    const/4 v6, 0x4

    move v7, v6

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x3

    move v7, v6

    const/4 v4, 0x0

    shl-int/2addr v7, v4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->Y(Ljava/lang/Object;Lcom/alibaba/fastjson/serializer/x;[Lcom/alibaba/fastjson/serializer/y;Ljava/lang/String;I[Lcom/alibaba/fastjson/serializer/a0;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-object p0
.end method

.method public static final j0(Lcom/alibaba/fastjson/a;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/a;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lq0/d;->b(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final varargs k([B[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "-U8qs"

    const-string v1, "U8s-T"

    const/4 v3, 0x7

    const-string v1, "T-sF8"

    const-string v1, "UTF-8"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/alibaba/fastjson/a;->t(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Lcom/alibaba/fastjson/e;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0

    :catch_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "tmFmponT sUpo8- u"

    const-string v0, "8Tom-UsFtpnr po u"

    const/4 v3, 0x1

    const-string/jumbo v0, "poTtourUo Fpn-ts "

    const-string v0, "UTF-8 not support"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p1
.end method

.method public static final varargs l0(Ljava/lang/Object;Ljava/io/Writer;[Lcom/alibaba/fastjson/serializer/a0;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p1, v1, p2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object p2, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1, v0, p2}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw p0
.end method

.method public static final n(Ljava/lang/String;)Lcom/alibaba/fastjson/b;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    new-array v0, v0, [Lcom/alibaba/fastjson/parser/d;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/alibaba/fastjson/a;->o(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Lcom/alibaba/fastjson/b;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final varargs o(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Lcom/alibaba/fastjson/b;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x5

    move v5, v4

    array-length v3, p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ge v2, v3, :cond_1

    const/4 v5, 0x5

    aget-object v3, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v3, v3, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    or-int/2addr v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    new-instance p1, Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x0

    const/4 v4, 0x4

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-direct {p1, p0, v2, v1}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)V

    const/4 v5, 0x5

    iget-object p0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v2, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne v1, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/e;->t()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 p0, 0x14

    const/4 v5, 0x0

    if-ne v1, p0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p0, Lcom/alibaba/fastjson/b;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/alibaba/fastjson/b;-><init>()V

    const/4 v5, 0x0

    invoke-virtual {p1, p0, v0}, Lcom/alibaba/fastjson/parser/b;->N(Ljava/util/Collection;Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public static final p(Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    new-instance v1, Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1, p0, v2}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object p0, v1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/16 v3, 0x8

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/e;->t()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/16 v3, 0x14

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne v2, v3, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/alibaba/fastjson/parser/e;->m()Z

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, p1, v0}, Lcom/alibaba/fastjson/parser/b;->H(Ljava/lang/Class;Ljava/util/Collection;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    :goto_0
    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v0
.end method

.method public static final q(Ljava/lang/String;[Ljava/lang/reflect/Type;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v0, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x5

    new-instance v1, Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1, p0, v2}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Lcom/alibaba/fastjson/parser/b;->Q([Ljava/lang/reflect/Type;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method public static final s(Ljava/lang/String;)Lcom/alibaba/fastjson/e;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/alibaba/fastjson/a;->d(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    instance-of v0, p0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object v2, Lcom/alibaba/fastjson/parser/d;->r:Lcom/alibaba/fastjson/parser/d;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    and-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "byeot"

    const-string v1, "@yeto"

    const/4 v4, 0x6

    const-string v1, "@uetp"

    const-string v1, "@type"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, p0}, Lcom/alibaba/fastjson/e;->P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0

    :cond_3
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast p0, Lcom/alibaba/fastjson/e;

    const/4 v4, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public static final varargs t(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Lcom/alibaba/fastjson/e;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p0, p1}, Lcom/alibaba/fastjson/a;->i(Ljava/lang/String;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    instance-of v0, p0, Lcom/alibaba/fastjson/e;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    check-cast p0, Lcom/alibaba/fastjson/e;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-object p0

    :cond_0
    const/4 v8, 0x7

    invoke-static {p0}, Lcom/alibaba/fastjson/a;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    check-cast v0, Lcom/alibaba/fastjson/e;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    sget-object v2, Lcom/alibaba/fastjson/parser/d;->r:Lcom/alibaba/fastjson/parser/d;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    and-int/2addr v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v3, 0x1

    const/4 v7, 0x1

    move v8, v7

    if-eqz v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    move v1, v3

    move v1, v3

    const/4 v8, 0x2

    move v1, v3

    move v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    move v1, v2

    move v1, v2

    const/4 v8, 0x6

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-nez v1, :cond_3

    const/4 v8, 0x6

    array-length v4, p1

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-ge v2, v4, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    aget-object v5, p1, v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    sget-object v6, Lcom/alibaba/fastjson/parser/d;->r:Lcom/alibaba/fastjson/parser/d;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ne v5, v6, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x5

    move v1, v3

    move v1, v3

    const/4 v8, 0x4

    move v1, v3

    move v1, v3

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_1

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v1, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo p1, "ybpt@"

    const-string p1, "bpy@t"

    const/4 v8, 0x4

    const-string p1, "et@qy"

    const-string p1, "@type"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0, p1, p0}, Lcom/alibaba/fastjson/e;->P0(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-object v0
.end method

.method public static final varargs u(Ljava/lang/String;Lcom/alibaba/fastjson/k;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Lcom/alibaba/fastjson/k<",
            "TT;>;[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p1, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, p1, v0, v1, p2}, Lcom/alibaba/fastjson/a;->A(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0
.end method

.method public static final w(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-array v0, v0, [Lcom/alibaba/fastjson/parser/d;

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lcom/alibaba/fastjson/a;->y(Ljava/lang/String;Ljava/lang/Class;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final varargs x(Ljava/lang/String;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/deserializer/g;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/deserializer/g;",
            "[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object v2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget v4, Lcom/alibaba/fastjson/a;->d:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lcom/alibaba/fastjson/a;->B(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;Lcom/alibaba/fastjson/parser/deserializer/g;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p0
.end method

.method public static final varargs y(Ljava/lang/String;Ljava/lang/Class;[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "TT;>;[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget v1, Lcom/alibaba/fastjson/a;->d:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1, p2}, Lcom/alibaba/fastjson/a;->A(Ljava/lang/String;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method

.method public static final varargs z(Ljava/lang/String;Ljava/lang/reflect/Type;I[Lcom/alibaba/fastjson/parser/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Type;",
            "I[",
            "Lcom/alibaba/fastjson/parser/d;",
            ")TT;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    array-length v0, p3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    if-ge v1, v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    aget-object v2, p3, v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v2, v2, Lcom/alibaba/fastjson/parser/d;->mask:I

    const/4 v3, 0x6

    move v4, v3

    or-int/2addr p2, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance p3, Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    invoke-direct {p3, p0, v0, p2}, Lcom/alibaba/fastjson/parser/b;-><init>(Ljava/lang/String;Lcom/alibaba/fastjson/parser/m;I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p3, p1}, Lcom/alibaba/fastjson/parser/b;->h0(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p3, p0}, Lcom/alibaba/fastjson/parser/b;->r(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/b;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p0
.end method


# virtual methods
.method public a(Ljava/lang/Appendable;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->w:[Lcom/alibaba/fastjson/serializer/a0;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v0, v3, v1, v2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v5, 0x7

    const/4 v4, 0x1

    sget-object v2, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v1, v0, v2}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x3

    invoke-virtual {v1, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {p1, v1}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v1, v2, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw p1
.end method

.method public b()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x5

    move v5, v4

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->w:[Lcom/alibaba/fastjson/serializer/a0;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v0, v3, v1, v2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget-object v2, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v1, v0, v2}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    throw v1
.end method

.method public k0(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v3, 0x0

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {}, Lcom/alibaba/fastjson/parser/m;->f()Lcom/alibaba/fastjson/parser/m;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/alibaba/fastjson/a;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method
