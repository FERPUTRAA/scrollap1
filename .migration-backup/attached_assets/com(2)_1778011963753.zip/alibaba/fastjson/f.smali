.class public Lcom/alibaba/fastjson/f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field private final a:Lcom/alibaba/fastjson/parser/b;

.field private b:Lcom/alibaba/fastjson/h;

.field private c:Ljava/io/Reader;


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/parser/b;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method

.method public constructor <init>(Lcom/alibaba/fastjson/parser/e;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Lcom/alibaba/fastjson/parser/b;-><init>(Lcom/alibaba/fastjson/parser/e;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/alibaba/fastjson/f;-><init>(Lcom/alibaba/fastjson/parser/b;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(Ljava/io/Reader;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/alibaba/fastjson/parser/e;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/alibaba/fastjson/f;->l(Ljava/io/Reader;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/parser/e;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/alibaba/fastjson/f;-><init>(Lcom/alibaba/fastjson/parser/e;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/alibaba/fastjson/f;->c:Ljava/io/Reader;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private Q()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "t-s ~n/v@y    /@~~od@~~ba bc  @So ~~ @o~~@~@@. ~@~fiif@@@l4 @m~r ui~~@1l~ @~~~bo~~s@~MK@   oo@t@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v0, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    packed-switch v0, :pswitch_data_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    const-string v2, " e mtseatl aisg:"

    const-string/jumbo v2, "t:s lstl ieea ag"

    const/4 v4, 0x2

    const-string v2, "gs:lotlae tea  i"

    const-string/jumbo v2, "illegal state : "

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, v2, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw v0

    :pswitch_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/16 v1, 0x10

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v1, 0x11

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    :goto_0
    :pswitch_2
    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_2
        :pswitch_0
    .end packed-switch
.end method

.method private d()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/alibaba/fastjson/h;->a:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    iget v1, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch v1, :pswitch_data_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    const/4 v4, 0x6

    move v1, v2

    move v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :pswitch_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 v1, 0x3ed

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :pswitch_1
    const/4 v3, 0x7

    move v4, v3

    const/16 v1, 0x3eb

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v1, 0x3ea

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v1, v0, Lcom/alibaba/fastjson/h;->b:I

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_2
        :pswitch_1
        :pswitch_2
        :pswitch_0
    .end packed-switch
.end method

.method private j()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/16 v2, 0x3ea

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v3, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    packed-switch v1, :pswitch_data_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const-string/jumbo v3, "l aembst ilgleat"

    const-string/jumbo v3, "ie mstl t lealag"

    const/4 v5, 0x4

    const-string/jumbo v3, "laitseu g t:alel"

    const-string/jumbo v3, "illegal state : "

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    throw v0

    :pswitch_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    move v2, v3

    const/4 v5, 0x0

    move v2, v3

    move v2, v3

    const/4 v5, 0x2

    goto :goto_0

    :pswitch_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/16 v2, 0x3ed

    const/4 v5, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :pswitch_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v2, 0x3eb

    :goto_0
    :pswitch_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq v2, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput v2, v0, Lcom/alibaba/fastjson/h;->b:I

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method static l(Ljava/io/Reader;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/16 v1, 0x800

    :try_start_0
    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v2, v1, [C

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0, v2, v3, v1}, Ljava/io/Reader;->read([CII)I

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-gez v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p0

    :cond_0
    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v2, v3, v4}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v1, " er t dpeioodagnrrfoase rrrmr"

    const-string v1, "eo eordrdn frrrrm aigstroa re"

    const/4 v6, 0x7

    const-string/jumbo v1, "srroan rqerdtoe r rrgemf edia"

    const-string/jumbo v1, "read string from reader error"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v0, v1, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    throw v0
.end method

.method private m()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v0, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    packed-switch v0, :pswitch_data_0

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v3, "illegal state : "

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw v1

    :pswitch_0
    const/4 v4, 0x0

    move v5, v4

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/16 v1, 0x10

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :pswitch_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v1, 0x11

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    :goto_0
    :pswitch_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_2
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public D(Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/reflect/Type;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->h0(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v1, 0x1

    move v2, v1

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->h0(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1
.end method

.method public H(Ljava/util/Map;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->p0(Ljava/util/Map;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->p0(Ljava/util/Map;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    const/4 v2, 0x0

    return-object p1
.end method

.method public I(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->s0(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->s0(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public J()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lq0/d;->v(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public K()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/16 v1, 0x3ec

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x2

    move v3, v2

    move v3, v2

    const/4 v4, 0x3

    invoke-direct {v0, v2, v1}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->Q()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0, v2, v1}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v4, 0x4

    const/16 v1, 0xe

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method public N()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 v1, 0x3e9

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, v2, v1}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->Q()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v2, v1}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x7

    move v4, v3

    const/16 v1, 0xc

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method public a(Lcom/alibaba/fastjson/parser/d;Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p1, p2}, Lcom/alibaba/fastjson/parser/b;->e(Lcom/alibaba/fastjson/parser/d;Z)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/16 v1, 0xf

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->d()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public c()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v1, 0xd

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->d()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public close()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v3, 0x2

    move v4, v3

    iget-object v0, v0, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->c:Ljava/io/Reader;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/io/Reader;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, "desar ere rrcoobdsr"

    const-string/jumbo v2, "odarrb droscrere ee"

    const/4 v4, 0x7

    const-string v2, " r meoadreoseerrrdl"

    const-string v2, "closed reader error"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1, v2, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    throw v1

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public e()Z
    .locals 6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x1

    move v5, v4

    iget v1, v1, Lcom/alibaba/fastjson/h;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    packed-switch v1, :pswitch_data_0

    :pswitch_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v3, "lt eou :tliesga "

    const-string/jumbo v3, "iglls u  at:tlee"

    const/4 v5, 0x4

    const-string/jumbo v3, "illegal state : "

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw v0

    :pswitch_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v1, 0xf

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq v0, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    move v2, v3

    move v2, v3

    const/4 v5, 0x6

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v2

    :pswitch_2
    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v1, 0xd

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq v0, v1, :cond_1

    const/4 v4, 0x7

    move v5, v4

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    move v2, v3

    move v2, v3

    const/4 v5, 0x7

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v4, 0x7

    const/4 v4, 0x0

    return v2

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "sxnltbu eloci p"

    const-string v1, " s ltitpnexlocu"

    const/4 v5, 0x0

    const-string v1, " e iucunsltlnxo"

    const-string v1, "context is null"

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, v0, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public p()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lq0/d;->p(Ljava/lang/Object;)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-object v0
.end method

.method public r()Ljava/lang/Long;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lq0/d;->t(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public readObject()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v1, 0x6

    move v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public t(Lcom/alibaba/fastjson/k;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/k<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p1, p1, Lcom/alibaba/fastjson/k;->a:Ljava/lang/reflect/Type;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/f;->D(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public v(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->b:Lcom/alibaba/fastjson/h;

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->e0(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->m()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/f;->a:Lcom/alibaba/fastjson/parser/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/parser/b;->e0(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/alibaba/fastjson/f;->j()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method
