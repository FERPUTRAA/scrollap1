.class public final enum Lcom/alibaba/fastjson/j;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/alibaba/fastjson/j;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/alibaba/fastjson/j;

.field public static final enum b:Lcom/alibaba/fastjson/j;

.field public static final enum c:Lcom/alibaba/fastjson/j;

.field public static final enum d:Lcom/alibaba/fastjson/j;

.field private static final synthetic e:[Lcom/alibaba/fastjson/j;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    new-instance v0, Lcom/alibaba/fastjson/j;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v1, "lCsmesCea"

    const/4 v10, 0x5

    const-string v1, "CamelCase"

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {v0, v1, v2}, Lcom/alibaba/fastjson/j;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    sput-object v0, Lcom/alibaba/fastjson/j;->a:Lcom/alibaba/fastjson/j;

    const/4 v10, 0x0

    new-instance v1, Lcom/alibaba/fastjson/j;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string v3, "ascmaClaes"

    const/4 v10, 0x0

    const-string/jumbo v3, "sPsceCsaaa"

    const-string v3, "PascalCase"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v4, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v1, v3, v4}, Lcom/alibaba/fastjson/j;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    sput-object v1, Lcom/alibaba/fastjson/j;->b:Lcom/alibaba/fastjson/j;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance v3, Lcom/alibaba/fastjson/j;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v5, "askmCenea"

    const-string v5, "SnakeCase"

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v6, 0x2

    const/4 v9, 0x7

    or-int/2addr v10, v9

    invoke-direct {v3, v5, v6}, Lcom/alibaba/fastjson/j;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    sput-object v3, Lcom/alibaba/fastjson/j;->c:Lcom/alibaba/fastjson/j;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v5, Lcom/alibaba/fastjson/j;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string v7, "baseoaKbC"

    const-string v7, "KebabCase"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v8, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-direct {v5, v7, v8}, Lcom/alibaba/fastjson/j;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    sput-object v5, Lcom/alibaba/fastjson/j;->d:Lcom/alibaba/fastjson/j;

    const/4 v9, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v7, 0x4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-array v7, v7, [Lcom/alibaba/fastjson/j;

    const/4 v10, 0x5

    aput-object v0, v7, v2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    aput-object v1, v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    aput-object v3, v7, v6

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    aput-object v5, v7, v8

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    sput-object v7, Lcom/alibaba/fastjson/j;->e:[Lcom/alibaba/fastjson/j;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/alibaba/fastjson/j;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ o ab~@~~tfi cf@ @ @~ob~ ~~@~~~4/ @~/ @1~ob. @ro yiKnbM @u@t~~~s  m@v~d~~ @@~@@o@-~oi~  @@l @@l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-class v0, Lcom/alibaba/fastjson/j;

    const-class v0, Lcom/alibaba/fastjson/j;

    const/4 v2, 0x3

    const-class v0, Lcom/alibaba/fastjson/j;

    const-class v0, Lcom/alibaba/fastjson/j;

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/alibaba/fastjson/j;

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/alibaba/fastjson/j;
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    sget-object v0, Lcom/alibaba/fastjson/j;->e:[Lcom/alibaba/fastjson/j;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lcom/alibaba/fastjson/j;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast v0, [Lcom/alibaba/fastjson/j;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    sget-object v0, Lcom/alibaba/fastjson/j$a;->a:[I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    aget v0, v0, v1

    const/4 v7, 0x2

    const/16 v1, 0x5a

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/16 v2, 0x41

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq v0, v3, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v3, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eq v0, v3, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v3, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eq v0, v3, :cond_2

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    const/4 v3, 0x4

    xor-int/2addr v7, v3

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    if-eq v0, v3, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object p1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-lt v0, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-gt v0, v1, :cond_1

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    aget-char v0, p1, v4

    const/4 v7, 0x4

    add-int/lit8 v0, v0, 0x20

    const/4 v7, 0x0

    const/4 v6, 0x2

    int-to-char v0, v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    aput-char v0, p1, v4

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {v0, p1}, Ljava/lang/String;-><init>([C)V

    const/4 v6, 0x2

    move v7, v6

    return-object v0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-object p1

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/16 v1, 0x61

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-lt v0, v1, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v1, 0x7a

    const/4 v7, 0x1

    const/4 v6, 0x3

    if-gt v0, v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    aget-char v0, p1, v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    add-int/lit8 v0, v0, -0x20

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    int-to-char v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    aput-char v0, p1, v4

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v0, p1}, Ljava/lang/String;-><init>([C)V

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    return-object v0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-object p1

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-ge v4, v3, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    if-lt v3, v2, :cond_6

    const/4 v7, 0x4

    if-gt v3, v1, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x20

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    int-to-char v3, v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-lez v4, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/16 v5, 0x2d

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_1

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_7
    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-object p1

    :cond_8
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    move v7, v6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v4, v3, :cond_b

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-lt v3, v2, :cond_a

    const/4 v7, 0x4

    const/4 v6, 0x1

    if-gt v3, v1, :cond_a

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x20

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    int-to-char v3, v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-lez v4, :cond_9

    const/4 v7, 0x0

    const/16 v5, 0x5f

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_9
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_3

    :cond_a
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_3
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_2

    :cond_b
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-object p1
.end method
