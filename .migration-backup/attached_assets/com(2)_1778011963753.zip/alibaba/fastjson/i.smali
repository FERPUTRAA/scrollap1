.class public Lcom/alibaba/fastjson/i;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# instance fields
.field private a:Lcom/alibaba/fastjson/serializer/z;

.field private b:Lcom/alibaba/fastjson/serializer/m;

.field private c:Lcom/alibaba/fastjson/h;


# direct methods
.method public constructor <init>(Ljava/io/Writer;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    invoke-direct {v0, p1}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance p1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/alibaba/fastjson/i;->b:Lcom/alibaba/fastjson/serializer/m;

    const/4 v2, 0x4

    return-void
.end method

.method private a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@is@Ml /@ ~~ ot ~~@o@@ f@c4~u~  ~~ oo~b~~t ~fsK ~~~ob@ ~.@@ ~d @@@/@@n @~i~ib~o -y@ar 1 v~Sl@~m@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v1, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x6

    move v3, v2

    move v3, v2

    const/4 v4, 0x7

    packed-switch v1, :pswitch_data_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :pswitch_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 v1, 0x3ed

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_1

    :pswitch_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/16 v1, 0x3eb

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_1

    :pswitch_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v1, 0x3ea

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_1

    :goto_0
    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput v1, v0, Lcom/alibaba/fastjson/h;->b:I

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_2
        :pswitch_1
        :pswitch_2
        :pswitch_0
    .end packed-switch
.end method

.method private b()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/16 v1, 0x3ea

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eq v0, v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/16 v1, 0x3eb

    const/4 v4, 0x3

    const/16 v2, 0x2c

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v0, v1, :cond_2

    const/16 v1, 0x3ed

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eq v0, v1, :cond_1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v1, 0x3a

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method private c()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v0, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, "al mt al:etgsli "

    const-string/jumbo v3, "ltsl :aalgit s e"

    const/4 v5, 0x5

    const-string v3, "eta olgl ia e:ts"

    const-string/jumbo v3, "illegal state : "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    throw v1

    :pswitch_1
    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v1, 0x2c

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :pswitch_2
    const/4 v5, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v1, 0x3a

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_0
    :pswitch_3
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x3e9
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_3
        :pswitch_1
    .end packed-switch
.end method

.method private j()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, v0, Lcom/alibaba/fastjson/h;->a:Lcom/alibaba/fastjson/h;

    const/4 v5, 0x4

    move v6, v5

    iput-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v1, v0, Lcom/alibaba/fastjson/h;->b:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/16 v2, 0x3e9

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/16 v3, 0x3ea

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eq v1, v2, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eq v1, v3, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/16 v2, 0x3ec

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eq v1, v2, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v3, v4

    move v3, v4

    const/4 v6, 0x7

    move v3, v4

    move v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    move v6, v5

    const/16 v3, 0x3ed

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/16 v3, 0x3eb

    :cond_3
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eq v3, v4, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput v3, v0, Lcom/alibaba/fastjson/h;->b:I

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void
.end method


# virtual methods
.method public close()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public d(Lcom/alibaba/fastjson/serializer/a0;Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Lcom/alibaba/fastjson/serializer/z;->d(Lcom/alibaba/fastjson/serializer/a0;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0x5d

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->j()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public f()V
    .locals 4

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/16 v1, 0x7d

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->j()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public flush()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->flush()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public l()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->c()V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v3, 0x3

    move v4, v3

    const/16 v2, 0x3ec

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/16 v1, 0x5b

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method

.method public m()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->c()V

    :cond_0
    const/4 v4, 0x3

    new-instance v0, Lcom/alibaba/fastjson/h;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/16 v2, 0x3e9

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lcom/alibaba/fastjson/h;-><init>(Lcom/alibaba/fastjson/h;I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/alibaba/fastjson/i;->c:Lcom/alibaba/fastjson/h;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->a:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/16 v1, 0x7b

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method public p(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/i;->t(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public r(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->b()V

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->b:Lcom/alibaba/fastjson/serializer/m;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public t(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->b()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/i;->b:Lcom/alibaba/fastjson/serializer/m;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/alibaba/fastjson/i;->a()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public v(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/i;->r(Ljava/lang/Object;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method
