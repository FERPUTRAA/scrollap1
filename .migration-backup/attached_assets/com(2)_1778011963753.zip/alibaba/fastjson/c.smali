.class public interface abstract Lcom/alibaba/fastjson/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract b()Ljava/lang/String;
.end method
