.class synthetic Lcom/alibaba/fastjson/j$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alibaba/fastjson/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/alibaba/fastjson/j;->values()[Lcom/alibaba/fastjson/j;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    array-length v0, v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-array v0, v0, [I

    const/4 v4, 0x1

    const/4 v3, 0x5

    sput-object v0, Lcom/alibaba/fastjson/j$a;->a:[I

    :try_start_0
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/j;->c:Lcom/alibaba/fastjson/j;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v0, Lcom/alibaba/fastjson/j$a;->a:[I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/j;->d:Lcom/alibaba/fastjson/j;

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x6

    move v4, v3

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x1

    sget-object v0, Lcom/alibaba/fastjson/j$a;->a:[I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/j;->b:Lcom/alibaba/fastjson/j;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object v0, Lcom/alibaba/fastjson/j$a;->a:[I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/j;->a:Lcom/alibaba/fastjson/j;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    return-void
.end method
