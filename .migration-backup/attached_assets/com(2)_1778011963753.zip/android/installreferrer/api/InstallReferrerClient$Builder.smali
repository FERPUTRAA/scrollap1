.class public final Lcom/android/installreferrer/api/InstallReferrerClient$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/android/installreferrer/api/InstallReferrerClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private final mContext:Landroid/content/Context;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/android/installreferrer/api/InstallReferrerClient$Builder;->mContext:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Landroid/content/Context;Lcom/android/installreferrer/api/InstallReferrerClient$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/android/installreferrer/api/InstallReferrerClient$Builder;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public build()Lcom/android/installreferrer/api/InstallReferrerClient;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "d sl~oso@ f~t~~@o@~ M @u@ @@@o.  @-@~1 a@oi~~  ~bbm~y~S~@/4~i@~lb  v~~~@n@~ c@@~ft o~@@~ r K~/ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/android/installreferrer/api/InstallReferrerClient$Builder;->mContext:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/android/installreferrer/api/InstallReferrerClientImpl;

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {v1, v0}, Lcom/android/installreferrer/api/InstallReferrerClientImpl;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "Paemnxsdleotiiapae sr tdo.Clv  "

    const-string/jumbo v1, "plsaeotdoeCe tidxvnaelPir .a  s"

    const/4 v3, 0x1

    const-string v1, "i.lsoaltareo nvC a Px eidvpteed"

    const-string v1, "Please provide a valid Context."

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw v0
.end method
