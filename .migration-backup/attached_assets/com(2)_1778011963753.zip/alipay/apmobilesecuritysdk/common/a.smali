.class public final Lcom/alipay/apmobilesecuritysdk/common/a;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ts@@o i~ ~f-~~ ~itl~vo@@~~@bo~~m~b/sd~o.M~@S @@l@o@ @f~ ociny/@~~1  r@@ @ ~~@   ~ @~~4@u@a  K@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/h;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/alipay/apmobilesecuritysdk/common/a;->a(Ljava/util/List;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p0, Lcom/alipay/apmobilesecuritysdk/common/RushTimeUtil$1;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/alipay/apmobilesecuritysdk/common/RushTimeUtil$1;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/common/a;->a(Ljava/util/List;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x1

    return p0
.end method

.method private static a(Ljava/util/List;)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v1, "dM-mss:yHdyM:smm-yH"

    const-string v1, "Hssys:yMdH:m-yyMm-d"

    const-string v1, "-ms:oyHmd-yyyd: sHM"

    const-string/jumbo v1, "yyyy-MM-dd HH:mm:ss"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setLenient(Z)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const/4 v9, 0x7

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    mul-double/2addr v2, v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const/4 v9, 0x1

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    mul-double/2addr v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    mul-double/2addr v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    double-to-int v2, v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    mul-int/2addr v2, v3

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v4, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    check-cast v4, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v5, "&"

    const-string v5, "&"

    const/4 v9, 0x1

    const-string v5, "&"

    const-string v5, "&"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v4, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    array-length v5, v4

    const/4 v9, 0x4

    const/4 v6, 0x2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-ne v5, v6, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v5, Ljava/util/Date;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-direct {v5}, Ljava/util/Date;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    aget-object v7, v4, v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    const-string v7, "00 m000::"

    const/4 v9, 0x7

    const-string v7, ":0: 0b000"

    const-string v7, " 00:00:00"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0, v6}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    move v9, v8

    aget-object v4, v4, v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string v4, "5:5 92u3o"

    const-string v4, "535:o2 99"

    const-string v4, "29:539:p "

    const-string v4, " 23:59:59"

    const/4 v9, 0x1

    const/4 v8, 0x3

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0, v4}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v7

    const/4 v9, 0x7

    const/4 v8, 0x3

    invoke-virtual {v7, v4}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    const/16 v4, 0xd

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v7, v4, v2}, Ljava/util/Calendar;->add(II)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v7}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v5, v6}, Ljava/util/Date;->after(Ljava/util/Date;)Z

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x0

    if-eqz v6, :cond_0

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-virtual {v5, v4}, Ljava/util/Date;->before(Ljava/util/Date;)Z

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v4, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    return v3

    :catch_0
    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    return v1
.end method
