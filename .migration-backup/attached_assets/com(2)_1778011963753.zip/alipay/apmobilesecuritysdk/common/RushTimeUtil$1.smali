.class final Lcom/alipay/apmobilesecuritysdk/common/RushTimeUtil$1;
.super Ljava/util/ArrayList;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/ArrayList<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const-string v0, "-2s01-8&2011-68680170"

    const-string v0, "17s0&608128210-8-10-6"

    const/4 v2, 0x4

    const-string v0, "1-8m21-017-82&-680016"

    const-string v0, "2018-06-17&2018-06-18"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "2119o80289--00098&0-0"

    const-string v0, "&02m-989802-0911000-8"

    const/4 v2, 0x6

    const-string v0, "800-1b98910-0-0280&29"

    const-string v0, "2018-09-08&2018-09-09"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "81210-u11&1180-11-01o"

    const-string v0, "1111o2&-1081-1-80-011"

    const/4 v2, 0x7

    const-string v0, "1-11-&-p11110080128-2"

    const-string v0, "2018-11-10&2018-11-11"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const-string v0, "0101-b21118-21&122--2"

    const/4 v2, 0x0

    const-string v0, "-2221-&2q1-8110210181"

    const-string v0, "2018-12-11&2018-12-12"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string v0, "50s&920--220412-900-1"

    const-string v0, "2019-02-04&2019-02-05"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "0-2290u6&176119--00-1"

    const/4 v2, 0x2

    const-string v0, "2&1m69009-681-01-207-"

    const-string v0, "2019-06-17&2019-06-18"

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "0912o&09-0-290189-009"

    const-string v0, "2019-09-08&2019-09-09"

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, "-119&b01-1-9101p1-201"

    const-string v0, "11-0-02p--1119&111091"

    const/4 v2, 0x7

    const-string v0, "0211-0u11991&201-1-1-"

    const-string v0, "2019-11-10&2019-11-11"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x5

    or-int/2addr v2, v1

    const-string v0, "9-292-1p1-111&120q10-"

    const-string v0, "-1--9&92q011220-12111"

    const/4 v2, 0x5

    const-string v0, "&9112-22q1-1-191-2002"

    const-string v0, "2019-12-11&2019-12-12"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "12s2&0--02-2245-s0100"

    const-string v0, "-2s000&4-05012212--02"

    const/4 v2, 0x0

    const-string v0, "100m52000--22-122-24&"

    const-string v0, "2020-01-24&2020-01-25"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const-string v0, "280-o0021-7-6100m62-2"

    const-string v0, "00-m280-0622-216107&-"

    const/4 v2, 0x7

    const-string v0, "00172b062016&--00822-"

    const-string v0, "2020-06-17&2020-06-18"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "020002u-00-9289-&o29-"

    const-string v0, "0020o-20---0900928&92"

    const/4 v2, 0x0

    const-string v0, "29008-&p-2090002029-0"

    const-string v0, "2020-09-08&2020-09-09"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "1--10b-2q-11120022010"

    const-string v0, "-1-0-b-20100121101212"

    const/4 v2, 0x0

    const-string v0, "00s2112021021-0-1&-1-"

    const-string v0, "2020-11-10&2020-11-11"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string v0, "1-1m0-2-u012&20210221"

    const-string v0, "20--02u1101-022212&-1"

    const/4 v2, 0x7

    const-string v0, "2011o022-12210&0---12"

    const-string v0, "2020-12-11&2020-12-12"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "--20-b1p&22011212-201"

    const-string v0, "012&12-p2-211-1-02220"

    const/4 v2, 0x4

    const-string v0, "001212u2-2-012102--12"

    const-string v0, "2021-02-11&2021-02-12"

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string v0, "-2726-1p161008&0-q1-2"

    const-string v0, "1102-2-1q&06168270-0-"

    const/4 v2, 0x7

    const-string v0, "6612-&00q11200-821--7"

    const-string v0, "2021-06-17&2021-06-18"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, "9-s-00&282992s0011200"

    const-string v0, "-0s9120-0&20210-82990"

    const/4 v2, 0x3

    const-string v0, "018m9022091-&02-0--92"

    const-string v0, "2021-09-08&2021-09-09"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, "&0-2o-102111212011m-1"

    const-string v0, "-11m2-101-1&2-0201121"

    const/4 v2, 0x0

    const-string v0, "102&1b-1011-1102-1122"

    const-string v0, "2021-11-10&2021-11-11"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, "02-11-u1-1121122&2-20"

    const-string v0, "-222o11--21&12112-001"

    const/4 v2, 0x0

    const-string v0, "22&0011p1112-2-211-2-"

    const-string v0, "2021-12-11&2021-12-12"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v0, "-22-3-1&q002102b2-022"

    const-string v0, "-&10-b-0322-102022122"

    const/4 v2, 0x1

    const-string v0, "01s32--210002&--12220"

    const-string v0, "2022-01-31&2022-02-01"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "718m06-021u-&-0220-22"

    const-string v0, "2206-2u--70-826&01102"

    const-string v0, "2--2o-11&6282-2007600"

    const-string v0, "2022-06-17&2022-06-18"

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const-string v0, "--20-b202000902-92p&8"

    const-string v0, "2002-98p2202-0-0-2&09"

    const/4 v2, 0x1

    const-string v0, "92090-u&20020-2-89202"

    const-string v0, "2022-09-08&2022-09-09"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "1-12011p22-2010221q-&"

    const-string v0, "021122--q1-11&2001122"

    const/4 v2, 0x0

    const-string v0, "-0-11&02q2122120-1-12"

    const-string v0, "2022-11-10&2022-11-11"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "01s22202-21-221-211&2"

    const-string v0, "2&s02-012221-12-22211"

    const/4 v2, 0x5

    const-string v0, "212m-122-0-22&102211-"

    const-string v0, "2022-12-11&2022-12-12"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-void
.end method
