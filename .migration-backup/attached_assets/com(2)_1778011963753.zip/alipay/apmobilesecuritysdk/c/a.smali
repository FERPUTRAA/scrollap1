.class public final Lcom/alipay/apmobilesecuritysdk/c/a;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4~sv@~@ y~ @@1d @~S a~@@ n~~@bM~  ~.r s   ~obi~~ l //~oct~o-~~ @f o o@@~@o~mf@@@@~@bK @~tl~@iu~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, p1, p2, p3}, Lcom/alipay/apmobilesecuritysdk/c/a;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/alipay/security/mobile/module/d/a;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const-string p0, "//pmaol"

    const-string/jumbo p0, "pos//al"

    const/4 v3, 0x5

    const-string/jumbo p0, "l/opog/"

    const-string p0, "/log/ap"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    new-instance p3, Ljava/text/SimpleDateFormat;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    const-string/jumbo v1, "yymdMbMy"

    const-string v1, "ddMmyyMy"

    const/4 v3, 0x7

    const-string/jumbo v1, "yyMyMdud"

    const-string/jumbo v1, "yyyyMMdd"

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {p3, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p3, p2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo p2, "lg.o"

    const-string/jumbo p2, "lo.g"

    const/4 v3, 0x0

    const-string/jumbo p2, "lgo."

    const-string p2, ".log"

    const/4 v3, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/alipay/security/mobile/module/d/a;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p2, p1}, Lcom/alipay/security/mobile/module/d/d;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    throw p0
.end method

.method public static declared-synchronized a(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/alipay/security/mobile/module/d/d;->a(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw p0
.end method

.method public static declared-synchronized a(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v2, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/c/a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/alipay/security/mobile/module/d/d;->c(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    throw p0
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/alipay/security/mobile/module/d/a;
    .locals 10

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_1

    :catchall_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v9, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto :goto_0

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x6

    new-instance p0, Lcom/alipay/security/mobile/module/d/a;

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v3, "P-KuPcPpySDAeKArLISioSAt"

    const-string v3, "cSAPoKAPrIDtSKSieALDyPu-"

    const/4 v9, 0x4

    const-string/jumbo v3, "yDcPYIKLqKDAPPirAAeSu-tS"

    const-string v3, "APPSecuritySDK-ALIPAYSDK"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v4, "60s99203.1604b3.1."

    const-string v4, ".9.14b.69306203011"

    const/4 v9, 0x3

    const-string v4, "61.m36.001.1019293"

    const-string v4, "3.4.0.201910161639"

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct/range {v0 .. v7}, Lcom/alipay/security/mobile/module/d/a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-object p0
.end method
