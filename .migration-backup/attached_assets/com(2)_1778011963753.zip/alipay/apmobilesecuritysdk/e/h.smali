.class public Lcom/alipay/apmobilesecuritysdk/e/h;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/Context;)J
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s~ i @l@ ~ Mv@S o @4r~l-@a@~o   Ko~b @~~/@@@ b~.@fd~y~@m t@fo~~~c~~ @~@o@n@  ~@is/~1~ i@@tb o~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const-string/jumbo v0, "tnstrivlmiptd_ee_aue"

    const/4 v4, 0x7

    const-string/jumbo v0, "mtemduiteetvlp_rana_"

    const-string/jumbo v0, "update_time_interval"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v1, "ikvdontem_tysie"

    const-string/jumbo v1, "yvgmdsetnkit_ie"

    const/4 v4, 0x4

    const-string/jumbo v1, "sg_nibttveskyde"

    const-string/jumbo v1, "vkeyid_settings"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0, v1, v0}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    const/4 v4, 0x1

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-wide v1
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "tivaulun_otmda_etepe"

    const-string v0, "ai_toueaetlvpme_dtni"

    const/4 v2, 0x1

    const-string/jumbo v0, "uilit_vpraepedmnae_t"

    const-string/jumbo v0, "update_time_interval"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "ybvaled_qk"

    const-string/jumbo v1, "ilevdbak_y"

    const/4 v3, 0x2

    const-string/jumbo v1, "vlsiavyed_"

    const-string/jumbo v1, "vkey_valid"

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo p3, "issmtdvynegukt_"

    const-string/jumbo p3, "snkeevuy_dtsitg"

    const/4 v3, 0x7

    const-string/jumbo p3, "skstoeidn_eivty"

    const-string/jumbo p3, "vkeyid_settings"

    const/4 v3, 0x7

    invoke-static {p0, p3, p1, p2}, Lb1/a;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "se_iybipedktvst"

    const-string/jumbo v0, "itesvdepskigty_"

    const-string/jumbo v0, "yvetkiu_gisetns"

    const-string/jumbo v0, "vkeyid_settings"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0, v0, p1, p2}, Lb1/a;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string p1, "1"

    const-string p1, "1"

    const/4 v2, 0x2

    const-string p1, "1"

    const-string p1, "1"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string p1, "0"

    const-string p1, "0"

    const/4 v2, 0x3

    const-string p1, "0"

    const-string p1, "0"

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "ciwogltps_"

    const-string v0, "_wgistclqo"

    const/4 v2, 0x7

    const-string/jumbo v0, "iocgwtlhq_"

    const-string/jumbo v0, "log_switch"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string v0, "atss_asndped_l"

    const-string v0, "_dsiasn_adetpl"

    const/4 v3, 0x6

    const-string v0, "_vamdd_tlnsiep"

    const-string/jumbo v0, "last_apdid_env"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "ttvkogieeysd_ms"

    const-string v1, "de_mnsyeksgivtt"

    const/4 v3, 0x6

    const-string v1, "_ytgdbtseeiinkv"

    const-string/jumbo v1, "vkeyid_settings"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0, v1, v0}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    const-string/jumbo v0, "it___huclnttommeisoeba"

    const-string v0, "eetoolm__si_ctmbatnhia"

    const/4 v2, 0x1

    const-string/jumbo v0, "last_machine_boot_time"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v0, "eadn__bppiadsl"

    const-string/jumbo v0, "ldda_biepn_tsa"

    const/4 v2, 0x3

    const-string/jumbo v0, "ps_l_ddtqvanai"

    const-string/jumbo v0, "last_apdid_env"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "_lsctigsoh"

    const-string v0, "c_tisguolh"

    const/4 v3, 0x5

    const-string/jumbo v0, "ohgmiwcst_"

    const-string/jumbo v0, "log_switch"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "kt_yogsivpeidet"

    const-string/jumbo v1, "skvyteepit_isgd"

    const/4 v3, 0x0

    const-string v1, "gsteybvn_diitek"

    const-string/jumbo v1, "vkeyid_settings"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, v1, v0}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "1"

    const-string v0, "1"

    const/4 v3, 0x0

    const-string v0, "1"

    const-string v0, "1"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p0
.end method

.method public static d(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "nkyec_uyqdm"

    const-string v0, "acnmked_qyy"

    const/4 v3, 0x6

    const-string v0, "dynamic_key"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "yivdktipssegest"

    const-string v1, "_dstiievestskyg"

    const/4 v3, 0x5

    const-string v1, "dtyiis_kqnsvegt"

    const-string/jumbo v1, "vkeyid_settings"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, v1, v0}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "_sstmcaentgh"

    const-string/jumbo v0, "isgmtanehc_t"

    const/4 v2, 0x1

    const-string/jumbo v0, "wa_mngcshtit"

    const-string v0, "agent_switch"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const-string v0, "eoproadsdg_e"

    const-string v0, "_rddopegeesa"

    const/4 v3, 0x6

    const-string v0, "gerasbe_paed"

    const-string v0, "apse_degrade"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const-string v1, "_stiedugbistvyn"

    const-string v1, "_stydbgitiesevn"

    const/4 v3, 0x1

    const-string v1, "e_nikispgydevtt"

    const-string/jumbo v1, "vkeyid_settings"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v1, v0}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "my_ncyikqua"

    const-string v0, "cmyek_unayi"

    const-string/jumbo v0, "icsn_deykym"

    const-string v0, "dynamic_key"

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public static f(Landroid/content/Context;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/h;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/h;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/h;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v1, "eklmo__vpyrdympnai"

    const-string v1, "ak_l_ryppamvnoeiyd"

    const/4 v6, 0x0

    const-string/jumbo v1, "idalomyraeyoavnpk_"

    const-string v1, "alipay_vkey_random"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v2, "dqmorb"

    const-string v2, "adqrmo"

    const/4 v6, 0x3

    const-string/jumbo v2, "urndma"

    const-string/jumbo v2, "random"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0, v1, v2, v3}, Lb1/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/h;->a:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v1}, La1/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/h;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v2, "iral_y_psykpveaadm"

    const-string v2, "dksyyalraveni_am_p"

    const/4 v6, 0x5

    const-string/jumbo v2, "kd_mrnoaqyeapyvia_"

    const-string v2, "alipay_vkey_random"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v3, "mromda"

    const/4 v6, 0x0

    const-string v3, "aosrdn"

    const-string/jumbo v3, "random"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p0, :cond_0

    const/4 v5, 0x5

    move v6, v5

    invoke-interface {p0, v3, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v6, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    sget-object p0, Lcom/alipay/apmobilesecuritysdk/e/h;->a:Ljava/lang/String;

    const/4 v6, 0x7

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    throw p0
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string v0, "buemwolr_c"

    const-string/jumbo v0, "rclboutwe_"

    const/4 v2, 0x5

    const-string/jumbo v0, "tbewourlc_"

    const-string/jumbo v0, "webrtc_url"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "raea_beesbgd"

    const-string v0, "de_gsbaarpee"

    const/4 v2, 0x5

    const-string v0, "_apdeeurasdg"

    const-string v0, "apse_degrade"

    const/4 v2, 0x0

    invoke-static {p0, v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;)J
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :try_start_0
    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v2, "tiyevt_psnekidg"

    const-string v2, "dktgsnuivt_eeyi"

    const/4 v6, 0x3

    const-string v2, "_sniiktsqvdeyge"

    const-string/jumbo v2, "vkeyid_settings"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v4, "pkslide_av"

    const-string v4, "eidvl_apkv"

    const/4 v6, 0x3

    const-string/jumbo v4, "y_emvdakiv"

    const-string/jumbo v4, "vkey_valid"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p0, v2, p1}, Lb1/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-wide v0

    :cond_0
    const/4 v6, 0x4

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-wide p0

    :catchall_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-wide v0
.end method
