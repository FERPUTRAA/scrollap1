.class public final Lcom/alipay/apmobilesecuritysdk/e/b;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->a:Ljava/lang/String;

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->c:Ljava/lang/String;

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method
