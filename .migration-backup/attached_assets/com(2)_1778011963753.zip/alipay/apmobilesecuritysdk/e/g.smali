.class public final Lcom/alipay/apmobilesecuritysdk/e/g;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s ~d@~nva~@b ~~t1~~~@@~b.@/ ~@KSlf~~ i ~~@i@@4  o@ @@yt@@o@f~~si-c ~~o@~@ M @~ ~~o /l ou@bm  o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v5, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v5, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const-string/jumbo v1, "ii_mflirnpoaespe"

    const-string v1, "aesiolirp_nfp_ie"

    const/4 v5, 0x2

    const-string v1, "_nplofoe_areipip"

    const-string/jumbo v1, "openapi_file_pri"

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const-string v3, "Aipmobp"

    const-string/jumbo v3, "inompAp"

    const/4 v5, 0x4

    const-string/jumbo v3, "opeApnu"

    const-string/jumbo v3, "openApi"

    const/4 v4, 0x5

    const/4 v4, 0x2

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p0, v1, p1, v2}, Lb1/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x4

    const-string p0, ""

    const-string p0, ""
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object p0

    :cond_0
    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p1, p0}, La1/c;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x7

    const-string p0, ""

    const-string p0, ""
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x3

    return-object p0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw p0
.end method

.method public static declared-synchronized a()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v2, 0x3

    monitor-enter v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v4, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "raponpppioifiel_"

    const-string/jumbo v1, "ifp_o_ppleioarni"

    const/4 v4, 0x7

    const-string v1, "_iinoifeqlpp_ape"

    const-string/jumbo v1, "openapi_file_pri"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v4, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/g;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "bispl_ipiarfp_en"

    const-string/jumbo v1, "inrppbpflai_i_oe"

    const/4 v4, 0x1

    const-string/jumbo v1, "lrimfpnpi_apiee_"

    const-string/jumbo v1, "openapi_file_pri"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "uopiopA"

    const-string v2, "eioAppu"

    const/4 v4, 0x4

    const-string/jumbo v2, "ppneobA"

    const-string/jumbo v2, "openApi"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1, p2}, La1/c;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :catchall_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method
