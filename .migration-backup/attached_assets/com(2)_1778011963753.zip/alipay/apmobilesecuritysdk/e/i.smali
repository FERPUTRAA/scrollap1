.class public final Lcom/alipay/apmobilesecuritysdk/e/i;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""

.field private static b:Ljava/lang/String; = ""

.field private static c:Ljava/lang/String; = ""

.field private static d:Ljava/lang/String; = ""

.field private static e:Ljava/lang/String; = ""

.field private static f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static declared-synchronized a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@/s ~ @s@uatf@v/~iof~@4t~~l~o@m @~ oo  b~c-@b@@@@@r   i ~~~~ K@~o~ @~.b~ ~~ 1ly ~@ ~@~iSM@@n@od~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v4, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v2, "oasmahcTdpkdine"

    const-string v2, "aesaeidphdTnkoc"

    const/4 v4, 0x5

    const-string v2, "ehoConkTicdepad"

    const-string v2, "apdidTokenCache"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v1, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object p0

    :cond_0
    :try_start_1
    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x0

    const-string p0, ""

    const-string p0, ""
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    throw p0
.end method

.method public static declared-synchronized a()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v2, 0x7

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-enter v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    monitor-exit v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static declared-synchronized a(Lcom/alipay/apmobilesecuritysdk/e/b;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    monitor-enter v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->b:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->c:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0

    :cond_0
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public static declared-synchronized a(Lcom/alipay/apmobilesecuritysdk/e/c;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-enter v0

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->b:Ljava/lang/String;

    const/4 v3, 0x0

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->d:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->c:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p0

    :cond_0
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    return-void
.end method

.method public static declared-synchronized a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v4, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v4, 0x3

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "minTabhocdekadC"

    const-string v2, "aaimChpcnodkdeT"

    const/4 v4, 0x0

    const-string v2, "eCoackupddTaehi"

    const-string v2, "apdidTokenCache"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v1, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v1, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v8, 0x7

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    monitor-enter v0

    const/4 v7, 0x2

    move v8, v7

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    const/4 v8, 0x5

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;)J

    move-result-wide v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x2

    const-wide/16 v5, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    cmp-long v5, v3, v5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-gez v5, :cond_0

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    move-wide v1, v3

    :catchall_0
    :goto_0
    :try_start_1
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->h(Landroid/content/Context;Ljava/lang/String;)J

    move-result-wide p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    sub-long/2addr v3, p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    cmp-long p0, p0, v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-gez p0, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    monitor-exit v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 p0, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    return p0

    :catchall_1
    move-exception p0

    :try_start_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    monitor-exit v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 p0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    return p0

    :catchall_2
    move-exception p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    monitor-exit v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    throw p0
.end method

.method public static declared-synchronized b()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    throw v1
.end method

.method public static b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static declared-synchronized c()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw v1
.end method

.method public static c(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public static declared-synchronized d()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->d:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw v1
.end method

.method public static d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static declared-synchronized e()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x3

    const/4 v2, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->e:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v2, 0x2

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw v1
.end method

.method public static e(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->d:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static declared-synchronized f()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw v1
.end method

.method public static f(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    sput-object p0, Lcom/alipay/apmobilesecuritysdk/e/i;->e:Ljava/lang/String;

    const/4 v1, 0x5

    return-void
.end method

.method public static declared-synchronized g()Lcom/alipay/apmobilesecuritysdk/e/c;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/i;

    const/4 v8, 0x1

    move v9, v8

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v7, Lcom/alipay/apmobilesecuritysdk/e/c;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    sget-object v2, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;

    const/4 v9, 0x3

    sget-object v3, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    sget-object v4, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget-object v5, Lcom/alipay/apmobilesecuritysdk/e/i;->d:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    sget-object v6, Lcom/alipay/apmobilesecuritysdk/e/i;->e:Ljava/lang/String;

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct/range {v1 .. v6}, Lcom/alipay/apmobilesecuritysdk/e/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v9, 0x1

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    return-object v7

    :catchall_0
    move-exception v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    monitor-exit v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    throw v1
.end method

.method public static h()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->f:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x7

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->e:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/e/i;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
