.class public final Lcom/alipay/apmobilesecuritysdk/e/e;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/f;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~asv/@  ~dmo@r ~ @ @n~@b~ito41~~~@  @@ ~o@@  u@is@bM~@~~  ~~~@~~@@l obytof -S~o~~f./ ~@@ Kci@ l@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "eetmnrermieade_fv_cause_s"

    const-string v1, "fcseermdaesenia_e_tv_ufre"

    const/4 v4, 0x4

    const-string v1, "eiaso_tncderfuea_vfremepe"

    const-string v1, "device_feature_prefs_name"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v2, "faycrbmeeeresfue__pe_dkv"

    const-string/jumbo v2, "kermde_efepryv__cseaufet"

    const/4 v4, 0x6

    const-string v2, "frspeeudeueeriyta_fkev__"

    const-string v2, "device_feature_prefs_key"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p0, v1, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string p0, "e_i_ceipameeorntlufaef_d"

    const-string p0, "anemod__eaufifervteeci_l"

    const/4 v4, 0x3

    const-string/jumbo p0, "ude_a_vtqieeeefniacf_rml"

    const-string p0, "device_feature_file_name"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, "eesdffrakeey__ctl_evuei"

    const-string v1, "device_feature_file_key"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p0, v1}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v0

    :cond_2
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    new-instance p0, Lcom/alipay/apmobilesecuritysdk/e/f;

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/alipay/apmobilesecuritysdk/e/f;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "imei"

    const-string/jumbo v2, "iiem"

    const/4 v4, 0x1

    const-string v2, "eiim"

    const-string/jumbo v2, "imei"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0, v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->a(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "miis"

    const-string/jumbo v2, "iims"

    const-string/jumbo v2, "ismi"

    const-string/jumbo v2, "imsi"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->b(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "mca"

    const-string/jumbo v2, "mac"

    const/4 v4, 0x6

    const-string/jumbo v2, "mac"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->c(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v2, "ecombhbmtalu"

    const-string v2, "bouclbhmetao"

    const/4 v4, 0x5

    const-string v2, "aecbotoholut"

    const-string v2, "bluetoothmac"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->d(Ljava/lang/String;)V

    const/4 v4, 0x5

    const-string v2, "gsi"

    const-string/jumbo v2, "sgi"

    const/4 v4, 0x7

    const-string/jumbo v2, "isg"

    const-string v2, "gsi"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v1}, Lcom/alipay/apmobilesecuritysdk/e/f;->e(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0
.end method
