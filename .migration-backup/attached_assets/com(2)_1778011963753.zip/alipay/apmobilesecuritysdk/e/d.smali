.class public final Lcom/alipay/apmobilesecuritysdk/e/d;
.super Ljava/lang/Object;


# direct methods
.method private static a(Ljava/lang/String;)Lcom/alipay/apmobilesecuritysdk/e/c;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "sKsM~~@@@@~~@~@tu@@l~-~ ~/ Si @@@iy cf4 @o@ ~@of~o1v~@~ ~@i~@r~o ~~  ~/ m .~ bad~~ tbon@  @ @l~b"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v9, 0x3

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-nez v1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance v1, Lorg/json/JSONObject;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance p0, Lcom/alipay/apmobilesecuritysdk/e/c;

    const/4 v9, 0x1

    const-string v2, "dsdmp"

    const-string/jumbo v2, "idspd"

    const/4 v9, 0x7

    const-string/jumbo v2, "pdado"

    const-string v2, "apdid"

    const/4 v9, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const-string v2, "hcHidbvsnaeIof"

    const-string v2, "deviceInfoHash"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string/jumbo v2, "mmeaimuts"

    const-string/jumbo v2, "saimptemm"

    const/4 v9, 0x7

    const-string/jumbo v2, "itmpsaept"

    const-string/jumbo v2, "timestamp"

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string v2, "dti"

    const/4 v9, 0x3

    const-string/jumbo v2, "tdi"

    const-string/jumbo v2, "tid"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v2, "udtqd"

    const-string/jumbo v2, "tdudo"

    const/4 v9, 0x0

    const-string/jumbo v2, "utdid"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct/range {v2 .. v7}, Lcom/alipay/apmobilesecuritysdk/e/c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    return-object v0
.end method

.method public static declared-synchronized a()V
    .locals 3

    const/4 v2, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v2, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    monitor-enter v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v5, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v1, "_vskp_edfesvio4rlb"

    const-string v1, "do_ivbfypkles4ve_r"

    const/4 v5, 0x0

    const-string/jumbo v1, "ovimds_pyivflker4e"

    const-string/jumbo v1, "vkeyid_profiles_v4"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "d_ecoyk_ee4vuvd"

    const-string v2, "_yiedcu4_ekdvve"

    const/4 v5, 0x2

    const-string/jumbo v2, "key_deviceid_v4"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x3

    const-string v3, ""

    const-string v3, ""

    invoke-static {p0, v1, v2, v3}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p0, "s4awpb_xxc"

    const-string/jumbo p0, "sa4vxc_pwx"

    const/4 v5, 0x2

    const-string/jumbo p0, "xa_wx4ucvs"

    const-string/jumbo p0, "wxcasxx_v4"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "k4xqxxwpvec_ya"

    const-string/jumbo v1, "xxcaxwe_qk4vsy"

    const/4 v5, 0x6

    const-string v1, "4c_vkexwqxys_x"

    const-string/jumbo v1, "key_wxcasxx_v4"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, ""

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p0, v1, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v4, 0x7

    move v5, v4

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;Lcom/alipay/apmobilesecuritysdk/e/c;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "pisdd"

    const-string/jumbo v2, "idspd"

    const/4 v5, 0x3

    const-string v2, "didma"

    const-string v2, "apdid"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const-string v2, "evIioeHoasfmnh"

    const-string v2, "HncmioeIaehvsf"

    const/4 v5, 0x4

    const-string/jumbo v2, "iednfbcoesHIah"

    const-string v2, "deviceInfoHash"

    const/4 v4, 0x6

    and-int/2addr v5, v4

    iget-object v3, p1, Lcom/alipay/apmobilesecuritysdk/e/c;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const-string v2, "aimmeputt"

    const-string/jumbo v2, "timestamp"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/alipay/apmobilesecuritysdk/e/c;->c:Ljava/lang/String;

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v2, "tdi"

    const-string v2, "dit"

    const/4 v5, 0x4

    const-string/jumbo v2, "tid"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v3, p1, Lcom/alipay/apmobilesecuritysdk/e/c;->d:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, "dtpuo"

    const-string/jumbo v2, "utdio"

    const/4 v5, 0x2

    const-string v2, "duiqt"

    const-string/jumbo v2, "utdid"

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    iget-object p1, p1, Lcom/alipay/apmobilesecuritysdk/e/c;->e:Ljava/lang/String;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, "4ss_viyorl_kvfdbpe"

    const-string/jumbo v1, "v_e_pbkov4slderfyi"

    const/4 v5, 0x5

    const-string/jumbo v1, "iefmro4vksveyd_pi_"

    const-string/jumbo v1, "vkeyid_profiles_v4"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "id_eo_cekidyuv4"

    const-string/jumbo v2, "vid4keuvc_ey_di"

    const/4 v5, 0x1

    const-string v2, "ecvkebeidiv_4d_"

    const-string/jumbo v2, "key_deviceid_v4"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0, v1, v2, p1}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo p0, "w4xacxu_ps"

    const-string p0, "4sxvc_apxw"

    const-string p0, "cs4xaxwpx_"

    const-string/jumbo p0, "wxcasxx_v4"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo v1, "vwa_xx_eqxcy4s"

    const/4 v5, 0x2

    const-string/jumbo v1, "xx_we_4cqxkysv"

    const-string/jumbo v1, "key_wxcasxx_v4"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0, v1, p1}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    throw p0
.end method

.method public static declared-synchronized b()Lcom/alipay/apmobilesecuritysdk/e/c;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "xwss_ac4vx"

    const/4 v4, 0x6

    const-string/jumbo v1, "xvsascw_xx"

    const-string/jumbo v1, "wxcasxx_v4"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v2, "c4ymx_ksvx_eaw"

    const-string/jumbo v2, "key_wxcasxx_v4"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x5

    return-object v0

    :cond_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/d;->a(Ljava/lang/String;)Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    throw v1
.end method

.method public static declared-synchronized b(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/c;
    .locals 5

    const/4 v4, 0x7

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v1, "si_lodyvo_4freeikp"

    const-string/jumbo v1, "vkeyid_profiles_v4"

    const/4 v4, 0x4

    const-string v2, "cmiddbey_k_vvee"

    const-string/jumbo v2, "veime_vykcedd_4"

    const/4 v4, 0x4

    const-string v2, "deieyeucvdi_v4k"

    const-string/jumbo v2, "key_deviceid_v4"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p0, v1, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo p0, "soxca4xpvx"

    const-string p0, "a_4xoxcsvx"

    const/4 v4, 0x2

    const-string/jumbo p0, "xsaxw_xcqv"

    const-string/jumbo p0, "wxcasxx_v4"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "wcs__akby4sxvx"

    const-string v1, "4acxkbywvsx__x"

    const/4 v4, 0x7

    const-string/jumbo v1, "sxcmkew4xax_vy"

    const-string/jumbo v1, "key_wxcasxx_v4"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0, v1}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_0
    const/4 v4, 0x2

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/d;->a(Ljava/lang/String;)Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw p0
.end method

.method public static declared-synchronized c(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/c;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/e/d;

    const/4 v4, 0x5

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "_kueooe4fivpdrviy_"

    const-string v1, "_iese4uovvrpkfi_yd"

    const/4 v4, 0x3

    const-string/jumbo v1, "li4f_by_vokrisveep"

    const-string/jumbo v1, "vkeyid_profiles_v4"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v2, "piv_veu_c4ekddi"

    const-string v2, "dikd4_ip_veeecv"

    const/4 v4, 0x0

    const-string v2, "edivi__pyce4kde"

    const-string/jumbo v2, "key_deviceid_v4"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0, v1, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p0

    :cond_0
    :try_start_1
    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/d;->a(Ljava/lang/String;)Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p0
.end method
