.class public final Lcom/alipay/apmobilesecuritysdk/e/c;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    iput-object p4, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->d:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p5, p0, Lcom/alipay/apmobilesecuritysdk/e/c;->e:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method
