.class Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/Map;

.field final synthetic b:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;

.field final synthetic c:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;


# direct methods
.method constructor <init>(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;Ljava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->c:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->a:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->b:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/@so ~b.v@@~@ditf~~s@~oi  ~M@l~~@f @ooa ~@@r~ ~n~@~@m~ l@@@ b-  ~@~@b 4c ~~1o @@oSK ~/ty~u~ @~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/a/a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->c:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->a(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;)Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->a:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Ljava/util/Map;)I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->b:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;->c:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v3, 0x2

    invoke-virtual {v1}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->getTokenResult()Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;->onResult(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;)V

    :cond_0
    const/4 v3, 0x2

    return-void
.end method
