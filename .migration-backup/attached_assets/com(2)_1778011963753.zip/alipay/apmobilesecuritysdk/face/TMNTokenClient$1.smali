.class Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/Map;

.field final synthetic b:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;


# direct methods
.method constructor <init>(Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;Ljava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->d:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->a:Ljava/util/Map;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->b:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p4, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " 1s~o ic ~f@K @~tu@~o @ ~o~i@@~t ~v~~omb@~4@l~~y ~@.n@@/-Mf/~~@or  ~ o~ ~@bd @sialS@@ @@b@~@ ~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/a/a;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->d:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a(Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;)Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->a:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Ljava/util/Map;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->b:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->d:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a(Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;)Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;->b:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v1, v0, v2}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;->onResult(Ljava/lang/String;I)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v1, v2, v0}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;->onResult(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method
