.class public Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;,
        Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;
    }
.end annotation


# static fields
.field private static a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

.field private static c:Ljava/lang/Object;


# instance fields
.field private b:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->c:Ljava/lang/Object;

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@@1 ~@ @   ~ o@~~~@~b@Mt/o~~-y@@oS ~@f~ u@sb~.~i rnd @~i ~/oi@@ @lc~~@ ~o a~fbl @~ m~ ~@@oKvt"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public static getInstance(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->c:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v1, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v3, 0x7

    return-object p0
.end method

.method public static getUtdid(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/otherid/UtdidWrapper;->getUtdid(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method


# virtual methods
.method public getApdidToken()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v5, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    move v5, v4

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    move v4, v2

    move v4, v2

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x6

    move v4, v3

    move v4, v3

    const/4 v5, 0x5

    invoke-virtual {p0, v3, v1, v2}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->initToken(ILjava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v0
.end method

.method public getSdkName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string v0, "AKLmiDPYDSPecrPSAsI-SAty"

    const-string v0, "PrsStL-iIDKASPAPecKASYyD"

    const/4 v2, 0x7

    const-string v0, "SSAroADLKK-DuAPecIPyPSti"

    const-string v0, "APPSecuritySDK-ALIPAYSDK"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSdkVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const-string v0, "1920mb3.611.064910"

    const-string v0, "639m6402.00911..11"

    const/4 v2, 0x3

    const-string v0, ".6.2.1u16130390109"

    const-string v0, "3.4.0.201910161639"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public declared-synchronized getTokenResult()Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;
    .locals 6

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v0, p0}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;-><init>(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x4

    invoke-static {v1, v2}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->apdidToken:Ljava/lang/String;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/h;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->clientKey:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->apdid:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/otherid/UmidSdkWrapper;->getSecurityToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->umidToken:Ljava/lang/String;

    iget-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->apdid:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->apdidToken:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, v0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->clientKey:Ljava/lang/String;

    const/4 v5, 0x2

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, v3, v1, v2}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->initToken(ILjava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_1
    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object v0

    :catchall_1
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    monitor-exit p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw v0
.end method

.method public initToken(ILjava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;",
            ")V"
        }
    .end annotation

    const/4 v7, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/b/a;->a()Lcom/alipay/apmobilesecuritysdk/b/a;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, p1}, Lcom/alipay/apmobilesecuritysdk/b/a;->a(I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/e/h;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/b/a;->a()Lcom/alipay/apmobilesecuritysdk/b/a;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/alipay/apmobilesecuritysdk/b/a;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p1, v0}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez v1, :cond_0

    const/4 v6, 0x4

    move v7, v6

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/a;->a(Landroid/content/Context;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/d;->a(Landroid/content/Context;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/g;->a(Landroid/content/Context;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->h()V

    :cond_0
    const/4 v7, 0x5

    invoke-static {p1, v0}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {p1, v0}, Lcom/alipay/apmobilesecuritysdk/e/h;->c(Landroid/content/Context;Ljava/lang/String;)V

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x5

    const-string p1, "ddpot"

    const-string/jumbo p1, "tiddo"

    const-string/jumbo p1, "idtqd"

    const-string/jumbo p1, "utdid"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x4

    const-string v0, ""

    const/4 v7, 0x7

    invoke-static {p2, p1, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v2, "itd"

    const-string/jumbo v2, "itd"

    const-string/jumbo v2, "tid"

    const-string/jumbo v2, "tid"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p2, v2, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const-string v4, "Idusrb"

    const/4 v7, 0x5

    const-string/jumbo v4, "sdsuer"

    const-string/jumbo v4, "userId"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {p2, v4, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v5, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->b:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/otherid/UtdidWrapper;->getUtdid(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance v5, Ljava/util/HashMap;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-interface {v5, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-interface {v5, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v5, v4, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo p1, "mpumaeN"

    const-string p1, "Npeaamu"

    const/4 v7, 0x4

    const-string p1, "appName"

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-interface {v5, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string p1, "apiponeptKeC"

    const-string p1, "KyntpaipepCe"

    const/4 v7, 0x4

    const-string/jumbo p1, "tpKlnbeyaCip"

    const-string p1, "appKeyClient"

    const/4 v7, 0x2

    invoke-interface {v5, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string p1, "hqclneunaa"

    const-string p1, "cnanepalqh"

    const/4 v7, 0x4

    const-string/jumbo p1, "pclaenppan"

    const-string p1, "appchannel"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v5, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string p1, "cVrsrisnqe"

    const-string/jumbo p1, "rVsricpsen"

    const/4 v7, 0x1

    const-string/jumbo p1, "rpcVersion"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string p2, "8"

    const-string p2, "8"

    const/4 v7, 0x5

    const-string p2, "8"

    const-string p2, "8"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v5, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/f/b;->a()Lcom/alipay/apmobilesecuritysdk/f/b;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p2, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {p2, p0, v5, p3}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$1;-><init>(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;Ljava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p1, p2}, Lcom/alipay/apmobilesecuritysdk/f/b;->a(Ljava/lang/Runnable;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method
