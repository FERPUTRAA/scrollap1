.class public Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;
    }
.end annotation


# static fields
.field private static a:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;


# instance fields
.field private b:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->b:Landroid/content/Context;

    const/4 v1, 0x5

    move v2, v1

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "itseoruoenCMoaneTz crikitNals l o. n:xTilltni tsiinen"

    const-string/jumbo v0, "tlsi enoikltionaN iscltarrzi:onln ieeenTiTounCMx  .tt"

    const/4 v2, 0x6

    const-string v0, "Te mlnru iensotiTMtCczoil eat.:nt Nilnlneoir tixnakir"

    const-string v0, "TMNTokenClient initialization error: context is null."

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw p1
.end method

.method static synthetic a(Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->b:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public static getInstance(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    move v3, v2

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    sget-object p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->a:Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0
.end method


# virtual methods
.method public intiToken(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;)V
    .locals 6

    const/4 v5, 0x0

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    if-eqz p4, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {p4, v1, v0}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;->onResult(Ljava/lang/String;I)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p4, :cond_1

    const/4 v4, 0x7

    move v5, v4

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    invoke-interface {p4, v1, v0}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;->onResult(Ljava/lang/String;I)V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;->b:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v2}, Lcom/alipay/apmobilesecuritysdk/otherid/UtdidWrapper;->getUtdid(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v3, "dmido"

    const-string v3, "dudmi"

    const/4 v5, 0x5

    const-string v3, "bdiut"

    const-string/jumbo v3, "utdid"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "itd"

    const-string v2, "dti"

    const/4 v5, 0x1

    const-string v2, "dit"

    const-string/jumbo v2, "tid"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v2, "udIusr"

    const-string/jumbo v2, "udrIos"

    const/4 v5, 0x5

    const-string/jumbo v2, "upsdre"

    const-string/jumbo v2, "userId"

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "bqppmae"

    const-string v1, "eNmapbp"

    const/4 v5, 0x4

    const-string v1, "emspaNa"

    const-string v1, "appName"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v1, "uiympCatenpe"

    const-string/jumbo v1, "pieeCpunylta"

    const/4 v5, 0x5

    const-string v1, "appKeyClient"

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-interface {v0, v1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p2, "hpcnoplapn"

    const-string/jumbo p2, "ncanhplpep"

    const/4 v5, 0x5

    const-string/jumbo p2, "phncpbanea"

    const-string p2, "appchannel"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const-string/jumbo v1, "qaipopu"

    const-string/jumbo v1, "nqoippa"

    const/4 v5, 0x5

    const-string/jumbo v1, "pnpoepi"

    const-string/jumbo v1, "openapi"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v0, p2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string p2, "diseoIssn"

    const/4 v5, 0x4

    const-string p2, "Indsoessq"

    const-string/jumbo p2, "sessionId"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string p2, "Vnsmrocrse"

    const-string/jumbo p2, "irnmsrVoce"

    const/4 v5, 0x4

    const-string/jumbo p2, "neimosprcr"

    const-string/jumbo p2, "rpcVersion"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string p3, "8"

    const-string p3, "8"

    const/4 v5, 0x4

    const-string p3, "8"

    const-string p3, "8"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/f/b;->a()Lcom/alipay/apmobilesecuritysdk/f/b;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance p3, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p3, p0, v0, p4, p1}, Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$1;-><init>(Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient;Ljava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/TMNTokenClient$InitResultListener;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p2, p3}, Lcom/alipay/apmobilesecuritysdk/f/b;->a(Ljava/lang/Runnable;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method
