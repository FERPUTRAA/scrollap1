.class public Lcom/alipay/apmobilesecuritysdk/face/EnvModeConfig;
.super Ljava/lang/Object;


# static fields
.field public static final ENVIRONMENT_AAA:I = 0x4

.field public static final ENVIRONMENT_DAILY:I = 0x1

.field public static final ENVIRONMENT_ONLINE:I = 0x0

.field public static final ENVIRONMENT_PRE:I = 0x2

.field public static final ENVIRONMENT_SIT:I = 0x3


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
