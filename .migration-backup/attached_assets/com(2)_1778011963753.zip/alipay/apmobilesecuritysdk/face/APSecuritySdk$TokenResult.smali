.class public Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "TokenResult"
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

.field public apdid:Ljava/lang/String;

.field public apdidToken:Ljava/lang/String;

.field public clientKey:Ljava/lang/String;

.field public umidToken:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->a:Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method
