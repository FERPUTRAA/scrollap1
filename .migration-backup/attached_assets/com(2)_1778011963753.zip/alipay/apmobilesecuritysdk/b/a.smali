.class public final Lcom/alipay/apmobilesecuritysdk/b/a;
.super Ljava/lang/Object;


# static fields
.field private static b:Lcom/alipay/apmobilesecuritysdk/b/a;


# instance fields
.field private a:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/alipay/apmobilesecuritysdk/b/a;-><init>()V

    const/4 v2, 0x1

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/b/a;->b:Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lcom/alipay/apmobilesecuritysdk/b/a;->a:I

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static a()Lcom/alipay/apmobilesecuritysdk/b/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~soS@4ua@@~@ ~@@~ bod~@bcb@~~if~i @.~o-@~@s~in~f~   o~ ~~ @r@@  @/ @ ~K~t1 mt vM~@@@o~y @/l~o~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/b/a;->b:Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public final a(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/alipay/apmobilesecuritysdk/b/a;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method

.method public final b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/alipay/apmobilesecuritysdk/b/a;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public final c()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/http/d;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/alipay/apmobilesecuritysdk/b/a;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    shl-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x7

    if-eq v0, v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq v0, v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "bc.m/mthmmlwsgo/o.yhieapw.ip:tgsatl"

    const-string/jumbo v0, "olseglbm...tasotpcwmmhgi:yam/hptiw/"

    const/4 v3, 0x3

    const-string/jumbo v0, "pialohcgpayl/moitt/mmw./es:htmo.bg."

    const-string v0, "https://mobilegw.alipay.com/mgw.htm"

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "ptmynbbah.lm/ateaiahw/om/t..g:i.emtlgp"

    const-string/jumbo v0, "meomp.lamnalbaa/tmpwgeyi.ai.hhtgt/t:/."

    const-string/jumbo v0, "oltitguthmaaaabmniw.eal.g.//y.p:e/htmw"

    const-string v0, "http://mobilegw.aaa.alipay.net/mgw.htm"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x7

    const-string/jumbo v0, "p..tghmpm/olypnit1b6oh//4t:.seewgtaea-.tmtiw"

    const-string v0, "an-togltiytmh4//lo.gbtm.:eip1weea.ths.wmt/6p"

    const/4 v3, 0x3

    const-string/jumbo v0, "wel-:p4tqetm/t.ltpsite../ot6iayw-agm.hbm/nh1"

    const-string v0, "http://mobilegw-1-64.test.alipay.net/mgw.htm"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_3
    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v0, "wmsm/tgtetpyaipa/whe.:el/btt..ahslgbob.ln"

    const-string v0, ".bl:tbegh.ameltty..wbsw///honmpmpagitteal"

    const/4 v3, 0x4

    const-string/jumbo v0, "nb.ms.ttwggaae/bmmieht.tmp/.litwlp:a/hoyl"

    const-string v0, "http://mobilegw.stable.alipay.net/mgw.htm"

    const/4 v3, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
