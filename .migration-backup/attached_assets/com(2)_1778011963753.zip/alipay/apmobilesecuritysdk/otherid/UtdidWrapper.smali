.class public Lcom/alipay/apmobilesecuritysdk/otherid/UtdidWrapper;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static getUtdid(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l~ss@~ ~-@v o@on@~@ @~m  f~t@~Mdt~oK~~@~~bS@@  aii~ .i@ @@/~l ~ y@ /b@or ~4uo ~ oc1~@ @b@~@~f~ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-object p0
.end method
