.class public final Lcom/alipay/apmobilesecuritysdk/f/b;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/alipay/apmobilesecuritysdk/f/b;


# instance fields
.field private b:Ljava/lang/Thread;

.field private c:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Ljava/lang/Runnable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/f/b;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/alipay/apmobilesecuritysdk/f/b;-><init>()V

    const/4 v1, 0x7

    or-int/2addr v2, v1

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/f/b;->a:Lcom/alipay/apmobilesecuritysdk/f/b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    shr-int/2addr v1, v0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->b:Ljava/lang/Thread;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Ljava/util/LinkedList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->c:Ljava/util/LinkedList;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public static a()Lcom/alipay/apmobilesecuritysdk/f/b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l@s/@@l~@i ~ a~~@@~1 b@v  4nu@  b@f~ o~cM @@ oto@t~drm@~~ @~@~b~o@o@K  iy~ ~~ f~@~~@Si~s~/-o.  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/alipay/apmobilesecuritysdk/f/b;->a:Lcom/alipay/apmobilesecuritysdk/f/b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method

.method static synthetic a(Lcom/alipay/apmobilesecuritysdk/f/b;)Ljava/util/LinkedList;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->c:Ljava/util/LinkedList;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic b(Lcom/alipay/apmobilesecuritysdk/f/b;)Ljava/lang/Thread;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->b:Ljava/lang/Thread;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/lang/Runnable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->c:Ljava/util/LinkedList;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->b:Ljava/lang/Thread;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/Thread;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/f/c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/alipay/apmobilesecuritysdk/f/c;-><init>(Lcom/alipay/apmobilesecuritysdk/f/b;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/f/b;->b:Ljava/lang/Thread;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw p1
.end method
