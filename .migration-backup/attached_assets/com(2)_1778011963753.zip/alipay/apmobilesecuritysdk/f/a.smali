.class public Lcom/alipay/apmobilesecuritysdk/f/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "f1s@ ~@of@@~o@~~n~o~Mt  @b~@~ bc~~  ~ /~~a y ~i@@S-Kdb@o@@mil.  t@~ o@u@~@~~@o@~r  @~v~li ~/@s4 "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p0, :cond_2

    const/4 v3, 0x5

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {p0, p1, p2, v1}, Lb1/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x0

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, p0}, La1/c;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_2
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const/4 v4, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    or-int/2addr v4, v3

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Lb1/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    :try_start_2
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object v2

    :cond_1
    :try_start_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    :try_start_4
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v2

    :cond_2
    :try_start_5
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1, p0}, La1/c;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v2

    :cond_3
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v2

    :catchall_1
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p3}, La1/c;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v1, 0x6

    move v2, v1

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lb1/e;->b(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const/4 v5, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/f/a;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_3

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto/16 :goto_1

    :cond_0
    :try_start_1
    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0}, Lb1/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v2, Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-static {v1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v3, :cond_1

    :try_start_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v2, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    :try_start_3
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v2, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    :cond_1
    :goto_0
    const/4 v5, 0x3

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1, p2}, La1/c;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catchall_0
    :try_start_5
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Lb1/c;->b()Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string p2, "fotmSnemsigCs"

    const-string/jumbo p2, "mgsnCseStif.o"

    const/4 v5, 0x4

    const-string/jumbo p2, "myeCofStno.gi"

    const-string p2, ".SystemConfig"

    const/4 v4, 0x4

    move v5, v4

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    sget-object p2, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {}, Lb1/c;->b()Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    new-instance p1, Ljava/io/File;

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p1, p2, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/io/File;->isFile()Z

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/io/File;->delete()Z
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :catch_1
    :catchall_1
    :cond_2
    :try_start_7
    const/4 v4, 0x5

    move v5, v4

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void

    :cond_3
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x3

    return-void

    :catchall_2
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    throw p0
.end method
