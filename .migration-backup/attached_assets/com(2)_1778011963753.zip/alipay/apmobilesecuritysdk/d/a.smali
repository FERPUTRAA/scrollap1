.class public final Lcom/alipay/apmobilesecuritysdk/d/a;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "ofsds@ o~m~@~~@ ~i /@~o@c~M Kt .~@@ 4btiS@ y /b-@~@f~ @~~~@b~@~~ ~lr~  @@ @u~ao@o o@@l@n 1iv~~~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/a;

    const/4 v5, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/a;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "asempclpan"

    const-string/jumbo v1, "pascnapelh"

    const/4 v5, 0x0

    const-string v1, "ceaaopnlhp"

    const-string v1, "appchannel"

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const-string v2, ""

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1, v1, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, "A1A"

    const-string v2, "AA1"

    const/4 v5, 0x5

    const-string v2, "1AA"

    const-string v2, "AA1"

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "A2A"

    const-string v2, "AA2"

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {}, Lcom/alipay/security/mobile/module/b/a;->a()Lcom/alipay/security/mobile/module/b/a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v1, v2, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string p0, "AA3"

    const-string p0, "A3A"

    const/4 v5, 0x7

    const-string p0, "3AA"

    const-string p0, "AA3"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v2, "PLYSKbAtKA-SiePcDmyISArP"

    const-string v2, "AALmyDSrAKPIiSeSPcDYtKP-"

    const/4 v5, 0x6

    const-string v2, "PPSDrPuAyKKASItceDuS-iYL"

    const-string v2, "APPSecuritySDK-ALIPAYSDK"

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string p0, "AA4"

    const-string p0, "AA4"

    const/4 v5, 0x6

    const-string p0, "A4A"

    const-string p0, "AA4"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "0391360p46o11219.."

    const-string v2, "...3o1004162113969"

    const/4 v5, 0x6

    const-string v2, "1.960021q1..193306"

    const-string v2, "3.4.0.201910161639"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const-string p0, "AA6"

    const/4 v5, 0x3

    const-string p0, "AA6"

    const-string p0, "AA6"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v1, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    throw p0
.end method
