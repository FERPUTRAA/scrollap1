.class public final Lcom/alipay/apmobilesecuritysdk/d/c;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Ljava/util/Map;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->a()Lcom/alipay/security/mobile/module/b/c;

    move-result-object v0

    const/4 v13, 0x7

    new-instance v1, Ljava/util/HashMap;

    const/4 v13, 0x0

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v13, 0x7

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/e;->a(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/f;

    move-result-object v2

    const/4 v13, 0x7

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x2

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x7

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->A(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v13, 0x5

    if-eqz v2, :cond_3

    const/4 v13, 0x6

    invoke-static {v3}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v7

    const/4 v13, 0x5

    if-eqz v7, :cond_0

    const/4 v13, 0x1

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->a()Ljava/lang/String;

    move-result-object v3

    :cond_0
    const/4 v13, 0x7

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v7

    const/4 v13, 0x3

    if-eqz v7, :cond_1

    const/4 v13, 0x0

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->b()Ljava/lang/String;

    move-result-object v4

    :cond_1
    const/4 v13, 0x4

    invoke-static {v5}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v7

    const/4 v13, 0x2

    if-eqz v7, :cond_2

    const/4 v13, 0x0

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->c()Ljava/lang/String;

    move-result-object v5

    :cond_2
    const/4 v13, 0x7

    invoke-static {v6}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v7

    const/4 v13, 0x6

    if-eqz v7, :cond_3

    const/4 v13, 0x2

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->e()Ljava/lang/String;

    move-result-object v6

    :cond_3
    const/4 v13, 0x6

    new-instance v2, Lcom/alipay/apmobilesecuritysdk/e/f;

    const/4 v13, 0x4

    const-string v11, ""

    const-string v11, ""

    const-string v11, ""

    const-string v11, ""

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v8, v3

    move-object v8, v3

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v12, v6

    move-object v12, v6

    move-object v12, v6

    const/4 v13, 0x3

    invoke-direct/range {v7 .. v12}, Lcom/alipay/apmobilesecuritysdk/e/f;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x3

    if-eqz p0, :cond_4

    :try_start_0
    const/4 v13, 0x4

    new-instance v7, Lorg/json/JSONObject;

    const/4 v13, 0x6

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const-string/jumbo v8, "imie"

    const-string/jumbo v8, "iemi"

    const-string v8, "eiim"

    const-string/jumbo v8, "imei"

    const/4 v13, 0x7

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->a()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x0

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v13, 0x4

    const-string/jumbo v8, "isim"

    const-string/jumbo v8, "ismi"

    const-string/jumbo v8, "simi"

    const-string/jumbo v8, "imsi"

    const/4 v13, 0x3

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->b()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x4

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "acm"

    const-string/jumbo v8, "mac"

    const-string/jumbo v8, "mca"

    const-string/jumbo v8, "mac"

    const/4 v13, 0x6

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->c()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x7

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v13, 0x4

    const-string/jumbo v8, "meslhabtoous"

    const-string/jumbo v8, "ocslbmeoutha"

    const-string v8, "alombomhettu"

    const-string v8, "bluetoothmac"

    const/4 v13, 0x5

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->d()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x0

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string/jumbo v8, "sig"

    const-string v8, "gsi"

    const-string/jumbo v8, "isg"

    const-string v8, "gsi"

    const/4 v13, 0x1

    invoke-virtual {v2}, Lcom/alipay/apmobilesecuritysdk/e/f;->e()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-virtual {v7, v8, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v13, 0x7

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    const-string/jumbo v7, "l_meocrtemediavufineea_f"

    const-string v7, "eifmiv_mraecdenatefe_ule"

    const-string/jumbo v7, "i_uldbe_aircnaefvef_eeet"

    const-string v7, "device_feature_file_name"

    const/4 v13, 0x4

    const-string/jumbo v8, "le_reeuveioetafydefk__i"

    const-string v8, "eya_oee_cikfdeei_lverft"

    const-string v8, "ckvu_fep_atferiieely_ed"

    const-string v8, "device_feature_file_key"

    const/4 v13, 0x4

    invoke-static {v7, v8, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x0

    const-string v7, "_mrnvaeequeedtb_eirpefc_a"

    const-string v7, "aem_abfep_ifvre_teeedurcn"

    const-string v7, "a_sferp_tuevenmesfadeec_i"

    const-string v7, "device_feature_prefs_name"

    const/4 v13, 0x5

    const-string/jumbo v8, "prdmveftu_yi_u_kcraeesee"

    const-string/jumbo v8, "sieeeeu_akeudprvect_fyr_"

    const-string/jumbo v8, "si_foy_etkueeefrcverpead"

    const-string v8, "device_feature_prefs_key"

    invoke-static {p0, v7, v8, v2}, Lcom/alipay/apmobilesecuritysdk/f/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v13, 0x5

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v13, 0x6

    invoke-static {v2}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V

    :cond_4
    :goto_0
    const-string v2, "AD1"

    const-string v2, "1DA"

    const-string v2, "1DA"

    const-string v2, "AD1"

    const/4 v13, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    const-string v2, "2DA"

    const-string v2, "D2A"

    const-string v2, "DA2"

    const-string v2, "AD2"

    const/4 v13, 0x2

    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x7

    const-string v2, "A3D"

    const-string v2, "3AD"

    const-string v2, "D3A"

    const-string v2, "AD3"

    const/4 v13, 0x5

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->m(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x0

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x4

    const-string v2, "A5D"

    const-string v2, "DA5"

    const-string v2, "DA5"

    const-string v2, "AD5"

    const/4 v13, 0x1

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->q(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x2

    const-string v2, "6AD"

    const-string v2, "6AD"

    const-string v2, "AD6"

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->s(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "D7A"

    const-string v2, "AD7"

    const-string v2, "AD7"

    const-string v2, "AD7"

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->u(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "DA8"

    const-string v2, "AD8"

    const-string v2, "8AD"

    const-string v2, "AD8"

    const/4 v13, 0x6

    invoke-interface {v1, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "9AD"

    const-string v2, "AD9"

    const-string v2, "DA9"

    const-string v2, "AD9"

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->y(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v2, "1DA0"

    const-string v2, "01DA"

    const-string v2, "10AD"

    const-string v2, "AD10"

    const/4 v13, 0x3

    invoke-interface {v1, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v2, "1DA1"

    const-string v2, "AD11"

    const-string v2, "1DA1"

    const-string v2, "AD11"

    const/4 v13, 0x6

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->h()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x6

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v2, "21DA"

    const-string v2, "DA21"

    const-string v2, "A21D"

    const-string v2, "AD12"

    const/4 v13, 0x6

    invoke-virtual {v0}, Lcom/alipay/security/mobile/module/b/c;->j()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "31AD"

    const-string v0, "D13A"

    const-string v0, "1A3D"

    const-string v0, "AD13"

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->l()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x2

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x4

    const-string v0, "D41A"

    const-string v0, "AD14"

    const/4 v13, 0x6

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->p()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "5AD1"

    const-string v0, "15AD"

    const-string v0, "AD15"

    const/4 v13, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    const-string v0, "1D6A"

    const-string v0, "1D6A"

    const-string v0, "A6D1"

    const-string v0, "AD16"

    const/4 v13, 0x4

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->t()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "71AD"

    const-string v0, "D7A1"

    const-string v0, "7A1D"

    const-string v0, "AD17"

    const/4 v13, 0x0

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const/4 v13, 0x7

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "1D9A"

    const-string v0, "A9D1"

    const-string v0, "A91D"

    const-string v0, "AD19"

    const/4 v13, 0x4

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->C(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x7

    invoke-interface {v1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x2

    const-string v0, "2A0D"

    const-string v0, "2AD0"

    const-string v0, "2A0D"

    const-string v0, "AD20"

    const/4 v13, 0x6

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->v()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x0

    invoke-interface {v1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x4

    const-string v0, "D22A"

    const-string v0, "2DA2"

    const-string v0, "2DA2"

    const-string v0, "AD22"

    const/4 v13, 0x2

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v0, "3AD2"

    const-string v0, "D23A"

    const-string v0, "2DA3"

    const-string v0, "AD23"

    const/4 v13, 0x5

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->G(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x3

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->o(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    invoke-static {v0}, Lz0/a;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x7

    const-string v2, "AD24"

    const-string v2, "A2D4"

    const-string v2, "DA24"

    const-string v2, "AD24"

    const/4 v13, 0x7

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    const-string v0, "6D2A"

    const-string v0, "6D2A"

    const-string v0, "AD26"

    const/4 v13, 0x4

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x0

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "AD72"

    const-string v0, "7AD2"

    const-string v0, "2AD7"

    const-string v0, "AD27"

    const/4 v13, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->F()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x6

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x5

    const-string v0, "A8D2"

    const-string v0, "DA28"

    const-string v0, "D28A"

    const-string v0, "AD28"

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->J()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x3

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x5

    const-string v0, "DA29"

    const-string v0, "AD92"

    const-string v0, "29AD"

    const-string v0, "AD29"

    const/4 v13, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->N()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x6

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "D30A"

    const-string v0, "DA03"

    const-string v0, "0DA3"

    const-string v0, "AD30"

    const/4 v13, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->H()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x5

    const-string v0, "1D3A"

    const-string v0, "1AD3"

    const-string v0, "A3D1"

    const-string v0, "AD31"

    const/4 v13, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->L()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v0, "2A3D"

    const-string v0, "32AD"

    const-string v0, "A23D"

    const-string v0, "AD32"

    const/4 v13, 0x0

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->B()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x0

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x2

    const-string v0, "33DA"

    const-string v0, "33AD"

    const-string v0, "A3D3"

    const-string v0, "AD33"

    const/4 v13, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->D()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    const-string v0, "4D3A"

    const-string v0, "AD34"

    const/4 v13, 0x5

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->K(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x0

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "5AD3"

    const-string v0, "D5A3"

    const-string v0, "A35D"

    const-string v0, "AD35"

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->M(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v0, "6D3A"

    const-string v0, "A6D3"

    const-string v0, "D63A"

    const-string v0, "AD36"

    const/4 v13, 0x2

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->I(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v0, "D37A"

    const-string v0, "DA37"

    const-string v0, "D7A3"

    const-string v0, "AD37"

    const/4 v13, 0x0

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->z()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x1

    const-string v0, "A3D8"

    const-string v0, "A8D3"

    const-string v0, "D3A8"

    const-string v0, "AD38"

    const/4 v13, 0x5

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->x()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "D93A"

    const-string v0, "39AD"

    const-string v0, "AD39"

    const/4 v13, 0x4

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x1

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    const-string v0, "A04D"

    const-string v0, "AD40"

    const/4 v13, 0x3

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->i(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "AD41"

    const-string v0, "1AD4"

    const-string v0, "A41D"

    const-string v0, "AD41"

    const/4 v13, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "D24A"

    const-string v0, "2DA4"

    const-string v0, "D2A4"

    const-string v0, "AD42"

    const/4 v13, 0x6

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->f()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const-string v0, "AL3"

    const-string v0, "LA3"

    const-string v0, "A3L"

    const-string v0, "AL3"

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x0

    invoke-interface {v1, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1
.end method
