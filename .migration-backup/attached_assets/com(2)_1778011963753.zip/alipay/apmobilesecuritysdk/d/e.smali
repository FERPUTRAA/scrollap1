.class public final Lcom/alipay/apmobilesecuritysdk/d/e;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final b:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 44

    const-string v0, "A1D"

    const-string v0, "1DA"

    const-string v0, "AD1"

    const-string v0, "AD1"

    const-string v1, "A2D"

    const-string v1, "AD2"

    const-string v1, "AD2"

    const-string v2, "3DA"

    const-string v2, "3DA"

    const-string v2, "AD3"

    const-string v3, "AD8"

    const-string v3, "8DA"

    const-string v3, "DA8"

    const-string v3, "AD8"

    const-string v4, "D9A"

    const-string v4, "DA9"

    const-string v4, "D9A"

    const-string v4, "AD9"

    const-string v5, "1A0D"

    const-string v5, "01DA"

    const-string v5, "1AD0"

    const-string v5, "AD10"

    const-string v6, "1A1D"

    const-string v6, "A11D"

    const-string v6, "D11A"

    const-string v6, "AD11"

    const-string v7, "D2A1"

    const-string v7, "D1A2"

    const-string v7, "2AD1"

    const-string v7, "AD12"

    const-string v8, "4DA1"

    const-string v8, "A41D"

    const-string v8, "1AD4"

    const-string v8, "AD14"

    const-string v9, "1DA5"

    const-string v9, "51DA"

    const-string v9, "AD15"

    const-string v10, "1DA6"

    const-string v10, "AD16"

    const-string v11, "8DA1"

    const-string v11, "D81A"

    const-string v11, "AD18"

    const-string v11, "AD18"

    const-string v12, "A20D"

    const-string v12, "0DA2"

    const-string v12, "2DA0"

    const-string v12, "AD20"

    const-string v13, "A12D"

    const-string v13, "1AD2"

    const-string v13, "2DA1"

    const-string v13, "AD21"

    const-string v14, "A2D3"

    const-string v14, "2A3D"

    const-string v14, "D2A3"

    const-string v14, "AD23"

    const-string v15, "A24D"

    const-string v15, "4A2D"

    const-string v15, "4D2A"

    const-string v15, "AD24"

    const-string v16, "A62D"

    const-string v16, "6D2A"

    const-string v16, "A6D2"

    const-string v16, "AD26"

    const-string v17, "72DA"

    const-string v17, "AD72"

    const-string v17, "D7A2"

    const-string v17, "AD27"

    const-string v18, "82DA"

    const-string v18, "AD28"

    const-string v18, "A8D2"

    const-string v18, "AD28"

    const-string v19, "9DA2"

    const-string v19, "A92D"

    const-string v19, "9D2A"

    const-string v19, "AD29"

    const-string v20, "A30D"

    const-string v20, "DA30"

    const-string v20, "3AD0"

    const-string v20, "AD30"

    const-string v21, "DA31"

    const-string v21, "3D1A"

    const-string v21, "1DA3"

    const-string v21, "AD31"

    const-string v22, "AD34"

    const-string v22, "DA34"

    const-string v22, "3A4D"

    const-string v22, "AD34"

    const-string v23, "AA1"

    const-string v23, "AA1"

    const-string v23, "AA1"

    const-string v23, "AA1"

    const-string v24, "A2A"

    const-string v24, "A2A"

    const-string v24, "2AA"

    const-string v24, "AA2"

    const-string v25, "A3A"

    const-string v25, "3AA"

    const-string v25, "3AA"

    const-string v25, "AA3"

    const-string v26, "AA4"

    const-string v26, "A4A"

    const-string v26, "AA4"

    const-string v26, "AA4"

    const-string v27, "AC4"

    const-string v27, "A4C"

    const-string v27, "C4A"

    const-string v27, "AC4"

    const-string v28, "A1C0"

    const-string v28, "1AC0"

    const-string v28, "0A1C"

    const-string v28, "AC10"

    const-string v29, "1AE"

    const-string v29, "E1A"

    const-string v29, "A1E"

    const-string v29, "AE1"

    const-string v30, "2AE"

    const-string v30, "AE2"

    const-string v30, "AE2"

    const-string v30, "AE2"

    const-string v31, "E3A"

    const-string v31, "3AE"

    const-string v31, "EA3"

    const-string v31, "AE3"

    const-string v32, "4AE"

    const-string v32, "AE4"

    const-string v33, "5EA"

    const-string v33, "A5E"

    const-string v33, "5EA"

    const-string v33, "AE5"

    const-string v34, "E6A"

    const-string v34, "EA6"

    const-string v34, "AE6"

    const-string v35, "A7E"

    const-string v35, "7EA"

    const-string v35, "AE7"

    const-string v36, "A8E"

    const-string v36, "EA8"

    const-string v36, "AE8"

    const-string v36, "AE8"

    const-string v37, "E9A"

    const-string v37, "AE9"

    const-string v37, "EA9"

    const-string v37, "AE9"

    const-string v38, "01EA"

    const-string v38, "01EA"

    const-string v38, "A0E1"

    const-string v38, "AE10"

    const-string v39, "1AE1"

    const-string v39, "A1E1"

    const-string v39, "A11E"

    const-string v39, "AE11"

    const-string v40, "1EA2"

    const-string v40, "E12A"

    const-string v40, "A2E1"

    const-string v40, "AE12"

    const-string v41, "1EA3"

    const-string v41, "EA31"

    const-string v41, "AE13"

    const-string v42, "4AE1"

    const-string v42, "41AE"

    const-string v42, "A1E4"

    const-string v42, "AE14"

    const-string v43, "A15E"

    const-string v43, "E15A"

    const-string v43, "EA15"

    const-string v43, "AE15"

    filled-new-array/range {v0 .. v43}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/alipay/apmobilesecuritysdk/d/e;->b:[Ljava/lang/String;

    return-void
.end method

.method private static a(Ljava/util/Map;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-ge v2, v3, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {p0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    check-cast v4, Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v5, ""

    const-string v5, ""

    const/4 v8, 0x6

    const-string v5, ""

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-nez v4, :cond_0

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move v8, v7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-nez v2, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v5, "&"

    const-string v5, "&"

    const/4 v8, 0x5

    const-string v5, "&"

    const-string v5, "&"

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v3, "="

    const-string v3, "="

    const/4 v8, 0x4

    const-string v3, "="

    const-string v3, "="

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v7, 0x1

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    return-object p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/d/e;->c(Landroid/content/Context;Ljava/util/Map;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object p0, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/d/d;->a()Ljava/util/Map;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object p0, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    throw p0
.end method

.method public static declared-synchronized a()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-enter v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw v1
.end method

.method public static declared-synchronized b(Landroid/content/Context;Ljava/util/Map;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v6, 0x2

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/d/e;->a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance p0, Ljava/util/TreeMap;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {p0}, Ljava/util/TreeMap;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    sget-object p1, Lcom/alipay/apmobilesecuritysdk/d/e;->b:[Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    array-length v1, p1

    const/4 v6, 0x4

    const/4 v2, 0x6

    const/4 v6, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-ge v2, v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    aget-object v3, p1, v2

    const/4 v6, 0x1

    sget-object v4, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-interface {v4, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    sget-object v4, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {p0, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v5, 0x5

    move v6, v5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/d/e;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p0}, La1/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw p0
.end method

.method private static declared-synchronized c(Landroid/content/Context;Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v4, 0x4

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/e;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/util/TreeMap;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/util/TreeMap;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sput-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/d/b;->a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/d/d;->a(Landroid/content/Context;)Ljava/util/Map;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v3, 0x3

    move v4, v3

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/d/c;->a(Landroid/content/Context;)Ljava/util/Map;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v1, Lcom/alipay/apmobilesecuritysdk/d/e;->a:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/d/a;->a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v1, p0}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw p0
.end method
