.class public final Lcom/alipay/apmobilesecuritysdk/d/d;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a()Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~sfo@b~ @il~4 vK ~o@@s @u@ tm~@o/~ ~-dl n/@ @c o~~@i@b@S~ ~~~ o@@@.~o~M~@ ~r@@fyt ab i  @ @1~~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const/4 v5, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v2, "E6A1"

    const-string v2, "AE16"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v3, Lcom/alipay/apmobilesecuritysdk/c/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v3}, Lcom/alipay/apmobilesecuritysdk/c/b;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v1

    :catchall_1
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    throw v1
.end method

.method public static declared-synchronized a(Landroid/content/Context;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const/4 v6, 0x1

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/d;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->a()Lcom/alipay/security/mobile/module/b/e;

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->a()Lcom/alipay/security/mobile/module/b/c;

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v1, Ljava/util/HashMap;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v2, "EA1"

    const-string v2, "1EA"

    const/4 v6, 0x4

    const-string v2, "E1A"

    const-string v2, "AE1"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->d()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v2, "2EA"

    const-string v2, "E2A"

    const/4 v6, 0x6

    const-string v2, "E2A"

    const-string v2, "AE2"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->e()Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    if-eqz v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v4, "1"

    const-string v4, "1"

    const/4 v6, 0x1

    const-string v4, "1"

    const-string v4, "1"

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x1

    const-string v4, "0"

    const-string v4, "0"

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v2, "AE3"

    const-string v2, "AE3"

    const/4 v6, 0x4

    const-string v2, "3AE"

    const-string v2, "AE3"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/e;->c(Landroid/content/Context;)Z

    move-result p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string p0, "1"

    const-string p0, "1"

    const/4 v6, 0x3

    const-string p0, "1"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v1, v2, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const-string p0, "4AE"

    const-string p0, "AE4"

    const/4 v6, 0x1

    const-string p0, "4EA"

    const-string p0, "AE4"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->f()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const-string p0, "5AE"

    const-string p0, "AE5"

    const/4 v6, 0x5

    const-string p0, "5AE"

    const-string p0, "AE5"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->g()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string p0, "AE6"

    const-string p0, "A6E"

    const/4 v6, 0x3

    const-string p0, "AE6"

    const-string p0, "AE6"

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string p0, "EA7"

    const-string p0, "AE7"

    const/4 v6, 0x0

    const-string p0, "A7E"

    const-string p0, "AE7"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->i()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string p0, "EA8"

    const-string p0, "8EA"

    const/4 v6, 0x5

    const-string p0, "EA8"

    const-string p0, "AE8"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->j()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string p0, "EA9"

    const-string p0, "E9A"

    const/4 v6, 0x4

    const-string p0, "AE9"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->k()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string p0, "A1E0"

    const-string p0, "E1A0"

    const/4 v6, 0x1

    const-string p0, "AE10"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->l()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string p0, "EA11"

    const-string p0, "E11A"

    const/4 v6, 0x6

    const-string p0, "11AE"

    const-string p0, "AE11"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->m()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string p0, "21AE"

    const-string p0, "21AE"

    const/4 v6, 0x6

    const-string p0, "AE12"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->n()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string p0, "13AE"

    const-string p0, "3E1A"

    const/4 v6, 0x2

    const-string p0, "AE13"

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->o()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const-string p0, "EA41"

    const-string p0, "1EA4"

    const-string p0, "E41A"

    const-string p0, "AE14"

    const/4 v6, 0x4

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->p()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string p0, "5A1E"

    const-string p0, "5A1E"

    const-string p0, "5E1A"

    const-string p0, "AE15"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {}, Lcom/alipay/security/mobile/module/b/e;->q()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const-string p0, "2A1E"

    const-string p0, "2E1A"

    const/4 v6, 0x1

    const-string p0, "21EA"

    const-string p0, "AE21"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->n()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    throw p0
.end method
