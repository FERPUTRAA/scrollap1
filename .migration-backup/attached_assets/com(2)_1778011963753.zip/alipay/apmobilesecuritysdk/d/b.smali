.class public final Lcom/alipay/apmobilesecuritysdk/d/b;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "-as @v@c~y/o @ u@~~@@@b~@lf~nSf~~t m. t@~r@ i~@   o  s@i/~i ~K4  @@~ o@1 ~oo@@M~bbd~~@@~~ @~o~~l"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x3

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/b;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/b;

    const/4 v11, 0x0

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/b;

    const-class v0, Lcom/alipay/apmobilesecuritysdk/d/b;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-instance v1, Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x6

    const-string/jumbo v2, "tdi"

    const-string/jumbo v2, "tid"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p1, v2, v3}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo v3, "sdumi"

    const-string/jumbo v3, "itsdu"

    const/4 v11, 0x6

    const-string v3, "dtduo"

    const-string/jumbo v3, "utdid"

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v4, ""

    const-string v4, ""

    const/4 v11, 0x1

    const-string v4, ""

    const-string v4, ""

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {p1, v3, v4}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string v4, "Isdmub"

    const-string/jumbo v4, "sdemuI"

    const/4 v11, 0x1

    const-string/jumbo v4, "udeusI"

    const-string/jumbo v4, "userId"

    const/4 v10, 0x2

    move v11, v10

    const-string v5, ""

    const-string v5, ""

    const/4 v11, 0x0

    const-string v5, ""

    const-string v5, ""

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {p1, v4, v5}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string/jumbo v5, "peoaNma"

    const-string v5, "aNepoam"

    const/4 v11, 0x0

    const-string/jumbo v5, "mqaaepp"

    const-string v5, "appName"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v6, ""

    const-string v6, ""

    const/4 v11, 0x6

    const-string v6, ""

    const-string v6, ""

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {p1, v5, v6}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x7

    const-string v6, "epseyClnbpai"

    const-string/jumbo v6, "iyCKebaenlpp"

    const/4 v11, 0x4

    const-string/jumbo v6, "ytKmnelpepai"

    const-string v6, "appKeyClient"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string v7, ""

    const-string v7, ""

    const/4 v11, 0x4

    const-string v7, ""

    const-string v7, ""

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {p1, v6, v7}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string/jumbo v7, "usstodIinexS"

    const-string/jumbo v7, "itensxudsSIm"

    const/4 v11, 0x4

    const-string v7, "dxIitbosmnSs"

    const-string/jumbo v7, "tmxSessionId"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    const-string v8, ""

    const-string v8, ""

    const/4 v11, 0x2

    const-string v8, ""

    const-string v8, ""

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {p1, v7, v8}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/h;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v8, "essndiuIp"

    const-string/jumbo v8, "snedoIips"

    const/4 v11, 0x6

    const-string/jumbo v8, "sesidonpI"

    const-string/jumbo v8, "sessionId"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string v9, ""

    const-string v9, ""

    const/4 v11, 0x4

    const-string v9, ""

    const-string v9, ""

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {p1, v8, v9}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    const-string v8, "1CA"

    const-string v8, "C1A"

    const/4 v11, 0x1

    const-string v8, "CA1"

    const-string v8, "AC1"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-interface {v1, v8, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    move v11, v10

    const-string v2, "2CA"

    const-string v2, "2CA"

    const/4 v11, 0x6

    const-string v2, "2CA"

    const-string v2, "AC2"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const-string v2, "AC3"

    const-string v2, "AC3"

    const/4 v11, 0x4

    const-string v2, "3AC"

    const-string v2, "AC3"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v2, "A4C"

    const-string v2, "4AC"

    const/4 v11, 0x4

    const-string v2, "4CA"

    const-string v2, "AC4"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-interface {v1, v2, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string p0, "AC5"

    const-string p0, "C5A"

    const/4 v11, 0x7

    const-string p0, "A5C"

    const-string p0, "AC5"

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-interface {v1, p0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string p0, "AC6"

    const-string p0, "AC6"

    const-string p0, "6AC"

    const-string p0, "AC6"

    const/4 v11, 0x2

    invoke-interface {v1, p0, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string p0, "A7C"

    const-string p0, "C7A"

    const/4 v11, 0x2

    const-string p0, "7AC"

    const-string p0, "AC7"

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v11, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string p0, "8AC"

    const/4 v11, 0x3

    const-string p0, "A8C"

    const-string p0, "AC8"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-interface {v1, p0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string p0, "9CA"

    const-string p0, "A9C"

    const/4 v11, 0x3

    const-string p0, "CA9"

    const-string p0, "AC9"

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v1, p0, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result p0

    const/4 v11, 0x6

    const/4 v10, 0x0

    if-eqz p0, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const-string p0, "CA01"

    const/4 v11, 0x3

    const-string p0, "0AC1"

    const-string p0, "AC10"

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-interface {v1, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    monitor-exit v0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    monitor-exit v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    throw p0
.end method
