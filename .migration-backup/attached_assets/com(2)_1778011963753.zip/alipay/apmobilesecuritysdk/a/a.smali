.class public final Lcom/alipay/apmobilesecuritysdk/a/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lcom/alipay/apmobilesecuritysdk/b/a;

.field private c:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/b/a;->a()Lcom/alipay/apmobilesecuritysdk/b/a;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->b:Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "S s~@ifo@~b@ lf t@@iKn@/@l@o~~ y@ ~~@~t @ou~~ ~@@4r    ~1co@i/@@ ~@~-~Mv~   b b~~~@oo~~sm a~.@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/a/a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/h;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/a/a;->b()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lcom/alipay/apmobilesecuritysdk/e/g;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {p1, p0}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0

    :catchall_0
    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0
.end method

.method private static a()Z
    .locals 12

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string/jumbo v1, "yys-dHMm sm:d:yHys-"

    const/4 v11, 0x2

    const-string/jumbo v1, "sydmyMHmHd:yy M-s:m"

    const-string/jumbo v1, "yyyy-MM-dd HH:mm:ss"

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string v1, "- 10o71-111-1211007m-"

    const-string v1, "117m-117-11-02020 1-1"

    const-string v1, "70112b70--111-1- 2011"

    const-string v1, "2017-11-10 2017-11-11"

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v2, "-11110u770 2212o-12-1"

    const-string v2, "1210o 21--11017-271-2"

    const/4 v11, 0x6

    const-string v2, "710127-p21112-2 121--"

    const-string v2, "2017-12-11 2017-12-12"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string v3, "7-02 b727121-8-011-02"

    const/4 v11, 0x2

    const-string v3, "-7100272q-1--2101 720"

    const-string v3, "2017-01-27 2017-01-28"

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    filled-new-array {v3, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v2

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const/4 v11, 0x4

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const-wide/high16 v4, 0x4038000000000000L    # 24.0

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    mul-double/2addr v2, v4

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const/4 v11, 0x3

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const-wide/high16 v4, 0x404e000000000000L    # 60.0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    mul-double/2addr v2, v4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    mul-double/2addr v2, v4

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    double-to-int v2, v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v3, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    mul-int/2addr v2, v3

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 v4, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    move v5, v4

    move v5, v4

    const/4 v11, 0x3

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    const/4 v6, 0x3

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-ge v5, v6, :cond_1

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    aget-object v6, v1, v5

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v7, " "

    const-string v7, " "

    const/4 v11, 0x6

    const-string v7, " "

    const-string v7, " "

    const/4 v10, 0x6

    shr-int/2addr v11, v10

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-eqz v6, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    array-length v7, v6

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    const/4 v8, 0x2

    const/4 v11, 0x5

    if-ne v7, v8, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v7, Ljava/util/Date;

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-direct {v7}, Ljava/util/Date;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    aget-object v9, v6, v4

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v9, "0us:000:0"

    const-string v9, "0:0:00u00"

    const/4 v11, 0x7

    const-string v9, "0:0m:0 00"

    const-string v9, " 00:00:00"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v0, v8}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v8

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    aget-object v6, v6, v3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const-string v6, " 55:o:92p"

    const-string v6, "25 :539p:"

    const/4 v11, 0x5

    const-string v6, "599::b35 "

    const-string v6, " 23:59:59"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v0, v6}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v9

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v9, v6}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/16 v6, 0xd

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v9, v6, v2}, Ljava/util/Calendar;->add(II)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v9}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v6

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v7, v8}, Ljava/util/Date;->after(Ljava/util/Date;)Z

    move-result v8

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v8, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v7, v6}, Ljava/util/Date;->before(Ljava/util/Date;)Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-eqz v6, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    return v3

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    goto/16 :goto_0

    :catch_0
    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    return v4
.end method

.method private b(Ljava/util/Map;)Ld1/c;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ld1/c;"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-instance v2, Ld1/d;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {v2}, Ld1/d;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string/jumbo v3, "ppqeNau"

    const-string/jumbo v3, "pqNmaep"

    const/4 v10, 0x6

    const-string/jumbo v3, "paepNam"

    const-string v3, "appName"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {p1, v3, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string/jumbo v4, "osiesnsIq"

    const-string/jumbo v4, "sessionId"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p1, v4, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string/jumbo v5, "nrsVecpois"

    const/4 v10, 0x4

    const-string v5, "erspscoiVr"

    const-string/jumbo v5, "rpcVersion"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p1, v5, v0}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v1, v3}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/otherid/UmidSdkWrapper;->getSecurityToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/h;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v4}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v8

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v8, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-object v4, v2, Ld1/d;->c:Ljava/lang/String;

    const/4 v9, 0x4

    move v10, v9

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    iput-object v3, v2, Ld1/d;->c:Ljava/lang/String;

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    iput-object v6, v2, Ld1/d;->d:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    iput-object v7, v2, Ld1/d;->e:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v3, "rddmiao"

    const-string v3, "drdmoia"

    const/4 v10, 0x1

    const-string v3, "dinooad"

    const-string v3, "android"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput-object v3, v2, Ld1/d;->a:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/d;->c(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x7

    if-eqz v3, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v4, v3, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v9, 0x1

    move v10, v9

    iget-object v3, v3, Lcom/alipay/apmobilesecuritysdk/e/c;->c:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    goto :goto_1

    :cond_1
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-eqz v6, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/a;->c(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/b;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v6, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v4, v6, Lcom/alipay/apmobilesecuritysdk/e/b;->a:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v3, v6, Lcom/alipay/apmobilesecuritysdk/e/b;->c:Ljava/lang/String;

    :cond_2
    const/4 v10, 0x3

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/d;->b()Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object v6

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-eqz v6, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x2

    iget-object v0, v6, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v6, v6, Lcom/alipay/apmobilesecuritysdk/e/c;->c:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    goto :goto_2

    :cond_3
    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-eqz v7, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/a;->b()Lcom/alipay/apmobilesecuritysdk/e/b;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v7, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, v7, Lcom/alipay/apmobilesecuritysdk/e/b;->a:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v6, v7, Lcom/alipay/apmobilesecuritysdk/e/b;->c:Ljava/lang/String;

    :cond_4
    const/4 v9, 0x0

    const/4 v10, 0x1

    iput-object v4, v2, Ld1/d;->h:Ljava/lang/String;

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    iput-object v0, v2, Ld1/d;->g:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    iput-object v5, v2, Ld1/d;->j:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-eqz v5, :cond_5

    const/4 v10, 0x1

    iput-object v0, v2, Ld1/d;->b:Ljava/lang/String;

    const/4 v9, 0x6

    and-int/2addr v10, v9

    iput-object v6, v2, Ld1/d;->i:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_3

    :cond_5
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-object v4, v2, Ld1/d;->b:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x4

    iput-object v3, v2, Ld1/d;->i:Ljava/lang/String;

    :goto_3
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v1, p1}, Lcom/alipay/apmobilesecuritysdk/d/e;->a(Landroid/content/Context;Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-object p1, v2, Ld1/d;->f:Ljava/util/Map;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->b:Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/alipay/apmobilesecuritysdk/b/a;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-static {p1, v0}, Lcom/alipay/security/mobile/module/http/d;->c(Landroid/content/Context;Ljava/lang/String;)Le1/a;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {p1, v2}, Le1/a;->a(Ld1/d;)Ld1/c;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 p1, 0x0

    const/4 v10, 0x6

    return-object p1
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/d;->b(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Lcom/alipay/apmobilesecuritysdk/e/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, v0, Lcom/alipay/apmobilesecuritysdk/e/c;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/a;->b(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/e/b;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Lcom/alipay/apmobilesecuritysdk/e/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p0, p0, Lcom/alipay/apmobilesecuritysdk/e/b;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-static {p0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :catchall_0
    :cond_2
    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p0
.end method

.method private static b()V
    .locals 10

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/4 v0, 0x5

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-array v1, v0, [Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v2, "dealebfm__vfe_iuaeeetinr"

    const-string v2, "device_feature_file_name"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x1

    aput-object v2, v1, v3

    const/4 v8, 0x2

    and-int/2addr v9, v8

    const-string v2, "eo_stiuwellt"

    const-string v2, "esalowt_lite"

    const/4 v9, 0x3

    const-string/jumbo v2, "lmtwe_lpiset"

    const-string/jumbo v2, "wallet_times"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v4, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    aput-object v2, v1, v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string/jumbo v2, "sxx3c_awqv"

    const-string/jumbo v2, "wxcasxx_v3"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v4, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    aput-object v2, v1, v4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const-string/jumbo v2, "s_sb4xxaxw"

    const-string/jumbo v2, "xvxwabs4_x"

    const/4 v9, 0x0

    const-string/jumbo v2, "x_4mxvwasx"

    const-string/jumbo v2, "wxcasxx_v4"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v4, 0x3

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    aput-object v2, v1, v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v2, "yz1yo_vux"

    const-string v2, "1xyyw_uvz"

    const/4 v9, 0x7

    const-string/jumbo v2, "wyyx_bz1x"

    const-string/jumbo v2, "wxxzyy_v1"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v4, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    aput-object v2, v1, v4

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-ge v3, v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    aget-object v2, v1, v3

    const/4 v9, 0x2

    const/4 v8, 0x1

    new-instance v4, Ljava/io/File;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string v7, "e/Spnousmgtf.C"

    const-string v7, "fCin.mgpotesS/"

    const/4 v9, 0x6

    const-string v7, ".fSmytnpesoC/i"

    const-string v7, ".SystemConfig/"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v4, v5, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/io/File;->canWrite()Z

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v2, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_0

    :catchall_0
    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Map;)I
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)I"
        }
    .end annotation

    const/4 v10, 0x1

    const-string v0, "dtuqd"

    const-string/jumbo v0, "utdid"

    const/4 v9, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string/jumbo v1, "tdi"

    const-string v1, "dti"

    const/4 v10, 0x4

    const-string/jumbo v1, "tid"

    const-string/jumbo v1, "tid"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const-string v2, ""

    const-string v2, ""

    :try_start_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v3, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x0

    invoke-static {p1, v1, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {p1, v0, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v6, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v6}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v3, v4, v5, v6}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    move v10, v9

    const-string/jumbo v3, "qesNapm"

    const-string v3, "aqmapNe"

    const/4 v10, 0x2

    const-string v3, "appName"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {p1, v3, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/a/a;->b()V

    const/4 v10, 0x5

    const/4 v9, 0x3

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v4}, Lcom/alipay/apmobilesecuritysdk/a/a;->b(Landroid/content/Context;)Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v4, v3}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->a()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/a/a;->a()Z

    move-result v4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v6, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-nez v4, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v4}, Lcom/alipay/apmobilesecuritysdk/common/a;->a(Landroid/content/Context;)Z

    move-result v4

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v4, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/d/e;->a()V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x0

    invoke-static {v4, p1}, Lcom/alipay/apmobilesecuritysdk/d/e;->b(Landroid/content/Context;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->c()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v4, v7}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    xor-int/2addr v4, v6

    const/4 v9, 0x3

    move v10, v9

    if-eqz v4, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    goto/16 :goto_1

    :cond_1
    const/4 v10, 0x0

    invoke-static {p1, v1, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p1, v0, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v4}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v8, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->d()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v4, v8}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-nez v4, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto/16 :goto_1

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v7}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eqz v4, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->e()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v7, v4}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-nez v4, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x3

    goto :goto_1

    :cond_3
    const/4 v10, 0x6

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v4, v3}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-nez v4, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_1

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v4, v3}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x7

    if-eqz v4, :cond_5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_1

    :cond_5
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v4}, Lcom/alipay/apmobilesecuritysdk/a/a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v4, :cond_8

    const/4 v10, 0x2

    goto :goto_1

    :cond_6
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v9, 0x7

    move v10, v9

    invoke-static {v4, v3}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz v4, :cond_7

    :goto_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    move v4, v6

    move v4, v6

    const/4 v10, 0x2

    move v4, v6

    move v4, v6

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_2

    :cond_7
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v4}, Lcom/alipay/apmobilesecuritysdk/a/a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v4}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x1

    xor-int/2addr v10, v9

    if-eqz v4, :cond_8

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_1

    :cond_8
    const/4 v10, 0x1

    move v4, v5

    move v4, v5

    const/4 v10, 0x3

    move v4, v5

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->a()Lcom/alipay/security/mobile/module/b/c;

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->B()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->b(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-nez v4, :cond_a

    :cond_9
    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    move p1, v5

    move p1, v5

    const/4 v10, 0x1

    move p1, v5

    move p1, v5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto/16 :goto_9

    :cond_a
    const/4 v10, 0x7

    const/4 v9, 0x0

    new-instance v4, Lcom/alipay/apmobilesecuritysdk/c/b;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-direct {v4}, Lcom/alipay/apmobilesecuritysdk/c/b;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v4, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v9, 0x3

    xor-int/2addr v10, v9

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/b/a;->a()Lcom/alipay/apmobilesecuritysdk/b/a;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v7}, Lcom/alipay/apmobilesecuritysdk/b/a;->b()I

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v4, v7}, Lcom/alipay/apmobilesecuritysdk/otherid/UmidSdkWrapper;->startUmidTaskSync(Landroid/content/Context;I)Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-direct {p0, p1}, Lcom/alipay/apmobilesecuritysdk/a/a;->b(Ljava/util/Map;)Ld1/c;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v4, :cond_b

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v4}, Ld1/c;->a()I

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_4

    :cond_b
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v7, 0x2

    :goto_4
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eq v7, v6, :cond_e

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/4 p1, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eq v7, p1, :cond_d

    const/4 v9, 0x4

    const/4 v9, 0x1

    if-eqz v4, :cond_c

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string v0, "eermeslos,rrut er :rS"

    const-string v0, "ers Suroere e,srrl:rt"

    const/4 v10, 0x3

    const-string/jumbo v0, "urseo,vrrrertle :eS r"

    const-string v0, "Server error, result:"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, v4, Ld1/a;->b:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_5
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_6

    :cond_c
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo p1, "lodrnbre uermr rlntvreeSur "

    const-string/jumbo p1, "levm  Srordrrerlre unteuren"

    const/4 v10, 0x5

    const-string/jumbo p1, "nverelu de,rulrrer unetorrS"

    const-string p1, "Server error, returned null"

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    goto :goto_5

    :goto_6
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p1, v3}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz p1, :cond_9

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 p1, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_9

    :cond_d
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    move p1, v6

    move p1, v6

    const/4 v10, 0x2

    move p1, v6

    move p1, v6

    const/4 v10, 0x4

    goto/16 :goto_9

    :cond_e
    const/4 v10, 0x4

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v4}, Ld1/c;->b()Z

    move-result v8

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Z)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x5

    invoke-virtual {v4}, Ld1/c;->c()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->d(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v8, v4, Ld1/c;->g:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->e(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v8, v4, Ld1/c;->h:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v8, v4, Ld1/c;->i:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v8, v4, Ld1/c;->k:Ljava/lang/String;

    invoke-static {v7, v8}, Lcom/alipay/apmobilesecuritysdk/e/h;->g(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v7, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-static {v7, p1}, Lcom/alipay/apmobilesecuritysdk/d/e;->b(Landroid/content/Context;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    invoke-static {v7}, Lcom/alipay/apmobilesecuritysdk/e/i;->c(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v7, v4, Ld1/c;->d:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v3, v7}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x1

    iget-object v7, v4, Ld1/c;->c:Ljava/lang/String;

    const/4 v10, 0x5

    invoke-static {v7}, Lcom/alipay/apmobilesecuritysdk/e/i;->b(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v4, v4, Ld1/c;->j:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v4}, Lcom/alipay/apmobilesecuritysdk/e/i;->d(Ljava/lang/String;)V

    const/4 v9, 0x3

    move v10, v9

    invoke-static {p1, v1, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {v1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v4, :cond_f

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->d()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v1, v4}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-nez v4, :cond_f

    const/4 v10, 0x6

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/i;->e(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_7

    :cond_f
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->d()Ljava/lang/String;

    move-result-object v1

    :goto_7
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/alipay/apmobilesecuritysdk/e/i;->e(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    invoke-static {p1, v0, v2}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {p1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    if-eqz v0, :cond_10

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lz0/a;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-nez v0, :cond_10

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/e/i;->f(Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    goto :goto_8

    :cond_10
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->e()Ljava/lang/String;

    move-result-object p1

    :goto_8
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/e/i;->f(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->a()V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->g()Lcom/alipay/apmobilesecuritysdk/e/c;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v0, p1}, Lcom/alipay/apmobilesecuritysdk/e/d;->a(Landroid/content/Context;Lcom/alipay/apmobilesecuritysdk/e/c;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/d;->a()V

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    new-instance v0, Lcom/alipay/apmobilesecuritysdk/e/b;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->c()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/i;->f()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v0, v1, v2, v4}, Lcom/alipay/apmobilesecuritysdk/e/b;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p1, v0}, Lcom/alipay/apmobilesecuritysdk/e/a;->a(Landroid/content/Context;Lcom/alipay/apmobilesecuritysdk/e/b;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/a;->a()V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v3}, Lcom/alipay/apmobilesecuritysdk/e/i;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v9, 0x0

    move v10, v9

    invoke-static {v0, v3, p1}, Lcom/alipay/apmobilesecuritysdk/e/g;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    invoke-static {}, Lcom/alipay/apmobilesecuritysdk/e/g;->a()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {p1, v3, v0, v1}, Lcom/alipay/apmobilesecuritysdk/e/h;->a(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto/16 :goto_3

    :goto_9
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->c:I

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->b:Lcom/alipay/apmobilesecuritysdk/b/a;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/alipay/apmobilesecuritysdk/b/a;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-static {p1, v0}, Lcom/alipay/security/mobile/module/http/d;->c(Landroid/content/Context;Ljava/lang/String;)Le1/a;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string v1, "eyiinvopcotc"

    const-string/jumbo v1, "icotonniceyv"

    const-string/jumbo v1, "tynovcieqnti"

    const-string v1, "connectivity"

    const/4 v10, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    check-cast v1, Landroid/net/ConnectivityManager;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-eqz v1, :cond_11

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_a

    :cond_11
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v1, 0x0

    :goto_a
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eqz v1, :cond_12

    const/4 v9, 0x2

    and-int/2addr v10, v9

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz v2, :cond_12

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->getType()I

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-ne v1, v6, :cond_12

    const/4 v10, 0x5

    move v5, v6

    move v5, v6

    const/4 v10, 0x2

    move v5, v6

    move v5, v6

    :cond_12
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-eqz v5, :cond_13

    const/4 v9, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/alipay/apmobilesecuritysdk/e/h;->c(Landroid/content/Context;)Z

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v1, :cond_13

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v0, "gas/lp/"

    const-string v0, "/log/ap"

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    new-instance v1, Lcom/alipay/security/mobile/module/d/b;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v1, v0, p1}, Lcom/alipay/security/mobile/module/d/b;-><init>(Ljava/lang/String;Le1/a;)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v1}, Lcom/alipay/security/mobile/module/d/b;->b()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_b

    :catch_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/c/a;->a(Ljava/lang/Throwable;)V

    :cond_13
    :goto_b
    const/4 v9, 0x3

    const/4 v10, 0x2

    iget p1, p0, Lcom/alipay/apmobilesecuritysdk/a/a;->c:I

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    return p1
.end method
