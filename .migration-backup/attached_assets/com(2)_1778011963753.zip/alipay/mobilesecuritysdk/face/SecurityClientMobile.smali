.class public Lcom/alipay/mobilesecuritysdk/face/SecurityClientMobile;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    return-void
.end method

.method public static declared-synchronized GetApdid(Landroid/content/Context;Ljava/util/Map;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "c~sb@l~@i ~~ 1  @ @@~@@t/-@~i~@~~.o/@yr~@ ~ v@b~4  t os~ ~dnm b@ @ ~fS~u K@@@~Mf~lo@~o @~a~~o@ i"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-class v0, Lcom/alipay/mobilesecuritysdk/face/SecurityClientMobile;

    const-class v0, Lcom/alipay/mobilesecuritysdk/face/SecurityClientMobile;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v1, Ljava/util/HashMap;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "disdt"

    const/4 v6, 0x1

    const-string/jumbo v2, "udimt"

    const-string/jumbo v2, "utdid"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo v3, "itdmd"

    const-string/jumbo v3, "utido"

    const-string/jumbo v3, "utdid"

    const/4 v6, 0x4

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x6

    const-string v4, ""

    const-string v4, ""

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v3, v4}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo v2, "tid"

    const-string v2, "dit"

    const/4 v6, 0x3

    const-string/jumbo v2, "idt"

    const-string/jumbo v2, "tid"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v3, "dit"

    const-string v3, "dit"

    const/4 v6, 0x5

    const-string/jumbo v3, "itd"

    const-string/jumbo v3, "tid"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1, v3, v4}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v2, "Ioderb"

    const-string v2, "drIuoe"

    const-string/jumbo v2, "udrsIu"

    const-string/jumbo v2, "userId"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v3, "dprbeI"

    const-string v3, "durIeb"

    const-string/jumbo v3, "requIs"

    const-string/jumbo v3, "userId"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x4

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1, v3, v4}, Lz0/a;->c(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v1, v2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->getInstance(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x0

    shl-int/2addr v6, v2

    const/4 v5, 0x3

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1, v2, v1, v3}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->initToken(ILjava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p0}, Lcom/alipay/apmobilesecuritysdk/a/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    throw p0
.end method
