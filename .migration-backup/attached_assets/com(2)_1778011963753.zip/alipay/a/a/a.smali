.class public final Lcom/alipay/a/a/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/a/a/i;
.implements Lcom/alipay/a/a/j;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ sy~~o@  ~@  ilu~@~r  /@d~ ~~~~-.v~@o o~t@b c@K@m~oi~@@a  ~~~@@ ~@fb @ MSn/4~o@l@i @1@ob~@~ st~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    check-cast p1, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    array-length v1, p1

    const/4 v5, 0x6

    const/4 v2, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    if-ge v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    aget-object v3, p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {v3}, Lcom/alipay/a/a/f;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v0
.end method

.method public final a(Ljava/lang/Class;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->isArray()Z

    move-result p1

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p1
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const-class v1, Lorg/json/alipay/a;

    const-class v1, Lorg/json/alipay/a;

    const/4 v5, 0x6

    const-class v1, Lorg/json/alipay/a;

    const-class v1, Lorg/json/alipay/a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object p1

    :cond_0
    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast p1, Lorg/json/alipay/a;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    instance-of v0, p2, Ljava/lang/reflect/GenericArrayType;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x0

    check-cast p2, Ljava/lang/Class;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Lorg/json/alipay/a;->a()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p1, v2}, Lorg/json/alipay/a;->a(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v3, p2}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1, v2, v3}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object v1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string p2, "iDrmtysugor taan  er!seoncpspor"

    const-string p2, " osasD  !nirro epcunresraytgtpo"

    const/4 v5, 0x7

    const-string p2, "Does not support generic array!"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    throw p1
.end method
