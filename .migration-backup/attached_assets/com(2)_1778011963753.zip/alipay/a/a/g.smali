.class public final Lcom/alipay/a/a/g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/a/a/i;
.implements Lcom/alipay/a/a/j;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "-@s~t ~@ f~1@~id~@bou~~l~@ o.tv~~~@o~@yK~@~S@@@fo ~~o  @4  rm@/@ M@ /i ~ilb@oa@@~~ s@ ~c~   b n@"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    new-instance v0, Ljava/util/TreeMap;

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-class v3, Ljava/lang/Object;

    const-class v3, Ljava/lang/Object;

    const/4 v10, 0x1

    const-class v3, Ljava/lang/Object;

    const-class v3, Ljava/lang/Object;

    const/4 v10, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-nez v3, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v2, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    array-length v3, v2

    const/4 v9, 0x0

    shl-int/2addr v10, v9

    if-lez v3, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x1

    array-length v3, v2

    const/4 v4, 0x0

    and-int/2addr v10, v4

    shr-int/2addr v9, v4

    :goto_1
    const/4 v10, 0x3

    if-ge v4, v3, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    aget-object v5, v2, v4

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v6, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v5, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string/jumbo v8, "ti0mhs"

    const-string v8, "$hsti0"

    const/4 v10, 0x2

    const-string v8, "ht0soi"

    const-string/jumbo v8, "this$0"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-eqz v7, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_2

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v5}, Ljava/lang/reflect/AccessibleObject;->isAccessible()Z

    move-result v7

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v5, v8}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-nez v8, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_2

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v5, v7}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v8}, Lcom/alipay/a/a/f;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    :cond_2
    :goto_2
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v6, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    const/4 v9, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto :goto_1

    :cond_4
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-object v0
.end method

.method public final a(Ljava/lang/Class;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-class v1, Lorg/json/alipay/b;

    const-class v1, Lorg/json/alipay/b;

    const/4 v9, 0x2

    const-class v1, Lorg/json/alipay/b;

    const-class v1, Lorg/json/alipay/b;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-nez v0, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 p1, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-object p1

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    check-cast p1, Lorg/json/alipay/b;

    const/4 v8, 0x5

    or-int/2addr v9, v8

    check-cast p2, Ljava/lang/Class;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v9, 0x7

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v1, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    array-length v2, v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-lez v2, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x3

    array-length v2, v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v3, 0x0

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-ge v3, v2, :cond_2

    const/4 v8, 0x0

    move v9, v8

    aget-object v4, v1, v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v4}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    invoke-virtual {p1, v5}, Lorg/json/alipay/b;->b(Ljava/lang/String;)Z

    move-result v7

    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz v7, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v7, 0x1

    invoke-virtual {v4, v7}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p1, v5}, Lorg/json/alipay/b;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    invoke-static {v5, v6}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v4, v0, v5}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p2}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    return-object v0
.end method
