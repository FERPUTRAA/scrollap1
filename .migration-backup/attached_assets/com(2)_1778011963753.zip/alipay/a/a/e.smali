.class public final Lcom/alipay/a/a/e;
.super Ljava/lang/Object;


# static fields
.field static a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alipay/a/a/i;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Lcom/alipay/a/a/l;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/alipay/a/a/l;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Lcom/alipay/a/a/d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/alipay/a/a/d;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/a/a/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1}, Lcom/alipay/a/a/c;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/a/a/h;

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1}, Lcom/alipay/a/a/h;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Lcom/alipay/a/a/k;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1}, Lcom/alipay/a/a/k;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/a/a/b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1}, Lcom/alipay/a/a/b;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/alipay/a/a/a;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v1}, Lcom/alipay/a/a/a;-><init>()V

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v1, Lcom/alipay/a/a/g;

    const/4 v3, 0x6

    invoke-direct {v1}, Lcom/alipay/a/a/g;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public static final a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/Type;",
            ")TT;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o/slo~y@~ ~@K-oo ~/v@m@@4@l b@~@t~Mr@~~  @i~S.~ ~~@ u~ i~s~  fa~td@~~b~@ ~@~@ 1fo @b@i@ c@o~@   "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    sget-object v0, Lcom/alipay/a/a/e;->a:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v1, Lcom/alipay/a/a/i;

    const/4 v4, 0x6

    invoke-static {p1}, Lr0/a;->a(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-interface {v1, v2}, Lcom/alipay/a/a/i;->a(Ljava/lang/Class;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1, p0, p1}, Lcom/alipay/a/a/i;->b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p0
.end method

.method public static final b(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto/16 :goto_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const-string v0, "["

    const-string v0, "["

    const/4 v2, 0x1

    const-string v0, "["

    const-string v0, "["

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v1, 0x2

    move v2, v1

    const-string v0, "]"

    const-string v0, "]"

    const/4 v2, 0x4

    const-string v0, "]"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lorg/json/alipay/a;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lorg/json/alipay/a;-><init>(Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const-string/jumbo v0, "{"

    const-string/jumbo v0, "{"

    const-string/jumbo v0, "{"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "}"

    const-string/jumbo v0, "}"

    const/4 v2, 0x1

    const-string/jumbo v0, "}"

    const-string/jumbo v0, "}"

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lorg/json/alipay/b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lorg/json/alipay/b;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_3
    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method
