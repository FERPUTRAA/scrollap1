.class public final Lcom/alipay/a/a/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/a/a/i;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @suy@@ vo~/ f~o  s~Mr~@@  4~ ~~@obb~@ @~~@l~@1@~~~-lmf@ cat~~~b @~ o@d~/ onti i ~S@@@o~.i~K@ @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-class v0, Ljava/util/Set;

    const-class v0, Ljava/util/Set;

    const/4 v2, 0x5

    const-class v0, Ljava/util/Set;

    const-class v0, Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-class v1, Lorg/json/alipay/a;

    const/4 v4, 0x0

    const-class v1, Lorg/json/alipay/a;

    const-class v1, Lorg/json/alipay/a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x5

    return-object p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    check-cast p1, Lorg/json/alipay/a;

    const/4 v4, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    instance-of v1, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    aget-object p2, p2, v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const-class p2, Ljava/lang/Object;

    const-class p2, Ljava/lang/Object;

    const/4 v4, 0x3

    const-class p2, Ljava/lang/Object;

    const-class p2, Ljava/lang/Object;

    :goto_0
    const/4 v4, 0x0

    invoke-virtual {p1}, Lorg/json/alipay/a;->a()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-ge v2, v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1, v2}, Lorg/json/alipay/a;->a(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v1, p2}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v3, 0x5

    move v4, v3

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v0
.end method
