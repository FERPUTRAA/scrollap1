.class public final Lcom/alipay/a/a/f;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alipay/a/a/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sput-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v1, Lcom/alipay/a/a/l;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1}, Lcom/alipay/a/a/l;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v1, Lcom/alipay/a/a/d;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-direct {v1}, Lcom/alipay/a/a/d;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v1, Lcom/alipay/a/a/c;

    const/4 v3, 0x5

    invoke-direct {v1}, Lcom/alipay/a/a/c;-><init>()V

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/alipay/a/a/h;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-direct {v1}, Lcom/alipay/a/a/h;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v1, Lcom/alipay/a/a/b;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1}, Lcom/alipay/a/a/b;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Lcom/alipay/a/a/a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1}, Lcom/alipay/a/a/a;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v1, Lcom/alipay/a/a/g;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1}, Lcom/alipay/a/a/g;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public static a(Ljava/lang/Object;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/alipay/a/a/f;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0}, Lr0/a;->b(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0}, Lorg/json/alipay/b;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Ljava/util/Collection;

    const-class v1, Ljava/util/Collection;

    const/4 v4, 0x4

    const-class v1, Ljava/util/Collection;

    const-class v1, Ljava/util/Collection;

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast p0, Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Lorg/json/alipay/a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Lorg/json/alipay/a;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Lorg/json/alipay/a;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const-class v1, Ljava/util/Map;

    const-class v1, Ljava/util/Map;

    const-class v1, Ljava/util/Map;

    const-class v1, Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    move v4, v3

    check-cast p0, Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Lorg/json/alipay/b;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Lorg/json/alipay/b;-><init>(Ljava/util/Map;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lorg/json/alipay/b;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "s s eor tUsuln:appsC"

    const-string v2, "assnr ue dplUpostC: "

    const/4 v4, 0x4

    const-string v2, " :umodtlanpe rss sUp"

    const-string v2, "Unsupported Class : "

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    throw v0
.end method

.method public static b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    sget-object v0, Lcom/alipay/a/a/f;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v1, Lcom/alipay/a/a/j;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1, v2}, Lcom/alipay/a/a/j;->a(Ljava/lang/Class;)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {v1, p0}, Lcom/alipay/a/a/j;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "sedsontos aum prC :U"

    const-string/jumbo v2, "slsmaCdosr pue:U nt "

    const/4 v4, 0x4

    const-string/jumbo v2, "p CUabrpsn:l utdeso "

    const-string v2, "Unsupported Class : "

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw v0
.end method
