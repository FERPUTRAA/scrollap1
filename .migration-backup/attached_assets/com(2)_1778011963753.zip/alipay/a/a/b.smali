.class public final Lcom/alipay/a/a/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/a/a/i;
.implements Lcom/alipay/a/a/j;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private static c(Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/util/Collection;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/util/Collection<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@si-yr /~on@ fl@~@@   4~ ~@K.vu ~M~t@o~@~~~~o~@@@a@t~~ o~  fbsl @S@oi/ oc~~ i1@b~ @@~~ d @ m@b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const-class v0, Ljava/util/AbstractCollection;

    const-class v0, Ljava/util/AbstractCollection;

    const/4 v3, 0x6

    const-class v0, Ljava/util/AbstractCollection;

    const-class v0, Ljava/util/AbstractCollection;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne p0, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance p0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-class v0, Ljava/util/HashSet;

    const-class v0, Ljava/util/HashSet;

    const-class v0, Ljava/util/HashSet;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    new-instance p0, Ljava/util/HashSet;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/util/HashSet;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto/16 :goto_1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-class v0, Ljava/util/LinkedHashSet;

    const-class v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x0

    const-class v0, Ljava/util/LinkedHashSet;

    const-class v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto/16 :goto_1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-class v0, Ljava/util/TreeSet;

    const-class v0, Ljava/util/TreeSet;

    const/4 v3, 0x6

    const-class v0, Ljava/util/TreeSet;

    const-class v0, Ljava/util/TreeSet;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_3

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance p0, Ljava/util/TreeSet;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/util/TreeSet;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_1

    :cond_3
    const/4 v3, 0x4

    const-class v0, Ljava/util/ArrayList;

    const-class v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const-class v0, Ljava/util/ArrayList;

    const-class v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p0, Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_1

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-class v0, Ljava/util/EnumSet;

    const-class v0, Ljava/util/EnumSet;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_6

    const/4 v3, 0x7

    const/4 v2, 0x2

    instance-of p0, p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    aget-object p0, p0, p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_5
    const/4 v3, 0x7

    const-class p0, Ljava/lang/Object;

    const-class p0, Ljava/lang/Object;

    const/4 v3, 0x1

    const-class p0, Ljava/lang/Object;

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast p0, Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_1

    :cond_6
    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p1, Ljava/util/Collection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "sr mi,aest s rnreaee onratcl"

    const-string v1, "aisaosnlscre  cte rr tare,ne"

    const/4 v3, 0x3

    const-string v1, "ets,otanienar rs lraecocser "

    const-string v1, "create instane error, class "

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p1
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast p1, Ljava/lang/Iterable;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/alipay/a/a/f;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public final a(Ljava/lang/Class;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-class v1, Lorg/json/alipay/a;

    const-class v1, Lorg/json/alipay/a;

    const/4 v4, 0x4

    const-class v1, Lorg/json/alipay/a;

    const-class v1, Lorg/json/alipay/a;

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p2}, Lr0/a;->a(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p1, Lorg/json/alipay/a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p2}, Lcom/alipay/a/a/b;->c(Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/util/Collection;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    instance-of v1, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    aget-object p2, p2, v1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lorg/json/alipay/a;->a()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Lorg/json/alipay/a;->a(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v2, p2}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p2, " nmDmbo nttoeicppeoefi  ne . rpetsmtrrghesso"

    const-string p2, "ennmDue  o top gpsnesch ttem.efrriemtoior ps"

    const-string p2, "etotfiuo etme s ensoesgecDp t  rnrmpn.hlriou"

    const-string p2, "Does not support the implement for generics."

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v4, 0x4

    throw p1
.end method
