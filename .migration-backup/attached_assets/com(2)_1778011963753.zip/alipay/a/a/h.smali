.class public final Lcom/alipay/a/a/h;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/a/a/i;
.implements Lcom/alipay/a/a/j;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method private static c(Ljava/lang/reflect/Type;)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    :goto_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ s-~  @~~/n@ @  ~~@ Sio~~ ~~@@r.1id@~  c~~i/l@tK@@ @f ooo~ bb~  4~f~M@@@o@~~maoy@@sulv~~~ t@~@b"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    const-class v0, Ljava/util/Properties;

    const-class v0, Ljava/util/Properties;

    const/4 v5, 0x4

    const-class v0, Ljava/util/Properties;

    const-class v0, Ljava/util/Properties;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p0, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance p0, Ljava/util/Properties;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0}, Ljava/util/Properties;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object p0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-class v0, Ljava/util/Hashtable;

    const-class v0, Ljava/util/Hashtable;

    const/4 v5, 0x7

    const-class v0, Ljava/util/Hashtable;

    const-class v0, Ljava/util/Hashtable;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ne p0, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance p0, Ljava/util/Hashtable;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0}, Ljava/util/Hashtable;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object p0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-class v0, Ljava/util/IdentityHashMap;

    const-class v0, Ljava/util/IdentityHashMap;

    const/4 v5, 0x4

    const-class v0, Ljava/util/IdentityHashMap;

    const-class v0, Ljava/util/IdentityHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne p0, v0, :cond_2

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance p0, Ljava/util/IdentityHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p0}, Ljava/util/IdentityHashMap;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-class v0, Ljava/util/SortedMap;

    const-class v0, Ljava/util/SortedMap;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq p0, v0, :cond_b

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-class v0, Ljava/util/TreeMap;

    const-class v0, Ljava/util/TreeMap;

    const/4 v5, 0x2

    const-class v0, Ljava/util/TreeMap;

    const-class v0, Ljava/util/TreeMap;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne p0, v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto/16 :goto_3

    :cond_3
    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq p0, v0, :cond_a

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x5

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ne p0, v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto/16 :goto_2

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v5, 0x6

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eq p0, v0, :cond_9

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-class v0, Ljava/util/HashMap;

    const-class v0, Ljava/util/HashMap;

    const/4 v5, 0x4

    const-class v0, Ljava/util/HashMap;

    const-class v0, Ljava/util/HashMap;

    const/4 v5, 0x6

    if-ne p0, v0, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto/16 :goto_1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x4

    const-class v0, Ljava/util/LinkedHashMap;

    const-class v0, Ljava/util/LinkedHashMap;

    const/4 v5, 0x3

    const-class v0, Ljava/util/LinkedHashMap;

    const-class v0, Ljava/util/LinkedHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ne p0, v0, :cond_6

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance p0, Ljava/util/LinkedHashMap;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object p0

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_7
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v0, Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->isInterface()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, " ttmrusspuonpe "

    const-string/jumbo v2, "y sepuotrs nupt"

    const/4 v5, 0x5

    const-string/jumbo v2, "u propon pytetu"

    const-string/jumbo v2, "unsupport type "

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v1, :cond_8

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v0, Ljava/util/Map;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    throw v1

    :cond_8
    const/4 v5, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x3

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    throw v0

    :cond_9
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance p0, Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object p0

    :cond_a
    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance p0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v5, 0x5

    return-object p0

    :cond_b
    :goto_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    new-instance p0, Ljava/util/TreeMap;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/util/TreeMap;-><init>()V

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object p0
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Ljava/util/TreeMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast p1, Ljava/util/Map;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    instance-of v2, v2, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/alipay/a/a/f;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "yt bsb tmnkM!p meeSi ur"

    const-string/jumbo v0, "urnmpgSs  !tyikm M etbe"

    const/4 v4, 0x7

    const-string/jumbo v0, "t inM u ysaukSe !tebgpm"

    const-string v0, "Map key must be String!"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v0
.end method

.method public final a(Ljava/lang/Class;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x0

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v2, 0x6

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method public final b(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-class v1, Lorg/json/alipay/b;

    const-class v1, Lorg/json/alipay/b;

    const/4 v5, 0x6

    const-class v1, Lorg/json/alipay/b;

    const-class v1, Lorg/json/alipay/b;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v5, 0x3

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast p1, Lorg/json/alipay/b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p2}, Lcom/alipay/a/a/h;->c(Ljava/lang/reflect/Type;)Ljava/util/Map;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    instance-of v1, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_4

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    aget-object v1, v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p2}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-object p2, p2, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x5

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    if-ne v2, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Lorg/json/alipay/b;->a()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    check-cast v2, Ljava/lang/String;

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast v3, Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v3}, Lr0/a;->b(Ljava/lang/Class;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1, v2}, Lorg/json/alipay/b;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Lorg/json/alipay/b;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v3, p2}, Lcom/alipay/a/a/e;->a(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v3

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    return-object v0

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p2, "lteis apisbr eezss.ga macelKteSupyo  MDr"

    const-string p2, "ely ot lazrruKiSsbDapMesnisec teas.g  em"

    const/4 v5, 0x4

    const-string p2, " saeas.zqs emarr  tDl gbySiMiuiplseKetce"

    const-string p2, "Deserialize Map Key must be String.class"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    throw p1

    :cond_4
    const/4 v5, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string p2, "essebea bi esGnprezeDMcs riu lmt!"

    const-string p2, "eesiabcm Dee uer!tp Ge bnaiMlszrs"

    const/4 v5, 0x0

    const-string p2, " izm sepetiesinub!eMrDmraclGsea e"

    const-string p2, "Deserialize Map must be Generics!"

    const/4 v5, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw p1
.end method
