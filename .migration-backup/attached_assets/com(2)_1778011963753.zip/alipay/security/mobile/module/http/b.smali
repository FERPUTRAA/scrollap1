.class public Lcom/alipay/security/mobile/module/http/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/security/mobile/module/http/a;


# static fields
.field private static d:Lcom/alipay/security/mobile/module/http/b;

.field private static e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;


# instance fields
.field private a:Lcom/alipay/android/phone/mrpc/core/w;

.field private b:Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

.field private c:Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/alipay/security/mobile/module/http/b;->a:Lcom/alipay/android/phone/mrpc/core/w;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alipay/security/mobile/module/http/b;->b:Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/security/mobile/module/http/b;->c:Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/aa;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/alipay/android/phone/mrpc/core/aa;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Lcom/alipay/android/phone/mrpc/core/aa;->a(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p2, Lcom/alipay/android/phone/mrpc/core/h;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p2, p1}, Lcom/alipay/android/phone/mrpc/core/h;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/alipay/security/mobile/module/http/b;->a:Lcom/alipay/android/phone/mrpc/core/w;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-class p1, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const-class p1, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const-class p1, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const-class p1, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p2, p1, v0}, Lcom/alipay/android/phone/mrpc/core/w;->a(Ljava/lang/Class;Lcom/alipay/android/phone/mrpc/core/aa;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p1, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/alipay/security/mobile/module/http/b;->b:Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/alipay/security/mobile/module/http/b;->a:Lcom/alipay/android/phone/mrpc/core/w;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-class p2, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const-class p2, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const-class p2, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const-class p2, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2, v0}, Lcom/alipay/android/phone/mrpc/core/w;->a(Ljava/lang/Class;Lcom/alipay/android/phone/mrpc/core/aa;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p1, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/alipay/security/mobile/module/http/b;->c:Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public static declared-synchronized b(Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/security/mobile/module/http/b;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s1 ~@.~S~~oi @  ~u~~~bi t~@~yoo/@m~@iK~~ M@cfrbs~@o @l~@4@@o  ~ @~ /@fdb  t@ @v@~-@ o~ln@a~ @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    const-class v0, Lcom/alipay/security/mobile/module/http/b;

    const-class v0, Lcom/alipay/security/mobile/module/http/b;

    const/4 v3, 0x7

    const-class v0, Lcom/alipay/security/mobile/module/http/b;

    const-class v0, Lcom/alipay/security/mobile/module/http/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    sget-object v1, Lcom/alipay/security/mobile/module/http/b;->d:Lcom/alipay/security/mobile/module/http/b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/security/mobile/module/http/b;

    const/4 v3, 0x4

    invoke-direct {v1, p0, p1}, Lcom/alipay/security/mobile/module/http/b;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    sput-object v1, Lcom/alipay/security/mobile/module/http/b;->d:Lcom/alipay/security/mobile/module/http/b;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    sget-object p0, Lcom/alipay/security/mobile/module/http/b;->d:Lcom/alipay/security/mobile/module/http/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    throw p0
.end method

.method static synthetic c(Lcom/alipay/security/mobile/module/http/b;)Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;
    .locals 2

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/alipay/security/mobile/module/http/b;->c:Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic d()Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/alipay/security/mobile/module/http/b;->e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic e(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    sput-object p0, Lcom/alipay/security/mobile/module/http/b;->e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v1, 0x0

    return-object p0
.end method


# virtual methods
.method public a(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/alipay/security/mobile/module/http/b;->c:Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    sput-object v0, Lcom/alipay/security/mobile/module/http/b;->e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v1, Lcom/alipay/security/mobile/module/http/c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1}, Lcom/alipay/security/mobile/module/http/c;-><init>(Lcom/alipay/security/mobile/module/http/b;Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const p1, 0x493e0

    :goto_0
    const/4 v2, 0x0

    sget-object v0, Lcom/alipay/security/mobile/module/http/b;->e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x5

    if-ltz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-wide/16 v0, 0x32

    const-wide/16 v0, 0x32

    const/4 v3, 0x6

    const-wide/16 v0, 0x32

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    add-int/lit8 p1, p1, -0x32

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object p1, Lcom/alipay/security/mobile/module/http/b;->e:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1
.end method

.method public a(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x0

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/alipay/security/mobile/module/http/b;->b:Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v2, 0x6

    move v3, v2

    invoke-static {p1}, Lz0/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lcom/alipay/tscenter/biz/rpc/deviceFp/BugTrackMessageService;->logCollect(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const-string/jumbo p1, "ssumses"

    const-string/jumbo p1, "usssecs"

    const/4 v3, 0x2

    const-string p1, "ecusosc"

    const-string/jumbo p1, "success"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v1
.end method
