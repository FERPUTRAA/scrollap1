.class Lcom/alipay/security/mobile/module/http/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;

.field final synthetic b:Lcom/alipay/security/mobile/module/http/b;


# direct methods
.method constructor <init>(Lcom/alipay/security/mobile/module/http/b;Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/security/mobile/module/http/c;->b:Lcom/alipay/security/mobile/module/http/b;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/alipay/security/mobile/module/http/c;->a:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~is@ ~@/ d@ur@ ~@bS@~@~cf. ~-~@ lo~@ab ~~~/ @~ n@@~@oo@  f i ~vy@~o @m~tM~K i4@~~o@ o1tl~b~  s@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/alipay/security/mobile/module/http/c;->b:Lcom/alipay/security/mobile/module/http/b;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/alipay/security/mobile/module/http/b;->c(Lcom/alipay/security/mobile/module/http/b;)Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/alipay/security/mobile/module/http/c;->a:Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Lcom/alipay/tscenter/biz/rpc/report/general/DataReportService;->reportData(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/alipay/security/mobile/module/http/b;->e(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v1, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v1}, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/alipay/security/mobile/module/http/b;->e(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/http/b;->d()Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-boolean v2, v1, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;->success:Z

    const/4 v5, 0x3

    invoke-static {}, Lcom/alipay/security/mobile/module/http/b;->d()Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    const-string/jumbo v3, "static data rpc upload error, "

    const-string/jumbo v3, "static data rpc upload error, "

    const/4 v5, 0x2

    const-string/jumbo v3, "static data rpc upload error, "

    const-string/jumbo v3, "static data rpc upload error, "

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lz0/a;->b(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v2, v1, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;->resultCode:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0}, Lz0/a;->b(Ljava/lang/Throwable;)Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method
