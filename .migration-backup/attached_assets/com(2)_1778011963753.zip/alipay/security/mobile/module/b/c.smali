.class public final Lcom/alipay/security/mobile/module/b/c;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/alipay/security/mobile/module/b/c;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    new-instance v0, Lcom/alipay/security/mobile/module/b/c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/alipay/security/mobile/module/b/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput-object v0, Lcom/alipay/security/mobile/module/b/c;->a:Lcom/alipay/security/mobile/module/b/c;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method public static A(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s@~@s-l /~4v~o@@u ~t@ M@@oo~@i~/ ~ @@@bomry~ @n@~. ~~o~~o@df~ a@b1~~@ ib   l~ ci @fK@~~  ~@ St"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const-string v1, "adsmodind_"

    const-string/jumbo v1, "odsarnidd_"

    const/4 v3, 0x7

    const-string v1, "didnoodira"

    const-string v1, "android_id"

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :cond_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method public static B()Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    sub-long/2addr v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x1

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    rem-long v3, v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    sub-long/2addr v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-object v0

    :catchall_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v0
.end method

.method public static C(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "bphmn"

    const-string/jumbo v0, "nepmh"

    const/4 v2, 0x6

    const-string/jumbo v0, "nupho"

    const-string/jumbo v0, "phone"

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getNetworkType()I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :catchall_0
    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string p0, ""

    const/4 v2, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public static D()Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :catchall_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const-string v0, ""

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    return-object v0
.end method

.method public static E(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "oTFSnsIpAoST.mi.IsWEnCreCd_Ar_adoiiE"

    const-string v0, "dErIoTSiAToIF.nSm_i_rdCanoiAEWesCs.p"

    const/4 v3, 0x5

    const-string v0, "Erd_AdeSqnaTinsSs.oA.mTCIioWiCS_pIrF"

    const-string v0, "android.permission.ACCESS_WIFI_STATE"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v1

    :cond_0
    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "iiwf"

    const-string/jumbo v0, "wiif"

    const/4 v3, 0x1

    const-string/jumbo v0, "ifwi"

    const-string/jumbo v0, "wifi"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p0, Landroid/net/wifi/WifiManager;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/net/wifi/WifiInfo;->getBSSID()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    :cond_1
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_1

    :cond_2
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v1
.end method

.method public static F()Ljava/lang/String;
    .locals 9

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v0, "00"

    const-string v0, "00"

    const/4 v8, 0x5

    const-string v0, "00"

    const-string v0, "00"

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v2, 0x3

    const/4 v8, 0x7

    const/4 v2, 0x7

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-array v3, v2, [Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v4, "pdsqemee_/uib/"

    const-string/jumbo v4, "imduebeeq/_pv/"

    const/4 v8, 0x7

    const-string/jumbo v4, "m/eme/vp_qipue"

    const-string v4, "/dev/qemu_pipe"

    const/4 v8, 0x0

    const/4 v5, 0x4

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    aput-object v4, v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v4, "e/t/ovqeuseckdo/m"

    const-string v4, "eq/tkeu/v/dmeoucs"

    const/4 v8, 0x2

    const-string v4, "/dev/socket/qemud"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    move v8, v7

    aput-object v4, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    const-string/jumbo v4, "mcuetbo_bdscaie/e_bls/lgslqim_pm./ulo"

    const-string/jumbo v4, "iums/lbpol_tlmbgesbcua_deos/ce/lq._mi"

    const/4 v8, 0x0

    const-string v4, "/system/lib/libc_malloc_debug_qemu.so"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    aput-object v4, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v4, "mrysceuas/t/_qe"

    const-string/jumbo v4, "us_esrc/qamy/et"

    const/4 v8, 0x7

    const-string v4, "a/ure_cptssqyme"

    const-string v4, "/sys/qemu_trace"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v6, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    aput-object v4, v3, v6

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v4, "/e/nmumqqsrtbsp-epsoy/"

    const-string v4, "e/snmbmseos-/rptsyuqp/"

    const/4 v8, 0x4

    const-string/jumbo v4, "mpsret-qm/suib/eopyssn"

    const-string v4, "/system/bin/qemu-props"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v6, 0x4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    aput-object v4, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v4, "e/gmnkds/cemoy/ed"

    const-string v4, "dydm/netkecesgo//"

    const/4 v8, 0x1

    const-string v4, "dotsoey//cekv/dne"

    const-string v4, "/dev/socket/genyd"

    const/4 v7, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v6, 0x5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object v4, v3, v6

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v4, "eads_bcdendask/oyob/b/egnt"

    const-string/jumbo v4, "saagoneb/yosdcdk/_enb/dtve"

    const/4 v8, 0x3

    const-string v4, "ed/odeukne_tgd/b/yanevacsb"

    const-string v4, "/dev/socket/baseband_genyd"

    const/4 v7, 0x2

    move v8, v7

    const/4 v6, 0x6

    move v8, v6

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput-object v4, v3, v6

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string v0, ":"

    const-string v0, ":"

    const/4 v8, 0x7

    const-string v0, ":"

    const-string v0, ":"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ge v5, v2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    aget-object v0, v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v4, Ljava/io/File;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v4, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const-string v0, "1"

    const-string v0, "1"

    const/4 v8, 0x7

    const-string v0, "1"

    const-string v0, "1"

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_2

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v0, "0"

    const-string v0, "0"

    const/4 v8, 0x3

    const-string v0, "0"

    const-string v0, "0"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_1

    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-object v0

    :catchall_0
    const/4 v8, 0x2

    const-string v0, ""

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object v0
.end method

.method public static G(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v2, 0x1d

    const/4 v4, 0x1

    if-lt v1, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/16 v2, 0x1a

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-lt v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v1, 0x1c

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-lt p0, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lcom/alipay/security/mobile/module/b/b;->a()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p0, Landroid/os/Build;->SERIAL:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    :goto_0
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_2

    :cond_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0
.end method

.method public static H()Ljava/lang/String;
    .locals 7

    const/4 v5, 0x1

    move v6, v5

    const-string/jumbo v0, "nte.Tsipalsvyaktm.i"

    const-string v0, "dalvik.system.Taint"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, "00"

    const-string v2, "00"

    const/4 v6, 0x6

    const-string v2, "00"

    const-string v2, "00"

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v2, ":"

    const-string v2, ":"

    const/4 v6, 0x2

    const-string v2, ":"

    const-string v2, ":"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x6

    if-gtz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    aget-object v4, v0, v2

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "1"

    const-string v4, "1"

    const/4 v6, 0x3

    const-string v4, "1"

    const-string v4, "1"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_1

    :catchall_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v4, "0"

    const/4 v6, 0x4

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object v0
.end method

.method public static I(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/alipay/security/mobile/module/b/c;->O(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->S()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p0}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string p0, ":"

    const-string p0, ":"

    const/4 v4, 0x5

    const-string p0, ":"

    const-string p0, ":"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->S()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :catchall_0
    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0
.end method

.method public static J()Ljava/lang/String;
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v1, Ljava/util/LinkedHashMap;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v2, "ort.ybeim/sppld/su"

    const/4 v9, 0x6

    const-string/jumbo v2, "um.rsiy/qob/pstped"

    const-string v2, "/system/build.prop"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string/jumbo v3, "n.sro=rkaoped.ctdsu"

    const-string/jumbo v3, "pokr=ruosca.dd.ntue"

    const/4 v9, 0x6

    const-string v3, ".kamrdctur.=odsoepm"

    const-string/jumbo v3, "ro.product.name=sdk"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string v2, "ctpvo/ed/rtrsoyir"

    const-string v2, "/proc/tty/drivers"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const-string v3, "hspgfbol"

    const-string/jumbo v3, "sgiolhfp"

    const/4 v9, 0x2

    const-string v3, "dlgfsoui"

    const-string v3, "goldfish"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v2, "poccn/qp/oriu"

    const-string v2, "cc/ropfuqo/ni"

    const/4 v9, 0x5

    const-string/jumbo v2, "poccnrpuq/fi/"

    const-string v2, "/proc/cpuinfo"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v3, "00"

    const/4 v9, 0x6

    const-string v3, "00"

    const-string v3, "00"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v3, ":"

    const-string v3, ":"

    const/4 v9, 0x1

    const-string v3, ":"

    const-string v3, ":"

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    and-int/2addr v9, v8

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :catchall_0
    :cond_0
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eqz v3, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/16 v4, 0x30

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance v5, Ljava/io/LineNumberReader;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v6, Ljava/io/InputStreamReader;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v7, Ljava/io/FileInputStream;

    const/4 v8, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {v7, v3}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {v6, v7}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {v5, v6}, Ljava/io/LineNumberReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :cond_1
    :try_start_1
    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v6, :cond_2

    const/4 v8, 0x0

    move v9, v8

    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast v7, Ljava/lang/CharSequence;

    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz v6, :cond_1

    const/4 v9, 0x6

    const/16 v4, 0x31

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1
    :try_start_2
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/io/Reader;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x3

    goto :goto_0

    :catchall_1
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v5, 0x0

    :catchall_2
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v5, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_1

    :cond_3
    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    return-object v0
.end method

.method public static K(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    :try_start_0
    const/4 v8, 0x1

    const-string/jumbo v0, "uysesgad"

    const-string v0, "eksdygau"

    const/4 v8, 0x2

    const-string/jumbo v0, "keyguard"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    check-cast p0, Landroid/app/KeyguardManager;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/app/KeyguardManager;->isKeyguardSecure()Z

    move-result p0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez p0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string p0, "00:"

    const-string p0, "00:"

    const/4 v8, 0x1

    const-string p0, "0:0"

    const-string p0, "0:0"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-object p0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 p0, 0x5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-array v0, p0, [Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v1, "ssrmdad/ewm.aesatm/py/ots"

    const-string v1, "da/mpstdsmteyoe/kr.wass/a"

    const/4 v8, 0x2

    const-string v1, "ays/odsetoks.ted/araw/smp"

    const-string v1, "/data/system/password.key"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    aput-object v1, v0, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string/jumbo v1, "rku/osttm/yedyaatee/egss"

    const/4 v8, 0x5

    const-string/jumbo v1, "y.atebus/mkysdtrgae/e/et"

    const-string v1, "/data/system/gesture.key"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    aput-object v1, v0, v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v1, ".m/dtba/aktrseesedkewo/srpe.atygeasy"

    const/4 v8, 0x0

    const-string v1, "ersaytuspttgea/es.kye.e/ekwaddmsr/pa"

    const-string v1, "/data/system/gatekeeper.password.key"

    const/4 v7, 0x3

    shl-int/2addr v8, v7

    const/4 v3, 0x2

    or-int/2addr v8, v3

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    aput-object v1, v0, v3

    const/4 v7, 0x6

    move v8, v7

    const-string v1, ".eekeedpas/.rukgsmg/ut/teaseryetypa"

    const-string v1, ".adet.utreskmrgsuse/eeaykp/age/eeyt"

    const/4 v8, 0x2

    const-string v1, "eekaetaeqk/sgtsgy.e.serra/dey/emtup"

    const-string v1, "/data/system/gatekeeper.gesture.key"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v8, 0x5

    aput-object v1, v0, v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const-string v1, "atsymeeerydastg/e./prskptaekeetnt.a"

    const-string v1, "eeasea.pany/mttsk/.teragtyer/depetk"

    const/4 v8, 0x4

    const-string/jumbo v1, "retmsse/etet..rkkpanpe/teyye/gdtmaa"

    const-string v1, "/data/system/gatekeeper.pattern.key"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v3, 0x4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v1, v0, v3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    :goto_0
    const/4 v8, 0x5

    if-ge v2, p0, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x6

    aget-object v1, v0, v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance v5, Ljava/io/File;

    const/4 v7, 0x1

    or-int/2addr v8, v7

    invoke-direct {v5, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v5}, Ljava/io/File;->lastModified()J

    move-result-wide v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_1

    :catchall_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v8, 0x3

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    :goto_1
    :try_start_2
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string v0, ":1"

    const/4 v8, 0x4

    const-string v0, ":1"

    const-string v0, "1:"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object p0

    :catchall_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v8, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object p0
.end method

.method public static L()Ljava/lang/String;
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v2, "00"

    const-string v2, "00"

    const/4 v8, 0x0

    const-string v2, "00"

    const-string v2, "00"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const-string v2, ":"

    const-string v2, ":"

    const/4 v8, 0x0

    const-string v2, ":"

    const-string v2, ":"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v1, Ljava/util/LinkedHashMap;

    const/4 v8, 0x4

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v2, "BqRDo"

    const-string v2, "RBAqD"

    const/4 v8, 0x4

    const-string v2, "bABRN"

    const-string v2, "BRAND"

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v3, "cesneiu"

    const-string v3, "eiscern"

    const/4 v8, 0x7

    const-string/jumbo v3, "pgernci"

    const-string v3, "generic"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v2, "DARqO"

    const-string v2, "RODmA"

    const/4 v8, 0x2

    const-string v2, "ODsBR"

    const-string v2, "BOARD"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v4, "nnkmuow"

    const-string/jumbo v4, "wnnkoun"

    const/4 v8, 0x4

    const-string/jumbo v4, "wnkuoon"

    const-string/jumbo v4, "unknown"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v2, "EVbIEb"

    const-string v2, "DEEIVb"

    const/4 v8, 0x1

    const-string/jumbo v2, "uECEVI"

    const-string v2, "DEVICE"

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v2, "REAAuWDp"

    const-string v2, "WAEAHDuR"

    const/4 v8, 0x5

    const-string v2, "HARDWARE"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v3, "qlsoifhp"

    const-string/jumbo v3, "ishofdlp"

    const/4 v8, 0x5

    const-string/jumbo v3, "sdshilgo"

    const-string v3, "goldfish"

    const/4 v7, 0x0

    move v8, v7

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v2, "TDUmCOR"

    const-string v2, "RqODUTC"

    const/4 v8, 0x5

    const-string v2, "ORUCoDP"

    const-string v2, "PRODUCT"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string/jumbo v3, "kds"

    const-string/jumbo v3, "ksd"

    const/4 v8, 0x6

    const-string/jumbo v3, "ksd"

    const-string/jumbo v3, "sdk"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v2, "bDOEs"

    const-string v2, "ODsME"

    const/4 v8, 0x2

    const-string v2, "EuDMO"

    const-string v2, "MODEL"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x0

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v3, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/16 v4, 0x30

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-class v5, Landroid/os/Build;

    const-class v5, Landroid/os/Build;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v5, v3}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v5, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v6, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v6, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v3, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/16 v4, 0x31

    :catchall_0
    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-object v0
.end method

.method public static M(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Landroid/content/IntentFilter;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "android.intent.action.BATTERY_CHANGED"

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, "elpve"

    const-string v0, "elemv"

    const/4 v4, 0x7

    const-string v0, "eevql"

    const-string/jumbo v0, "level"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v4, 0x6

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "sssaot"

    const-string/jumbo v2, "sttsoa"

    const/4 v4, 0x4

    const-string v2, "autmss"

    const-string/jumbo v2, "status"

    const/4 v4, 0x5

    invoke-virtual {p0, v2, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eq p0, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-ne p0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p0, 0x1

    :goto_1
    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const-string p0, "1"

    const-string p0, "1"

    const/4 v4, 0x5

    const-string p0, "1"

    const-string p0, "1"

    goto :goto_2

    :cond_2
    const-string p0, "0"

    const-string p0, "0"

    const/4 v4, 0x2

    const-string p0, "0"

    const-string p0, "0"

    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string p0, ":"

    const/4 v4, 0x1

    const-string p0, ":"

    const-string p0, ":"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p0

    :catchall_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x6

    return-object p0
.end method

.method public static N()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v2, "00"

    const-string v2, "00"

    const/4 v7, 0x6

    const-string v2, "00"

    const-string v2, "00"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v2, ":"

    const-string v2, ":"

    const/4 v7, 0x2

    const-string v2, ":"

    const-string v2, ":"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v1, Ljava/util/LinkedHashMap;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v2, "ardeobw.roa"

    const-string v2, "aah.dbrwero"

    const/4 v7, 0x4

    const-string v2, "earohbr.wdr"

    const-string/jumbo v2, "ro.hardware"

    const/4 v7, 0x1

    const-string v3, "fldhiuus"

    const-string/jumbo v3, "sdhfigul"

    const/4 v7, 0x7

    const-string v3, "hgsliodp"

    const-string v3, "goldfish"

    const/4 v7, 0x0

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const-string/jumbo v2, "nq.rele.qpkmoe"

    const-string/jumbo v2, "krme.ueplqoe.n"

    const/4 v7, 0x1

    const-string/jumbo v2, "r.skmreu.qleon"

    const-string/jumbo v2, "ro.kernel.qemu"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const-string v3, "1"

    const-string v3, "1"

    const-string v3, "1"

    const-string v3, "1"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v2, "ro.product.device"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v3, "ecemngq"

    const-string/jumbo v3, "rqceneg"

    const/4 v7, 0x1

    const-string/jumbo v3, "nercoig"

    const-string v3, "generic"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo v2, "mtolpbsod..orued"

    const-string v2, "eus.lctoddr.ompo"

    const/4 v7, 0x4

    const-string/jumbo v2, "ro.product.model"

    const/4 v7, 0x1

    const-string/jumbo v4, "sdk"

    const-string/jumbo v4, "skd"

    const/4 v7, 0x0

    const-string/jumbo v4, "sdk"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x3

    const-string/jumbo v2, "p.udmbucorn.aotr"

    const-string/jumbo v2, "tuam.prcbnrrdo.o"

    const/4 v7, 0x4

    const-string/jumbo v2, "rutb.pcpror.dand"

    const-string/jumbo v2, "ro.product.brand"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo v2, "pordtro.q.cuman"

    const-string/jumbo v2, "ternoro..umcadp"

    const/4 v7, 0x1

    const-string/jumbo v2, "meso.tcra.nprou"

    const-string/jumbo v2, "ro.product.name"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const-string/jumbo v2, "n.pmnutebir.idbfolrg"

    const-string/jumbo v2, "rrpbgbtdlion.uifi.ne"

    const/4 v7, 0x4

    const-string/jumbo v2, "n.npobrudgiei.firlto"

    const-string/jumbo v2, "ro.build.fingerprint"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v3, "ettu-bkes"

    const-string v3, "eks-stute"

    const/4 v7, 0x2

    const-string/jumbo v3, "ss-ettuke"

    const-string/jumbo v3, "test-keys"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v2, "pautrmepuoucrtoa.p.rdrc"

    const-string/jumbo v2, "potmcf.pd.rutareuaurroc"

    const/4 v7, 0x5

    const-string v2, "ao.puofaqrttruceurrdmc."

    const-string/jumbo v2, "ro.product.manufacturer"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v3, "uksnqn"

    const-string/jumbo v3, "nnqwuk"

    const/4 v7, 0x5

    const-string/jumbo v3, "nokmuw"

    const-string/jumbo v3, "unknow"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v5, ""

    const-string v5, ""

    const/4 v7, 0x3

    const-string v5, ""

    const-string v5, ""

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v3, v5}, Lz0/a;->f(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/16 v3, 0x31

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/16 v3, 0x30

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    return-object v0
.end method

.method private static O(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "iS.NoAKer_CSnasmE.EoOCEsrs_RidpSTAWTiod"

    const-string v0, "EisdEArnCmCespN.aT.sEonrTWOSiS_iAo_SKRd"

    const/4 v4, 0x0

    const-string v0, "_msndbisi_dESAo.OKWoRTCnSE.CreiTpSNAETa"

    const-string v0, "android.permission.ACCESS_NETWORK_STATE"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "veyictuinmnc"

    const-string/jumbo v1, "ntcmivtcniye"

    const-string v1, "connectivity"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast p0, Landroid/net/ConnectivityManager;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez p0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto/16 :goto_2

    :cond_1
    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-ne v1, v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "WIFI"

    const-string v0, "FWII"

    const/4 v4, 0x2

    const-string v0, "WIFI"

    const-string v0, "WIFI"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto/16 :goto_2

    :cond_2
    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v1, :cond_8

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq p0, v1, :cond_7

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eq p0, v2, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eq p0, v1, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eq p0, v1, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/16 v1, 0xb

    const/4 v4, 0x7

    if-ne p0, v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq p0, v1, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x5

    shr-int/2addr v4, v1

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq p0, v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x6

    const/4 v3, 0x2

    const/4 v3, 0x5

    if-eq p0, v1, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/16 v1, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eq p0, v1, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v1, 0x9

    const/4 v4, 0x3

    if-eq p0, v1, :cond_6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/16 v1, 0xa

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eq p0, v1, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v1, 0xc

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p0, v1, :cond_6

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/16 v1, 0xe

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eq p0, v1, :cond_6

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 v1, 0xf

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    if-ne p0, v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v1, 0xd

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne p0, v1, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v0, "4G"

    const-string v0, "4G"

    const/4 v4, 0x5

    const-string v0, "G4"

    const-string v0, "4G"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_2

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v0, "NpKOWN"

    const-string v0, "UNKNOW"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_2

    :cond_6
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v0, "3G"

    const-string v0, "G3"

    const/4 v4, 0x7

    const-string v0, "3G"

    const-string v0, "3G"

    const/4 v4, 0x0

    const/4 v3, 0x7

    goto :goto_2

    :cond_7
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, "G2"

    const-string v0, "2G"

    const/4 v4, 0x1

    const-string v0, "2G"

    const-string v0, "2G"
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_8
    :goto_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0
.end method

.method private static P()Ljava/lang/String;
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string v0, "0:00o0:0020::000:"

    const/4 v10, 0x1

    const-string v0, "::000200q:0::0000"

    const-string v0, "02:00:00:00:00:00"

    :try_start_0
    const/4 v10, 0x1

    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v1}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x5

    if-eqz v1, :cond_4

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-eqz v2, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    check-cast v2, Ljava/net/NetworkInterface;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v2, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v3, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string/jumbo v4, "lwsnb"

    const-string v4, "bn0lw"

    const/4 v10, 0x6

    const-string/jumbo v4, "wa0mn"

    const-string/jumbo v4, "wlan0"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-eqz v3, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getHardwareAddress()[B

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    if-nez v1, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object v0

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    array-length v3, v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v4, 0x0

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    move v5, v4

    const/4 v10, 0x4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v6, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-ge v5, v3, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x7

    aget-byte v7, v1, v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string v8, "02:%o"

    const-string v8, ":u20%"

    const/4 v10, 0x2

    const-string v8, "b2X%:"

    const-string v8, "%02X:"

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    and-int/lit16 v7, v7, 0xff

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    aput-object v7, v6, v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v8, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x3

    goto :goto_0

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-lez v1, :cond_3

    const/4 v9, 0x7

    move v10, v9

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    sub-int/2addr v1, v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object v0
.end method

.method private static Q()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v0, "nc/fxsufmuu/ispypde/cm0/rtu/foe/urcesspqpvcees_cqi/ya"

    const-string/jumbo v0, "yqmqyspp/cusus0/cc/faxe//ivsscuemo_udff/ctee_r/eripnp"

    const/4 v5, 0x3

    const-string/jumbo v0, "qmnfcoup0s/escv_i/_ecuey/pcpfeprfipx/sdqtc/rsasy/u/me"

    const-string v0, "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v2, Ljava/io/FileReader;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2, v0}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v3, 0x2000

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0, v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    :try_start_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    if-nez v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :try_start_3
    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :try_start_4
    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/io/Reader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object v1

    :cond_0
    :try_start_5
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    :goto_0
    :try_start_6
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/io/Reader;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_7

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_2

    :catchall_3
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :catchall_4
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :catchall_5
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    :try_start_7
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :catchall_6
    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :catchall_7
    :cond_2
    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v0, ""

    const/4 v5, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v0
.end method

.method private static R()Ljava/lang/String;
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string v0, "/rpopcnfqio/c"

    const/4 v8, 0x0

    const-string/jumbo v0, "pr/oucpcqnof/"

    const-string v0, "/proc/cpuinfo"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x7

    const-string v1, ""

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v2, 0x0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v3, Ljava/io/FileReader;

    const/4 v8, 0x1

    invoke-direct {v3, v0}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/16 v4, 0x2000

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v0, v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_0
    :try_start_2
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez v4, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v4, ":"

    const-string v4, ":"

    const/4 v8, 0x1

    const-string v4, ":"

    const-string v4, ":"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    array-length v4, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-le v4, v5, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x7

    move v8, v7

    aget-object v4, v2, v4

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v6, "MosPBIos"

    const-string v6, "PosMIoSB"

    const/4 v8, 0x7

    const-string v6, "PBomMgoS"

    const-string v6, "BogoMIPS"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v4, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v4, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    aget-object v2, v2, v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :cond_1
    :try_start_3
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/io/Reader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :goto_0
    :try_start_4
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_2

    :catchall_1
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :catchall_2
    move-object v2, v3

    move-object v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto :goto_1

    :catchall_3
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v2, :cond_2

    :try_start_5
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/io/Reader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :catchall_4
    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v0, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    goto :goto_0

    :catchall_5
    :cond_3
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    return-object v1
.end method

.method private static S()Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    check-cast v1, Ljava/net/NetworkInterface;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    move-result-object v1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast v2, Ljava/net/InetAddress;

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {v2}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    instance-of v3, v2, Ljava/net/Inet4Address;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-virtual {v2}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object v0

    :catchall_0
    :cond_2
    const/4 v4, 0x7

    move v5, v4

    const-string v0, ""

    const/4 v5, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    return-object v0
.end method

.method public static a()Lcom/alipay/security/mobile/module/b/c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/alipay/security/mobile/module/b/c;->a:Lcom/alipay/security/mobile/module/b/c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "saAoonmDimPiiESnNT_sd.errTOoA_pR.Ed"

    const-string v0, "eTEmNdosS.oaRpOiPiAr_mTr.d_AEsHDnin"

    const/4 v4, 0x4

    const-string v0, "POAmdbEsTod.RiEHpraTSs_or.enAN_niDi"

    const-string v0, "android.permission.READ_PHONE_STATE"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v2, "euoho"

    const-string/jumbo v2, "ohneo"

    const/4 v4, 0x7

    const-string/jumbo v2, "nppeh"

    const-string/jumbo v2, "phone"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :catchall_0
    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v1
.end method

.method private static c(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p0}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    move p0, p1

    move p0, p1

    const/4 v2, 0x7

    move p0, p1

    move p0, p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    move p0, v0

    move p0, v0

    const/4 v2, 0x0

    move p0, v0

    move p0, v0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public static d()Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Environment;->getDataDirectory()Ljava/io/File;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v1, Landroid/os/StatFs;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/os/StatFs;->getBlockSize()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    int-to-long v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1}, Landroid/os/StatFs;->getAvailableBlocks()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    int-to-long v0, v0

    const/4 v5, 0x7

    mul-long/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v0
.end method

.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const-string v0, "erNET_PEqbTsiEnHSasA.on.RrD_AiOipdm"

    const-string v0, "DeRnpbrsTiEsO_.ioAPnaH.SrTNoAE_dEim"

    const-string v0, "_nsrTAiHoEiEdRNamP.A.To_issnSpdErOD"

    const-string v0, "android.permission.READ_PHONE_STATE"

    const/4 v2, 0x0

    move v3, v2

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    return-object v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "upnmh"

    const-string v0, "huonp"

    const/4 v3, 0x1

    const-string/jumbo v0, "pehoo"

    const-string/jumbo v0, "phone"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getSubscriberId()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    :cond_1
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    if-nez p0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    return-object v1
.end method

.method public static f()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v3, "monutbd"

    const-string/jumbo v3, "ptounmd"

    const/4 v7, 0x2

    const-string/jumbo v3, "tonuemu"

    const-string/jumbo v3, "mounted"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {}, Lz0/a;->a()Ljava/io/File;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v3, Landroid/os/StatFs;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v3, v2}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroid/os/StatFs;->getBlockSize()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    int-to-long v4, v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroid/os/StatFs;->getAvailableBlocks()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    int-to-long v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    mul-long/2addr v4, v0

    move-wide v0, v4

    :catchall_0
    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-object v0
.end method

.method public static g(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    const/4 v0, 0x0

    move v3, v0

    :try_start_0
    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "qno_r_epiaeomdlp"

    const-string/jumbo v1, "padlnaorqo_mei_e"

    const/4 v3, 0x0

    const-string v1, "apirlo_aqe_noemd"

    const-string v1, "airplane_mode_on"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, v1, v0}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ne v0, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p0, "1"

    const-string p0, "1"

    const/4 v3, 0x4

    const-string p0, "1"

    const-string p0, "1"

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0
.end method

.method public static h()Ljava/lang/String;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v0, "00s0000000s00000"

    const-string v0, "00s0000000000000"

    const/4 v9, 0x1

    const-string v0, "000m000000000000"

    const-string v0, "0000000000000000"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v8, 0x2

    move v9, v8

    new-instance v2, Ljava/io/FileInputStream;

    const/4 v9, 0x2

    new-instance v3, Ljava/io/File;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string v4, "fop/onoi/purm"

    const-string v4, "/inmpou/ropcf"

    const/4 v9, 0x4

    const-string v4, "fcinubopo//cr"

    const-string v4, "/proc/cpuinfo"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v2, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    :try_start_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v3, Ljava/io/InputStreamReader;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {v3, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v4, Ljava/io/LineNumberReader;

    const/4 v9, 0x6

    invoke-direct {v4, v3}, Ljava/io/LineNumberReader;-><init>(Ljava/io/Reader;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    move v5, v1

    move v5, v1

    const/4 v9, 0x5

    move v5, v1

    move v5, v1

    :goto_0
    const/4 v9, 0x0

    const/16 v6, 0x64

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-ge v5, v6, :cond_1

    :try_start_3
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v4}, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v6, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v7, "uearlS"

    const-string v7, "Serial"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v6, v7}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-ltz v7, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string v5, ":"

    const-string v5, ":"

    const/4 v9, 0x5

    const-string v5, ":"

    const-string v5, ":"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v6, v5}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    add-int/2addr v5, v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v6, v5, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :catchall_0
    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_3

    :cond_1
    :goto_1
    :try_start_4
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/io/Reader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    :try_start_5
    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v3}, Ljava/io/InputStreamReader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    :goto_2
    :try_start_6
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_8

    const/4 v9, 0x3

    goto :goto_4

    :catchall_3
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_3

    :catchall_4
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :catchall_5
    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v1, :cond_2

    :try_start_7
    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :catchall_6
    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eqz v3, :cond_3

    :try_start_8
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/io/InputStreamReader;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_7

    :catchall_7
    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v2, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_2

    :catchall_8
    :cond_4
    :goto_4
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez v0, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x1

    const-string v0, ""

    const-string v0, ""

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-object v0
.end method

.method public static i(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo v1, "oopid"

    const-string/jumbo v1, "odiao"

    const/4 v8, 0x2

    const-string v1, "audio"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    check-cast p0, Landroid/media/AudioManager;

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {p0}, Landroid/media/AudioManager;->getRingerMode()I

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-nez v1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    move v1, v2

    move v1, v2

    const/4 v8, 0x0

    move v1, v2

    move v1, v2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v1, v3

    move v1, v3

    const/4 v8, 0x6

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0, v3}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p0, v2}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v4, 0x2

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {p0, v4}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v5, 0x3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0, v5}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v6, 0x4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0, v6}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo v6, "odeimbgrrn"

    const/4 v8, 0x7

    const-string/jumbo v6, "noeridrgqe"

    const-string/jumbo v6, "ringermode"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0, v6, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v1, "clal"

    const-string v1, "allc"

    const/4 v8, 0x3

    const-string/jumbo v1, "lcal"

    const-string v1, "call"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo v1, "mtsess"

    const-string/jumbo v1, "system"

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const-string/jumbo v1, "nigr"

    const-string/jumbo v1, "nirg"

    const/4 v8, 0x5

    const-string/jumbo v1, "nrig"

    const-string/jumbo v1, "ring"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v1, "ciumm"

    const-string/jumbo v1, "music"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v1, "lrmao"

    const-string/jumbo v1, "luram"

    const/4 v8, 0x7

    const-string v1, "bamar"

    const-string v1, "alarm"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-object p0
.end method

.method public static k(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "oupne"

    const-string/jumbo v1, "oeppn"

    const/4 v3, 0x4

    const-string/jumbo v1, "pepoh"

    const-string/jumbo v1, "phone"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getNetworkOperatorName()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :catchall_0
    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo p0, "lnlu"

    const-string/jumbo p0, "null"

    const/4 v3, 0x0

    const-string/jumbo p0, "ulln"

    const-string/jumbo p0, "null"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p0, :cond_2

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public static l()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->Q()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->R()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method public static m(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const/4 v4, 0x0

    move v5, v4

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v1, "qeqors"

    const-string/jumbo v1, "seqonr"

    const/4 v5, 0x7

    const-string v1, "eosnsr"

    const-string/jumbo v1, "sensor"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast p0, Landroid/hardware/SensorManager;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p0, :cond_1

    const/4 v4, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-lez v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    check-cast v2, Landroid/hardware/Sensor;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/hardware/Sensor;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/hardware/Sensor;->getVersion()I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2}, Landroid/hardware/Sensor;->getVendor()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-static {p0}, Lz0/a;->j(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x4

    const-string v0, ""

    const-string v0, ""

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v0
.end method

.method public static n()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/io/FileReader;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v2, "ocsm/r/uifpno"

    const-string v2, "cos/upo/cfrin"

    const/4 v6, 0x4

    const-string v2, "/cpnop/iuofor"

    const-string v2, "/proc/cpuinfo"

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_5

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v2, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v3, "b://m"

    const-string v3, "//+m:"

    const/4 v6, 0x7

    const-string v3, ":u//s"

    const-string v3, ":\\s+"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    array-length v3, v0

    const/4 v6, 0x7

    const/4 v4, 0x6

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    if-le v3, v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    aget-object v0, v0, v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    :try_start_3
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :try_start_4
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object v0

    :cond_0
    :try_start_5
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    :goto_0
    :try_start_6
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_2

    :catchall_3
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :catchall_4
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_1

    :catchall_5
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    :try_start_7
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/Reader;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :catchall_6
    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x2

    goto :goto_0

    :catchall_7
    :cond_2
    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x2

    const-string v0, ""

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object v0
.end method

.method public static o(Landroid/content/Context;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Lorg/json/JSONArray;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const-string/jumbo v1, "opsneo"

    const-string/jumbo v1, "osneos"

    const/4 v6, 0x1

    const-string/jumbo v1, "ssqron"

    const-string/jumbo v1, "sensor"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast p0, Landroid/hardware/SensorManager;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz p0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v1, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz p0, :cond_1

    const/4 v5, 0x5

    move v6, v5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-lez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v1, Landroid/hardware/Sensor;

    const/4 v6, 0x3

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v2, Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v3, "mnae"

    const-string/jumbo v3, "mnea"

    const/4 v6, 0x2

    const-string/jumbo v3, "mane"

    const-string/jumbo v3, "name"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/hardware/Sensor;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "nessivr"

    const-string/jumbo v3, "version"

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/hardware/Sensor;->getVersion()I

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v3, "nobmev"

    const-string v3, "evdonb"

    const/4 v6, 0x3

    const-string v3, "ernvod"

    const-string/jumbo v3, "vendor"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/hardware/Sensor;->getVendor()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object p0
.end method

.method public static p()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v0, "m/rf/bipmonuo"

    const-string v0, "f//monumopcir"

    const/4 v7, 0x2

    const-string/jumbo v0, "mpn/eiuoo/cmf"

    const-string v0, "/proc/meminfo"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-wide/16 v1, 0x0

    const/4 v7, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x6

    move v7, v6

    const/4 v3, 0x1

    const/4 v3, 0x0

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v4, Ljava/io/FileReader;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {v4, v0}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/16 v5, 0x2000

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v0, v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v5, "//+s"

    const-string v5, "/s+/"

    const/4 v7, 0x1

    const-string v5, "/s/+"

    const-string v5, "\\s+"

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v5, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    aget-object v3, v3, v5

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    int-to-long v1, v1

    :cond_0
    :try_start_3
    invoke-virtual {v4}, Ljava/io/Reader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :goto_0
    :try_start_4
    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_2

    :catchall_1
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :catchall_2
    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_1

    :catchall_3
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v3, :cond_1

    :try_start_5
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/io/Reader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :catchall_4
    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_0

    :catchall_5
    :cond_2
    :goto_2
    const/4 v7, 0x6

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-object v0
.end method

.method public static q(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v1, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "*"

    const-string v1, "*"

    const/4 v3, 0x1

    const-string v1, "*"

    const-string v1, "*"

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public static r()Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Environment;->getDataDirectory()Ljava/io/File;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Landroid/os/StatFs;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/os/StatFs;->getBlockSize()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-long v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/os/StatFs;->getBlockCount()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    int-to-long v0, v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    mul-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v5, 0x0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v0
.end method

.method public static s(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget p0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0

    :catchall_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static t()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v3, "pumdtnp"

    const-string/jumbo v3, "pmedtnu"

    const/4 v7, 0x4

    const-string/jumbo v3, "mounted"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v2, :cond_0

    const/4 v7, 0x7

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v3, Landroid/os/StatFs;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v3, v2}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroid/os/StatFs;->getBlockSize()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    int-to-long v4, v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/os/StatFs;->getBlockCount()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    mul-long/2addr v4, v0

    move-wide v0, v4

    :catchall_0
    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    return-object v0
.end method

.method public static u(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0

    :catchall_0
    const/4 v2, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static v()Ljava/lang/String;
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v10, 0x0

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x4

    const-string v1, ""

    const-string v1, ""

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string/jumbo v2, "trrsetmPqeo.aidiqdpssSnryo."

    const-string/jumbo v2, "rooeiiarqy.Pdtsnr.spotSesmd"

    const/4 v10, 0x3

    const-string/jumbo v2, "posrmdiet.rdrePissoasynS.te"

    const-string v2, "android.os.SystemProperties"

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const-string v4, "etg"

    const-string v4, "get"

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v7, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    aput-object v0, v6, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v8, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    aput-object v0, v6, v8

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v2, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-array v2, v5, [Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string v4, "eanmaiebmrobgdsvs.s."

    const-string/jumbo v4, "iesdearbvmnsoa.gsbn."

    const/4 v10, 0x6

    const-string v4, ".gaboavnm.besordsnis"

    const-string v4, "gsm.version.baseband"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    aput-object v4, v2, v7

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string v4, "essnab gme"

    const-string/jumbo v4, "mnemea ssg"

    const/4 v10, 0x2

    const-string v4, " asgesueno"

    const-string/jumbo v4, "no message"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    aput-object v4, v2, v8

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v10, 0x5

    goto :goto_0

    :catchall_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    if-nez v0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    goto :goto_1

    :cond_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_1
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-object v1
.end method

.method public static w(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v0, "EiEAdCFp_a.WT.inoCTdS_IoSoASsrepsIrn"

    const-string v0, "eoSSorsT_ApT.Esia_FiEoCmn.WdrdIAnSCI"

    const/4 v3, 0x7

    const-string/jumbo v0, "rosSpAoAqC_rWaIndmIET.idieSiECnsT_F."

    const-string v0, "android.permission.ACCESS_WIFI_STATE"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v1

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v0, "fiiw"

    const-string v0, "fiwi"

    const-string/jumbo v0, "ifiw"

    const-string/jumbo v0, "wifi"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    check-cast p0, Landroid/net/wifi/WifiManager;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/net/wifi/WifiInfo;->getMacAddress()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string p0, "0bs:00000:0:200:0"

    const-string p0, "0000:b2:000::0000"

    const/4 v3, 0x7

    const-string p0, "0::m:000000020:00"

    const-string p0, "02:00:00:00:00:00"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p0, :cond_2

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {}, Lcom/alipay/security/mobile/module/b/c;->P()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0

    :catchall_0
    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    return-object v1
.end method

.method public static x()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_1

    :cond_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public static y(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, "SEiro_dimOrpdsP.nAT_DNsRHeAoioE.Tan"

    const-string v0, "android.permission.READ_PHONE_STATE"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/alipay/security/mobile/module/b/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    move v3, v2

    return-object v1

    :cond_0
    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, "bnueh"

    const-string/jumbo v0, "nuhep"

    const/4 v3, 0x6

    const-string v0, "eunoh"

    const-string/jumbo v0, "phone"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getSimSerialNumber()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p0, :cond_2

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    :cond_1
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    :catchall_1
    :cond_2
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v1
.end method

.method public static z()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2, v2}, Ljava/util/TimeZone;->getDisplayName(ZI)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method


# virtual methods
.method public final j()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "yip/v/tpcmsueseesssdy/p/"

    const-string/jumbo v1, "ves/eesptsm/s/sipcyd/uy/"

    const/4 v3, 0x3

    const-string v1, "edem/yusqss/ic/c/e/ssvyt"

    const-string v1, "/sys/devices/system/cpu/"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v1, Lcom/alipay/security/mobile/module/b/d;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/alipay/security/mobile/module/b/d;-><init>(Lcom/alipay/security/mobile/module/b/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    array-length v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :catchall_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v0, "1"

    const-string v0, "1"

    const/4 v3, 0x5

    const-string v0, "1"

    const-string v0, "1"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method
