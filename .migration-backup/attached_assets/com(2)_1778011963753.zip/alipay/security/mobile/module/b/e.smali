.class public final Lcom/alipay/security/mobile/module/b/e;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/alipay/security/mobile/module/b/e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    new-instance v0, Lcom/alipay/security/mobile/module/b/e;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/alipay/security/mobile/module/b/e;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/alipay/security/mobile/module/b/e;->a:Lcom/alipay/security/mobile/module/b/e;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static a()Lcom/alipay/security/mobile/module/b/e;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~csn-~. 4r~lKbt@~ @oof~~ i~ ~@~@a@s@u~tof~o1v @~@~i ~@ ~~@ @@~@lyo MSd@~@ ~b@~  @@io@  /  @~ b~m"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/alipay/security/mobile/module/b/e;->a:Lcom/alipay/security/mobile/module/b/e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method private static b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v8, 0x5

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v1, "Sestnirosoo.rPta.mdrdspeeys"

    const-string v1, "dasmotoesePdeSiito.mrnspryr"

    const-string v1, "android.os.SystemProperties"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v2, "egt"

    const-string/jumbo v2, "teg"

    const/4 v8, 0x4

    const-string v2, "etg"

    const-string v2, "get"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v3, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x4

    or-int/2addr v8, v7

    const/4 v5, 0x0

    xor-int/2addr v8, v5

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    aput-object v0, v4, v5

    const/4 v8, 0x4

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    move v8, v7

    aput-object v0, v4, v6

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-array v1, v3, [Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x3

    aput-object p0, v1, v5

    const/4 v8, 0x4

    const/4 v7, 0x4

    aput-object p1, v1, v6

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 p0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    return-object p0

    :catch_0
    const/4 v7, 0x2

    move v8, v7

    return-object p1
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 9

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x1

    move v7, v0

    move v7, v0

    :try_start_0
    const/4 v8, 0x1

    sget-object v1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v2, "slodomgh"

    const-string/jumbo v2, "sgimodlh"

    const/4 v8, 0x2

    const-string/jumbo v2, "isgflbod"

    const-string v2, "goldfish"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v1, :cond_5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget-object v1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v3, "skd"

    const-string/jumbo v3, "kds"

    const-string/jumbo v3, "sdk"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-nez v1, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    sget-object v1, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    const-string/jumbo v3, "nrgoeeu"

    const-string/jumbo v3, "rncgoee"

    const/4 v8, 0x3

    const-string/jumbo v3, "pgrncei"

    const-string v3, "generic"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto/16 :goto_3

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const-string v1, "bphqe"

    const-string v1, "bhpoe"

    const/4 v8, 0x0

    const-string/jumbo v1, "phone"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    check-cast v1, Landroid/telephony/TelephonyManager;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v1, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-nez v3, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    move v4, v0

    move v4, v0

    const/4 v8, 0x6

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-ge v4, v3, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {v5}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-nez v5, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/16 v6, 0x30

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-eq v5, v6, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    move v1, v0

    move v1, v0

    const/4 v8, 0x1

    move v1, v0

    move v1, v0

    const/4 v7, 0x7

    move v8, v7

    goto :goto_2

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    move v1, v2

    move v1, v2

    const/4 v8, 0x6

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v1, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    return v2

    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string/jumbo v1, "uas_dodndi"

    const-string v1, "ddoniduar_"

    const/4 v8, 0x6

    const-string v1, "darmidno_d"

    const-string v1, "android_id"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {p0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    return p0

    :cond_5
    :goto_3
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    return v2

    :catch_0
    const/4 v8, 0x3

    return v0
.end method

.method public static d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const-string/jumbo v0, "oddaorp"

    const-string/jumbo v0, "pnradod"

    const/4 v2, 0x1

    const-string v0, "drdonba"

    const-string v0, "android"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public static e()Z
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v0, "u//qnb"

    const-string v0, "//qnib"

    const/4 v7, 0x7

    const-string/jumbo v0, "npib/s"

    const-string v0, "/sbin/"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v1, "ibnv/edsqor/"

    const-string v1, "/rsoi/ednbvn"

    const/4 v7, 0x4

    const-string v1, "dbso//einvn/"

    const-string v1, "/vendor/bin/"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v2, "tibmyenm/sm/"

    const-string/jumbo v2, "nyemm/bists/"

    const/4 v7, 0x6

    const-string v2, "/e/nosbys/im"

    const-string v2, "/system/bin/"

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v3, "iy/tosmb/xs/e"

    const/4 v7, 0x6

    const-string/jumbo v3, "isnmyb/b//ets"

    const-string v3, "/system/xbin/"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const-string/jumbo v4, "yemsn/ubsst/i"

    const-string v4, "bsstsb/ynmi/e"

    const/4 v7, 0x1

    const-string/jumbo v4, "setsmispy/b//"

    const-string v4, "/system/sbin/"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    const/4 v7, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v3, 0x5

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-ge v2, v3, :cond_1

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v3, Ljava/io/File;

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    aget-object v5, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v5, "us"

    const-string/jumbo v5, "su"

    const/4 v7, 0x6

    const-string/jumbo v5, "su"

    const-string/jumbo v5, "su"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    return v0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :catch_0
    :cond_1
    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return v1
.end method

.method public static f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Landroid/os/Build;->BOARD:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static h()Ljava/lang/String;
    .locals 3

    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public static j()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Build$VERSION;->INCREMENTAL:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public static k()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public static l()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public static m()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static n()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public static o()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    sget-object v0, Landroid/os/Build$VERSION;->SDK:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method public static p()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Landroid/os/Build;->TAGS:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static q()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, "enkmeorlq.euuq"

    const-string/jumbo v0, "uneermulrq.oke"

    const/4 v3, 0x0

    const-string v0, "ees.m.olurenrq"

    const-string/jumbo v0, "ro.kernel.qemu"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "0"

    const-string v1, "0"

    const/4 v3, 0x2

    const-string v1, "0"

    const-string v1, "0"

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/alipay/security/mobile/module/b/e;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method
