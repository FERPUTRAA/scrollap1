.class public final synthetic Lcom/alipay/security/mobile/module/b/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b slt yf~o@d~ @   @1i ~4~@r~@o@@@~@saK@o So~n// @b@m-~@@~@~ ~~~~ ~~@l o~i ~~~ @.@b@iof~ ~Mt @ vc"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {}, Landroid/os/Build;->getSerial()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method
