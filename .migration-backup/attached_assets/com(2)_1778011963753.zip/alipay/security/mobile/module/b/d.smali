.class final Lcom/alipay/security/mobile/module/b/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/FileFilter;


# instance fields
.field final synthetic a:Lcom/alipay/security/mobile/module/b/c;


# direct methods
.method constructor <init>(Lcom/alipay/security/mobile/module/b/c;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/security/mobile/module/b/d;->a:Lcom/alipay/security/mobile/module/b/c;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final accept(Ljava/io/File;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@s~ u~  @Mino@io~~l@ob@-~/@ ~1t @o~@ b @ ~~~ sc@ S~K@@@fy@v a~@~.@~4~/i@dt~ @o@f  ~o~~ ml @r~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-string/jumbo v0, "p[sm]uc+-"

    const-string v0, "0us]+c[p-"

    const/4 v2, 0x7

    const-string v0, "cp9]ou+0["

    const-string v0, "cpu[0-9]+"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p1}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method
