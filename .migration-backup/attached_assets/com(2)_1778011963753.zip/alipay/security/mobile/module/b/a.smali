.class public final Lcom/alipay/security/mobile/module/b/a;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/alipay/security/mobile/module/b/a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lcom/alipay/security/mobile/module/b/a;

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {v0}, Lcom/alipay/security/mobile/module/b/a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Lcom/alipay/security/mobile/module/b/a;->a:Lcom/alipay/security/mobile/module/b/a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static a()Lcom/alipay/security/mobile/module/b/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sf~ ~~~@mb~.@@  ~ o@@i@@ @@o @~~ iyl@sit~~bKoMv~c bof  odu ~  @@~-@@@ao ~r@ @4n ~/1~@~@/tS~l~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/alipay/security/mobile/module/b/a;->a:Lcom/alipay/security/mobile/module/b/a;

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/16 v1, 0x10

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const-string p0, "00sm."

    const-string p0, ".0s00"

    const/4 v3, 0x0

    const-string p0, ".000o"

    const-string p0, "0.0.0"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0
.end method
