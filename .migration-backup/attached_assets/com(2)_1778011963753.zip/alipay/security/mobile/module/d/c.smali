.class final Lcom/alipay/security/mobile/module/d/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/alipay/security/mobile/module/d/b;


# direct methods
.method constructor <init>(Lcom/alipay/security/mobile/module/d/b;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alipay/security/mobile/module/d/c;->a:Lcom/alipay/security/mobile/module/d/b;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~/KM~ b @@td~n@i ~~~~@ @~f iru@o@lt~~~ ~~@@@i~o1@v@~S  4cl~oo @@ bob  f@ ao~@~-m~@~~ sy@ @~/ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/c;->a:Lcom/alipay/security/mobile/module/d/b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/alipay/security/mobile/module/d/b;->c(Lcom/alipay/security/mobile/module/d/b;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void

    :catch_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/alipay/security/mobile/module/d/d;->c(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
