.class public final Lcom/alipay/security/mobile/module/d/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/security/mobile/module/d/a;->a:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/alipay/security/mobile/module/d/a;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/alipay/security/mobile/module/d/a;->c:Ljava/lang/String;

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/alipay/security/mobile/module/d/a;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-object p5, p0, Lcom/alipay/security/mobile/module/d/a;->e:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p6, p0, Lcom/alipay/security/mobile/module/d/a;->f:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p7, p0, Lcom/alipay/security/mobile/module/d/a;->g:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~ms@~o~@@@~b @ o@~ fc~-/@4~~o ~ ~ d ~s@~r~.tKb@oo tM~@@@@n@@i /y~  l~~ oi~~ai~f ul@@S  @~@@~ v1 "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v1, "dSHmdHSssMSymmsMy"

    const-string v1, "SdsmssySymMSyHMHd"

    const/4 v7, 0x2

    const-string v1, "SsmyoydSmMdsyHMyS"

    const-string/jumbo v1, "yyyyMMddHHmmssSSS"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v1, v0}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v2, ","

    const-string v2, ","

    const-string v2, ","

    const-string v2, ","

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/alipay/security/mobile/module/d/a;->a:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/alipay/security/mobile/module/d/a;->b:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/alipay/security/mobile/module/d/a;->c:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/alipay/security/mobile/module/d/a;->d:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->e:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/16 v4, 0x14

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->e:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ge v0, v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    iget-object v5, p0, Lcom/alipay/security/mobile/module/d/a;->e:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v5, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v5, p0, Lcom/alipay/security/mobile/module/d/a;->e:Ljava/lang/String;

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->f:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez v0, :cond_3

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->f:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ge v0, v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_2

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v5, p0, Lcom/alipay/security/mobile/module/d/a;->f:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v5, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v5, p0, Lcom/alipay/security/mobile/module/d/a;->f:Ljava/lang/String;

    :goto_3
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->g:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez v0, :cond_5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/a;->g:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ge v0, v4, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_4

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/alipay/security/mobile/module/d/a;->g:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_5

    :cond_5
    :goto_4
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/alipay/security/mobile/module/d/a;->g:Ljava/lang/String;

    :goto_5
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object v0
.end method
