.class public final Lcom/alipay/security/mobile/module/d/d;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""

.field private static b:Ljava/lang/String; = ""

.field private static c:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static declared-synchronized a(Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sb@cut ~~  o@m@@@~t~o  @1l ~~i~ /@ l-~o@~@@v/~b@@i@o~s@ ~b 4~ Md o ~@~~i@f @K@af o~S.@~n~y~@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/alipay/security/mobile/module/d/d;->d(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x5

    throw p0
.end method

.method public static declared-synchronized b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v2, 0x1

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput-object p0, Lcom/alipay/security/mobile/module/d/d;->a:Ljava/lang/String;

    const/4 v2, 0x0

    sput-object p1, Lcom/alipay/security/mobile/module/d/d;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object p2, Lcom/alipay/security/mobile/module/d/d;->c:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    monitor-exit v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw p0
.end method

.method public static declared-synchronized c(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v2, Ljava/io/StringWriter;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v3, Ljava/io/PrintWriter;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v3, v2}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x3

    const-string p0, ""

    const-string p0, ""

    :goto_0
    const/4 v5, 0x5

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/alipay/security/mobile/module/d/d;->d(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw p0
.end method

.method private static declared-synchronized d(Ljava/util/List;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v7, 0x7

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const-class v0, Lcom/alipay/security/mobile/module/d/d;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget-object v1, Lcom/alipay/security/mobile/module/d/d;->b:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v1, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v1, Lcom/alipay/security/mobile/module/d/d;->c:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-static {v1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto/16 :goto_2

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v2, Lcom/alipay/security/mobile/module/d/d;->c:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x7

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v4, ", "

    const-string v4, ", "

    const/4 v7, 0x3

    const-string v4, ", "

    const-string v4, ", "

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string p0, "/n"

    const-string/jumbo p0, "n/"

    const/4 v7, 0x4

    const-string/jumbo p0, "n/"

    const-string p0, "\n"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance p0, Ljava/io/File;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v2, Lcom/alipay/security/mobile/module/d/d;->a:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {p0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v2, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance p0, Ljava/io/File;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget-object v2, Lcom/alipay/security/mobile/module/d/d;->a:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget-object v3, Lcom/alipay/security/mobile/module/d/d;->b:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {p0, v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-nez v2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/io/File;->createNewFile()Z

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->length()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    int-to-long v4, v4

    const/4 v7, 0x7

    add-long/2addr v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const-wide/32 v2, 0xc800

    const-wide/32 v2, 0xc800

    const/4 v7, 0x4

    const-wide/32 v2, 0xc800

    const-wide/32 v2, 0xc800

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    cmp-long v2, v4, v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-gtz v2, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v2, Ljava/io/FileWriter;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {v2, p0, v3}, Ljava/io/FileWriter;-><init>(Ljava/io/File;Z)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_1

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v2, Ljava/io/FileWriter;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v2, p0}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V

    :goto_1
    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, p0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/io/Writer;->flush()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/io/Writer;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    monitor-exit v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    return-void

    :catch_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    monitor-exit v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-void

    :cond_5
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    monitor-exit v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    throw p0
.end method
