.class public final Lcom/alipay/security/mobile/module/d/b;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/io/File;

.field private b:Le1/a;


# direct methods
.method public constructor <init>(Ljava/lang/String;Le1/a;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->b:Le1/a;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Ljava/io/File;

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/alipay/security/mobile/module/d/b;->b:Le1/a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "los.o~~i@ v@@~@@ @~-M @i ~@~Sf@ ~o  ~  dfb  4aco/@tbo@@yt @~~@i ~  ~~~~mol~@nu~@@1 ~@~K~s@~ @/r~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "ytpe"

    const-string v1, "eytp"

    const-string v1, "eypt"

    const-string/jumbo v1, "type"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "di"

    const/4 v4, 0x1

    const-string v2, "di"

    const-string/jumbo v2, "id"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v1, "rosre"

    const/4 v4, 0x1

    const-string v1, "eromr"

    const-string v1, "error"

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p0

    :catch_0
    const/4 v4, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p0
.end method

.method static synthetic c(Lcom/alipay/security/mobile/module/d/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/alipay/security/mobile/module/d/b;->d()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private declared-synchronized d()V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    monitor-exit p0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-void

    :cond_0
    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v0, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    array-length v0, v0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto/16 :goto_2

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    array-length v2, v1

    const/4 v7, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v3, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-ge v4, v2, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    aget-object v5, v1, v4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x6

    const/4 v7, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v0}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/lit8 v1, v1, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v5, Ljava/text/SimpleDateFormat;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v6, "MymMoydy"

    const-string/jumbo v6, "yydmMMyy"

    const/4 v8, 0x6

    const-string/jumbo v6, "yddyMbyM"

    const-string/jumbo v6, "yyyyMMdd"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v5, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v5, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v4, "gl.o"

    const-string/jumbo v4, "l.og"

    const/4 v8, 0x6

    const-string v4, ".olg"

    const-string v4, ".log"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v4, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v4, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-ge v1, v4, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    monitor-exit p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-void

    :cond_3
    :try_start_2
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    sub-int/2addr v1, v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v2, v2, -0x1

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v4, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v4, v1}, Lz0/b;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/alipay/security/mobile/module/d/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v4, p0, Lcom/alipay/security/mobile/module/d/b;->b:Le1/a;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {v4, v1}, Le1/a;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-nez v1, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    add-int/lit8 v2, v2, -0x1

    :cond_5
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-ge v3, v2, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v4, Ljava/io/File;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v5, p0, Lcom/alipay/security/mobile/module/d/b;->a:Ljava/io/File;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v4, v5, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_1

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    monitor-exit p0

    const/4 v8, 0x6

    return-void

    :cond_7
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    monitor-exit p0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    monitor-exit p0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    throw v0
.end method


# virtual methods
.method public final b()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v1, Lcom/alipay/security/mobile/module/d/c;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/alipay/security/mobile/module/d/c;-><init>(Lcom/alipay/security/mobile/module/d/b;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method
