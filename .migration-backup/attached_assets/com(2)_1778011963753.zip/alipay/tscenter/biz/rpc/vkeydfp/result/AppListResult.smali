.class public Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/AppListResult;
.super Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public appListData:Ljava/lang/String;

.field public appListVer:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;-><init>()V

    const/4 v1, 0x6

    return-void
.end method
