.class public Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/DeviceDataReportResult;
.super Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public apdid:Ljava/lang/String;

.field public appListVer:Ljava/lang/String;

.field public bugTrackSwitch:Ljava/lang/String;

.field public currentTime:Ljava/lang/String;

.field public token:Ljava/lang/String;

.field public version:Ljava/lang/String;

.field public vkeySwitch:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
