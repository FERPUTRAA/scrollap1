.class public Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/AppListCmdResult;
.super Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/AppListResult;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public needRetry:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/AppListResult;-><init>()V

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/AppListCmdResult;->needRetry:Z

    const/4 v2, 0x6

    return-void
.end method
