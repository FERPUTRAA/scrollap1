.class public Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public resultCode:Ljava/lang/String;

.field public success:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/alipay/tscenter/biz/rpc/vkeydfp/result/BaseResult;->success:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method
