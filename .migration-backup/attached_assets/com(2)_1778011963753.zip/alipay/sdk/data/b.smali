.class public Lcom/alipay/sdk/data/b;
.super Ljava/lang/Object;


# static fields
.field private static final d:Ljava/lang/String; = "virtualImeiAndImsi"

.field private static final e:Ljava/lang/String; = "virtual_imei"

.field private static final f:Ljava/lang/String; = "virtual_imsi"

.field private static volatile g:Lcom/alipay/sdk/data/b;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x6

    const-string/jumbo v0, "lssastdin-d-"

    const-string/jumbo v0, "lssdita--knd"

    const/4 v4, 0x3

    const-string/jumbo v0, "kinmadsdel-t"

    const-string/jumbo v0, "sdk-and-lite"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/data/b;->b:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/alipay/sdk/app/c;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/c;->c()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/alipay/sdk/data/b;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v2, 0x5f

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/data/b;->b:Ljava/lang/String;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ @~os r. @o @Sa~~@1~iv~M@@~@  / @@ ~l~~~~~d~~K@ n~u4~-y/@o@it@ t   o o@ lb~~@fo~@b~ ~i@fo@~b@m "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "("

    const-string v2, "("

    const/4 v4, 0x6

    const-string v2, "("

    const-string v2, "("

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, ";"

    const-string v1, ";"

    const/4 v4, 0x6

    const-string v1, ";"

    const-string v1, ";"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string p0, ")"

    const-string p0, ")"

    const/4 v3, 0x4

    and-int/2addr v4, v3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0

    :catch_0
    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p0
.end method

.method static synthetic c(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/data/b;->h(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public static declared-synchronized e(Ljava/lang/String;)V
    .locals 5

    const/4 v3, 0x3

    const-class v0, Lcom/alipay/sdk/data/b;

    const-class v0, Lcom/alipay/sdk/data/b;

    const-class v0, Lcom/alipay/sdk/data/b;

    const-class v0, Lcom/alipay/sdk/data/b;

    const/4 v4, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const-string/jumbo v2, "kydmreeti"

    const/4 v4, 0x2

    const-string/jumbo v2, "trideskey"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v1, v2, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    sput-object p0, Lt0/a;->e:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p0
.end method

.method public static declared-synchronized f()Lcom/alipay/sdk/data/b;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-class v0, Lcom/alipay/sdk/data/b;

    const-class v0, Lcom/alipay/sdk/data/b;

    const/4 v3, 0x6

    const-class v0, Lcom/alipay/sdk/data/b;

    const-class v0, Lcom/alipay/sdk/data/b;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v1, Lcom/alipay/sdk/data/b;->g:Lcom/alipay/sdk/data/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    new-instance v1, Lcom/alipay/sdk/data/b;

    const/4 v3, 0x2

    invoke-direct {v1}, Lcom/alipay/sdk/data/b;-><init>()V

    const/4 v3, 0x0

    sput-object v1, Lcom/alipay/sdk/data/b;->g:Lcom/alipay/sdk/data/b;

    :cond_0
    const/4 v3, 0x7

    sget-object v1, Lcom/alipay/sdk/data/b;->g:Lcom/alipay/sdk/data/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v1
.end method

.method private static g(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Landroid/widget/TextView;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method private static h(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Landroid/content/Context;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v5, 0x5

    move v6, v5

    const-string v0, "bohti"

    const-string/jumbo v0, "tdhio"

    const/4 v6, 0x5

    const-string/jumbo v0, "tuirh"

    const-string/jumbo v0, "third"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->getInstance(Landroid/content/Context;)Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v3, Landroid/os/ConditionVariable;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v3}, Landroid/os/ConditionVariable;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    new-instance v4, Lcom/alipay/sdk/data/b$a;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v4, v1, v3}, Lcom/alipay/sdk/data/b$a;-><init>([Ljava/lang/String;Landroid/os/ConditionVariable;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1, v2, p2, v4}, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk;->initToken(ILjava/util/Map;Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-wide/16 p1, 0xbb8

    const-wide/16 p1, 0xbb8

    const/4 v6, 0x6

    const-wide/16 p1, 0xbb8

    const-wide/16 p1, 0xbb8

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v3, p1, p2}, Landroid/os/ConditionVariable;->block(J)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string p2, "EdxtGpipAb"

    const-string/jumbo p2, "pdxiAbtEGe"

    const/4 v6, 0x6

    const-string/jumbo p2, "tepxidEGqA"

    const-string p2, "GetApdidEx"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p0, v0, p2, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    aget-object p1, v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string/jumbo p1, "ptsluNluGAid"

    const-string/jumbo p1, "tlGpduuliNAd"

    const/4 v6, 0x5

    const-string/jumbo p1, "idlmNluGetdp"

    const-string p1, "GetApdidNull"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string p2, "gmneoikipstno"

    const-string/jumbo p2, "tgiiknopsnsem"

    const/4 v6, 0x0

    const-string/jumbo p2, "keinsbmn sogt"

    const-string/jumbo p2, "missing token"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p0, v0, p1, p2}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string p1, ":pa"

    const-string p1, "ap:"

    const/4 v6, 0x7

    const-string p1, ":ap"

    const-string p1, "ap:"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    aget-object p1, v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo p1, "mpsl"

    const/4 v6, 0x0

    const-string/jumbo p1, "mspl"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, p0}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    aget-object p0, v1, v2

    const/4 v6, 0x1

    return-object p0
.end method

.method public static i()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v1, "AmIlrvuImneiaisqui"

    const-string/jumbo v1, "niasIiieqrmAlvmutI"

    const/4 v6, 0x4

    const-string/jumbo v1, "idmIAevpiluatrmIsn"

    const-string/jumbo v1, "virtualImeiAndImsi"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x7

    move v6, v5

    const-string v3, "_uiitrlsqeai"

    const-string/jumbo v3, "trsiai_uelmi"

    const/4 v6, 0x1

    const-string/jumbo v3, "tisi_aimrevu"

    const-string/jumbo v3, "virtual_imei"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v4, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v2, :cond_0

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {}, Lcom/alipay/sdk/data/b;->p()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/util/b;->d()Ljava/lang/String;

    move-result-object v0

    :goto_0
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v2
.end method

.method private static j(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "wfii"

    const-string/jumbo v0, "wifi"

    const/4 v2, 0x5

    const-string/jumbo v0, "ifiw"

    const-string/jumbo v0, "wifi"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p0, Landroid/net/wifi/WifiManager;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const-string p0, "1-"

    const-string p0, "-1"

    const/4 v2, 0x5

    const-string p0, "-1"

    const-string p0, "-1"

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return-object p0
.end method

.method private static k(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Landroid/content/Context;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/sdk/data/b$b;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1, p2}, Lcom/alipay/sdk/data/b$b;-><init>(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object p1

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object p2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide/16 v0, 0xbb8

    const-wide/16 v0, 0xbb8

    const/4 v3, 0x2

    const-wide/16 v0, 0xbb8

    const-wide/16 v0, 0xbb8

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1, p2}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo p2, "tirmd"

    const-string/jumbo p2, "rdtmi"

    const/4 v3, 0x2

    const-string/jumbo p2, "ihdto"

    const-string/jumbo p2, "third"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "eeGutbAtipddTio"

    const-string v0, "GetApdidTimeout"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, p2, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x7

    const-string p1, ""

    const-string p1, ""

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1
.end method

.method public static l()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v1, "oilnsrummtIiIdveiu"

    const-string/jumbo v1, "ritaoImdelmusiIniv"

    const/4 v6, 0x4

    const-string/jumbo v1, "mItesarpidlAIimnui"

    const-string/jumbo v1, "virtualImeiAndImsi"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v3, "litiuabvqm_r"

    const-string/jumbo v3, "vmtisbu_lrai"

    const-string v3, "_isilvmsuiar"

    const-string/jumbo v3, "virtual_imsi"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-eqz v4, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0}, Lx0/b;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/16 v4, 0x12

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-ge v2, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    move v6, v5

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lcom/alipay/sdk/data/b;->p()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/alipay/sdk/util/b;->b()Ljava/lang/String;

    move-result-object v0

    :goto_1
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x6

    return-object v2
.end method

.method private static m(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "wfii"

    const-string/jumbo v0, "wifi"

    const/4 v2, 0x5

    const-string/jumbo v0, "iifw"

    const-string/jumbo v0, "wifi"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p0, Landroid/net/wifi/WifiManager;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/net/wifi/WifiInfo;->getBSSID()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const-string p0, "00"

    const-string p0, "00"

    const/4 v2, 0x5

    const-string p0, "00"

    const-string p0, "00"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method private static n()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "1"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method private static o()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "-u-1;"

    const/4 v2, 0x0

    const-string v0, "11-m;"

    const-string v0, "-1;-1"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method private static p()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0, v1}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/util/Random;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 v0, 0x2328

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    add-int/lit16 v0, v0, 0x3e8

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/data/b;->c:Ljava/lang/String;

    const/4 v2, 0x1

    return-object v0
.end method

.method public d(Lx0/a;Lcom/alipay/sdk/tid/c;)Ljava/lang/String;
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v1

    invoke-virtual {v1}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object v2

    iget-object v3, v0, Lcom/alipay/sdk/data/b;->a:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const-string v4, ";"

    const-string v4, ";"

    const-string v4, ";"

    const-string v4, ";"

    if-eqz v3, :cond_0

    invoke-static {}, Lcom/alipay/sdk/util/l;->u()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Lcom/alipay/sdk/util/l;->z()Ljava/lang/String;

    move-result-object v5

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->K(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->G(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v1}, Lcom/alipay/sdk/data/b;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "7.pM17.p5/"

    const-string v11, ".7./oM7s5p"

    const-string v11, "Msp/15.7.7"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, "( "

    const-string v11, " ("

    const-string v11, " ("

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lcom/alipay/sdk/data/b;->a:Ljava/lang/String;

    :cond_0
    invoke-static {v1}, Lcom/alipay/sdk/util/b;->c(Landroid/content/Context;)Lcom/alipay/sdk/util/e;

    move-result-object v3

    invoke-virtual {v3}, Lcom/alipay/sdk/util/e;->c()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->M(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Lcom/alipay/sdk/data/b;->n()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2}, Lcom/alipay/sdk/util/b;->b()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2}, Lcom/alipay/sdk/util/b;->d()Ljava/lang/String;

    move-result-object v8

    invoke-static {}, Lcom/alipay/sdk/data/b;->l()Ljava/lang/String;

    move-result-object v9

    invoke-static {}, Lcom/alipay/sdk/data/b;->i()Ljava/lang/String;

    move-result-object v10

    if-eqz p2, :cond_1

    invoke-virtual/range {p2 .. p2}, Lcom/alipay/sdk/tid/c;->f()Ljava/lang/String;

    move-result-object v11

    iput-object v11, v0, Lcom/alipay/sdk/data/b;->c:Ljava/lang/String;

    :cond_1
    sget-object v11, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const-string v12, " "

    const-string v12, " "

    const-string v12, " "

    invoke-virtual {v11, v4, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v11

    sget-object v13, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v13, v4, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    invoke-static {}, Lx0/b;->e()Z

    move-result v13

    invoke-virtual {v2}, Lcom/alipay/sdk/util/b;->g()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1}, Lcom/alipay/sdk/data/b;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1}, Lcom/alipay/sdk/data/b;->m(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v16, v1

    move-object/from16 v16, v1

    move-object/from16 v16, v1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v17, v15

    move-object/from16 v17, v15

    move-object/from16 v17, v15

    move-object/from16 v17, v15

    iget-object v15, v0, Lcom/alipay/sdk/data/b;->a:Ljava/lang/String;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v0, Lcom/alipay/sdk/data/b;->c:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/alipay/sdk/data/b;->o()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/alipay/sdk/data/b;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p2, :cond_2

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    invoke-static/range {v16 .. v16}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v3

    invoke-virtual {v3}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "tdi"

    const-string/jumbo v4, "tdi"

    const-string v4, "dti"

    const-string/jumbo v4, "tid"

    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v3

    invoke-virtual {v3}, Lx0/b;->f()Ljava/lang/String;

    move-result-object v3

    const-string v4, "bddiu"

    const-string/jumbo v4, "uddqi"

    const-string v4, "dudiu"

    const-string/jumbo v4, "utdid"

    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    invoke-static {v3, v4, v2}, Lcom/alipay/sdk/data/b;->k(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2

    const-string v3, ";;;"

    const-string v3, ";;;"

    const-string v3, ";;;"

    const-string v3, ";;;"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const-string v2, ")"

    const-string v2, ")"

    const-string v2, ")"

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
