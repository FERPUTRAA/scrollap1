.class Lcom/alipay/sdk/data/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lx0/a;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/alipay/sdk/data/a;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/data/a;Lx0/a;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/data/a$a;->c:Lcom/alipay/sdk/data/a;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/alipay/sdk/data/a$a;->a:Lx0/a;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/alipay/sdk/data/a$a;->b:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "n@s l @/tS~ ~f  ~~  da @ @/o~Mim@ oo~~ ~ ~@bKb oi@~-@f r~~~@@ ~@y@o1u@@~l~@ ~@@~i~4.~@voc @t~sb~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    new-instance v0, Lcom/alipay/sdk/packet/impl/b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Lcom/alipay/sdk/packet/impl/b;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/alipay/sdk/data/a$a;->a:Lx0/a;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/alipay/sdk/data/a$a;->b:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/alipay/sdk/packet/e;->a(Lx0/a;Landroid/content/Context;)Lcom/alipay/sdk/packet/b;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/data/a$a;->c:Lcom/alipay/sdk/data/a;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/alipay/sdk/packet/b;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/alipay/sdk/data/a;->b(Lcom/alipay/sdk/data/a;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/data/a$a;->c:Lcom/alipay/sdk/data/a;

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-static {}, Lx0/a;->f()Lx0/a;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/alipay/sdk/data/a;->c(Lcom/alipay/sdk/data/a;Lx0/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    return-void
.end method
