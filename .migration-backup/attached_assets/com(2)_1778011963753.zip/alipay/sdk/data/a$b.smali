.class public final Lcom/alipay/sdk/data/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/data/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/data/a$b;->a:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p2, p0, Lcom/alipay/sdk/data/a$b;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/alipay/sdk/data/a$b;->c:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public static a(Lorg/json/JSONObject;)Lcom/alipay/sdk/data/a$b;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 p0, 0x0

    move v5, p0

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v0, Lcom/alipay/sdk/data/a$b;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v1, "np"

    const-string/jumbo v1, "np"

    const/4 v5, 0x6

    const-string/jumbo v1, "np"

    const-string/jumbo v1, "pn"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "v"

    const-string/jumbo v2, "v"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0, v2, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v3, "pk"

    const-string/jumbo v3, "kp"

    const/4 v5, 0x0

    const-string/jumbo v3, "pk"

    const-string/jumbo v3, "pk"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2, p0}, Lcom/alipay/sdk/data/a$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v0
.end method

.method public static b(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ge v2, v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v3}, Lcom/alipay/sdk/data/a$b;->a(Lorg/json/JSONObject;)Lcom/alipay/sdk/data/a$b;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    return-object v0
.end method

.method public static c(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lorg/json/JSONArray;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v1, Lcom/alipay/sdk/data/a$b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/alipay/sdk/data/a$b;->d(Lcom/alipay/sdk/data/a$b;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public static d(Lcom/alipay/sdk/data/a$b;)Lorg/json/JSONObject;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v0

    :cond_0
    :try_start_0
    const/4 v5, 0x0

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v2, "pn"

    const-string/jumbo v2, "pn"

    const/4 v5, 0x0

    const-string/jumbo v2, "np"

    const-string/jumbo v2, "pn"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/alipay/sdk/data/a$b;->a:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v2, "v"

    const-string/jumbo v2, "v"

    const/4 v5, 0x5

    const-string/jumbo v2, "v"

    const-string/jumbo v2, "v"

    const/4 v5, 0x5

    iget v3, p0, Lcom/alipay/sdk/data/a$b;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v2, "kp"

    const-string/jumbo v2, "kp"

    const/4 v5, 0x2

    const-string/jumbo v2, "kp"

    const-string/jumbo v2, "pk"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p0, p0, Lcom/alipay/sdk/data/a$b;->c:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object p0

    :catch_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v0
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/data/a$b;->d(Lcom/alipay/sdk/data/a$b;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method
