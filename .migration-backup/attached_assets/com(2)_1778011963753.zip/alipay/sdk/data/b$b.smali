.class final Lcom/alipay/sdk/data/b$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/data/b;->k(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lx0/a;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/util/HashMap;


# direct methods
.method constructor <init>(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/data/b$b;->a:Lx0/a;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/alipay/sdk/data/b$b;->b:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/alipay/sdk/data/b$b;->c:Ljava/util/HashMap;

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "t@sMo-t@@/ ~a@b ~ior~~@  ~@~  f@@~~ /~~@~sd@o@@oli~@@b~~~cu@i~~  @ ~@ o~b@ .K1~@  y f~ ~v4S @lmo"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/data/b$b;->a:Lx0/a;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/data/b$b;->b:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/alipay/sdk/data/b$b;->c:Ljava/util/HashMap;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {v0, v1, v2}, Lcom/alipay/sdk/data/b;->c(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/data/b$b;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method
