.class final Lcom/alipay/sdk/data/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$InitResultListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/data/b;->h(Lx0/a;Landroid/content/Context;Ljava/util/HashMap;)Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/String;

.field final synthetic b:Landroid/os/ConditionVariable;


# direct methods
.method constructor <init>([Ljava/lang/String;Landroid/os/ConditionVariable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/data/b$a;->a:[Ljava/lang/String;

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/alipay/sdk/data/b$a;->b:Landroid/os/ConditionVariable;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onResult(Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@slb~@i4n~ ~i  @~@ l~oo ~@t ~/ m@fo ~  ~cir@~1@M o-~~@ @ ~@b~od@S@ s~~f~~o@K@@t~.~b@ uv y@@@ /a"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/data/b$a;->a:[Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p1, Lcom/alipay/apmobilesecuritysdk/face/APSecuritySdk$TokenResult;->apdidToken:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    aput-object p1, v0, v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/data/b$a;->b:Landroid/os/ConditionVariable;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/ConditionVariable;->open()V

    const/4 v3, 0x2

    return-void
.end method
