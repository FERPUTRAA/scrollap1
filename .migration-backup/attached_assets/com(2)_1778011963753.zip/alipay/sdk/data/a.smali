.class public final Lcom/alipay/sdk/data/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/data/a$b;
    }
.end annotation


# static fields
.field private static final A:Z = false

.field private static final B:Z = false

.field private static final C:Z = false

.field private static final D:Z = false

.field private static final E:I = 0x3e8

.field private static final F:I = 0x4e20

.field private static final G:Ljava/lang/String; = "alipay_cashier_dynamic_config"

.field private static final H:Ljava/lang/String; = "timeout"

.field private static final I:Ljava/lang/String; = "h5_port_degrade"

.field private static final J:Ljava/lang/String; = "st_sdk_config"

.field private static final K:Ljava/lang/String; = "tbreturl"

.field private static final L:Ljava/lang/String; = "launchAppSwitch"

.field private static final M:Ljava/lang/String; = "configQueryInterval"

.field private static final N:Ljava/lang/String; = "deg_log_mcgw"

.field private static final O:Ljava/lang/String; = "deg_start_srv_first"

.field private static final P:Ljava/lang/String; = "prev_jump_dual"

.field private static final Q:Ljava/lang/String; = "use_sc_only"

.field private static final R:Ljava/lang/String; = "bind_use_imp"

.field private static final S:Ljava/lang/String; = "retry_bnd_once"

.field private static final T:Ljava/lang/String; = "skip_trans"

.field private static final U:Ljava/lang/String; = "up_before_pay"

.field private static final V:Ljava/lang/String; = "scheme_pay_2"

.field private static final W:Ljava/lang/String; = "intercept_batch"

.field private static X:Lcom/alipay/sdk/data/a; = null

.field private static final q:Ljava/lang/String; = "DynCon"

.field private static final r:I = 0x2710

.field private static final s:Ljava/lang/String; = "https://h5.m.taobao.com/mlapp/olist.html"

.field private static final t:I = 0xa

.field private static final u:Z = true

.field private static final v:Z = true

.field private static final w:Z = false

.field private static final x:Z = true

.field private static final y:Z = true

.field private static final z:Ljava/lang/String; = ""


# instance fields
.field private a:I

.field private b:Z

.field private c:Ljava/lang/String;

.field private d:I

.field private e:Z

.field private f:Z

.field public g:Z

.field private h:Z

.field private i:Z

.field private j:Z

.field private k:Ljava/lang/String;

.field private l:Z

.field private m:Z

.field private n:Z

.field private o:Z

.field private p:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v0, 0x2710

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v0, p0, Lcom/alipay/sdk/data/a;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->b:Z

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "//smmlsalmhap.hst./sp.ot:5hi/tbp.loaoctt"

    const-string v1, "./sa/tsbhsc5ppoimlotth.l/.ap:t/otham.olm"

    const/4 v3, 0x7

    const-string/jumbo v1, "loom.bpm///tt:mitlaomhh.asclpt5shoa..t/m"

    const-string v1, "https://h5.m.taobao.com/mlapp/olist.html"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/alipay/sdk/data/a;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v1, p0, Lcom/alipay/sdk/data/a;->d:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-boolean v1, p0, Lcom/alipay/sdk/data/a;->e:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-boolean v1, p0, Lcom/alipay/sdk/data/a;->f:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->g:Z

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->h:Z

    const/4 v3, 0x1

    iput-boolean v1, p0, Lcom/alipay/sdk/data/a;->i:Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-boolean v1, p0, Lcom/alipay/sdk/data/a;->j:Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/alipay/sdk/data/a;->k:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->l:Z

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->m:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->n:Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->o:Z

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/data/a;->p:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic b(Lcom/alipay/sdk/data/a;Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/alipay/sdk/data/a;->i(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic c(Lcom/alipay/sdk/data/a;Lx0/a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/alipay/sdk/data/a;->f(Lx0/a;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method private d(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/alipay/sdk/data/a;->e(Lorg/json/JSONObject;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method private e(Lorg/json/JSONObject;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v0, "mtemoiu"

    const-string/jumbo v0, "uemmtti"

    const/4 v4, 0x6

    const-string/jumbo v0, "omitebt"

    const-string/jumbo v0, "timeout"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x2710

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v0, p0, Lcom/alipay/sdk/data/a;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v0, "hrpegduro__ta5e"

    const-string v0, "h5_port_degrade"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->b:Z

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    const-string/jumbo v0, "ltbrurtp"

    const-string/jumbo v0, "tbreturl"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "t.spposhqtll/tm/.c.hbiamoomp/5.aht:omol/"

    const-string v2, ":ia/o.5/hhtmtlamobl/osto.pmahmsl/..topcp"

    const/4 v4, 0x4

    const-string v2, "hmsp.mp/ambolhttltoai/psshc/ola/o5..:.tt"

    const-string v2, "https://h5.m.taobao.com/mlapp/olist.html"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/alipay/sdk/data/a;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v0, "QvrmaogelucnbtriIyf"

    const-string/jumbo v0, "vrIfrbtucoenlgQeaiy"

    const/4 v4, 0x6

    const-string/jumbo v0, "vrtnoauogyfnleIreiQ"

    const-string v0, "configQueryInterval"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/16 v2, 0xa

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v0, p0, Lcom/alipay/sdk/data/a;->d:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v0, "chShibuutAlwpca"

    const-string/jumbo v0, "tcwShcuhpualipA"

    const/4 v4, 0x4

    const-string v0, "hlncwSupaciuAph"

    const-string/jumbo v0, "launchAppSwitch"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/alipay/sdk/data/a$b;->b(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/alipay/sdk/data/a;->p:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v0, "scp_amyp2_ph"

    const-string v0, "ae__yscp2phm"

    const/4 v4, 0x5

    const-string v0, "ecs_y2meqph_"

    const-string/jumbo v0, "scheme_pay_2"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->e:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v0, "prseentaichqttb"

    const-string/jumbo v0, "rcteicbhqetapnt"

    const/4 v4, 0x3

    const-string v0, "ahcmpncteeitrt_"

    const-string/jumbo v0, "intercept_batch"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->f:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v0, "ld_gogmew_go"

    const-string v0, "gws_ledg_ogm"

    const/4 v4, 0x6

    const-string/jumbo v0, "ow_gebdmclg_"

    const-string v0, "deg_log_mcgw"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->h:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "srsi__ugeftr_drvmst"

    const-string v0, "_irmtftgssrrde_sav_"

    const/4 v4, 0x4

    const-string v0, "_esvrrfpstttiadr_sg"

    const-string v0, "deg_start_srv_first"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->i:Z

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v0, "mua_euljq_rpdo"

    const-string/jumbo v0, "jmudoarppu_el_"

    const/4 v4, 0x1

    const-string/jumbo v0, "p_s_velmduajrp"

    const-string/jumbo v0, "prev_jump_dual"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->j:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, "_symuoc_els"

    const-string/jumbo v0, "use_sc_only"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/alipay/sdk/data/a;->k:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, "bind_use_imp"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->l:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "_bnnod_eoyctrr"

    const-string v0, "do_ecbeyrr_nnt"

    const/4 v4, 0x1

    const-string v0, "ecbnrbe__ndoyt"

    const-string/jumbo v0, "retry_bnd_once"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->m:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "sauirpu_ks"

    const-string/jumbo v0, "knpa_suisr"

    const-string/jumbo v0, "prki_snpts"

    const-string/jumbo v0, "skip_trans"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-boolean v0, p0, Lcom/alipay/sdk/data/a;->n:Z

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v0, "r_euypbaqeopp"

    const-string v0, "ap_oupbpyer_e"

    const/4 v4, 0x4

    const-string/jumbo v0, "pus_aypoe_ebr"

    const-string/jumbo v0, "up_before_pay"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-boolean p1, p0, Lcom/alipay/sdk/data/a;->o:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method private f(Lx0/a;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/alipay/sdk/data/a;->z()Lorg/json/JSONObject;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v2, "cynm_ei_ciqdlosang_chryaaipaf"

    const-string v2, "ecndapahqnyil_arcsfgaioy_ci_i"

    const/4 v4, 0x5

    const-string/jumbo v2, "nneloyo_aapcsh__idyiacgraiicf"

    const-string v2, "alipay_cashier_dynamic_config"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1, v1, v2, v0}, Lcom/alipay/sdk/util/h;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method private i(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo p1, "nsfdibs_o_kst"

    const-string/jumbo p1, "sosdgf_nsi_tk"

    const/4 v2, 0x6

    const-string/jumbo p1, "t_ckonussdigf"

    const-string/jumbo p1, "st_sdk_config"

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/alipay/sdk/data/a;->e(Lorg/json/JSONObject;)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo p1, "npCnyo"

    const-string/jumbo p1, "noymCn"

    const/4 v2, 0x6

    const-string/jumbo p1, "nnqDCy"

    const-string p1, "DynCon"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "cesnpooitf m"

    const-string/jumbo v0, "nftiopgcemo "

    const/4 v2, 0x4

    const-string v0, "fgtm menpciy"

    const-string v0, "empty config"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/alipay/sdk/util/d;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public static x()Lcom/alipay/sdk/data/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/alipay/sdk/data/a;->X:Lcom/alipay/sdk/data/a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/alipay/sdk/data/a;

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {v0}, Lcom/alipay/sdk/data/a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object v0, Lcom/alipay/sdk/data/a;->X:Lcom/alipay/sdk/data/a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/alipay/sdk/data/a;->y()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    sget-object v0, Lcom/alipay/sdk/data/a;->X:Lcom/alipay/sdk/data/a;

    const/4 v2, 0x1

    return-object v0
.end method

.method private y()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-static {}, Lx0/a;->f()Lx0/a;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v2, "_liyobaiipec_n_cdfncimshogary"

    const-string v2, "emsahb__onadifylgipc_nyciicar"

    const/4 v5, 0x0

    const-string/jumbo v2, "iml_cbciaoyfcseghnnpaaaiydr__"

    const-string v2, "alipay_cashier_dynamic_config"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1, v0, v2, v3}, Lcom/alipay/sdk/util/h;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Lcom/alipay/sdk/data/a;->d(Ljava/lang/String;)V

    const/4 v4, 0x3

    move v5, v4

    return-void
.end method

.method private z()Lorg/json/JSONObject;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "tuieomu"

    const-string/jumbo v1, "timeout"

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->a()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "dr_ghduao5tr_ep"

    const/4 v4, 0x2

    const-string/jumbo v1, "rto5erapd_ehd_p"

    const-string v1, "h5_port_degrade"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->j()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "qretulpr"

    const-string/jumbo v1, "rtluebrp"

    const-string/jumbo v1, "rlsbuetr"

    const-string/jumbo v1, "tbreturl"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->m()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v1, "vIfmaqyclninQregtro"

    const-string/jumbo v1, "vrgnIaleqiyfQrcetno"

    const/4 v4, 0x3

    const-string/jumbo v1, "uvfnogicrlrnQtyeIea"

    const-string v1, "configQueryInterval"

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->n()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->w()Ljava/util/List;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/alipay/sdk/data/a$b;->c(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v2, "hhcSpbaAulipwnt"

    const-string/jumbo v2, "launchAppSwitch"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v1, "ecy_h_upsems"

    const-string/jumbo v1, "scs_y2e_emph"

    const/4 v4, 0x7

    const-string v1, "2sy_cpep_ham"

    const-string/jumbo v1, "scheme_pay_2"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->k()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "hcmcetrtqpae_tn"

    const-string v1, "a_cmrtctpeetnih"

    const/4 v4, 0x3

    const-string v1, "b_scnateierthtc"

    const-string/jumbo v1, "intercept_batch"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->l()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const-string v1, "dowmggcmo_ge"

    const-string v1, "gegcoomw_gd_"

    const/4 v4, 0x3

    const-string/jumbo v1, "l__moegodggw"

    const-string v1, "deg_log_mcgw"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->o()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "sdb_fbvrt_ta_tesgis"

    const-string/jumbo v1, "rtt__brdisgessvat_f"

    const/4 v4, 0x3

    const-string/jumbo v1, "t_ssesud_vrtiafg_tr"

    const-string v1, "deg_start_srv_first"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->p()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "prev_jump_dual"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->q()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "_s_ncyupols"

    const-string v1, "_sycosunle_"

    const/4 v4, 0x3

    const-string/jumbo v1, "nceyo_slqu_"

    const-string/jumbo v1, "use_sc_only"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "susiepndmi__"

    const-string/jumbo v1, "psdeinip_m_u"

    const/4 v4, 0x2

    const-string v1, "_udmsen_mbpi"

    const-string v1, "bind_use_imp"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->s()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, "ctnoo_drey_enq"

    const-string/jumbo v1, "rnecy_odq_tern"

    const/4 v4, 0x1

    const-string v1, "_yr_nbcbneertd"

    const-string/jumbo v1, "retry_bnd_once"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->t()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "sikpnsu_ts"

    const-string/jumbo v1, "pks_nsasit"

    const/4 v4, 0x3

    const-string/jumbo v1, "nsriatkpp_"

    const-string/jumbo v1, "skip_trans"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->u()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const-string v1, "a_pruyb_qeefm"

    const-string v1, "eyfmruppe__ab"

    const/4 v4, 0x0

    const-string v1, "ausp_ore_beyf"

    const-string/jumbo v1, "up_before_pay"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/data/a;->v()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v0, p0, Lcom/alipay/sdk/data/a;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 v1, 0x3e8

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "nDCmoy"

    const-string/jumbo v2, "oCDyon"

    const/4 v4, 0x7

    const-string/jumbo v2, "noyDoC"

    const-string v2, "DynCon"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-lt v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 v1, 0x4e20

    if-le v0, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "itm =be"

    const/4 v4, 0x7

    const-string v1, "e =itb "

    const-string/jumbo v1, "time = "

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v1, p0, Lcom/alipay/sdk/data/a;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v2, v0}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v0, p0, Lcom/alipay/sdk/data/a;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, "d0m0t ufe)=i10 e("

    const-string v0, "=emdftu10 i00()e "

    const/4 v4, 0x3

    const-string/jumbo v0, "m0= itep(d0e) 100"

    const-string/jumbo v0, "time(def) = 10000"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v2, v0}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 v0, 0x2710

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v0
.end method

.method public g(Lx0/a;Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lcom/alipay/sdk/data/a$a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, p0, p1, p2}, Lcom/alipay/sdk/data/a$a;-><init>(Lcom/alipay/sdk/data/a;Lx0/a;Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public h(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/alipay/sdk/data/a;->g:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->f:Z

    const/4 v2, 0x3

    return v0
.end method

.method public m()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/data/a;->c:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public n()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/alipay/sdk/data/a;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public o()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->h:Z

    const/4 v2, 0x3

    return v0
.end method

.method public p()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->i:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public q()Z
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->j:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public r()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/data/a;->k:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public s()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->l:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    return v0
.end method

.method public t()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->m:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public u()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->n:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public v()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/alipay/sdk/data/a;->o:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public w()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/data/a;->p:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method
