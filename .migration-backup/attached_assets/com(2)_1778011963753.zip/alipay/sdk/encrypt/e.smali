.class public Lcom/alipay/sdk/encrypt/e;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = "DESede/CBC/PKCS5Padding"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~fs ~@ ~ ib @sc~ ~oiu~.~@  ~b/ ao ~@i @~/~~~ ~@l@ d~S~4t~o1 @~ @v-@@@~~~oKmy@M@l~f @ @ n@@@oortb"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/encrypt/e;->b(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/encrypt/a;->b([B)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    goto :goto_0

    :catch_0
    const/4 v1, 0x2

    const/4 p0, 0x5

    const/4 v1, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public static b(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "seemSd"

    const-string v1, "eDsedS"

    const/4 v3, 0x0

    const-string v1, "eeEdoD"

    const-string v1, "DESede"

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-direct {v0, p0, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object p0, Lcom/alipay/sdk/encrypt/e;->a:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {p0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Ljavax/crypto/spec/IvParameterSpec;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, p2}, Lcom/alipay/sdk/encrypt/c;->a(Ljavax/crypto/Cipher;Ljava/lang/String;)[B

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1, p2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, p2, v0, v1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/encrypt/a;->d(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/encrypt/e;->d(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p1, Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p1, p0}, Ljava/lang/String;-><init>([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    goto :goto_0

    :catch_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public static d(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, "DmedEb"

    const-string v1, "EdSmDe"

    const/4 v3, 0x4

    const-string v1, "DESede"

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object p0, Lcom/alipay/sdk/encrypt/e;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Ljavax/crypto/spec/IvParameterSpec;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0, p2}, Lcom/alipay/sdk/encrypt/c;->a(Ljavax/crypto/Cipher;Ljava/lang/String;)[B

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v1, p2}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, p2, v0, v1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0
.end method
