.class public Lcom/alipay/sdk/encrypt/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x4

    return-void
.end method

.method public static a([B)[B
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@us@~/b~b/v~if@ o @~cm~@s@@@@41o ~o ~S- @ ~~ ~@ ~iyf@~@~~ @b.a@o@~ M~~d @ o @ ~int~t K@@o l~l~r "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v7, 0x7

    new-instance p0, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v2, Ljava/util/zip/GZIPOutputStream;

    const/4 v6, 0x4

    move v7, v6

    invoke-direct {v2, p0}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/16 v0, 0x1000

    :try_start_3
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-array v0, v0, [B

    :goto_0
    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v4, -0x1

    const/4 v6, 0x2

    move v7, v6

    if-eq v3, v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v2, v0, v4, v3}, Ljava/util/zip/GZIPOutputStream;->write([BII)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/io/OutputStream;->flush()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/util/zip/GZIPOutputStream;->finish()V

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    :try_start_5
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    :catch_1
    :try_start_6
    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_2

    :catchall_1
    move-exception v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_1

    :catchall_3
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_1
    move-object v0, p0

    move-object v0, p0

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    :try_start_7
    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    :catch_3
    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz p0, :cond_2

    :try_start_8
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    :catch_4
    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v2, :cond_3

    :try_start_9
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    :catch_5
    :cond_3
    const/4 v7, 0x6

    throw v0
.end method

.method public static b([B)[B
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x4

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance p0, Ljava/util/zip/GZIPInputStream;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {p0, v1}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/16 v2, 0x1000

    :try_start_2
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-array v3, v2, [B

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v0, 0x0

    :try_start_3
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0, v3, v0, v2}, Ljava/util/zip/GZIPInputStream;->read([BII)I

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v6, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eq v5, v6, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v4, v3, v0, v5}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/io/OutputStream;->flush()V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    :try_start_5
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/util/zip/GZIPInputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    :catch_1
    :try_start_6
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_2

    :catchall_1
    move-exception v2

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_1

    :catchall_3
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v4, v1

    move-object v4, v1

    :goto_1
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    :goto_2
    :try_start_7
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    :catch_3
    :try_start_8
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0}, Ljava/util/zip/GZIPInputStream;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    :catch_4
    :try_start_9
    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_5

    :catch_5
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    throw v0
.end method
