.class public final Lcom/alipay/sdk/encrypt/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = 0x80

.field private static final b:I = 0x40

.field private static final c:I = 0x18

.field private static final d:I = 0x8

.field private static final e:I = 0x10

.field private static final f:I = 0x4

.field private static final g:I = -0x80

.field private static final h:C = '='

.field private static final i:[B

.field private static final j:[C


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/16 v0, 0x80

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-array v1, v0, [B

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    sput-object v1, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/16 v1, 0x40

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-array v1, v1, [C

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    sput-object v1, Lcom/alipay/sdk/encrypt/a;->j:[C

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v1, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-ge v2, v0, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    sget-object v3, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v4, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    aput-byte v4, v3, v2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    goto :goto_0

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    const/16 v0, 0x5a

    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/16 v2, 0x41

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-lt v0, v2, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v2, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v10, 0x4

    move v11, v10

    add-int/lit8 v3, v0, -0x41

    const/4 v11, 0x7

    int-to-byte v3, v3

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    aput-byte v3, v2, v0

    const/4 v11, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto :goto_1

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/16 v0, 0x7a

    :goto_2
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/16 v2, 0x1a

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/16 v3, 0x61

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-lt v0, v3, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    sget-object v3, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    add-int/lit8 v4, v0, -0x61

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    add-int/2addr v4, v2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    int-to-byte v2, v4

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    aput-byte v2, v3, v0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v11, 0x7

    goto :goto_2

    :cond_2
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/16 v0, 0x39

    :goto_3
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/16 v3, 0x34

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/16 v4, 0x30

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-lt v0, v4, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget-object v4, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    add-int/lit8 v5, v0, -0x30

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    add-int/2addr v5, v3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    int-to-byte v3, v5

    const/4 v10, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    aput-byte v3, v4, v0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    goto :goto_3

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    sget-object v0, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/16 v4, 0x2b

    const/4 v11, 0x4

    const/16 v5, 0x3e

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    aput-byte v5, v0, v4

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/16 v6, 0x2f

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    const/16 v7, 0x3f

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    aput-byte v7, v0, v6

    const/4 v11, 0x6

    move v0, v1

    move v0, v1

    const/4 v11, 0x4

    move v0, v1

    move v0, v1

    :goto_4
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    const/16 v8, 0x19

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-gt v0, v8, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget-object v8, Lcom/alipay/sdk/encrypt/a;->j:[C

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    add-int/lit8 v9, v0, 0x41

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    int-to-char v9, v9

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    aput-char v9, v8, v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v11, 0x1

    goto :goto_4

    :cond_4
    const/4 v10, 0x1

    const/4 v11, 0x2

    move v0, v1

    move v0, v1

    const/4 v11, 0x2

    move v0, v1

    move v0, v1

    :goto_5
    const/4 v10, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    const/16 v8, 0x33

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-gt v2, v8, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    sget-object v8, Lcom/alipay/sdk/encrypt/a;->j:[C

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    add-int/lit8 v9, v0, 0x61

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    int-to-char v9, v9

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    aput-char v9, v8, v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto :goto_5

    :cond_5
    :goto_6
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    const/16 v0, 0x3d

    const/4 v10, 0x4

    and-int/2addr v11, v10

    if-gt v3, v0, :cond_6

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object v0, Lcom/alipay/sdk/encrypt/a;->j:[C

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    add-int/lit8 v2, v1, 0x30

    const/4 v11, 0x1

    const/4 v10, 0x2

    int-to-char v2, v2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    aput-char v2, v0, v3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto :goto_6

    :cond_6
    const/4 v10, 0x2

    move v11, v10

    sget-object v0, Lcom/alipay/sdk/encrypt/a;->j:[C

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    aput-char v4, v0, v5

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    aput-char v6, v0, v7

    const/4 v11, 0x4

    const/4 v10, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private static a([C)I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " Ks@~o~m b~b@o~tnbdl  @~a   @~~s.@@@1o@rS@@@~~~ ~~/~v~@o ~@f ~ y ~iouc~@fi@t  i~- @@~ ~lo@@M~ /4"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v6, 0x6

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x6

    move v2, v0

    move v2, v0

    const/4 v6, 0x0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-ge v0, v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    aget-char v3, p0, v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v3}, Lcom/alipay/sdk/encrypt/a;->c(C)Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    add-int/lit8 v3, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-char v4, p0, v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    aput-char v4, p0, v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    const/4 v6, 0x3

    move v2, v3

    move v2, v3

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_2
    const/4 v6, 0x1

    return v2
.end method

.method public static b([B)Ljava/lang/String;
    .locals 15

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    array-length v0, p0

    const/16 v1, 0x8

    mul-int/2addr v0, v1

    if-nez v0, :cond_1

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    return-object p0

    :cond_1
    rem-int/lit8 v2, v0, 0x18

    div-int/lit8 v0, v0, 0x18

    if-eqz v2, :cond_2

    add-int/lit8 v3, v0, 0x1

    goto :goto_0

    :cond_2
    move v3, v0

    move v3, v0

    move v3, v0

    move v3, v0

    :goto_0
    mul-int/lit8 v3, v3, 0x4

    new-array v3, v3, [C

    const/4 v4, 0x0

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :goto_1
    if-ge v4, v0, :cond_6

    add-int/lit8 v7, v5, 0x1

    aget-byte v5, p0, v5

    add-int/lit8 v8, v7, 0x1

    aget-byte v7, p0, v7

    add-int/lit8 v9, v8, 0x1

    aget-byte v8, p0, v8

    and-int/lit8 v10, v7, 0xf

    int-to-byte v10, v10

    and-int/lit8 v11, v5, 0x3

    int-to-byte v11, v11

    and-int/lit8 v12, v5, -0x80

    shr-int/lit8 v5, v5, 0x2

    if-nez v12, :cond_3

    goto :goto_2

    :cond_3
    xor-int/lit16 v5, v5, 0xc0

    :goto_2
    int-to-byte v5, v5

    and-int/lit8 v12, v7, -0x80

    shr-int/lit8 v7, v7, 0x4

    if-nez v12, :cond_4

    goto :goto_3

    :cond_4
    xor-int/lit16 v7, v7, 0xf0

    :goto_3
    int-to-byte v7, v7

    and-int/lit8 v12, v8, -0x80

    if-nez v12, :cond_5

    shr-int/lit8 v12, v8, 0x6

    goto :goto_4

    :cond_5
    shr-int/lit8 v12, v8, 0x6

    xor-int/lit16 v12, v12, 0xfc

    :goto_4
    int-to-byte v12, v12

    add-int/lit8 v13, v6, 0x1

    sget-object v14, Lcom/alipay/sdk/encrypt/a;->j:[C

    aget-char v5, v14, v5

    aput-char v5, v3, v6

    add-int/lit8 v5, v13, 0x1

    shl-int/lit8 v6, v11, 0x4

    or-int/2addr v6, v7

    aget-char v6, v14, v6

    aput-char v6, v3, v13

    add-int/lit8 v6, v5, 0x1

    shl-int/lit8 v7, v10, 0x2

    or-int/2addr v7, v12

    aget-char v7, v14, v7

    aput-char v7, v3, v5

    add-int/lit8 v5, v6, 0x1

    and-int/lit8 v7, v8, 0x3f

    aget-char v7, v14, v7

    aput-char v7, v3, v6

    add-int/lit8 v4, v4, 0x1

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    move v5, v9

    move v5, v9

    move v5, v9

    goto :goto_1

    :cond_6
    const/16 v0, 0x3d

    if-ne v2, v1, :cond_8

    aget-byte p0, p0, v5

    and-int/lit8 v1, p0, 0x3

    int-to-byte v1, v1

    and-int/lit8 v2, p0, -0x80

    shr-int/lit8 p0, p0, 0x2

    if-nez v2, :cond_7

    goto :goto_5

    :cond_7
    xor-int/lit16 p0, p0, 0xc0

    :goto_5
    int-to-byte p0, p0

    add-int/lit8 v2, v6, 0x1

    sget-object v4, Lcom/alipay/sdk/encrypt/a;->j:[C

    aget-char p0, v4, p0

    aput-char p0, v3, v6

    add-int/lit8 p0, v2, 0x1

    shl-int/lit8 v1, v1, 0x4

    aget-char v1, v4, v1

    aput-char v1, v3, v2

    add-int/lit8 v1, p0, 0x1

    aput-char v0, v3, p0

    aput-char v0, v3, v1

    goto :goto_8

    :cond_8
    const/16 v1, 0x10

    if-ne v2, v1, :cond_b

    aget-byte v1, p0, v5

    add-int/lit8 v5, v5, 0x1

    aget-byte p0, p0, v5

    and-int/lit8 v2, p0, 0xf

    int-to-byte v2, v2

    and-int/lit8 v4, v1, 0x3

    int-to-byte v4, v4

    and-int/lit8 v5, v1, -0x80

    shr-int/lit8 v1, v1, 0x2

    if-nez v5, :cond_9

    goto :goto_6

    :cond_9
    xor-int/lit16 v1, v1, 0xc0

    :goto_6
    int-to-byte v1, v1

    and-int/lit8 v5, p0, -0x80

    shr-int/lit8 p0, p0, 0x4

    if-nez v5, :cond_a

    goto :goto_7

    :cond_a
    xor-int/lit16 p0, p0, 0xf0

    :goto_7
    int-to-byte p0, p0

    add-int/lit8 v5, v6, 0x1

    sget-object v7, Lcom/alipay/sdk/encrypt/a;->j:[C

    aget-char v1, v7, v1

    aput-char v1, v3, v6

    add-int/lit8 v1, v5, 0x1

    shl-int/lit8 v4, v4, 0x4

    or-int/2addr p0, v4

    aget-char p0, v7, p0

    aput-char p0, v3, v5

    add-int/lit8 p0, v1, 0x1

    shl-int/lit8 v2, v2, 0x2

    aget-char v2, v7, v2

    aput-char v2, v3, v1

    aput-char v0, v3, p0

    :cond_b
    :goto_8
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, v3}, Ljava/lang/String;-><init>([C)V

    return-object p0
.end method

.method private static c(C)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p0, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/16 v0, 0xd

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 v0, 0xa

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 v0, 0x9

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-ne p0, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x5

    move v2, v1

    const/4 p0, 0x1

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p0
.end method

.method public static d(Ljava/lang/String;)[B
    .locals 14

    const/4 v13, 0x5

    const/4 v0, 0x0

    const/4 v13, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    const/4 v13, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v13, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/encrypt/a;->a([C)I

    move-result v1

    const/4 v13, 0x0

    rem-int/lit8 v2, v1, 0x4

    const/4 v13, 0x1

    if-eqz v2, :cond_1

    const/4 v13, 0x6

    return-object v0

    :cond_1
    const/4 v13, 0x1

    div-int/lit8 v1, v1, 0x4

    const/4 v13, 0x5

    const/4 v2, 0x0

    const/4 v13, 0x1

    if-nez v1, :cond_2

    const/4 v13, 0x3

    new-array p0, v2, [B

    const/4 v13, 0x4

    return-object p0

    :cond_2
    const/4 v13, 0x6

    mul-int/lit8 v3, v1, 0x3

    new-array v3, v3, [B

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    const/4 v13, 0x4

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    const/4 v13, 0x2

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :goto_0
    const/4 v13, 0x4

    add-int/lit8 v7, v1, -0x1

    const/4 v13, 0x4

    if-ge v4, v7, :cond_5

    const/4 v13, 0x4

    add-int/lit8 v7, v5, 0x1

    const/4 v13, 0x3

    aget-char v5, p0, v5

    const/4 v13, 0x6

    invoke-static {v5}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v8

    const/4 v13, 0x5

    if-eqz v8, :cond_4

    const/4 v13, 0x7

    add-int/lit8 v8, v7, 0x1

    const/4 v13, 0x2

    aget-char v7, p0, v7

    const/4 v13, 0x3

    invoke-static {v7}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v9

    const/4 v13, 0x0

    if-eqz v9, :cond_4

    const/4 v13, 0x7

    add-int/lit8 v9, v8, 0x1

    const/4 v13, 0x3

    aget-char v8, p0, v8

    invoke-static {v8}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v10

    const/4 v13, 0x5

    if-eqz v10, :cond_4

    add-int/lit8 v10, v9, 0x1

    const/4 v13, 0x3

    aget-char v9, p0, v9

    const/4 v13, 0x2

    invoke-static {v9}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v11

    const/4 v13, 0x7

    if-nez v11, :cond_3

    const/4 v13, 0x2

    goto :goto_1

    :cond_3
    const/4 v13, 0x1

    sget-object v11, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v13, 0x3

    aget-byte v5, v11, v5

    const/4 v13, 0x2

    aget-byte v7, v11, v7

    aget-byte v8, v11, v8

    const/4 v13, 0x2

    aget-byte v9, v11, v9

    const/4 v13, 0x3

    add-int/lit8 v11, v6, 0x1

    const/4 v13, 0x0

    shl-int/lit8 v5, v5, 0x2

    const/4 v13, 0x5

    shr-int/lit8 v12, v7, 0x4

    const/4 v13, 0x5

    or-int/2addr v5, v12

    const/4 v13, 0x5

    int-to-byte v5, v5

    const/4 v13, 0x2

    aput-byte v5, v3, v6

    const/4 v13, 0x4

    add-int/lit8 v5, v11, 0x1

    const/4 v13, 0x3

    and-int/lit8 v6, v7, 0xf

    const/4 v13, 0x0

    shl-int/lit8 v6, v6, 0x4

    const/4 v13, 0x5

    shr-int/lit8 v7, v8, 0x2

    const/4 v13, 0x0

    and-int/lit8 v7, v7, 0xf

    const/4 v13, 0x1

    or-int/2addr v6, v7

    const/4 v13, 0x1

    int-to-byte v6, v6

    const/4 v13, 0x6

    aput-byte v6, v3, v11

    const/4 v13, 0x6

    add-int/lit8 v6, v5, 0x1

    const/4 v13, 0x5

    shl-int/lit8 v7, v8, 0x6

    const/4 v13, 0x4

    or-int/2addr v7, v9

    const/4 v13, 0x4

    int-to-byte v7, v7

    const/4 v13, 0x5

    aput-byte v7, v3, v5

    const/4 v13, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v13, 0x7

    move v5, v10

    move v5, v10

    move v5, v10

    const/4 v13, 0x5

    goto/16 :goto_0

    :cond_4
    :goto_1
    const/4 v13, 0x0

    return-object v0

    :cond_5
    const/4 v13, 0x0

    add-int/lit8 v1, v5, 0x1

    const/4 v13, 0x5

    aget-char v5, p0, v5

    const/4 v13, 0x7

    invoke-static {v5}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v7

    const/4 v13, 0x0

    if-eqz v7, :cond_c

    const/4 v13, 0x0

    add-int/lit8 v7, v1, 0x1

    const/4 v13, 0x3

    aget-char v1, p0, v1

    const/4 v13, 0x0

    invoke-static {v1}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v8

    const/4 v13, 0x3

    if-nez v8, :cond_6

    const/4 v13, 0x1

    goto/16 :goto_3

    :cond_6
    const/4 v13, 0x2

    sget-object v8, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v13, 0x0

    aget-byte v5, v8, v5

    const/4 v13, 0x6

    aget-byte v1, v8, v1

    const/4 v13, 0x0

    add-int/lit8 v9, v7, 0x1

    aget-char v7, p0, v7

    const/4 v13, 0x7

    aget-char p0, p0, v9

    const/4 v13, 0x2

    invoke-static {v7}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v9

    const/4 v13, 0x2

    if-eqz v9, :cond_8

    const/4 v13, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/encrypt/a;->f(C)Z

    move-result v9

    const/4 v13, 0x0

    if-nez v9, :cond_7

    const/4 v13, 0x6

    goto :goto_2

    :cond_7
    const/4 v13, 0x5

    aget-byte v0, v8, v7

    const/4 v13, 0x1

    aget-byte p0, v8, p0

    const/4 v13, 0x6

    add-int/lit8 v2, v6, 0x1

    const/4 v13, 0x1

    shl-int/lit8 v4, v5, 0x2

    const/4 v13, 0x1

    shr-int/lit8 v5, v1, 0x4

    const/4 v13, 0x6

    or-int/2addr v4, v5

    const/4 v13, 0x7

    int-to-byte v4, v4

    const/4 v13, 0x2

    aput-byte v4, v3, v6

    const/4 v13, 0x4

    add-int/lit8 v4, v2, 0x1

    const/4 v13, 0x7

    and-int/lit8 v1, v1, 0xf

    const/4 v13, 0x6

    shl-int/lit8 v1, v1, 0x4

    shr-int/lit8 v5, v0, 0x2

    const/4 v13, 0x7

    and-int/lit8 v5, v5, 0xf

    const/4 v13, 0x5

    or-int/2addr v1, v5

    const/4 v13, 0x4

    int-to-byte v1, v1

    const/4 v13, 0x7

    aput-byte v1, v3, v2

    const/4 v13, 0x5

    shl-int/lit8 v0, v0, 0x6

    const/4 v13, 0x1

    or-int/2addr p0, v0

    const/4 v13, 0x6

    int-to-byte p0, p0

    const/4 v13, 0x1

    aput-byte p0, v3, v4

    const/4 v13, 0x7

    return-object v3

    :cond_8
    :goto_2
    const/4 v13, 0x6

    invoke-static {v7}, Lcom/alipay/sdk/encrypt/a;->e(C)Z

    move-result v9

    const/4 v13, 0x3

    if-eqz v9, :cond_a

    const/4 v13, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/encrypt/a;->e(C)Z

    move-result v9

    const/4 v13, 0x1

    if-eqz v9, :cond_a

    const/4 v13, 0x0

    and-int/lit8 p0, v1, 0xf

    const/4 v13, 0x4

    if-eqz p0, :cond_9

    const/4 v13, 0x5

    return-object v0

    :cond_9
    const/4 v13, 0x7

    mul-int/lit8 v4, v4, 0x3

    const/4 v13, 0x2

    add-int/lit8 p0, v4, 0x1

    const/4 v13, 0x1

    new-array p0, p0, [B

    const/4 v13, 0x7

    invoke-static {v3, v2, p0, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v13, 0x2

    shl-int/lit8 v0, v5, 0x2

    const/4 v13, 0x3

    shr-int/lit8 v1, v1, 0x4

    const/4 v13, 0x2

    or-int/2addr v0, v1

    const/4 v13, 0x1

    int-to-byte v0, v0

    const/4 v13, 0x3

    aput-byte v0, p0, v6

    return-object p0

    :cond_a
    const/4 v13, 0x7

    invoke-static {v7}, Lcom/alipay/sdk/encrypt/a;->e(C)Z

    move-result v9

    const/4 v13, 0x6

    if-nez v9, :cond_c

    const/4 v13, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/encrypt/a;->e(C)Z

    move-result p0

    const/4 v13, 0x5

    if-eqz p0, :cond_c

    const/4 v13, 0x3

    aget-byte p0, v8, v7

    const/4 v13, 0x0

    and-int/lit8 v7, p0, 0x3

    const/4 v13, 0x3

    if-eqz v7, :cond_b

    const/4 v13, 0x7

    return-object v0

    :cond_b
    const/4 v13, 0x2

    mul-int/lit8 v4, v4, 0x3

    const/4 v13, 0x3

    add-int/lit8 v0, v4, 0x2

    const/4 v13, 0x2

    new-array v0, v0, [B

    invoke-static {v3, v2, v0, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v13, 0x3

    add-int/lit8 v2, v6, 0x1

    const/4 v13, 0x4

    shl-int/lit8 v3, v5, 0x2

    const/4 v13, 0x7

    shr-int/lit8 v4, v1, 0x4

    const/4 v13, 0x1

    or-int/2addr v3, v4

    const/4 v13, 0x3

    int-to-byte v3, v3

    aput-byte v3, v0, v6

    const/4 v13, 0x4

    and-int/lit8 v1, v1, 0xf

    const/4 v13, 0x4

    shl-int/lit8 v1, v1, 0x4

    const/4 v13, 0x1

    shr-int/lit8 p0, p0, 0x2

    const/4 v13, 0x6

    and-int/lit8 p0, p0, 0xf

    or-int/2addr p0, v1

    const/4 v13, 0x7

    int-to-byte p0, p0

    const/4 v13, 0x0

    aput-byte p0, v0, v2

    :cond_c
    :goto_3
    return-object v0
.end method

.method private static e(C)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/16 v0, 0x3d

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-ne p0, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0
.end method

.method private static f(C)Z
    .locals 3

    const/4 v2, 0x0

    const/16 v0, 0x80

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ge p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/alipay/sdk/encrypt/a;->i:[B

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    aget-byte p0, v0, p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p0
.end method
