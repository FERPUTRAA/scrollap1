.class public Lcom/alipay/sdk/encrypt/d;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "RSA"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)[B
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "o@sKM~lioo //@~@S~@ ~-@b~iof~ td @m. 1@ ~if  @~~@ @ @r@@a otcy~ub@@b~@~s vl@4~~ ~~ @~~ @~ ~n o@~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v1, "ARS"

    const-string v1, "ASR"

    const/4 v6, 0x5

    const-string v1, "RSA"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v1, p1}, Lcom/alipay/sdk/encrypt/d;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/security/PublicKey;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v1, "/AKmP1SEC/sRiBgdPndC"

    const-string v1, "1nsA/K/PddRCCSiSPBEg"

    const/4 v6, 0x1

    const-string v1, "AnaBo/R1CSC/dPSgdEiP"

    const-string v1, "RSA/ECB/PKCS1Padding"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v2, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string p1, "bFU-m"

    const-string p1, "U-Fm8"

    const/4 v6, 0x3

    const-string p1, "UuF8-"

    const-string p1, "UTF-8"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljavax/crypto/Cipher;->getBlockSize()I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x0

    :goto_0
    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    array-length v4, p0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-ge v3, v4, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    array-length v4, p0

    const/4 v6, 0x4

    sub-int/2addr v4, v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ge v4, p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    array-length v4, p0

    const/4 v6, 0x7

    sub-int/2addr v4, v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    move v6, v5

    move v4, p1

    move v4, p1

    const/4 v6, 0x4

    move v4, p1

    move v4, p1

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, p0, v3, v4}, Ljavax/crypto/Cipher;->doFinal([BII)[B

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2, v4}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/2addr v3, p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_3

    :catch_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_3

    :catch_1
    move-exception p0

    const/4 v6, 0x0

    const/4 v5, 0x2

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_4

    :catch_2
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_2
    :try_start_3
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v2, :cond_2

    :try_start_4
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :cond_2
    :goto_3
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object v0

    :catchall_1
    move-exception p0

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_4
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_3

    :try_start_5
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_5

    :catch_3
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_3
    :goto_5
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    throw p0
.end method

.method private static b(Ljava/lang/String;Ljava/lang/String;)Ljava/security/PublicKey;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/NoSuchAlgorithmException;,
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/alipay/sdk/encrypt/a;->d(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/security/spec/X509EncodedKeySpec;

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {v0, p1}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-object p0
.end method
