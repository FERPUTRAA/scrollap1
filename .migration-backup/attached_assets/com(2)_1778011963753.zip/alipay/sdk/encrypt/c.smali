.class Lcom/alipay/sdk/encrypt/c;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method static a(Ljavax/crypto/Cipher;Ljava/lang/String;)[B
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~s~r @ o -to~ @ .c@~~@d@@nb~ @~v~i m~~@y~ ~@~ s@~fl@KM~@ ~ob at~~ ~~@io  @@ ~bSf/li @4~@/1@uoo@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    new-instance v0, Ljava/security/SecureRandom;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljavax/crypto/Cipher;->getBlockSize()I

    move-result p0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/Random;->nextDouble()D

    move-result-wide v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object p1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    mul-int/lit8 v1, p0, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-array v2, v1, [B

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-array v3, p0, [B

    const/4 v7, 0x6

    invoke-virtual {v0, v3}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, 0x1

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ge v0, v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    rem-int v5, v0, v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1, v5}, Ljava/lang/String;->codePointAt(I)I

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    and-int/lit8 v5, v5, 0x7f

    const/4 v6, 0x5

    move v7, v6

    int-to-byte v5, v5

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    aput-byte v5, v2, v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-lt v0, p0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    aget-byte v4, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    and-int/2addr v4, v5

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    int-to-byte v4, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    aput-byte v4, v2, v0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v2, p0, v3, v4, p0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-object v3
.end method
