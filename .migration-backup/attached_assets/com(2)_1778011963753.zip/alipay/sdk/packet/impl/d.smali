.class public Lcom/alipay/sdk/packet/impl/d;
.super Lcom/alipay/sdk/packet/e;


# static fields
.field public static final t:Ljava/lang/String; = "log_v"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~ s  ~l.@ ov@bc@~K~~i ~ ~M~4o@~@@a~S   @ @l~~foo1@@iu ~~@ ~ ~~of@/@ t-~bm~~dn @~@@y/~o@bs  @t@ir"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    const-string v4, ":kpm.tmmold//.wyasi./hoostgdccags"

    const-string v4, "ats/sc:imtappd/gsh.lowydkoo/..mcg"

    const/4 v7, 0x1

    const-string v4, "/iwtopasplygo.a..km:tcogdmsd/ch/o"

    const-string v4, "https://mcgw.alipay.com/sdklog.do"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v5, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-virtual/range {v0 .. v5}, Lcom/alipay/sdk/packet/e;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Z)Lcom/alipay/sdk/packet/b;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-object p1
.end method

.method protected g(Lx0/a;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    return-object p2
.end method

.method protected h(ZLjava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p2, Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "s-pimbzg"

    const-string/jumbo v0, "ipzmsg-m"

    const/4 v2, 0x6

    const-string v0, "gzipmsup"

    const-string/jumbo v0, "msp-gzip"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p2, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo p1, "opcoye-ptnnt"

    const-string p1, "-nyeotteopnc"

    const/4 v2, 0x4

    const-string/jumbo p1, "t-eytoenqcnt"

    const-string p1, "content-type"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "iasaccplneoto/tr-bitmtea"

    const-string/jumbo v0, "iinocbcpar-ltmt/teaaopte"

    const/4 v2, 0x2

    const-string/jumbo v0, "ocrmt/eatlcnaosiipttpam-"

    const-string v0, "application/octet-stream"

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo p1, "s-umoedd"

    const-string p1, "-dmseeud"

    const/4 v2, 0x5

    const-string p1, "ddmoebs-"

    const-string p1, "des-mode"

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "CCB"

    const/4 v2, 0x4

    const-string v0, "CCB"

    const-string v0, "CBC"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-object p2
.end method

.method protected i()Lorg/json/JSONObject;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-object v0
.end method

.method protected n()Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x6

    and-int/2addr v5, v4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    const-string/jumbo v1, "naap_pue"

    const-string v1, "aean_pmp"

    const/4 v5, 0x1

    const-string/jumbo v1, "iaaen_pp"

    const-string v1, "api_name"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v2, "qkogsqld"

    const-string/jumbo v2, "qgds/klo"

    const-string v2, "dgs/lkos"

    const-string v2, "/sdk/log"

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "_simnorsaiv"

    const-string/jumbo v1, "issrainv_eo"

    const/4 v5, 0x3

    const-string v1, "_oniopiaves"

    const-string v1, "api_version"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "b..m0"

    const-string v2, "1..m0"

    const/4 v5, 0x1

    const-string v2, ".u100"

    const-string v2, "1.0.0"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, "gop_l"

    const-string v2, "go_lo"

    const-string v2, "glvqo"

    const-string/jumbo v2, "log_v"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v3, "0.1"

    const-string v3, "01."

    const/4 v5, 0x2

    const-string v3, ".10"

    const-string v3, "1.0"

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/alipay/sdk/packet/e;->e(Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    return-object v0
.end method
