.class public Lcom/alipay/sdk/packet/impl/c;
.super Lcom/alipay/sdk/packet/e;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected i()Lorg/json/JSONObject;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ys-~@ @~i@ ~o@ o~bM~@@~~@  @/  ~oc@o @@ 1~rm~of  ~ @~l~t@ ~iS bKdfa~t~~@ub@~v/4~i@ls.n~ o@ @@~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const-string v0, "eramsic"

    const-string v0, "assicer"

    const/4 v3, 0x4

    const-string v0, "hracosi"

    const-string v0, "cashier"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "edtmng"

    const/4 v3, 0x1

    const-string v1, "edtngb"

    const-string v1, "gentid"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/alipay/sdk/packet/e;->j(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method protected m()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "0u0o."

    const-string v0, ".0.0o"

    const/4 v2, 0x6

    const-string v0, "05p0."

    const-string v0, "5.0.0"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method
