.class public Lcom/alipay/sdk/packet/impl/f;
.super Lcom/alipay/sdk/packet/e;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected i()Lorg/json/JSONObject;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " 4s~@bbl@~cK m@n ~ 1-~if~~dr bMt@@.o @ l@u oSa~@@/ ~@ @v ~/ @~ ~fo@y@to~@o ~~i~  ~~@os~~~i~@@ ~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const-string/jumbo v0, "shamesc"

    const-string/jumbo v0, "sesrcha"

    const/4 v3, 0x7

    const-string/jumbo v0, "iaheosc"

    const-string v0, "cashier"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "main"

    const-string/jumbo v1, "imna"

    const-string/jumbo v1, "naim"

    const-string/jumbo v1, "main"

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-static {v0, v1}, Lcom/alipay/sdk/packet/e;->j(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method
