.class public Lcom/alipay/sdk/packet/impl/a;
.super Lcom/alipay/sdk/packet/e;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected i()Lorg/json/JSONObject;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4@s/ f@1u~i~@o@@ ~~@no@@ d~ @rMc~~m@ S@s~~~b~@ @t~~~o~oiK@ ~~f ay@@ ~l ./~  lo t~  @vb@-~@ob~@i "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string v0, "eirmhas"

    const-string v0, "cashier"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "naim"

    const/4 v3, 0x1

    const-string/jumbo v1, "mnia"

    const-string/jumbo v1, "main"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/alipay/sdk/packet/e;->j(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method
