.class public Lcom/alipay/sdk/packet/impl/e;
.super Lcom/alipay/sdk/packet/e;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @so@o.a1@v@  b i/@~o @@~sb~~~t~ /@od@~ ly~@ @ln~@~ucK ~ @of i~~@S ~ -@ ~@ b@ @~~~~t ~o~M@i4f@~r"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    const-string p1, " otmpsdmp"

    const-string/jumbo p1, "ptssdmpo "

    const/4 v5, 0x4

    const-string p1, "a spodptm"

    const-string/jumbo p1, "mdap post"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v0, "splm"

    const-string/jumbo v0, "mspl"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, p1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string p1, "UTF-8"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p3, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p3}, Lcom/alipay/sdk/encrypt/b;->a([B)[B

    move-result-object p3

    const/4 v5, 0x6

    const/4 v4, 0x4

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Lx0/b;->f()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string v3, "btdIu"

    const-string v3, "dtImu"

    const/4 v5, 0x2

    const-string v3, "duutd"

    const-string/jumbo v3, "utdId"

    const/4 v5, 0x0

    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "Hoaloerpg"

    const-string v2, "Hlarogdoe"

    const/4 v5, 0x6

    const-string/jumbo v2, "logHeader"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v3, "WRA"

    const-string v3, "RAW"

    const/4 v5, 0x6

    const-string v3, "RAW"

    const-string v3, "RAW"

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v2, "Cqdebzo"

    const-string/jumbo v2, "zbCoebd"

    const/4 v5, 0x3

    const-string/jumbo v2, "odsCzie"

    const-string v2, "bizCode"

    const/4 v5, 0x7

    const-string/jumbo v3, "ysumdlaip"

    const-string v3, "ayalsiupd"

    const/4 v5, 0x6

    const-string/jumbo v3, "sykaopild"

    const-string v3, "alipaysdk"

    const/4 v5, 0x7

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "doprIbtpd"

    const-string/jumbo v2, "rpduIodpt"

    const/4 v5, 0x1

    const-string/jumbo v2, "tIuproucd"

    const-string/jumbo v2, "productId"

    const/4 v5, 0x1

    const-string/jumbo v3, "qia_onppsikarddal"

    const-string/jumbo v3, "k_ndiyrsqildopaaa"

    const/4 v5, 0x1

    const-string v3, "alipaysdk_android"

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, "genosdE-qnontnCi"

    const-string/jumbo v2, "nisn-EnngdotecCo"

    const-string/jumbo v2, "ncsn-ogEteniotdC"

    const-string v2, "Content-Encoding"

    const/4 v5, 0x5

    const-string/jumbo v3, "zipG"

    const-string/jumbo v3, "pzGi"

    const/4 v5, 0x0

    const-string/jumbo v3, "zpGi"

    const-string v3, "Gzip"

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "dprmrucoVnmeot"

    const-string/jumbo v2, "rdemnopVurtcio"

    const/4 v5, 0x1

    const-string/jumbo v2, "rpnsooVudtciro"

    const-string/jumbo v2, "productVersion"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v3, "157..b"

    const-string v3, "15.7.7"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance v2, Lv0/a$a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v3, "lio.sluw.ggolwtgldhgdpasyo.:po-ocgoaple/Utmd//a/k"

    const-string/jumbo v3, "ytpooomggoleg.:ld/p.c/oplidU/g-lt/aohswdakswla.go"

    const/4 v5, 0x0

    const-string v3, "https://loggw-exsdk.alipay.com/loggw/logUpload.do"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v2, v3, v1, p3}, Lv0/a$a;-><init>(Ljava/lang/String;Ljava/util/Map;[B)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p2, v2}, Lv0/a;->b(Landroid/content/Context;Lv0/a$a;)Lv0/a$b;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v1, "gda bopp "

    const-string v1, "gamodb  p"

    const/4 v5, 0x6

    const-string v1, " d gpatoq"

    const-string/jumbo v1, "mdap got "

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, p3}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz p2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p2}, Lcom/alipay/sdk/packet/e;->l(Lv0/a$b;)Z

    move-result p3

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object p2, p2, Lv0/a$b;->c:[B

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz p3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p2}, Lcom/alipay/sdk/encrypt/b;->b([B)[B

    move-result-object p2

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p3, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-direct {p3, p2, p1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Lcom/alipay/sdk/packet/b;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string p2, ""

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p1, p2, p3}, Lcom/alipay/sdk/packet/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object p1

    :catch_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo p2, "nlsou lee iupsss"

    const-string/jumbo p2, "oun lsuspse ilne"

    const/4 v5, 0x3

    const-string/jumbo p2, "olRmnseslnspe  u"

    const-string p2, "Response is null"

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    throw p1
.end method

.method protected g(Lx0/a;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p2
.end method

.method protected h(ZLjava/lang/String;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method protected i()Lorg/json/JSONObject;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method
