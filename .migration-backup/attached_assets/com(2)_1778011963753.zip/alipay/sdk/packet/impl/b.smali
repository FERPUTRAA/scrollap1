.class public Lcom/alipay/sdk/packet/impl/b;
.super Lcom/alipay/sdk/packet/e;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/alipay/sdk/packet/e;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected i()Lorg/json/JSONObject;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const-string/jumbo v0, "nisodsfCk"

    const-string/jumbo v0, "iksCsfodn"

    const/4 v3, 0x6

    const-string/jumbo v0, "igsmfonCd"

    const-string/jumbo v0, "sdkConfig"

    const/4 v2, 0x1

    move v3, v2

    const-string v1, "bonaoi"

    const-string/jumbo v1, "oiamnb"

    const-string/jumbo v1, "nbitab"

    const-string/jumbo v1, "obtain"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/packet/e;->j(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method protected m()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, ".u.o0"

    const-string v0, "05..o"

    const/4 v2, 0x6

    const-string v0, ".0p05"

    const-string v0, "5.0.0"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method
