.class public abstract Lcom/alipay/sdk/packet/e;
.super Ljava/lang/Object;


# static fields
.field public static final c:Ljava/lang/String; = "msp-gzip"

.field public static final d:Ljava/lang/String; = "Msp-Param"

.field public static final e:Ljava/lang/String; = "Operation-Type"

.field public static final f:Ljava/lang/String; = "content-type"

.field public static final g:Ljava/lang/String; = "Version"

.field public static final h:Ljava/lang/String; = "AppId"

.field public static final i:Ljava/lang/String; = "des-mode"

.field public static final j:Ljava/lang/String; = "namespace"

.field public static final k:Ljava/lang/String; = "api_name"

.field public static final l:Ljava/lang/String; = "api_version"

.field public static final m:Ljava/lang/String; = "data"

.field public static final n:Ljava/lang/String; = "params"

.field public static final o:Ljava/lang/String; = "public_key"

.field public static final p:Ljava/lang/String; = "device"

.field public static final q:Ljava/lang/String; = "action"

.field public static final r:Ljava/lang/String; = "type"

.field public static final s:Ljava/lang/String; = "method"


# instance fields
.field protected a:Z

.field protected b:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    and-int/2addr v2, v1

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/alipay/sdk/packet/e;->a:Z

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/alipay/sdk/packet/e;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method protected static f(Lv0/a$b;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  sm~r / ~tf~ @t o~v ~@i~  @@@@~S@@@ 4oo@ y@a @o~~@fi~l@@~c b 1blo~/- ~d~n.uo~b~~Ki~@M~ @~@@s~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p0, :cond_3

    const/4 v1, 0x0

    move v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p0, p0, Lv0/a$b;->a:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x6

    const-string p1, ","

    const-string p1, ","

    const/4 v2, 0x0

    const-string p1, ","

    const-string p1, ","

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p0}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0

    :cond_3
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method protected static j(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x6

    const-string/jumbo v2, "tpey"

    const-string/jumbo v2, "tpey"

    const-string/jumbo v2, "tpey"

    const-string/jumbo v2, "type"

    const/4 v4, 0x1

    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo p0, "oehmds"

    const-string p0, "doseth"

    const/4 v4, 0x5

    const-string p0, "hmodot"

    const-string/jumbo p0, "method"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p0, "mcoatb"

    const-string/jumbo p0, "itcmoa"

    const/4 v4, 0x4

    const-string/jumbo p0, "uotcia"

    const-string p0, "action"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v0
.end method

.method private static k(Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x4

    const-string/jumbo v0, "mpaors"

    const-string v0, "amsroa"

    const/4 v4, 0x7

    const-string/jumbo v0, "rmqpaa"

    const-string/jumbo v0, "params"

    const/4 v3, 0x7

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    return v2

    :cond_0
    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const-string p0, "data"

    const/4 v4, 0x7

    const-string p0, "dtaa"

    const-string p0, "data"

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v2

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v0, "ibsukcpe_y"

    const-string v0, "cepiybukb_"

    const-string/jumbo v0, "public_key"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/data/b;->e(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 p0, 0x3

    const/4 p0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    move v2, p0

    move v2, p0

    const/4 v4, 0x6

    move v2, p0

    move v2, p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_2
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v2
.end method

.method protected static l(Lv0/a$b;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "imum-ppg"

    const-string/jumbo v0, "pgmpisu-"

    const/4 v2, 0x0

    const-string/jumbo v0, "pzgmops-"

    const-string/jumbo v0, "msp-gzip"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/alipay/sdk/packet/e;->f(Lv0/a$b;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0
.end method


# virtual methods
.method public a(Lx0/a;Landroid/content/Context;)Lcom/alipay/sdk/packet/b;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lcom/alipay/sdk/packet/e;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1
.end method

.method public b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p2}, Lcom/alipay/sdk/util/k;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/alipay/sdk/packet/e;->c(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1
.end method

.method public c(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v5, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual/range {v0 .. v5}, Lcom/alipay/sdk/packet/e;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Z)Lcom/alipay/sdk/packet/b;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-object p1
.end method

.method protected d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Z)Lcom/alipay/sdk/packet/b;
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v1, "tkacpbPe"

    const-string v1, "etac kPp"

    const-string v1, "e:ct Pua"

    const-string v1, "Packet: "

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string/jumbo v1, "slpm"

    const-string/jumbo v1, "mpls"

    const/4 v9, 0x1

    const-string/jumbo v1, "mspl"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v1, v0}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-instance v0, Lcom/alipay/sdk/packet/c;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-boolean v1, p0, Lcom/alipay/sdk/packet/e;->b:Z

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {v0, v1}, Lcom/alipay/sdk/packet/c;-><init>(Z)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-instance v1, Lcom/alipay/sdk/packet/b;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/packet/e;->n()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/packet/e;->i()Lorg/json/JSONObject;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p0, p1, p3, v3}, Lcom/alipay/sdk/packet/e;->g(Lx0/a;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v1, v2, v3}, Lcom/alipay/sdk/packet/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0, v2, p3}, Lcom/alipay/sdk/packet/e;->h(ZLjava/lang/String;)Ljava/util/Map;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-boolean v3, p0, Lcom/alipay/sdk/packet/e;->a:Z

    const/4 v9, 0x3

    const-string/jumbo v4, "rSi"

    const-string/jumbo v4, "irS"

    const/4 v9, 0x5

    const-string/jumbo v4, "irS"

    const-string/jumbo v4, "iSr"

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    check-cast v5, Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v1, v3, v5}, Lcom/alipay/sdk/packet/c;->c(Lcom/alipay/sdk/packet/b;ZLjava/lang/String;)Lcom/alipay/sdk/packet/d;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v1}, Lcom/alipay/sdk/packet/d;->a()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0, v3, p3}, Lcom/alipay/sdk/packet/e;->h(ZLjava/lang/String;)Ljava/util/Map;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance v5, Lv0/a$a;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v1}, Lcom/alipay/sdk/packet/d;->b()[B

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-direct {v5, p4, v3, v1}, Lv0/a$a;-><init>(Ljava/lang/String;Ljava/util/Map;[B)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p2, v5}, Lv0/a;->b(Landroid/content/Context;Lv0/a$a;)Lv0/a$b;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v1}, Lcom/alipay/sdk/packet/e;->l(Lv0/a$b;)Z

    move-result v3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, v1, Lv0/a$b;->c:[B

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v5, Lcom/alipay/sdk/packet/d;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v5, v3, v1}, Lcom/alipay/sdk/packet/d;-><init>(Z[B)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v5, v1}, Lcom/alipay/sdk/packet/c;->b(Lcom/alipay/sdk/packet/d;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    if-eqz v0, :cond_0

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/packet/b;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v1}, Lcom/alipay/sdk/packet/e;->k(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-eqz v1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz p5, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual/range {v2 .. v7}, Lcom/alipay/sdk/packet/e;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Z)Lcom/alipay/sdk/packet/b;

    move-result-object v0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    return-object v0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo p2, "niesq lpsRulnpoe "

    const-string/jumbo p2, "lneipsloq su.R ne"

    const/4 v9, 0x7

    const-string p2, " lonspsRqe.lenusi"

    const-string p2, "Response is null."

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    throw p1
.end method

.method protected e(Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    if-eqz p2, :cond_2

    const/4 v4, 0x0

    move v5, v4

    new-instance p1, Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v3, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string p2, "apsass"

    const-string p2, "apsasm"

    const-string/jumbo p2, "sramam"

    const-string/jumbo p2, "params"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x6

    const-string p1, "dtaa"

    const-string p1, "atad"

    const/4 v5, 0x3

    const-string/jumbo p1, "tada"

    const-string p1, "data"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    return-object p1
.end method

.method protected g(Lx0/a;Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v2, Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v2, p3}, Lcom/alipay/sdk/util/c;->a(Lorg/json/JSONObject;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p3

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v2, "ee_ioxonnrlma"

    const-string/jumbo v2, "rotmxeae_nlin"

    const/4 v5, 0x5

    const-string v2, "a_tfnbeleorxi"

    const-string v2, "external_info"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p3, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string p2, "dit"

    const-string/jumbo p2, "idt"

    const/4 v5, 0x0

    const-string/jumbo p2, "idt"

    const-string/jumbo p2, "tid"

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo p2, "raueo_unge"

    const-string p2, "ges_oanure"

    const/4 v5, 0x6

    const-string/jumbo p2, "user_agent"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Lx0/b;->d()Lcom/alipay/sdk/data/b;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2, p1, v1}, Lcom/alipay/sdk/data/b;->d(Lx0/a;Lcom/alipay/sdk/tid/c;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x5

    const-string p2, "_hpalbsayi"

    const/4 v5, 0x6

    const-string p2, "ha_ilaspya"

    const-string p2, "has_alipay"

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v3, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1, v2, v3}, Lcom/alipay/sdk/util/l;->y(Lx0/a;Landroid/content/Context;Ljava/util/List;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo p2, "ps_paasuq_m"

    const-string p2, "haspmau_p_s"

    const/4 v5, 0x6

    const-string/jumbo p2, "pmsas_hpps_"

    const-string p2, "has_msp_app"

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-static {v2}, Lcom/alipay/sdk/util/l;->o(Landroid/content/Context;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo p2, "pp_myak"

    const-string/jumbo p2, "ppp_yka"

    const/4 v5, 0x7

    const-string/jumbo p2, "kaypo_p"

    const-string p2, "app_key"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string v2, "00021b5q16020208"

    const-string v2, "10201626q0000852"

    const/4 v5, 0x2

    const-string v2, "268002u145016000"

    const-string v2, "2014052600006128"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string p2, "ddpst"

    const-string/jumbo p2, "tusdd"

    const/4 v5, 0x3

    const-string/jumbo p2, "utiqd"

    const-string/jumbo p2, "utdid"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Lx0/b;->f()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p3, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string p2, "eis_eynncl_mwe"

    const-string/jumbo p2, "nk_mniceye_elw"

    const/4 v5, 0x2

    const-string/jumbo p2, "nekm_lecn_wtey"

    const-string/jumbo p2, "new_client_key"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/alipay/sdk/tid/c;->f()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p3, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x5

    const-string/jumbo p2, "pa"

    const-string/jumbo p2, "pa"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/alipay/sdk/data/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p3, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v0, "biz"

    const-string v0, "biz"

    const/4 v5, 0x0

    const-string/jumbo v0, "zbi"

    const-string v0, "biz"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v1, "rrdyoBE"

    const-string v1, "dyEBoro"

    const-string v1, "BodyErr"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1, v0, v1, p2}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {p2}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1
.end method

.method protected h(ZLjava/lang/String;)Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "gm-ipbbs"

    const-string/jumbo v1, "psm-ibpg"

    const/4 v3, 0x6

    const-string/jumbo v1, "iz-pgpus"

    const-string/jumbo v1, "msp-gzip"

    const/4 v2, 0x1

    move v3, v2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string p1, "euryeTip-pOoap"

    const-string p1, "aeertTuippoyO-"

    const-string/jumbo p1, "pnytoeOrqapeT-"

    const-string p1, "Operation-Type"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v1, ".pstepalhhpyra.sc.ssbideitiscpya."

    const-string/jumbo v1, "t..iamapcsaydclhetpss.phireysp.bi"

    const/4 v3, 0x4

    const-string/jumbo v1, "ycsmi.pyssi.hsttaapblhaip..reeacd"

    const-string v1, "alipay.msp.cashier.dispatch.bytes"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    const-string/jumbo p1, "tneptetcqy-o"

    const/4 v3, 0x3

    const-string/jumbo p1, "tncton-tpeoe"

    const-string p1, "content-type"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const-string/jumbo v1, "otanobcc/rstltepam-eaiip"

    const-string v1, "application/octet-stream"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string p1, "erssnVo"

    const/4 v3, 0x0

    const-string/jumbo p1, "sVinoru"

    const-string p1, "Version"

    const/4 v3, 0x6

    const-string v1, "20."

    const-string v1, "2.0"

    const/4 v2, 0x0

    and-int/2addr v3, v2

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p1, "dApIm"

    const-string p1, "IdpmA"

    const/4 v3, 0x2

    const-string p1, "AppId"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "ToqAOO"

    const-string v1, "OABToO"

    const/4 v3, 0x5

    const-string v1, "OAsBOT"

    const-string v1, "TAOBAO"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    const-string p1, "am-maMpPr"

    const-string p1, "Msp-Param"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p2}, Lcom/alipay/sdk/packet/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p1, "ed-dooms"

    const-string/jumbo p1, "meosdb-d"

    const/4 v3, 0x2

    const-string p1, "dsd-eboe"

    const-string p1, "des-mode"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string p2, "CBC"

    const/4 v3, 0x3

    const-string p2, "CBC"

    const-string p2, "CBC"

    const/4 v3, 0x4

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method

.method protected abstract i()Lorg/json/JSONObject;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation
.end method

.method protected m()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, ".u4.9"

    const-string v0, ".u4.9"

    const/4 v2, 0x5

    const-string v0, "..p40"

    const-string v0, "4.9.0"

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method protected n()Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-string v1, "device"

    const/4 v4, 0x6

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "nscampeaq"

    const-string v1, "eecsamnpa"

    const/4 v4, 0x1

    const-string/jumbo v1, "sasecpmea"

    const-string/jumbo v1, "namespace"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v2, "almmoyarp.beqoiei.masclh"

    const-string v2, ".pailibyqeeoamiahols.cmr"

    const/4 v4, 0x4

    const-string/jumbo v2, "osimopie.cholyelaam.ibra"

    const-string v2, "com.alipay.mobilecashier"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "ipea_ban"

    const-string/jumbo v1, "p_saniae"

    const-string v1, "api_name"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v2, "lacmymucopaipy.a"

    const-string v2, "alamcioy.pycp.ma"

    const/4 v4, 0x4

    const-string v2, ".opmmicpcalyapa."

    const-string v2, "com.alipay.mcpay"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "vorniipeqsa"

    const-string v1, "eiioonpsarv"

    const/4 v4, 0x6

    const-string/jumbo v1, "iesso_vrpia"

    const-string v1, "api_version"

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/packet/e;->m()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Ljava/util/HashMap;

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/alipay/sdk/packet/e;->e(Ljava/util/HashMap;Ljava/util/HashMap;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-object v0
.end method
