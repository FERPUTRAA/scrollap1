.class public final Lcom/alipay/sdk/packet/c;
.super Ljava/lang/Object;


# instance fields
.field private a:Z

.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/alipay/sdk/packet/c;->a:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/16 p1, 0x18

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/util/l;->e(I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/packet/c;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private static a(Ljava/lang/String;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@slo@b ~~~ @~~@  r4@d~.~@~ ~  @o~ @/@ ooiniy @ ~~  1@@@@c@t@Komf/@ us@oai-~f ~v  b~~~tSlM~~~~b~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p0
.end method

.method private static d(I)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object p0, v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const-string p0, "50%d"

    const-string p0, "50%d"

    const/4 v4, 0x7

    const-string p0, "5d%0"

    const-string p0, "%05d"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0, p0, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0
.end method

.method private static e(Ljava/lang/String;Ljava/lang/String;)[B
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/alipay/sdk/encrypt/d;->a(Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method private static f(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 2

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/encrypt/e;->b(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-object p0
.end method

.method private static varargs g([[B)[B
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz p0, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    array-length v1, p0

    const/4 v8, 0x7

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto/16 :goto_6

    :cond_0
    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v2, Ljava/io/DataOutputStream;

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v2, v1}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v8, 0x2

    const/4 v7, 0x3

    array-length v3, p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-ge v4, v3, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    aget-object v5, p0, v4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    array-length v6, v5

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-static {v6}, Lcom/alipay/sdk/packet/c;->d(I)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v2, v6}, Ljava/io/OutputStream;->write([B)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v2, v5}, Ljava/io/OutputStream;->write([B)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    :catch_0
    :goto_1
    :try_start_4
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_3

    :catch_1
    move-exception p0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    goto :goto_2

    :catchall_0
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    goto :goto_4

    :catch_2
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_2

    :catchall_1
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto :goto_5

    :catch_3
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_2
    :try_start_5
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v1, :cond_2

    :try_start_6
    const/4 v7, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    :catch_4
    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v2, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :catch_5
    :cond_3
    :goto_3
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object v0

    :catchall_2
    move-exception p0

    :goto_4
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_5
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_4

    :try_start_7
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_6

    :catch_6
    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x5

    if-eqz v2, :cond_5

    :try_start_8
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_7

    :catch_7
    :cond_5
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    throw p0

    :cond_6
    :goto_6
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object v0
.end method

.method private static h(Ljava/lang/String;[BLjava/lang/String;)[B
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/encrypt/e;->d(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p0
.end method


# virtual methods
.method public b(Lcom/alipay/sdk/packet/d;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/alipay/sdk/packet/d;->b()[B

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x5

    :try_start_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-array v3, v2, [B

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance v4, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v4, v3}, Ljava/lang/String;-><init>([B)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v4}, Lcom/alipay/sdk/packet/c;->a(Ljava/lang/String;)I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    new-array v3, v3, [B

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v3}, Ljava/io/InputStream;->read([B)I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v4, Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v4, v3}, Ljava/lang/String;-><init>([B)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-array v2, v2, [B

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/io/InputStream;->read([B)I

    const/4 v5, 0x3

    move v6, v5

    new-instance v3, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v3, v2}, Ljava/lang/String;-><init>([B)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v3}, Lcom/alipay/sdk/packet/c;->a(Ljava/lang/String;)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-lez v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-array v2, v2, [B

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Ljava/io/InputStream;->read([B)I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-boolean v3, p0, Lcom/alipay/sdk/packet/c;->a:Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/alipay/sdk/packet/c;->b:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v3, v2, p2}, Lcom/alipay/sdk/packet/c;->h(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object v2

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/alipay/sdk/packet/d;->a()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v2}, Lcom/alipay/sdk/encrypt/b;->b([B)[B

    move-result-object v2

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {p1, v2}, Ljava/lang/String;-><init>([B)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    :try_start_3
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4

    const/4 v6, 0x6

    goto :goto_2

    :catch_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_1

    :catch_1
    move-exception p1

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_3

    :catch_2
    move-exception p1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    :goto_1
    :try_start_4
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    :try_start_5
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    :catch_3
    :cond_3
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :catch_4
    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v4, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez p1, :cond_4

    const/4 v5, 0x3

    move v6, v5

    return-object v0

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance p2, Lcom/alipay/sdk/packet/b;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p2, v4, p1}, Lcom/alipay/sdk/packet/b;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p2

    :catchall_1
    move-exception p1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_5

    :try_start_6
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_5

    :catch_5
    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    throw p1
.end method

.method public c(Lcom/alipay/sdk/packet/b;ZLjava/lang/String;)Lcom/alipay/sdk/packet/d;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez p1, :cond_0

    const/4 v7, 0x5

    const/4 p1, 0x0

    const/4 v7, 0x1

    move v6, p1

    move v6, p1

    return-object p1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/alipay/sdk/packet/b;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1}, Lcom/alipay/sdk/packet/b;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz p2, :cond_1

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/encrypt/b;->a([B)[B

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_0

    :catch_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    move p2, v1

    move p2, v1

    const/4 v7, 0x7

    move p2, v1

    move p2, v1

    :cond_1
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-boolean v2, p0, Lcom/alipay/sdk/packet/c;->a:Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x6

    move v7, v6

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/alipay/sdk/packet/c;->b:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v5, Lt0/a;->e:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v2, v5}, Lcom/alipay/sdk/packet/c;->e(Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v5, p0, Lcom/alipay/sdk/packet/c;->b:Ljava/lang/String;

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    invoke-static {v5, p1, p3}, Lcom/alipay/sdk/packet/c;->f(Ljava/lang/String;[BLjava/lang/String;)[B

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 p3, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-array p3, p3, [[B

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    aput-object v0, p3, v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    aput-object v2, p3, v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    aput-object p1, p3, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p3}, Lcom/alipay/sdk/packet/c;->g([[B)[B

    move-result-object p1

    const/4 v7, 0x4

    goto :goto_1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-array p3, v4, [[B

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    aput-object v0, p3, v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput-object p1, p3, v3

    const/4 v7, 0x4

    invoke-static {p3}, Lcom/alipay/sdk/packet/c;->g([[B)[B

    move-result-object p1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p3, Lcom/alipay/sdk/packet/d;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p3, p2, p1}, Lcom/alipay/sdk/packet/d;-><init>(Z[B)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-object p3
.end method
