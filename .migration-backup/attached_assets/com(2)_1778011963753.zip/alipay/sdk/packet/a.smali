.class public Lcom/alipay/sdk/packet/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "o so ~b@@n ~lKo~u.@ r~  t@@c~d@@-o@i@ My~@i~i/vm ~/~1@~~~ 4 ~s~@@o ~~a f @~o ~b~ lt~@@bS~ ~ @@f@"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-object v1

    :cond_0
    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v0, "&"

    const-string v0, "&"

    const/4 v10, 0x1

    const-string v0, "&"

    const-string v0, "&"

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    array-length v0, p0

    const/4 v10, 0x6

    if-nez v0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    return-object v1

    :cond_1
    const/4 v9, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    array-length v0, p0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x1

    move v6, v1

    move v6, v1

    const/4 v10, 0x3

    move v6, v1

    move v6, v1

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ge v6, v0, :cond_6

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    aget-object v7, p0, v6

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v8, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x4

    invoke-static {v7}, Lcom/alipay/sdk/packet/a;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v8, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {v7}, Lcom/alipay/sdk/packet/a;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-eqz v8, :cond_4

    const/4 v9, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {v7}, Lcom/alipay/sdk/packet/a;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v8, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v7}, Lcom/alipay/sdk/packet/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :cond_5
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_0

    :cond_6
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    const-string v6, ";"

    const-string v6, ";"

    const/4 v10, 0x1

    const-string v6, ";"

    const-string v6, ";"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-nez v0, :cond_7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const-string/jumbo v7, "p=zmts_yb"

    const-string/jumbo v7, "ytsbi=_zp"

    const-string v7, "be_yoiztp"

    const-string v7, "biz_type="

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez v0, :cond_8

    const/4 v10, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string v2, "bzo=mbi"

    const-string/jumbo v2, "oizm_b="

    const/4 v10, 0x7

    const-string/jumbo v2, "ibz=nou"

    const-string v2, "biz_no="

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-nez v0, :cond_9

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo v2, "r_aodenp="

    const-string v2, "_or=oedan"

    const/4 v10, 0x1

    const-string v2, "=raeto_dq"

    const-string/jumbo v2, "trade_no="

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_9
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-nez v0, :cond_a

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    move v10, v9

    const-string/jumbo v2, "upsdpe=sbri"

    const-string/jumbo v2, "prsuibdpea="

    const/4 v10, 0x5

    const-string v2, "_=pmdisreau"

    const-string v2, "app_userid="

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_a
    const/4 v10, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p0, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz v0, :cond_b

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_b
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-object p0
.end method

.method private static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "puyio_ze"

    const-string v0, "_ezbpiuy"

    const/4 v2, 0x5

    const-string v0, "bpe_zbyi"

    const-string v0, "biz_type"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/packet/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method private static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "uioz_p"

    const-string v0, "_pbizo"

    const/4 v2, 0x5

    const-string v0, "biz_no"

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/packet/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method private static d(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "atq_oerp"

    const-string/jumbo v0, "qodeta_r"

    const/4 v2, 0x3

    const-string/jumbo v0, "qe_naodr"

    const-string/jumbo v0, "trade_no"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "ntso_ar_oseu"

    const-string/jumbo v0, "r_souatteo_n"

    const/4 v2, 0x3

    const-string v0, "aonmtrue_dot"

    const-string/jumbo v0, "out_trade_no"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/packet/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-object p0

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x2

    move v2, v1

    return-object p0
.end method

.method private static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "="

    const-string v0, "="

    const/4 v3, 0x0

    const-string v0, "="

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    array-length v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-le v0, v1, :cond_0

    const/4 v3, 0x4

    aget-object p0, p0, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "//"

    const/4 v3, 0x4

    const-string v0, "//"

    const-string v0, "\""

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p0, 0x0

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0
.end method

.method private static f(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo v0, "rsdmu_ippa"

    const/4 v2, 0x3

    const-string v0, "daruoipse_"

    const-string v0, "app_userid"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/packet/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method
