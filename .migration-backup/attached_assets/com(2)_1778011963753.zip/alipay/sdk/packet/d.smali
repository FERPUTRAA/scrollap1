.class final Lcom/alipay/sdk/packet/d;
.super Ljava/lang/Object;


# instance fields
.field private final a:Z

.field private final b:[B


# direct methods
.method constructor <init>(Z[B)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/alipay/sdk/packet/d;->a:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/alipay/sdk/packet/d;->b:[B

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l@su@fK n~~~oy@  @odto/~~@~~~M ic~@~~@~ -@ So a bm~@vo4@   tf1@@@~ /~~ @~@b i ~~o@@ @@l ib~@.s~r"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/alipay/sdk/packet/d;->a:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method b()[B
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/packet/d;->b:[B

    return-object v0
.end method
