.class public final Lcom/alipay/sdk/packet/b;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/packet/b;->a:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/alipay/sdk/packet/b;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~s@~@@ i~@@-1~bo~ t ~ o  ~ svo~~ ~ orf@d~ @@l @~ ~@  o~ /@ii ~y ./uK@@@am@@o@4M~c@~tS~@bl~~~n@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/packet/b;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/packet/b;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public c()Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/packet/b;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    return-object v1

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/alipay/sdk/packet/b;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v1, v0

    move-object v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v1
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/packet/b;->a:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/alipay/sdk/packet/b;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "<btmo>stne=eLe%rd s%slop e="

    const-string v1, "e<s=pdlret Loes%tn =ebos>%v"

    const/4 v4, 0x4

    const-string v1, "e=stolop<%yobL>re n% std=ve"

    const-string v1, "<Letter envelop=%s body=%s>"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method
