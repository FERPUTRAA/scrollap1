.class public final Lcom/alipay/sdk/util/l$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/util/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Landroid/content/pm/PackageInfo;

.field public final b:I

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/pm/PackageInfo;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Lcom/alipay/sdk/util/l$b;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/alipay/sdk/util/l$b;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y~sro @.to~~/t  @~~@bi@/~@~fb  S@@o~~~va~ ~~  K@~~~cdms@ @~ ~ oul in f@@ oi@~@blM~@4~-@1@ o~@  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v1, p0, Lcom/alipay/sdk/util/l$b;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ge v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0
.end method

.method public b(Lx0/a;)Z
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    array-length v2, v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-nez v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    array-length v2, v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v3, v1

    move v3, v1

    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ge v3, v2, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    aget-object v4, v0, v3

    const/4 v7, 0x6

    invoke-virtual {v4}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p1, v4}, Lcom/alipay/sdk/util/l;->l(Lx0/a;[B)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v4, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v5, p0, Lcom/alipay/sdk/util/l$b;->c:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v4, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v5, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v0, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    aput-object v4, v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/util/l$b;->c:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    aput-object v1, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v1, " xsmtee%dG e ,osps%"

    const-string v1, "%es, ps% tGco sxdee"

    const/4 v7, 0x2

    const-string/jumbo v1, "teG o est sepdxco,%"

    const-string v1, "Got %s, expected %s"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v1, "bzi"

    const-string v1, "bzi"

    const/4 v7, 0x3

    const-string v1, "bzi"

    const-string v1, "biz"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v3, "embtPbUlmyhcuian"

    const-string v3, "PUtmieymbhcnaluc"

    const/4 v7, 0x0

    const-string/jumbo v3, "ucbPlcunmhatUyeK"

    const-string v3, "PublicKeyUnmatch"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p1, v1, v3, v0}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_2
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    return v1
.end method
