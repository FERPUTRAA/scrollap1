.class public Lcom/alipay/sdk/util/l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/util/l$b;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "com.alipay.android.app"

.field static final b:Ljava/lang/String; = "com.eg.android.AlipayGphone"

.field private static final c:Ljava/lang/String; = "com.eg.android.AlipayGphoneRC"

.field private static final d:I = 0x63

.field private static final e:[Ljava/lang/String;

.field static final f:I = 0x7d


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v0, "15s.311.01s150"

    const-string v0, "51s10105.1.131"

    const/4 v3, 0x3

    const-string v0, "0.0m531.1.1511"

    const-string v0, "10.1.5.1013151"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "..0.o811041513"

    const-string v1, "10.1.5.1013148"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/alipay/sdk/util/l;->e:[Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static A(Landroid/content/Context;)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "lou@~bc id-~~S/r~ @~t m ~@@ @n@i @~@ ~~o ~ ~y~~~~@K@@bs @@@ vM1 4~to~ o o@@ @l/if~@~.ao~~ ~f @bb"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    invoke-static {}, Lcom/alipay/sdk/util/l;->u()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/sdk/util/l;->z()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/l;->E(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/l;->G(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v4, "( "

    const-string v4, "( "

    const/4 v6, 0x1

    const-string v4, " ("

    const-string v4, " ("

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v0, ";"

    const-string v0, ";"

    const/4 v6, 0x5

    const-string v0, ";"

    const-string v0, ";"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string p0, ")"

    const-string p0, ")"

    const/4 v6, 0x7

    const-string p0, ")"

    const-string p0, ")"

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string p0, "a s)(iudrndkm"

    const-string/jumbo p0, "s(dmdrank )io"

    const/4 v6, 0x1

    const-string/jumbo p0, "sir akdpoddn)"

    const-string p0, "(sdk android)"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object p0
.end method

.method public static B(Lx0/a;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v1, "..rdaiPtqdryetsosmsioooeenp"

    const-string/jumbo v1, "ttseom.iSdropasndos.Pyereoi"

    const/4 v8, 0x3

    const-string/jumbo v1, "mosesiopydetPaerrsr.intdso."

    const-string v1, "android.os.SystemProperties"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const-string v2, "etg"

    const-string/jumbo v2, "teg"

    const/4 v8, 0x4

    const-string v2, "egt"

    const-string v2, "get"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x0

    move v8, v7

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x4

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    aput-object v5, v4, v6

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    aput-object p1, v2, v6

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string v1, "biz"

    const-string/jumbo v1, "ibz"

    const/4 v8, 0x1

    const-string/jumbo v1, "zbi"

    const-string v1, "biz"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo v2, "rflex"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p0, v1, v2, p1}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object v0
.end method

.method public static C(Ljava/lang/String;)Lorg/json/JSONObject;
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :catchall_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public static D()I
    .locals 3

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/16 v0, -0xc8

    :goto_0
    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public static E(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public static F(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "vnamp/p-((+?/[d9t|0.]*/)eaah/*y(o/ia):y(^e.i:)_)/b/d||a/.omtp(?/$))o/st/+al-(?tbacl"

    const-string v0, ")]patba(|-p?0/+?ey/(ht)-o|_)o?/(a.te//l/iv/c/l/a+a(d)oay|(t[/*p(-s.i:)9d/n^b.*:$)am"

    const/4 v2, 0x1

    const-string v0, ")(/(oa/o)tal||i[n.z+s))-(--??/a?mpp(/d0//a.ae)a/ohb/$:/o:d.^le(/ct+y(9)ptayi]*v_|/*"

    const-string v0, "^http(s)?://([a-z0-9_\\-]+\\.)*(alipaydev|alipay|taobao)\\.(com|net)(:\\d+)?(/.*)?$"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->matches()Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    return p0
.end method

.method public static G(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    invoke-static {p0}, Lcom/alipay/sdk/util/l;->O(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    iget v1, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string v1, "*"

    const-string v1, "*"

    const/4 v3, 0x5

    const-string v1, "*"

    const-string v1, "*"

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0
.end method

.method public static H(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "%s%s"

    const-string v1, "%s%s"

    const/4 v5, 0x0

    const-string/jumbo v1, "s%s%"

    const-string v1, "%s%s"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    aput-object v0, v2, v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    aput-object p0, v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string p0, "-"

    const-string p0, "-"

    const/4 v5, 0x2

    const-string p0, "-"

    const-string p0, "-"

    const/4 v5, 0x2

    return-object p0
.end method

.method public static I()Z
    .locals 8

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/alipay/sdk/data/a;->r()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v2, "|//"

    const-string v2, "//|"

    const/4 v7, 0x7

    const-string v2, "\\|"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    return v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    array-length v3, v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ge v4, v3, :cond_2

    const/4 v6, 0x1

    move v7, v6

    aget-object v5, v1, v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v2, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v5, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v0, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    return v0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x4

    move v7, v6

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    return v0

    :catchall_0
    move-exception v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    return v0
.end method

.method private static J()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v0, "/n"

    const-string/jumbo v0, "n/"

    const-string/jumbo v0, "n/"

    const-string v0, "\n"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo v1, "unleabaaUbl"

    const-string v1, "Uaabnlualve"

    const/4 v7, 0x6

    const-string/jumbo v1, "nUaelaualbi"

    const-string v1, "Unavailable"

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v3, Ljava/io/FileReader;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v4, "spierpoponrcv"

    const-string v4, "er/rovnpspioc"

    const/4 v7, 0x0

    const-string/jumbo v4, "ioner/r/qpovs"

    const-string v4, "/proc/version"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v3, v4}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/16 v4, 0x100

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v2, v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string v2, "^/s/+(?/wM[+/(/))]^[/+/)/E//]?s(^s*)./^([[+s/T*()+/s])*(?/P]/+(/+q)/.+///[+^+^//+//s/[/)E]/)?)ss@^:]///s*/:/+][@/R?+((+w))^(/([/?/ssPs)]/"

    const-string v2, ")//??^w[q/(?+(+/s(//+/((^+[(//+/^/*/P]E[(E[ss/])/)//////))*/)s](:/s/.[/)[?)Pw[/)+/(R+]^/]*)^?+:./@/+/s///]?+s^]@))//T(^+s[^s(Ms/]/)/+*+s+"

    const/4 v7, 0x4

    const-string v2, "/P(m]]?/)?///^(^//+*(]@]M/[w[///(]E/[s(T/(//)/?)^+sw+:ss:)s??+)//)*E+/s]^./(/^/sP]/^[+(+)+:+)s+[)s//?++//)*s+[(./[//R/)])/(^/(*@/s/)+//[^"

    const-string v2, "\\w+\\s+\\w+\\s+([^\\s]+)\\s+\\(([^\\s@]+(?:@[^\\s.]+)?)[^)]*\\)\\s+\\((?:[^(]*\\([^)]*\\))?[^)]*\\)\\s+([^\\s]+)\\s+(?:PREEMPT\\s+)?(.+)"

    const/4 v6, 0x5

    move v7, v6

    invoke-static {v2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v3, :cond_0

    const/4 v7, 0x7

    return-object v1

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->groupCount()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v4, 0x4

    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-ge v3, v4, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-object v1

    :cond_1
    const/4 v6, 0x5

    move v7, v6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v5, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v5, " "

    const-string v5, " "

    const/4 v7, 0x7

    const-string v5, " "

    const-string v5, " "

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/4 v5, 0x3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v2, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    throw v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v1
.end method

.method public static K(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/util/k;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "://"

    const-string v0, "/:/"

    const/4 v3, 0x7

    const-string v0, "/:/"

    const-string v0, "://"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0
.end method

.method public static L(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const-string v0, "5DM"

    const-string v0, "M5D"

    const/4 v2, 0x7

    const-string v0, "MD5"

    const-string v0, "MD5"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->update([B)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/util/l;->m([B)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0

    :catch_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public static M(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string/jumbo p0, "s-;1o"

    const-string p0, "1;s1-"

    const/4 v1, 0x3

    const-string p0, "b-11-"

    const-string p0, "-1;-1"

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public static N(Landroid/content/Context;)Landroid/content/pm/ActivityInfo;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    instance-of v1, p0, Landroid/app/Activity;

    const/4 v8, 0x4

    if-eqz v1, :cond_1

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v1, Landroid/app/Activity;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x1

    xor-int/2addr v8, v7

    invoke-virtual {v2, p0, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->activities:[Landroid/content/pm/ActivityInfo;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    array-length v2, p0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-ge v3, v2, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    aget-object v4, p0, v3

    const/4 v8, 0x7

    iget-object v5, v4, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v5, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v5, :cond_0

    const/4 v8, 0x7

    return-object v4

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    return-object v0

    :catchall_0
    move-exception p0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-object v0
.end method

.method private static O(Landroid/content/Context;)Landroid/util/DisplayMetrics;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Landroid/util/DisplayMetrics;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "uonidw"

    const-string/jumbo v1, "niwmod"

    const/4 v3, 0x6

    const-string/jumbo v1, "opwinw"

    const-string/jumbo v1, "window"

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p0, Landroid/view/WindowManager;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method private static a(Landroid/content/pm/PackageInfo;ILjava/lang/String;)Lcom/alipay/sdk/util/l$b;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/alipay/sdk/util/l$b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1, p2}, Lcom/alipay/sdk/util/l$b;-><init>(Landroid/content/pm/PackageInfo;ILjava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object v0
.end method

.method private static b(Lx0/a;Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)Lcom/alipay/sdk/util/l$b;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, "amo.dliGq.gdr.aohpoeynpAcei"

    const-string v0, "i.y.ooidlercengnmdpaGhAaop."

    const/4 v3, 0x7

    const-string v0, "i.snAg.dnyaolGheidopmrp.eco"

    const-string v0, "com.eg.android.AlipayGphone"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string p2, "dAnoGbgReoon.ip.mraidlheayp.C"

    const/4 v3, 0x0

    const-string p2, ".apmnpCmi.iRyGdceo.dgAaoorlhn"

    const-string p2, "com.eg.android.AlipayGphoneRC"

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    move v3, v0

    :try_start_0
    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lcom/alipay/sdk/util/l;->t(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/PackageInfo;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p2, "cIPGxoueegnEafka"

    const/4 v3, 0x2

    const-string p2, "GenEoIxcaPogaetf"

    const-string p2, "GetPackageInfoEx"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "htua"

    const-string/jumbo v1, "uath"

    const/4 v3, 0x7

    const-string v1, "ahtu"

    const-string v1, "auth"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, v1, p2, p1}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/l;->q(Lx0/a;Landroid/content/pm/PackageInfo;)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-nez p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1, p3, p4}, Lcom/alipay/sdk/util/l;->a(Landroid/content/pm/PackageInfo;ILjava/lang/String;)Lcom/alipay/sdk/util/l$b;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p0
.end method

.method public static c(Lx0/a;Landroid/content/Context;Ljava/util/List;)Lcom/alipay/sdk/util/l$b;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;)",
            "Lcom/alipay/sdk/util/l$b;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    if-nez p2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast v1, Lcom/alipay/sdk/data/a$b;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, v1, Lcom/alipay/sdk/data/a$b;->a:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v3, v1, Lcom/alipay/sdk/data/a$b;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/alipay/sdk/data/a$b;->c:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p0, p1, v2, v3, v1}, Lcom/alipay/sdk/util/l;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)Lcom/alipay/sdk/util/l$b;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, p0}, Lcom/alipay/sdk/util/l$b;->b(Lx0/a;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/alipay/sdk/util/l$b;->a()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    return-object v1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-object v0
.end method

.method static d()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "oicGleCpAndhoroRmya.i..dgppea"

    const/4 v3, 0x6

    const-string/jumbo v0, "ioyAlb.aadroRhegip.mpcdn.enCG"

    const-string v0, "com.eg.android.AlipayGphoneRC"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_0
    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Lcom/alipay/sdk/data/a$b;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, v0, Lcom/alipay/sdk/data/a$b;->a:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0

    :catchall_0
    const/4 v3, 0x5

    const-string v0, "ecldn.uhGogproaAqnpoimed.yi"

    const-string v0, ".hneyie.qodGcpolinoamg.prdA"

    const/4 v3, 0x2

    const-string v0, "geaned.popdroyGomipAln.aih."

    const-string v0, "com.eg.android.AlipayGphone"

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public static e(I)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    new-instance v0, Ljava/util/Random;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v2, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-ge v2, p0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v3, 0x3

    const/4 v8, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-wide/high16 v4, 0x4039000000000000L    # 25.0

    const-wide/high16 v4, 0x4039000000000000L    # 25.0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz v3, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v6, 0x1

    const/4 v8, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eq v3, v6, :cond_1

    const/4 v9, 0x3

    const/4 v4, 0x4

    const/4 v9, 0x2

    const/4 v4, 0x2

    if-eq v3, v4, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto/16 :goto_1

    :cond_0
    const/4 v8, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v3, Ljava/util/Random;

    const/4 v9, 0x3

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    const/4 v9, 0x0

    const/16 v4, 0xa

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    mul-double/2addr v6, v4

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-wide v3, 0x4058400000000000L    # 97.0

    const-wide v3, 0x4058400000000000L    # 97.0

    const/4 v9, 0x7

    const/4 v8, 0x6

    add-double/2addr v6, v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    long-to-int v3, v3

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    int-to-char v3, v3

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_1

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v6

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    mul-double/2addr v6, v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-wide v3, 0x4050400000000000L    # 65.0

    const-wide v3, 0x4050400000000000L    # 65.0

    const/4 v9, 0x5

    const-wide v3, 0x4050400000000000L    # 65.0

    const-wide v3, 0x4050400000000000L    # 65.0

    const/4 v9, 0x4

    add-double/2addr v6, v3

    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    long-to-int v3, v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    int-to-char v3, v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v8, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x5

    move v9, v8

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-object p0
.end method

.method static f(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v0, ":"

    const-string v0, ":"

    const/4 v7, 0x3

    const-string v0, ":"

    const-string v0, ":"

    const/4 v6, 0x5

    move v7, v6

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x3

    const-string v1, ""

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v2, "aistvyti"

    const/4 v7, 0x0

    const-string/jumbo v2, "qytiacvt"

    const-string v2, "activity"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :cond_0
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    check-cast v3, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v7, 0x7

    const/4 v6, 0x3

    iget-object v4, v3, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v4, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v2, "M#"

    const/4 v7, 0x6

    const-string v2, "M#"

    const-string v2, "#M"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    iget-object v4, v3, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v4, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v2, "#"

    const-string v2, "#"

    const/4 v7, 0x4

    const-string v2, "#"

    const-string v2, "#"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v3, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    invoke-virtual {v2, v3, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_2
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :catchall_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-lez p0, :cond_3

    const/4 v7, 0x2

    const/4 p0, 0x1

    const/4 v7, 0x7

    shr-int/2addr v6, p0

    const/4 v7, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez p0, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, "N"

    const-string v1, "N"

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object v1
.end method

.method static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "mgsh.mn.oppeiaaGedoRAin.dclry"

    const-string/jumbo v0, "nR.mopnmArdecodogayeil.hpGa.i"

    const/4 v2, 0x6

    const-string v0, "GoAmRd.caCamdoyehgepilnpi.ron"

    const-string v0, "com.eg.android.AlipayGphoneRC"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string p0, "ddoeoAopneygxmha.iraaApiln..oylCciIPG."

    const-string p0, "com.eg.android.AlipayGphoneRC.IAlixPay"

    const/4 v1, 0x2

    or-int/2addr v2, v1

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const-string/jumbo p0, "ilh.pbey.A.anieooaIxGnPdlaomrApcidgo"

    const-string/jumbo p0, "xm.aoleyr.dpiGo..hPagAopldAiieInnoca"

    const/4 v2, 0x3

    const-string p0, "dGanl.ulAapecneparP.A.gdyI.iomyhoixo"

    const-string p0, "com.eg.android.AlipayGphone.IAlixPay"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    add-int/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-gt v1, p0, :cond_0

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2, p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 p0, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ge p0, p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    return-object p0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, v1, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p0

    :catchall_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public static i(Lx0/a;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "liid..fproegrptrinub"

    const-string/jumbo v0, "ifrrrbeln.dogu.piitb"

    const/4 v2, 0x0

    const-string/jumbo v0, "ir.reiotqg.pdbflnrni"

    const-string/jumbo v0, "ro.build.fingerprint"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/alipay/sdk/util/l;->B(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static j(Lx0/a;Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lcom/alipay/sdk/util/l;->k(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method private static k(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/16 v0, 0x80

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1, p2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p0, p1, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo p2, "ibz"

    const-string/jumbo p2, "zib"

    const/4 v2, 0x1

    const-string/jumbo p2, "ibz"

    const-string p2, "biz"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "xasePokaItuGcfgE"

    const-string v0, "IoataEufGxngkceP"

    const/4 v2, 0x1

    const-string v0, "axcmoekPGnEfgIta"

    const-string v0, "GetPackageInfoEx"

    const/4 v2, 0x5

    invoke-static {p0, p2, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p0, ""

    const/4 v2, 0x1

    const-string p0, ""

    const-string p0, ""

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public static l(Lx0/a;[B)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "p5.Xo"

    const-string v0, "X.p95"

    const/4 v3, 0x7

    const-string v0, "b0X5."

    const-string v0, "X.509"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast p1, Ljava/security/cert/X509Certificate;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    instance-of v0, p1, Ljava/security/interfaces/RSAPublicKey;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast p1, Ljava/security/interfaces/RSAPublicKey;

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v0, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Ljava/math/BigInteger;->toString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :catch_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v0, "htua"

    const-string/jumbo v0, "uaht"

    const/4 v3, 0x3

    const-string/jumbo v0, "tahu"

    const-string v0, "auth"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "nmborxSeqEFteucPKyigGl"

    const/4 v3, 0x3

    const-string v1, "FimbSPuuirlcnEGyxeoeKg"

    const-string v1, "GetPublicKeyFromSignEx"

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0, v0, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    const/4 p0, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x0

    return-object p0
.end method

.method private static m([B)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    array-length v1, p0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    mul-int/lit8 v1, v1, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    array-length v1, p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ge v2, v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    aget-byte v3, p0, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    and-int/lit16 v4, v3, 0xf0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    shr-int/lit8 v4, v4, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/16 v5, 0x10

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v4, v5}, Ljava/lang/Character;->forDigit(II)C

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    and-int/lit8 v3, v3, 0xf

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v3, v5}, Ljava/lang/Character;->forDigit(II)C

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-object p0
.end method

.method public static n(Lx0/a;Ljava/lang/String;)Ljava/util/Map;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v1, 0x4

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/16 v1, 0x3f

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v2, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eq v1, v2, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v4, 0x1

    const/4 v9, 0x2

    move v10, v9

    sub-int/2addr v3, v4

    const/4 v10, 0x7

    if-ge v1, v3, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    add-int/2addr v1, v4

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string v1, "&"

    const-string v1, "&"

    const/4 v10, 0x5

    const-string v1, "&"

    const-string v1, "&"

    const/4 v9, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    array-length v1, p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/4 v3, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    move v5, v3

    move v5, v3

    const/4 v10, 0x4

    move v5, v3

    move v5, v3

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-ge v5, v1, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    aget-object v6, p1, v5

    const/4 v10, 0x1

    const/16 v7, 0x3d

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v6, v7, v4}, Ljava/lang/String;->indexOf(II)I

    move-result v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eq v7, v2, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    sub-int/2addr v8, v4

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-lt v7, v8, :cond_0

    const/4 v10, 0x5

    goto :goto_1

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v6, v3, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x4

    const/4 v9, 0x4

    add-int/lit8 v7, v7, 0x1

    const/4 v10, 0x7

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {p0, v6}, Lcom/alipay/sdk/util/l;->v(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-interface {v0, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto :goto_0

    :cond_2
    const/4 v10, 0x2

    return-object v0
.end method

.method public static o(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "lcdpprapam.dyiao.osipa"

    const-string/jumbo v1, "mcsaaaaoppoldny.dirip."

    const/4 v4, 0x2

    const-string v1, ".noiydarqcppa.aidampl."

    const-string v1, "com.alipay.android.app"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/16 v2, 0x80

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 p0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p0

    :catch_0
    const/4 v3, 0x7

    const/4 v4, 0x7

    return v0
.end method

.method static p(Landroid/content/pm/PackageInfo;)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v0, 0x0

    move v4, v0

    move v4, v0

    const/4 v5, 0x5

    if-nez p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v0

    :cond_0
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v5, 0x1

    sget-object v1, Lcom/alipay/sdk/util/l;->e:[Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    aget-object v2, v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v2, :cond_2

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    aget-object v1, v1, v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p0, :cond_1

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v0

    :cond_2
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    return v3

    :catchall_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v0
.end method

.method private static q(Lx0/a;Landroid/content/pm/PackageInfo;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const/4 v1, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez p1, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v0, "=fsl onmli=u"

    const-string/jumbo v0, "nn m=luifo=l"

    const/4 v4, 0x1

    const-string/jumbo v0, "info == null"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v0, "snanotrlenu=g= silifu.o"

    const/4 v4, 0x5

    const-string v0, "  sm.rftilsionaglu=nnue"

    const-string/jumbo v0, "info.signatures == null"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length p1, p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-gtz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v0, "hebtous=<.otinlin0.e fr sag"

    const-string/jumbo v0, "srngabn.lfh0 t .ties<iugeo="

    const/4 v4, 0x6

    const-string v0, "ht0i bnng<astls i=nou.ge.re"

    const-string/jumbo v0, "info.signatures.length <= 0"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string p1, "huta"

    const-string/jumbo p1, "uhta"

    const/4 v4, 0x5

    const-string/jumbo p1, "thua"

    const-string p1, "auth"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "iacgNtuunuStsenruedl"

    const-string/jumbo v2, "usSdNnunugceteilrIat"

    const/4 v4, 0x3

    const-string/jumbo v2, "oSudrgnpsiNuelancetI"

    const-string v2, "NotIncludeSignatures"

    const/4 v4, 0x4

    invoke-static {p0, p1, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v4, 0x6

    return v1
.end method

.method public static r(Lx0/a;Ljava/lang/String;Landroid/app/Activity;)Z
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v0, "&"

    const-string v0, "&"

    const/4 v9, 0x0

    const-string v0, "&"

    const/4 v9, 0x7

    const-string v1, "=lrer_&putnr"

    const-string/jumbo v1, "u_r&rrnuqtl="

    const-string v1, "&return_url="

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string v2, "descn_=o&e"

    const-string v2, "&end_code="

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v3, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    return v4

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-nez p2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    return v3

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string v6, ":/pmpmapty/q?/faiopAtalrlritsaa"

    const-string/jumbo v6, "l/p/l?poqpttsiyaapf/apmaritraA:"

    const/4 v9, 0x5

    const-string v6, "aorpolrp/a/aAaattfip:/lympit?ps"

    const-string v6, "alipays://platformapi/startApp?"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v5, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x4

    if-nez v5, :cond_9

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string/jumbo v7, "tmrt/bepi:aa?ft//rlpastnisnpat"

    const-string v7, "asst/ipenantra/fm:litap/prt?tp"

    const/4 v9, 0x3

    const-string/jumbo v7, "tpittpuont?rtpamp/esaar://anil"

    const-string/jumbo v7, "intent://platformapi/startapp?"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v7}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v8, 0x7

    invoke-virtual {v5, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v5, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto/16 :goto_4

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string p0, "5esuiqmpkithd:t/"

    const-string p0, "d:lmhi5uk/esitqt"

    const/4 v9, 0x7

    const-string/jumbo p0, "itt:/kdiq/sheu5l"

    const-string/jumbo p0, "sdklite://h5quit"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-nez p0, :cond_8

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo p0, "ltsi/yipm?qa.mophcata5otc.o/u=ih/t"

    const-string/jumbo p0, "qhc.o5/olnp?iy//thomaiaa=tiu.cpmtt"

    const/4 v9, 0x7

    const-string p0, "http://m.alipay.com/?action=h5quit"

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz p0, :cond_3

    const/4 v8, 0x3

    move v9, v8

    goto/16 :goto_3

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo p0, "rtemdtukts/i=5h/:sieulb?"

    const-string p0, "=ihekbt/luussle/d:i?5ttr"

    const/4 v9, 0x3

    const-string p0, "/5drouleitshqk/tsl?:e=ti"

    const-string/jumbo p0, "sdklite://h5quit?result="

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v5, :cond_7

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v5, v5, 0x18

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v5, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/lit8 v6, v6, 0xa

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    sget-object v6, Lcom/alipay/sdk/app/e;->a:Lcom/alipay/sdk/app/e;

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-virtual {v6}, Lcom/alipay/sdk/app/e;->a()I

    move-result v6

    const/4 v9, 0x4

    if-eq v5, v6, :cond_5

    const/4 v8, 0x1

    const/4 v9, 0x7

    sget-object v6, Lcom/alipay/sdk/app/e;->g:Lcom/alipay/sdk/app/e;

    const/4 v9, 0x6

    invoke-virtual {v6}, Lcom/alipay/sdk/app/e;->a()I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-ne v5, v6, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    goto :goto_0

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    sget-object p0, Lcom/alipay/sdk/app/e;->b:Lcom/alipay/sdk/app/e;

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/app/e;->a()I

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/alipay/sdk/app/e;->a()I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0}, Lcom/alipay/sdk/app/e;->e()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p1, p0, v0}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    goto/16 :goto_2

    :cond_5
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    sget-boolean v6, Lt0/a;->u:Z

    const/4 v9, 0x5

    if-eqz v6, :cond_6

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    move v9, v8

    invoke-static {p1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {v7, p0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    add-int/lit8 p0, p0, 0x18

    const/4 v8, 0x6

    shl-int/2addr v9, v8

    invoke-virtual {v7, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v7, p0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    aget-object p0, p0, v3

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    add-int/lit8 v2, v2, 0xc

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p1, v0, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p1, v2, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p1, v0, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_1

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    add-int/lit8 p0, p0, 0x18

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p1, p0, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v5}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->a()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->e()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v0, p1, p0}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_2

    :catch_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/d;->h()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance p0, Lcom/alipay/sdk/util/l$a;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {p0, p2}, Lcom/alipay/sdk/util/l$a;-><init>(Landroid/app/Activity;)V

    const/4 v8, 0x1

    shr-int/2addr v9, v8

    invoke-virtual {p2, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    return v4

    :cond_7
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    return v3

    :cond_8
    :goto_3
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2}, Landroid/app/Activity;->finish()V

    const/4 v8, 0x4

    move v9, v8

    return v4

    :cond_9
    :goto_4
    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    sget-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    const/4 v8, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p0, p2, v0}, Lcom/alipay/sdk/util/l;->c(Lx0/a;Landroid/content/Context;Ljava/util/List;)Lcom/alipay/sdk/util/l$b;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v0, :cond_c

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/util/l$b;->a()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-nez v1, :cond_c

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v0, p0}, Lcom/alipay/sdk/util/l$b;->b(Lx0/a;)Z

    move-result p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz p0, :cond_a

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_5

    :cond_a
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string/jumbo p0, "ptmp:bsntafoepila/a/p/itntrra"

    const-string/jumbo p0, "nfpn/suapi/paoaptitr/taemrl:t"

    const/4 v9, 0x1

    const-string/jumbo p0, "pnepriuatstmtai/ptn/tarfpl/:a"

    const-string/jumbo p0, "intent://platformapi/startapp"

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz p0, :cond_b

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo p0, "ti?apr/p/ia/attmlaren//:opptpnft"

    const-string/jumbo p0, "intent://platformapi/startapp\\?"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p1, p0, v6}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_b
    const/4 v9, 0x1

    const/4 v8, 0x5

    new-instance p0, Landroid/content/Intent;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string/jumbo v0, "nndiaao.q.oIWeicEtnrntpt.i"

    const-string/jumbo v0, "t.EiWniptoIe.nda.onictnaVr"

    const/4 v9, 0x6

    const-string/jumbo v0, "oIsaantrnEit.ndtWi.Vocidn."

    const-string v0, "android.intent.action.VIEW"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p0, v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p2, p0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    nop

    :catchall_0
    :cond_c
    :goto_5
    const/4 v9, 0x4

    const/4 v8, 0x1

    return v4
.end method

.method public static s(I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const v0, 0x186a0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    div-int/2addr p0, v0

    const/4 v2, 0x4

    return p0
.end method

.method private static t(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/PackageInfo;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/pm/PackageManager$NameNotFoundException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/16 v0, 0xc0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static u()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "dirmn Aq"

    const-string/jumbo v1, "q inrdoA"

    const/4 v3, 0x7

    const-string/jumbo v1, "inodo dr"

    const-string v1, "Android "

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static v(Lx0/a;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v2, 0x2

    move v3, v2

    const-string v0, "bu8fs"

    const-string v0, "fus8t"

    const/4 v3, 0x0

    const-string/jumbo v0, "utf-8"

    invoke-static {p1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "izb"

    const-string/jumbo v0, "zib"

    const/4 v3, 0x4

    const-string/jumbo v0, "ibz"

    const-string v0, "biz"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "yrtirlusPH5aaaAmaorEsn"

    const-string/jumbo v1, "oarmEysPaHD5saarritAln"

    const/4 v3, 0x1

    const-string v1, "DaEi5aPpyoAaylnHarrsts"

    const-string v1, "H5PayDataAnalysisError"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0, v0, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x5

    move v3, v2

    return-object p0
.end method

.method public static w(Ljava/lang/String;)Ljava/util/Map;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v1, "&"

    const-string v1, "&"

    const/4 v8, 0x3

    const-string v1, "&"

    const-string v1, "&"

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    array-length v1, p0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-ge v3, v1, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    aget-object v4, p0, v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x2

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v6, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-ne v6, v5, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v4, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x3

    const/4 v7, 0x3

    add-int/lit8 v5, v5, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v4}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0, v6, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    move v8, v7

    return-object v0
.end method

.method public static x(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {}, Lcom/alipay/sdk/util/l;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 v2, 0x80

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/16 v1, 0x63

    const/4 v4, 0x2

    if-ge p0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    return p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    return v0
.end method

.method public static y(Lx0/a;Landroid/content/Context;Ljava/util/List;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;)Z"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :catch_0
    :cond_0
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v1, Lcom/alipay/sdk/data/a$b;

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/alipay/sdk/data/a$b;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x2

    const-string/jumbo v2, "yigd.a.aqdoloec.meoAopiGhrn"

    const-string/jumbo v2, "yph.ooaalepmi.groedi.dAoGcn"

    const/4 v5, 0x5

    const-string v2, "ecso.ayl.rp.gpedioaoGmnnhid"

    const-string v2, "com.eg.android.AlipayGphone"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, "dcnrGbooeRhgn.lda.e.ipmypoaCi"

    const/4 v5, 0x4

    const-string v1, "dirmnaopnlo.yeaiGdCAch.Rm.eop"

    const-string v1, "com.eg.android.AlipayGphoneRC"

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 v3, 0x80

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v1, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v1
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 p0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    return p0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v0

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string p2, "biz"

    const-string/jumbo p2, "zib"

    const/4 v5, 0x5

    const-string/jumbo p2, "zbi"

    const-string p2, "biz"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v1, "pcEhoLenuitxhcCxkapsE"

    const-string v1, "huanptuExEcxCLephiksc"

    const/4 v5, 0x3

    const-string/jumbo v1, "uxpcEbLCpixchsthEknAa"

    const-string v1, "CheckLaunchAppExistEx"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, p2, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    return v0
.end method

.method public static z()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x7

    move v5, v4

    invoke-static {}, Lcom/alipay/sdk/util/l;->J()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, "-"

    const-string v1, "-"

    const/4 v5, 0x5

    const-string v1, "-"

    const-string v1, "-"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v1, v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "/n"

    const-string/jumbo v1, "n/"

    const/4 v5, 0x4

    const-string v1, "/n"

    const-string v1, "\n"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eq v1, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v2, "upxnui"

    const-string/jumbo v2, "upLnxi"

    const/4 v5, 0x4

    const-string v2, "Linux "

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object v0
.end method
