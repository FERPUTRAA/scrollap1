.class Lcom/alipay/sdk/util/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/sdk/app/AlipayResultActivity$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/util/f;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/CountDownLatch;

.field final synthetic b:Lcom/alipay/sdk/util/f;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/util/f;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/util/f$a;->b:Lcom/alipay/sdk/util/f;

    const/4 v1, 0x5

    const/4 v0, 0x7

    iput-object p2, p0, Lcom/alipay/sdk/util/f$a;->a:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " /s@v4@@~o~@~~~  ~ib@ ~~S~c@@ ml@traK ul@d@~@  ~fn @~fM~ o o ~ bo~ @it~@i~@ o~b ~s~.y@-@ ~~o1@@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/util/f$a;->b:Lcom/alipay/sdk/util/f;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1, p2, p3}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/alipay/sdk/util/f;->c(Lcom/alipay/sdk/util/f;Ljava/lang/String;)Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/util/f$a;->a:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v2, 0x5

    return-void
.end method
