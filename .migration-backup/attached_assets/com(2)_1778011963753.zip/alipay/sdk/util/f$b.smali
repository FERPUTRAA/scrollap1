.class Lcom/alipay/sdk/util/f$b;
.super Lcom/alipay/android/app/IRemoteServiceCallback$Stub;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/util/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/util/f;


# direct methods
.method private constructor <init>(Lcom/alipay/sdk/util/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/alipay/android/app/IRemoteServiceCallback$Stub;-><init>()V

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/alipay/sdk/util/f;Lcom/alipay/sdk/util/f$a;)V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/alipay/sdk/util/f$b;-><init>(Lcom/alipay/sdk/util/f;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getVersion()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "- s~oK@ o@M~~~l/  b~ . o~ ou@@ia@~ s@f1v~@~@~  @~@@@f~r~/i@~@4o l~b~@@i cy ~d~@t~ S@ @@tbm~ ~o~n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public isHideLoadingScreen()Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public payEnd(ZLjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public r03(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v2, 0x7

    iget-object p3, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p3}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const-string/jumbo v0, "ltw"

    const-string/jumbo v0, "twl"

    const/4 v2, 0x1

    const-string/jumbo v0, "twl"

    const-string/jumbo v0, "wlt"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p3, v0, p1, p2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public startActivity(Ljava/lang/String;Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v7, 0x6

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v7, 0x0

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v1, "surmclErtl"

    const-string v1, "ctsluNrElr"

    const/4 v7, 0x7

    const-string/jumbo v1, "lcNEolAutr"

    const-string v1, "ErrActNull"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string v2, "bzi"

    const-string/jumbo v2, "ibz"

    const/4 v7, 0x2

    const-string v2, "biz"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v3, Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v4, "nn.ArbeInd.ttnt.oaimcaMdoi"

    const-string v4, ".tMmenodrnc.otaAidN.Inntia"

    const/4 v7, 0x0

    const-string/jumbo v4, "in.cNiuernattdM.IoAti.dnna"

    const-string v4, "android.intent.action.MAIN"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v6, 0x1

    move v7, v6

    if-nez p4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance p4, Landroid/os/Bundle;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {p4}, Landroid/os/Bundle;-><init>()V

    :cond_0
    :try_start_0
    const/4 v6, 0x3

    const/4 v6, 0x5

    const-string v4, "Plianiopdg"

    const-string/jumbo v4, "lniloiaPgd"

    const/4 v7, 0x3

    const-string v4, "PClialgdqn"

    const-string v4, "CallingPid"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p4, v4, p3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, p4}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p4, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-static {p4}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p4

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v4, "tenxnbIEEtr"

    const/4 v7, 0x4

    const-string v4, "ExsntnrrtEI"

    const-string v4, "ErrIntentEx"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p4, v2, v4, p3}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3, p1, p2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance p1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-direct {p1}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p1}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p2, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    invoke-static {p2}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string/jumbo p3, "sgFi"

    const-string/jumbo p3, "sgiF"

    const/4 v7, 0x0

    const-string p3, "Fgis"

    const-string/jumbo p3, "isFg"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v4, p1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p4, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget p1, p1, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p2, v2, p3, p1}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->l(Lcom/alipay/sdk/util/f;)Landroid/app/Activity;

    move-result-object p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x3

    if-eqz p1, :cond_1

    :try_start_3
    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide p3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->l(Lcom/alipay/sdk/util/f;)Landroid/app/Activity;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, v3}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v0, "usAm2t"

    const-string/jumbo v0, "utA2cs"

    const/4 v7, 0x3

    const-string v0, "c2tAos"

    const-string/jumbo v0, "stAct2"

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    sub-long/2addr v4, p3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p1, v2, v0, p2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p1, v2, v1, p2}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1}, Lx0/a;->m()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz p1, :cond_2

    const/4 v7, 0x5

    invoke-virtual {p1, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_2
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p1}, Lcom/alipay/sdk/util/f;->m(Lcom/alipay/sdk/util/f;)Lcom/alipay/sdk/util/f$d;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {p1}, Lcom/alipay/sdk/util/f$d;->b()V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    return-void

    :catchall_1
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object p2, p0, Lcom/alipay/sdk/util/f$b;->a:Lcom/alipay/sdk/util/f;

    const/4 v7, 0x4

    invoke-static {p2}, Lcom/alipay/sdk/util/f;->g(Lcom/alipay/sdk/util/f;)Lx0/a;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p2, v2, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    throw p1
.end method
