.class public Lcom/alipay/sdk/util/h;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@s@n ub  ~~@o-4i ~r@y@@@1@~ ~iMa@ ~~@~ @~/ ~~@@tKSdf~  b@f~ov~bs@@l/o.t ~o~m o  @c~~@i ~ ~@l@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lcom/alipay/sdk/util/h;->a:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x5

    const-string p0, ""

    const-string p0, ""

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p0, "000ms00000000000000000000000"

    const-string p0, "00s0000000000000000000000000"

    const/4 v3, 0x6

    const-string p0, "0000o00000000000000000000000"

    const-string p0, "0000000000000000000000000000"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 v1, 0x18

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object p0, Lcom/alipay/sdk/util/h;->a:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    sget-object p0, Lcom/alipay/sdk/util/h;->a:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0
.end method

.method public static declared-synchronized b(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x3

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v6, 0x4

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v5, 0x7

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/alipay/sdk/util/h;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v1, p3, p2}, Lcom/alipay/sdk/encrypt/e;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-nez v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, ",ssm%"

    const/4 v6, 0x6

    const-string v2, "bs%%s"

    const-string v2, "%s,%s"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x2

    aput-object p2, v3, v4

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    aput-object p3, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v2, "pc"

    const-string v2, "cp"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v3, "psrrEtuyreTiorrDoe"

    const-string/jumbo v3, "rprioeTEyDDroetrrs"

    const/4 v6, 0x5

    const-string v3, "TriDesDecryptError"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0, v2, v3, p3}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-interface {p0, p2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void

    :catchall_1
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    throw p0
.end method

.method public static declared-synchronized c(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {p0, p1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 p0, 0x1

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    monitor-exit v0

    const/4 v2, 0x6

    return p0

    :catchall_1
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    throw p0
.end method

.method public static declared-synchronized d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v5, 0x0

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    monitor-enter v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v2, p2, p3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/alipay/sdk/util/h;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p1, p3, p2}, Lcom/alipay/sdk/encrypt/e;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    and-int/2addr v5, v4

    const-string p1, "%bp%,"

    const-string p1, "b,%%s"

    const/4 v5, 0x1

    const-string/jumbo p1, "ss%q,"

    const-string p1, "%s,%s"

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    aput-object p2, v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 p2, 0x1

    move v5, p2

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    aput-object p3, v2, p2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string p2, "cp"

    const-string p2, "cp"

    const/4 v5, 0x3

    const-string/jumbo p2, "pc"

    const-string p2, "cp"

    const/4 v5, 0x1

    const-string/jumbo p3, "rysrupnEsTicEtrore"

    const-string/jumbo p3, "orsrEcurrnpeTtriyE"

    const/4 v5, 0x0

    const-string/jumbo p3, "rpDmorscrEeiTtrEry"

    const-string p3, "TriDesEncryptError"

    const/4 v5, 0x0

    invoke-static {p0, p2, p3, p1}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_1

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v1

    :goto_1
    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    throw p0
.end method

.method public static declared-synchronized e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v2, 0x7

    const-class v0, Lcom/alipay/sdk/util/h;

    const-class v0, Lcom/alipay/sdk/util/h;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v2, 0x0

    return-void

    :catchall_1
    move-exception p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw p0
.end method
