.class public Lcom/alipay/sdk/util/k;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "content://com.alipay.android.app.settings.data.ServerProvider/current_server"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s ~  @~ io1aul@@ @ ~/~4 ~oc@.@t@~i  ovfo@@@@y@~@o~ ~K~ @~s~b n@ ~@t~f~d@-lrMb@m~ /~@@~~ ~bo~Si"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    const-string/jumbo p0, "wisgc//lttashmebi./ppyovtwommm:lhde..g"

    const/4 v2, 0x5

    const-string p0, "edtm:itmlybow.wmghlao/hpat/cgi..epmmsv"

    const-string p0, "https://mobilegw.alipaydev.com/mgw.htm"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p0, :cond_1

    const/4 v2, 0x6

    sget-object p0, Lt0/a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object p0, Lt0/a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object p0, Lt0/a;->a:Ljava/lang/String;

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo p0, "irsrooraend:_tnapadavtiyv.oegsmttd.vecSn./uidl/nnarep.rratrerceoePi/mocr.ts."

    const-string/jumbo p0, "t.pmrtslnr/penv.evsttio/ae.gnaetci.sSiaiu/aoaredroP.p_drvcrar.m:drrtcdnnyeeo"

    const/4 v7, 0x7

    const-string/jumbo p0, "nr.._birmSdeved/te.aocptPetvaecsensdyvn.nrr.cioeleps:p.rituaoatrdao/gritr/an"

    const-string p0, "content://com.alipay.android.app.settings.data.ServerProvider/current_server"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v5, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz p0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {p0}, Landroid/database/Cursor;->getCount()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-lez v1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v0, "url"

    const-string/jumbo v0, "ulr"

    const/4 v7, 0x6

    const-string/jumbo v0, "lur"

    const-string/jumbo v0, "url"

    const/4 v7, 0x7

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v0
.end method
