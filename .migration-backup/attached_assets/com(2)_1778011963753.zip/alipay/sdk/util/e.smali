.class public final enum Lcom/alipay/sdk/util/e;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/alipay/sdk/util/e;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/alipay/sdk/util/e;

.field public static final enum b:Lcom/alipay/sdk/util/e;

.field public static final enum c:Lcom/alipay/sdk/util/e;

.field public static final enum d:Lcom/alipay/sdk/util/e;

.field public static final enum e:Lcom/alipay/sdk/util/e;

.field public static final enum f:Lcom/alipay/sdk/util/e;

.field public static final enum g:Lcom/alipay/sdk/util/e;

.field public static final enum h:Lcom/alipay/sdk/util/e;

.field public static final enum i:Lcom/alipay/sdk/util/e;

.field public static final enum j:Lcom/alipay/sdk/util/e;

.field public static final enum k:Lcom/alipay/sdk/util/e;

.field public static final enum l:Lcom/alipay/sdk/util/e;

.field public static final enum m:Lcom/alipay/sdk/util/e;

.field public static final enum n:Lcom/alipay/sdk/util/e;

.field public static final enum o:Lcom/alipay/sdk/util/e;

.field public static final enum p:Lcom/alipay/sdk/util/e;

.field private static final synthetic s:[Lcom/alipay/sdk/util/e;


# instance fields
.field private q:I

.field private r:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 20

    new-instance v0, Lcom/alipay/sdk/util/e;

    const-string v1, "WFII"

    const-string v1, "WIIF"

    const-string v1, "IFWI"

    const-string v1, "WIFI"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2, v1}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v0, Lcom/alipay/sdk/util/e;->a:Lcom/alipay/sdk/util/e;

    new-instance v1, Lcom/alipay/sdk/util/e;

    const-string/jumbo v3, "sGsnumo2"

    const-string/jumbo v3, "n2somGui"

    const-string/jumbo v3, "ocGmm2iu"

    const-string/jumbo v3, "unicom2G"

    const-string v4, "KETPoTNW1_EYmR"

    const-string v4, "TNPmR1EW_YE_KT"

    const-string v4, "E1KRNbY_OT_PTE"

    const-string v4, "NETWORK_TYPE_1"

    const/4 v5, 0x1

    invoke-direct {v1, v4, v5, v5, v3}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v1, Lcom/alipay/sdk/util/e;->b:Lcom/alipay/sdk/util/e;

    new-instance v3, Lcom/alipay/sdk/util/e;

    const-string v4, "2bmlooei"

    const-string/jumbo v4, "lbo2meuG"

    const-string/jumbo v4, "mobile2G"

    const-string v6, "K2YORNEpWT_b_E"

    const-string v6, "NW_TEb2_KYORTE"

    const-string v6, "YPNE2_OWqKTTER"

    const-string v6, "NETWORK_TYPE_2"

    const/4 v7, 0x2

    invoke-direct {v3, v6, v7, v7, v4}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/alipay/sdk/util/e;->c:Lcom/alipay/sdk/util/e;

    new-instance v4, Lcom/alipay/sdk/util/e;

    const-string/jumbo v6, "mlsouetG2"

    const-string/jumbo v6, "mte2Gluoe"

    const-string/jumbo v6, "lmcmtG2eo"

    const-string/jumbo v6, "telecom2G"

    const-string v8, "E_PYoT4OpEK_WN"

    const-string v8, "_ONWKT_pEE4PYR"

    const-string v8, "_YRKTb4NEPWTE_"

    const-string v8, "NETWORK_TYPE_4"

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v4, v8, v9, v10, v6}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v4, Lcom/alipay/sdk/util/e;->d:Lcom/alipay/sdk/util/e;

    new-instance v6, Lcom/alipay/sdk/util/e;

    const-string v8, "5__TYOuKERNqTP"

    const-string v8, "_E_TORKEqTYPN5"

    const-string v8, "NETWORK_TYPE_5"

    const/4 v11, 0x5

    const-string v12, "Ge3smlepo"

    const-string v12, "elsmcG3oe"

    const-string v12, "eGetmo3lq"

    const-string/jumbo v12, "telecom3G"

    invoke-direct {v6, v8, v10, v11, v12}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v6, Lcom/alipay/sdk/util/e;->e:Lcom/alipay/sdk/util/e;

    new-instance v8, Lcom/alipay/sdk/util/e;

    const-string v13, "K6_mPWEETYRONT"

    const-string v13, "NEsTETRYPKO6_W"

    const-string v13, "NETWORK_TYPE_6"

    const/4 v14, 0x6

    invoke-direct {v8, v13, v11, v14, v12}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v8, Lcom/alipay/sdk/util/e;->f:Lcom/alipay/sdk/util/e;

    new-instance v13, Lcom/alipay/sdk/util/e;

    const-string v15, "PNEm_OR_ToY1TEK"

    const-string v15, "OE1PoTETNKYRW__"

    const-string v15, "RWT1o2ET__NYOKE"

    const-string v15, "NETWORK_TYPE_12"

    const/16 v11, 0xc

    invoke-direct {v13, v15, v14, v11, v12}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v13, Lcom/alipay/sdk/util/e;->g:Lcom/alipay/sdk/util/e;

    new-instance v12, Lcom/alipay/sdk/util/e;

    const-string v15, "_PYETbN8RKEWOT"

    const-string v15, "PTOW_bETR8EYKN"

    const-string v15, "NETWORK_TYPE_8"

    const/4 v14, 0x7

    const/16 v10, 0x8

    const-string v7, "3uGcimun"

    const-string/jumbo v7, "unicom3G"

    invoke-direct {v12, v15, v14, v10, v7}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v12, Lcom/alipay/sdk/util/e;->h:Lcom/alipay/sdk/util/e;

    new-instance v15, Lcom/alipay/sdk/util/e;

    const-string v14, "PR3TNTEp_Y_KWE"

    const-string v14, "NETWORK_TYPE_3"

    invoke-direct {v15, v14, v10, v9, v7}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v15, Lcom/alipay/sdk/util/e;->i:Lcom/alipay/sdk/util/e;

    new-instance v7, Lcom/alipay/sdk/util/e;

    const-string v14, "LTE"

    const-string v14, "LTE"

    const-string v10, "3Y1EE_WPqTTKu_R"

    const-string v10, "R1E3YPuOTT_KE_W"

    const-string v10, "E3sRNYTEWTP_K1O"

    const-string v10, "NETWORK_TYPE_13"

    const/16 v9, 0x9

    const/16 v5, 0xd

    invoke-direct {v7, v10, v9, v5, v14}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v7, Lcom/alipay/sdk/util/e;->j:Lcom/alipay/sdk/util/e;

    new-instance v10, Lcom/alipay/sdk/util/e;

    const-string v14, "INDE"

    const-string v14, "IDNE"

    const-string v14, "IDEN"

    const-string v2, "NETWORK_TYPE_11"

    const/16 v5, 0xa

    const/16 v11, 0xb

    invoke-direct {v10, v2, v5, v11, v14}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v10, Lcom/alipay/sdk/util/e;->k:Lcom/alipay/sdk/util/e;

    new-instance v2, Lcom/alipay/sdk/util/e;

    const-string v14, "TEEmp9PKORW__T"

    const-string v14, "RTTKWN_pPO_E9E"

    const-string v14, "E_9ToEPTRY_KNO"

    const-string v14, "NETWORK_TYPE_9"

    const-string v5, "bHqUP"

    const-string v5, "PUSqH"

    const-string v5, "HuSUA"

    const-string v5, "HSUPA"

    invoke-direct {v2, v14, v11, v9, v5}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v2, Lcom/alipay/sdk/util/e;->l:Lcom/alipay/sdk/util/e;

    new-instance v5, Lcom/alipay/sdk/util/e;

    const-string v14, "T1sWTN0pP_REOY_"

    const-string v14, "W1sTRTP0K_OEYN_"

    const-string v14, "EK_ETY_OqWP10TN"

    const-string v14, "NETWORK_TYPE_10"

    const-string v11, "SHAP"

    const-string v11, "PSHA"

    const-string v11, "SPHA"

    const-string v11, "HSPA"

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    const/16 v2, 0xa

    const/16 v9, 0xc

    invoke-direct {v5, v14, v9, v2, v11}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/alipay/sdk/util/e;->m:Lcom/alipay/sdk/util/e;

    new-instance v2, Lcom/alipay/sdk/util/e;

    const-string v9, "APsmS"

    const-string v9, "HAPmS"

    const-string v9, "PPAmH"

    const-string v9, "HSPAP"

    const-string v11, "WPo1o5TO_NY_KER"

    const-string v11, "TPERo5__N1KOYWT"

    const-string v11, "ERY_TbNEKTP1OW5"

    const-string v11, "NETWORK_TYPE_15"

    const/16 v14, 0xf

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    const/16 v5, 0xd

    invoke-direct {v2, v11, v5, v14, v9}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v2, Lcom/alipay/sdk/util/e;->n:Lcom/alipay/sdk/util/e;

    new-instance v5, Lcom/alipay/sdk/util/e;

    const/16 v9, 0x14

    const-string v11, "5G"

    const-string v11, "5G"

    const-string v14, "YONKETubET_R2P0"

    const-string v14, "YE0P_b_NOT2ETKR"

    const-string v14, "W_NYRK0pO2PETET"

    const-string v14, "NETWORK_TYPE_20"

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    const/16 v2, 0xe

    invoke-direct {v5, v14, v2, v9, v11}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/alipay/sdk/util/e;->o:Lcom/alipay/sdk/util/e;

    new-instance v9, Lcom/alipay/sdk/util/e;

    const/4 v11, -0x1

    const-string/jumbo v14, "oenn"

    const-string/jumbo v14, "neno"

    const-string/jumbo v14, "neon"

    const-string/jumbo v14, "none"

    const-string v2, "NOEN"

    const-string v2, "ENNO"

    const-string v2, "NEON"

    const-string v2, "NONE"

    move-object/from16 v19, v5

    move-object/from16 v19, v5

    move-object/from16 v19, v5

    move-object/from16 v19, v5

    const/16 v5, 0xf

    invoke-direct {v9, v2, v5, v11, v14}, Lcom/alipay/sdk/util/e;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v9, Lcom/alipay/sdk/util/e;->p:Lcom/alipay/sdk/util/e;

    const/16 v2, 0x10

    new-array v2, v2, [Lcom/alipay/sdk/util/e;

    const/4 v5, 0x0

    aput-object v0, v2, v5

    const/4 v0, 0x1

    aput-object v1, v2, v0

    const/4 v0, 0x2

    aput-object v3, v2, v0

    const/4 v0, 0x3

    aput-object v4, v2, v0

    const/4 v0, 0x4

    aput-object v6, v2, v0

    const/4 v0, 0x5

    aput-object v8, v2, v0

    const/4 v0, 0x6

    aput-object v13, v2, v0

    const/4 v0, 0x7

    aput-object v12, v2, v0

    const/16 v0, 0x8

    aput-object v15, v2, v0

    const/16 v0, 0x9

    aput-object v7, v2, v0

    const/16 v0, 0xa

    aput-object v10, v2, v0

    const/16 v0, 0xb

    aput-object v16, v2, v0

    const/16 v0, 0xc

    aput-object v17, v2, v0

    const/16 v0, 0xd

    aput-object v18, v2, v0

    const/16 v0, 0xe

    aput-object v19, v2, v0

    const/16 v0, 0xf

    aput-object v9, v2, v0

    sput-object v2, Lcom/alipay/sdk/util/e;->s:[Lcom/alipay/sdk/util/e;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput p3, p0, Lcom/alipay/sdk/util/e;->q:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/alipay/sdk/util/e;->r:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static b(I)Lcom/alipay/sdk/util/e;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "t @~ u.oqb~r@~~i~o~~l-  c @ ~@~@a@~~oS m @@f/@@@i@v~o@~ @~@~1~~nKs ~f@o~@ @@~/ y btio~ 4 l@b dM~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    invoke-static {}, Lcom/alipay/sdk/util/e;->values()[Lcom/alipay/sdk/util/e;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    array-length v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ge v2, v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-object v3, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v3}, Lcom/alipay/sdk/util/e;->a()I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ne v4, p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object v3

    :cond_0
    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget-object p0, Lcom/alipay/sdk/util/e;->p:Lcom/alipay/sdk/util/e;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/alipay/sdk/util/e;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-class v0, Lcom/alipay/sdk/util/e;

    const-class v0, Lcom/alipay/sdk/util/e;

    const/4 v2, 0x1

    const-class v0, Lcom/alipay/sdk/util/e;

    const-class v0, Lcom/alipay/sdk/util/e;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/alipay/sdk/util/e;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/alipay/sdk/util/e;
    .locals 3

    sget-object v0, Lcom/alipay/sdk/util/e;->s:[Lcom/alipay/sdk/util/e;

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lcom/alipay/sdk/util/e;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, [Lcom/alipay/sdk/util/e;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public final a()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/alipay/sdk/util/e;->q:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/util/e;->r:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method
