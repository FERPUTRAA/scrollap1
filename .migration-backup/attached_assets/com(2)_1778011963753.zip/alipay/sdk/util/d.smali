.class public Lcom/alipay/sdk/util/d;
.super Ljava/lang/Object;


# static fields
.field private static a:Lu0/a$a; = null

.field private static final b:Ljava/lang/String; = "alipaysdk"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method private static a(Ljava/lang/String;)V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@s @n~~@b@@i  ~i~lml ~.o@~ s@~ ~@o r 4 @~1@fb@~~ a~@K~@o-~@S @/c~~ uv/~  o~dM@ot~y@ b ~i~f@to@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    sget-object v0, Lcom/alipay/sdk/util/d;->a:Lu0/a$a;

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v2, "smsh::SmS.hS"

    const/4 v6, 0x6

    const-string v2, "hs:mSmmshSS:"

    const-string v2, "hh:mm:ss.SSS"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v5, 0x7

    or-int/2addr v6, v5

    new-instance v2, Ljava/util/Date;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v2, "  A%o]apK%mlDsSiy"

    const-string v2, "KsAm%yS ip a]l%Ds"

    const-string v2, "SD A[byl]i% Ks%ap"

    const-string v2, "[AlipaySDK] %s %s"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    aput-object v1, v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object p0, v3, v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v0, p0}, Lu0/a$a;->a(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/d;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/d;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const-string p0, " "

    const-string p0, " "

    const/4 v1, 0x5

    const-string p0, " "

    const-string p0, " "

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p2}, Lcom/alipay/sdk/util/d;->f(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static d(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-nez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->f(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v1, 0x2

    return-void
.end method

.method public static e(Lu0/a$a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    sput-object p0, Lcom/alipay/sdk/util/d;->a:Lu0/a$a;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method private static f(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    new-instance v0, Ljava/io/StringWriter;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Ljava/io/PrintWriter;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static g(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/d;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static h(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/d;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static i(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/alipay/sdk/util/d;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private static j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p0, :cond_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez p1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    aput-object p0, v0, v1

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v3, 0x2

    move v2, p0

    move v2, p0

    const/4 v3, 0x5

    aput-object p1, v0, p0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string p0, "[]%[ssuo"

    const-string p0, "]%s[o]s["

    const/4 v3, 0x5

    const-string/jumbo p0, "s]%[][%p"

    const-string p0, "[%s][%s]"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0
.end method
