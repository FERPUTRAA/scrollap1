.class public Lcom/alipay/sdk/util/g;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "pref_trade_token"

.field public static final b:Ljava/lang/String; = ";"

.field public static final c:Ljava/lang/String; = "result={"

.field public static final d:Ljava/lang/String; = "}"

.field public static final e:Ljava/lang/String; = "trade_token=\""

.field public static final f:Ljava/lang/String; = "\""

.field public static final g:Ljava/lang/String; = "trade_token="


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "r@s@b t  ~u 1Mao/co voy@~~@ f @~dio@~@if@.~b~@~ ~t @@~So~~K@~~s~~ @~~o@n @@l-m@@/~ ~l @ ~ @~i4  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    return-object v1

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v0, ";"

    const-string v0, ";"

    const/4 v8, 0x3

    const-string v0, ";"

    const-string v0, ";"

    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v0, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    move v2, v0

    move v2, v0

    const/4 v8, 0x3

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    array-length v3, p0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-ge v2, v3, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    aget-object v3, p0, v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v4, "ls{mrset"

    const-string/jumbo v4, "sts=ler{"

    const/4 v8, 0x7

    const-string v4, "=sleou{r"

    const-string/jumbo v4, "result={"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v3, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    aget-object v3, p0, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string/jumbo v4, "}"

    const-string/jumbo v4, "}"

    const/4 v8, 0x7

    const-string/jumbo v4, "}"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v3, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    aget-object v3, p0, v2

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v4, v4, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/16 v5, 0x8

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v4, "&"

    const-string v4, "&"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    move v4, v0

    move v4, v0

    const/4 v8, 0x0

    move v4, v0

    move v4, v0

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    array-length v5, v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-ge v4, v5, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x4

    aget-object v5, v3, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v6, "=e_tnbrdke/m/o"

    const-string v6, "d/kme=eratno_/"

    const/4 v8, 0x6

    const-string/jumbo v6, "kta_neu=rodte/"

    const-string/jumbo v6, "trade_token=\""

    const/4 v7, 0x4

    or-int/2addr v8, v7

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v5, :cond_1

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    aget-object v5, v3, v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v6, "//"

    const-string v6, "//"

    const/4 v8, 0x5

    const-string v6, "//"

    const-string v6, "\""

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    aget-object v1, v3, v4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    add-int/lit8 v3, v3, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/16 v4, 0xd

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_2

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    aget-object v5, v3, v4

    const/4 v7, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string v6, "_aotoetp=drk"

    const-string/jumbo v6, "tnodoatrke=_"

    const/4 v8, 0x3

    const-string v6, "dtaeeok=q_rn"

    const-string/jumbo v6, "trade_token="

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v5, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    aget-object v1, v3, v4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/16 v3, 0xc

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    goto :goto_2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto/16 :goto_1

    :cond_3
    :goto_2
    const/4 v7, 0x6

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object v1
.end method

.method public static b(Lx0/a;Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v0, "pesroaefbdter_n_"

    const-string v0, "e_dnpbf_orraeett"

    const/4 v3, 0x3

    const-string/jumbo v0, "oermfae_d_nkeprt"

    const-string/jumbo v0, "pref_trade_token"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0, p1, v0, v1}, Lcom/alipay/sdk/util/h;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, " tgkoedt r:t oneu"

    const-string/jumbo v0, "t tnoaueg ekd:tr "

    const-string v0, " t etbderkgat :oe"

    const-string v0, "get trade token: "

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v0, "lsmp"

    const-string/jumbo v0, "slpm"

    const/4 v3, 0x6

    const-string/jumbo v0, "mlsp"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p0
.end method

.method public static c(Lx0/a;Landroid/content/Context;Ljava/lang/String;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/alipay/sdk/util/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v0, "slpm"

    const-string/jumbo v0, "mlps"

    const/4 v4, 0x1

    const-string/jumbo v0, "mlps"

    const-string/jumbo v0, "mspl"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v2, "anert uode:pk"

    const-string v2, "a: trokpeetdn"

    const/4 v4, 0x1

    const-string/jumbo v2, "tearn:op ek d"

    const-string/jumbo v2, "trade token: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v0, "fqardtneqrto_kee"

    const-string v0, "e_rondfkqr_teate"

    const/4 v4, 0x6

    const-string/jumbo v0, "ttsee_ndakrperof"

    const-string/jumbo v0, "pref_trade_token"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0, p1, v0, p2}, Lcom/alipay/sdk/util/h;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string p2, "bzi"

    const-string/jumbo p2, "zbi"

    const/4 v4, 0x6

    const-string/jumbo p2, "zbi"

    const-string p2, "biz"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v0, "ovTmrseeErSkanerraT"

    const-string v0, "EesovrkraenarTSoeTr"

    const/4 v4, 0x4

    const-string/jumbo v0, "rreroeeEdvaTroSTkoa"

    const-string v0, "SaveTradeTokenError"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0, p2, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method
