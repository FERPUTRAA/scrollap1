.class public Lcom/alipay/sdk/util/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Lorg/json/JSONObject;Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v1, 0x2

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-array v2, v1, [Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    aput-object p0, v2, v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 p0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    aput-object p1, v2, p0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ge v3, v1, :cond_2

    const/4 v6, 0x0

    move v7, v6

    aget-object p0, v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez p0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_2

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eqz v4, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0, v4}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    goto :goto_1

    :cond_1
    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object v0
.end method
