.class Lcom/alipay/sdk/widget/d$d$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/d$d;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/d$d;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/d$d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/widget/d$d$a;->a:Lcom/alipay/sdk/widget/d$d;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@vsKbb~o@tM~~@r ~u omi@ .    ~~l cs~~@@i/ @@~@~~i So-@ @ @~ ~t @@f@@yl@~@n~ o@~~~~  b4d~oa~of1/~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/alipay/sdk/widget/d$d$a;->a:Lcom/alipay/sdk/widget/d$d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p1, Lcom/alipay/sdk/widget/d$d;->b:Landroid/webkit/SslErrorHandler;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/webkit/SslErrorHandler;->cancel()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/alipay/sdk/widget/d$d$a;->a:Lcom/alipay/sdk/widget/d$d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p1, p1, Lcom/alipay/sdk/widget/d$d;->c:Lcom/alipay/sdk/widget/d;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-static {p1}, Lcom/alipay/sdk/widget/d;->u(Lcom/alipay/sdk/widget/d;)Lx0/a;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string p2, "eDSmsieSL"

    const-string p2, "DisSLenSe"

    const/4 v3, 0x6

    const-string p2, "SdneoiLeD"

    const-string p2, "SSLDenied"

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "2"

    const-string v0, "2"

    const/4 v3, 0x2

    const-string v0, "2"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v1, "etn"

    const-string v1, "ent"

    const/4 v3, 0x4

    const-string/jumbo v1, "ten"

    const-string/jumbo v1, "net"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v1, p2, v0}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/alipay/sdk/widget/d$d$a;->a:Lcom/alipay/sdk/widget/d$d;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p1, Lcom/alipay/sdk/widget/d$d;->a:Landroid/app/Activity;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-void
.end method
