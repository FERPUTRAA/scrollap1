.class Lcom/alipay/sdk/widget/e$d;
.super Landroid/webkit/WebViewClient;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/e;->setWebClientProxy(Lcom/alipay/sdk/widget/e$g;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/e;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~usM~~@@tr~~@   @~4 .cf1 @~o@  ~io@ ~~sS@@i//@@v ~yoo ~@~ bod bl~~~ ~~@ imot@f~@~@ ~b@K @l@a@ ~-"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/widget/e;->p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0, v1, p2}, Lcom/alipay/sdk/widget/e$g;->g(Lcom/alipay/sdk/widget/e;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .locals 3

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p3}, Lcom/alipay/sdk/widget/e;->p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p3, v0, p2}, Lcom/alipay/sdk/widget/e$g;->d(Lcom/alipay/sdk/widget/e;Ljava/lang/String;)Z

    move-result p3

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-nez p3, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/alipay/sdk/widget/e;->p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1, p2, p3, p4}, Lcom/alipay/sdk/widget/e$g;->a(Lcom/alipay/sdk/widget/e;ILjava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-super {p0, p1, p2, p3, p4}, Landroid/webkit/WebViewClient;->onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method public onReceivedSslError(Landroid/webkit/WebView;Landroid/webkit/SslErrorHandler;Landroid/net/http/SslError;)V
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/widget/e;->p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0, v1, p2, p3}, Lcom/alipay/sdk/widget/e$g;->e(Lcom/alipay/sdk/widget/e;Landroid/webkit/SslErrorHandler;Landroid/net/http/SslError;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onReceivedSslError(Landroid/webkit/WebView;Landroid/webkit/SslErrorHandler;Landroid/net/http/SslError;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/alipay/sdk/widget/e;->p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$d;->a:Lcom/alipay/sdk/widget/e;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, v1, p2}, Lcom/alipay/sdk/widget/e$g;->i(Lcom/alipay/sdk/widget/e;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p1
.end method
