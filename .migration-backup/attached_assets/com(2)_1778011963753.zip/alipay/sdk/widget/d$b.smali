.class Lcom/alipay/sdk/widget/d$b;
.super Lcom/alipay/sdk/widget/d$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/d;->B()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Lcom/alipay/sdk/widget/e;

.field final synthetic c:Lcom/alipay/sdk/widget/d;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/d;Lcom/alipay/sdk/widget/e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/widget/d$b;->c:Lcom/alipay/sdk/widget/d;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/alipay/sdk/widget/d$b;->b:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/alipay/sdk/widget/d$e;-><init>(Lcom/alipay/sdk/widget/d;Lcom/alipay/sdk/widget/d$a;)V

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sn@i~o  @@~/ @@t o u @~a~~~@S ~t~or@@~o@o4 K~v~@.oc@lm @bf  ~s @@~Ml@ -  @~i fy bb/@d~~~1~i@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/alipay/sdk/widget/d$b;->b:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/alipay/sdk/widget/e;->c()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/widget/d$b;->c:Lcom/alipay/sdk/widget/d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/alipay/sdk/widget/d;->t(Lcom/alipay/sdk/widget/d;Z)Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method
