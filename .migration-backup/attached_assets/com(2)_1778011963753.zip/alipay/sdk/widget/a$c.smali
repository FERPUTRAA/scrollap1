.class Lcom/alipay/sdk/widget/a$c;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/widget/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/a;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/a;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/widget/a$c;->a:Lcom/alipay/sdk/widget/a;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public dispatchMessage(Landroid/os/Message;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s~o. ~~~~~ MS~@@@  - @@ t~n~~  bK ~o~l vro ~~i ~~@~/ls1yfo~u4fb@~@to~@/di @@@@i b@mc@@ @@a@~~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/alipay/sdk/widget/a$c;->a:Lcom/alipay/sdk/widget/a;

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/alipay/sdk/widget/a;->i()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method
