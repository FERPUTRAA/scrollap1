.class Lcom/alipay/sdk/widget/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/a;->g()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/a;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/widget/a;->h(Lcom/alipay/sdk/widget/a;)Lcom/alipay/sdk/widget/a$d;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v1, Lcom/alipay/sdk/widget/a$d;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/alipay/sdk/widget/a;->a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v1, v2, v3}, Lcom/alipay/sdk/widget/a$d;-><init>(Lcom/alipay/sdk/widget/a;Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/alipay/sdk/widget/a;->b(Lcom/alipay/sdk/widget/a;Lcom/alipay/sdk/widget/a$d;)Lcom/alipay/sdk/widget/a$d;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/alipay/sdk/widget/a;->h(Lcom/alipay/sdk/widget/a;)Lcom/alipay/sdk/widget/a$d;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/alipay/sdk/widget/a;->k(Lcom/alipay/sdk/widget/a;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    :cond_0
    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/widget/a;->h(Lcom/alipay/sdk/widget/a;)Lcom/alipay/sdk/widget/a$d;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/alipay/sdk/widget/a;->h(Lcom/alipay/sdk/widget/a;)Lcom/alipay/sdk/widget/a$d;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/a$a;->a:Lcom/alipay/sdk/widget/a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/alipay/sdk/widget/a;->l(Lcom/alipay/sdk/widget/a;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-wide/16 v2, 0x7530

    const-wide/16 v2, 0x7530

    const/4 v5, 0x6

    const-wide/16 v2, 0x7530

    const-wide/16 v2, 0x7530

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v5, 0x1

    return-void
.end method
