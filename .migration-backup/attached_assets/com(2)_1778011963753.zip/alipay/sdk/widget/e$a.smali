.class Lcom/alipay/sdk/widget/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/widget/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/e;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/e;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " /ss~ t  /@ivyno@M@~oo@ @@l~@oab~@m@d- i@ @o~~~ ~c i@S@ou~l~4@tr @~~ ~f@~~@~@.  ~b  b@@f ~~~ 1~K"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/widget/e;->b(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$h;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1, v1}, Landroid/view/View;->setEnabled(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {}, Lcom/alipay/sdk/widget/e;->h()Landroid/os/Handler;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v2, Lcom/alipay/sdk/widget/e$a$a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v2, p0, p1}, Lcom/alipay/sdk/widget/e$a$a;-><init>(Lcom/alipay/sdk/widget/e$a;Landroid/view/View;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-wide/16 v3, 0x100

    const-wide/16 v3, 0x100

    const/4 v6, 0x4

    const-wide/16 v3, 0x100

    const-wide/16 v3, 0x100

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/alipay/sdk/widget/e;->i(Lcom/alipay/sdk/widget/e;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ne p1, v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0, p1}, Lcom/alipay/sdk/widget/e$h;->c(Lcom/alipay/sdk/widget/e;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/alipay/sdk/widget/e;->k(Lcom/alipay/sdk/widget/e;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ne p1, v1, :cond_1

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$a;->a:Lcom/alipay/sdk/widget/e;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0, p1}, Lcom/alipay/sdk/widget/e$h;->f(Lcom/alipay/sdk/widget/e;)V

    :cond_1
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method
