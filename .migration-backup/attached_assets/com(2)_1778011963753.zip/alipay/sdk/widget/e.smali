.class public Lcom/alipay/sdk/widget/e;
.super Landroid/widget/LinearLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/widget/e$h;,
        Lcom/alipay/sdk/widget/e$g;,
        Lcom/alipay/sdk/widget/e$f;,
        Lcom/alipay/sdk/widget/e$e;
    }
.end annotation


# static fields
.field private static m:Landroid/os/Handler;


# instance fields
.field private a:Landroid/widget/ImageView;

.field private b:Landroid/widget/TextView;

.field private c:Landroid/widget/ImageView;

.field private d:Landroid/widget/ProgressBar;

.field private e:Landroid/webkit/WebView;

.field private final f:Lcom/alipay/sdk/widget/e$e;

.field private g:Lcom/alipay/sdk/widget/e$f;

.field private h:Lcom/alipay/sdk/widget/e$g;

.field private i:Lcom/alipay/sdk/widget/e$h;

.field private final j:Lx0/a;

.field private k:Landroid/view/View$OnClickListener;

.field private final l:F


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object v0, Lcom/alipay/sdk/widget/e;->m:Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;Lx0/a;Lcom/alipay/sdk/widget/e$e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    new-instance p2, Lcom/alipay/sdk/widget/e$a;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p2, p0}, Lcom/alipay/sdk/widget/e$a;-><init>(Lcom/alipay/sdk/widget/e;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/alipay/sdk/widget/e;->k:Landroid/view/View$OnClickListener;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p4, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    new-instance p4, Lcom/alipay/sdk/widget/e$e;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p4, p2, p2}, Lcom/alipay/sdk/widget/e$e;-><init>(ZZ)V

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/alipay/sdk/widget/e;->f:Lcom/alipay/sdk/widget/e$e;

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/alipay/sdk/widget/e;->j:Lx0/a;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p2, p2, Landroid/util/DisplayMetrics;->density:F

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p2, p0, Lcom/alipay/sdk/widget/e;->l:F

    const/4 v0, 0x5

    and-int/2addr v1, v0

    const/4 p2, 0x2

    const/4 p2, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/alipay/sdk/widget/e;->d(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-direct {p0, p1}, Lcom/alipay/sdk/widget/e;->j(Landroid/content/Context;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/alipay/sdk/widget/e;->l(Landroid/content/Context;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lx0/a;Lcom/alipay/sdk/widget/e$e;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1, v0, p2, p3}, Lcom/alipay/sdk/widget/e;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;Lx0/a;Lcom/alipay/sdk/widget/e$e;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private a(I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ si~~~1a@~bi~~  ~lf  -@~o ood   @i~M ~@ @b@cu~~@@/@@t@@.@~@~~@ t@~ b~ ~K~ lo soo@4y@fnvr@~m@/~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    int-to-float p1, p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/alipay/sdk/widget/e;->l:F

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    mul-float/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    float-to-int p1, p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1
.end method

.method static synthetic b(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$h;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->i:Lcom/alipay/sdk/widget/e$h;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method private d(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x5

    new-instance v0, Landroid/widget/LinearLayout;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    const v1, -0xd000001

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 v2, 0x10

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->f:Lcom/alipay/sdk/widget/e$e;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v2}, Lcom/alipay/sdk/widget/e$e;->a(Lcom/alipay/sdk/widget/e$e;)Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v2, :cond_0

    const/4 v9, 0x1

    move v10, v9

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/16 v2, 0x8

    :goto_0
    const/4 v10, 0x3

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    new-instance v2, Landroid/widget/ImageView;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {v2, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    iput-object v2, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v10, 0x3

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->k:Landroid/view/View$OnClickListener;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v10, 0x1

    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v3, "OEBmr5Ag7OATKvcDSAA6p1ExUR54lI=n3AABgVy4AkrWETgBkVEWMaJzki2pQ/8Vg5wjVNGuAlIiIoQ42kiCkoU2IZABAlAMJNANB6EARAnrpA0y+AM4AjAeugI5AnRC2hCg7nAGM0BEgxN+Rj/A+R13QwxSiZslLgSAB69RwyVFGfpAw2QeJoMAYTSAABBSs0AFyCCou+FMUkaHA+5bAkUA1ULe0OAQTijJ=jjYPBRnZsa6VAARQnnoETQiUemNoJ7rUwKRABAR0ArL1HA0QAAS"

    const-string v3, "RJsyV3kT4kApTA65VkiBGFL2R=H0A4jJEi/Vx0Qb=AMe4N0AAg7oAVArn5GBgRwKi7BAi1CORSOwLn+oSkARsDAlwjAAAlA/6JxowIQAAEOA7AglA+NEcmRFQlWBrBsiIAVWvQCfABYA8uGCETLnyAVSQTwiAA5jAUJMuB4hA6jpCnUHUA00r6y5U2B+AooEMrnIrjE5yNA1peFRgR3YagCA2KpMog+jUeg9UaRA1MxA2aNQkITgEJAMUARBu0kkPSZB1+B2SzeQASnNQAInBAZZ"

    const/4 v10, 0x1

    const-string v3, "clg2ol6A22UK5ARkAwW55AuABVMVwS0rTiBA4MrAU4RLAQjwB3jNlNzMAgHkAZmE10IijAAIQ0ywAiCCyMAANT7YWjoPCSErAjTEHeNn6QEZ+RTeQVIOg9lUZoxFBsJIEUBAj58O/Kuins4oAAArnVjREoAGn0gMU2/JyAgAOJAakaxoQDwkRI7LA+fTp1C=Upg0GAAAFVACABe7UYvGe+1AkApkB6BBgBiARQFRAbAnp6SJVkERS++MnQBAS4xJgn0A12o5iLyRurh=BQA3RAaS"

    const-string/jumbo v3, "iVBORw0KGgoAAAANSUhEUgAAAEgAAABIBAMAAACnw650AAAAFVBMVEUAAAARjusRkOkQjuoRkeoRj+oQjunya570AAAABnRSTlMAinWeSkk7CjRNAAAAZElEQVRIx+3MOw6AIBQF0YsrMDGx1obaLeGH/S9BQgkJ82rypp4ceTN1ilvyKizmZIAyU7FML0JVYig55BBAfQ2EU4V4CpZJ+2AiSj11C6rUoTannBpRn4W6xNQjLBSI2+TN0w/+3HT2wPClrQAAAABJRU5ErkJggg=="

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v3, p1}, Lcom/alipay/sdk/util/i;->a(Ljava/lang/String;Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/16 v3, 0xc

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-direct {p0, v3}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-direct {p0, v3}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v2, v4, v1, v5, v1}, Landroid/view/View;->setPadding(IIII)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v4, -0x2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {v2, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v5, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v0, v5, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance v2, Landroid/view/View;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {v2, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    const v5, -0x262627

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v2, v5}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v6, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-direct {p0, v6}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/16 v8, 0x19

    const/4 v10, 0x7

    invoke-direct {p0, v8}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v8

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-direct {v5, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    new-instance v2, Landroid/widget/TextView;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {v2, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    iput-object v2, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    const v5, -0xeeeeef

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/high16 v5, 0x41880000    # 17.0f

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v10, 0x0

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    const/4 v10, 0x0

    const/4 v9, 0x0

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v5, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/16 v6, 0x11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {p0, v6}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v6

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v2, v6, v1, v1, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    iput v6, v2, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    const/4 v10, 0x7

    iget-object v6, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v10, 0x4

    invoke-virtual {v0, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    new-instance v2, Landroid/widget/ImageView;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {v2, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput-object v2, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v6, p0, Lcom/alipay/sdk/widget/e;->k:Landroid/view/View$OnClickListener;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v2, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v2, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v9, 0x7

    move v10, v9

    const-string/jumbo v6, "svxmey8MA/OYGnYSFdoaj+mxaAstgTJFjJAbSvSaTQby1QQjAPQFCB8poi2QM1bA4KCj9idSFepiHj3olccRwOeMmQAArA1RAHACQj3MY+em7k=CRkQhfk8MHqXuRobBoQu+o+0AC9AXFjvksjIv3INE5tNmRG/jy3MPTkndio7A1h+WCmUSG/DtW0FjoxPFExR5Bk4KBSmCEs7H9smNI4ScFuokUt+pr+SOM11AREcA6fB2/QzQZjWhaj5yu+zFMB9XUkBYR+UgAKioXjI5OLRx5j8mMMs1VQM6Ab5RRqKRLJ+RQLJw1Gb804IVI9YUooysD39lj1gdohTjutwDMuAV2j2KHX72aONioRFIsHpGvYoDqhs3LWsmuJoS3eKrDbG/KfA/Vn4S5xjauWGRvT+wtTbuvJk6VwU7uHGWYHfmlkj2YJOED+Ahjm5kypnyNQWQykAEjWoF8DROlsdqDbbaAilBPGeAAmovlEm1kTn/RyW/bDC3Iv5fevbjLfW+5sVIjErKc2STFdxiI8vM9eEKjkKbozoG04j6jDuO+C2zQ6WjkXj7AoaZjAY8wwR3GXO8E1DoOtSd0SnAkaVRXw++IpRgVT+polypVBYjozoajmO3pOh+QR4o1KaLTU+iaKkdg+A5sXVayLe87B9oPskgV72buHsZuSBfkUcoVDoax8kcxsoMs7oOO7O1wD/Cc5h7aTAfGNCRwrKCA0YAmyZTCgvgkjgR+ZvE6kkwFL6bGoLVd0AeHoEk3+a8k+kzB9iD85/eoG/TrhbhNjPZcqT86QI/cUMCEyaZn8ohQz5+BO0Ln0KXmlwrfsB2XYmI6JQojoijzFuczAE8g6O4jZJxfz48Gab9WjqjM0a7LvANOh8TU7k+6pDjD/A0RW43Xjio5rDzBijZ7MR/kgcITLwAjkACd0u6/uN+oW0ebZPZCDuoj5QDTQj+e/UazKolo1m5B+gHE4sQAjhzHV5QQ1jj7CThj2qOJbChAI6MwUQ0jXVN1tMHsQbxc0UZurlIthuXGTXxIA+ZSzbkRTkflsNkVA8IKCp+oy8SaoNMWgP+NauUQTS0WSFofDjckWyD6zA4Amn4+p01qA+tHOhnARCuPDE9ocUnjsQjV/j5uzqQrQ6BmOc6suBGd1kQoSRysvTwGY7GGnSRAFuJjS7rklT6OCCNVdUrPl+YShhy2k3sYrN3+VJR"

    const/4 v10, 0x0

    const-string v6, "7TSKabeus27Qij6Oz3k1A+NkF6KG4owp0ORBMZAQMxrDlJk96jao8IEo7VcO/QT1kx4jsotcgQL8ifoLDN3jbzCUxratZQHuJDdusF+olbQuC6Bw2krHm75JkSXPCopQ9bQf23Ov5YDS6QcI+YIXHLhkABrjpb73zkaf6QARghskm++0XlujPA4Nd/eX58eEjoE74wsHy1GVDkruRv85waOyRup0a+BOEE17wCmmj+Ayjok+7CkKLjus/so10x+X8jP7jj19fQYUwn6kua0j6BCH8GJ/VhAhGtWBQOObFFjg0jWTTD43UyFaKJCCi7cAYnK+IQSoRukVArcD/suVncNsGaoCeGVjOmEhDAZ/jShfhoxoYkYFVOBADlkP508jgMqR0TdYLosox9dVTwj4VxL5MpdJZZoKs29ryqIGIt85vC/5ypTYoyAGWD5j9XmGDATQKby8VRdTGOcRm60EoaWB+hT9AmXoBaOjQMiLRGZQE4cRQ8RSqolGY1TQuuAh+QERMKRdgdPMtfsVReSMYRCokpWLsTd1A8nGKusIIkaFop/1Xj2XvT/VRMlDpFAAMjbagxDc5moGFeOWDU/vjwP/D6l+yIv6Q8WEpFJ+WoDVoQ3oQ93AGPbNejbjKe1tmRQvo7UsVMzbQONSXRAjLso9RvnCmAsE5+EIn2N48EDANV8QAMu3B76urbDV2j6m0+wRUHyejjmQevUjlOFHwkccBhRUJ5FkOIypaJwqkQwk3bTiT6k+n+Wchsfh9e4hN0/z2QWB+w51EOjS1nBoTS1KAvZKUx5MERjKWetbdKjS+GoYAIyhqgan6=7jZARgVsoS/5Av2A/jEkkxAAiUJZ/4cBXHrjRz8NN7ak2upMUElDcHhw1ouuGbzIkfGbSqsW8oFz3jaB8UmbYhMz7WA61CyG+hSNfI5vVvb7HmlOcjRSkbDF+zmzd3A+P8tylhjZ/PWjCzijA1UTV2A0y+KQ+S0CTkA4QJPoFzrAMu+RjgKS5DTXk+5rq+Ab0iNkXgadlHzAmMOJUY+uNCaZoRiw2oxATRgm/BCkjf+gqBjt8+I0sSXUlqsAsujZfAeosWCAMmj1M3TCOjiaAtznjAiT0Mkku5oHF33ZaDmvCAYHorbuGCSojjXo4+WoT+Q+ryBkCSLcfhnQ6vo4II7SozOjOWoiAiY9n8ga+RILH1Nk0RSjbyLsxU"

    const-string/jumbo v6, "iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAmVBMVEUAAAARj+oQjuoRkOsVk/AQj+oRjuoQj+oSkO3///8Rj+kRj+oQkOsTk+whm/8Qj+oRj+oQj+oSkus2p/8QjuoQj+oQj+oQj+oQj+oRj+oTkuwRj+oQj+oRj+oRj+oSkOsSkO0ZlfMbk+8XnPgQj+oRj+oQj+oQj+sSj+sRkOoSkescqv8Rj+oQj+oSj+sXku4Rj+kQjuoQjumXGBCVAAAAMnRSTlMAxPtPF8ry7CoB9npbGwe6lm0wBODazb1+aSejm5GEYjcTDwvls6uJc0g/CdWfRCF20AXrk5QAAAJqSURBVFjD7ZfXmpswEIUFphmDCxi3talurGvm/R8uYSDe5FNBwlzsxf6XmvFBmiaZ/PCdWDk9CWn61OhHCMAaXfoRAth7wx6EkMXnWyrho4yg4bDpquI8Jy78Q7eoj9cmUFijsaLM0JsD9CD0uQAa9aNdPuCFvbA7B9t/Becap8Pu6Q/2jcyH81VHc/WCHDQZXwbvtUhQ61iDlqadncU6Rp31yGkZIzOAu7AjtPpYGREzq/pY5DRFHS1siyO6HfkOKTrMjdb2qevV4zosK7MbkFY2LmYk55hL6juCIFWMOI2KGzblmho3b18EIbxL1hs6r5m2Q2WaEElwS3NW4xh6ZZJuzTtUsBKT4G0h35s4y1mNgkNoS6TZ8SKBXTZQGBNYdPTozXGYKoyLAmOasttjThT4xT6Ch+2qIjRhV9Ja3NC87Kyo5We1vCNEMW1T+j1VLZ9UhE54Q1DL52r5piJ0YxdegvWlHOwTu76uKkJX+MOTHno4YFSEbHYdhViojsLrCTg/MKnhKWaEYzvkZFM8aOkPH7iTSvoFZKD7jGEJbarkRaxQyOeWvGVIbsji152jK7TbDgRzcIuz7SGj89BFU8d30TqWeDtrILxyTkD1IXfvmHseuU3lVHDz607bw0f3xDqejm5ncd0j8VDwfoibRy8RcgTkWHBvocbDbMlJsQAkGnAOHwGy90kLmQY1Wkob07/GaCNRIzdoWK7/+6y/XkLDJCcynOGFuUrKIMuCMonNr9VpSOQoIxBgJ0SacGbzZNy4ICrkscvU2fpElYz+U3sd+aQThjfVmjNa5i15kLcojM3Gz8kP34jf4VaV3X55gNEAAAAASUVORK5CYII="

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {v6, p1}, Lcom/alipay/sdk/util/i;->a(Ljava/lang/String;Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v2, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v9, 0x3

    or-int/2addr v10, v9

    invoke-direct {p0, v3}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    invoke-direct {p0, v3}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p1, v2, v1, v3, v1}, Landroid/view/View;->setPadding(IIII)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-direct {p1, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/16 v1, 0x30

    const/4 v9, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-direct {p0, v1}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {p1, v5, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p0, v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    return-void
.end method

.method static synthetic h()Landroid/os/Handler;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/alipay/sdk/widget/e;->m:Landroid/os/Handler;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic i(Lcom/alipay/sdk/widget/e;)Landroid/widget/ImageView;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method private j(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v0, Landroid/widget/ProgressBar;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const v2, 0x103001f

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, p1, v1, v2}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const v1, 0x108006c

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v0, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setMax(I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const v0, -0xd000001

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x2

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/alipay/sdk/widget/e;->a(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p1, v1, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v4, 0x6

    invoke-virtual {p0, v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method static synthetic k(Lcom/alipay/sdk/widget/e;)Landroid/widget/ImageView;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method private l(Landroid/content/Context;)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v0, "aeclaiuciiossaTvretsby"

    const-string/jumbo v0, "icesoiryevcaissTbtalra"

    const/4 v8, 0x6

    const-string v0, "accessibilityTraversal"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string v1, "ciibaesplcity"

    const-string v1, "eicsbbicaylit"

    const/4 v8, 0x1

    const-string v1, "accessibility"

    const/4 v8, 0x7

    const-string/jumbo v2, "iougJahxqdaB_seBarre"

    const-string v2, "aa_eaJuxighBdBrorcse"

    const/4 v8, 0x3

    const-string v2, "BJsrehvrasaeBgac_ixo"

    const-string/jumbo v2, "searchBoxJavaBridge_"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v3, Landroid/webkit/WebView;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {v3, p1}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x4

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Landroid/webkit/WebView;->setVerticalScrollbarOverlay(Z)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v3, p1}, Lcom/alipay/sdk/widget/e;->e(Landroid/webkit/WebView;Landroid/content/Context;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    sget-object v5, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    const/4 v7, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-wide/32 v5, 0x500000

    const-wide/32 v5, 0x500000

    const/4 v8, 0x1

    const-wide/32 v5, 0x500000

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v3, v5, v6}, Landroid/webkit/WebSettings;->setAppCacheMaxSize(J)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setAppCachePath(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    sget-object v6, Landroid/webkit/WebSettings$TextSize;->NORMAL:Landroid/webkit/WebSettings$TextSize;

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3, v6}, Landroid/webkit/WebSettings;->setTextSize(Landroid/webkit/WebSettings$TextSize;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setAppCacheEnabled(Z)V

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setSavePassword(Z)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    const/4 v8, 0x5

    invoke-virtual {v3, v5}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Landroid/webkit/WebView;->setVerticalScrollbarOverlay(Z)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v6, Lcom/alipay/sdk/widget/e$b;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v6, p0, p1}, Lcom/alipay/sdk/widget/e$b;-><init>(Lcom/alipay/sdk/widget/e;Landroid/content/Context;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v3, v6}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p1, v2}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :catch_0
    :try_start_1
    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v3, "efamrmcpctteoearernpIiasv"

    const-string v3, "frsiemcpatpreoIeaarcvntev"

    const/4 v8, 0x4

    const-string v3, "etaaoIconpsaivmrtreeJvcef"

    const-string/jumbo v3, "removeJavascriptInterface"

    const/4 v7, 0x3

    move v8, v7

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v8, 0x6

    invoke-virtual {p1, v3, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz p1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v3, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-array v6, v4, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v2, v6, v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    aput-object v1, v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x3

    move v8, v7

    iget-object v1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    aput-object v0, v2, v5

    const/4 v7, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p1, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_0
    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v7, 0x6

    move v8, v7

    invoke-static {p1}, Lcom/alipay/sdk/widget/c;->k(Landroid/webkit/WebView;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v0, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {p1, v0, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0, v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-void
.end method

.method static synthetic m(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$e;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->f:Lcom/alipay/sdk/widget/e$e;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;
    .locals 2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic o(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$f;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->g:Lcom/alipay/sdk/widget/e$f;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic p(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$g;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/alipay/sdk/widget/e;->h:Lcom/alipay/sdk/widget/e$g;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method


# virtual methods
.method public c()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method protected e(Landroid/webkit/WebView;Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p2}, Lcom/alipay/sdk/util/l;->A(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public f(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/widget/c;->k(Landroid/webkit/WebView;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public g(Ljava/lang/String;[B)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Landroid/webkit/WebView;->postUrl(Ljava/lang/String;[B)V

    const/4 v2, 0x0

    return-void
.end method

.method public getBackButton()Landroid/widget/ImageView;
    .locals 3

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->a:Landroid/widget/ImageView;

    const/4 v2, 0x0

    return-object v0
.end method

.method public getProgressbar()Landroid/widget/ProgressBar;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->d:Landroid/widget/ProgressBar;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public getRefreshButton()Landroid/widget/ImageView;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->c:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-object v0
.end method

.method public getTitle()Landroid/widget/TextView;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->b:Landroid/widget/TextView;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method

.method public getWebView()Landroid/webkit/WebView;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object v0
.end method

.method public setChromeProxy(Lcom/alipay/sdk/widget/e$f;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/widget/e;->g:Lcom/alipay/sdk/widget/e$f;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, Lcom/alipay/sdk/widget/e$c;

    invoke-direct {v0, p0}, Lcom/alipay/sdk/widget/e$c;-><init>(Lcom/alipay/sdk/widget/e;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setWebClientProxy(Lcom/alipay/sdk/widget/e$g;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/widget/e;->h:Lcom/alipay/sdk/widget/e$g;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x0

    move v2, v1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    shl-int/2addr v1, v0

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/alipay/sdk/widget/e;->e:Landroid/webkit/WebView;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lcom/alipay/sdk/widget/e$d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/alipay/sdk/widget/e$d;-><init>(Lcom/alipay/sdk/widget/e;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setWebEventProxy(Lcom/alipay/sdk/widget/e$h;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/widget/e;->i:Lcom/alipay/sdk/widget/e$h;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method
