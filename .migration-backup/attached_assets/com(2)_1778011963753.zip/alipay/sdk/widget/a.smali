.class public Lcom/alipay/sdk/widget/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/widget/a$d;
    }
.end annotation


# static fields
.field public static final i:Ljava/lang/String; = "\u6b63\u5728\u52a0\u8f7d"

.field public static final j:Ljava/lang/String; = "\u53bb\u652f\u4ed8\u5b9d\u4ed8\u6b3e"

.field public static final k:Ljava/lang/String; = "\u53bb\u652f\u4ed8\u5b9d\u6388\u6743"

.field public static l:Ljava/lang/String; = "iVBORw0KGgoAAAANSUhEUgAAAF4AAABeCAYAAACq0qNuAAAAAXNSR0IArs4c6QAACp9JREFUeAHtXWtsHNUV3l2vvXgdh8QJJViULKVVoIEUFwJRU1nBAiJEK/IjBSQkKtQKoQaIQDRqS1WlP1AqFRT6qyj9V6mloVWBtlYVEHYFpMUlL6OUkDrITakgMcSO114/so/p961ndu+end2d3Z0dbzz3SMdzn+ee88313Zn7OBMMNCEZhhGFWusEr0W8UzCigSnBpxE/qXIwGJxBvKko2AzaAOh26LEZ3Ae+DXwzOAx2g1IQcgg8CB4AH8SNmMXVnwSwI+Dt4FfBc2CviG2xTbYd8Q36MPZm8AvgCfBiE3WgLvwP85Q8G2pgXC8sexp8p0MLR1DuAzDHa14ZnwCrYzqiBeP+SsS/BL4WzN8IXhl3Qq+h0DMYht50UrjpywDwPvBb4Ep0CgX2ge8HX+6WYZRlyqRstlGJqCt/ay5OgvLd4P0VrDyD/L3gHq+sZFtmm2y7HFH3bq/0qrsdKBsGPwmOg0vRIDLuBrv15FK13mzb1GEQ11JEG2jLounpyDAoGAMPgUtRPzK+5kiYh4WoE5i6laJ3kBHzUCXnTUGxbeBSTyr/RN5G59IWpyR1BFNXO6Jt2xZHM5tWoQz/ZZ+30xRp4+BHwCGbqk2ZRF1Nnam7HdHWxR16oEA7+M922iHtZfBlTYmuA6Wou2kDLkVEm/m27T2h4ZXgg0UqGcY80nZ6r1FjWqQtYNokibbzvcE7QoN8VDwuNUF8FOz5W2CjLadNpm24GMbYXNrYNZwwdhxJjP1sZH59o9vPyke77Ol2oB9BumsvPp4YU0UjtA1MG43egbgReGk8y9f0n597anj26ipEZYtW9aOHNjmu/QUs7zJn/rbgdftsVuoS/GPatgWmDR6e4ITnAn2YyEReP3vh2A/eq27YcQw8QOcv+Utg+Rz+CtLugmLxBVWW7l/Txru2XtE2qlo5fD69/O3Ppt7f/S+jTU0vF3YMPIQ8C/6GEMaefj8UmhfpSzZKWzdc2rFhY1cLJ+xy9PZnqTXvjk8P5RIqBBwBj97OFwf5pHIUadv8BLqF5e71wek7V7fecG1nqGBlq/+T5I0PH5rZY5Urd604LQzQYxBAkFcogv6D8CaAvmTHdMXWksGnhuev/91Hc0f+N5NutQpd2hrKfC/W1runJ3rQSrO7lu3x5ri+HxVV0C8g/i2/g04wn/1K5Ph9V7U91BoKGoyTJpOZUP9Y8q+PjZRf3SoLPOQ8Dr6FAhXaBdC5hqkJCDy3of03917Z9rIKxnuT6c6xTxN/UNMch9Hb+ZIkp3YLGnAszAcFNw/EP7ae7Xnt+ONE5vvDia+WMr1cj9+LStxOYdEEAg9bEX0tROCOK9q2rGwLZazURMoIHp7IlOyotsCjp/dBwL2WEPP6Iwwxn4o0HTUR2H3dJf++pzv8ogrIwFjyqp3HZp5Q06ywLfDI/KlVwLy+i+s+kaajAoHExo5vr18eSqjJb5xN7lbjVrgIePR27gb4ulXAvO5Ab8/9G4k8HTUR+H0wmO67PPyo+ox+fDK9/NEjM49VBAnAHwCr1F+xki5QgAB+aM+oP7S3vhEvGqILejzQ5pSu3PfyTIFUHamIwC1dLT9RCw2dS63edXT6ATWtAHhkfFfNRPhvGGL+LtJ0tAICe2/s2NezsuW8WuxYPPNjNZ4DHr2d+wjvUzMR5sSYphoQuLUr/Lxa7Z3x9LpdHxi5x/Mc8Cj0TbA6NcB5mANqZR12jsCaS6J7LouE0laNeNIITk7P5oYgFfgHrULm9UUMM/kZf5Gpo+URwAzmhU2rw8NqqRNTqdw4nwUew0w7CmxVCyH8axHX0SoR+EI08Jxa5R/n0mt2DMVXMc3q8ZsRVldPPkRvP6pW0uHqEfhFz7LfxjpCSatmMmMEjXD4O4xbwPdZmeZ1QMR1tEYEvtzZckqtemYufQ/jFvC3qZkIa+AFILVGu6PB19W6p6YzNzDO7Wo86CX3wnAtVZMLCKxobf2VKub9qcyyH56Ir2KPXwdW9wKOYHz39ZKeClS9Ya5SxaItXLXLUgrj/MxcaKsFvJXOK4+9aHIRgc9Hg+OquEQquEkDryLSoPCqSOi/qujJlHG9HfA87KXJRQRWhAMnVHHn5jNXE/i1aiLCIyKuo3UisKw1dFgVce6C0UXgO9VEhLm2qslFBKJh4yNVXCIVaLMDnudINbmIQEu6cK16Nm2ENfAuAlxKVEs4dEbNww6EkAZeRaRB4blMpBD4dCBI4DU1GIGfbwgkr2zPL4F/LhLMztXIMV3+2DZYLV+I79x3U0eA4JN/eVN0KoC5mlGwSjFfQOGhkQCXB69VGuVQo3t842+CHEWm7ID39ghh441uhha6hBJZ4E+LRKf+XUQ1HS2DwBdF3mn2eDk3w2liTe4iQIdFKp20A14WUivocG0IyM6sga8Nx6pryc58ko+TUXBSfdZBeMme0K4asjorEEuBLbGOhrDMxyOD8kyTXPyus3lfV5dYHiLmHONJcnG7byFZ/3UBAYllHmt0/dvFv0PBXhAXGvetCOAqPf/dngMDmXT4Qw+kKvXkCuhATQgATHr8U4kYc7vkwoYmjDmzCMudwXITa02N+7ySxPCAiXUeFtyJ7eqtQZh+GdX9NvnCOlQRAWJnYohLjrYXVUQWnSxLL3p3FxXUCY4QAJb0q6kSsY3YVkYGHRyrlP8Ftq2hE0shABAHVSARfqFUWb5M0feWJOkYqGR9nbGAAACkA1FJcn9qIVworY9bFkJSdQwYSq+t8sGlWCYq9cpbhXjTe0kttmRxUoiVDX69jrRBRel2nG5frbdcRzL8WIgYgaWL3LccY4HK9Pku6RHHAnxaEIDRna8kOWVQHh3Upv90lehr96J1WVve2vpziQ1Y+iPeX7VkCNGOgqpADXjRl7JKdLLUXYWIfFFUpNN6STvzJXSICAAg+h+W9GTN6EASX3vptF4lOjgu/0xac4sXX0ViAZZOn4lZfdMtEMDNOHIqYRRpvl+lIgZgYqESsYq50oUgiF9DkEQHx8tdaeAiFELbwcRA0jZXzYF0u68iDCDdfuLH1dabSxhtBtN2SQUeO1zRGi1wvLf7OgJ/zX0DPm0F02ZJxKa+cb3UnYJgrlTZfSWBd3/JDzu0EWzX04lJdmWpFHZ1p6MB3zvuBwYq8SMG3uw3RUO+/lSFgjpBr+0lqdZ/Ad5lsN2ww2faJfOSRVvA8jkdSVnbvenp8iahcf05IgmKV3GAz6cdu0dNJOsPcDX8PgBkvmTxrc2OOEfd9Isp1BEs59Mte2ibuy9Hbt0VKMbphSFLU5srl8Sabg2XOoGpWymiTTG3cGqIHCjIoYezmtL3PJJyNIiQ/qxoI+4AgOUj535wOeKmqb1gz7YLsi2zTbZdjqi7t4+Kbt4IKM9lRLmGa2ewrz4dnT9u7CbaNrKANFfanwZLp9E2pbNJdN9Cb1FkntNinJ5FeDzUYgRtP5bOoy88hUF2epjuNZRdOh9LhzEFhBvAhQPuWCv1BIQsz4g6UBf/LOzAWM7ybQf/Cczty14R22KbbHvRZlU9G2oKur2IAADO7G0GcysEj66wB7o1xUr/yDxqxH2gA+CDRVulkeg1NQXw0mjcCPrC5Dit8lrEeTRdZURz47017p9GGn8TcswzRyzYTPR//0eajTDt10YAAAAASUVORK5CYII="


# instance fields
.field private a:Lcom/alipay/sdk/widget/a$d;

.field private b:Landroid/app/Activity;

.field private c:Ljava/lang/String;

.field private d:J

.field private final e:I

.field private final f:J

.field private g:Z

.field private h:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/alipay/sdk/widget/a;->d:J

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    iput v0, p0, Lcom/alipay/sdk/widget/a;->e:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-wide/16 v0, 0x7530

    const-wide/16 v0, 0x7530

    const/4 v3, 0x5

    const-wide/16 v0, 0x7530

    const-wide/16 v0, 0x7530

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/alipay/sdk/widget/a;->f:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/alipay/sdk/widget/a;->g:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Lcom/alipay/sdk/widget/a$c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, p0, v1}, Lcom/alipay/sdk/widget/a$c;-><init>(Lcom/alipay/sdk/widget/a;Landroid/os/Looper;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/alipay/sdk/widget/a;->h:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/alipay/sdk/widget/a;->d:J

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v0, p0, Lcom/alipay/sdk/widget/a;->e:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-wide/16 v0, 0x7530

    const-wide/16 v0, 0x7530

    const/4 v3, 0x6

    const-wide/16 v0, 0x7530

    const-wide/16 v0, 0x7530

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/alipay/sdk/widget/a;->f:J

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/alipay/sdk/widget/a;->g:Z

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    new-instance v0, Lcom/alipay/sdk/widget/a$c;

    const/4 v2, 0x6

    const/4 v2, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/alipay/sdk/widget/a$c;-><init>(Lcom/alipay/sdk/widget/a;Landroid/os/Looper;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/alipay/sdk/widget/a;->h:Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/alipay/sdk/widget/a;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method static synthetic a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s~@ -t@@~~@u@~l~o~o~ f~ bc  l@v b@o~oi dr  @@@~Ko@~@@iaio~~/@/b@~@n @y ~@@~~ .~t1 S~  m4sf ~M~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic b(Lcom/alipay/sdk/widget/a;Lcom/alipay/sdk/widget/a$d;)Lcom/alipay/sdk/widget/a$d;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/widget/a;->a:Lcom/alipay/sdk/widget/a$d;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic f(Lcom/alipay/sdk/widget/a;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/alipay/sdk/widget/a;->c:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic h(Lcom/alipay/sdk/widget/a;)Lcom/alipay/sdk/widget/a$d;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/alipay/sdk/widget/a;->a:Lcom/alipay/sdk/widget/a$d;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic k(Lcom/alipay/sdk/widget/a;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/alipay/sdk/widget/a;->g:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic l(Lcom/alipay/sdk/widget/a;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/alipay/sdk/widget/a;->h:Landroid/os/Handler;

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/a;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/widget/a;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method public e(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/alipay/sdk/widget/a;->g:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v1, Lcom/alipay/sdk/widget/a$a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/alipay/sdk/widget/a$a;-><init>(Lcom/alipay/sdk/widget/a;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v1, Lcom/alipay/sdk/widget/a$b;

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/alipay/sdk/widget/a$b;-><init>(Lcom/alipay/sdk/widget/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public j()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alipay/sdk/widget/a;->b:Landroid/app/Activity;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/alipay/sdk/widget/a;->a:Lcom/alipay/sdk/widget/a$d;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
