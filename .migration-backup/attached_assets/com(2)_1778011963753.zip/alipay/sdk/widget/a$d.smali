.class public Lcom/alipay/sdk/widget/a$d;
.super Landroid/app/AlertDialog;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/widget/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/a;


# direct methods
.method protected constructor <init>(Lcom/alipay/sdk/widget/a;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p2}, Landroid/app/AlertDialog;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method private a(Landroid/content/Context;F)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~si~~~@ uK ~M b~ ~@@~i@ o@ @d~@tS 1ooy~~f- @bi@blac  /~~~@ or t~.v~@om~@@l  /  @ @~~~@f@~@4no@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    mul-float/2addr p2, p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    float-to-int p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method private b(Landroid/content/Context;Ljava/lang/String;I)Landroid/graphics/drawable/Drawable;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v3, 0x2

    invoke-static {p2}, Lcom/alipay/sdk/encrypt/a;->d(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance p2, Landroid/graphics/BitmapFactory$Options;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-gtz p3, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 p3, 0xf0

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput p3, p2, Landroid/graphics/BitmapFactory$Options;->inDensity:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget p3, p3, Landroid/util/DisplayMetrics;->densityDpi:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput p3, p2, Landroid/graphics/BitmapFactory$Options;->inTargetDensity:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1, v0, p2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance p3, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p3, p1, p2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :catchall_1
    move-exception p1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    :try_start_3
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    :try_start_4
    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    :catch_1
    :cond_1
    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :catchall_2
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    :try_start_5
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    :catch_2
    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw p1
.end method

.method private c(Landroid/content/Context;)Landroid/view/View;
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v4, 0x42480000    # 50.0f

    invoke-direct {v0, v1, v4}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v3, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v4, 0x11

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v6, 0x0

    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v7, -0x1ae0dcc9

    invoke-virtual {v3, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v7, 0x40a00000    # 5.0f

    invoke-direct {v0, v1, v7}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v3, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x41a00000    # 20.0f

    invoke-direct {v0, v1, v8}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v9

    invoke-direct {v0, v1, v8}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v8

    invoke-direct {v7, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v8, 0x10

    iput v8, v7, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    iget-object v9, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v9}, Lcom/alipay/sdk/widget/a;->a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;

    move-result-object v9

    const/high16 v10, 0x41880000    # 17.0f

    invoke-direct {v0, v9, v10}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v9

    iget-object v11, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v11}, Lcom/alipay/sdk/widget/a;->a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;

    move-result-object v11

    const/high16 v12, 0x41200000    # 10.0f

    invoke-direct {v0, v11, v12}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v11

    iget-object v13, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v13}, Lcom/alipay/sdk/widget/a;->a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;

    move-result-object v13

    const/high16 v14, 0x41000000    # 8.0f

    invoke-direct {v0, v13, v14}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v13

    iget-object v14, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v14}, Lcom/alipay/sdk/widget/a;->a(Lcom/alipay/sdk/widget/a;)Landroid/app/Activity;

    move-result-object v14

    invoke-direct {v0, v14, v12}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v7, v9, v11, v13, v12}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    sget-object v7, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v7}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    sget-object v7, Lcom/alipay/sdk/widget/a;->l:Ljava/lang/String;

    const/16 v9, 0x1e0

    invoke-direct {v0, v1, v7, v9}, Lcom/alipay/sdk/widget/a$d;->b(Landroid/content/Context;Ljava/lang/String;I)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v3, v7}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v7, Landroid/view/animation/RotateAnimation;

    const/4 v12, 0x0

    const v13, 0x43b38000    # 359.0f

    const/4 v14, 0x1

    const/high16 v15, 0x3f000000    # 0.5f

    const/16 v16, 0x1

    const/high16 v17, 0x3f000000    # 0.5f

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    invoke-direct/range {v11 .. v17}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    const/4 v9, -0x1

    invoke-virtual {v7, v9}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    const-wide/16 v11, 0x384

    const-wide/16 v11, 0x384

    const-wide/16 v11, 0x384

    const-wide/16 v11, 0x384

    invoke-virtual {v7, v11, v12}, Landroid/view/animation/Animation;->setDuration(J)V

    new-instance v11, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v11}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v7, v11}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    invoke-virtual {v3, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v11, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v11}, Lcom/alipay/sdk/widget/a;->f(Lcom/alipay/sdk/widget/a;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_0

    const-string v11, "f2/m3u/57u7/ba6265uu0sd/"

    const-string v11, "6/s2750ud5//ub/2auf3u867"

    const-string v11, "60//o72/3d5fba/882u6u7uu"

    const-string/jumbo v11, "\u6b63\u5728\u52a0\u8f7d"

    goto :goto_0

    :cond_0
    iget-object v11, v0, Lcom/alipay/sdk/widget/a$d;->a:Lcom/alipay/sdk/widget/a;

    invoke-static {v11}, Lcom/alipay/sdk/widget/a;->f(Lcom/alipay/sdk/widget/a;)Ljava/lang/String;

    move-result-object v11

    :goto_0
    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v11, 0x41800000    # 16.0f

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v9, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iput v8, v9, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    invoke-direct {v0, v1, v10}, Lcom/alipay/sdk/widget/a$d;->a(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v9, v6, v6, v8, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v7, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v2, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/FrameLayout;

    invoke-direct {v3, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v5, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v3, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-object v3
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/app/AlertDialog;->onCreate(Landroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/alipay/sdk/widget/a$d;->c(Landroid/content/Context;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method
