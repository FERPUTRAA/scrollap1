.class Lcom/alipay/sdk/widget/e$c;
.super Landroid/webkit/WebChromeClient;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/e;->setChromeProxy(Lcom/alipay/sdk/widget/e$f;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/e;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/e;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x2

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onJsPrompt(Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsPromptResult;)Z
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "r~s@@@~~@fK   ~@i4 b o t@~c~v~ @~o~@t.@~S~~@~@mi~/ - @~~@ ~od~@@oM@la o@ny /@u bb s~i@~  ~f1 l@~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->o(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$f;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-interface/range {v0 .. v5}, Lcom/alipay/sdk/widget/e$f;->b(Lcom/alipay/sdk/widget/e;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsPromptResult;)Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    return p1
.end method

.method public onProgressChanged(Landroid/webkit/WebView;I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x1

    and-int/2addr v2, v1

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->m(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$e;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/widget/e$e;->b(Lcom/alipay/sdk/widget/e$e;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x0

    const/16 p1, 0x5a

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-le p2, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ne p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->n(Lcom/alipay/sdk/widget/e;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 p2, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_0
    const/4 v2, 0x1

    return-void
.end method

.method public onReceivedTitle(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/alipay/sdk/widget/e;->o(Lcom/alipay/sdk/widget/e;)Lcom/alipay/sdk/widget/e$f;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/widget/e$c;->a:Lcom/alipay/sdk/widget/e;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p1, v0, p2}, Lcom/alipay/sdk/widget/e$f;->h(Lcom/alipay/sdk/widget/e;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method
