.class abstract Lcom/alipay/sdk/widget/d$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/animation/Animation$AnimationListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/widget/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x402
    name = "e"
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/d;


# direct methods
.method private constructor <init>(Lcom/alipay/sdk/widget/d;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/widget/d$e;->a:Lcom/alipay/sdk/widget/d;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    and-int/2addr v1, v0

    return-void
.end method

.method synthetic constructor <init>(Lcom/alipay/sdk/widget/d;Lcom/alipay/sdk/widget/d$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/alipay/sdk/widget/d$e;-><init>(Lcom/alipay/sdk/widget/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " /sr ii~~  @@@~i@~~~~ @s@t@/~~~~uf@  l@  @~~b y b~d n ~4@~@@o~vb @l~ f~@o1@@@o ~~~m.o octa-M@SKo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method

.method public onAnimationRepeat(Landroid/view/animation/Animation;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public onAnimationStart(Landroid/view/animation/Animation;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method
