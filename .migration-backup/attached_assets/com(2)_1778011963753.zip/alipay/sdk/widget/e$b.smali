.class Lcom/alipay/sdk/widget/e$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/webkit/DownloadListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/e;->l(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/alipay/sdk/widget/e;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/e;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alipay/sdk/widget/e$b;->b:Lcom/alipay/sdk/widget/e;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/alipay/sdk/widget/e$b;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public onDownloadStart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 2

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~@ol~o/@~b ~b~/fbri@~ ~mo~i@4 ~o~v sM ~ @~~~~ . ud ~f Kc @ @@a@@oto@@1l@@~S~- t @~@@ @ y@~~n@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    new-instance p2, Landroid/content/Intent;

    const/4 v1, 0x2

    const-string/jumbo p3, "iotmcnIW.ietV.Etra.dadnsni"

    const-string p3, "disi..octeoItatnErndaiVW.n"

    const/4 v1, 0x0

    const-string/jumbo p3, "id.iont.WcVneEIrtanoaitod."

    const-string p3, "android.intent.action.VIEW"

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p2, p3, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v0, 0x2

    move v1, v0

    const/high16 p1, 0x10000000

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v0, 0x7

    move v1, v0

    iget-object p1, p0, Lcom/alipay/sdk/widget/e$b;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method
