.class final Lcom/alipay/sdk/widget/e$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/widget/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "e"
.end annotation


# instance fields
.field private a:Z

.field private b:Z


# direct methods
.method constructor <init>(ZZ)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/alipay/sdk/widget/e$e;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-boolean p2, p0, Lcom/alipay/sdk/widget/e$e;->b:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/alipay/sdk/widget/e$e;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-boolean p0, p0, Lcom/alipay/sdk/widget/e$e;->a:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic b(Lcom/alipay/sdk/widget/e$e;)Z
    .locals 2

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/alipay/sdk/widget/e$e;->b:Z

    const/4 v1, 0x6

    return p0
.end method
