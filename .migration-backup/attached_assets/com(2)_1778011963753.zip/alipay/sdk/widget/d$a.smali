.class Lcom/alipay/sdk/widget/d$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/widget/d;->b(Lcom/alipay/sdk/widget/e;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsPromptResult;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/widget/d;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/widget/d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/widget/d$a;->a:Lcom/alipay/sdk/widget/d;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ibs@ oi .~~a@o~@~ o ~ ~@l~~@ tuf~/Sb on rK~@~@@ t~@1~b~@M@sy @~  ~@ l4@@@ oo ~m-id v@~@c~~~/@f ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/alipay/sdk/widget/d$a;->a:Lcom/alipay/sdk/widget/d;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/alipay/sdk/widget/c;->a:Landroid/app/Activity;

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void
.end method
