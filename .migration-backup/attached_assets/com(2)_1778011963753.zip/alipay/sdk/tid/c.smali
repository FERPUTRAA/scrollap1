.class public Lcom/alipay/sdk/tid/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/tid/c$a;
    }
.end annotation


# static fields
.field public static final g:Ljava/lang/String; = "alipay_tid_storage"

.field public static final h:Ljava/lang/String; = "tidinfo"

.field public static final i:Ljava/lang/String; = "tid"

.field public static final j:Ljava/lang/String; = "client_key"

.field public static final k:Ljava/lang/String; = "timestamp"

.field public static final l:Ljava/lang/String; = "vimei"

.field public static final m:Ljava/lang/String; = "vimsi"

.field private static n:Landroid/content/Context;

.field private static o:Lcom/alipay/sdk/tid/c;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:J

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/alipay/sdk/tid/c;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @sli~ @o~ r@@ ~f ~@~b~@@~~ ~o ~cb /y 4.l~ ~@ ~@u dm@@~iot@~@v boMif  ~s@o@t~@/@n~ -Ko~~Sa @1~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/sdk/tid/c;

    const-class v0, Lcom/alipay/sdk/tid/c;

    const/4 v3, 0x7

    const-class v0, Lcom/alipay/sdk/tid/c;

    const-class v0, Lcom/alipay/sdk/tid/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/alipay/sdk/tid/c;->o:Lcom/alipay/sdk/tid/c;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v2, 0x7

    and-int/2addr v3, v2

    new-instance v1, Lcom/alipay/sdk/tid/c;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/alipay/sdk/tid/c;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v1, Lcom/alipay/sdk/tid/c;->o:Lcom/alipay/sdk/tid/c;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    sget-object v1, Lcom/alipay/sdk/tid/c;->n:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v1, Lcom/alipay/sdk/tid/c;->o:Lcom/alipay/sdk/tid/c;

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/alipay/sdk/tid/c;->g(Landroid/content/Context;)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object p0, Lcom/alipay/sdk/tid/c;->o:Lcom/alipay/sdk/tid/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    throw p0
.end method

.method private d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/alipay/sdk/tid/c;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p4, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez p5, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-wide p1, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p5}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-wide p1, p0, Lcom/alipay/sdk/tid/c;->c:J

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->t()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-nez p1, :cond_1

    const/4 v0, 0x6

    move v1, v0

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-nez p1, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-nez p1, :cond_1

    const/4 v0, 0x7

    move v1, v0

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x1

    :goto_1
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method private g(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    sput-object p1, Lcom/alipay/sdk/tid/c;->n:Landroid/content/Context;

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget-boolean p1, p0, Lcom/alipay/sdk/tid/c;->f:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eqz p1, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/alipay/sdk/tid/c;->f:Z

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->p()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic o()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x5

    sget-object v0, Lcom/alipay/sdk/tid/c;->n:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method private p()V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v2, 0x0

    :try_start_0
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string v3, "_aomptdagiras_ilse"

    const-string/jumbo v3, "lpse_a_rtgaiaistdo"

    const/4 v10, 0x7

    const-string v3, "alipay_tid_storage"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string/jumbo v4, "oifiotm"

    const-string/jumbo v4, "iifmnot"

    const/4 v10, 0x0

    const-string/jumbo v4, "tiinfbo"

    const-string/jumbo v4, "tidinfo"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    const/4 v5, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v3, v4, v5}, Lcom/alipay/sdk/tid/c$a;->b(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v4, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    new-instance v4, Lorg/json/JSONObject;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string/jumbo v3, "tdi"

    const-string/jumbo v3, "tid"

    const/4 v10, 0x1

    const-string v3, "dti"

    const-string/jumbo v3, "tid"

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    invoke-virtual {v4, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    :try_start_1
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string v5, "client_key"

    const/4 v9, 0x4

    const/4 v9, 0x2

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    :try_start_2
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v6, "asotitupm"

    const-string v6, "amstoetip"

    const/4 v10, 0x0

    const-string/jumbo v6, "mpetsaipm"

    const-string/jumbo v6, "timestamp"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v4, v6, v7, v8}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string v6, "ebmqi"

    const-string v6, "bivme"

    const/4 v10, 0x6

    const-string v6, "eisvi"

    const-string/jumbo v6, "vimei"

    invoke-virtual {v4, v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :try_start_3
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string/jumbo v7, "imimu"

    const-string/jumbo v7, "muivi"

    const/4 v10, 0x5

    const-string/jumbo v7, "isimo"

    const-string/jumbo v7, "vimsi"

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v4, v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_2

    :catch_0
    move-exception v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_1

    :catch_1
    move-exception v0

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_1

    :catch_2
    move-exception v0

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_0

    :cond_0
    move-object v0, v2

    move-object v0, v2

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_3

    :catch_3
    move-exception v0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v5, v3

    move-object v5, v3

    :goto_0
    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    :goto_1
    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_2
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_3
    const/4 v10, 0x4

    const/4 v9, 0x7

    const-string/jumbo v3, "lspm"

    const-string/jumbo v3, "pmls"

    const/4 v10, 0x1

    const-string/jumbo v3, "smpl"

    const-string/jumbo v3, "mspl"

    const/4 v10, 0x5

    const-string v4, "_tli:btdpso r"

    const-string v4, " _ds:ldptoitr"

    const-string/jumbo v4, "ta _s:uidlotr"

    const-string/jumbo v4, "tid_str: load"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {v3, v4}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-direct {p0, v2, v5, v6, v0}, Lcom/alipay/sdk/tid/c;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v3, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->q()V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    goto :goto_4

    :cond_1
    const/4 v9, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    iput-object v2, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    iput-object v5, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput-wide v1, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v10, 0x1

    const/4 v9, 0x0

    iput-object v6, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    iput-object v0, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    :goto_4
    const/4 v9, 0x7

    move v10, v9

    return-void
.end method

.method private q()V
    .locals 4

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->k()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->r()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->r()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "_taptilpasyerga_di"

    const-string v0, "alipay_tid_storage"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "fqoinit"

    const-string/jumbo v1, "tidinfo"

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/alipay/sdk/tid/c$a;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method private r()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Ljava/util/Random;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/16 v0, 0x2328

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/lit16 v0, v0, 0x3e8

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method

.method private s()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method private t()V
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v1, "itd"

    const-string v1, "dti"

    const/4 v5, 0x5

    const-string/jumbo v1, "tid"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    const-string/jumbo v1, "yesiq_tlec"

    const-string v1, "ekic_letqy"

    const/4 v5, 0x4

    const-string v1, "eykmncl_te"

    const-string v1, "client_key"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "epstoamsi"

    const-string/jumbo v1, "issemtpta"

    const/4 v5, 0x5

    const-string/jumbo v1, "pemtsbtmi"

    const-string/jumbo v1, "timestamp"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v1, "euiim"

    const-string/jumbo v1, "ieimv"

    const/4 v5, 0x7

    const-string/jumbo v1, "mipvi"

    const-string/jumbo v1, "vimei"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x7

    const-string/jumbo v1, "iomqs"

    const-string/jumbo v1, "miiso"

    const/4 v5, 0x4

    const-string/jumbo v1, "iisvm"

    const-string/jumbo v1, "vimsi"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v1, "poamatgbtelid_i_sy"

    const-string v1, "_esiyboa_tapidaglt"

    const/4 v5, 0x7

    const-string/jumbo v1, "teyso_od_agiiplrat"

    const-string v1, "alipay_tid_storage"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "itfdiou"

    const-string/jumbo v2, "infoibd"

    const-string/jumbo v2, "tidinfo"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v1, v2, v0, v3}, Lcom/alipay/sdk/tid/c$a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method


# virtual methods
.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public c(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "lpms"

    const-string/jumbo v0, "mslp"

    const/4 v3, 0x7

    const-string/jumbo v0, "pmsl"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const-string v1, "dtvs _uepst:a"

    const-string/jumbo v1, "v:ds stp_aret"

    const/4 v3, 0x3

    const-string/jumbo v1, "tdtv:sspe r_i"

    const-string/jumbo v1, "tid_str: save"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p2, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->t()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->s()V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->d:Ljava/lang/String;

    const/4 v2, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/tid/c;->e:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x4

    return v0
.end method

.method public k()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v2, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-le v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    sub-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0
.end method

.method public l()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "splm"

    const-string/jumbo v0, "plms"

    const-string/jumbo v0, "slpm"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "ei ldqr:q_tt"

    const-string v1, "el i_:drqdtt"

    const/4 v3, 0x6

    const-string/jumbo v1, "tid_str: del"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/alipay/sdk/tid/c;->q()V

    const/4 v3, 0x3

    return-void
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->j()Z

    move-result v0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public n()Ljava/lang/Long;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/alipay/sdk/tid/c;->c:J

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    return-object v0
.end method
