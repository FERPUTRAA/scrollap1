.class public final Lcom/alipay/sdk/tid/a;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/tid/a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/alipay/sdk/tid/a;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p3, p0, Lcom/alipay/sdk/tid/a;->c:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public static d(Lcom/alipay/sdk/tid/a;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-eqz p0, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/alipay/sdk/tid/a;->a:Ljava/lang/String;

    const/4 v1, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/tid/a;->a:Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/tid/a;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public c()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/alipay/sdk/tid/a;->c:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0
.end method
