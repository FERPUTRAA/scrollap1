.class public Lcom/alipay/sdk/tid/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method private static a(Landroid/content/Context;Lcom/alipay/sdk/tid/c;)Lcom/alipay/sdk/tid/a;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "m@s/@di@o@~f@n@~S~~@l~ ~@@   ~~o@~-  @b~ o~f~ ~y~oo ~  c@b@ ~s~.i~1@ tr~b@a @ov@@/Mli@~ @~ ~ t4K"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/alipay/sdk/tid/c;->j()Z

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance p0, Lcom/alipay/sdk/tid/a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/alipay/sdk/tid/c;->f()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/alipay/sdk/tid/c;->n()Ljava/lang/Long;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/alipay/sdk/tid/a;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v4, 0x6

    move v5, v4

    return-object p0

    :cond_1
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 p0, 0x0

    move v5, p0

    const/4 v4, 0x3

    move v5, v4

    return-object p0
.end method

.method private static b(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {v0, p0}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private static c(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    new-instance v1, Lcom/alipay/sdk/packet/impl/c;

    const/4 v5, 0x1

    move v6, v5

    invoke-direct {v1}, Lcom/alipay/sdk/packet/impl/c;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lx0/a;->f()Lx0/a;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, v2, p0}, Lcom/alipay/sdk/packet/e;->a(Lx0/a;Landroid/content/Context;)Lcom/alipay/sdk/packet/b;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v2, Lorg/json/JSONObject;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/alipay/sdk/packet/b;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v3, "dti"

    const-string/jumbo v3, "idt"

    const/4 v6, 0x5

    const-string/jumbo v3, "itd"

    const-string/jumbo v3, "tid"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v4, "_symtlkeec"

    const-string v4, "_ksenectly"

    const/4 v6, 0x3

    const-string/jumbo v4, "ieneotlcky"

    const-string v4, "client_key"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, v3, v2}, Lcom/alipay/sdk/tid/c;->c(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p0, v1}, Lcom/alipay/sdk/tid/b;->a(Landroid/content/Context;Lcom/alipay/sdk/tid/c;)Lcom/alipay/sdk/tid/a;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object p0

    :catchall_0
    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object v0
.end method

.method public static d(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-static {p0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->l()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/util/b;->d()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/util/b;->b()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public static declared-synchronized g(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/sdk/tid/b;

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/sdk/tid/b;

    const-class v0, Lcom/alipay/sdk/tid/b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->k(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/tid/a;->d(Lcom/alipay/sdk/tid/a;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/a;->a()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p0
.end method

.method public static h(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {}, Lcom/alipay/sdk/data/b;->f()Lcom/alipay/sdk/data/b;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/b;->i()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public static i(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {}, Lcom/alipay/sdk/data/b;->f()Lcom/alipay/sdk/data/b;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/b;->l()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public static j(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->m()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 p0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object p0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v0, Lcom/alipay/sdk/tid/a;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->f()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/tid/c;->n()Ljava/lang/Long;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/alipay/sdk/tid/a;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v6, 0x2

    return-object v0
.end method

.method public static declared-synchronized k(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-class v0, Lcom/alipay/sdk/tid/b;

    const/4 v5, 0x5

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const-string/jumbo v1, "slmp"

    const-string/jumbo v1, "mspl"

    const/4 v5, 0x2

    const-string/jumbo v2, "rtca_bl_idmeeat"

    const-string/jumbo v2, "t_dmaareieolt_c"

    const/4 v5, 0x2

    const-string/jumbo v2, "t_eraculteao_id"

    const-string/jumbo v2, "load_create_tid"

    const/4 v4, 0x5

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->l(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/alipay/sdk/tid/a;->d(Lcom/alipay/sdk/tid/a;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-ne v2, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 p0, 0x0

    move v5, p0

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    return-object p0

    :cond_0
    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->c(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    throw p0
.end method

.method public static l(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/alipay/sdk/tid/b;->a(Landroid/content/Context;Lcom/alipay/sdk/tid/c;)Lcom/alipay/sdk/tid/a;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "plms"

    const-string/jumbo v0, "lsmp"

    const/4 v3, 0x4

    const-string/jumbo v0, "pmls"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x6

    const-string/jumbo v1, "lonoutdpl _da"

    const-string v1, " oldol_dntaul"

    const/4 v3, 0x5

    const-string v1, "_ tlnoidqadll"

    const-string/jumbo v1, "load_tid null"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0
.end method

.method public static m(Landroid/content/Context;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "psml"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x3

    const-string/jumbo v0, "mpsl"

    const-string/jumbo v0, "mspl"

    const-string/jumbo v1, "tbs_tsedi"

    const-string/jumbo v1, "ttdr_bise"

    const/4 v3, 0x6

    const-string/jumbo v1, "srdmtei_e"

    const-string/jumbo v1, "reset_tid"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->b(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->d(Landroid/content/Context;)V

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/alipay/sdk/tid/b;->c(Landroid/content/Context;)Lcom/alipay/sdk/tid/a;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/tid/a;->d(Lcom/alipay/sdk/tid/a;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x0

    return p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/Exception;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "dlt oehM esd wkarnraot eocerl u"

    const-string v0, "Must be called on worker thread"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method
