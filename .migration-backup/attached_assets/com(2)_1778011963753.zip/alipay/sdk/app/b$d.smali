.class final Lcom/alipay/sdk/app/b$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "d"
.end annotation


# instance fields
.field final a:I

.field final b:Ljava/lang/String;

.field final c:Landroid/os/Bundle;

.field final synthetic d:Lcom/alipay/sdk/app/b;


# direct methods
.method private constructor <init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/b$d;->d:Lcom/alipay/sdk/app/b;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p2, p0, Lcom/alipay/sdk/app/b$d;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/alipay/sdk/app/b$d;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/alipay/sdk/app/b$d;->c:Landroid/os/Bundle;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ s  @ari @4u @@i ~@M~@io ~~ ~ ~fobK  ~@ ~/@y@ s~~@~~ ~@~~od~ o~~t@fn-o@@ @v1cl obl.S~mb~~t/@@@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/app/b$d;->d:Lcom/alipay/sdk/app/b;

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    invoke-static {v0}, Lcom/alipay/sdk/app/b;->a(Lcom/alipay/sdk/app/b;)Lcom/alipay/sdk/app/b$c;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/app/b$d;->d:Lcom/alipay/sdk/app/b;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/app/b;->a(Lcom/alipay/sdk/app/b;)Lcom/alipay/sdk/app/b$c;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v1, p0, Lcom/alipay/sdk/app/b$d;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/alipay/sdk/app/b$d;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/alipay/sdk/app/b$d;->c:Landroid/os/Bundle;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {v0, v1, v2, v3}, Lcom/alipay/sdk/app/b$c;->a(ILjava/lang/String;Landroid/os/Bundle;)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method
