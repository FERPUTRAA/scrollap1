.class final Lcom/alipay/sdk/app/statistic/a$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/app/statistic/a$b;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->b:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s~~o~@4am/@ i@oy~S~  @tiu~ t   ~@@o Kc~o/ l~@ @l~b~@1o@vf ~.id~~@ ~@b o~@~~@~-@M~@s@@fb~r    n"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->b:Landroid/content/Context;

    const/4 v3, 0x7

    move v4, v3

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/app/statistic/a$b;->d(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x0

    move v4, v3

    if-ge v0, v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->b:Landroid/content/Context;

    invoke-static {v1}, Lcom/alipay/sdk/app/statistic/a$a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/alipay/sdk/app/statistic/a$b$a;->b:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {v2, v1}, Lcom/alipay/sdk/app/statistic/a$b;->d(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method
