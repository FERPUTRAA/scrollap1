.class final Lcom/alipay/sdk/app/statistic/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/statistic/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/statistic/a$a$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "RecordPref"

.field private static final b:Ljava/lang/String; = "alipay_cashier_statistic_record"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)I
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "oosy@t~t~s@   ~lK -@@b/  m~@~SMn@~@ ~4@ a~~bu~fl@@f@@@~@~@~@c oo~i ~~r1~  i~i@ @ ~ob@  @v od~.~/"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const-string v1, "RPsmecfdro"

    const-string v1, "ersRPfocrd"

    const-string/jumbo v1, "reoRoPrcfe"

    const-string v1, "RecordPref"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const-string v3, "et m aovrsme"

    const/4 v7, 0x2

    const-string/jumbo v3, "see mbrtavt "

    const-string/jumbo v3, "stat remove "

    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v1, v2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz p0, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto/16 :goto_2

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/a$a;->e(Landroid/content/Context;)Lcom/alipay/sdk/app/statistic/a$a$a;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v3, v2, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v3, :cond_1

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    return v1

    :cond_1
    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v7, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v3, v2, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_2
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v4, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v3, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v4, v2, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v4, v3}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x4

    goto :goto_1

    :cond_4
    const/4 v7, 0x5

    invoke-static {p0, v2}, Lcom/alipay/sdk/app/statistic/a$a;->d(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/a$a$a;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    monitor-exit v0

    const/4 v6, 0x0

    move v7, v6

    return p0

    :catchall_0
    move-exception p1

    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object p1, v2, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/util/AbstractMap;->size()I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v1, Lcom/alipay/sdk/app/statistic/a$a$a;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {v1}, Lcom/alipay/sdk/app/statistic/a$a$a;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p0, v1}, Lcom/alipay/sdk/app/statistic/a$a;->d(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/a$a$a;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x2

    move v7, v6

    monitor-exit v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    return p1

    :cond_5
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v7, 0x2

    return v1

    :catchall_1
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    throw p0
.end method

.method static declared-synchronized b(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x1

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const-string v1, "ceRofPudre"

    const-string v1, "derroPfcRe"

    const/4 v4, 0x5

    const-string v1, "corfPedprR"

    const-string v1, "RecordPref"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string v2, "b stekaeq"

    const-string/jumbo v2, "kp etbsae"

    const/4 v4, 0x1

    const-string/jumbo v2, "stat peek"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v1

    :cond_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/a$a;->e(Landroid/content/Context;)Lcom/alipay/sdk/app/statistic/a$a$a;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    iget-object v2, p0, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x2

    return-object v1

    :cond_1
    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object p0, p0, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast p0, Ljava/util/Map$Entry;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast p0, Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_3
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    throw p0
.end method

.method static declared-synchronized c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v5, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x7

    const-string/jumbo v1, "uesrrePoRf"

    const-string/jumbo v1, "rPerdfuReo"

    const/4 v5, 0x1

    const-string v1, "efrmrodcRP"

    const-string v1, "RecordPref"

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v3, " pattaepnd p"

    const/4 v5, 0x5

    const-string v3, "esa ott dpan"

    const-string/jumbo v3, "stat append "

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v3, " , "

    const-string v3, " , "

    const/4 v5, 0x3

    const-string v3, " , "

    const-string v3, " , "

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1, v2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/a$a;->e(Landroid/content/Context;)Lcom/alipay/sdk/app/statistic/a$a$a;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v2, v1, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/util/AbstractMap;->size()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/16 v3, 0x14

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-le v2, v3, :cond_2

    iget-object v2, v1, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    :cond_2
    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v2, v1, Lcom/alipay/sdk/app/statistic/a$a$a;->a:Ljava/util/LinkedHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, p2, p1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0, v1}, Lcom/alipay/sdk/app/statistic/a$a;->d(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/a$a$a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    return-object p2

    :cond_3
    :goto_0
    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw p0
.end method

.method private static declared-synchronized d(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/a$a$a;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x0

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    monitor-enter v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez p1, :cond_0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance p1, Lcom/alipay/sdk/app/statistic/a$a$a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/alipay/sdk/app/statistic/a$a$a;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/alipay/sdk/app/statistic/a$a$a;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v1, "aart_bcsiye_sht_sidicqcealtorip"

    const-string v1, "clshosycq_aairdeiraitatip_sect_"

    const/4 v4, 0x2

    const-string/jumbo v1, "selitrucashtiad_y_caiirasptrco_"

    const-string v1, "alipay_cashier_statistic_record"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v2, p0, v1, p1}, Lcom/alipay/sdk/util/h;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    goto :goto_2

    :goto_1
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :catchall_1
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p0
.end method

.method private static declared-synchronized e(Landroid/content/Context;)Lcom/alipay/sdk/app/statistic/a$a$a;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "_iaaisypdtchtit_clarsirarpoc_es"

    const-string v1, "alipay_cashier_statistic_record"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v2, p0, v1, v2}, Lcom/alipay/sdk/util/h;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance p0, Lcom/alipay/sdk/app/statistic/a$a$a;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/alipay/sdk/app/statistic/a$a$a;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_0
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Lcom/alipay/sdk/app/statistic/a$a$a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1, p0}, Lcom/alipay/sdk/app/statistic/a$a$a;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v1

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    move v4, v3

    new-instance p0, Lcom/alipay/sdk/app/statistic/a$a$a;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/alipay/sdk/app/statistic/a$a$a;-><init>()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :catchall_1
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p0
.end method
