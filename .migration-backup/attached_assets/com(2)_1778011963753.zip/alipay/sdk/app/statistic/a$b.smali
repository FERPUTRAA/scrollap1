.class final Lcom/alipay/sdk/app/statistic/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/statistic/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static declared-synchronized a(Landroid/content/Context;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s. @ob@@@~1~i~c @~ @~  o o@d ~o~ 4a@~~m~ r t i~t@b f@~Kubyo~~oS@~~nv@/i-~ @~~l/s@@~~ @~@ l M f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v3, 0x0

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-enter v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, v1, v1}, Lcom/alipay/sdk/app/statistic/a$b;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x5

    move v3, v2

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    throw p0
.end method

.method static declared-synchronized b(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/b;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-enter v0

    const/4 v2, 0x3

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Lcom/alipay/sdk/app/statistic/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0, p1, p3}, Lcom/alipay/sdk/app/statistic/a$b;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    monitor-exit v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-exit v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method private static declared-synchronized c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v3, 0x5

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    monitor-enter v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    monitor-exit v0

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, p1, p2}, Lcom/alipay/sdk/app/statistic/a$a;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/Thread;

    const/4 v3, 0x2

    const/4 v2, 0x0

    new-instance v1, Lcom/alipay/sdk/app/statistic/a$b$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1, p1, p0}, Lcom/alipay/sdk/app/statistic/a$b$a;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    const/4 v3, 0x2

    invoke-direct {p2, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0
.end method

.method static synthetic d(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/alipay/sdk/app/statistic/a$b;->e(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method private static declared-synchronized e(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v5, 0x6

    const-class v0, Lcom/alipay/sdk/app/statistic/a$b;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v1, "slpm"

    const/4 v5, 0x6

    const-string/jumbo v1, "spml"

    const-string/jumbo v1, "mspl"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v3, " bsutsa s"

    const/4 v5, 0x5

    const-string/jumbo v3, "tatmbssu "

    const-string/jumbo v3, "stat sub "

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Lcom/alipay/sdk/data/a;->o()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v1, Lcom/alipay/sdk/packet/impl/d;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v1}, Lcom/alipay/sdk/packet/impl/d;-><init>()V

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v1, Lcom/alipay/sdk/packet/impl/e;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v1}, Lcom/alipay/sdk/packet/impl/e;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v3, 0x0

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2, p0, p1}, Lcom/alipay/sdk/packet/e;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0, p1}, Lcom/alipay/sdk/app/statistic/a$a;->a(Landroid/content/Context;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    return p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v3

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    return v3

    :catchall_1
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    throw p0
.end method
