.class final Lcom/alipay/sdk/app/statistic/a$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/statistic/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "alipay_cashier_statistic_v"


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method static declared-synchronized a(Landroid/content/Context;)J
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a$c;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$c;

    const/4 v7, 0x6

    const-class v0, Lcom/alipay/sdk/app/statistic/a$c;

    const-class v0, Lcom/alipay/sdk/app/statistic/a$c;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    monitor-enter v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x2

    move v7, v6

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v4, "caslitirhas_ses_cpyataitsi"

    const-string/jumbo v4, "pisitchtsslc_iaa_yt_iesraa"

    const/4 v7, 0x6

    const-string/jumbo v4, "iatmtisvaaepyshic_sa_it_cl"

    const-string v4, "alipay_cashier_statistic_v"

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-static {v1, p0, v4, v1}, Lcom/alipay/sdk/util/h;->d(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-long/2addr v2, v4

    :try_start_1
    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v4, "v_atocatisasmhrpiycsit_al_"

    const-string v4, "__amialrctavasecitit_ypshs"

    const/4 v7, 0x1

    const-string v4, "cc_asbali_ithtsapey_iitavs"

    const-string v4, "alipay_cashier_statistic_v"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v1, p0, v4, v5}, Lcom/alipay/sdk/util/h;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    monitor-exit v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-wide v2
.end method
