.class public Lcom/alipay/sdk/app/statistic/b;
.super Ljava/lang/Object;


# static fields
.field public static final A:Ljava/lang/String; = "H5PayNetworkError"

.field public static final A0:Ljava/lang/String; = "out_trade_no"

.field public static final B:Ljava/lang/String; = "H5AuthNetworkError"

.field public static final B0:Ljava/lang/String; = "trade_no"

.field public static final C:Ljava/lang/String; = "SSLError"

.field public static final C0:Ljava/lang/String; = "biz_content"

.field public static final D:Ljava/lang/String; = "SSLProceed"

.field public static final D0:Ljava/lang/String; = "app_id"

.field public static final E:Ljava/lang/String; = "SSLDenied"

.field public static final F:Ljava/lang/String; = "H5PayDataAnalysisError"

.field public static final G:Ljava/lang/String; = "H5AuthDataAnalysisError"

.field public static final H:Ljava/lang/String; = "PublicKeyUnmatch"

.field public static final I:Ljava/lang/String; = "ClientBindFailed"

.field public static final J:Ljava/lang/String; = "TriDesEncryptError"

.field public static final K:Ljava/lang/String; = "TriDesDecryptError"

.field public static final L:Ljava/lang/String; = "ClientBindException"

.field public static final M:Ljava/lang/String; = "SaveTradeTokenError"

.field public static final N:Ljava/lang/String; = "ClientBindServiceFailed"

.field public static final O:Ljava/lang/String; = "TryStartServiceEx"

.field public static final P:Ljava/lang/String; = "BindWaitTimeoutEx"

.field public static final Q:Ljava/lang/String; = "CheckClientExistEx"

.field public static final R:Ljava/lang/String; = "CheckClientSignEx"

.field public static final S:Ljava/lang/String; = "GetInstalledAppEx"

.field public static final T:Ljava/lang/String; = "ParserTidClientKeyEx"

.field public static final U:Ljava/lang/String; = "PgApiInvoke"

.field public static final V:Ljava/lang/String; = "PgBindStarting"

.field public static final W:Ljava/lang/String; = "PgBinded"

.field public static final X:Ljava/lang/String; = "PgBindEnd"

.field public static final Y:Ljava/lang/String; = "PgBindPay"

.field public static final Z:Ljava/lang/String; = "PgReturn"

.field public static final a0:Ljava/lang/String; = "PgReturnV"

.field public static final b0:Ljava/lang/String; = "PgWltVer"

.field public static final c0:Ljava/lang/String; = "PgOpenStarting"

.field public static final d0:Ljava/lang/String; = "ErrIntentEx"

.field public static final e0:Ljava/lang/String; = "ErrActNull"

.field public static final f0:Ljava/lang/String; = "ErrActNull"

.field public static final g0:Ljava/lang/String; = "GetInstalledAppEx"

.field public static final h0:Ljava/lang/String; = "StartLaunchAppTransEx"

.field public static final i0:Ljava/lang/String; = "CheckLaunchAppExistEx"

.field public static final j0:Ljava/lang/String; = "LogCurrentAppLaunchSwitch"

.field public static final k:Ljava/lang/String; = "net"

.field public static final k0:Ljava/lang/String; = "LogCurrentQueryTime"

.field public static final l:Ljava/lang/String; = "biz"

.field public static final l0:Ljava/lang/String; = "LogCalledPackage"

.field public static final m:Ljava/lang/String; = "cp"

.field public static final m0:Ljava/lang/String; = "LogBindCalledH5"

.field public static final n:Ljava/lang/String; = "auth"

.field public static final n0:Ljava/lang/String; = "LogCalledH5"

.field public static final o:Ljava/lang/String; = "third"

.field public static final o0:Ljava/lang/String; = "LogHkLoginByIntent"

.field public static final p:Ljava/lang/String; = "tid"

.field public static final p0:Ljava/lang/String; = "SchemePayWrongHashEx"

.field public static final q:Ljava/lang/String; = "wlt"

.field public static final q0:Ljava/lang/String; = "LogAppLaunchSwitchEnabled"

.field public static final r:Ljava/lang/String; = "FormatResultEx"

.field public static final r0:Ljava/lang/String; = "H5CbUrlEmpty"

.field public static final s:Ljava/lang/String; = "GetApdidEx"

.field public static final s0:Ljava/lang/String; = "H5CbEx"

.field public static final t:Ljava/lang/String; = "GetApdidNull"

.field public static final t0:Ljava/lang/String; = "BuildSchemePayUriError"

.field public static final u:Ljava/lang/String; = "GetApdidTimeout"

.field public static final u0:Ljava/lang/String; = "StartActivityEx"

.field public static final v:Ljava/lang/String; = "GetUtdidEx"

.field public static final v0:Ljava/lang/String; = "JSONEx"

.field public static final w:Ljava/lang/String; = "GetPackageInfoEx"

.field public static final w0:Ljava/lang/String; = "ParseBundleSerializableError"

.field public static final x:Ljava/lang/String; = "NotIncludeSignatures"

.field public static final x0:Ljava/lang/String; = "ParseSchemeQueryError"

.field public static final y:Ljava/lang/String; = "GetInstalledPackagesEx"

.field public static final y0:Ljava/lang/String; = "tid_context_null"

.field public static final z:Ljava/lang/String; = "GetPublicKeyFromSignEx"

.field public static final z0:Ljava/lang/String; = "partner"


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/alipay/sdk/app/statistic/b;->h:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lcom/alipay/sdk/app/statistic/b;->o()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/alipay/sdk/app/statistic/b;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/app/statistic/b;->c:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    if-eqz p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/a$c;->a(Landroid/content/Context;)J

    move-result-wide v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/app/statistic/b;->a(J)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object p2, p0, Lcom/alipay/sdk/app/statistic/b;->d:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {}, Lcom/alipay/sdk/app/statistic/b;->u()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p2, p0, Lcom/alipay/sdk/app/statistic/b;->e:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->l(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->f:Ljava/lang/String;

    const/4 v3, 0x0

    const-string p1, "-"

    const-string p1, "-"

    const/4 v3, 0x3

    const-string p1, "-"

    const-string p1, "-"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->g:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->j:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private static a(J)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "dosf~~tbo@~ uo@ciKy /i~r@@@b1~@@a~bi  @ ~M~o~ @~@ vm~~~/S ~ @f@n-@@@~l o~t ~s ~@l~@ @ @o~ ~~ @ 4"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    const-string v0, "1s.m7."

    const-string v0, "7.s7.1"

    const/4 v5, 0x5

    const-string v0, "75.1o7"

    const-string v0, "15.7.7"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "ah7..bm.."

    const-string v1, "7h7m...a."

    const/4 v5, 0x3

    const-string v1, "h.a.3.7.7"

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v2, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v0, v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object v1, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v1, "~"

    const-string/jumbo v1, "~"

    const/4 v5, 0x6

    const-string/jumbo v1, "~"

    const-string/jumbo v1, "~"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 p1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p0, v2, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo p0, "pyoc5,upda.ai3,lismrs,,os..,c,-%n,%a-,ya%dm"

    const-string p0, "dp,mo-.5raopc,sloy,i.,%a,ns.as%3,c,yad%m-,i"

    const/4 v5, 0x5

    const-string p0, ",y,yaapps.dn35,--,oa%m,slam,s.%ic.0,i%rco,p"

    const-string p0, "android,3,%s,%s,com.alipay.mcpay,5.0,-,%s,-"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object p0
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v0, "-"

    const-string v0, "-"

    const/4 v5, 0x7

    const-string v0, "-"

    const-string v0, "-"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v5, 0x5

    const/16 v2, 0x40

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/b;->c(Landroid/content/pm/PackageInfo;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "|"

    const-string/jumbo v2, "|"

    const/4 v5, 0x4

    const-string/jumbo v2, "|"

    const-string/jumbo v2, "|"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :catchall_1
    :goto_0
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_1

    :cond_0
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    aput-object v0, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    aput-object p0, v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string p0, "%-%sb-s,q,-"

    const-string p0, "%,s%-bs-,-,"

    const/4 v5, 0x6

    const-string p0, "%%s,-,s-,s-"

    const-string p0, "%s,%s,-,-,-"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object p0
.end method

.method private static c(Landroid/content/pm/PackageInfo;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v0, "?"

    const-string v0, "?"

    const/4 v8, 0x4

    const-string v0, "?"

    const-string v0, "?"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz p0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v1, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v1, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    array-length v1, v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto/16 :goto_3

    :cond_0
    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v2, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v8, 0x0

    const/4 v7, 0x2

    array-length v2, v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    array-length v2, p0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v3, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-ge v4, v2, :cond_2

    const/4 v8, 0x2

    aget-object v5, p0, v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v5}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v6, v5}, Lcom/alipay/sdk/util/l;->l(Lx0/a;[B)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v6, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v5}, Lcom/alipay/sdk/util/l;->L(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v6, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v5, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_2

    :catchall_0
    :goto_1
    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    :goto_2
    :try_start_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v6, "-"

    const-string v6, "-"

    const/4 v8, 0x5

    const-string v6, "-"

    const-string v6, "-"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object p0

    :catchall_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object v0

    :cond_3
    :goto_3
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string p0, "0"

    const-string p0, "0"

    const/4 v8, 0x1

    const-string p0, "0"

    const-string p0, "0"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    return-object p0
.end method

.method private static e(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v0, "0b3m  u/"

    const-string v0, "b00 3/u "

    const/4 v7, 0x0

    const-string v0, " \u300b "

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-nez p0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v7, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v7, 0x1

    return-object p0

    :cond_0
    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    :try_start_0
    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const-string v2, ":"

    const-string v2, ":"

    const/4 v7, 0x5

    const-string v2, ":"

    const-string v2, ":"

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz p0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    array-length v2, p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    move v4, v3

    move v4, v3

    const/4 v7, 0x7

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-ge v3, v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    aget-object v5, p0, v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {v5}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v5, 0x5

    const/4 v7, 0x2

    if-le v4, v5, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    :cond_2
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object p0
.end method

.method private j()Z
    .locals 3

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method private static k()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v1, "ms::SmspHSSH"

    const/4 v4, 0x3

    const-string/jumbo v1, "sm::osSSmSH:"

    const-string v1, "HH:mm:ss:SSS"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method private static l(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v2}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3}, Lcom/alipay/sdk/util/b;->b()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v3}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->c(Landroid/content/Context;)Lcom/alipay/sdk/util/e;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v4}, Lcom/alipay/sdk/util/e;->c()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x3

    invoke-static {v4}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/alipay/sdk/util/b;->a(Landroid/content/Context;)Lcom/alipay/sdk/util/b;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/alipay/sdk/util/b;->d()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/16 v5, 0x9

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    aput-object v0, v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v0, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo v6, "qnroabd"

    const-string/jumbo v6, "iqronda"

    const/4 v8, 0x7

    const-string v6, "doiadnu"

    const-string v6, "android"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v6, v5, v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v0, 0x2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    aput-object v1, v5, v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v0, 0x3

    const/4 v7, 0x5

    move v8, v7

    aput-object v2, v5, v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v1, "-"

    const-string v1, "-"

    const/4 v8, 0x5

    const-string v1, "-"

    const-string v1, "-"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    aput-object v1, v5, v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v0, 0x5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    aput-object v3, v5, v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v0, 0x6

    const/4 v8, 0x5

    aput-object v4, v5, v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v0, 0x7

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string/jumbo v1, "wg"

    const-string v1, "gw"

    const-string/jumbo v1, "wg"

    const-string v1, "gw"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    aput-object v1, v5, v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/16 v0, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    aput-object p0, v5, v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo p0, "sss,s,%p,%ss%s,%,%%-ss,s%,,,"

    const-string/jumbo p0, "s,s,%%,%s,,,s%ssss,,,%%ss%%-"

    const/4 v8, 0x6

    const-string p0, "%s,%s,%s,%s,%s,%s,%s,%s,%s,-"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-object p0
.end method

.method private static m(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string p0, ""

    const/4 v3, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x1

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v0, "["

    const-string v0, "["

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, "03q/u0"

    const-string/jumbo v1, "\u3010"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, "]"

    const-string v0, "]"

    const-string v0, "]"

    const-string v0, "]"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "11s30u"

    const-string/jumbo v1, "u01m31"

    const/4 v3, 0x5

    const-string/jumbo v1, "u13m01"

    const-string/jumbo v1, "\u3011"

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v0, "("

    const-string v0, "("

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "\uff08"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v0, ")"

    const-string v0, ")"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "fu9/o0"

    const-string/jumbo v1, "\uff09"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, ","

    const-string v0, ","

    const-string v0, ","

    const-string v0, ","

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "0f/uob"

    const-string/jumbo v1, "u0ffo/"

    const/4 v3, 0x6

    const-string/jumbo v1, "u0/fuf"

    const-string/jumbo v1, "\uff0c"

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "^"

    const-string v0, "^"

    const/4 v3, 0x6

    const-string v0, "^"

    const-string v0, "^"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "~"

    const-string/jumbo v1, "~"

    const/4 v3, 0x0

    const-string/jumbo v1, "~"

    const-string/jumbo v1, "~"

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "#"

    const-string v0, "#"

    const/4 v3, 0x5

    const-string v0, "#"

    const-string v0, "#"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "3pfub/"

    const-string v1, "0/u3fb"

    const/4 v3, 0x1

    const-string v1, "f/q03u"

    const-string/jumbo v1, "\uff03"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0
.end method

.method private static o()Ljava/lang/String;
    .locals 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SimpleDateFormat"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "yHsMMysydHmsm:ud-:y"

    const-string v1, "MdyyMyu-ssy:-d:HHmm"

    const/4 v5, 0x0

    const-string v1, "Hy-m-dssymmy-dMy:HM"

    const-string/jumbo v1, "yyyy-MM-dd-HH:mm:ss"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v1, Ljava/util/Date;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/alipay/sdk/app/statistic/b;->r()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    aput-object v3, v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    aput-object v0, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v0, "ps,%o"

    const-string/jumbo v0, "ssp,%"

    const/4 v5, 0x1

    const-string v0, "bs%s%"

    const-string v0, "%s,%s"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method private static p(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const-string p0, "-"

    const-string p0, "-"

    const/4 v2, 0x4

    const-string p0, "-"

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method private declared-synchronized q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v0, "lspm"

    const-string/jumbo v0, "plms"

    const/4 v8, 0x3

    const-string/jumbo v0, "psml"

    const-string/jumbo v0, "mspl"

    const/4 v8, 0x6

    const-string/jumbo v1, "qs% s u e%r%"

    const-string/jumbo v1, "sse   %rq%%r"

    const/4 v8, 0x6

    const-string/jumbo v1, "r%%r espss% "

    const-string v1, "err %s %s %s"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v2, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    aput-object p1, v3, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v5, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object p2, v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    aput-object p3, v3, v6

    const/4 v8, 0x2

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;

    const/4 v8, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const-string v0, "^"

    const/4 v8, 0x2

    const-string v0, "^"

    const-string v0, "^"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    move v8, v7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v0, "%sss%,,%s,%"

    const/4 v8, 0x5

    const-string v0, "%s%s,,,%q%s"

    const-string v0, "%s,%s,%s,%s"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v3, 0x4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object p1, v3, v4

    const/4 v8, 0x7

    aput-object p2, v3, v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz p1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string p1, "-"

    const-string p1, "-"

    const/4 v8, 0x7

    const-string p1, "-"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p3}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    aput-object p1, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {}, Lcom/alipay/sdk/app/statistic/b;->k()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    aput-object p1, v3, v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object p3, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    monitor-exit p0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    monitor-exit p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    throw p1
.end method

.method private static r()Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0

    :catchall_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "1us6i357d4u2"

    const-string v0, "12345678uuid"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method private static s(Ljava/lang/String;)Ljava/lang/String;
    .locals 14

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    if-nez p0, :cond_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const-string v1, "&"

    const-string v1, "&"

    const-string v1, "&"

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz p0, :cond_7

    array-length v5, p0

    move v8, v3

    move v8, v3

    move v8, v3

    move v8, v3

    move-object v6, v4

    move-object v6, v4

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    :goto_0
    if-ge v8, v5, :cond_6

    aget-object v9, p0, v8

    const-string v10, "="

    const-string v10, "="

    const-string v10, "="

    const-string v10, "="

    invoke-virtual {v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_5

    array-length v10, v9

    if-ne v10, v1, :cond_5

    aget-object v10, v9, v3

    const-string/jumbo v11, "rpemmta"

    const-string/jumbo v11, "tapmrne"

    const-string/jumbo v11, "pnreoar"

    const-string/jumbo v11, "partner"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    const-string v11, "//"

    const-string v11, "\""

    if-eqz v10, :cond_1

    aget-object v4, v9, v2

    invoke-virtual {v4, v11, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_1
    aget-object v10, v9, v3

    const-string v12, "aoertbod_uno"

    const-string v12, "e_uaodtotonr"

    const-string/jumbo v12, "o_drauu_tetn"

    const-string/jumbo v12, "out_trade_no"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_2

    aget-object v6, v9, v2

    invoke-virtual {v6, v11, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_2
    aget-object v10, v9, v3

    const-string/jumbo v13, "n_dbteap"

    const-string v13, "datenbo_"

    const-string/jumbo v13, "qn_tador"

    const-string/jumbo v13, "trade_no"

    invoke-virtual {v10, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_3

    aget-object v7, v9, v2

    invoke-virtual {v7, v11, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_3
    aget-object v10, v9, v3

    const-string v11, "bnsoei_tztc"

    const-string v11, "biz_content"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_4

    :try_start_0
    invoke-static {}, Lx0/a;->f()Lx0/a;

    move-result-object v10

    aget-object v9, v9, v2

    invoke-static {v10, v9}, Lcom/alipay/sdk/util/l;->v(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_5

    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :cond_4
    aget-object v10, v9, v3

    const-string v11, "a_dmup"

    const-string/jumbo v11, "u_adpp"

    const-string/jumbo v11, "pdi_op"

    const-string v11, "app_id"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_5

    :try_start_1
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_5

    aget-object v4, v9, v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_5
    :goto_1
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_0

    :cond_6
    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    goto :goto_2

    :cond_7
    move-object p0, v4

    move-object p0, v4

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    :goto_2
    invoke-static {v4}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v6}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    aput-object v0, v5, v3

    aput-object v4, v5, v2

    aput-object p0, v5, v1

    const-string p0, "%-s-sb,s,-,-p,%,"

    const-string p0, ",%,-s,,p--s-%s%,"

    const-string p0, ",,%-,su-,,-%s%-s"

    const-string p0, "%s,%s,-,%s,-,-,-"

    invoke-static {p0, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private declared-synchronized t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const-string/jumbo v0, "mlps"

    const-string/jumbo v0, "lmsp"

    const/4 v9, 0x4

    const-string/jumbo v0, "mlsp"

    const-string/jumbo v0, "mspl"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string v1, "% se%n%p sevs "

    const-string v1, " nses %vq%es% "

    const/4 v9, 0x4

    const-string v1, "event %s %s %s"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v2, 0x3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    aput-object p1, v3, v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v5, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    aput-object p2, v3, v5

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x6

    aput-object p3, v3, v6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x5

    and-int/2addr v9, v8

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->h:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v1, :cond_0

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string v0, "^"

    const-string v0, "^"

    const/4 v9, 0x1

    const-string v0, "^"

    const-string v0, "^"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v0, "-s,--,ssq,,s,s,,,,,-,-%%-,%---%"

    const-string v0, ",%s%,,,-%-s,--%s-,s,,-,-,,s,--,"

    const/4 v9, 0x4

    const-string v0, ",,s,%-,--%-,sss-s--,,%-,%,,-,-,"

    const-string v0, "%s,%s,%s,-,-,-,-,-,-,-,-,-,-,%s"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v3, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v7, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string p1, "-"

    const-string p1, "-"

    const/4 v9, 0x4

    const-string p1, "-"

    const-string p1, "-"

    const/4 v9, 0x2

    goto :goto_0

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    aput-object p1, v3, v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p2}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    aput-object p1, v3, v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {p3}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    aput-object p1, v3, v6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {}, Lcom/alipay/sdk/app/statistic/b;->k()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    aput-object p1, v3, v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    iget-object p3, p0, Lcom/alipay/sdk/app/statistic/b;->h:Ljava/lang/String;

    const/4 v9, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->h:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    monitor-exit p0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x2

    monitor-exit p0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    throw p1
.end method

.method private static u()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/tid/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1}, Lx0/b;->f()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/alipay/sdk/app/statistic/b;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object v0, v2, v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    aput-object v1, v2, v0

    const-string/jumbo v0, "s%-m,s-m-,,"

    const-string v0, "-,%m-ss-,,,"

    const/4 v5, 0x4

    const-string v0, "-s%,os,--%,"

    const-string v0, "%s,%s,-,-,-"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object v0
.end method


# virtual methods
.method public d(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 v0, 0xa

    const/4 v4, 0x5

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/alipay/sdk/app/statistic/b;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object p1, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p1, 0x2

    const/4 v3, 0x2

    and-int/2addr v4, v3

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    aput-object v1, v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 p1, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->d:Ljava/lang/String;

    const/4 v4, 0x4

    aput-object v1, v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p1, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->e:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    aput-object v1, v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p1, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->f:Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v1, v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 p1, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->g:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    aput-object v1, v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->h:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-object p1, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/alipay/sdk/app/statistic/b;->i:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/alipay/sdk/app/statistic/b;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/16 v1, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    aput-object p1, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 p1, 0x9

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/statistic/b;->j:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    aput-object v1, v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string p1, "%,),(b%,s))%)ss,%%))%(s))(((%,[,)%s(s,s(),(,(%]ssos"

    const-string p1, "%(,,o%,s[s(,s))),%,%ss%))()))ss((%s%(%%%s(,),])(,s("

    const/4 v4, 0x0

    const-string p1, "[(%s),(%s),(%s),(%s),(%s),(%s),(%s),(%s),(%s),(%s)]"

    const/4 v3, 0x2

    move v4, v3

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object p1
.end method

.method f(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, v0, p1, p2}, Lcom/alipay/sdk/app/statistic/b;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p3}, Lcom/alipay/sdk/app/statistic/b;->e(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p3

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p3}, Lcom/alipay/sdk/app/statistic/b;->e(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string p4, ": "

    const-string p4, ": "

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo p2, "|"

    const-string/jumbo p2, "|"

    const/4 v2, 0x1

    const-string/jumbo p2, "|"

    const-string/jumbo p2, "|"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string p3, ""

    const-string p3, ""

    const/4 v2, 0x6

    const-string p3, ""

    const-string p3, ""

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p3, p1, p2}, Lcom/alipay/sdk/app/statistic/b;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
