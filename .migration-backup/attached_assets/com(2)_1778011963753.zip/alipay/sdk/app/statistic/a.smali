.class public Lcom/alipay/sdk/app/statistic/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/statistic/a$b;,
        Lcom/alipay/sdk/app/statistic/a$a;,
        Lcom/alipay/sdk/app/statistic/a$c;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s/i ~@K~o ~ ~@@ @  @b1~ i~ @@t-@~  i ~~omb @cMr ~@ @ot~~d~S@vfs~l4yn~l~ o~~ua~f@oo @~@@ @/@@b@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x2

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/app/statistic/a$b;->a(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    throw p0
.end method

.method public static declared-synchronized b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x4

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-enter v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p1, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Lcom/alipay/sdk/app/statistic/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, p1, p3}, Lcom/alipay/sdk/app/statistic/a$a;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :catchall_1
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    throw p0

    :cond_1
    :goto_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public static c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-nez p0, :cond_0

    const/4 v1, 0x2

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/alipay/sdk/app/statistic/b;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p0, :cond_0

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x6

    return-void
.end method

.method public static e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    if-nez p0, :cond_0

    const/4 v0, 0x3

    move v1, v0

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static f(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    if-nez p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/alipay/sdk/app/statistic/b;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static g(Lx0/a;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0, p2}, Lcom/alipay/sdk/app/statistic/b;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public static declared-synchronized h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x5

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const-class v0, Lcom/alipay/sdk/app/statistic/a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    monitor-enter v0

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v2, 0x7

    iget-object p1, p1, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/a$b;->b(Landroid/content/Context;Lcom/alipay/sdk/app/statistic/b;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    throw p0

    :cond_1
    :goto_0
    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public static i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-nez p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lx0/a;->i:Lcom/alipay/sdk/app/statistic/b;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/alipay/sdk/app/statistic/b;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method
