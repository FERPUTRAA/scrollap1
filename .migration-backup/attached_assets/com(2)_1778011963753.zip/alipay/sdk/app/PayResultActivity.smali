.class public final Lcom/alipay/sdk/app/PayResultActivity;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/PayResultActivity$b;
    }
.end annotation


# static fields
.field public static final b:Ljava/lang/String; = "{\"isLogin\":\"false\"}"

.field public static final c:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "hk.alipay.wallet"

.field public static final e:Ljava/lang/String; = "phonecashier.pay.hash"

.field public static final f:Ljava/lang/String; = "orderSuffix"

.field public static final g:Ljava/lang/String; = "externalPkgName"

.field public static final h:Ljava/lang/String; = "phonecashier.pay.result"

.field public static final i:Ljava/lang/String; = "phonecashier.pay.resultOrderHash"


# instance fields
.field private a:Lx0/a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    sput-object v0, Lcom/alipay/sdk/app/PayResultActivity;->c:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/alipay/sdk/app/PayResultActivity;->a:Lx0/a;

    const/4 v2, 0x3

    return-void
.end method

.method private static a(Landroid/app/Activity;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " dsi~ @@~@ -@ob@ i1~~4~ ~K@/ s ~~Sy@@ @t~.@ ~@~o ~~@~~/M~~r l~@ nio@cob~v ba@ o@u @fo~ t~fl@m@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v1, Lcom/alipay/sdk/app/PayResultActivity$a;

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/alipay/sdk/app/PayResultActivity$a;-><init>(Landroid/app/Activity;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    int-to-long p0, p1

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private static b(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, "-8TmF"

    const-string v0, "8TsF-"

    const/4 v5, 0x7

    const-string v0, "-8UTo"

    const-string v0, "UTF-8"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    :try_start_0
    const/4 v5, 0x3

    const-string v2, "aw.labaikel.htly"

    const-string v2, "hk.alipay.wallet"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v3, "li/ar/unA?50p0atlkhsI0Srpopisay2=&tp/se2cmmpf0ePhyasa1dptae:apim"

    const-string/jumbo v3, "tafmap2Spo&/a0loI=ltiysic/rp/sr0ph0s52edaA1hpmanp?epsitaPmya0k:e"

    const-string/jumbo v3, "otm01s2p/Saoc0PphlfppA=sye:2/0ppdeysair?tIaleatmkasi0p&p5anai=r/"

    const-string v3, "alipayhk://platformapi/startApp?appId=20000125&schemePaySession="

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const-string/jumbo p1, "ufSxfrr=qe&oo"

    const-string p1, "eS=forx&ofrui"

    const/4 v5, 0x4

    const-string/jumbo p1, "ros=&ffieSrux"

    const-string p1, "&orderSuffix="

    const/4 v4, 0x0

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-static {p2, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p1, "peamkeb&ama=g"

    const-string/jumbo p1, "peamabk=a&geN"

    const/4 v5, 0x2

    const-string/jumbo p1, "ma&po=cagakNe"

    const-string p1, "&packageName="

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p3, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p1, "nx&kebtamP=gelaNe"

    const-string p1, "&externalPkgName="

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p3, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p0, :cond_0

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_1

    :catchall_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method private static c(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lcom/alipay/sdk/app/PayResultActivity$b;->b:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/alipay/sdk/app/PayResultActivity;->c:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0, p0}, Lcom/alipay/sdk/app/PayResultActivity;->e(Ljava/util/HashMap;Ljava/lang/String;)Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method private static d(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    sput-object p0, Lcom/alipay/sdk/app/PayResultActivity$b;->b:Ljava/lang/String;

    const/4 v0, 0x5

    const/4 v1, 0x1

    sget-object p0, Lcom/alipay/sdk/app/PayResultActivity;->c:Ljava/util/HashMap;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/alipay/sdk/app/PayResultActivity;->e(Ljava/util/HashMap;Ljava/lang/String;)Z

    const/4 v1, 0x6

    return-void
.end method

.method private static e(Ljava/util/HashMap;Ljava/lang/String;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    return v0

    :cond_1
    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1

    :cond_2
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v0, "droeffuSruu"

    const-string/jumbo v0, "oreidSuuffr"

    const/4 v7, 0x2

    const-string v0, "fofexriprud"

    const-string/jumbo v0, "orderSuffix"

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    xor-int/lit8 v1, v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 v2, 0x12c

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v1, :cond_1

    const/4 v7, 0x3

    const-string/jumbo v1, "pshche..qsyiaanrpaeho"

    const-string v1, ".n.haheperchhoapsaiys"

    const/4 v7, 0x2

    const-string/jumbo v1, "srshs.npiphyaea.ohhae"

    const-string/jumbo v1, "phonecashier.pay.hash"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    sput-object v1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v1, "PxmmeltekrneqNa"

    const-string/jumbo v1, "rxaenemlqetNkPa"

    const/4 v7, 0x3

    const-string v1, "gxnaoeeeratmkNl"

    const-string v1, "externalPkgName"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p1}, Lx0/a$a;->a(Landroid/content/Intent;)Lx0/a;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/alipay/sdk/app/PayResultActivity;->a:Lx0/a;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    sget-object p1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p0, p1, v0, v1}, Lcom/alipay/sdk/app/PayResultActivity;->b(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p0, v2}, Lcom/alipay/sdk/app/PayResultActivity;->a(Landroid/app/Activity;I)V

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/app/PayResultActivity;->a:Lx0/a;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-nez v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_2
    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v0, "euripbserscy.ps.ethaaln"

    const-string v0, "e.sorpauslepnreyticsh.a"

    const/4 v7, 0x7

    const-string/jumbo v0, "ural.yuoepitcshsanep.he"

    const-string/jumbo v0, "phonecashier.pay.result"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v1, "sr.mHaa.orsrnehyaeruOhthieclspep"

    const-string v1, "hrrc.hypdnsrietuhOoeaesesaalprp."

    const-string/jumbo v1, "phonecashier.pay.resultOrderHash"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v3, 0x0

    and-int/2addr v7, v3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    if-eqz p1, :cond_5

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    sget-object v1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v1, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v1, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez p1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object p1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v0, p1}, Lcom/alipay/sdk/app/PayResultActivity;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto :goto_0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object p1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/app/PayResultActivity;->c(Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    sput-object p1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p0, v2}, Lcom/alipay/sdk/app/PayResultActivity;->a(Landroid/app/Activity;I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void

    :cond_5
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/app/PayResultActivity;->a:Lx0/a;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v1, "bzi"

    const-string/jumbo v1, "zib"

    const/4 v7, 0x5

    const-string/jumbo v1, "izb"

    const-string v1, "biz"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v3, "shgnWeSaqoPeyoxrmchE"

    const-string v3, "exSsonoregmchaPEayWh"

    const/4 v7, 0x6

    const-string v3, "aEsoxrahecSHWngsyehP"

    const-string v3, "SchemePayWrongHashEx"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    or-int/2addr v7, v6

    const-string v5, "eedmbtEcp"

    const-string v5, "dEeepbtxc"

    const/4 v7, 0x6

    const-string/jumbo v5, "t Edocepx"

    const-string v5, "Expected "

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object v5, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v5, " o,tgb"

    const-string/jumbo v5, "u,og t"

    const/4 v7, 0x4

    const-string/jumbo v5, "u,ogt "

    const-string v5, ", got "

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v0, v1, v3, p1}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object p1, Lcom/alipay/sdk/app/PayResultActivity$b;->a:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/alipay/sdk/app/PayResultActivity;->c(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p0, v2}, Lcom/alipay/sdk/app/PayResultActivity;->a(Landroid/app/Activity;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-void

    :catchall_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void
.end method
