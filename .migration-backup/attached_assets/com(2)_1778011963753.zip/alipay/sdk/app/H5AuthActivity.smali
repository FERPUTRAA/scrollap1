.class public Lcom/alipay/sdk/app/H5AuthActivity;
.super Lcom/alipay/sdk/app/H5PayActivity;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/alipay/sdk/app/H5PayActivity;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @snb~~K ~1~  ~~b~Mt@@@  S@ o~~~ @r f~4@@~.-~@/~@i@@l~@l~@oyos@fma vt~  b ouo~@/@i @ ~  i@od~@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/sdk/app/AuthTask;->c:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->notify()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_1

    :catch_0
    :goto_0
    :try_start_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw v1
.end method
