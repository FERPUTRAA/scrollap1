.class Lcom/alipay/sdk/app/PayTask$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/app/PayTask;->payInterceptorWithUrl(Ljava/lang/String;ZLcom/alipay/sdk/app/H5PayCallback;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Z

.field final synthetic c:Lcom/alipay/sdk/app/H5PayCallback;

.field final synthetic d:Lcom/alipay/sdk/app/PayTask;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/app/PayTask;Ljava/lang/String;ZLcom/alipay/sdk/app/H5PayCallback;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$a;->d:Lcom/alipay/sdk/app/PayTask;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/alipay/sdk/app/PayTask$a;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-boolean p3, p0, Lcom/alipay/sdk/app/PayTask$a;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/alipay/sdk/app/PayTask$a;->c:Lcom/alipay/sdk/app/H5PayCallback;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ys~f@@v~~iu ~~l@ ~ot~K @ S tc-oo@@@@M@o ~ia@ br o~~4@~ .1 @ ~l~~~i@m~~f@~b s  / ~o@/@@dn@ ~ @b~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    new-instance v0, Lx0/a;

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask$a;->d:Lcom/alipay/sdk/app/PayTask;

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    invoke-static {v1}, Lcom/alipay/sdk/app/PayTask;->a(Lcom/alipay/sdk/app/PayTask;)Landroid/app/Activity;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/app/PayTask$a;->a:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo v3, "lprmiaptenttsUWIrhyce"

    const-string/jumbo v3, "restpatoyWniUhtcplreI"

    const/4 v5, 0x6

    const-string/jumbo v3, "oeWlornhetirIratycppU"

    const-string/jumbo v3, "payInterceptorWithUrl"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v0, v1, v2, v3}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask$a;->d:Lcom/alipay/sdk/app/PayTask;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/alipay/sdk/app/PayTask$a;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-boolean v3, p0, Lcom/alipay/sdk/app/PayTask$a;->b:Z

    invoke-virtual {v1, v0, v2, v3}, Lcom/alipay/sdk/app/PayTask;->h5Pay(Lx0/a;Ljava/lang/String;Z)Lcom/alipay/sdk/util/a;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string/jumbo v2, "micfdbniiseh: "

    const-string v2, "cn mfdi i:sieh"

    const/4 v5, 0x0

    const-string v2, "f:hdsiui i nnc"

    const-string/jumbo v2, "inc finished: "

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/alipay/sdk/util/a;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v2, "lpms"

    const-string/jumbo v2, "lspm"

    const/4 v5, 0x4

    const-string/jumbo v2, "mspl"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v2, v1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask$a;->c:Lcom/alipay/sdk/app/H5PayCallback;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v1, v0}, Lcom/alipay/sdk/app/H5PayCallback;->onPayResult(Lcom/alipay/sdk/util/a;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-void
.end method
