.class Lcom/alipay/sdk/app/AuthTask$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/sdk/util/f$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/app/AuthTask;->a()Lcom/alipay/sdk/util/f$d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/alipay/sdk/app/AuthTask;


# direct methods
.method constructor <init>(Lcom/alipay/sdk/app/AuthTask;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/AuthTask$a;->a:Lcom/alipay/sdk/app/AuthTask;

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@cs~@M/@s~~ ~@d~ @@l@a~o@ ~.~@i@b@m@ f~l u~o~@@b@~ vo  @~b   K~~t ~-Sr~4 ~~@yt@o 1n@/io~io~@ f  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask$a;->a:Lcom/alipay/sdk/app/AuthTask;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/app/AuthTask;->d(Lcom/alipay/sdk/app/AuthTask;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
