.class public Lcom/alipay/sdk/app/c;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""

.field private static final b:Lcom/alipay/sdk/data/a$b;

.field private static final c:Lcom/alipay/sdk/data/a$b;

.field public static d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v0, Lcom/alipay/sdk/data/a$b;

    const/4 v6, 0x7

    const/16 v1, 0x49

    const/4 v5, 0x3

    move v6, v5

    const-string v2, "b9sc07a05d945476a336246cda3f97bdca1be78fafd03b6050248f6feb77eae73c25ea5658b20aeefff61c0d74002103a62457f03c12a959bf48d64a2a4e4caa889c1aa844e212a6d7d0e89a89f0e69c2148cc6aedb2632e90d1b26efe03495499bc91fddb27907s81b259061a8609265dd88fcb8b61958abcc77cd87db6a227"

    const-string v2, "39s49769112a4dc2d65faa8dc05671e0d2dfa414f65b8b32a0fb8784b0c3d5482f28c94eed9d2cda438f9887d279ef257f0bf00c763f18bf5a96d096ae61cae986c8466a6409e0a684adb24972936a116dec7bca5f1e83ba5e72cfaae0a220472c1729ea8b9be300be22ccc17a253c687105650a8b7f620e75ba096d4db9bd49"

    const/4 v6, 0x2

    const-string v2, "bcam2b4d21d386caddfbaa0498dc856f3bebce2790964ddfc70cfa6002f878a9aa647258991bc2320c2ae2e4bd86a0a96954012e2061dd9097f82ae15350e91b1e7af660b4b6774066aec7b679f17d54aebf222d5fb4a8b1e74124eb5da549c62741ded03f9e896a0325663c879f6a37a8fce85890cc20fbd82a1ac9847c305f"

    const-string v2, "b6cbad6cbd5ed0d209afc69ad3b7a617efaae9b3c47eabe0be42d924936fa78c8001b1fd74b079e5ff9690061dacfa4768e981a526b9ca77156ca36251cf2f906d105481374998a7e6e6e18f75ca98b8ed2eaf86ff402c874cca0a263053f22237858206867d210020daa38c48b20cc9dfd82b44a51aeb5db459b22794e2d649"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "m.Aiod..oraeaGnmghpidnoeyop"

    const-string/jumbo v3, "phpmGnono.aiogdarA.ycied.me"

    const/4 v6, 0x3

    const-string v3, ".pcmiboln.ypageAhdd.oiGearo"

    const-string v3, "com.eg.android.AlipayGphone"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v0, v3, v1, v2}, Lcom/alipay/sdk/data/a$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    sput-object v0, Lcom/alipay/sdk/app/c;->b:Lcom/alipay/sdk/data/a$b;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v1, Lcom/alipay/sdk/data/a$b;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/16 v2, 0x28

    const/4 v6, 0x5

    const-string v3, "99b942u696808b80a4b79be03a72cfdd51fdd29a35bc97627f91070f73e1d3c00948273af1a472069dfc6d19e3f46ec969d3b6325f8aa54f7c40bcd62a13f9df7610c6f97323970a9671917bd0f01509f5081fad81a6a1a129ea1c30e3ad1657a4846d0ed7aeede6f7116ab4839168c6a3f8dab7e0739d9c08738f6856264467df71e1711a5f86cbc015ef6bdd9039b5397b0b0080bb2eedb150839793ddd8dd1c72428612f7da641fedb4857fd5d807adb010ab708fe56c16bef679447ba900bee75326db9984beddaee610404480a2b44b6dc6f4b15a33669d25835eb217918ff14cee8843f70c8215b45778485cbde81737d9c75a3ob90cf4479351bcbd47"

    const-string v3, "8e96o84ce1bd9f0970fa1d8393d440f2d717b7d628036b4512b126fb66d6cefbba50b4b27fd185a16ddf7d168b455f858fdc9a86a434f6dc19ff259e6618db8319c3ef7bbec6161e14707fb96a0f2cedfdb69b1996a1981b40b3d1e1d2eaf47e73eb63e2b0b477349be096e63bebe9b700c39d31861dcb73793925f73fd2b574c00bc6d23c87471997b0456d9445fe8a30cf8d6096415ae8d05a03895c297316d1116d4fa372d78a0c12f5d8408c870c1d9b95515189afa4efa125ba0758a09761634ada0de30d93d1e7a87e34148004e9f6d6804a8d4d76cf99a7f5a8a037150a078004d73ef4732b91d6aeb6062c78977779ae0db7c52ca2835df149f1b07c"

    const-string v3, "0cf1b1ap6ed8a832918b5557a8d1e926f7188df61e6bec791d6d614088a360c305017406226db708ae5de635963d9f810f627b107d6dcfbe8117194630426ae877c2099037b0c78856974571cafddf195f8f3032fdaa83765a48f7c08d4e41679cdaad1392b9140d9626c73e80732a920d41f571d3ffaea80dd063f9f33344ba9a1d782d456dc406cd08ea4884f636b66e13033bf92cee4111d7e44f96bcd19d457b764d89b162bf703377579bd198c7ce94b4748a7f95a679191b83e0b0c460e6175f699429f3c57430a0579df81b17e0ebb9bfd04d796d4aaab49b8a5bb1001ed2b3f9b9c1bfb1afc7960e2ed705a758812aed03bdab520effbb74e557dcfd"

    const-string v3, "e6b1bdcb890370f2f2419fe06d0fdf7628ad0083d52da1ecfe991164711bbf9297e75353de96f1740695d07610567b1240549af9cbd87d06919ac31c859ad37ab6907c311b4756e1e208775989a4f691bff4bbbc58174d2a96b1d0d970a05114d7ee57dfc33b1bafaf6e0d820e838427018b6435f903df04ba7fd34d73f843df9434b164e0220baabb10c8978c3f4c6b7da79d8220a968356d15090dea07df9606f665cbec14d218dd3d691cce2866a58840971b6a57b76af88b1a65fdffd2c080281a6ab20be5879e0330eb7ff70871ce684e7174ada5dc3159c461375a0796b17ce7beca83cf34f65976d237aee993db48d34a4e344f4d8b7e99119168bdd7"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v4, "eaaiyhllqapbk.tl"

    const-string/jumbo v4, "teiapbyalwhl.lka"

    const/4 v6, 0x5

    const-string/jumbo v4, "kws.aahell.alypi"

    const-string v4, "hk.alipay.wallet"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v1, v4, v2, v3}, Lcom/alipay/sdk/data/a$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v6, 0x1

    sput-object v1, Lcom/alipay/sdk/app/c;->c:Lcom/alipay/sdk/data/a$b;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "r@ mib f@@  /ta@~  ~~@n ~1d@~iu ~@ ~ b@~y~~S ~ @~~~t@svi~~@bK@~@o  o.~@o~@ mc o~~o@4Mfol/@~l@@@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/alipay/sdk/app/c;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public static b(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object p0, Lcom/alipay/sdk/app/c;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo v0, "kh"

    const-string/jumbo v0, "kh"

    const/4 v2, 0x4

    const-string v0, "hk"

    const-string v0, "hk"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object p0, Lcom/alipay/sdk/app/c;->b:Lcom/alipay/sdk/data/a$b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object p0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object p0, Lcom/alipay/sdk/app/c;->c:Lcom/alipay/sdk/data/a$b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    sput-object p0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    :goto_0
    const/4 v2, 0x7

    return-void
.end method

.method public static c()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/sdk/app/c;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    const-string/jumbo v0, "nc"

    const-string/jumbo v0, "nc"

    const/4 v3, 0x3

    const-string v0, "cn"

    const-string v0, "cn"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v1, Lcom/alipay/sdk/app/c;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v0
.end method
