.class public Lcom/alipay/sdk/app/AlipayResultActivity;
.super Landroid/app/Activity;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/AlipayResultActivity$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Lcom/alipay/sdk/app/AlipayResultActivity$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/alipay/sdk/app/AlipayResultActivity;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private a(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s~@ol~  b4t l@@ @vc~~o s@r~@ b~S@~~a/~i~ @@@K@nu~o@ff~t~ ~@~@b  @~1o @~o@-~ oim @/yM   d ~~i~."

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    sget-object v0, Lcom/alipay/sdk/app/AlipayResultActivity;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast p1, Lcom/alipay/sdk/app/AlipayResultActivity$a;

    const/4 v4, 0x2

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v0, "edomesC"

    const-string v0, "doseenC"

    const/4 v4, 0x1

    const-string v0, "dnoCoed"

    const-string v0, "endCode"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v1, "memo"

    const-string/jumbo v1, "moem"

    const/4 v4, 0x2

    const-string/jumbo v1, "mmeo"

    const-string/jumbo v1, "memo"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v2, "umrltb"

    const-string/jumbo v2, "teumrl"

    const/4 v4, 0x0

    const-string/jumbo v2, "uuetsl"

    const-string/jumbo v2, "result"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p1, v0, v1, p2}, Lcom/alipay/sdk/app/AlipayResultActivity$a;->a(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    throw p1
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 14

    const/4 v13, 0x5

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v13, 0x3

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x0

    const-string/jumbo v1, "oplreu"

    const-string/jumbo v1, "suelor"

    const/4 v13, 0x2

    const-string/jumbo v1, "srqtle"

    const-string/jumbo v1, "result"

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x0

    const-string/jumbo v2, "oesnibs"

    const-string/jumbo v2, "snoisbe"

    const/4 v13, 0x1

    const-string/jumbo v2, "niemsso"

    const-string/jumbo v2, "session"

    const/4 v12, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    const-string/jumbo v3, "izb"

    const-string v3, "biz"

    const/4 v13, 0x4

    const-string/jumbo v3, "zib"

    const-string v3, "biz"

    const/4 v12, 0x7

    move v13, v12

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x1

    const/4 v4, 0x0

    :try_start_1
    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v6

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x0

    const-string/jumbo v7, "uceno"

    const-string v7, "cusen"

    const/4 v13, 0x5

    const-string v7, "bensc"

    const-string/jumbo v7, "scene"

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {p1, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x2

    const/4 v12, 0x2

    invoke-static {v5}, Lx0/a$a;->b(Ljava/lang/String;)Lx0/a;

    move-result-object v4

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    if-nez v4, :cond_0

    const/4 v13, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x6

    return-void

    :cond_0
    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x2

    const-string v8, "iBPnSsusop"

    const-string v8, "SPinosBpsS"

    const/4 v13, 0x5

    const-string/jumbo v8, "oSiBPnspse"

    const-string v8, "BSPSession"

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x4

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x6

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v4, v3, v8, v9}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x1

    const-string/jumbo v8, "ypqemcPmqSae"

    const-string v8, "eaPmmyqpqecS"

    const/4 v13, 0x6

    const-string v8, "aSsecpmqyPeh"

    const-string/jumbo v8, "mqpSchemePay"

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-static {v8, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-eqz v7, :cond_1

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-direct {p0, v5, v6}, Lcom/alipay/sdk/app/AlipayResultActivity;->a(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    return-void

    :cond_1
    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    if-nez v7, :cond_2

    const/4 v13, 0x1

    if-nez v6, :cond_4

    :cond_2
    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x3

    if-eqz v7, :cond_4

    :try_start_3
    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-virtual {p1}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x2

    new-instance v7, Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/4 v8, 0x2

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {p1, v8}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x7

    const-string v8, "UTsm8"

    const-string v8, "UTs8-"

    const/4 v13, 0x3

    const-string v8, "-TF8o"

    const-string v8, "UTF-8"

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-direct {v7, p1, v8}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    new-instance p1, Lorg/json/JSONObject;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-direct {p1, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x5

    const-string p1, "PsSiUbBrSnsme"

    const-string/jumbo p1, "sBrmUnsSoeSPi"

    const/4 v13, 0x4

    const-string p1, "SSUoiBuirnssP"

    const-string p1, "BSPUriSession"

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-static {v4, v3, p1, v5}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x5

    new-instance p1, Landroid/os/Bundle;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    const/4 v13, 0x3

    invoke-virtual {v1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    if-eqz v6, :cond_3

    const/4 v13, 0x3

    const/4 v12, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x6

    check-cast v6, Ljava/lang/String;

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x3

    const/4 v12, 0x3

    invoke-virtual {p1, v6, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x5

    goto :goto_0

    :cond_3
    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    goto :goto_2

    :catchall_0
    move-exception v1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_1

    :catchall_1
    move-exception v1

    :goto_1
    :try_start_5
    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    const-string p1, "SEBPoRse"

    const/4 v13, 0x2

    const-string p1, "PeERsBSp"

    const-string p1, "BSPResEx"

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-static {v4, v3, p1, v1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x0

    const-string/jumbo p1, "reemuroyqeEarbQshSPer"

    const-string/jumbo p1, "ohSmebersyQrrEeerruPa"

    const/4 v13, 0x5

    const-string/jumbo p1, "rhsESmoPrercersreaQye"

    const-string p1, "ParseSchemeQueryError"

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-static {v4, v3, p1, v1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_4
    :goto_2
    const/4 v13, 0x1

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v13, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x4

    if-nez p1, :cond_6

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x7

    if-nez v6, :cond_5

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x0

    goto/16 :goto_3

    :cond_5
    :try_start_6
    const/4 v13, 0x2

    const-string p1, "PgReturn"

    const/4 v13, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v2, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-static {v4, v3, p1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x0

    const-string p1, "erPmuRgnu"

    const-string p1, "RgeunVuPr"

    const/4 v13, 0x1

    const-string p1, "VurtoPRgn"

    const-string p1, "PgReturnV"

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    const-string v7, "Cdneobp"

    const-string/jumbo v7, "pnCedod"

    const/4 v13, 0x1

    const-string v7, "eCdnoeu"

    const-string v7, "endCode"

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v8, -0x1

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v6, v7, v8}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v7

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    const-string/jumbo v0, "moem"

    const/4 v13, 0x4

    const-string/jumbo v0, "memo"

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    const-string v7, "-"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v6, v0, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-static {v4, v3, p1, v0}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x4

    const-string p1, "KO"

    const-string p1, "OK"

    const/4 v13, 0x5

    const-string p1, "KO"

    const-string p1, "OK"

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    const/16 v0, 0x2328

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-static {v5, v0, p1, v6}, Lcom/alipay/sdk/app/b;->d(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x2

    iget-object p1, v4, Lx0/a;->d:Ljava/lang/String;

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-static {p0, v4, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v13, 0x3

    goto :goto_4

    :catchall_2
    move-exception p1

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x7

    iget-object v0, v4, Lx0/a;->d:Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-static {p0, v4, v1, v0}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x5

    throw p1

    :cond_6
    :goto_3
    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x6

    iget-object p1, v4, Lx0/a;->d:Ljava/lang/String;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-static {p0, v4, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    goto :goto_4

    :catchall_3
    move-exception p1

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x5

    const-string v0, "PeSrBqrprSr"

    const-string/jumbo v0, "rPrrrSBeqSE"

    const/4 v13, 0x1

    const-string/jumbo v0, "rBrSoSreqEr"

    const-string v0, "BSPSerError"

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-static {v4, v3, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x7

    const-string/jumbo v0, "iasesdiabrSnurerserllaerEPoB"

    const-string/jumbo v0, "lasBeridnleoPrrbEeraaeluriSs"

    const/4 v13, 0x4

    const-string/jumbo v0, "ziimlleuBsrodrlerEnaPreSbaar"

    const-string v0, "ParseBundleSerializableError"

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-static {v4, v3, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    return-void

    :catchall_4
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_4
    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x4

    return-void
.end method
