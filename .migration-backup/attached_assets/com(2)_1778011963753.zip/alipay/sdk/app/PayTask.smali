.class public Lcom/alipay/sdk/app/PayTask;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/PayTask$c;
    }
.end annotation


# static fields
.field static final h:Ljava/lang/Object;

.field private static i:J = 0x0L

.field private static final j:J = 0xbb8L

.field private static k:J = -0x1L


# instance fields
.field private a:Landroid/app/Activity;

.field private b:Lcom/alipay/sdk/widget/a;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;

.field private g:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/alipay/sdk/app/PayTask$c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/sdk/util/f;

    const-class v0, Lcom/alipay/sdk/util/f;

    const/4 v2, 0x7

    const-class v0, Lcom/alipay/sdk/util/f;

    const-class v0, Lcom/alipay/sdk/util/f;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Lcom/alipay/sdk/app/PayTask;->h:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "..stecasmrp.prioehwacwlvse/gytpmsiya"

    const-string v0, "gpswa.vs.h/coiamyp.tycaslpeemtiwrare"

    const/4 v3, 0x0

    const-string/jumbo v0, "wmemmigtpasaw..ialsca/cpvytyhpe.reor"

    const-string/jumbo v0, "wappaygw.alipay.com/service/rest.htm"

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->c:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "cenmoiatorsi.ecaypcrmtm/ivh.e/t.ell"

    const-string/jumbo v0, "mclient.alipay.com/service/rest.htm"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const-string/jumbo v0, "toe.ebachmg.tncoeans.pAmymi/ixrchfsemlmaei/"

    const-string v0, ".mim.rtfopcemiehg//nsnymescilemoaxaAha.ltce"

    const/4 v3, 0x7

    const-string/jumbo v0, "le.l./ufss.emonnott/aehmpmiremcycicgxeihaat"

    const-string/jumbo v0, "mclient.alipay.com/home/exterfaceAssign.htm"

    const/4 v3, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->e:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "my.ahscpcal/eitepbioh.mipmt/clnoaylrima."

    const-string v0, "aet.occyhpcpsr.tialeim.moll/ynebmaihma/i"

    const/4 v3, 0x2

    const-string/jumbo v0, "mclient.alipay.com/cashier/mobilepay.htm"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->f:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->g:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lcom/alipay/sdk/widget/a;

    const/4 v3, 0x7

    const-string v1, "6b5ub/84q9b4/5/bud/5/efbue/uuu2dd683"

    const-string v1, "68eu8be3d//du5df4e5bu/4u//ubb295u/6b"

    const/4 v3, 0x4

    const-string v1, "8usb45533ebde/u/bu6uf269ue//4udd5/8b"

    const-string/jumbo v1, "\u53bb\u652f\u4ed8\u5b9d\u4ed8\u6b3e"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, p1, v1}, Lcom/alipay/sdk/widget/a;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic a(Lcom/alipay/sdk/app/PayTask;)Landroid/app/Activity;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "loKm~a @ @~b@~@v no b~ o1~m o.@4~~@ @@@@  -/~t/  ~@@yt~@  SMlico o@@~u sdi~~~f@~b~~r@ ~ @@i~f~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method private b()Lcom/alipay/sdk/util/f$d;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    new-instance v0, Lcom/alipay/sdk/app/PayTask$b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/alipay/sdk/app/PayTask$b;-><init>(Lcom/alipay/sdk/app/PayTask;)V

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return-object v0
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string p2, "={"

    const-string p2, "={"

    const/4 v2, 0x5

    const-string p2, "={"

    const-string p2, "={"

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    add-int/2addr v0, p2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo p2, "}"

    const-string/jumbo p2, "}"

    const/4 v2, 0x3

    const-string/jumbo p2, "}"

    const-string/jumbo p2, "}"

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, v0, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p1
.end method

.method private d(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string/jumbo v0, "tuuroStatues"

    const-string v0, "atusruutlteS"

    const/4 v11, 0x2

    const-string/jumbo v0, "tetulburSsst"

    const-string/jumbo v0, "resultStatus"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string v1, "0900"

    const-string v1, "9000"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string/jumbo v1, "ulptes"

    const-string v1, "eplrts"

    const/4 v11, 0x6

    const-string/jumbo v1, "result"

    const/4 v10, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {p2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/app/PayTask;->g:Ljava/util/Map;

    const/4 v10, 0x4

    shl-int/2addr v11, v10

    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    check-cast p1, Lcom/alipay/sdk/app/PayTask$c;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v2, 0x2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x1

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-eqz p1, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p1}, Lcom/alipay/sdk/app/PayTask$c;->c()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x2

    const/4 v10, 0x3

    goto :goto_0

    :cond_0
    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v5, 0x0

    const/4 v11, 0x4

    aput-object v4, v2, v5

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz p1, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p1}, Lcom/alipay/sdk/app/PayTask$c;->g()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    goto :goto_1

    :cond_1
    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v5, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    aput-object v4, v2, v5

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v2}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-string/jumbo v2, "lkarclUpqBc"

    const-string/jumbo v2, "raBaUlckqlc"

    const-string v2, "acllrcakqUB"

    const-string v2, "callBackUrl"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {p2, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eqz v4, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-interface {p2, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x4

    return-object p1

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/16 v2, 0xf

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-le p2, v2, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string/jumbo p2, "kasca&/slU=l/cl"

    const-string/jumbo p2, "l&slaccl/kUaB=/"

    const/4 v11, 0x0

    const-string p2, "&rBmcl/=/claklU"

    const-string p2, "&callBackUrl=\""

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v2, "//"

    const-string v2, "//"

    const/4 v11, 0x4

    const-string v2, "//"

    const-string v2, "\""

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p2, v2, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const-string p2, "_b&mol_/allucrk/="

    const-string p2, "bllm_c/cul_ak&=/r"

    const/4 v11, 0x4

    const-string p2, "c/&lub_a=_b/lrklc"

    const-string p2, "&call_back_url=\""

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {p2, v2, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string p2, "_&ltrnur=//uue"

    const-string/jumbo p2, "rurto_&l//nu=e"

    const/4 v11, 0x1

    const-string p2, "&/=rt/epnr_ulu"

    const-string p2, "&return_url=\""

    const/4 v10, 0x6

    invoke-static {p2, v2, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string/jumbo p2, "n=t_&brequur"

    const-string p2, "=rrtnbluue&_"

    const/4 v11, 0x7

    const-string p2, "&usr=l_retun"

    const-string p2, "&return_url="

    const/4 v10, 0x1

    move v11, v10

    const-string v7, "&"

    const/4 v11, 0x4

    const-string v7, "&"

    const/4 v10, 0x1

    shr-int/2addr v11, v10

    invoke-static {p2, v7, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string/jumbo v8, "ut-mu"

    const-string/jumbo v8, "tu-uf"

    const/4 v11, 0x2

    const-string v8, "8-tfo"

    const-string/jumbo v8, "utf-8"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {p2, v8}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string/jumbo v9, "lB=labcUr&pck"

    const-string v9, "&k=lrcBplcUla"

    const/4 v11, 0x1

    const-string v9, "allrccuBU=lka"

    const-string v9, "&callBackUrl="

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v9, v7, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v7, v8}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string v7, "/lau/l=pklcr_a_q"

    const-string v7, "_clak=luq_lc//ar"

    const/4 v11, 0x5

    const-string/jumbo v7, "krl=/a__q/ucclbl"

    const-string v7, "call_back_url=\""

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v7, v2, v1}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v7, p2

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    filled-new-array/range {v4 .. v9}, [Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {p2}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-nez v1, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    return-object p2

    :cond_3
    const/4 v11, 0x1

    const/4 v10, 0x7

    if-eqz p1, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v0, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p1}, Lcom/alipay/sdk/app/PayTask$c;->a()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    goto :goto_2

    :cond_4
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {p1}, Lcom/alipay/sdk/app/PayTask$c;->e()Ljava/lang/String;

    move-result-object p2

    :goto_2
    const/4 v11, 0x3

    const/4 v10, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-nez v0, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    return-object p2

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-eqz p1, :cond_6

    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1}, Lcom/alipay/sdk/data/a;->m()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    return-object p1

    :cond_6
    const/4 v11, 0x0

    return-object v3
.end method

.method private e(Ljava/lang/String;Lx0/a;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Lx0/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v0, "oesp/s=t/pedwaaay/me/trexhsG"

    const-string v0, "hasp/et/wrsd=myGeaexotp/ase/"

    const/4 v8, 0x7

    const-string v0, "e/tm/dyayeheamsGo/patw=/prxe"

    const-string/jumbo v0, "paymethod=\"expressGateway\""

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {p0, p2, p1}, Lcom/alipay/sdk/app/PayTask;->f(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-object p1

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->w()Ljava/util/List;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-boolean v1, v1, Lcom/alipay/sdk/data/a;->g:Z

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v0, :cond_2

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {p2, v1, v0}, Lcom/alipay/sdk/util/l;->y(Lx0/a;Landroid/content/Context;Ljava/util/List;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string v2, "bzi"

    const-string v2, "bzi"

    const/4 v8, 0x5

    const-string/jumbo v2, "ibz"

    const-string v2, "biz"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v1, :cond_7

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v1, Lcom/alipay/sdk/util/f;

    const/4 v7, 0x5

    and-int/2addr v8, v7

    iget-object v3, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {p0}, Lcom/alipay/sdk/app/PayTask;->b()Lcom/alipay/sdk/util/f$d;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v1, v3, p2, v4}, Lcom/alipay/sdk/util/f;-><init>(Landroid/app/Activity;Lx0/a;Lcom/alipay/sdk/util/f$d;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v4, "epnsotnay: rmrida e"

    const-string v4, ":iemtnra edprns yat"

    const/4 v8, 0x0

    const-string v4, "eya  ba:nidrs ntrpe"

    const-string/jumbo v4, "pay inner started: "

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const-string/jumbo v4, "lmsp"

    const-string/jumbo v4, "lspm"

    const/4 v8, 0x1

    const-string/jumbo v4, "splm"

    const-string/jumbo v4, "mspl"

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    invoke-static {v4, v3}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    invoke-virtual {v1, p1}, Lcom/alipay/sdk/util/f;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string/jumbo v6, "ur ipautnae:s eorlynwr"

    const-string v6, " leaotypea i: rnurwsrn"

    const/4 v8, 0x1

    const-string/jumbo v6, "seryr  pwr:npa t eianu"

    const-string/jumbo v6, "pay inner raw result: "

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v4, v5}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1}, Lcom/alipay/sdk/util/f;->h()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo v1, "ibqdla"

    const-string/jumbo v1, "idleab"

    const/4 v8, 0x1

    const-string v1, "fasedi"

    const-string v1, "failed"

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-static {v3, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-nez v1, :cond_6

    const/4 v8, 0x2

    const-string/jumbo v1, "uhcmfladeesmi"

    const-string/jumbo v1, "ialm_euhcsdfe"

    const/4 v8, 0x0

    const-string v1, "eeelomshdciaf"

    const-string/jumbo v1, "scheme_failed"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v3, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v1, :cond_3

    const/4 v7, 0x6

    and-int/2addr v8, v7

    goto :goto_0

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v1, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-object p1

    :cond_4
    const/4 v8, 0x3

    const-string v1, "/g/a}b/leif//o:/isLpn/s"

    const-string/jumbo v1, "il:/f/gps//Ln///}s/eaoi"

    const/4 v8, 0x3

    const-string v1, "L:neliuo///a}fi/gs/s{//"

    const-string/jumbo v1, "{\"isLogin\":\"false\"}"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v1, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v1, "kLigBntpHyqnIenLoo"

    const-string/jumbo v1, "ynLtogntqHnIiekoLB"

    const/4 v8, 0x6

    const-string v1, "IBngkyLoqtLitHngon"

    const-string v1, "LogHkLoginByIntent"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p2, v2, v1}, Lcom/alipay/sdk/app/statistic/a;->c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v8, 0x4

    invoke-static {p2, p1, v0, v3, v1}, Lcom/alipay/sdk/app/PayTask;->g(Lx0/a;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Landroid/app/Activity;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-object p1

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-object v3

    :cond_6
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const-string v0, "5CsiLBdoHeganld"

    const-string v0, "BHslaCidde5ngLo"

    const/4 v8, 0x6

    const-string v0, "eCLmign5dHlaBdl"

    const-string v0, "LogBindCalledH5"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {p2, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p0, p2, p1}, Lcom/alipay/sdk/app/PayTask;->f(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-object p1

    :cond_7
    const/4 v8, 0x2

    const-string v0, "5adgoHLeCol"

    const-string v0, "LogCalledH5"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p2, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {p0, p2, p1}, Lcom/alipay/sdk/app/PayTask;->f(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-object p1
.end method

.method private f(Lx0/a;Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->showLoading()V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v1, Lcom/alipay/sdk/packet/impl/f;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-direct {v1}, Lcom/alipay/sdk/packet/impl/f;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1, p1, v2, p2}, Lcom/alipay/sdk/packet/e;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1}, Lcom/alipay/sdk/packet/b;->c()Lorg/json/JSONObject;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v2, "_deoebcm"

    const-string v2, "edcme_od"

    const/4 v9, 0x6

    const-string v2, "ed_ndouc"

    const-string v2, "end_code"

    const/4 v8, 0x6

    const/4 v8, 0x4

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v3, "from"

    const-string/jumbo v3, "rmfo"

    const/4 v9, 0x4

    const-string/jumbo v3, "omfr"

    const-string v3, "form"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string v4, "dpnooa"

    const-string/jumbo v4, "naoood"

    const/4 v9, 0x4

    const-string/jumbo v4, "odqonl"

    const-string/jumbo v4, "onload"

    const/4 v9, 0x7

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v3}, Lw0/b;->b(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v4, 0x0

    and-int/2addr v9, v4

    const/4 v8, 0x5

    move v9, v8

    move v5, v4

    const/4 v9, 0x4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ge v5, v6, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    check-cast v6, Lw0/b;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v6}, Lw0/b;->e()Lw0/a;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    sget-object v7, Lw0/a;->c:Lw0/a;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-ne v6, v7, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    check-cast v6, Lw0/b;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v6}, Lw0/b;->c(Lw0/b;)V

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-direct {p0, p1, v1}, Lcom/alipay/sdk/app/PayTask;->l(Lx0/a;Lorg/json/JSONObject;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x1

    const/4 v8, 0x7

    iget-object v5, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v1, p1, p2, v5}, Lcom/alipay/sdk/app/statistic/a;->b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    if-ge v4, v1, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x3

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    check-cast v1, Lw0/b;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v1}, Lw0/b;->e()Lw0/a;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget-object v6, Lw0/a;->b:Lw0/a;

    const/4 v8, 0x2

    move v9, v8

    if-ne v5, v6, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-direct {p0, p1, v1}, Lcom/alipay/sdk/app/PayTask;->i(Lx0/a;Lw0/b;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v8, 0x6

    move v9, v8

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x7

    const/4 v8, 0x3

    iget-object v2, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v1, p1, p2, v2}, Lcom/alipay/sdk/app/statistic/a;->b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-object v0

    :cond_2
    :try_start_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1}, Lw0/b;->e()Lw0/a;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    sget-object v6, Lw0/a;->d:Lw0/a;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-ne v5, v6, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {p0, p1, v1, v2}, Lcom/alipay/sdk/app/PayTask;->j(Lx0/a;Lw0/b;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto :goto_2

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto :goto_1

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v2, "izb"

    const-string v2, "bzi"

    const/4 v9, 0x4

    const-string v2, "bzi"

    const-string v2, "biz"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v3, "rrsDtsyaoaslAHr5naabEi"

    const-string v3, "AHaaabrParnysrDisEot5l"

    const/4 v9, 0x0

    const-string/jumbo v3, "trrm5AEasaonyiDsayHlaP"

    const-string v3, "H5PayDataAnalysisError"

    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-static {p1, v2, v3, v1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v2, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v1, p1, p2, v2}, Lcom/alipay/sdk/app/statistic/a;->b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    goto :goto_3

    :catch_0
    move-exception v0

    :try_start_3
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    sget-object v1, Lcom/alipay/sdk/app/e;->d:Lcom/alipay/sdk/app/e;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1}, Lcom/alipay/sdk/app/e;->a()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v1}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo v2, "ten"

    const-string/jumbo v2, "nte"

    const/4 v9, 0x6

    const-string v2, "etn"

    const-string/jumbo v2, "net"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p1, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->g(Lx0/a;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v2, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v0, p1, p2, v2}, Lcom/alipay/sdk/app/statistic/a;->b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_3
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-nez v0, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    sget-object p1, Lcom/alipay/sdk/app/e;->b:Lcom/alipay/sdk/app/e;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->a()I

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {p1}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object v0

    :cond_5
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/app/e;->a()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/app/e;->e()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {p1, p2, v0}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-object p1

    :catchall_1
    move-exception v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v2, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v8, 0x3

    invoke-static {v1, p1, p2, v2}, Lcom/alipay/sdk/app/statistic/a;->b(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    throw v0
.end method

.method public static declared-synchronized fetchSdkConfig(Landroid/content/Context;)Z
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x3

    const-class v0, Lcom/alipay/sdk/app/PayTask;

    const-class v0, Lcom/alipay/sdk/app/PayTask;

    const/4 v9, 0x5

    const-class v0, Lcom/alipay/sdk/app/PayTask;

    const-class v0, Lcom/alipay/sdk/app/PayTask;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-enter v0

    const/4 v8, 0x1

    move v9, v8

    const/4 v1, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v8, 0x1

    move v9, v8

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v2, p0}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v9, 0x1

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v8, 0x1

    const/4 v9, 0x5

    div-long/2addr v2, v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    sget-wide v4, Lcom/alipay/sdk/app/PayTask;->i:J

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    sub-long v4, v2, v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v6}, Lcom/alipay/sdk/data/a;->n()I

    move-result v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    int-to-long v6, v6

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    cmp-long v4, v4, v6

    const/4 v9, 0x3

    if-gez v4, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x2

    monitor-exit v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    return v1

    :cond_0
    :try_start_1
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    sput-wide v2, Lcom/alipay/sdk/app/PayTask;->i:J

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {}, Lx0/a;->f()Lx0/a;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v2, v3, p0}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    monitor-exit v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 p0, 0x6

    const/4 p0, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    return p0

    :catchall_0
    move-exception p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    :try_start_2
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    return v1

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    throw p0
.end method

.method private static g(Lx0/a;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Landroid/app/Activity;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/alipay/sdk/data/a$b;",
            ">;",
            "Ljava/lang/String;",
            "Landroid/app/Activity;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0, p4, p2}, Lcom/alipay/sdk/util/l;->c(Lx0/a;Landroid/content/Context;Ljava/util/List;)Lcom/alipay/sdk/util/l$b;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, p0}, Lcom/alipay/sdk/util/l$b;->b(Lx0/a;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/alipay/sdk/util/l$b;->a()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p2, p2, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    const/4 v3, 0x4

    iget-object p2, p2, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const-string v0, ".iaelhulywpkalt."

    const/4 v3, 0x2

    const-string/jumbo v0, "k.ayoalwaelpt.lh"

    const-string v0, "hk.alipay.wallet"

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    const-string/jumbo p2, "smpl"

    const-string/jumbo p2, "plsm"

    const/4 v3, 0x0

    const-string/jumbo p2, "slpm"

    const-string/jumbo p2, "mspl"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p3, "tik_abTylns ogpPn"

    const-string/jumbo p3, "tnsaoklpog_PTny i"

    const/4 v3, 0x5

    const-string/jumbo p3, "ksn aaugiToynPt_o"

    const-string p3, "PayTask not_login"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p2, p3}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p3, Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p3}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lcom/alipay/sdk/app/PayResultActivity;->c:Ljava/util/HashMap;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p2, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p3, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-class v1, Lcom/alipay/sdk/app/PayResultActivity;

    const-class v1, Lcom/alipay/sdk/app/PayResultActivity;

    const/4 v3, 0x1

    const-class v1, Lcom/alipay/sdk/app/PayResultActivity;

    const-class v1, Lcom/alipay/sdk/app/PayResultActivity;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p3, p4, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "rurofSdpxfe"

    const-string v1, "fSorefdrqxu"

    const/4 v3, 0x6

    const-string/jumbo v1, "orderSuffix"

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p3, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo p1, "nsxerltaqeePmaN"

    const-string p1, "exsetralegmaNnP"

    const/4 v3, 0x1

    const-string p1, "PmseleNgxrenaak"

    const-string p1, "externalPkgName"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p3, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo p1, "yaemphhhosncapi.ehm.r"

    const-string p1, "eahmcp.aeaoh.rshihnyp"

    const/4 v3, 0x2

    const-string/jumbo p1, "shpyopaaonhsc.ia.hhre"

    const-string/jumbo p1, "phonecashier.pay.hash"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p3, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p3}, Lx0/a$a;->c(Lx0/a;Landroid/content/Intent;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p4, p3}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x5

    const-string/jumbo p1, "lpms"

    const-string/jumbo p1, "mlps"

    const/4 v3, 0x2

    const-string/jumbo p1, "mspl"

    const/4 v3, 0x5

    const-string p3, " stkybaaiPoT"

    const-string/jumbo p3, "isayo TkPtwa"

    const/4 v3, 0x6

    const-string/jumbo p3, "tPaT ausawiy"

    const-string p3, "PayTask wait"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, p3}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->wait()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object p0, Lcom/alipay/sdk/app/PayResultActivity$b;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo p1, "mspl"

    const-string/jumbo p1, "plms"

    const/4 v3, 0x5

    const-string/jumbo p1, "plsm"

    const-string/jumbo p1, "mspl"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p3, "sa bPkep:taTy"

    const-string p3, " :kPTbseaa yt"

    const/4 v3, 0x1

    const-string/jumbo p3, "s:arPTy q tke"

    const-string p3, "PayTask ret: "

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, p2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :catch_0
    :try_start_2
    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo p1, "pslm"

    const-string/jumbo p1, "pmsl"

    const/4 v3, 0x0

    const-string/jumbo p1, "spml"

    const-string/jumbo p1, "mspl"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string p2, " rerdauykspaPuenitT"

    const/4 v3, 0x6

    const-string/jumbo p2, "ukstnsrpaytedai ePr"

    const-string p2, "PayTask interrupted"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, p2}, Lcom/alipay/sdk/util/d;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p1

    :cond_1
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p3
.end method

.method private declared-synchronized h(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {}, Lcom/alipay/sdk/app/PayTask;->n()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo p2, "ibz"

    const-string p2, "bzi"

    const/4 v7, 0x7

    const-string p2, "bzi"

    const-string p2, "biz"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo p3, "pepmaP"

    const-string p3, "apPRep"

    const/4 v7, 0x6

    const-string p3, "eyapoP"

    const-string p3, "RepPay"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x3

    invoke-static {p1, p2, p3, v0}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Lcom/alipay/sdk/app/d;->g()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    monitor-exit p0

    return-object p1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz p3, :cond_1

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->showLoading()V

    :cond_1
    const/4 v7, 0x3

    const-string p3, "aynp_bt=qsnmt"

    const-string/jumbo p3, "nts_tm=iqnayp"

    const/4 v7, 0x0

    const-string/jumbo p3, "nysnptu_ieatm"

    const-string/jumbo p3, "payment_inst="

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz p3, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo p3, "ntmpeispyta_s"

    const-string/jumbo p3, "tpss_naetmnyi"

    const/4 v7, 0x5

    const-string/jumbo p3, "payment_inst="

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-int/lit8 p3, p3, 0xd

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/16 v0, 0x26

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-lez v0, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p3, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p3

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v0, "//"

    const-string v0, "//"

    const/4 v7, 0x3

    const-string v0, "//"

    const-string v0, "\""

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p3, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v0, "ayimap"

    const/4 v7, 0x2

    const-string/jumbo v0, "yaqlia"

    const-string v0, "alipay"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p3, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p3}, Lcom/alipay/sdk/app/c;->b(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string p3, ""

    const-string p3, ""

    const/4 v7, 0x1

    const-string p3, ""

    const-string p3, ""

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p3}, Lcom/alipay/sdk/app/c;->b(Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const-string p3, "arsparr.ndiqey=ai.isaoerur.aaecc.lpceovydm"

    const-string/jumbo p3, "scp.oyaqarepratcnleaeiecudy.mvr.iadr=io.ra"

    const/4 v7, 0x5

    const-string p3, "c=lm.emcurderiasqr.ricat.aaiaverpaeeyndp.y"

    const-string/jumbo p3, "service=alipay.acquire.mr.ord.createandpay"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz p3, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 p3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    sput-boolean p3, Lt0/a;->u:Z

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-boolean p3, Lt0/a;->u:Z

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz p3, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string p3, ":cmmwbaowsce/ee.a.ga.lyfhsxtrtihga/nahtpptAomepis?/py"

    const/4 v7, 0x5

    const-string/jumbo p3, "oe.woaasixcsynaggl/h/aeha/eppcwtpo.tmmr./?:tpyAetfmhi"

    const-string p3, "https://wappaygw.alipay.com/home/exterfaceAssign.htm?"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz p3, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo p3, "umeoabpcet/mseaaA./cyhrsppi/aeo.hagxf?ypnw:ttlmts/.ig"

    const-string/jumbo p3, "ytgeanuclet:m/e/opgpwtpteisa?s.c.iofAp./ahhyxash/rmma"

    const/4 v7, 0x1

    const-string p3, "ayamsyuwsgr.wcagmipnf//pAxee:e.ttathohiec/m?plhp/os.t"

    const-string p3, "https://wappaygw.alipay.com/home/exterfaceAssign.htm?"

    const/4 v6, 0x1

    or-int/2addr v7, v6

    invoke-virtual {p2, p3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p3

    const/4 v7, 0x5

    const/4 v6, 0x2

    add-int/lit8 p3, p3, 0x35

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_1

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo p3, "tosht/ipm.ieeachpxl.:emgnmslopsAcm/paie.thy/t?aec/ft"

    const-string/jumbo p3, "mehi/nnplahoihcep?sptote.l/tsgcteai/cmx:ya/tAfmsem.."

    const/4 v7, 0x3

    const-string p3, "eehy?c//qmotemspxfmm/.piAgalhnts.:ca/cisirlttnoh.aee"

    const-string p3, "https://mclient.alipay.com/home/exterfaceAssign.htm?"

    const/4 v7, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    const/4 v7, 0x5

    const/4 v6, 0x4

    if-eqz p3, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x0

    const-string p3, ".psomp/ah/afnqhA?emocyiesht.ite:e/men.lstirmcxl/actt"

    const-string/jumbo p3, "ieyihcmxqpeah/na.cAlo?cmehtpetft/imt.//rsmn:oasl.est"

    const/4 v7, 0x5

    const-string p3, "https://mclient.alipay.com/home/exterfaceAssign.htm?"

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p3

    const/4 v7, 0x3

    add-int/lit8 p3, p3, 0x34

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    :cond_6
    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string p3, ""

    const-string p3, ""

    const/4 v7, 0x6

    const-string p3, ""

    const-string p3, ""
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v7, 0x4

    const-string/jumbo v0, "lmsp"

    const-string/jumbo v0, "pslm"

    const/4 v7, 0x3

    const-string/jumbo v0, "mspl"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const-string v2, " ppmayee rrad:"

    const-string/jumbo v2, "pay prepared: "

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0, p2, p1}, Lcom/alipay/sdk/app/PayTask;->e(Ljava/lang/String;Lx0/a;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x2

    const-string/jumbo v0, "lpms"

    const-string/jumbo v0, "lmps"

    const-string/jumbo v0, "pmsl"

    const-string/jumbo v0, "mspl"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    move v7, v6

    const-string/jumbo v2, "rrssot  upl:yeaa"

    const-string/jumbo v2, "y sarwpla :rtues"

    const/4 v7, 0x3

    const-string/jumbo v2, "pay raw result: "

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    shl-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {p1, v0, p3}, Lcom/alipay/sdk/util/g;->c(Lx0/a;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const-string v0, "bzi"

    const-string v0, "biz"

    const/4 v7, 0x6

    const-string v0, "bzi"

    const-string v0, "biz"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string/jumbo v1, "uRgmtbnP"

    const-string v1, "RtnmugPe"

    const/4 v7, 0x7

    const-string/jumbo v1, "nretuPug"

    const-string v1, "PgReturn"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string v0, "biz"

    const-string v0, "biz"

    const/4 v7, 0x4

    const-string/jumbo v0, "izb"

    const-string v0, "biz"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v1, "turoRegpP"

    const-string/jumbo v1, "ruPeogtRV"

    const/4 v7, 0x6

    const-string v1, "gRPertunq"

    const-string v1, "PgReturnV"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v3, "Susststuatlr"

    const-string/jumbo v3, "resultStatus"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x6

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const-string v3, "emom"

    const-string/jumbo v3, "oemm"

    const/4 v7, 0x5

    const-string/jumbo v3, "meom"

    const-string/jumbo v3, "memo"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->v()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez v0, :cond_7

    const/4 v7, 0x5

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_7
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v0, p1, p2, v1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto/16 :goto_3

    :catchall_0
    move-exception v0

    :try_start_4
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v0, "izb"

    const/4 v7, 0x4

    const-string/jumbo v0, "ibz"

    const-string v0, "biz"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v1, "nbRmeugP"

    const-string v1, "ReungbrP"

    const/4 v7, 0x5

    const-string v1, "RtruogPe"

    const-string v1, "PgReturn"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x1

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo v0, "zib"

    const-string/jumbo v0, "izb"

    const/4 v7, 0x1

    const-string/jumbo v0, "zbi"

    const-string v0, "biz"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "VurunbegR"

    const-string v1, "VenPguuRr"

    const/4 v7, 0x0

    const-string v1, "VPungRure"

    const-string v1, "PgReturnV"

    const/4 v7, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v3, "ratSttppselu"

    const-string v3, "eutlaStpusrt"

    const/4 v7, 0x7

    const-string/jumbo v3, "suStlertqaut"

    const-string/jumbo v3, "resultStatus"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x7

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v3, "mome"

    const-string v3, "eomm"

    const/4 v7, 0x4

    const-string/jumbo v3, "omme"

    const-string/jumbo v3, "memo"

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->v()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-nez v0, :cond_8

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto/16 :goto_2

    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo p1, "lspm"

    const-string/jumbo p1, "pslm"

    const/4 v7, 0x2

    const-string/jumbo p1, "lmsp"

    const-string/jumbo p1, "mspl"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v0, "rtsayp nq: uire"

    const-string/jumbo v0, "uergrp iq n:ayt"

    const/4 v7, 0x5

    const-string/jumbo v0, "iupmntnar e rgy"

    const-string/jumbo v0, "pay returning: "

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p1, p2}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    monitor-exit p0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-object p3

    :catchall_1
    move-exception v0

    :try_start_6
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v1, "zbi"

    const-string/jumbo v1, "zbi"

    const/4 v7, 0x3

    const-string/jumbo v1, "ibz"

    const-string v1, "biz"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v2, "gnPsoRet"

    const-string/jumbo v2, "rtsePnRg"

    const/4 v7, 0x0

    const-string/jumbo v2, "netrRbPg"

    const-string v2, "PgReturn"

    const/4 v7, 0x3

    const/4 v6, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p1, v1, v2, v3}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v1, "bzi"

    const-string/jumbo v1, "zbi"

    const/4 v7, 0x2

    const-string/jumbo v1, "izb"

    const-string v1, "biz"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v2, "tnuegPurR"

    const-string v2, "PgReturnV"

    const/4 v6, 0x1

    move v7, v6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v4, "srSluetptmus"

    const-string v4, "Susmtulttser"

    const/4 v7, 0x4

    const-string/jumbo v4, "srstaeutqStl"

    const-string/jumbo v4, "resultStatus"

    const/4 v7, 0x1

    invoke-static {p3, v4}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v4, "mmeo"

    const-string v4, "eomm"

    const/4 v7, 0x6

    const-string/jumbo v4, "memo"

    const-string/jumbo v4, "memo"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p3, v4}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p1, v1, v2, p3}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object p3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p3}, Lcom/alipay/sdk/data/a;->v()Z

    move-result p3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez p3, :cond_9

    const/4 v6, 0x0

    and-int/2addr v7, v6

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object p3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p3, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_9
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/app/PayTask;->dismissLoading()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object p3, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p3, p1, p2, v1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    monitor-exit p0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    throw p1
.end method

.method private i(Lx0/a;Lw0/b;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {p2}, Lw0/b;->g()[Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x2

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    aget-object v2, p2, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v3, "ulr"

    const-string/jumbo v3, "rul"

    const/4 v5, 0x0

    const-string/jumbo v3, "lru"

    const-string/jumbo v3, "url"

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    array-length v2, p2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne v2, v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    aget-object p2, p2, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v2, "oesioo"

    const-string/jumbo v2, "iceooo"

    const/4 v5, 0x2

    const-string v2, "coemko"

    const-string v2, "cookie"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1, v0}, Lx0/a$a;->c(Lx0/a;Landroid/content/Intent;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object p1, Lcom/alipay/sdk/app/PayTask;->h:Ljava/lang/Object;

    const/4 v5, 0x3

    monitor-enter p1

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->wait()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v5, 0x4

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lcom/alipay/sdk/app/d;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object p1

    :catchall_0
    move-exception p2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :catch_0
    move-exception p2

    :try_start_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p2}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    monitor-exit p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p2

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    throw p2
.end method

.method private j(Lx0/a;Lw0/b;Ljava/lang/String;)Ljava/lang/String;
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p2}, Lw0/b;->g()[Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v9, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const/4 v10, 0x0

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const-class v2, Lcom/alipay/sdk/app/H5PayActivity;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    new-instance v1, Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v2, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    aget-object v3, p2, v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {v3}, Lcom/alipay/sdk/encrypt/a;->d(Ljava/lang/String;)[B

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct {v1, v3}, Ljava/lang/String;-><init>([B)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->C(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string/jumbo v3, "lru"

    const-string/jumbo v3, "rul"

    const/4 v10, 0x2

    const-string/jumbo v3, "rlu"

    const-string/jumbo v3, "url"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v4, 0x0

    aget-object v5, p2, v4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v3, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v3, "libto"

    const-string v3, "betil"

    const/4 v10, 0x6

    const-string v3, "bteli"

    const-string/jumbo v3, "title"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v5, 0x1

    const/4 v9, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    aget-object v6, p2, v5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0, v3, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string/jumbo v3, "ivusoeu"

    const-string/jumbo v3, "ienosvu"

    const/4 v10, 0x4

    const-string/jumbo v3, "pnvores"

    const-string/jumbo v3, "version"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-string/jumbo v6, "v2"

    const-string v6, "2v"

    const/4 v10, 0x6

    const-string v6, "2v"

    const-string/jumbo v6, "v2"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v3, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v3, "hpqtmo"

    const-string/jumbo v3, "mpetho"

    const/4 v10, 0x4

    const-string/jumbo v3, "otsmde"

    const-string/jumbo v3, "method"

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    const-string/jumbo v6, "tqhmed"

    const-string v6, "hdqeto"

    const/4 v10, 0x3

    const-string/jumbo v6, "omedoh"

    const-string/jumbo v6, "method"

    const/4 v10, 0x1

    const-string v7, "SOPT"

    const-string v7, "PSOT"

    const/4 v10, 0x4

    const-string v7, "SPTO"

    const-string v7, "POST"

    const/4 v10, 0x5

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v9, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v4}, Lcom/alipay/sdk/app/d;->d(Z)V

    const/4 v10, 0x6

    const/4 p2, 0x5

    const/4 v10, 0x6

    const/4 p2, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {p2}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {p1, v0}, Lx0/a$a;->c(Lx0/a;Landroid/content/Intent;)V

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    sget-object v0, Lcom/alipay/sdk/app/PayTask;->h:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    monitor-enter v0

    :try_start_1
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->wait()V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {}, Lcom/alipay/sdk/app/d;->e()Z

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {}, Lcom/alipay/sdk/app/d;->a()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v4}, Lcom/alipay/sdk/app/d;->d(Z)V

    const/4 v9, 0x6

    and-int/2addr v10, v9

    invoke-static {p2}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string p2, ""

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x5

    const/4 v9, 0x4

    if-eqz v1, :cond_1

    :try_start_3
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-instance v0, Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {v3}, Lcom/alipay/sdk/encrypt/a;->d(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/alipay/sdk/util/l;->C(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v0}, Lw0/b;->b(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    move v1, v4

    const/4 v10, 0x5

    move v1, v4

    move v1, v4

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-ge v1, v6, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    check-cast v6, Lw0/b;

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v6}, Lw0/b;->e()Lw0/a;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    sget-object v8, Lw0/a;->e:Lw0/a;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-ne v7, v8, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v6}, Lw0/b;->g()[Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    aget-object v1, v0, v5

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    aget-object v4, v0, v4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    aget-object v0, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {p1, v0}, Lcom/alipay/sdk/util/l;->v(Lx0/a;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v1, v4, v0}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_1

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string/jumbo v1, "zib"

    const-string/jumbo v1, "izb"

    const-string/jumbo v1, "ibz"

    const-string v1, "biz"

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string v2, "ayrPsbrHlniysrt5aDoasE"

    const-string/jumbo v2, "rtsEaiyHarPsyloaDnA5rs"

    const/4 v10, 0x0

    const-string v2, "5tHyrDusylaaPaAroErins"

    const-string v2, "H5PayDataAnalysisError"

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {p1, v1, v2, v0, v3}, Lcom/alipay/sdk/app/statistic/a;->f(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    :cond_1
    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-eqz v0, :cond_2

    :try_start_4
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string v1, ""

    const/4 v10, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p2, v0, v1}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_2

    :catchall_1
    move-exception p2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string v0, "biz"

    const/4 v10, 0x3

    const-string/jumbo v0, "zib"

    const-string v0, "biz"

    const/4 v10, 0x3

    const-string/jumbo v1, "siymrElPyroanr5staaDaA"

    const/4 v10, 0x1

    const-string/jumbo v1, "sriPly5pyDaatanHosAaEr"

    const-string v1, "H5PayDataAnalysisError"

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string v3, ":eo eddoq"

    const-string v3, "dd:eon eo"

    const/4 v10, 0x1

    const-string/jumbo v3, "odsedn :C"

    const-string v3, "endCode: "

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {p1, v0, v1, p2, p3}, Lcom/alipay/sdk/app/statistic/a;->f(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v10, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 p3, 0x1f40

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-static {p3, p1, p2}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    :cond_2
    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x1

    return-object p2

    :catchall_2
    move-exception p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_5
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v10, 0x7

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    monitor-exit v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-object p1

    :goto_3
    const/4 v10, 0x7

    const/4 v9, 0x5

    monitor-exit v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/4 v9, 0x0

    move v10, v9

    throw p1

    :catchall_3
    move-exception p3

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {p3}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string/jumbo v0, "zbi"

    const-string/jumbo v0, "zib"

    const/4 v10, 0x5

    const-string/jumbo v0, "izb"

    const-string v0, "biz"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string v1, "EDAmtrP5abiarsalysHayr"

    const-string v1, "asatrbnrsayEHAy5ariPlD"

    const/4 v10, 0x7

    const-string/jumbo v1, "rnaEoi5rosytDHPasrAaal"

    const-string v1, "H5PayDataAnalysisError"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {p1, v0, v1, p3, p2}, Lcom/alipay/sdk/app/statistic/a;->f(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    return-object p1
.end method

.method private static final varargs k([Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez p0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x0

    const/4 v5, 0x6

    array-length v1, p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-ge v2, v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    aget-object v3, p0, v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v3

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object v0
.end method

.method private l(Lx0/a;Lorg/json/JSONObject;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "itd"

    const-string/jumbo v0, "tid"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v1, "eiylkbc_en"

    const-string v1, "cenikeu_ly"

    const/4 v3, 0x0

    const-string/jumbo v1, "ktnleeuciy"

    const-string v1, "client_key"

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x0

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Lx0/b;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/alipay/sdk/tid/c;->a(Landroid/content/Context;)Lcom/alipay/sdk/tid/c;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1, v0, p2}, Lcom/alipay/sdk/tid/c;->c(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "izb"

    const-string v0, "biz"

    const/4 v3, 0x7

    const-string/jumbo v0, "izb"

    const-string v0, "biz"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "liCPeKrpTasEyrpnteex"

    const-string/jumbo v1, "irerETypexseCPnlKdta"

    const/4 v3, 0x7

    const-string v1, "ParserTidClientKeyEx"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, v0, v1, p2}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method private varargs m(ZZLjava/lang/String;Ljava/lang/StringBuilder;Ljava/util/Map;[Ljava/lang/String;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Ljava/lang/String;",
            "Ljava/lang/StringBuilder;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;[",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    array-length v0, p6

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ge v2, v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    aget-object v3, p6, v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {p5, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    invoke-interface {p5, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5

    const/4 v6, 0x1

    const/4 v5, 0x7

    check-cast p5, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string p5, ""

    const-string p5, ""

    const/4 v6, 0x0

    const-string p5, ""

    const-string p5, ""

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p6

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz p6, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x6

    if-eqz p2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    return v1

    :cond_2
    const/4 v6, 0x7

    const-string p2, "//"

    const-string p2, "//"

    const/4 v6, 0x7

    const-string p2, "//"

    const-string p2, "\""

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string p6, "=//"

    const-string p6, "=//"

    const-string p6, "/=/"

    const-string p6, "=\""

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz p1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string p1, "&"

    const/4 v6, 0x5

    const-string p1, "&"

    const-string p1, "&"

    const/4 v6, 0x7

    const/4 v5, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p4, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_2

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p4, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4
    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 p1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    return p1
.end method

.method private static n()Z
    .locals 8

    const/4 v7, 0x4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-wide v2, Lcom/alipay/sdk/app/PayTask;->k:J

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    sub-long v2, v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const/4 v7, 0x3

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-ltz v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    sput-wide v0, Lcom/alipay/sdk/app/PayTask;->k:J

    const/4 v7, 0x5

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    return v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    return v0
.end method


# virtual methods
.method public dismissLoading()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/a;->i()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/sdk/app/PayTask;->b:Lcom/alipay/sdk/widget/a;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public declared-synchronized fetchOrderInfoFromH5PayUrl(Ljava/lang/String;)Ljava/lang/String;
    .locals 17

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    monitor-enter p0

    :try_start_0
    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v1, "v.yaeltgqssc.se//maipamoa:/ttytreicq/phhpwrp"

    const-string/jumbo v1, "wam/vte.qtrpem.pgcsihsry//ot.aatlcyp:psi/hae"

    const-string/jumbo v1, "oaspa/rpcivts.emgshe.a/lr/wythtaws/pt:pmyie."

    const-string v1, "https://wappaygw.alipay.com/service/rest.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string/jumbo v1, "pa.mhcat/tswlgry.hsmasw./eamer:ypp/titvpoi/"

    const-string/jumbo v1, "s:sty.wwse/hhgea/cpv.t/pit/apaopmytilmrca.r"

    const-string v1, ".w/eoprtai/sea.hwam/.tiomy/rclspg:htaptpvey"

    const-string v1, "http://wappaygw.alipay.com/service/rest.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    const-string/jumbo v1, "pp/msrtso..iyt:et?wyhp/s/|e)p/a(itaptacletmr/vcwh/.mhg"

    const-string v1, "/chp(bhlss)i?geypawpswv/pe/ar/tp/maa:|...mttrytch/tite"

    const-string v1, "(http|https)://wappaygw.alipay.com/service/rest.htm\\?"

    const-string v2, ""

    const-string v2, ""

    invoke-virtual {v9, v1, v2}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->w(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const-string/jumbo v1, "qerad_ut"

    const-string/jumbo v1, "radqote_"

    const-string v1, "ataq_erp"

    const-string/jumbo v1, "req_data"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string/jumbo v1, "nekteobtq>ru<eq"

    const-string/jumbo v1, "q>netbtk<_oruee"

    const-string v1, "ensokeet>q_t<rs"

    const-string v1, "<request_token>"

    const-string/jumbo v2, "uutmsetqk/>rne_<"

    const-string/jumbo v2, "tr_ekqune>ut</es"

    const-string v2, "</request_token>"

    invoke-static {v1, v2, v0}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lx0/a;

    iget-object v2, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    invoke-direct {v1, v2, v3, v4}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/esoout/ptnd&icerrr=u_o8/f=ta-k/_/h/ne"

    const-string v3, "_input_charset=\"utf-8\"&ordertoken=\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "&p/clbae&/s/_/pbypdaiacaxzknnh=t/=intdye_i/_//"

    const-string v0, "ci/d&/cp/=y//aadtzbin=t_&s_pa/lkxinaep_//neoyh"

    const-string/jumbo v0, "isi/tyuc/_ndhxnca&at=/yie/l&_o/denp/aa/lbp/kz_"

    const-string v0, "\"&pay_channel_id=\"alipay_sdk\"&bizcontext=\""

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "sc"

    const-string v0, "cs"

    const-string/jumbo v0, "sc"

    const-string/jumbo v0, "sc"

    const-string/jumbo v3, "nohtei5ptq"

    const-string v3, "eit5ntahqo"

    const-string/jumbo v3, "in5othevqa"

    const-string v3, "h5tonative"

    invoke-virtual {v1, v0, v3}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "//"

    const-string v0, "//"

    const-string v0, "//"

    const-string v0, "\""

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_1
    :try_start_1
    const-string/jumbo v1, "scselhermiseetc/.lhm./tpicttm:apri/nast.yvo"

    const-string v1, "https://mclient.alipay.com/service/rest.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2

    const-string/jumbo v1, "p./m:nceahtamimctetipitsohrtlmec.e/syl/vs."

    const-string v1, "/csi.shemrmr.ot.cp:ehi/eetptamtlnic/ylvtsa"

    const-string v1, "hp/hotmy/evcatpl.cismtma:tse/nl/cro.i.eret"

    const-string v1, "http://mclient.alipay.com/service/rest.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    :cond_2
    const-string/jumbo v1, "vtthmbp/taopl/sia/pl:(?scsmci)thh/.ny./trit|emrece/tm"

    const-string v1, "atemyl/svm/t/epccotra|ti(tt.h/et..rlpmmcshp):?n/h/iis"

    const-string/jumbo v1, "|..metu:/t/)lpptc/hvt./a(/cechnmsreiy?etaomirtp/hssli"

    const-string v1, "(http|https)://mclient.alipay.com/service/rest.htm\\?"

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    invoke-virtual {v9, v1, v2}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->w(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const-string/jumbo v1, "r_etoada"

    const-string/jumbo v1, "rta_eaqp"

    const-string/jumbo v1, "req_data"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string/jumbo v1, "tt>_resnqqueke<"

    const-string v1, "<request_token>"

    const-string v2, "etsnbke</s>utrq_"

    const-string/jumbo v2, "q>ueeb_s/kt<rten"

    const-string v2, "_/smre>enkeo<uqt"

    const-string v2, "</request_token>"

    invoke-static {v1, v2, v0}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lx0/a;

    iget-object v2, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    invoke-direct {v1, v2, v3, v4}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "rduko_/at=ttuot_/sh/e-/&8epc/nfu/renir"

    const-string v3, "atnt/uurf_pkue8r_ooes//tec-d/&hi=//ntr"

    const-string/jumbo v3, "kn_orbttio/nf/e-/e_h8r//=drt=uscut&e/a"

    const-string v3, "_input_charset=\"utf-8\"&ordertoken=\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "/_kb//usenp&=_/l=/xhpczpi_adt/y/tdyin/iaaoceln"

    const-string v0, "_adi_l/pi&k/_tp/shonbadyn=x/le=//yn/iczpect/&a"

    const-string/jumbo v0, "tyy/b=ep_n&caspak//d_htacpe=dz/n&/n/xa/ii/io_l"

    const-string v0, "\"&pay_channel_id=\"alipay_sdk\"&bizcontext=\""

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "sc"

    const-string/jumbo v0, "sc"

    const-string/jumbo v0, "sc"

    const-string/jumbo v0, "sc"

    const-string/jumbo v3, "ohqnta5eqi"

    const-string/jumbo v3, "vhi5nteaqo"

    const-string v3, "hos5ventti"

    const-string v3, "h5tonative"

    invoke-virtual {v1, v0, v3}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "//"

    const-string v0, "\""

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_3
    :try_start_2
    const-string v1, "Aalmhy.ctmgeceeicemsts.o/antmioh/lttpp/nha:xmf/iess"

    const-string v1, "e/sacihntmmh:axest.cee/proiptaetgysmlsnm.t//fchAilo"

    const-string/jumbo v1, "sphfoeoiicmpyh/li.aae/o.tcAemr.sam:tnsmcet/xgnlett/"

    const-string v1, "https://mclient.alipay.com/home/exterfaceAssign.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_4

    const-string v1, "h.:mommieysAtrcpstntn/mtgaaf..xp/aiellet/ioemec/ch"

    const-string/jumbo v1, "icreob.//.ttsm/ahle/nApp.xthclmeehtftnma:gaomeciiy"

    const-string v1, "http://mclient.alipay.com/home/exterfaceAssign.htm"

    invoke-virtual {v9, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_4
    const-string v1, "dptoecu.ueylawreap.py.y.ca.atirbe.ir"

    const-string/jumbo v1, "rpltoyy.bpeitr..y.apcreaceei..wasdua"

    const-string v1, "alipay.wap.create.direct.pay.by.user"

    invoke-virtual {v9, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "atpo_fxpbaeeetcd_arwrr"

    const-string v1, "faxc_brpreda_eraoettw_"

    const-string/jumbo v1, "rwxttaeeqropra__eadce_"

    const-string v1, "create_forex_trade_wap"

    invoke-virtual {v9, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_6

    :cond_5
    const-string/jumbo v1, "tcsx//stplifat:smciay?t|eiemh.(stht/plcAn.upnmr.h/o/geaot)hme"

    const-string/jumbo v1, "snth?tu.c)lthcoe/giiAxmp//tl.paet|hsp/mnyee/scrha:tm/f(.iomta"

    const-string v1, "/e/mem/ti)hiptni/lcshma.ase.:ptl/e?grxaofAmcstptne.thcm(t|/yh"

    const-string v1, "(http|https)://mclient.alipay.com/home/exterfaceAssign.htm\\?"

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    invoke-virtual {v9, v1, v2}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_6

    new-instance v1, Lx0/a;

    iget-object v2, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    invoke-direct {v1, v2, v3, v4}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string/jumbo v3, "lru"

    const-string/jumbo v3, "lur"

    const-string/jumbo v3, "rlu"

    const-string/jumbo v3, "url"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string/jumbo v0, "zbtcontpxi"

    const-string v0, "bizcontext"

    const-string v3, "cs"

    const-string v3, "cs"

    const-string v3, "cs"

    const-string/jumbo v3, "sc"

    const-string/jumbo v4, "vqieonatot"

    const-string/jumbo v4, "tn5votaiqe"

    const-string/jumbo v4, "noviabetht"

    const-string v4, "h5tonative"

    invoke-virtual {v1, v3, v4}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "_aewt=ux_oifne=snnr"

    const-string v1, "_nsn==tan_eieoxwref"

    const-string v1, "i=nf_lept_e=ranonew"

    const-string/jumbo v1, "new_external_info=="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_6
    :try_start_3
    const-string/jumbo v1, "omda/rmeqit?pp^./.tey./oo/at/m_hlatpwde.ml(pttaa/ai/y//m/.opd///(l.a.d.wdiisr/y)olippd._|:|oo/)y/dwy.c?aptt/e/|/.//lpc/c.a/aca/nhaira/mlm_r?/"

    const-string/jumbo v1, "l)imryodi/(/doslt|/ti.popycooto./m)mad./aamy//te/lt|d:|?./a/_p/a/a/a?pe^p//r.dwmw/t/i..l/tdt.crpi/.l(hyecpyhaipe/oa/r?d/_anmalmyc/a._/./ap./w"

    const-string/jumbo v1, "oesoohil|aapottraerydyac:m.lttw.ood/.picd/p/t/.//i/.lwy/c|/yipa_)ampah/al/p/.m/)d.tiy(/a..adm/pm/rl?.s.i/n/?/a(ta_deo_a/r?/y.///mc|pa^/ltep/d"

    const-string v1, "^(http|https)://(maliprod\\.alipay\\.com/w/trade_pay\\.do.?|mali\\.alipay\\.com/w/trade_pay\\.do.?|mclient\\.alipay\\.com/w/trade_pay\\.do.?)"

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x1

    const/4 v15, 0x0

    if-eqz v1, :cond_b

    const-string v1, "?"

    const-string v1, "?"

    const-string v1, "?"

    const-string v1, "?"

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    invoke-static {v1, v2, v0}, Lcom/alipay/sdk/util/l;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-static {v0}, Lcom/alipay/sdk/util/l;->w(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "aodmn_or"

    const-string/jumbo v4, "raedono_"

    const-string/jumbo v4, "odneoart"

    const-string/jumbo v4, "trade_no"

    new-array v6, v13, [Ljava/lang/String;

    const-string v1, "don_ebra"

    const-string/jumbo v1, "onra_bde"

    const-string/jumbo v1, "trdnoaue"

    const-string/jumbo v1, "trade_no"

    aput-object v1, v6, v15

    const-string v1, "_auadeppl_yotia"

    const-string v1, "ad_aieuoparty_l"

    const-string/jumbo v1, "iyldpaaoq_erat_"

    const-string v1, "alipay_trade_no"

    aput-object v1, v6, v14

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object/from16 p1, v7

    move-object/from16 p1, v7

    move-object/from16 p1, v7

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    invoke-direct/range {v1 .. v7}, Lcom/alipay/sdk/app/PayTask;->m(ZZLjava/lang/String;Ljava/lang/StringBuilder;Ljava/util/Map;[Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v4, "pdsipeash_ay"

    const-string/jumbo v4, "pay_phase_id"

    new-array v7, v12, [Ljava/lang/String;

    const-string v1, "IaPmpaeysp"

    const-string v1, "apysPIdpea"

    const-string v1, "aeyIohPsad"

    const-string/jumbo v1, "payPhaseId"

    aput-object v1, v7, v15

    const-string v1, "hsqd_bpapiye"

    const-string v1, "hppiady_qes_"

    const-string v1, "_aedhyusia_p"

    const-string/jumbo v1, "pay_phase_id"

    aput-object v1, v7, v14

    const-string v1, "_uoloteps_atrii"

    const-string/jumbo v1, "losntrueii_a_to"

    const-string v1, "do_atiulqtonei_"

    const-string/jumbo v1, "out_relation_id"

    aput-object v1, v7, v13

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    invoke-direct/range {v1 .. v7}, Lcom/alipay/sdk/app/PayTask;->m(ZZLjava/lang/String;Ljava/lang/StringBuilder;Ljava/util/Map;[Ljava/lang/String;)Z

    const-string/jumbo v1, "yespm=/bT/_bsD/u_ti/ARz"

    const-string/jumbo v1, "iRsmy/zb/DEe_T/=upA/tb_"

    const-string v1, "Tp_my/&bEb/t/D/zAReui=s"

    const-string v1, "&biz_sub_type=\"TRADE\""

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "//ytoidz=r/_eopea/&"

    const-string v1, "/tb/oaed//ipryez_=&"

    const-string v1, "b/ertbez/=_tidp/y/&"

    const-string v1, "&biz_type=\"trade\""

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "p_pmebaa"

    const-string v1, "a_mpeaun"

    const-string v1, "app_name"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_7

    const-string v2, "dci"

    const-string v2, "cdi"

    const-string v2, "cdi"

    const-string v2, "cid"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_7

    const-string/jumbo v1, "piual68"

    const-string v1, "ai18l6u"

    const-string v1, "8q6i1a8"

    const-string v1, "ali1688"

    goto :goto_0

    :cond_7
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_9

    const-string/jumbo v2, "sdi"

    const-string/jumbo v2, "sdi"

    const-string v2, "dsi"

    const-string/jumbo v2, "sid"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8

    const-string v2, "_dsi"

    const-string/jumbo v2, "id_s"

    const-string v2, "_ids"

    const-string/jumbo v2, "s_id"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_9

    :cond_8
    const-string v1, "bt"

    const-string/jumbo v1, "tb"

    const-string/jumbo v1, "tb"

    const-string/jumbo v1, "tb"

    :cond_9
    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "e=sam/_/pnpp"

    const-string/jumbo v3, "ppm/eaap/=n_"

    const-string v3, "e_amp/n&/am="

    const-string v3, "&app_name=\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "//"

    const-string v1, "//"

    const-string v1, "//"

    const-string v1, "\""

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v4, "nntooetxekeq"

    const-string/jumbo v4, "okxrtntnqeee"

    const-string/jumbo v4, "tre_kbeenoxt"

    const-string v4, "extern_token"

    new-array v7, v11, [Ljava/lang/String;

    const-string v1, "e_eensuntotk"

    const-string v1, "erskne_etton"

    const-string/jumbo v1, "rnete_opketx"

    const-string v1, "extern_token"

    aput-object v1, v7, v15

    const-string v1, "dic"

    const-string v1, "dic"

    const-string v1, "cdi"

    const-string v1, "cid"

    aput-object v1, v7, v14

    const-string/jumbo v1, "sdi"

    const-string v1, "dsi"

    const-string/jumbo v1, "ids"

    const-string/jumbo v1, "sid"

    aput-object v1, v7, v13

    const-string v1, "ds_i"

    const-string/jumbo v1, "id_s"

    const-string/jumbo v1, "s_id"

    aput-object v1, v7, v12

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object v5, v9

    move-object v5, v9

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    invoke-direct/range {v1 .. v7}, Lcom/alipay/sdk/app/PayTask;->m(ZZLjava/lang/String;Ljava/lang/StringBuilder;Ljava/util/Map;[Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_a

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_a
    const/4 v2, 0x1

    const/4 v3, 0x0

    :try_start_4
    const-string/jumbo v4, "vnqmpe"

    const-string/jumbo v4, "npvmea"

    const-string/jumbo v4, "vaspep"

    const-string v4, "appenv"

    new-array v7, v14, [Ljava/lang/String;

    const-string v1, "epnmoa"

    const-string/jumbo v1, "venpoa"

    const-string/jumbo v1, "nevaop"

    const-string v1, "appenv"

    aput-object v1, v7, v15

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    invoke-direct/range {v1 .. v7}, Lcom/alipay/sdk/app/PayTask;->m(ZZLjava/lang/String;Ljava/lang/StringBuilder;Ljava/util/Map;[Ljava/lang/String;)Z

    const-string v1, "_/pe&bkibld/aap_dln/yysn=ai/_h"

    const-string/jumbo v1, "p_//ybicpkls/ile&__aadhandy/=n"

    const-string v1, "hkaeciu=yydp/sipa/_a&a__n/ndl/"

    const-string v1, "&pay_channel_id=\"alipay_sdk\""

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Lcom/alipay/sdk/app/PayTask$c;

    invoke-direct {v1, v8, v10}, Lcom/alipay/sdk/app/PayTask$c;-><init>(Lcom/alipay/sdk/app/PayTask;Lcom/alipay/sdk/app/PayTask$a;)V

    const-string v2, "_luurnuprr"

    const-string/jumbo v2, "lurrntu_ru"

    const-string/jumbo v2, "uurnelr_qr"

    const-string/jumbo v2, "return_url"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/alipay/sdk/app/PayTask$c;->b(Ljava/lang/String;)V

    const-string v2, "h_uorlsp"

    const-string v2, "_oswuhrs"

    const-string/jumbo v2, "show_url"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/alipay/sdk/app/PayTask$c;->f(Ljava/lang/String;)V

    const-string v2, "ar_mqdip_oyd"

    const-string v2, "_d_yaoeiqprd"

    const-string v2, "a_yroepodir_"

    const-string/jumbo v2, "pay_order_id"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lcom/alipay/sdk/app/PayTask$c;->d(Ljava/lang/String;)V

    new-instance v0, Lx0/a;

    iget-object v2, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    invoke-direct {v0, v2, v3, v4}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "t&xeibs/c/bont"

    const-string/jumbo v3, "ixs/=/&ncbtoet"

    const-string v3, "=ozte/ut/cnxi&"

    const-string v3, "&bizcontext=\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "sc"

    const-string v3, "cs"

    const-string/jumbo v3, "sc"

    const-string/jumbo v3, "sc"

    const-string/jumbo v4, "t5aimhnpte"

    const-string/jumbo v4, "n5tmevatih"

    const-string/jumbo v4, "ioahvt5eqt"

    const-string v4, "h5tonative"

    invoke-virtual {v0, v3, v4}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "//"

    const-string v0, "//"

    const-string v0, "\""

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v8, Lcom/alipay/sdk/app/PayTask;->g:Ljava/util/Map;

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_b
    :try_start_5
    const-string/jumbo v0, "pcscmna.ytlysoite:opr/.phaoithm/e/tsabmmeliih./a"

    const-string/jumbo v0, "ymh.oaabpm/ripsithtlloa:/t.cpael/cmteimni/oyhes."

    const-string v0, "chtm:yatchmhebp//n/lpmy.atmooir/tlapisilsma.c.ei"

    const-string v0, "https://mclient.alipay.com/cashier/mobilepay.htm"

    invoke-virtual {v9, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_10

    const-string/jumbo v0, "paayocbich:at/el./plaicsr/bmleytptiio..enm/tmoh"

    const-string/jumbo v0, "pa.hib.cbi:cypresenltlmttaaht/imaimeoy/m/p/l.oc"

    const-string v0, "http://mclient.alipay.com/cashier/mobilepay.htm"

    invoke-virtual {v9, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_10

    invoke-static {}, Lcom/alipay/sdk/app/a;->b()Z

    move-result v0

    if-eqz v0, :cond_c

    const-string/jumbo v0, "sgbucb..a/a.typlimblheyoe/ivwmapmedemleihclrnoaiot"

    const-string/jumbo v0, "ibalyhusmaco.ph.eey/vdpebi.laalcnew/motltoimieimrg"

    const-string v0, "cmableugtyaisymle/ime.p/ecwiol.iohleocnha.rtapmdiv"

    const-string/jumbo v0, "mobileclientgw.alipaydev.com/cashier/mobilepay.htm"

    invoke-virtual {v9, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_c

    goto/16 :goto_4

    :cond_c
    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->l()Z

    move-result v0

    if-eqz v0, :cond_11

    const-string/jumbo v0, "l/?/acspohmam?app/o:ynomh.|/ay^otaltii//(pamcp//c.lya/)de//rl.d/i_b.p.itm//at"

    const-string/jumbo v0, "oyp/^pepy?c//./mm(:/abp/_/a./ta.ai/nadho.hp/al/smtc.iy/a/mailo//|?ttcioldlrm)"

    const-string/jumbo v0, "ptnyal//qm/lebtamaad/os_i/i/ym/p./^p/:looap|hy(./h?ir/)aci/oc.a.atmc.l?/pt//m"

    const-string v0, "^https?://(maliprod\\.alipay\\.com|mali\\.alipay\\.com)/batch_payment\\.do\\?"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "_usentlrqr"

    const-string/jumbo v1, "rru_telnqr"

    const-string v1, "_rumturlnr"

    const-string/jumbo v1, "return_url"

    invoke-virtual {v0, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string/jumbo v2, "ohslosw_"

    const-string v2, "_hsowsul"

    const-string v2, "_owhubsr"

    const-string/jumbo v2, "show_url"

    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "m_yorpuderd_"

    const-string v3, "_dpm_eirydor"

    const-string v3, "daiyep_pdr_r"

    const-string/jumbo v3, "pay_order_id"

    invoke-virtual {v0, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-array v4, v13, [Ljava/lang/String;

    const-string v5, "aoostn_rq"

    const-string/jumbo v5, "rnsaoeto_"

    const-string/jumbo v5, "snsdt_ora"

    const-string/jumbo v5, "trade_nos"

    invoke-virtual {v0, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v15

    const-string/jumbo v5, "rlnmyb_atopeida"

    const-string/jumbo v5, "tinpdb_lyarao_e"

    const-string/jumbo v5, "nlaooe_di_ptray"

    const-string v5, "alipay_trade_no"

    invoke-virtual {v0, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v14

    invoke-static {v4}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v5, v12, [Ljava/lang/String;

    const-string/jumbo v6, "uepadbIPay"

    const-string v6, "PdIaphueay"

    const-string/jumbo v6, "pseahyuPaI"

    const-string/jumbo v6, "payPhaseId"

    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v15

    const-string v6, "e_ipadsphpp_"

    const-string/jumbo v6, "sapd_e_ppahi"

    const-string/jumbo v6, "sdpie__hqpya"

    const-string/jumbo v6, "pay_phase_id"

    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v14

    const-string/jumbo v6, "uqs_ndi_ttolaer"

    const-string v6, "eoiratunqtdl_i_"

    const-string/jumbo v6, "ti_moueintdl_ro"

    const-string/jumbo v6, "out_relation_id"

    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v13

    invoke-static {v5}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-array v6, v11, [Ljava/lang/String;

    const-string v7, "epmpo_ns"

    const-string/jumbo v7, "masn_epp"

    const-string/jumbo v7, "peanpb_m"

    const-string v7, "app_name"

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v15

    const-string v7, "cid"

    const-string v7, "cdi"

    const-string/jumbo v7, "idc"

    const-string v7, "cid"

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_d

    const-string v7, "1ail68u"

    const-string v7, "1alm8i6"

    const-string/jumbo v7, "pi8al86"

    const-string v7, "ali1688"

    goto :goto_1

    :cond_d
    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    :goto_1
    aput-object v7, v6, v14

    const-string/jumbo v7, "sid"

    const-string/jumbo v7, "isd"

    const-string/jumbo v7, "isd"

    const-string/jumbo v7, "sid"

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_e

    const-string v7, "bt"

    const-string v7, "bt"

    const-string v7, "bt"

    const-string/jumbo v7, "tb"

    goto :goto_2

    :cond_e
    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    :goto_2
    aput-object v7, v6, v13

    const-string v7, "ds_i"

    const-string/jumbo v7, "s_id"

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_f

    const-string v7, "bt"

    const-string/jumbo v7, "tb"

    const-string/jumbo v7, "tb"

    goto :goto_3

    :cond_f
    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    :goto_3
    aput-object v7, v6, v12

    invoke-static {v6}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-array v7, v11, [Ljava/lang/String;

    const-string/jumbo v9, "texko_neqoen"

    const-string/jumbo v9, "nk_noeeeotxt"

    const-string/jumbo v9, "trstnxoene_e"

    const-string v9, "extern_token"

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v15

    const-string v9, "cid"

    const-string v9, "cid"

    const-string v9, "cdi"

    const-string v9, "cid"

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v14

    const-string v9, "dsi"

    const-string/jumbo v9, "sdi"

    const-string/jumbo v9, "sdi"

    const-string/jumbo v9, "sid"

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v13

    const-string v9, "_dis"

    const-string/jumbo v9, "s_id"

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v12

    invoke-static {v7}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v9, v14, [Ljava/lang/String;

    const-string/jumbo v10, "vepmnb"

    const-string/jumbo v10, "nveppb"

    const-string v10, "aenpop"

    const-string v10, "appenv"

    invoke-virtual {v0, v10}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v9, v15

    invoke-static {v9}, Lcom/alipay/sdk/app/PayTask;->k([Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_11

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_11

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_11

    new-instance v9, Lx0/a;

    iget-object v10, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v11, ""

    const-string v11, ""

    const-string v11, ""

    const-string v11, ""

    const-string v12, ""

    const-string v12, ""

    const-string v12, ""

    invoke-direct {v9, v10, v11, v12}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const-string v10, "/lt//b=e&siedlbn=ndn=p/i/a%e=/h/e/d/_so/eat_Tbb/p/yeee/sR_%a_r=Enm/Da%_cbaincv/asiixt%x/t=&aas/y&&zpz/%//&epa//s_i=dno//re&/hp_/&yrd_soz//t&A___tnps/kku/%/n=tyaep=ppestpua//y/"

    const-string/jumbo v10, "znrtsbu/i/op/p=ki_=aT/ed/s&nzn/__be&yek%svy////t%ps/lirdptl_azdh&/a/s%//sniptsa/tapya&eh/e%&ec%dpusAy_/s/e_m/nae&/anr/e/t/e&ppaebao//e_/_===xo/i=E=/%//a/_di&pbxD_cntRytn///==_"

    const-string/jumbo v10, "pn&/e%u/o/&&ny/b/=//_pvsks&tapo/p//t/%i///b&iay/=eam/l/ea//dih&dDxai=rn/et/n=x&s//_apce=ryEac_Ae/np=rszsndzTola%pb/=/n/e%pbas//e%d_t%td_ethyeR/e_=pi/snt/_///esk=y_pi__au_zst&a"

    const-string/jumbo v10, "trade_no=\"%s\"&pay_phase_id=\"%s\"&biz_type=\"trade\"&biz_sub_type=\"TRADE\"&app_name=\"%s\"&extern_token=\"%s\"&appenv=\"%s\"&pay_channel_id=\"alipay_sdk\"&bizcontext=\"%s\""

    const/4 v11, 0x6

    new-array v11, v11, [Ljava/lang/Object;

    aput-object v4, v11, v15

    aput-object v5, v11, v14

    aput-object v6, v11, v13

    const/4 v5, 0x3

    aput-object v7, v11, v5

    const/4 v5, 0x4

    aput-object v0, v11, v5

    const-string v0, "cs"

    const-string v0, "cs"

    const-string/jumbo v0, "sc"

    const-string/jumbo v0, "sc"

    const-string/jumbo v5, "ivhnoatpet"

    const-string v5, "evhan5iptt"

    const-string v5, "h5tonative"

    invoke-virtual {v9, v0, v5}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    aput-object v0, v11, v5

    invoke-static {v10, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v5, Lcom/alipay/sdk/app/PayTask$c;

    const/4 v6, 0x0

    invoke-direct {v5, v8, v6}, Lcom/alipay/sdk/app/PayTask$c;-><init>(Lcom/alipay/sdk/app/PayTask;Lcom/alipay/sdk/app/PayTask$a;)V

    invoke-virtual {v5, v1}, Lcom/alipay/sdk/app/PayTask$c;->b(Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Lcom/alipay/sdk/app/PayTask$c;->f(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Lcom/alipay/sdk/app/PayTask$c;->d(Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Lcom/alipay/sdk/app/PayTask$c;->h(Ljava/lang/String;)V

    iget-object v1, v8, Lcom/alipay/sdk/app/PayTask;->g:Ljava/util/Map;

    invoke-interface {v1, v0, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    monitor-exit p0

    return-object v0

    :cond_10
    :goto_4
    :try_start_6
    new-instance v0, Lx0/a;

    iget-object v1, v8, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    invoke-direct {v0, v1, v2, v3}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v1, "sc"

    const-string v1, "cs"

    const-string v1, "cs"

    const-string/jumbo v1, "sc"

    const-string/jumbo v2, "n5ioavteqq"

    const-string/jumbo v2, "tt5veaniqo"

    const-string v2, "etshvitan5"

    const-string v2, "h5tonative"

    invoke-virtual {v0, v1, v2}, Lx0/a;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string/jumbo v2, "lur"

    const-string/jumbo v2, "url"

    const-string/jumbo v2, "rul"

    const-string/jumbo v2, "url"

    invoke-virtual {v1, v2, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string/jumbo v2, "zsbmnxttec"

    const-string/jumbo v2, "ttsezxconb"

    const-string/jumbo v2, "zixeottobc"

    const-string v2, "bizcontext"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string/jumbo v0, "ot=s%bm=nfna_relexnei"

    const-string/jumbo v0, "nl%mnreet=e_a=osx_fin"

    const-string v0, "f=e%n_unrxa_etlnsowie"

    const-string/jumbo v0, "new_external_info==%s"

    new-array v2, v14, [Ljava/lang/Object;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v2, v15

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_7
    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_11
    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    monitor-exit p0

    return-object v0

    :catchall_1
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized fetchTradeToken()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v0, Lx0/a;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v3, "dkfrhTepaonotTe"

    const-string/jumbo v3, "theaonkfTerdeTo"

    const/4 v5, 0x5

    const-string v3, "TraoTfctqhdneee"

    const-string v3, "fetchTradeToken"

    const/4 v4, 0x2

    move v5, v4

    invoke-direct {v0, v1, v2, v3}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/g;->b(Lx0/a;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    monitor-exit p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    monitor-exit p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw v0
.end method

.method public getVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "1.s.5b"

    const-string v0, "715..b"

    const/4 v2, 0x7

    const-string v0, "..5m71"

    const-string v0, "15.7.7"

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public declared-synchronized h5Pay(Lx0/a;Ljava/lang/String;Z)Lcom/alipay/sdk/util/a;
    .locals 9

    const/4 v8, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v0, Lcom/alipay/sdk/util/a;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {v0}, Lcom/alipay/sdk/util/a;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/PayTask;->h(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v1, ";"

    const-string v1, ";"

    const/4 v8, 0x2

    const-string v1, ";"

    const-string v1, ";"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p3, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v1, Ljava/util/HashMap;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    array-length v2, p3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    const/4 v8, 0x6

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ge v4, v2, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    aget-object v5, p3, v4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v6, "={"

    const-string v6, "={"

    const/4 v8, 0x1

    const-string/jumbo v6, "{="

    const-string v6, "={"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ltz v6, :cond_0

    const/4 v8, 0x1

    invoke-virtual {v5, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-direct {p0, v5, v6}, Lcom/alipay/sdk/app/PayTask;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-interface {v1, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo p3, "ttusoeutlSas"

    const-string/jumbo p3, "resultStatus"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {v1, p3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p3, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string/jumbo p3, "lsStrbusatut"

    const-string p3, "atursluusStt"

    const-string p3, "elausrutstSt"

    const-string/jumbo p3, "resultStatus"

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-interface {v1, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    check-cast p3, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0, p3}, Lcom/alipay/sdk/util/a;->c(Ljava/lang/String;)V

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {p0, p2, v1}, Lcom/alipay/sdk/app/PayTask;->d(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, p2}, Lcom/alipay/sdk/util/a;->d(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/alipay/sdk/util/a;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-eqz p2, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo p2, "izb"

    const-string p2, "biz"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string p3, "UbClptmpHrE5"

    const-string/jumbo p3, "tHUr5yEpCmlb"

    const/4 v8, 0x3

    const-string p3, "5rCEbpylqtUH"

    const-string p3, "H5CbUrlEmpty"

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1, p2, p3, v1}, Lcom/alipay/sdk/app/statistic/a;->d(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_1

    :catchall_0
    move-exception p2

    :try_start_2
    const/4 v8, 0x5

    const/4 v7, 0x7

    const-string/jumbo p3, "ibz"

    const-string/jumbo p3, "ibz"

    const/4 v8, 0x5

    const-string/jumbo p3, "izb"

    const-string p3, "biz"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v1, "EbsHxq"

    const-string v1, "bHqxE5"

    const/4 v8, 0x7

    const-string/jumbo v1, "xEbmH5"

    const-string v1, "H5CbEx"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p1, p3, v1, p2}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p2}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_3
    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    monitor-exit p0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object v0

    :catchall_1
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    monitor-exit p0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    throw p1
.end method

.method public declared-synchronized pay(Ljava/lang/String;Z)Ljava/lang/String;
    .locals 5

    const/4 v3, 0x7

    const/4 v4, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Lx0/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "apy"

    const-string/jumbo v2, "pya"

    const/4 v4, 0x6

    const-string/jumbo v2, "pay"

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0, v1, p1, v2}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0, v0, p1, p2}, Lcom/alipay/sdk/app/PayTask;->h(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v3, 0x3

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    throw p1
.end method

.method public declared-synchronized payInterceptorWithUrl(Ljava/lang/String;ZLcom/alipay/sdk/app/H5PayCallback;)Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lcom/alipay/sdk/app/PayTask;->fetchOrderInfoFromH5PayUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "lpms"

    const/4 v4, 0x4

    const-string/jumbo v0, "lmps"

    const-string/jumbo v0, "mspl"

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "iestoptdrenc:"

    const-string/jumbo v2, "tcsrdtep:eine"

    const/4 v4, 0x4

    const-string v2, "e:dicbntpte r"

    const-string/jumbo v2, "intercepted: "

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lcom/alipay/sdk/util/d;->g(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Thread;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Lcom/alipay/sdk/app/PayTask$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/alipay/sdk/app/PayTask$a;-><init>(Lcom/alipay/sdk/app/PayTask;Ljava/lang/String;ZLcom/alipay/sdk/app/H5PayCallback;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    xor-int/lit8 p1, p1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    throw p1
.end method

.method public declared-synchronized payV2(Ljava/lang/String;Z)Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Lx0/a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/PayTask;->a:Landroid/app/Activity;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "2umaV"

    const-string v2, "aVpm2"

    const-string v2, "appVy"

    const-string/jumbo v2, "payV2"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, v1, p1, v2}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, v0, p1, p2}, Lcom/alipay/sdk/app/PayTask;->h(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0, p1}, Lcom/alipay/sdk/util/j;->d(Lx0/a;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    throw p1
.end method

.method public showLoading()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/a;->g()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method
