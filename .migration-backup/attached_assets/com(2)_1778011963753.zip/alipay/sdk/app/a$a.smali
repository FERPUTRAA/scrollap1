.class public final enum Lcom/alipay/sdk/app/a$a;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/alipay/sdk/app/a$a;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/alipay/sdk/app/a$a;

.field public static final enum b:Lcom/alipay/sdk/app/a$a;

.field private static final synthetic c:[Lcom/alipay/sdk/app/a$a;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v0, Lcom/alipay/sdk/app/a$a;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v1, "NEssLI"

    const-string v1, "NEsILO"

    const/4 v6, 0x5

    const-string v1, "NLEmOI"

    const-string v1, "ONLINE"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2}, Lcom/alipay/sdk/app/a$a;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x5

    sput-object v0, Lcom/alipay/sdk/app/a$a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Lcom/alipay/sdk/app/a$a;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v3, "XSBNomA"

    const-string v3, "BAXmDSN"

    const/4 v6, 0x0

    const-string v3, "ABNDSbX"

    const-string v3, "SANDBOX"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-direct {v1, v3, v4}, Lcom/alipay/sdk/app/a$a;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    sput-object v1, Lcom/alipay/sdk/app/a$a;->b:Lcom/alipay/sdk/app/a$a;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-array v3, v3, [Lcom/alipay/sdk/app/a$a;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    aput-object v0, v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    aput-object v1, v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    sput-object v3, Lcom/alipay/sdk/app/a$a;->c:[Lcom/alipay/sdk/app/a$a;

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/alipay/sdk/app/a$a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~l@/-u ~~@t~y~ @o ~m @@i t@idc~~M@su4@~ooi@~ S. K@ ~/~ 1 b~nf b ~v@ ~ ~@obfoa@@~@or@~@~@@@ ~ ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const-class v0, Lcom/alipay/sdk/app/a$a;

    const-class v0, Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x2

    const-class v0, Lcom/alipay/sdk/app/a$a;

    const-class v0, Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lcom/alipay/sdk/app/a$a;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/alipay/sdk/app/a$a;->c:[Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/alipay/sdk/app/a$a;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, [Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method
