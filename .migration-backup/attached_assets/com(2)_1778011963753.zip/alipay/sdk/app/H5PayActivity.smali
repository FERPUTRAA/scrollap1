.class public Lcom/alipay/sdk/app/H5PayActivity;
.super Landroid/app/Activity;


# instance fields
.field private a:Lcom/alipay/sdk/widget/c;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Z

.field private g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v1, 0x7

    return-void
.end method

.method private b()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "yis~~bf ~@ M~@ @oo o@ ~4sli~@a ~ oc~ bi n@@l@SK@~~@u~@~1@@@ /~~ @~bf .~ot @@v/t~ ~o~@ d~~r@~ m@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x1

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-super {p0, v0}, Landroid/app/Activity;->requestWindowFeature(I)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v0, Lcom/alipay/sdk/app/PayTask;->h:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->notify()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :catch_0
    :goto_0
    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-void

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw v1
.end method

.method public finish()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->a()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public onBackPressed()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/app/H5PayActivity;->a:Lcom/alipay/sdk/widget/c;

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/c;->o()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/c;->n()Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/c;->n()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/alipay/sdk/app/d;->c(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/alipay/sdk/app/H5PayActivity;->b()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1}, Lx0/a$a;->a(Landroid/content/Intent;)Lx0/a;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->j()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lcom/alipay/sdk/app/H5PayActivity;->setRequestedOrientation(I)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Lcom/alipay/sdk/app/H5PayActivity;->setRequestedOrientation(I)V

    :goto_0
    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v1, "rul"

    const/4 v5, 0x4

    const-string/jumbo v1, "rul"

    const-string/jumbo v1, "url"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->b:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/alipay/sdk/util/l;->F(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v1, "ecimks"

    const-string/jumbo v1, "icsoek"

    const/4 v5, 0x5

    const-string v1, "ekoioc"

    const-string v1, "cookie"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->d:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "edmotb"

    const-string v1, "ehomtd"

    const/4 v5, 0x2

    const-string/jumbo v1, "uodhtm"

    const-string/jumbo v1, "method"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->c:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v1, "otpte"

    const-string v1, "eltto"

    const/4 v5, 0x2

    const-string/jumbo v1, "litqe"

    const-string/jumbo v1, "title"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->e:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v1, "nsioebv"

    const-string/jumbo v1, "rossnie"

    const-string/jumbo v1, "version"

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v2, "v1"

    const-string v2, "1v"

    const/4 v5, 0x4

    const-string v2, "1v"

    const-string/jumbo v2, "v1"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->g:Ljava/lang/String;

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    const-string v1, "eximtsciau"

    const-string/jumbo v1, "iscieaubtx"

    const/4 v5, 0x2

    const-string/jumbo v1, "iatiosbkec"

    const-string v1, "backisexit"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-boolean v0, p0, Lcom/alipay/sdk/app/H5PayActivity;->f:Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Lcom/alipay/sdk/widget/d;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->g:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v0, p0, p1, v1}, Lcom/alipay/sdk/widget/d;-><init>(Landroid/app/Activity;Lx0/a;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->e:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/alipay/sdk/app/H5PayActivity;->c:Ljava/lang/String;

    const/4 v5, 0x2

    iget-boolean v3, p0, Lcom/alipay/sdk/app/H5PayActivity;->f:Z

    const/4 v4, 0x5

    move v5, v4

    invoke-virtual {v0, v1, v2, v3}, Lcom/alipay/sdk/widget/d;->r(Ljava/lang/String;Ljava/lang/String;Z)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/alipay/sdk/app/H5PayActivity;->d:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/alipay/sdk/widget/c;->m(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/alipay/sdk/app/H5PayActivity;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/alipay/sdk/widget/d;->l(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/alipay/sdk/app/H5PayActivity;->a:Lcom/alipay/sdk/widget/c;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v1, "izb"

    const-string/jumbo v1, "izb"

    const/4 v5, 0x2

    const-string v1, "bzi"

    const-string v1, "biz"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v2, "sAtlxbeGEteppanlp"

    const-string/jumbo v2, "ltaAxpeplsnpGetdE"

    const/4 v5, 0x7

    const-string v2, "EnGAlautlIdetspep"

    const-string v2, "GetInstalledAppEx"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1, v1, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :catch_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void

    :catch_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void
.end method

.method protected onDestroy()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/app/H5PayActivity;->a:Lcom/alipay/sdk/widget/c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/c;->j()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setRequestedOrientation(I)V
    .locals 5

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-super {p0, p1}, Landroid/app/Activity;->setRequestedOrientation(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lx0/a$a;->a(Landroid/content/Intent;)Lx0/a;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "zbi"

    const-string/jumbo v1, "zib"

    const/4 v4, 0x2

    const-string/jumbo v1, "zbi"

    const-string v1, "biz"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "ssEaanyp5yloqairaDPAtr"

    const-string/jumbo v2, "raEAPDrnqalaryis5yotsa"

    const/4 v4, 0x0

    const-string v2, "EDsPHlyoqtAsyaairrnaa5"

    const-string v2, "H5PayDataAnalysisError"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method
