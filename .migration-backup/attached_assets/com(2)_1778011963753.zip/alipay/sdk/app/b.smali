.class public final Lcom/alipay/sdk/app/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/b$d;,
        Lcom/alipay/sdk/app/b$c;,
        Lcom/alipay/sdk/app/b$b;
    }
.end annotation


# static fields
.field private static final e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/alipay/sdk/app/b$c;",
            ">;"
        }
    .end annotation
.end field

.field private static f:J = 0x0L

.field public static final g:I = 0x2328

.field public static final h:I = 0x1388

.field public static final i:I = 0xfa1

.field public static final j:I = 0xfa0

.field private static final k:I = 0x7a


# instance fields
.field private volatile a:Z

.field private final b:Landroid/app/Activity;

.field private c:Lcom/alipay/sdk/app/b$c;

.field private final d:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x2

    sput-object v0, Lcom/alipay/sdk/app/b;->e:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-wide v0, Lcom/alipay/sdk/app/b;->f:J

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    move v2, v0

    move v2, v0

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/alipay/sdk/app/b;->a:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    const/4 v3, 0x0

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic a(Lcom/alipay/sdk/app/b;)Lcom/alipay/sdk/app/b$c;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s b~f~at-~@o~ i  ~~b@ @~ @~o ~s@~ ~4/bSnu~@ yt~M1o~@~l~@m @cor lK@@i~o@~ .@ o@@~@di@v@f~ ~~ @/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/alipay/sdk/app/b;->c:Lcom/alipay/sdk/app/b$c;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method private b(JLjava/lang/String;Lcom/alipay/sdk/app/b$b;Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "Teamttssr"

    const-string v1, "aTssrttem"

    const/4 v3, 0x2

    const-string/jumbo v1, "tmsaoiteT"

    const-string/jumbo v1, "startTime"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x0

    const-string p1, "enossbi"

    const-string/jumbo p1, "nsimoes"

    const/4 v3, 0x6

    const-string/jumbo p1, "ossnieu"

    const-string/jumbo p1, "session"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo p2, "pecpkao"

    const-string p2, "gkpcoea"

    const/4 v3, 0x1

    const-string p2, "cqepgka"

    const-string/jumbo p2, "package"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p4, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string p1, "Ipsad"

    const-string p1, "baIdp"

    const/4 v3, 0x4

    const-string p1, "apImp"

    const-string p1, "appId"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p4}, Lcom/alipay/sdk/app/b$b;->a(Lcom/alipay/sdk/app/b$b;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo p1, "isreooVdsu"

    const-string p1, "dkorVeuiss"

    const/4 v3, 0x7

    const-string/jumbo p1, "idsekbrVos"

    const-string/jumbo p1, "sdkVersion"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p2, "7..3h.u.p"

    const-string p2, ".7..7.hp3"

    const/4 v3, 0x4

    const-string p2, "37a7...p."

    const-string p2, "h.a.3.7.7"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string p1, "LRqpqm"

    const-string p1, "LqqRmp"

    const/4 v3, 0x5

    const-string/jumbo p1, "qRsLpU"

    const-string/jumbo p1, "mqpURL"

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p2, "FTs-8"

    const/4 v3, 0x5

    const-string p2, "-FUm8"

    const-string p2, "UTF-8"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p2, 0x2

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p1, p2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    return-object p1
.end method

.method private c(Lcom/alipay/sdk/app/b$b;Ljava/util/Map;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alipay/sdk/app/b$b;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Landroid/net/Uri$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "lasmapi"

    const/4 v4, 0x3

    const-string/jumbo v1, "syapoal"

    const-string v1, "alipays"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "aloaobppftm"

    const-string v1, "afpioopltam"

    const/4 v4, 0x4

    const-string/jumbo v1, "tipaopufarl"

    const-string/jumbo v1, "platformapi"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "tprtaapp"

    const-string v1, "attapbrp"

    const/4 v4, 0x3

    const-string/jumbo v1, "qpptrsat"

    const-string/jumbo v1, "startapp"

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v1, "daspI"

    const-string/jumbo v1, "pudIa"

    const-string v1, "dapmI"

    const-string v1, "appId"

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/alipay/sdk/app/b$b;->a(Lcom/alipay/sdk/app/b$b;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v1, Lcom/alipay/sdk/app/b$a;->a:[I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    aget p1, v1, p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-eq p1, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo p1, "poClopearTp"

    const-string p1, "eppoClrpTap"

    const/4 v4, 0x0

    const-string p1, "aTpapbeplro"

    const-string p1, "appClearTop"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const-string/jumbo v1, "sufqe"

    const-string/jumbo v1, "sefql"

    const/4 v4, 0x0

    const-string/jumbo v1, "lapef"

    const-string v1, "false"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, p1, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "sptluptsqMtA"

    const-string v1, "MtsstpAplrut"

    const/4 v4, 0x3

    const-string/jumbo v1, "upsrpttlAstM"

    const-string/jumbo v1, "startMultApp"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, "SYE"

    const-string v2, "YES"

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {p1, v1, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast p2, Ljava/util/Map$Entry;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-interface {p2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast p2, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v3, 0x0

    move v4, v3

    goto :goto_1

    :cond_1
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string p2, "bp mszmmiyTneis"

    const-string/jumbo p2, "ibemiTnpsi mzsy"

    const/4 v4, 0x6

    const-string p2, "bsnyoi impgTzse"

    const-string/jumbo p2, "missing bizType"

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1
.end method

.method static d(Ljava/lang/String;ILjava/lang/String;Landroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/alipay/sdk/app/b;->e:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p0, Lcom/alipay/sdk/app/b$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p0, p1, p2, p3}, Lcom/alipay/sdk/app/b$c;->a(ILjava/lang/String;Landroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method private e(Lx0/a;Ljava/lang/String;Lcom/alipay/sdk/app/b$b;Ljava/util/Map;Z)Z
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lx0/a;",
            "Ljava/lang/String;",
            "Lcom/alipay/sdk/app/b$b;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    const-string/jumbo v9, "izb"

    const-string/jumbo v9, "izb"

    const-string v9, "biz"

    const-string v9, "biz"

    iget-boolean v0, v7, Lcom/alipay/sdk/app/b;->a:Z

    const/4 v10, 0x1

    if-eqz v0, :cond_0

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    new-instance v8, Lcom/alipay/sdk/app/b$d;

    const/16 v3, 0xfa0

    const-string v4, "8u/A/b7oha/btceuu7ue68Ts/45uf22/5k2n 85p 6Od"

    const-string v4, "//u/ouu2p2ake uTc dtOh8//4e2f5s586b7nA6u758u"

    const-string/jumbo v4, "u7fp//u/ne65kh878Au 56suO8u/22/T2ueb a5u84td"

    const-string/jumbo v4, "\u8be5 OpenAuthTask \u5df2\u5728\u6267\u884c"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v10

    :cond_0
    iput-boolean v10, v7, Lcom/alipay/sdk/app/b;->a:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    sget-wide v0, Lcom/alipay/sdk/app/b;->f:J

    sub-long v0, v11, v0

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    cmp-long v0, v0, v2

    if-gtz v0, :cond_1

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    new-instance v8, Lcom/alipay/sdk/app/b$d;

    const/16 v3, 0x1388

    const-string v4, "8uu2/ucp5dd5uu9580/db165s 39/ef/1"

    const-string v4, "5uu/5b uu/dd898c31/d5/146s02efu59"

    const-string v4, "5u95/d5/q5128u0d 496udeu/fs/31u/c"

    const-string v4, "3s \u5185\u91cd\u590d\u652f\u4ed8"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v10

    :cond_1
    sput-wide v11, Lcom/alipay/sdk/app/b;->f:J

    const-string v13, ""

    const-string v13, ""

    const-string v13, ""

    const-string v13, ""

    invoke-static {v13}, Lcom/alipay/sdk/app/c;->b(Ljava/lang/String;)V

    const/16 v0, 0x20

    invoke-static {v0}, Lcom/alipay/sdk/util/l;->e(I)Ljava/lang/String;

    move-result-object v14

    new-instance v1, Ljava/util/HashMap;

    move-object/from16 v0, p4

    move-object/from16 v0, p4

    move-object/from16 v0, p4

    invoke-direct {v1, v0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "PgsqmkuapN"

    const-string v2, "NqPepgukma"

    const-string/jumbo v2, "kpemgPammq"

    const-string/jumbo v2, "mqpPkgName"

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "dks"

    const-string/jumbo v0, "skd"

    const-string/jumbo v0, "skd"

    const-string/jumbo v0, "sdk"

    const-string/jumbo v2, "pecqoepS"

    const-string/jumbo v2, "neSqepcp"

    const-string/jumbo v2, "nmeScbqp"

    const-string/jumbo v2, "mqpScene"

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->w()Ljava/util/List;

    move-result-object v0

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v3

    iget-boolean v3, v3, Lcom/alipay/sdk/data/a;->g:Z

    if-eqz v3, :cond_2

    if-nez v0, :cond_3

    :cond_2
    sget-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    :cond_3
    iget-object v3, v7, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    invoke-static {v8, v3, v0}, Lcom/alipay/sdk/util/l;->c(Lx0/a;Landroid/content/Context;Ljava/util/List;)Lcom/alipay/sdk/util/l$b;

    move-result-object v15

    const/16 v16, 0x0

    if-eqz v15, :cond_6

    invoke-virtual {v15, v8}, Lcom/alipay/sdk/util/l$b;->b(Lx0/a;)Z

    move-result v0

    if-nez v0, :cond_6

    invoke-virtual {v15}, Lcom/alipay/sdk/util/l$b;->a()Z

    move-result v0

    if-nez v0, :cond_6

    iget-object v0, v15, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    if-eqz v0, :cond_6

    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    const/16 v3, 0x7a

    if-ge v0, v3, :cond_4

    goto/16 :goto_3

    :cond_4
    :try_start_0
    invoke-static/range {p1 .. p1}, Lx0/a;->e(Lx0/a;)Ljava/util/HashMap;

    move-result-object v0

    const-string v2, "eeqhcsus_"

    const-string/jumbo v2, "mes_ceshq"

    const-string/jumbo v2, "shmesetpc"

    const-string/jumbo v2, "ts_scheme"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v0}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    const-string/jumbo v0, "oLspcq"

    const-string/jumbo v0, "pLqcmo"

    const-string/jumbo v0, "mqpLoc"

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_1
    const-string/jumbo v2, "ncsxuhELpAtoe"

    const-string v2, "OpenAuthLocEx"

    invoke-static {v8, v9, v2, v0}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    invoke-direct {v7, v5, v1}, Lcom/alipay/sdk/app/b;->c(Lcom/alipay/sdk/app/b$b;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    sget-object v0, Lcom/alipay/sdk/app/b;->e:Ljava/util/Map;

    iget-object v1, v7, Lcom/alipay/sdk/app/b;->c:Lcom/alipay/sdk/app/b$c;

    invoke-interface {v0, v14, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-wide v2, v11

    move-object v4, v14

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    :try_start_2
    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b;->b(JLjava/lang/String;Lcom/alipay/sdk/app/b$b;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const-string v0, "NJxmES"

    const-string v0, "JNxmES"

    const-string v0, "ONESox"

    const-string v0, "JSONEx"

    invoke-static {v8, v9, v0, v1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v0, 0x0

    :goto_1
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    new-instance v8, Lcom/alipay/sdk/app/b$d;

    const/16 v3, 0xfa0

    const-string v4, "5/5/6buf9/95/1ucbo23e8uu"

    const-string v4, "385uo9/f1u/5905/6ec/2uub"

    const-string v4, "2/0/5uu59u/bf/9c678u531u"

    const-string/jumbo v4, "\u53c2\u6570\u9519\u8bef"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v10

    :cond_5
    new-instance v1, Landroid/net/Uri$Builder;

    invoke-direct {v1}, Landroid/net/Uri$Builder;-><init>()V

    const-string/jumbo v2, "paipaly"

    const-string v2, "alipays"

    invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v1

    const-string/jumbo v2, "lrtamfopqab"

    const-string/jumbo v2, "lpatpbarofm"

    const-string/jumbo v2, "pmspaiatrof"

    const-string/jumbo v2, "platformapi"

    invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v1

    const-string/jumbo v2, "uramptat"

    const-string/jumbo v2, "tasptrua"

    const-string/jumbo v2, "sattorap"

    const-string/jumbo v2, "startapp"

    invoke-virtual {v1, v2}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v1

    const-string v2, "bpIad"

    const-string/jumbo v2, "papdI"

    const-string v2, "appId"

    const-string v3, "21q010u2"

    const-string/jumbo v3, "q0101220"

    const-string v3, "1922000p"

    const-string v3, "20001129"

    invoke-virtual {v1, v2, v3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v1

    const-string v2, "aqyspol"

    const-string/jumbo v2, "lpsdyao"

    const-string/jumbo v2, "pdsloaa"

    const-string/jumbo v2, "payload"

    invoke-virtual {v1, v2, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    new-instance v1, Landroid/content/Intent;

    const-string/jumbo v2, "oaimIoVEWaiicndmtn.tn.tn.e"

    const-string v2, "cd.madIVnioWe.tiEitantnon."

    const-string v2, "andeoWndtto..crEa.nVniioiI"

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v0, 0x10000000

    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    iget-object v0, v15, Lcom/alipay/sdk/util/l$b;->a:Landroid/content/pm/PackageInfo;

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :try_start_3
    const-string v0, "PitpebSOnrgnta"

    const-string v0, "PgOpenStarting"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v8, v9, v0, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v8, v14}, Lx0/a$a;->d(Lx0/a;Ljava/lang/String;)V

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v0

    const-string/jumbo v1, "traxEeutSaolW"

    const-string/jumbo v1, "txeEolarSWlta"

    const-string v1, "StartWalletEx"

    invoke-static {v8, v9, v1, v0}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_2
    return v16

    :catchall_2
    iget-object v0, v7, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    new-instance v8, Lcom/alipay/sdk/app/b$d;

    const/16 v3, 0xfa0

    const-string v4, "a1b351up814c/29eu/b/u55e62/au/u9uf70"

    const-string v4, "3u/uub456/uac8u10b221eu91/5e7f595//a"

    const-string v4, "e2u53u5aq45u1299//1u/b6u10uae7///f85"

    const-string/jumbo v4, "\u4e1a\u52a1\u53c2\u6570\u9519\u8bef"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v10

    :cond_6
    :goto_3
    if-eqz p5, :cond_7

    invoke-static/range {p2 .. p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v3, "mhseumqSp"

    const-string v3, "Smeqheupm"

    const-string/jumbo v3, "meqmepchS"

    const-string/jumbo v3, "mqpScheme"

    invoke-interface {v1, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "NmfyooepaiNmt"

    const-string/jumbo v0, "mqpNotifyName"

    invoke-interface {v1, v0, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "pinnabg"

    const-string/jumbo v0, "pdanign"

    const-string/jumbo v0, "idnalnu"

    const-string/jumbo v0, "landing"

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct {v7, v5, v1}, Lcom/alipay/sdk/app/b;->c(Lcom/alipay/sdk/app/b$b;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/content/Intent;

    iget-object v2, v7, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    const-class v3, Lcom/alipay/sdk/app/H5OpenAuthActivity;

    const-class v3, Lcom/alipay/sdk/app/H5OpenAuthActivity;

    const-class v3, Lcom/alipay/sdk/app/H5OpenAuthActivity;

    const-class v3, Lcom/alipay/sdk/app/H5OpenAuthActivity;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-array v2, v10, [Ljava/lang/Object;

    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    aput-object v0, v2, v16

    const-string v0, "hs:pa/?oqlem/dcs%h/arpsesrpt=/cnmteiy/.ei"

    const-string/jumbo v0, "mtee=//pey/:s.sc.i/?ptpedoh/s%hcnsiraprla"

    const-string v0, "https://render.alipay.com/p/s/i?scheme=%s"

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v2, "rul"

    const-string/jumbo v2, "rul"

    const-string/jumbo v2, "rlu"

    const-string/jumbo v2, "url"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {v8, v1}, Lx0/a$a;->c(Lx0/a;Landroid/content/Intent;)V

    iget-object v0, v7, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return v16

    :cond_7
    iget-object v0, v7, Lcom/alipay/sdk/app/b;->d:Landroid/os/Handler;

    new-instance v8, Lcom/alipay/sdk/app/b$d;

    const/16 v3, 0xfa1

    const-string v4, "4a2u9uf1q9fu58bdd/5/50ee97//ucb/ue5///569uud5/ubu628/u8/48667278bu"

    const-string/jumbo v4, "\u652f\u4ed8\u5b9d\u672a\u5b89\u88c5\u6216\u7b7e\u540d\u9519\u8bef"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    invoke-direct/range {v1 .. v6}, Lcom/alipay/sdk/app/b$d;-><init>(Lcom/alipay/sdk/app/b;ILjava/lang/String;Landroid/os/Bundle;Lcom/alipay/sdk/app/b$a;)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v10
.end method


# virtual methods
.method public f(Ljava/lang/String;Lcom/alipay/sdk/app/b$b;Ljava/util/Map;Lcom/alipay/sdk/app/b$c;Z)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/alipay/sdk/app/b$b;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/alipay/sdk/app/b$c;",
            "Z)V"
        }
    .end annotation

    new-instance v6, Lx0/a;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v3, "ao-"

    const-string v3, "ao-"

    const/4 v8, 0x4

    const-string/jumbo v3, "oa-"

    const/4 v7, 0x4

    or-int/2addr v8, v7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    invoke-direct {v6, v0, v1, v2}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput-object p4, p0, Lcom/alipay/sdk/app/b;->c:Lcom/alipay/sdk/app/b$c;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v5, p5

    move v5, p5

    const/4 v8, 0x1

    move v5, p5

    move v5, p5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/alipay/sdk/app/b;->e(Lx0/a;Ljava/lang/String;Lcom/alipay/sdk/app/b$b;Ljava/util/Map;Z)Z

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz p1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/alipay/sdk/app/b;->b:Landroid/app/Activity;

    const/4 v8, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v8, 0x4

    const-string p2, ""

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object p3, v6, Lx0/a;->d:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p1, v6, p2, p3}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-void
.end method
