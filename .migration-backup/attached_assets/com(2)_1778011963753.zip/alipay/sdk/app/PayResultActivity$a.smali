.class final Lcom/alipay/sdk/app/PayResultActivity$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/alipay/sdk/app/PayResultActivity;->a(Landroid/app/Activity;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/app/PayResultActivity$a;->a:Landroid/app/Activity;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S~s@K/ @o @o~~t~~f  ~ M ~lr~~asb ~~4@@o~bt ~/@~ -~f bo@ ni@@ y@@~vii@ ~dl.o@m@cu~  @@@~@~o@ ~~@1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/app/PayResultActivity$a;->a:Landroid/app/Activity;

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
