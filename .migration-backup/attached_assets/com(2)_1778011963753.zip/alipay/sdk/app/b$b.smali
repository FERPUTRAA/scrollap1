.class public final enum Lcom/alipay/sdk/app/b$b;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/alipay/sdk/app/b$b;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/alipay/sdk/app/b$b;

.field public static final enum b:Lcom/alipay/sdk/app/b$b;

.field public static final enum c:Lcom/alipay/sdk/app/b$b;

.field private static final synthetic d:[Lcom/alipay/sdk/app/b$b;


# instance fields
.field private appId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v0, Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string v1, "90s0s220"

    const-string v1, "90s02002"

    const/4 v9, 0x2

    const-string v1, "902m2000"

    const-string v1, "20000920"

    const/4 v8, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string v2, "cviIoeo"

    const-string/jumbo v2, "vcomiIe"

    const/4 v9, 0x4

    const-string/jumbo v2, "oIvinbc"

    const-string v2, "Invoice"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x4

    invoke-direct {v0, v2, v3, v1}, Lcom/alipay/sdk/app/b$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    sput-object v0, Lcom/alipay/sdk/app/b$b;->a:Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    new-instance v1, Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x3

    const-string v2, "0o0020u7"

    const-string v2, "0007o260"

    const/4 v9, 0x7

    const-string v2, "7006000p"

    const-string v2, "20000067"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v4, "ActhAobuqtc"

    const-string v4, "ccAtubAthou"

    const/4 v9, 0x1

    const-string v4, "AccountAuth"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v5, 0x1

    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v1, v4, v5, v2}, Lcom/alipay/sdk/app/b$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    sput-object v1, Lcom/alipay/sdk/app/b$b;->b:Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    new-instance v2, Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v4, "10s0u070"

    const-string v4, "000507u1"

    const/4 v9, 0x0

    const-string v4, "610m0705"

    const-string v4, "60000157"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v6, "etpuoc"

    const-string/jumbo v6, "tpuecd"

    const/4 v9, 0x7

    const-string v6, "cDtueb"

    const-string v6, "Deduct"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v2, v6, v7, v4}, Lcom/alipay/sdk/app/b$b;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    sput-object v2, Lcom/alipay/sdk/app/b$b;->c:Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v4, 0x3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-array v4, v4, [Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    aput-object v0, v4, v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    aput-object v1, v4, v5

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    aput-object v2, v4, v7

    const/4 v9, 0x4

    sput-object v4, Lcom/alipay/sdk/app/b$b;->d:[Lcom/alipay/sdk/app/b$b;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/alipay/sdk/app/b$b;->appId:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method static synthetic a(Lcom/alipay/sdk/app/b$b;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~4~@@u~~~~vi @ f~.b M~mS@ t@@r/n-l~t/~ ~o oi ~@~ if~@ a@~  c@ ~ ~@l@ @~1 ~oubdbo@s @ @@o~@K~~yo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/alipay/sdk/app/b$b;->appId:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/alipay/sdk/app/b$b;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-class v0, Lcom/alipay/sdk/app/b$b;

    const-class v0, Lcom/alipay/sdk/app/b$b;

    const/4 v2, 0x7

    const-class v0, Lcom/alipay/sdk/app/b$b;

    const-class v0, Lcom/alipay/sdk/app/b$b;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Lcom/alipay/sdk/app/b$b;

    const/4 v1, 0x6

    move v2, v1

    return-object p0
.end method

.method public static values()[Lcom/alipay/sdk/app/b$b;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/alipay/sdk/app/b$b;->d:[Lcom/alipay/sdk/app/b$b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lcom/alipay/sdk/app/b$b;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    check-cast v0, [Lcom/alipay/sdk/app/b$b;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method
