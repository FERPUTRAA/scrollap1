.class public Lcom/alipay/sdk/app/AuthTask;
.super Ljava/lang/Object;


# static fields
.field static final c:Ljava/lang/Object;


# instance fields
.field private a:Landroid/app/Activity;

.field private b:Lcom/alipay/sdk/widget/a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-class v0, Lcom/alipay/sdk/util/f;

    const-class v0, Lcom/alipay/sdk/util/f;

    const/4 v2, 0x7

    const-class v0, Lcom/alipay/sdk/util/f;

    const-class v0, Lcom/alipay/sdk/util/f;

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    sput-object v0, Lcom/alipay/sdk/app/AuthTask;->c:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Lcom/alipay/sdk/widget/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "8usd63968/uub43b5462fb7us/d5u53//8/e"

    const-string v1, "bus8e6db844589u/5/56f//3du2u6/u3b/73"

    const/4 v3, 0x3

    const-string v1, "8/bm/533e28/7b4u/u8du396/4bu56u5f/du"

    const-string/jumbo v1, "\u53bb\u652f\u4ed8\u5b9d\u6388\u6743"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1}, Lcom/alipay/sdk/widget/a;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method private a()Lcom/alipay/sdk/util/f$d;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~4f ol@/ ~db ~   @~yioo@n~@@~~ @i~~@o ~~@ .@i b~ @~@v~@ Kr~~1u@~ ~o s ocMa/bol~tfS@@@t@~@~ ~m- @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/alipay/sdk/app/AuthTask$a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/alipay/sdk/app/AuthTask$a;-><init>(Lcom/alipay/sdk/app/AuthTask;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method private b(Landroid/app/Activity;Ljava/lang/String;Lx0/a;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p3, p2}, Lx0/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->w()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    iget-boolean v1, v1, Lcom/alipay/sdk/data/a;->g:Z

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v0, Lcom/alipay/sdk/app/c;->d:Ljava/util/List;

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p3, v1, v0}, Lcom/alipay/sdk/util/l;->y(Lx0/a;Landroid/content/Context;Ljava/util/List;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "zib"

    const-string/jumbo v1, "zib"

    const/4 v4, 0x4

    const-string v1, "biz"

    const-string v1, "biz"

    const/4 v4, 0x5

    if-eqz v0, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/alipay/sdk/util/f;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->a()Lcom/alipay/sdk/util/f$d;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, p1, p3, v2}, Lcom/alipay/sdk/util/f;-><init>(Landroid/app/Activity;Lx0/a;Lcom/alipay/sdk/util/f$d;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Lcom/alipay/sdk/util/f;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, "dmifab"

    const-string/jumbo v2, "ifdmae"

    const/4 v4, 0x3

    const-string/jumbo v2, "uialef"

    const-string v2, "failed"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v2, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v2, "moshieapedcfe"

    const-string v2, "ehcfodeslmiea"

    const/4 v4, 0x0

    const-string v2, "edfhicsaqml_e"

    const-string/jumbo v2, "scheme_failed"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0

    :cond_4
    :goto_0
    const/4 v3, 0x6

    const-string v0, "C5sibdaLoleHBdn"

    const-string v0, "5nlCgbBadeiodHL"

    const/4 v4, 0x4

    const-string/jumbo v0, "lLemoHB5nCgadid"

    const-string v0, "LogBindCalledH5"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p3, v1, v0}, Lcom/alipay/sdk/app/statistic/a;->c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/AuthTask;->e(Landroid/app/Activity;Ljava/lang/String;Lx0/a;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p1

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v0, "oagloHdu5Ll"

    const-string v0, "HlC5louLdga"

    const-string/jumbo v0, "lHeoCb5aldg"

    const-string v0, "LogCalledH5"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p3, v1, v0}, Lcom/alipay/sdk/app/statistic/a;->c(Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/alipay/sdk/app/AuthTask;->e(Landroid/app/Activity;Ljava/lang/String;Lx0/a;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    return-object p1
.end method

.method private c(Lx0/a;Lw0/b;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p2}, Lw0/b;->g()[Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    aget-object p2, p2, v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "lur"

    const-string/jumbo v1, "url"

    const/4 v4, 0x6

    const-string/jumbo v1, "url"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p2, Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-class v2, Lcom/alipay/sdk/app/H5AuthActivity;

    const-class v2, Lcom/alipay/sdk/app/H5AuthActivity;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p2, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v3, 0x6

    move v4, v3

    invoke-static {p1, p2}, Lx0/a$a;->c(Lx0/a;Landroid/content/Intent;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object p1, Lcom/alipay/sdk/app/AuthTask;->c:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-enter p1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->wait()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/alipay/sdk/app/d;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eqz p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p1

    :catchall_0
    move-exception p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    :try_start_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p2

    :goto_0
    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p2
.end method

.method static synthetic d(Lcom/alipay/sdk/app/AuthTask;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v1, 0x2

    return-void
.end method

.method private e(Landroid/app/Activity;Ljava/lang/String;Lx0/a;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->f()V

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/alipay/sdk/packet/impl/a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/alipay/sdk/packet/impl/a;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p3, p1, p2}, Lcom/alipay/sdk/packet/e;->b(Lx0/a;Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/sdk/packet/b;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/alipay/sdk/packet/b;->c()Lorg/json/JSONObject;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo p2, "orfm"

    const-string/jumbo p2, "rofm"

    const/4 v3, 0x5

    const-string/jumbo p2, "rfom"

    const-string p2, "form"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo p2, "upolnd"

    const-string/jumbo p2, "opndlo"

    const/4 v3, 0x5

    const-string/jumbo p2, "npolda"

    const-string/jumbo p2, "onload"

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {p1, p2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lw0/b;->b(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v3, 0x7

    const/4 p2, 0x0

    const/4 v3, 0x2

    xor-int/2addr v2, p2

    :goto_0
    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ge p2, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Lw0/b;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lw0/b;->e()Lw0/a;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v1, Lw0/a;->b:Lw0/a;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast p1, Lw0/b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0, p3, p1}, Lcom/alipay/sdk/app/AuthTask;->c(Lx0/a;Lw0/b;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo p2, "zib"

    const-string/jumbo p2, "ibz"

    const/4 v3, 0x0

    const-string/jumbo p2, "ibz"

    const-string p2, "biz"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "sayrrntAqrAEai5uahoDHsl"

    const/4 v3, 0x7

    const-string/jumbo v0, "rrtha5DsqaAArHyaitElusn"

    const-string v0, "H5AuthDataAnalysisError"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p3, p2, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->e(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_2
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object p2, Lcom/alipay/sdk/app/e;->d:Lcom/alipay/sdk/app/e;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/alipay/sdk/app/e;->a()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "tne"

    const-string/jumbo v0, "net"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p3, v0, p1}, Lcom/alipay/sdk/app/statistic/a;->g(Lx0/a;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object p1, Lcom/alipay/sdk/app/e;->b:Lcom/alipay/sdk/app/e;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->a()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/alipay/sdk/app/e;->d(I)Lcom/alipay/sdk/app/e;

    move-result-object p1

    :cond_2
    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->a()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/alipay/sdk/app/e;->e()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p3, ""

    const-string p3, ""

    const/4 v3, 0x2

    const-string p3, ""

    const-string p3, ""

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p2, p1, p3}, Lcom/alipay/sdk/app/d;->b(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p1

    :catchall_1
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p1
.end method

.method private f()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/a;->g()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method private g()V
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->b:Lcom/alipay/sdk/widget/a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/alipay/sdk/widget/a;->i()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public declared-synchronized auth(Ljava/lang/String;Z)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Lx0/a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v2, "thau"

    const-string v2, "ahut"

    const/4 v4, 0x0

    const-string/jumbo v2, "tuah"

    const-string v2, "auth"

    const/4 v4, 0x0

    invoke-direct {v0, v1, p1, v2}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v0, p1, p2}, Lcom/alipay/sdk/app/AuthTask;->innerAuth(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw p1
.end method

.method public declared-synchronized authV2(Ljava/lang/String;Z)Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    move v4, v3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v0, Lx0/a;

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v4, 0x3

    const-string v2, "Vsstuh"

    const-string/jumbo v2, "uhst2V"

    const/4 v4, 0x2

    const-string/jumbo v2, "uh2mta"

    const-string v2, "authV2"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, v1, p1, v2}, Lx0/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v0, p1, p2}, Lcom/alipay/sdk/app/AuthTask;->innerAuth(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lcom/alipay/sdk/util/j;->d(Lx0/a;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1
.end method

.method public declared-synchronized innerAuth(Lx0/a;Ljava/lang/String;Z)Ljava/lang/String;
    .locals 8

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    monitor-enter p0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz p3, :cond_0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->f()V

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {}, Lx0/b;->a()Lx0/b;

    move-result-object p3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p3, v0}, Lx0/b;->b(Landroid/content/Context;)V

    const/4 v7, 0x4

    invoke-static {}, Lcom/alipay/sdk/app/d;->f()Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v0}, Lcom/alipay/sdk/app/c;->b(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p0, v0, p2, p1}, Lcom/alipay/sdk/app/AuthTask;->b(Landroid/app/Activity;Ljava/lang/String;Lx0/a;)Ljava/lang/String;

    move-result-object p3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v0, "zib"

    const-string/jumbo v0, "izb"

    const/4 v7, 0x1

    const-string/jumbo v0, "zbi"

    const-string v0, "biz"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v1, "nrPgoRmu"

    const-string/jumbo v1, "tngmRPur"

    const-string v1, "RePrtbgu"

    const-string v1, "PgReturn"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo v0, "ibz"

    const-string/jumbo v0, "ibz"

    const/4 v7, 0x7

    const-string/jumbo v0, "zbi"

    const-string v0, "biz"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v1, "PtenuVugr"

    const-string v1, "VnProuteg"

    const/4 v7, 0x5

    const-string v1, "ertgRVnpP"

    const-string v1, "PgReturnV"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v3, "uSsrlsttqtbu"

    const-string/jumbo v3, "sttslbeutuSr"

    const/4 v7, 0x6

    const-string/jumbo v3, "resultStatus"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x4

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v3, "emom"

    const-string v3, "emmo"

    const/4 v7, 0x3

    const-string v3, "eomm"

    const-string/jumbo v3, "memo"

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->v()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v0, p1, p2, v1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto/16 :goto_1

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto/16 :goto_2

    :catch_0
    move-exception v0

    :try_start_3
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/alipay/sdk/util/d;->d(Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v7, 0x5

    const/4 v6, 0x1

    const-string/jumbo v0, "zib"

    const-string/jumbo v0, "ibz"

    const/4 v7, 0x1

    const-string/jumbo v0, "zib"

    const-string v0, "biz"

    const/4 v6, 0x1

    or-int/2addr v7, v6

    const-string/jumbo v1, "trsRgPne"

    const-string/jumbo v1, "rngPteuR"

    const/4 v7, 0x7

    const-string/jumbo v1, "regmRntu"

    const-string v1, "PgReturn"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "bzi"

    const-string v0, "biz"

    const/4 v7, 0x4

    const-string/jumbo v0, "zbi"

    const-string v0, "biz"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v1, "rgVeotRnP"

    const-string v1, "PgReturnV"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v3, "rpsltbtutesa"

    const-string/jumbo v3, "letrtstpuaSs"

    const/4 v7, 0x2

    const-string/jumbo v3, "tsSttruluusa"

    const-string/jumbo v3, "resultStatus"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    move v7, v6

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x4

    const-string/jumbo v3, "|"

    const-string/jumbo v3, "|"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v3, "mome"

    const-string/jumbo v3, "moem"

    const/4 v7, 0x5

    const-string/jumbo v3, "mmeo"

    const-string/jumbo v3, "memo"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p3, v3}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p1, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/alipay/sdk/data/a;->v()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto/16 :goto_0

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    monitor-exit p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-object p3

    :goto_2
    :try_start_5
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string/jumbo v1, "ibz"

    const-string/jumbo v1, "zbi"

    const/4 v7, 0x3

    const-string v1, "bzi"

    const-string v1, "biz"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string/jumbo v2, "qtenRrup"

    const-string/jumbo v2, "qPnuRret"

    const/4 v7, 0x4

    const-string/jumbo v2, "qntuPrRg"

    const-string v2, "PgReturn"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    move v7, v6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-static {p1, v1, v2, v3}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v1, "zib"

    const-string/jumbo v1, "zbi"

    const/4 v7, 0x7

    const-string/jumbo v1, "izb"

    const-string v1, "biz"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const-string v2, "ensgRVtPu"

    const-string/jumbo v2, "ntsRuPgeV"

    const/4 v7, 0x5

    const-string v2, "PegmVtRnu"

    const-string v2, "PgReturnV"

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "lsuaotmturte"

    const-string v4, "attmteSrulus"

    const/4 v7, 0x3

    const-string/jumbo v4, "setsSbtlartu"

    const-string/jumbo v4, "resultStatus"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p3, v4}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v4, "eomm"

    const-string/jumbo v4, "mmoe"

    const-string/jumbo v4, "moem"

    const-string/jumbo v4, "memo"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p3, v4}, Lcom/alipay/sdk/util/j;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x3

    invoke-static {p1, v1, v2, p3}, Lcom/alipay/sdk/app/statistic/a;->i(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object p3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p3}, Lcom/alipay/sdk/data/a;->v()Z

    move-result p3

    const/4 v7, 0x6

    const/4 v6, 0x0

    if-nez p3, :cond_3

    const/4 v7, 0x1

    invoke-static {}, Lcom/alipay/sdk/data/a;->x()Lcom/alipay/sdk/data/a;

    move-result-object p3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-virtual {p3, p1, v1}, Lcom/alipay/sdk/data/a;->g(Lx0/a;Landroid/content/Context;)V

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/alipay/sdk/app/AuthTask;->g()V

    const/4 v7, 0x7

    const/4 v6, 0x0

    iget-object p3, p0, Lcom/alipay/sdk/app/AuthTask;->a:Landroid/app/Activity;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v1, p1, Lx0/a;->d:Ljava/lang/String;

    const/4 v7, 0x7

    invoke-static {p3, p1, p2, v1}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :catchall_1
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    monitor-exit p0

    const/4 v7, 0x7

    throw p1
.end method
