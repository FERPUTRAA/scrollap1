.class public Lcom/alipay/sdk/app/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/sdk/app/a$a;
    }
.end annotation


# static fields
.field private static a:Lcom/alipay/sdk/app/a$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/alipay/sdk/app/a$a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    sput-object v0, Lcom/alipay/sdk/app/a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static a()Lcom/alipay/sdk/app/a$a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/alipay/sdk/app/a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static b()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Lcom/alipay/sdk/app/a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v1, Lcom/alipay/sdk/app/a$a;->b:Lcom/alipay/sdk/app/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v0
.end method

.method public static c(Lcom/alipay/sdk/app/a$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    sput-object p0, Lcom/alipay/sdk/app/a;->a:Lcom/alipay/sdk/app/a$a;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
