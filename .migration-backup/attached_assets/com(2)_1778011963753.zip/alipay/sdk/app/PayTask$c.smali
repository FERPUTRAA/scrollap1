.class Lcom/alipay/sdk/app/PayTask$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/sdk/app/PayTask;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field final synthetic e:Lcom/alipay/sdk/app/PayTask;


# direct methods
.method private constructor <init>(Lcom/alipay/sdk/app/PayTask;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->e:Lcom/alipay/sdk/app/PayTask;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->a:Ljava/lang/String;

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->b:Ljava/lang/String;

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->c:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->d:Ljava/lang/String;

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/alipay/sdk/app/PayTask;Lcom/alipay/sdk/app/PayTask$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/alipay/sdk/app/PayTask$c;-><init>(Lcom/alipay/sdk/app/PayTask;)V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~fs~ ~ d@@@ay@~~~/M@@@@@ ~b~~@crl@  sf~o ~t~i.loi o~b@@ n@~ ~~ ~@o @ S~t1Ko@bvi  @@~4@/  -~ ~mo~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask$c;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask$c;->c:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method public d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask$c;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object v0
.end method

.method public f(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/sdk/app/PayTask$c;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-object v0
.end method

.method public h(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alipay/sdk/app/PayTask$c;->d:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
