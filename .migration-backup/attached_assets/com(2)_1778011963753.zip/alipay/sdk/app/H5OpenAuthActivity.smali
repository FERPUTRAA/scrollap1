.class public Lcom/alipay/sdk/app/H5OpenAuthActivity;
.super Lcom/alipay/sdk/app/H5PayActivity;


# instance fields
.field private h:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/alipay/sdk/app/H5PayActivity;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/alipay/sdk/app/H5OpenAuthActivity;->h:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " cs S~@K ~~~-l~@@@s@@ @@i~t@o ~~~m~@@t /~uo~on ~ vb1l4@~~@o~o@f~if~~b@o~a/@i  @ @.b d@M~~@r    y"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-void
.end method

.method protected onDestroy()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/alipay/sdk/app/H5OpenAuthActivity;->h:Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0}, Lx0/a$a;->a(Landroid/content/Intent;)Lx0/a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v2, v0, Lx0/a;->d:Ljava/lang/String;

    const/4 v4, 0x5

    invoke-static {p0, v0, v1, v2}, Lcom/alipay/sdk/app/statistic/a;->h(Landroid/content/Context;Lx0/a;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-super {p0}, Lcom/alipay/sdk/app/H5PayActivity;->onDestroy()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public startActivity(Landroid/content/Intent;)V
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p1}, Lx0/a$a;->a(Landroid/content/Intent;)Lx0/a;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-super {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v0, "ppfmptlrya/aip:mssai/aoa/tratp"

    const-string/jumbo v0, "y/srpptl/attafmpsraipilap:aoa/"

    const/4 v5, 0x4

    const-string v0, "i/tlompayaa:rstisafaprptopap//"

    const-string v0, "alipays://platformapi/startapp"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-eqz p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz p1, :cond_3

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p1, "lnul"

    const-string/jumbo p1, "llun"

    const/4 v5, 0x7

    const-string/jumbo p1, "ulnl"

    const-string/jumbo p1, "null"

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo v2, "zbi"

    const-string/jumbo v2, "izb"

    const/4 v5, 0x2

    const-string v2, "biz"

    const-string v2, "biz"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v3, "vaAmrbcEyttxtSi"

    const-string v3, "SAxmtritEactvyt"

    const/4 v5, 0x7

    const-string v3, "StartActivityEx"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v2, v3, v1, p1}, Lcom/alipay/sdk/app/statistic/a;->f(Lx0/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-boolean p1, p0, Lcom/alipay/sdk/app/H5OpenAuthActivity;->h:Z

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw v1

    :catchall_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/alipay/sdk/app/H5PayActivity;->finish()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method
