.class public abstract Lcom/alipay/android/phone/mrpc/core/a/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/android/phone/mrpc/core/a/c;


# instance fields
.field protected a:Ljava/lang/reflect/Type;

.field protected b:[B


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Type;[B)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    or-int/2addr v1, v0

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->a:Ljava/lang/reflect/Type;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->b:[B

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method
