.class final Lcom/alipay/android/phone/mrpc/core/f;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/apache/http/conn/ConnectionKeepAliveStrategy;


# instance fields
.field final synthetic a:Lcom/alipay/android/phone/mrpc/core/d;


# direct methods
.method constructor <init>(Lcom/alipay/android/phone/mrpc/core/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/f;->a:Lcom/alipay/android/phone/mrpc/core/d;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final getKeepAliveDuration(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~-so~rs  @uma~@f@  @i@t@@n~@t ~ /i@~~@ d~./c~~K@i~@@ ~ by@4lo@ @~ f@o b~l@  ~1~~~ Mo~~bv~S @ @oo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const-wide/32 p1, 0x2bf20

    const-wide/32 p1, 0x2bf20

    const/4 v1, 0x3

    const-wide/32 p1, 0x2bf20

    const-wide/32 p1, 0x2bf20

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-wide p1
.end method
