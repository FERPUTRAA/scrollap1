.class final Lcom/alipay/android/phone/mrpc/core/n;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/ThreadFactory;


# instance fields
.field private final a:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>()V
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/n;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public final newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "ybsv @@@s~@@~r@@  @o~ ~@ ~oi l~oo  ~   S@@@.f- ~~/Kf~iit @@ ~~~~lt@~1@~~ M~m~cdn@ u@~ao/b~@o 4@b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, "e.Hm.sn.i.palWoto.mmtlymrpgsi#ppo.acto kerembathMco.tnpaonrHratt"

    const-string/jumbo v2, "posHlcmnH.tipomrkmaoreaartpg.ohptirnpneotM yt.ob#..tcalaeWstm.r."

    const/4 v4, 0x7

    const-string v2, "aaoeormapir.HaHnc#prtyoom rmethtiMtortatlpetm.s..t.oolnp.Wng.kpc"

    const-string v2, "com.alipay.mobile.common.transport.http.HttpManager.HttpWorker #"

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/n;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0, p1, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 p1, 0x6

    const/4 p1, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Thread;->setPriority(I)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0
.end method
