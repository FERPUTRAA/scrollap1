.class final Lcom/alipay/android/phone/mrpc/core/k$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/android/phone/mrpc/core/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field a:I

.field b:I

.field c:I


# direct methods
.method constructor <init>(III)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/alipay/android/phone/mrpc/core/k$a;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p2, p0, Lcom/alipay/android/phone/mrpc/core/k$a;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p3, p0, Lcom/alipay/android/phone/mrpc/core/k$a;->c:I

    const/4 v1, 0x2

    return-void
.end method
