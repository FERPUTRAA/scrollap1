.class final Lcom/alipay/android/phone/mrpc/core/c;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/apache/http/HttpRequestInterceptor;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final process(Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s1 o@@@@d~t @@~ ~fm~@o~~l@tS~@ l@s/ ~M ~~Ko@@bib-n  f@~~@~~@~~bv@4@@~iu ~a@ @oi~oo /~ . y c ~r"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p1, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eq p1, p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const-string p2, "aftm eebHhidis rd Trs TusesqtTohs"

    const-string p2, "TqsPfHissihr  det  eeTshtabdTsuor"

    const/4 v1, 0x7

    const-string p2, "bsdto Tuehiashrf roTqs sHedir Pet"

    const-string p2, "This thread forbids HTTP requests"

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    const/4 v1, 0x7

    return-void
.end method
