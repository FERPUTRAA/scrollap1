.class public Lcom/alipay/android/phone/mrpc/core/ad;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/apache/http/client/HttpRequestRetryHandler;


# static fields
.field static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const-class v0, Lcom/alipay/android/phone/mrpc/core/ad;

    const-class v0, Lcom/alipay/android/phone/mrpc/core/ad;

    const/4 v2, 0x3

    const-class v0, Lcom/alipay/android/phone/mrpc/core/ad;

    const-class v0, Lcom/alipay/android/phone/mrpc/core/ad;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/ad;->a:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public retryRequest(Ljava/io/IOException;ILorg/apache/http/protocol/HttpContext;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c~s/ K~~@1 i~~s@@ ~~~nuo-t~  ~o f~@o@@@y~M@ @4 @@ .i@ m~l~@b@ ~v~ o~@or  S~ilb f@/@a o~~~dt@~@@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 p3, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    if-lt p2, p3, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    instance-of p2, p1, Lorg/apache/http/NoHttpResponseException;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p3, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p3

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    instance-of p2, p1, Ljava/net/SocketException;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez p2, :cond_2

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    instance-of p2, p1, Ljavax/net/ssl/SSLException;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz p2, :cond_3

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p2, :cond_3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string p2, "Bpemkrnp se"

    const-string p2, "ense prBpki"

    const-string p2, "eBriop oenp"

    const-string p2, "Broken pipe"

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p1, :cond_3

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    return p3

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method
