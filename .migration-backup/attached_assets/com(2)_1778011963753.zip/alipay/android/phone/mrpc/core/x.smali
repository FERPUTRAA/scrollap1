.class public final Lcom/alipay/android/phone/mrpc/core/x;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/alipay/android/phone/mrpc/core/g;

.field private b:Lcom/alipay/android/phone/mrpc/core/z;


# direct methods
.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/g;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/x;->a:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    new-instance p1, Lcom/alipay/android/phone/mrpc/core/z;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p1, p0}, Lcom/alipay/android/phone/mrpc/core/z;-><init>(Lcom/alipay/android/phone/mrpc/core/x;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/x;->b:Lcom/alipay/android/phone/mrpc/core/z;

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final a()Lcom/alipay/android/phone/mrpc/core/g;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/x;->a:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public final a(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    aput-object p1, v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/y;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/alipay/android/phone/mrpc/core/x;->a:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/x;->b:Lcom/alipay/android/phone/mrpc/core/z;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v2, v3, p1, v4}, Lcom/alipay/android/phone/mrpc/core/y;-><init>(Lcom/alipay/android/phone/mrpc/core/g;Ljava/lang/Class;Lcom/alipay/android/phone/mrpc/core/z;)V

    const/4 v6, 0x1

    invoke-static {v0, v1, v2}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-object p1
.end method
