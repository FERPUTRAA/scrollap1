.class public final Lcom/alipay/android/phone/mrpc/core/y;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# instance fields
.field protected a:Lcom/alipay/android/phone/mrpc/core/g;

.field protected b:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field protected c:Lcom/alipay/android/phone/mrpc/core/z;


# direct methods
.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/g;Ljava/lang/Class;Lcom/alipay/android/phone/mrpc/core/z;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alipay/android/phone/mrpc/core/g;",
            "Ljava/lang/Class<",
            "*>;",
            "Lcom/alipay/android/phone/mrpc/core/z;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/y;->a:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/alipay/android/phone/mrpc/core/y;->b:Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-object p3, p0, Lcom/alipay/android/phone/mrpc/core/y;->c:Lcom/alipay/android/phone/mrpc/core/z;

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1@s~@Ma~.~y/  o~~moubS~~ s~b~@4nf~lr~@ @t@i@li/@ b   vfc~t  ~o i@@~@@@ ~~@@@od~o @~ @K @-~~~@ o "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/alipay/android/phone/mrpc/core/y;->c:Lcom/alipay/android/phone/mrpc/core/z;

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    invoke-virtual {p1, p2, p3}, Lcom/alipay/android/phone/mrpc/core/z;->a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    return-object p1
.end method
