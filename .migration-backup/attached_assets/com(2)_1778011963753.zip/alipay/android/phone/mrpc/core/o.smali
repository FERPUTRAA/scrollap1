.class public final Lcom/alipay/android/phone/mrpc/core/o;
.super Lcom/alipay/android/phone/mrpc/core/t;


# instance fields
.field private b:Ljava/lang/String;

.field private c:[B

.field private d:Ljava/lang/String;

.field private e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lorg/apache/http/Header;",
            ">;"
        }
    .end annotation
.end field

.field private f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private g:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/t;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    new-instance p1, Ljava/util/ArrayList;

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->e:Ljava/util/ArrayList;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string p1, "application/x-www-form-urlencoded"

    const/4 v1, 0x6

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->d:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osioi  f1~@K@~S  @ v~~  ~@l@ut@sb ~M~~ @@~~m~/@@~d /@ot~@ - o@a@@~obr~~ @~l o@i@ f4c@~y~~b @. ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public final a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->d:Ljava/lang/String;

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    return-void
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public final a(Lorg/apache/http/Header;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->e:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public final a(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->g:Z

    const/4 v1, 0x7

    return-void
.end method

.method public final a([B)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/o;->c:[B

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public final b(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p1
.end method

.method public final b()[B
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->c:[B

    const/4 v1, 0x7

    or-int/2addr v2, v1

    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public final d()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lorg/apache/http/Header;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->e:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public final e()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->g:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p0, p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x0

    move v5, v1

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v1

    :cond_1
    const/4 v5, 0x5

    const-class v2, Lcom/alipay/android/phone/mrpc/core/o;

    const-class v2, Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eq v2, v3, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    check-cast p1, Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/o;->c:[B

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v2, p1, Lcom/alipay/android/phone/mrpc/core/o;->c:[B

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v3, p1, Lcom/alipay/android/phone/mrpc/core/o;->c:[B

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz p1, :cond_6

    const/4 v5, 0x7

    return v1

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez p1, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v1

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v0
.end method

.method public final hashCode()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const-string/jumbo v1, "id"

    const-string v1, "di"

    const/4 v3, 0x6

    const-string v1, "di"

    const-string/jumbo v1, "id"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/o;->f:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v0, 0x1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/o;->b:Ljava/lang/String;

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/o;->e:Ljava/util/ArrayList;

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "ts%m ra::p tHd, UelH%ss"

    const-string/jumbo v1, "s s:deH,alrt%es p UtH%:"

    const/4 v4, 0x6

    const-string/jumbo v1, "rp%,o a r:%HssUedHt :et"

    const-string v1, "Url : %s,HttpHeader: %s"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object v0
.end method
