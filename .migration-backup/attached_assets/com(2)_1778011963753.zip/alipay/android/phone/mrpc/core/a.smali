.class public abstract Lcom/alipay/android/phone/mrpc/core/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/android/phone/mrpc/core/v;


# instance fields
.field protected a:Ljava/lang/reflect/Method;

.field protected b:[B

.field protected c:Ljava/lang/String;

.field protected d:I

.field protected e:Ljava/lang/String;

.field protected f:Z


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;ILjava/lang/String;[BLjava/lang/String;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/a;->a:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lcom/alipay/android/phone/mrpc/core/a;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/alipay/android/phone/mrpc/core/a;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/alipay/android/phone/mrpc/core/a;->b:[B

    iput-object p5, p0, Lcom/alipay/android/phone/mrpc/core/a;->e:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-boolean p6, p0, Lcom/alipay/android/phone/mrpc/core/a;->f:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
