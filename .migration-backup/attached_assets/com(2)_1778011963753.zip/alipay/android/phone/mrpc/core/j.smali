.class public final Lcom/alipay/android/phone/mrpc/core/j;
.super Lcom/alipay/android/phone/mrpc/core/a;


# instance fields
.field private g:Lcom/alipay/android/phone/mrpc/core/g;


# direct methods
.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/g;Ljava/lang/reflect/Method;ILjava/lang/String;[BZ)V
    .locals 9

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo v5, "lcspleexaws-owonar-iin/fmpot-dcwu"

    const-string/jumbo v5, "opsefic-new-cxri-rlwl/mtoduownaap"

    const/4 v8, 0x2

    const-string v5, "cc-mawemwudn-ialolwd/o-itxpprforn"

    const-string v5, "application/x-www-form-urlencoded"

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    move v2, p3

    move v2, p3

    const/4 v8, 0x3

    move v2, p3

    move v2, p3

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    move v6, p6

    move v6, p6

    const/4 v8, 0x7

    move v6, p6

    move v6, p6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v6}, Lcom/alipay/android/phone/mrpc/core/a;-><init>(Ljava/lang/reflect/Method;ILjava/lang/String;[BLjava/lang/String;Z)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/j;->g:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "o~odo ./~@vyr @b~so/ ~ @u@@@-o~ @@ l~o  at@~i@ b1 ~i@m~ ~~ M@@@l ~oK@@@b~ ~~S@f i ~cn4~~f@~~ ~t@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/j;->g:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v6, 0x4

    move v7, v6

    invoke-interface {v2}, Lcom/alipay/android/phone/mrpc/core/g;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/a;->b:[B

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a([B)V

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/a;->e:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    iget-boolean v2, p0, Lcom/alipay/android/phone/mrpc/core/a;->f:Z

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget v2, p0, Lcom/alipay/android/phone/mrpc/core/a;->d:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v3, "di"

    const-string/jumbo v3, "id"

    const/4 v7, 0x7

    const-string v3, "di"

    const-string/jumbo v3, "id"

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1, v3, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v2, "oirtobpenpmey"

    const-string/jumbo v2, "onemrptoyepai"

    const/4 v7, 0x4

    const-string/jumbo v2, "operationType"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/alipay/android/phone/mrpc/core/a;->c:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v3}, Lcom/alipay/android/phone/mrpc/core/o;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/j;->g:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-interface {v2}, Lcom/alipay/android/phone/mrpc/core/g;->d()Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v3, "pgzi"

    const-string/jumbo v3, "zgpi"

    const/4 v7, 0x3

    const-string/jumbo v3, "pgzi"

    const-string v3, "gzip"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, v3, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance v2, Lorg/apache/http/message/BasicHeader;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v4, "uiud"

    const-string v4, "duui"

    const/4 v7, 0x0

    const-string/jumbo v4, "uudi"

    const-string/jumbo v4, "uuid"

    const/4 v7, 0x0

    invoke-direct {v2, v4, v3}, Lorg/apache/http/message/BasicHeader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;->a(Lorg/apache/http/Header;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/j;->g:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {v2}, Lcom/alipay/android/phone/mrpc/core/g;->c()Lcom/alipay/android/phone/mrpc/core/aa;

    move-result-object v2

    const/4 v7, 0x3

    invoke-virtual {v2}, Lcom/alipay/android/phone/mrpc/core/aa;->b()Ljava/util/List;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x0

    check-cast v3, Lorg/apache/http/Header;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1, v3}, Lcom/alipay/android/phone/mrpc/core/o;->a(Lorg/apache/http/Header;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/o;->toString()Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/16 v2, 0x9

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/16 v3, 0xd

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/j;->g:Lcom/alipay/android/phone/mrpc/core/g;

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-interface {v4}, Lcom/alipay/android/phone/mrpc/core/g;->b()Lcom/alipay/android/phone/mrpc/core/ab;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {v4, v1}, Lcom/alipay/android/phone/mrpc/core/ab;->a(Lcom/alipay/android/phone/mrpc/core/t;)Ljava/util/concurrent/Future;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    check-cast v1, Lcom/alipay/android/phone/mrpc/core/u;

    const/4 v7, 0x4

    if-eqz v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/u;->b()[B

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v5, " onpulusen rssle"

    const-string/jumbo v5, "prneou s sellsno"

    const/4 v7, 0x1

    const-string/jumbo v5, "lpose lpeunsn sr"

    const-string/jumbo v5, "response is null"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v1, v4, v5}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    throw v1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v2, v3, v0, v1}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v7, 0x4

    throw v2

    :catch_1
    move-exception v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    instance-of v4, v3, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v4, :cond_2

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    check-cast v3, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3}, Lcom/alipay/android/phone/mrpc/core/HttpException;->getCode()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    packed-switch v1, :pswitch_data_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_1

    :pswitch_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/16 v1, 0x10

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_1

    :pswitch_1
    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/16 v1, 0xf

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :pswitch_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 v1, 0x8

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_1

    :pswitch_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_1

    :pswitch_4
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v1, 0x6

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_1

    :pswitch_5
    const/4 v7, 0x2

    const/4 v1, 0x5

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :pswitch_6
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v1, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :pswitch_7
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v1, 0x3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_1

    :pswitch_8
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v1, 0x2

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3}, Lcom/alipay/android/phone/mrpc/core/HttpException;->getMsg()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {v0, v1, v2}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    throw v0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v3, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v6, 0x1

    move v7, v6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v3, v2, v0, v1}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    throw v3

    :catch_2
    move-exception v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v2, v3, v0, v1}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    throw v2

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
