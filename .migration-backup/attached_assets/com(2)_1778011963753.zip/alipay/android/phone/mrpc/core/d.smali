.class final Lcom/alipay/android/phone/mrpc/core/d;
.super Lorg/apache/http/impl/client/DefaultHttpClient;


# instance fields
.field final synthetic a:Lcom/alipay/android/phone/mrpc/core/b;


# direct methods
.method constructor <init>(Lcom/alipay/android/phone/mrpc/core/b;Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/d;->a:Lcom/alipay/android/phone/mrpc/core/b;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p2, p3}, Lorg/apache/http/impl/client/DefaultHttpClient;-><init>(Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method protected final createConnectionKeepAliveStrategy()Lorg/apache/http/conn/ConnectionKeepAliveStrategy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ms4fi~~~  d~   S@t/M~r@ b~~n .@~l@ @~ v~@@~o@~@ Klo~c~o~@ ~i ~1obo@ut/ ~ y@@fb@@ - @@i ~o@@@s~a"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/f;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/alipay/android/phone/mrpc/core/f;-><init>(Lcom/alipay/android/phone/mrpc/core/d;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method protected final createHttpContext()Lorg/apache/http/protocol/HttpContext;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Lorg/apache/http/protocol/BasicHttpContext;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/apache/http/protocol/BasicHttpContext;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, "easmts-giysmcthrt.prehue"

    const-string/jumbo v1, "sesrth-hyumaet.gichtreps"

    const/4 v4, 0x0

    const-string/jumbo v1, "rsptotetsyhihemegr-tu.ah"

    const-string v1, "http.authscheme-registry"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lorg/apache/http/impl/client/DefaultHttpClient;->getAuthSchemes()Lorg/apache/http/auth/AuthSchemeRegistry;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Lorg/apache/http/protocol/HttpContext;->setAttribute(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "tiroebpksroesghettmc.yc-"

    const-string/jumbo v1, "sepmto.pcgoykeric-tersht"

    const/4 v4, 0x0

    const-string v1, "http.cookiespec-registry"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Lorg/apache/http/impl/client/DefaultHttpClient;->getCookieSpecs()Lorg/apache/http/cookie/CookieSpecRegistry;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, v1, v2}, Lorg/apache/http/protocol/HttpContext;->setAttribute(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "naedpouthcortalpev.sidhertt-.i"

    const-string/jumbo v1, "vpldocenht.tta-iihposteerd.rra"

    const/4 v4, 0x0

    const-string v1, "atecv..prptsd-trrhhpidtuneielo"

    const-string v1, "http.auth.credentials-provider"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lorg/apache/http/impl/client/DefaultHttpClient;->getCredentialsProvider()Lorg/apache/http/client/CredentialsProvider;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Lorg/apache/http/protocol/HttpContext;->setAttribute(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x3

    move v4, v3

    return-object v0
.end method

.method protected final createHttpProcessor()Lorg/apache/http/protocol/BasicHttpProcessor;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-super {p0}, Lorg/apache/http/impl/client/DefaultHttpClient;->createHttpProcessor()Lorg/apache/http/protocol/BasicHttpProcessor;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lcom/alipay/android/phone/mrpc/core/b;->a()Lorg/apache/http/HttpRequestInterceptor;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Lorg/apache/http/protocol/BasicHttpProcessor;->addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/b$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/d;->a:Lcom/alipay/android/phone/mrpc/core/b;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v1, v2, v3}, Lcom/alipay/android/phone/mrpc/core/b$a;-><init>(Lcom/alipay/android/phone/mrpc/core/b;B)V

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lorg/apache/http/protocol/BasicHttpProcessor;->addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object v0
.end method

.method protected final createRedirectHandler()Lorg/apache/http/client/RedirectHandler;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/e;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/alipay/android/phone/mrpc/core/e;-><init>(Lcom/alipay/android/phone/mrpc/core/d;)V

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method
