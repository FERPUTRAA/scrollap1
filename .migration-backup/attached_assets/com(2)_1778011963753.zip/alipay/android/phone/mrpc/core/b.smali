.class public final Lcom/alipay/android/phone/mrpc/core/b;
.super Ljava/lang/Object;

# interfaces
.implements Lorg/apache/http/client/HttpClient;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/android/phone/mrpc/core/b$a;,
        Lcom/alipay/android/phone/mrpc/core/b$b;
    }
.end annotation


# static fields
.field public static a:J = 0xa0L

.field private static b:[Ljava/lang/String;

.field private static final c:Lorg/apache/http/HttpRequestInterceptor;


# instance fields
.field private final d:Lorg/apache/http/client/HttpClient;

.field private e:Ljava/lang/RuntimeException;

.field private volatile f:Lcom/alipay/android/phone/mrpc/core/b$b;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v0, "maspaini/tloxpl"

    const-string v0, "application/xml"

    const/4 v4, 0x4

    const-string v1, "application/json"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "s/emt"

    const-string v2, "exst/"

    const/4 v4, 0x3

    const-string/jumbo v2, "xt/to"

    const-string/jumbo v2, "text/"

    const/4 v4, 0x2

    const/4 v3, 0x0

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/b;->b:[Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/c;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/alipay/android/phone/mrpc/core/c;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/b;->c:Lorg/apache/http/HttpRequestInterceptor;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method private constructor <init>(Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "eaamHdceidleeAstirldentp rnCt  ortnvddnceo"

    const/4 v3, 0x3

    const-string v1, "iAHeebancrelnaopliddt nedsdtcnt tvoCrder e"

    const-string v1, "AndroidHttpClient created and never closed"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->e:Ljava/lang/RuntimeException;

    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1, p2}, Lcom/alipay/android/phone/mrpc/core/d;-><init>(Lcom/alipay/android/phone/mrpc/core/b;Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic a(Lcom/alipay/android/phone/mrpc/core/b;)Lcom/alipay/android/phone/mrpc/core/b$b;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@o@~ uif~~~@. i~ @~u1s@l~~ ~ ~mr~MS@t@ @~ l-@/ ~~ K@@~ ~obi4   @dov@@o~ @~n~~cb~@f @ a/@yo~ t@o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/alipay/android/phone/mrpc/core/b;->f:Lcom/alipay/android/phone/mrpc/core/b$b;

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-object p0
.end method

.method public static a(Ljava/lang/String;)Lcom/alipay/android/phone/mrpc/core/b;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v0, Lorg/apache/http/params/BasicHttpParams;

    const/4 v7, 0x0

    invoke-direct {v0}, Lorg/apache/http/params/BasicHttpParams;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget-object v1, Lorg/apache/http/HttpVersion;->HTTP_1_1:Lorg/apache/http/HttpVersion;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lorg/apache/http/params/HttpProtocolParams;->setVersion(Lorg/apache/http/params/HttpParams;Lorg/apache/http/ProtocolVersion;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lorg/apache/http/params/HttpProtocolParams;->setUseExpectContinue(Lorg/apache/http/params/HttpParams;Z)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v0, v2}, Lorg/apache/http/params/HttpConnectionParams;->setStaleCheckingEnabled(Lorg/apache/http/params/HttpParams;Z)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/16 v3, 0x4e20

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0, v3}, Lorg/apache/http/params/HttpConnectionParams;->setConnectionTimeout(Lorg/apache/http/params/HttpParams;I)V

    const/4 v7, 0x6

    const/16 v3, 0x7530

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0, v3}, Lorg/apache/http/params/HttpConnectionParams;->setSoTimeout(Lorg/apache/http/params/HttpParams;I)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v4, 0x2000

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v0, v4}, Lorg/apache/http/params/HttpConnectionParams;->setSocketBufferSize(Lorg/apache/http/params/HttpParams;I)V

    const/4 v7, 0x4

    invoke-static {v0, v2}, Lorg/apache/http/client/params/HttpClientParams;->setRedirecting(Lorg/apache/http/params/HttpParams;Z)V

    const/4 v7, 0x1

    invoke-static {v0, v1}, Lorg/apache/http/client/params/HttpClientParams;->setAuthenticating(Lorg/apache/http/params/HttpParams;Z)V

    const/4 v7, 0x1

    invoke-static {v0, p0}, Lorg/apache/http/params/HttpProtocolParams;->setUserAgent(Lorg/apache/http/params/HttpParams;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance p0, Lorg/apache/http/conn/scheme/SchemeRegistry;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {p0}, Lorg/apache/http/conn/scheme/SchemeRegistry;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    new-instance v1, Lorg/apache/http/conn/scheme/Scheme;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Lorg/apache/http/conn/scheme/PlainSocketFactory;->getSocketFactory()Lorg/apache/http/conn/scheme/PlainSocketFactory;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/16 v4, 0x50

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v5, "ptht"

    const-string v5, "http"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {v1, v5, v2, v4}, Lorg/apache/http/conn/scheme/Scheme;-><init>(Ljava/lang/String;Lorg/apache/http/conn/scheme/SocketFactory;I)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0, v1}, Lorg/apache/http/conn/scheme/SchemeRegistry;->register(Lorg/apache/http/conn/scheme/Scheme;)Lorg/apache/http/conn/scheme/Scheme;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v1, Lorg/apache/http/conn/scheme/Scheme;

    const/4 v7, 0x0

    const/4 v2, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v3, v2}, Landroid/net/SSLCertificateSocketFactory;->getHttpSocketFactory(ILandroid/net/SSLSessionCache;)Lorg/apache/http/conn/ssl/SSLSocketFactory;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 v3, 0x1bb

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v4, "ptpht"

    const-string/jumbo v4, "pthto"

    const/4 v7, 0x2

    const-string/jumbo v4, "phtqs"

    const-string v4, "https"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {v1, v4, v2, v3}, Lorg/apache/http/conn/scheme/Scheme;-><init>(Ljava/lang/String;Lorg/apache/http/conn/scheme/SocketFactory;I)V

    const/4 v6, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Lorg/apache/http/conn/scheme/SchemeRegistry;->register(Lorg/apache/http/conn/scheme/Scheme;)Lorg/apache/http/conn/scheme/Scheme;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v1, Lorg/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager;

    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-direct {v1, v0, p0}, Lorg/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager;-><init>(Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/scheme/SchemeRegistry;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-wide/32 v2, 0xea60

    const-wide/32 v2, 0xea60

    const/4 v7, 0x1

    const-wide/32 v2, 0xea60

    const-wide/32 v2, 0xea60

    const/4 v6, 0x2

    and-int/2addr v7, v6

    invoke-static {v0, v2, v3}, Lorg/apache/http/conn/params/ConnManagerParams;->setTimeout(Lorg/apache/http/params/HttpParams;J)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance p0, Lorg/apache/http/conn/params/ConnPerRouteBean;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/16 v2, 0xa

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {p0, v2}, Lorg/apache/http/conn/params/ConnPerRouteBean;-><init>(I)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v0, p0}, Lorg/apache/http/conn/params/ConnManagerParams;->setMaxConnectionsPerRoute(Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/params/ConnPerRoute;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/16 p0, 0x32

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v0, p0}, Lorg/apache/http/conn/params/ConnManagerParams;->setMaxTotalConnections(Lorg/apache/http/params/HttpParams;I)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string/jumbo p0, "ttseebd.es.awlcohcasdnkr"

    const-string/jumbo p0, "stldcbtea.no.rarhdeswekc"

    const/4 v7, 0x1

    const-string/jumbo p0, "okem.htddewctralcrsne.sa"

    const-string/jumbo p0, "networkaddress.cache.ttl"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v2, "1-"

    const-string v2, "1-"

    const-string v2, "-1"

    const-string v2, "-1"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p0, v2}, Ljava/security/Security;->setProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    sget-object p0, Lorg/apache/http/conn/ssl/SSLSocketFactory;->STRICT_HOSTNAME_VERIFIER:Lorg/apache/http/conn/ssl/X509HostnameVerifier;

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-static {p0}, Ljavax/net/ssl/HttpsURLConnection;->setDefaultHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance p0, Lcom/alipay/android/phone/mrpc/core/b;

    const/4 v7, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, v1, v0}, Lcom/alipay/android/phone/mrpc/core/b;-><init>(Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V

    const/4 v7, 0x1

    return-object p0
.end method

.method public static a(Lorg/apache/http/HttpEntity;)Ljava/io/InputStream;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-interface {p0}, Lorg/apache/http/HttpEntity;->getContent()Ljava/io/InputStream;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p0}, Lorg/apache/http/HttpEntity;->getContentEncoding()Lorg/apache/http/Header;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p0}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "izpg"

    const-string v1, "gpiz"

    const/4 v3, 0x3

    const-string/jumbo v1, "pzgi"

    const-string v1, "gzip"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p0, Ljava/util/zip/GZIPInputStream;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method static synthetic a(Lorg/apache/http/client/methods/HttpUriRequest;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const-string v1, " urlo"

    const-string v1, " uulr"

    const/4 v9, 0x5

    const-string v1, "bul r"

    const-string v1, "curl "

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {p0}, Lorg/apache/http/client/methods/HttpUriRequest;->getAllHeaders()[Lorg/apache/http/Header;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    array-length v2, v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ge v4, v2, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    aget-object v5, v1, v4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-interface {v5}, Lorg/apache/http/Header;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v7, "ipoAthuuinoaz"

    const-string v7, "aiAnhtoptozui"

    const/4 v9, 0x5

    const-string v7, "Aohauttpiionz"

    const-string v7, "Authorization"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-nez v6, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {v5}, Lorg/apache/http/Header;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string v7, "Coqqki"

    const-string/jumbo v7, "ioqoCk"

    const/4 v9, 0x1

    const-string/jumbo v7, "kosioC"

    const-string v7, "Cookie"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez v6, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string v6, "d-amh/esr-e"

    const-string v6, "/asd/erhe--"

    const-string v6, "dhe/oa-/ -r"

    const-string v6, "--header \""

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string v5, "/ /"

    const/4 v9, 0x6

    const-string v5, "// "

    const-string v5, "\" "

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_1
    const/4 v9, 0x6

    invoke-interface {p0}, Lorg/apache/http/client/methods/HttpUriRequest;->getURI()Ljava/net/URI;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    instance-of v2, p0, Lorg/apache/http/impl/client/RequestWrapper;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v2, :cond_2

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    check-cast v2, Lorg/apache/http/impl/client/RequestWrapper;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v2}, Lorg/apache/http/impl/client/RequestWrapper;->getOriginal()Lorg/apache/http/HttpRequest;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    instance-of v4, v2, Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v4, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    check-cast v2, Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v2}, Lorg/apache/http/client/methods/HttpUriRequest;->getURI()Ljava/net/URI;

    move-result-object v1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v2, "//"

    const-string v2, "//"

    const/4 v9, 0x0

    const-string v2, "//"

    const-string v2, "\""

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    instance-of v1, p0, Lorg/apache/http/HttpEntityEnclosingRequest;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v1, :cond_5

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    check-cast v1, Lorg/apache/http/HttpEntityEnclosingRequest;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-interface {v1}, Lorg/apache/http/HttpEntityEnclosingRequest;->getEntity()Lorg/apache/http/HttpEntity;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v1, :cond_5

    const/4 v9, 0x4

    invoke-interface {v1}, Lorg/apache/http/HttpEntity;->isRepeatable()Z

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz v4, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-interface {v1}, Lorg/apache/http/HttpEntity;->getContentLength()J

    move-result-wide v4

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-wide/16 v6, 0x400

    const-wide/16 v6, 0x400

    const/4 v9, 0x5

    const-wide/16 v6, 0x400

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    cmp-long v4, v4, v6

    const/4 v8, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-gez v4, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    invoke-interface {v1, v4}, Lorg/apache/http/HttpEntity;->writeTo(Ljava/io/OutputStream;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/b;->b(Lorg/apache/http/client/methods/HttpUriRequest;)Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz p0, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v1, 0x2

    const/4 v9, 0x3

    invoke-static {p0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v2, " ecmo//"

    const/4 v9, 0x0

    const-string v2, "e/oc/b "

    const-string v2, "echo \'"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const-string p0, "$/s/o -6eb/ $>./b tp an|4m ;di"

    const/4 v9, 0x5

    const-string p0, " sp;/ u/b n>$ . /d|$-i mta/4eb"

    const-string p0, "\' | base64 -d > /tmp/$$.bin; "

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v0, v3, p0}, Ljava/lang/StringBuilder;->insert(ILjava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo p0, "m-b-rtipan/ pbd$@yai-/.b$n "

    const-string p0, "ami- bdbnn- y@iat.$pa$-/rb/"

    const/4 v9, 0x2

    const-string p0, "$nna$t@aqrb.-ditb/p-i my- /"

    const-string p0, " --data-binary @/tmp/$$.bin"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_1

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v1, "iasas/-t d --/iu"

    const-string v1, " c-i/autdi-as /-"

    const/4 v9, 0x6

    const-string v1, "--dm ai/ tcia/-s"

    const-string v1, " --data-ascii \""

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_2

    :cond_4
    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string p0, "ADp o DCC][T AUU MIOOHENO L"

    const-string p0, "OT OEU pNODAU IL[ TDCM] CAH"

    const/4 v9, 0x2

    const-string p0, "CHON]bL  U[DM CTO UAATO EDI"

    const-string p0, " [TOO MUCH DATA TO INCLUDE]"

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    return-object p0
.end method

.method static synthetic a()Lorg/apache/http/HttpRequestInterceptor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/alipay/android/phone/mrpc/core/b;->c:Lorg/apache/http/HttpRequestInterceptor;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public static a([B)Lorg/apache/http/entity/AbstractHttpEntity;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    array-length v0, p0

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    int-to-long v0, v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-wide v2, Lcom/alipay/android/phone/mrpc/core/b;->a:J

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-gez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v0, Lorg/apache/http/entity/ByteArrayEntity;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v0, p0}, Lorg/apache/http/entity/ByteArrayEntity;-><init>([B)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v1, Ljava/util/zip/GZIPOutputStream;

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-direct {v1, v0}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p0, Lorg/apache/http/entity/ByteArrayEntity;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p0, v0}, Lorg/apache/http/entity/ByteArrayEntity;-><init>([B)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v0, "gzpi"

    const/4 v5, 0x4

    const-string/jumbo v0, "zgip"

    const-string v0, "gzip"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Lorg/apache/http/entity/AbstractHttpEntity;->setContentEncoding(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Lorg/apache/http/entity/AbstractHttpEntity;->getContentLength()J

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v0
.end method

.method public static a(Lorg/apache/http/HttpRequest;)V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "gctAiouqe-cpcnn"

    const-string/jumbo v0, "tAccpcdgqneoi-n"

    const/4 v3, 0x4

    const-string v0, "-nApdccpgnteocE"

    const-string v0, "Accept-Encoding"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "gpzi"

    const-string/jumbo v1, "pzig"

    const/4 v3, 0x7

    const-string/jumbo v1, "zgpi"

    const-string v1, "gzip"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p0, v0, v1}, Lorg/apache/http/HttpRequest;->addHeader(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public static b(Ljava/lang/String;)J
    .locals 4

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/k;->a(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide v0
.end method

.method public static b(Lorg/apache/http/HttpRequest;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "nonnCseiqt"

    const-string v0, "Cesoonitnn"

    const/4 v3, 0x3

    const-string/jumbo v0, "iescnCnoto"

    const-string v0, "Connection"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "-memiKelAv"

    const-string v1, "eivmlAKee-"

    const/4 v3, 0x6

    const-string v1, "ee-Koepivl"

    const-string v1, "Keep-Alive"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p0, v0, v1}, Lorg/apache/http/HttpRequest;->addHeader(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    return-void
.end method

.method private static b(Lorg/apache/http/client/methods/HttpUriRequest;)Z
    .locals 12

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v0, "encttbndeg-cnoni"

    const-string v0, "content-encoding"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-interface {p0, v0}, Lorg/apache/http/client/methods/HttpUriRequest;->getHeaders(Ljava/lang/String;)[Lorg/apache/http/Header;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 v1, 0x0

    const/4 v11, 0x1

    const/4 v2, 0x6

    const/4 v11, 0x4

    const/4 v2, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eqz v0, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    array-length v3, v0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    move v4, v1

    move v4, v1

    const/4 v11, 0x6

    move v4, v1

    move v4, v1

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-ge v4, v3, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    aget-object v5, v0, v4

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string/jumbo v6, "ipgz"

    const-string/jumbo v6, "zgpi"

    const/4 v11, 0x5

    const-string/jumbo v6, "pzig"

    const-string v6, "gzip"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-interface {v5}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-virtual {v6, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-eqz v5, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    return v2

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v0, "ncoettupne-t"

    const-string v0, "etc-ontoetnp"

    const/4 v11, 0x7

    const-string/jumbo v0, "ptnn-yepoect"

    const-string v0, "content-type"

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-interface {p0, v0}, Lorg/apache/http/client/methods/HttpUriRequest;->getHeaders(Ljava/lang/String;)[Lorg/apache/http/Header;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-eqz p0, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    array-length v0, p0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x4

    if-ge v3, v0, :cond_4

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    aget-object v4, p0, v3

    const/4 v11, 0x6

    const/4 v10, 0x5

    sget-object v5, Lcom/alipay/android/phone/mrpc/core/b;->b:[Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    array-length v6, v5

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    move v7, v1

    move v7, v1

    const/4 v11, 0x2

    move v7, v1

    move v7, v1

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-ge v7, v6, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    aget-object v8, v5, v7

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-interface {v4}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v9, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-eqz v8, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x0

    return v1

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_2

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto :goto_1

    :cond_4
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    return v2
.end method


# virtual methods
.method public final a(Lorg/apache/http/client/HttpRequestRetryHandler;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast v0, Lorg/apache/http/impl/client/DefaultHttpClient;

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lorg/apache/http/impl/client/DefaultHttpClient;->setHttpRequestRetryHandler(Lorg/apache/http/client/HttpRequestRetryHandler;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lorg/apache/http/HttpHost;",
            "Lorg/apache/http/HttpRequest;",
            "Lorg/apache/http/client/ResponseHandler<",
            "+TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2, p3}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lorg/apache/http/HttpHost;",
            "Lorg/apache/http/HttpRequest;",
            "Lorg/apache/http/client/ResponseHandler<",
            "+TT;>;",
            "Lorg/apache/http/protocol/HttpContext;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2, p3, p4}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lorg/apache/http/client/methods/HttpUriRequest;",
            "Lorg/apache/http/client/ResponseHandler<",
            "+TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-interface {v0, p1, p2}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1
.end method

.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lorg/apache/http/client/methods/HttpUriRequest;",
            "Lorg/apache/http/client/ResponseHandler<",
            "+TT;>;",
            "Lorg/apache/http/protocol/HttpContext;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2, p3}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method

.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-interface {v0, p1, p2}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2, p3}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lorg/apache/http/client/HttpClient;->execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method

.method public final getConnectionManager()Lorg/apache/http/conn/ClientConnectionManager;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lorg/apache/http/client/HttpClient;->getConnectionManager()Lorg/apache/http/conn/ClientConnectionManager;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public final getParams()Lorg/apache/http/params/HttpParams;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b;->d:Lorg/apache/http/client/HttpClient;

    const/4 v1, 0x7

    move v2, v1

    invoke-interface {v0}, Lorg/apache/http/client/HttpClient;->getParams()Lorg/apache/http/params/HttpParams;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method
