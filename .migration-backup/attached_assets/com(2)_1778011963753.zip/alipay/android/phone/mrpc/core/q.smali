.class public final Lcom/alipay/android/phone/mrpc/core/q;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lcom/alipay/android/phone/mrpc/core/u;",
        ">;"
    }
.end annotation


# static fields
.field private static final e:Lorg/apache/http/client/HttpRequestRetryHandler;


# instance fields
.field protected a:Lcom/alipay/android/phone/mrpc/core/l;

.field protected b:Landroid/content/Context;

.field protected c:Lcom/alipay/android/phone/mrpc/core/o;

.field d:Ljava/lang/String;

.field private f:Lorg/apache/http/client/methods/HttpUriRequest;

.field private g:Lorg/apache/http/protocol/HttpContext;

.field private h:Lorg/apache/http/client/CookieStore;

.field private i:Landroid/webkit/CookieManager;

.field private j:Lorg/apache/http/entity/AbstractHttpEntity;

.field private k:Lorg/apache/http/HttpHost;

.field private l:Ljava/net/URL;

.field private m:I

.field private n:Z

.field private o:Z

.field private p:Ljava/lang/String;

.field private q:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/ad;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/alipay/android/phone/mrpc/core/ad;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/q;->e:Lorg/apache/http/client/HttpRequestRetryHandler;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/l;Lcom/alipay/android/phone/mrpc/core/o;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    new-instance v0, Lorg/apache/http/protocol/BasicHttpContext;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lorg/apache/http/protocol/BasicHttpContext;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->g:Lorg/apache/http/protocol/HttpContext;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lorg/apache/http/impl/client/BasicCookieStore;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {v0}, Lorg/apache/http/impl/client/BasicCookieStore;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->h:Lorg/apache/http/client/CookieStore;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->m:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->n:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->o:Z

    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->p:Ljava/lang/String;

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v2, 0x2

    iget-object p1, p1, Lcom/alipay/android/phone/mrpc/core/l;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/q;->b:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return-void
.end method

.method private static a([Ljava/lang/String;)J
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s@ @ o~@~~m~@-~ ~4r @ i~cd @a~ou ~@@ b@@.@~f~~ @~ol@@~ b~@~M~il/@/sovn 1y@~ i  ~tfS~tKo~@~o b "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    array-length v1, p0

    const/4 v3, 0x0

    move v4, v3

    if-ge v0, v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    aget-object v1, p0, v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, "axamm-g"

    const-string/jumbo v2, "xgs-maa"

    const/4 v4, 0x2

    const-string v2, "amx-oag"

    const-string/jumbo v2, "max-age"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    or-int/2addr v4, v3

    add-int/lit8 v1, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    aget-object v1, p0, v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-wide v0

    :catch_0
    :cond_0
    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-wide v0
.end method

.method private static a(Lorg/apache/http/HttpResponse;)Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-direct {v0}, Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p0}, Lorg/apache/http/HttpResponse;->getAllHeaders()[Lorg/apache/http/Header;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge v2, v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    aget-object v3, p0, v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-interface {v3}, Lorg/apache/http/Header;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v3}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v4, v3}, Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;->setHead(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object v0
.end method

.method private a(Lorg/apache/http/HttpResponse;ILjava/lang/String;)Lcom/alipay/android/phone/mrpc/core/u;
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string/jumbo v0, "rae ubeuo Amettpltamrcosrrry!O"

    const-string/jumbo v0, "yaemrpaotA!lrc oeustmerO rurtr"

    const/4 v11, 0x7

    const-string/jumbo v0, "sru atum!aottrSre erloApyurreO"

    const-string v0, "ArrayOutputStream close error!"

    const/4 v11, 0x5

    const/4 v10, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/lang/Thread;->getId()J

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v2, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-eqz v1, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-interface {v3}, Lorg/apache/http/StatusLine;->getStatusCode()I

    move-result v3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/16 v4, 0xc8

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-ne v3, v4, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v3}, Ljava/lang/Thread;->getId()J

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-instance v3, Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-direct {p0, v1, v3}, Lcom/alipay/android/phone/mrpc/core/q;->a(Lorg/apache/http/HttpEntity;Ljava/io/OutputStream;)V

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v6, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    iput-boolean v6, p0, Lcom/alipay/android/phone/mrpc/core/q;->o:Z

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v6, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    sub-long/2addr v7, v4

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v6, v7, v8}, Lcom/alipay/android/phone/mrpc/core/l;->c(J)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    array-length v5, v1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    int-to-long v5, v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v4, v5, v6}, Lcom/alipay/android/phone/mrpc/core/l;->a(J)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    new-instance v4, Lcom/alipay/android/phone/mrpc/core/p;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {p1}, Lcom/alipay/android/phone/mrpc/core/q;->a(Lorg/apache/http/HttpResponse;)Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;

    move-result-object v5

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v4, v5, p2, p3, v1}, Lcom/alipay/android/phone/mrpc/core/p;-><init>(Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;ILjava/lang/String;[B)V

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {p1}, Lcom/alipay/android/phone/mrpc/core/q;->b(Lorg/apache/http/HttpResponse;)J

    move-result-wide p2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getEntity()Lorg/apache/http/HttpEntity;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-interface {p1}, Lorg/apache/http/HttpEntity;->getContentType()Lorg/apache/http/Header;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-eqz p1, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-interface {p1}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {p1}, Lcom/alipay/android/phone/mrpc/core/q;->a(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string v1, "chteoar"

    const/4 v11, 0x3

    const-string/jumbo v1, "pcsrhae"

    const-string v1, "charset"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    move-object v2, v1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v1, "tpey-bnoqTte"

    const-string v1, "eynttbpeoT-n"

    const/4 v11, 0x4

    const-string v1, "Ttsn-tCneeoy"

    const-string v1, "Content-Type"

    const/4 v11, 0x3

    invoke-virtual {p1, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    check-cast p1, Ljava/lang/String;

    move-object v9, v2

    move-object v9, v2

    move-object v9, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    goto :goto_0

    :cond_0
    move-object p1, v2

    move-object p1, v2

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v4, v2}, Lcom/alipay/android/phone/mrpc/core/u;->b(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v4, p1}, Lcom/alipay/android/phone/mrpc/core/p;->a(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v4, v1, v2}, Lcom/alipay/android/phone/mrpc/core/p;->a(J)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v4, p2, p3}, Lcom/alipay/android/phone/mrpc/core/p;->b(J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    goto :goto_3

    :catch_0
    move-exception p1

    const/4 v11, 0x2

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v11, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    throw p2

    :catchall_0
    move-exception p1

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    goto :goto_1

    :catchall_1
    move-exception p1

    :goto_1
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-eqz v2, :cond_1

    :try_start_3
    const/4 v11, 0x0

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto :goto_2

    :catch_1
    move-exception p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x7

    throw p2

    :cond_1
    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    throw p1

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x5

    if-nez v1, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-interface {p1}, Lorg/apache/http/StatusLine;->getStatusCode()I

    :cond_3
    :goto_3
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    return-object v2
.end method

.method private static a(Ljava/lang/String;)Ljava/util/HashMap;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v1, ";"

    const-string v1, ";"

    const/4 v8, 0x7

    const-string v1, ";"

    const-string v1, ";"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    array-length v1, p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v2, 0x0

    move v8, v2

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v3, v2

    const/4 v8, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-ge v3, v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x7

    aget-object v4, p0, v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/16 v5, 0x3d

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v6, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-ne v5, v6, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v5, "unemtn-eTtpo"

    const-string/jumbo v5, "t-oeCpuenTnt"

    const/4 v8, 0x3

    const-string v5, "enyno-ttpToe"

    const-string v5, "Content-Type"

    const/4 v8, 0x2

    const/4 v7, 0x4

    filled-new-array {v5, v4}, [Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    goto :goto_1

    :cond_0
    const/4 v7, 0x5

    move v8, v7

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x4

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    aget-object v5, v4, v2

    const/4 v7, 0x4

    move v8, v7

    const/4 v6, 0x1

    shl-int/2addr v8, v6

    const/4 v7, 0x0

    move v8, v7

    aget-object v4, v4, v6

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    return-object v0
.end method

.method private a(Lorg/apache/http/HttpEntity;Ljava/io/OutputStream;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/alipay/android/phone/mrpc/core/b;->a(Lorg/apache/http/HttpEntity;)Ljava/io/InputStream;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-interface {p1}, Lorg/apache/http/HttpEntity;->getContentLength()J

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/16 p1, 0x800

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array p1, p1, [B

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/io/InputStream;->read([B)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-eq v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/alipay/android/phone/mrpc/core/t;->h()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v2, :cond_0

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x2

    move v3, v2

    move v3, v2

    const/4 v4, 0x4

    invoke-virtual {p2, p1, v2, v1}, Ljava/io/OutputStream;->write([BII)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/io/OutputStream;->flush()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/r;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance p2, Ljava/io/IOException;

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const-string v2, "Wetsob  orkEr!ueppqtHrtrr"

    const-string/jumbo v2, "rreo tspkreoq Wprttu!rEHR"

    const/4 v4, 0x2

    const-string/jumbo v2, "oresrEueR eWr!oqkrptutHt "

    const-string v2, "HttpWorker Request Error!"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p2, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/r;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x2

    throw p1
.end method

.method private static b(Lorg/apache/http/HttpResponse;)J
    .locals 6

    const/4 v5, 0x5

    const-string v0, "cqlo-etphrCon"

    const-string/jumbo v0, "tlnCcorCqhe-o"

    const/4 v5, 0x6

    const-string/jumbo v0, "tacohCoeqr-nl"

    const-string v0, "Cache-Control"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p0, v0}, Lorg/apache/http/HttpResponse;->getFirstHeader(Ljava/lang/String;)Lorg/apache/http/Header;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "="

    const-string v1, "="

    const/4 v5, 0x1

    const-string v1, "="

    const-string v1, "="

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-lt v1, v2, :cond_0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/q;->a([Ljava/lang/String;)J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-wide v0

    :catch_0
    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v0, "xrspsiE"

    const/4 v5, 0x7

    const-string/jumbo v0, "xEsrsep"

    const-string v0, "Expires"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p0, v0}, Lorg/apache/http/HttpResponse;->getFirstHeader(Ljava/lang/String;)Lorg/apache/http/Header;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p0, :cond_1

    const/4 v4, 0x0

    and-int/2addr v5, v4

    invoke-interface {p0}, Lorg/apache/http/Header;->getValue()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/b;->b(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-wide v0
.end method

.method private b()Ljava/net/URI;
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/alipay/android/phone/mrpc/core/o;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->d:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz v1, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v1, Ljava/net/URI;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-direct {v1, v0}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v1, "blomnld uu hol mult en"

    const-string v1, "dllmo lb s tuulneonu h"

    const/4 v3, 0x2

    const-string/jumbo v1, "ohusorntlebolllu dn   "

    const-string/jumbo v1, "url should not be null"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw v0
.end method

.method private c()Lorg/apache/http/client/methods/HttpUriRequest;
    .locals 5

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->j:Lorg/apache/http/entity/AbstractHttpEntity;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/alipay/android/phone/mrpc/core/o;->b()[B

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v2, "pigz"

    const-string/jumbo v2, "zipg"

    const-string v2, "gzip"

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Lcom/alipay/android/phone/mrpc/core/o;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v2, "retu"

    const-string/jumbo v2, "rteu"

    const/4 v4, 0x5

    const-string v2, "erut"

    const-string/jumbo v2, "true"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/b;->a([B)Lorg/apache/http/entity/AbstractHttpEntity;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->j:Lorg/apache/http/entity/AbstractHttpEntity;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Lorg/apache/http/entity/ByteArrayEntity;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1, v0}, Lorg/apache/http/entity/ByteArrayEntity;-><init>([B)V

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->j:Lorg/apache/http/entity/AbstractHttpEntity;

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->j:Lorg/apache/http/entity/AbstractHttpEntity;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/o;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lorg/apache/http/entity/AbstractHttpEntity;->setContentType(Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->j:Lorg/apache/http/entity/AbstractHttpEntity;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Lorg/apache/http/client/methods/HttpPost;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->b()Ljava/net/URI;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Lorg/apache/http/client/methods/HttpPost;-><init>(Ljava/net/URI;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Lorg/apache/http/client/methods/HttpPost;->setEntity(Lorg/apache/http/HttpEntity;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    goto :goto_1

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lorg/apache/http/client/methods/HttpGet;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->b()Ljava/net/URI;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Lorg/apache/http/client/methods/HttpGet;-><init>(Ljava/net/URI;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method private d()Lcom/alipay/android/phone/mrpc/core/u;
    .locals 15

    const/4 v14, 0x0

    const-string/jumbo v0, "inotebcnciot"

    const-string/jumbo v0, "icetovnnctio"

    const-string/jumbo v0, "tyivieuntcon"

    const-string v0, "connectivity"

    :goto_0
    const/4 v14, 0x3

    const/4 v1, 0x3

    const/4 v14, 0x0

    const/4 v2, 0x6

    const/4 v14, 0x4

    const/4 v3, 0x2

    const/4 v14, 0x1

    const/4 v4, 0x0

    :try_start_0
    const/4 v14, 0x5

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->b:Landroid/content/Context;

    const/4 v14, 0x6

    invoke-virtual {v5, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    const/4 v14, 0x7

    check-cast v5, Landroid/net/ConnectivityManager;

    const/4 v14, 0x2

    invoke-virtual {v5}, Landroid/net/ConnectivityManager;->getAllNetworkInfo()[Landroid/net/NetworkInfo;

    move-result-object v5

    const/4 v14, 0x3

    const/4 v6, 0x1

    const/4 v14, 0x4

    if-nez v5, :cond_1

    :cond_0
    const/4 v14, 0x4

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    goto :goto_2

    :cond_1
    const/4 v14, 0x3

    array-length v7, v5

    const/4 v14, 0x4

    move v8, v4

    move v8, v4

    move v8, v4

    move v8, v4

    :goto_1
    const/4 v14, 0x1

    if-ge v8, v7, :cond_0

    const/4 v14, 0x6

    aget-object v9, v5, v8

    const/4 v14, 0x5

    if-eqz v9, :cond_2

    const/4 v14, 0x7

    invoke-virtual {v9}, Landroid/net/NetworkInfo;->isAvailable()Z

    move-result v10

    const/4 v14, 0x4

    if-eqz v10, :cond_2

    const/4 v14, 0x2

    invoke-virtual {v9}, Landroid/net/NetworkInfo;->isConnectedOrConnecting()Z

    move-result v9

    const/4 v14, 0x5

    if-eqz v9, :cond_2

    const/4 v14, 0x6

    move v5, v6

    move v5, v6

    const/4 v14, 0x3

    goto :goto_2

    :cond_2
    const/4 v14, 0x5

    add-int/lit8 v8, v8, 0x1

    const/4 v14, 0x7

    goto :goto_1

    :goto_2
    const/4 v14, 0x2

    if-eqz v5, :cond_12

    const/4 v14, 0x1

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x1

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/o;->d()Ljava/util/ArrayList;

    move-result-object v5

    const/4 v14, 0x2

    if-eqz v5, :cond_3

    const/4 v14, 0x2

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    const/4 v14, 0x5

    if-nez v7, :cond_3

    const/4 v14, 0x7

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3
    const/4 v14, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v14, 0x0

    if-eqz v7, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    const/4 v14, 0x0

    check-cast v7, Lorg/apache/http/Header;

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->c()Lorg/apache/http/client/methods/HttpUriRequest;

    move-result-object v8

    const/4 v14, 0x3

    invoke-interface {v8, v7}, Lorg/apache/http/client/methods/HttpUriRequest;->addHeader(Lorg/apache/http/Header;)V

    const/4 v14, 0x5

    goto :goto_3

    :cond_3
    const/4 v14, 0x0

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->c()Lorg/apache/http/client/methods/HttpUriRequest;

    move-result-object v5

    const/4 v14, 0x5

    invoke-static {v5}, Lcom/alipay/android/phone/mrpc/core/b;->a(Lorg/apache/http/HttpRequest;)V

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->c()Lorg/apache/http/client/methods/HttpUriRequest;

    move-result-object v5

    const/4 v14, 0x5

    invoke-static {v5}, Lcom/alipay/android/phone/mrpc/core/b;->b(Lorg/apache/http/HttpRequest;)V

    const/4 v14, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->c()Lorg/apache/http/client/methods/HttpUriRequest;

    move-result-object v5

    const/4 v14, 0x3

    const-string/jumbo v7, "kpeobi"

    const-string v7, "ckoeib"

    const-string/jumbo v7, "okqioc"

    const-string v7, "cookie"

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->i()Landroid/webkit/CookieManager;

    move-result-object v8

    const/4 v14, 0x4

    iget-object v9, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x2

    invoke-virtual {v9}, Lcom/alipay/android/phone/mrpc/core/o;->a()Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x3

    invoke-virtual {v8, v9}, Landroid/webkit/CookieManager;->getCookie(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x6

    invoke-interface {v5, v7, v8}, Lorg/apache/http/client/methods/HttpUriRequest;->addHeader(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->g:Lorg/apache/http/protocol/HttpContext;

    const/4 v14, 0x3

    const-string v7, "ess.thrittocupook"

    const-string/jumbo v7, "oei.cturthoptosk-"

    const-string/jumbo v7, "ttkm-oeihco.oersp"

    const-string v7, "http.cookie-store"

    const/4 v14, 0x5

    iget-object v8, p0, Lcom/alipay/android/phone/mrpc/core/q;->h:Lorg/apache/http/client/CookieStore;

    const/4 v14, 0x3

    invoke-interface {v5, v7, v8}, Lorg/apache/http/protocol/HttpContext;->setAttribute(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v14, 0x0

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v14, 0x2

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/l;->a()Lcom/alipay/android/phone/mrpc/core/b;

    move-result-object v5

    const/4 v14, 0x5

    sget-object v7, Lcom/alipay/android/phone/mrpc/core/q;->e:Lorg/apache/http/client/HttpRequestRetryHandler;

    const/4 v14, 0x3

    invoke-virtual {v5, v7}, Lcom/alipay/android/phone/mrpc/core/b;->a(Lorg/apache/http/client/HttpRequestRetryHandler;)V

    const/4 v14, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v14, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->f()Ljava/lang/String;

    const/4 v14, 0x3

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v14, 0x4

    invoke-interface {v5}, Lorg/apache/http/client/methods/HttpUriRequest;->getURI()Ljava/net/URI;

    move-result-object v5

    const/4 v14, 0x1

    invoke-virtual {v5}, Ljava/net/URI;->toString()Ljava/lang/String;

    const/4 v14, 0x4

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v14, 0x2

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/l;->a()Lcom/alipay/android/phone/mrpc/core/b;

    move-result-object v5

    const/4 v14, 0x2

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/b;->getParams()Lorg/apache/http/params/HttpParams;

    move-result-object v5

    const/4 v14, 0x6

    const-string/jumbo v9, "oheeou.rtlpatfr-ttyduppx"

    const-string v9, "eldytatpxt-uu.oretf.rphp"

    const-string/jumbo v9, "t-poybx.fuptdlharetouert"

    const-string v9, "http.route.default-proxy"

    const/4 v14, 0x7

    iget-object v10, p0, Lcom/alipay/android/phone/mrpc/core/q;->b:Landroid/content/Context;

    const/4 v14, 0x3

    invoke-virtual {v10, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    const/4 v14, 0x5

    check-cast v10, Landroid/net/ConnectivityManager;

    const/4 v14, 0x1

    invoke-virtual {v10}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v10

    const/4 v14, 0x7

    const/4 v11, 0x0

    const/4 v14, 0x5

    if-eqz v10, :cond_4

    const/4 v14, 0x0

    invoke-virtual {v10}, Landroid/net/NetworkInfo;->isAvailable()Z

    move-result v10

    const/4 v14, 0x6

    if-eqz v10, :cond_4

    const/4 v14, 0x0

    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x2

    invoke-static {}, Landroid/net/Proxy;->getDefaultPort()I

    move-result v12

    const/4 v14, 0x1

    if-eqz v10, :cond_4

    const/4 v14, 0x0

    new-instance v13, Lorg/apache/http/HttpHost;

    const/4 v14, 0x1

    invoke-direct {v13, v10, v12}, Lorg/apache/http/HttpHost;-><init>(Ljava/lang/String;I)V

    const/4 v14, 0x1

    goto :goto_4

    :cond_4
    move-object v13, v11

    move-object v13, v11

    :goto_4
    const/4 v14, 0x3

    if-eqz v13, :cond_5

    const/4 v14, 0x6

    invoke-virtual {v13}, Lorg/apache/http/HttpHost;->getHostName()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x3

    const-string v12, "1.1.q.u72"

    const-string v12, "710.2..1q"

    const-string v12, ".170.1.p2"

    const-string v12, "127.0.0.1"

    const/4 v14, 0x0

    invoke-static {v10, v12}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v10

    const/4 v14, 0x0

    if-eqz v10, :cond_5

    invoke-virtual {v13}, Lorg/apache/http/HttpHost;->getPort()I

    move-result v10

    const/4 v14, 0x7

    const/16 v12, 0x1f97

    const/4 v14, 0x7

    if-ne v10, v12, :cond_5

    const/4 v14, 0x0

    goto :goto_5

    :cond_5
    move-object v11, v13

    move-object v11, v13

    move-object v11, v13

    move-object v11, v13

    :goto_5
    const/4 v14, 0x1

    invoke-interface {v5, v9, v11}, Lorg/apache/http/params/HttpParams;->setParameter(Ljava/lang/String;Ljava/lang/Object;)Lorg/apache/http/params/HttpParams;

    const/4 v14, 0x3

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/q;->k:Lorg/apache/http/HttpHost;

    const/4 v14, 0x3

    if-eqz v5, :cond_6

    const/4 v14, 0x1

    goto :goto_6

    :cond_6
    const/4 v14, 0x7

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->h()Ljava/net/URL;

    move-result-object v5

    const/4 v14, 0x5

    new-instance v9, Lorg/apache/http/HttpHost;

    const/4 v14, 0x5

    invoke-virtual {v5}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x4

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->g()I

    move-result v11

    const/4 v14, 0x1

    invoke-virtual {v5}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x0

    invoke-direct {v9, v10, v11, v5}, Lorg/apache/http/HttpHost;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v14, 0x3

    iput-object v9, p0, Lcom/alipay/android/phone/mrpc/core/q;->k:Lorg/apache/http/HttpHost;

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    :goto_6
    const/4 v14, 0x1

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->g()I

    move-result v9

    const/4 v14, 0x7

    const/16 v10, 0x50

    const/4 v14, 0x3

    if-ne v9, v10, :cond_7

    const/4 v14, 0x6

    new-instance v5, Lorg/apache/http/HttpHost;

    const/4 v14, 0x7

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->h()Ljava/net/URL;

    move-result-object v9

    const/4 v14, 0x5

    invoke-virtual {v9}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x7

    invoke-direct {v5, v9}, Lorg/apache/http/HttpHost;-><init>(Ljava/lang/String;)V

    :cond_7
    const/4 v14, 0x4

    iget-object v9, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v14, 0x1

    invoke-virtual {v9}, Lcom/alipay/android/phone/mrpc/core/l;->a()Lcom/alipay/android/phone/mrpc/core/b;

    move-result-object v9

    const/4 v14, 0x3

    iget-object v10, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v14, 0x3

    iget-object v11, p0, Lcom/alipay/android/phone/mrpc/core/q;->g:Lorg/apache/http/protocol/HttpContext;

    const/4 v14, 0x2

    invoke-virtual {v9, v5, v10, v11}, Lcom/alipay/android/phone/mrpc/core/b;->execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;

    move-result-object v5

    const/4 v14, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    const/4 v14, 0x7

    iget-object v11, p0, Lcom/alipay/android/phone/mrpc/core/q;->a:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v14, 0x0

    sub-long/2addr v9, v7

    const/4 v14, 0x4

    invoke-virtual {v11, v9, v10}, Lcom/alipay/android/phone/mrpc/core/l;->b(J)V

    const/4 v14, 0x5

    iget-object v7, p0, Lcom/alipay/android/phone/mrpc/core/q;->h:Lorg/apache/http/client/CookieStore;

    const/4 v14, 0x1

    invoke-interface {v7}, Lorg/apache/http/client/CookieStore;->getCookies()Ljava/util/List;

    move-result-object v7

    const/4 v14, 0x5

    iget-object v8, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x0

    invoke-virtual {v8}, Lcom/alipay/android/phone/mrpc/core/o;->e()Z

    move-result v8

    const/4 v14, 0x5

    if-eqz v8, :cond_8

    const/4 v14, 0x7

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->i()Landroid/webkit/CookieManager;

    move-result-object v8

    const/4 v14, 0x3

    invoke-virtual {v8}, Landroid/webkit/CookieManager;->removeAllCookie()V

    :cond_8
    const/4 v14, 0x0

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v8

    const/4 v14, 0x7

    if-nez v8, :cond_b

    const/4 v14, 0x2

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_9
    :goto_7
    const/4 v14, 0x5

    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v14, 0x2

    if-eqz v8, :cond_b

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    const/4 v14, 0x7

    check-cast v8, Lorg/apache/http/cookie/Cookie;

    const/4 v14, 0x1

    invoke-interface {v8}, Lorg/apache/http/cookie/Cookie;->getDomain()Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x6

    if-eqz v9, :cond_9

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x2

    invoke-interface {v8}, Lorg/apache/http/cookie/Cookie;->getName()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x3

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, "="

    const-string v10, "="

    const-string v10, "="

    const-string v10, "="

    const/4 v14, 0x4

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    invoke-interface {v8}, Lorg/apache/http/cookie/Cookie;->getValue()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x6

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const-string/jumbo v10, "m;oain sq"

    const-string/jumbo v10, "nisa; omd"

    const-string/jumbo v10, "iosa;nm=d"

    const-string v10, "; domain="

    const/4 v14, 0x0

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v8}, Lorg/apache/http/cookie/Cookie;->getDomain()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x4

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    invoke-interface {v8}, Lorg/apache/http/cookie/Cookie;->isSecure()Z

    move-result v8

    const/4 v14, 0x5

    if-eqz v8, :cond_a

    const/4 v14, 0x2

    const-string v8, " eSmuc;r"

    const-string/jumbo v8, "rcSm;eu "

    const-string/jumbo v8, "rceuoS;e"

    const-string v8, "; Secure"

    const/4 v14, 0x1

    goto :goto_8

    :cond_a
    const/4 v14, 0x7

    const-string v8, ""

    const-string v8, ""

    const-string v8, ""

    const-string v8, ""

    :goto_8
    const/4 v14, 0x4

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x6

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->i()Landroid/webkit/CookieManager;

    move-result-object v9

    const/4 v14, 0x1

    iget-object v10, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x2

    invoke-virtual {v10}, Lcom/alipay/android/phone/mrpc/core/o;->a()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x6

    invoke-virtual {v9, v10, v8}, Landroid/webkit/CookieManager;->setCookie(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x2

    invoke-static {}, Landroid/webkit/CookieSyncManager;->getInstance()Landroid/webkit/CookieSyncManager;

    move-result-object v8

    const/4 v14, 0x7

    invoke-virtual {v8}, Landroid/webkit/CookieSyncManager;->sync()V

    const/4 v14, 0x7

    goto/16 :goto_7

    :cond_b
    const/4 v14, 0x4

    invoke-interface {v5}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v7

    const/4 v14, 0x4

    invoke-interface {v7}, Lorg/apache/http/StatusLine;->getStatusCode()I

    move-result v7

    const/4 v14, 0x2

    invoke-interface {v5}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v8

    const/4 v14, 0x3

    invoke-interface {v8}, Lorg/apache/http/StatusLine;->getReasonPhrase()Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x0

    const/16 v9, 0xc8

    const/4 v14, 0x1

    if-eq v7, v9, :cond_e

    const/4 v14, 0x0

    const/16 v9, 0x130

    const/4 v14, 0x0

    if-ne v7, v9, :cond_c

    const/4 v14, 0x0

    goto :goto_9

    :cond_c
    const/4 v14, 0x6

    move v6, v4

    move v6, v4

    :goto_9
    if-eqz v6, :cond_d

    const/4 v14, 0x2

    goto :goto_a

    :cond_d
    const/4 v14, 0x6

    new-instance v6, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x0

    invoke-interface {v5}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v7

    const/4 v14, 0x6

    invoke-interface {v7}, Lorg/apache/http/StatusLine;->getStatusCode()I

    move-result v7

    const/4 v14, 0x4

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v14, 0x5

    invoke-interface {v5}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object v5

    const/4 v14, 0x2

    invoke-interface {v5}, Lorg/apache/http/StatusLine;->getReasonPhrase()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x0

    invoke-direct {v6, v7, v5}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x7

    throw v6

    :cond_e
    :goto_a
    const/4 v14, 0x6

    invoke-direct {p0, v5, v7, v8}, Lcom/alipay/android/phone/mrpc/core/q;->a(Lorg/apache/http/HttpResponse;ILjava/lang/String;)Lcom/alipay/android/phone/mrpc/core/u;

    move-result-object v5

    const/4 v14, 0x2

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const/4 v14, 0x7

    if-eqz v5, :cond_f

    const/4 v14, 0x7

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/u;->b()[B

    move-result-object v8

    const/4 v14, 0x6

    if-eqz v8, :cond_f

    const/4 v14, 0x6

    invoke-virtual {v5}, Lcom/alipay/android/phone/mrpc/core/u;->b()[B

    move-result-object v8

    const/4 v14, 0x7

    array-length v8, v8

    const/4 v14, 0x3

    int-to-long v8, v8

    const/4 v14, 0x2

    goto :goto_b

    :cond_f
    move-wide v8, v6

    :goto_b
    const/4 v14, 0x0

    cmp-long v6, v8, v6

    const/4 v14, 0x4

    if-nez v6, :cond_10

    const/4 v14, 0x4

    instance-of v6, v5, Lcom/alipay/android/phone/mrpc/core/p;

    if-eqz v6, :cond_10

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v14, 0x0

    check-cast v6, Lcom/alipay/android/phone/mrpc/core/p;
    :try_end_0
    .catch Lcom/alipay/android/phone/mrpc/core/HttpException; {:try_start_0 .. :try_end_0} :catch_e
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_d
    .catch Ljavax/net/ssl/SSLHandshakeException; {:try_start_0 .. :try_end_0} :catch_c
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_0 .. :try_end_0} :catch_b
    .catch Ljavax/net/ssl/SSLException; {:try_start_0 .. :try_end_0} :catch_a
    .catch Lorg/apache/http/conn/ConnectionPoolTimeoutException; {:try_start_0 .. :try_end_0} :catch_9
    .catch Lorg/apache/http/conn/ConnectTimeoutException; {:try_start_0 .. :try_end_0} :catch_8
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_7
    .catch Lorg/apache/http/NoHttpResponseException; {:try_start_0 .. :try_end_0} :catch_6
    .catch Lorg/apache/http/conn/HttpHostConnectException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v14, 0x0

    invoke-virtual {v6}, Lcom/alipay/android/phone/mrpc/core/p;->a()Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;

    move-result-object v6

    const/4 v14, 0x1

    const-string/jumbo v7, "ntnehbLotCneog"

    const-string/jumbo v7, "nhtnoeCeLgton-"

    const-string/jumbo v7, "n-enCgunhttteo"

    const-string v7, "Content-Length"

    const/4 v14, 0x3

    invoke-virtual {v6, v7}, Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;->getHead(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x1

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_10
    :try_start_2
    const/4 v14, 0x5

    iget-object v6, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x4

    invoke-virtual {v6}, Lcom/alipay/android/phone/mrpc/core/o;->a()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x0

    if-eqz v6, :cond_11

    const/4 v14, 0x1

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->f()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v14, 0x1

    if-nez v6, :cond_11

    const/4 v14, 0x6

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->f()Ljava/lang/String;

    :cond_11
    const/4 v14, 0x6

    return-object v5

    :cond_12
    const/4 v14, 0x2

    new-instance v5, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x0

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v14, 0x5

    const-string v7, "e b oeapholilrabaittk ewvTnn"

    const-string/jumbo v7, "to aabar vhbn  ieekilewtnTlo"

    const-string/jumbo v7, "twaveeb qihn oaainl sletkoTr"

    const-string v7, "The network is not available"

    const/4 v14, 0x0

    invoke-direct {v5, v6, v7}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x5

    throw v5
    :try_end_2
    .catch Lcom/alipay/android/phone/mrpc/core/HttpException; {:try_start_2 .. :try_end_2} :catch_e
    .catch Ljava/net/URISyntaxException; {:try_start_2 .. :try_end_2} :catch_d
    .catch Ljavax/net/ssl/SSLHandshakeException; {:try_start_2 .. :try_end_2} :catch_c
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_2 .. :try_end_2} :catch_b
    .catch Ljavax/net/ssl/SSLException; {:try_start_2 .. :try_end_2} :catch_a
    .catch Lorg/apache/http/conn/ConnectionPoolTimeoutException; {:try_start_2 .. :try_end_2} :catch_9
    .catch Lorg/apache/http/conn/ConnectTimeoutException; {:try_start_2 .. :try_end_2} :catch_8
    .catch Ljava/net/SocketTimeoutException; {:try_start_2 .. :try_end_2} :catch_7
    .catch Lorg/apache/http/NoHttpResponseException; {:try_start_2 .. :try_end_2} :catch_6
    .catch Lorg/apache/http/conn/HttpHostConnectException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/net/UnknownHostException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/NullPointerException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    move-exception v0

    const/4 v14, 0x7

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x3

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x3

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x0

    if-eqz v1, :cond_13

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_13
    const/4 v14, 0x4

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x6

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x2

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x6

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x1

    throw v1

    :catch_2
    move-exception v1

    const/4 v14, 0x4

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x5

    iget v2, p0, Lcom/alipay/android/phone/mrpc/core/q;->m:I

    const/4 v14, 0x5

    if-gtz v2, :cond_14

    const/4 v14, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v14, 0x7

    iput v2, p0, Lcom/alipay/android/phone/mrpc/core/q;->m:I

    const/4 v14, 0x0

    goto/16 :goto_0

    :cond_14
    const/4 v14, 0x6

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x1

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x2

    invoke-direct {v0, v2, v1}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x1

    throw v0

    :catch_3
    move-exception v0

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x3

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x1

    if-eqz v1, :cond_15

    const/4 v14, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_15
    const/4 v14, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x4

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x6

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x2

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x3

    throw v1

    :catch_4
    move-exception v0

    const/4 v14, 0x1

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x5

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x3

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x0

    if-eqz v1, :cond_16

    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_16
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x5

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x7

    const/16 v2, 0x9

    const/4 v14, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x4

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x2

    throw v1

    :catch_5
    move-exception v0

    const/4 v14, 0x5

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x2

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x4

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x7

    if-eqz v1, :cond_17

    const/4 v14, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_17
    const/4 v14, 0x6

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x0

    const/16 v2, 0x8

    const/4 v14, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x5

    throw v1

    :catch_6
    move-exception v0

    const/4 v14, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x7

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x6

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x6

    if-eqz v1, :cond_18

    const/4 v14, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_18
    const/4 v14, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x6

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x4

    const/4 v2, 0x5

    const/4 v14, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x7

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x3

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x2

    throw v1

    :catch_7
    move-exception v0

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x2

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x1

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x6

    if-eqz v1, :cond_19

    const/4 v14, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_19
    const/4 v14, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x5

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x3

    const/4 v2, 0x4

    const/4 v14, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x6

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x5

    throw v1

    :catch_8
    move-exception v0

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v2

    const/4 v14, 0x2

    if-eqz v2, :cond_1a

    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_1a
    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x4

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v14, 0x2

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    invoke-direct {v2, v1, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x6

    throw v2

    :catch_9
    move-exception v0

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x4

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x3

    invoke-virtual {v2}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v2

    const/4 v14, 0x6

    if-eqz v2, :cond_1b

    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_1b
    const/4 v14, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x3

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v14, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x1

    invoke-direct {v2, v1, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x4

    throw v2

    :catch_a
    move-exception v0

    const/4 v14, 0x1

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x1

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x1

    if-eqz v1, :cond_1c

    const/4 v14, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_1c
    const/4 v14, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x2

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x1

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x4

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    throw v1

    :catch_b
    move-exception v0

    const/4 v14, 0x4

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x2

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x7

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x5

    if-eqz v1, :cond_1d

    const/4 v14, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_1d
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x0

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x5

    throw v1

    :catch_c
    move-exception v0

    const/4 v14, 0x1

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x3

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x7

    if-eqz v1, :cond_1e

    const/4 v14, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    :cond_1e
    const/4 v14, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x5

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/HttpException;

    const/4 v14, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v14, 0x0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x7

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v14, 0x7

    throw v1

    :catch_d
    move-exception v0

    const/4 v14, 0x5

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v14, 0x7

    const-string v2, "Ueselrr s! rarpor"

    const-string v2, " rrr!lueseaUrr po"

    const-string v2, "Uerm rearospr l!r"

    const-string v2, "Url parser error!"

    const/4 v14, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v14, 0x2

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v14, 0x3

    throw v1

    :catch_e
    move-exception v0

    const/4 v14, 0x3

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->e()V

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v14, 0x1

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/t;->f()Lcom/alipay/android/phone/mrpc/core/ac;

    move-result-object v1

    const/4 v14, 0x4

    if-eqz v1, :cond_1f

    const/4 v14, 0x0

    invoke-virtual {v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;->getCode()I

    const/4 v14, 0x7

    invoke-virtual {v0}, Lcom/alipay/android/phone/mrpc/core/HttpException;->getMsg()Ljava/lang/String;

    :cond_1f
    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    const/4 v14, 0x6

    throw v0
.end method

.method private e()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->f:Lorg/apache/http/client/methods/HttpUriRequest;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-interface {v0}, Lorg/apache/http/client/methods/HttpUriRequest;->abort()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private f()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->q:Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->q:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "pToeorptapyoe"

    const-string v1, "apenoTyptrepo"

    const/4 v3, 0x0

    const-string/jumbo v1, "ntyrebpTeaoop"

    const-string/jumbo v1, "operationType"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/alipay/android/phone/mrpc/core/o;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->q:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method private g()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->h()Ljava/net/URL;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/net/URL;->getPort()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/net/URL;->getDefaultPort()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/net/URL;->getPort()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0
.end method

.method private h()Ljava/net/URL;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->l:Ljava/net/URL;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Ljava/net/URL;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/alipay/android/phone/mrpc/core/o;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->l:Ljava/net/URL;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method private i()Landroid/webkit/CookieManager;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->i:Landroid/webkit/CookieManager;

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->i:Landroid/webkit/CookieManager;

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public final a()Lcom/alipay/android/phone/mrpc/core/o;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/q;->c:Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public final synthetic call()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/q;->d()Lcom/alipay/android/phone/mrpc/core/u;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method
