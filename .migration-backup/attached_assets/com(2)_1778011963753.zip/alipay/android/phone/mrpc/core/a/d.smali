.class public final Lcom/alipay/android/phone/mrpc/core/a/d;
.super Lcom/alipay/android/phone/mrpc/core/a/a;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Type;[B)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/alipay/android/phone/mrpc/core/a/a;-><init>(Ljava/lang/reflect/Type;[B)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 8

    :try_start_0
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~smbfSa~~ ~u~t iro@tc@@@d@ @~~n~l@o~i  ~ b~@o~ /v1~@K   y@~ @@@~.o ~/~@@ o@s @i@@ ~b4- lo~~ ~~M"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->b:[B

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    const/4 v6, 0x5

    and-int/2addr v7, v6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v6, 0x4

    shl-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/lang/Thread;->getId()J

    const/4 v7, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const-string/jumbo v0, "ssumlsraeutt"

    const-string/jumbo v0, "tussrttusale"

    const/4 v7, 0x6

    const-string/jumbo v0, "leaSoutttsru"

    const-string/jumbo v0, "resultStatus"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/16 v2, 0x3e8

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-ne v0, v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->a:Ljava/lang/reflect/Type;

    const/4 v6, 0x2

    move v7, v6

    const-class v2, Ljava/lang/String;

    const/4 v7, 0x5

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const-string/jumbo v3, "srltmb"

    const-string/jumbo v3, "trlmse"

    const/4 v7, 0x5

    const-string/jumbo v3, "utusle"

    const-string/jumbo v3, "result"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-ne v0, v2, :cond_0

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->a:Ljava/lang/reflect/Type;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0, v1}, Lcom/alipay/a/a/e;->b(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-object v0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const-string/jumbo v2, "stip"

    const-string/jumbo v2, "itsp"

    const/4 v7, 0x2

    const-string/jumbo v2, "stip"

    const-string/jumbo v2, "tips"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v2, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v2, v0, v1}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    throw v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v2, 0xa

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v4, "son rsepo ="

    const-string/jumbo v4, "sps=o  neor"

    const/4 v7, 0x6

    const-string v4, "eopn= rsq e"

    const-string/jumbo v4, "response  ="

    const/4 v7, 0x1

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v5, p0, Lcom/alipay/android/phone/mrpc/core/a/a;->b:[B

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v4, v5}, Ljava/lang/String;-><init>([B)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v4, ":"

    const-string v4, ":"

    const/4 v7, 0x4

    const-string v4, ":"

    const-string v4, ":"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-nez v3, :cond_2

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v1, v2, v0}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    throw v1
.end method
