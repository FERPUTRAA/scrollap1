.class final Lcom/alipay/android/phone/mrpc/core/b$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/android/phone/mrpc/core/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:I


# direct methods
.method static synthetic a(Lcom/alipay/android/phone/mrpc/core/b$b;Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@s@f~ o  ~v ~t~~@~o~@S/  o~l~ 1@~tb@@@oi~~/@@m f  ~4si dnMl @ @@ ri~@~ucy@. ~ ~~o~@abo@@@@K~~~-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/alipay/android/phone/mrpc/core/b$b;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p0, p0, Lcom/alipay/android/phone/mrpc/core/b$b;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Landroid/util/Log;->println(ILjava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method static synthetic a(Lcom/alipay/android/phone/mrpc/core/b$b;)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/b$b;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget p0, p0, Lcom/alipay/android/phone/mrpc/core/b$b;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-static {v0, p0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p0
.end method
