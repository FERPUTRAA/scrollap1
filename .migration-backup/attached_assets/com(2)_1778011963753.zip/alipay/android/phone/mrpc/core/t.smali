.class public abstract Lcom/alipay/android/phone/mrpc/core/t;
.super Ljava/lang/Object;


# instance fields
.field protected a:Lcom/alipay/android/phone/mrpc/core/ac;

.field private b:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/t;->b:Z

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public final f()Lcom/alipay/android/phone/mrpc/core/ac;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~s/s~u1o~i b@@b~t~-~ ~l ~m~ t ~ ~@~fd~@@~iK ~@~~ M @@i@~v.  l@ a@4 @@c@@~~S @~@rn@@/@o ooo  boy"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/t;->a:Lcom/alipay/android/phone/mrpc/core/ac;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public final g()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/t;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public final h()Z
    .locals 3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/alipay/android/phone/mrpc/core/t;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method
