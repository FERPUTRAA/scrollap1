.class public final Lcom/alipay/android/phone/mrpc/core/k;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/android/phone/mrpc/core/k$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/util/regex/Pattern;

.field private static final b:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string v0, "0]s,z-})A]0] 0,(a(]9)1 ]-9024] 2-99-3],-[[-0[[0]{-1[2[{-[([-]}(s[9}{9:,[Z}--)90]:{9)"

    const-string/jumbo v0, "{9s-0, -[[9}}[30A]-[a] ])--01[2z}}]21Z{(-{(]:--9],]([ -0[(]9])4[9[{99),]0[0-:[0-),92"

    const/4 v2, 0x3

    const-string v0, "0{AmZ-)9[ 0-2-()-{::,(2[[0}[9,-]]-(-9 [)az[9[]]-1[[]-09,-],]{-1{4(909)[}2] 9}0]}03[]"

    const-string v0, "([0-9]{1,2})[- ]([A-Za-z]{3,9})[- ]([0-9]{2,4})[ ]([0-9]{1,2}:[0-9][0-9]:[0-9][0-9])"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/k;->a:Ljava/util/regex/Pattern;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "}]20o-]9 [][ ,{0(0{[2){[:9,[+[ }[)-)][9-0,-9A[9((,-)][10:}{Z]z9a]--]}-]39-[(m02]1 [09]"

    const-string/jumbo v0, "}-]m-{ -[,a-[9(]))]([}9}3]]z9902+{:02 [Z2((:]-1[}0],,[][[--[ [9A{{009 [9]]0,]0]9-)1)[-"

    const/4 v2, 0x3

    const-string v0, "9]{-{b[]-9[(]9+[-2]]:}1:[9)]A[)0]- 0[Z -a0[([93)0[,{-}2(]}041z0-}][9 -{][,]2]09,,-([) "

    const-string v0, "[ ]([A-Za-z]{3,9})[ ]+([0-9]{1,2})[ ]([0-9]{1,2}:[0-9][0-9]:[0-9][0-9])[ ]([0-9]{2,4})"

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/k;->b:Ljava/util/regex/Pattern;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Ljava/lang/String;)J
    .locals 14

    sget-object v0, Lcom/alipay/android/phone/mrpc/core/k;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v0, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/k;->b(Ljava/lang/String;)I

    move-result p0

    invoke-virtual {v0, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/alipay/android/phone/mrpc/core/k;->c(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/alipay/android/phone/mrpc/core/k;->d(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/k;->e(Ljava/lang/String;)Lcom/alipay/android/phone/mrpc/core/k$a;

    move-result-object v0

    goto :goto_0

    :cond_0
    sget-object v0, Lcom/alipay/android/phone/mrpc/core/k;->b:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0, v5}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/k;->c(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/k;->b(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/alipay/android/phone/mrpc/core/k;->e(Ljava/lang/String;)Lcom/alipay/android/phone/mrpc/core/k$a;

    move-result-object v3

    invoke-virtual {p0, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/k;->d(Ljava/lang/String;)I

    move-result p0

    move-object v13, v3

    move-object v13, v3

    move-object v13, v3

    move v3, p0

    move v3, p0

    move v3, p0

    move v3, p0

    move p0, v0

    move p0, v0

    move p0, v0

    move p0, v0

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    :goto_0
    const/4 v2, 0x0

    const/16 v4, 0x7f6

    if-lt v3, v4, :cond_1

    move v11, v2

    move v11, v2

    move v11, v2

    move v11, v2

    move v12, v4

    move v12, v4

    move v12, v4

    move v12, v4

    move v10, v5

    move v10, v5

    move v10, v5

    move v10, v5

    goto :goto_1

    :cond_1
    move v10, p0

    move v10, p0

    move v11, v1

    move v11, v1

    move v11, v1

    move v12, v3

    move v12, v3

    move v12, v3

    move v12, v3

    :goto_1
    new-instance p0, Landroid/text/format/Time;

    const-string v1, "TCU"

    const-string v1, "TUC"

    const-string v1, "UCT"

    const-string v1, "UTC"

    invoke-direct {p0, v1}, Landroid/text/format/Time;-><init>(Ljava/lang/String;)V

    iget v7, v0, Lcom/alipay/android/phone/mrpc/core/k$a;->c:I

    iget v8, v0, Lcom/alipay/android/phone/mrpc/core/k$a;->b:I

    iget v9, v0, Lcom/alipay/android/phone/mrpc/core/k$a;->a:I

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    invoke-virtual/range {v6 .. v12}, Landroid/text/format/Time;->set(IIIIII)V

    invoke-virtual {p0, v2}, Landroid/text/format/Time;->toMillis(Z)J

    move-result-wide v0

    return-wide v0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method private static b(Ljava/lang/String;)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~ @iu o@tK @~@/ .m~o~~  @s~ ~i@bn  f~@a@-vt @~@~r i@1@ob~M@u ~~y~o~@b ~~~/@@lS @dl@o@4 ~~c~fo@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ne v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/lit8 v0, v0, -0x30

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    mul-int/lit8 v0, v0, 0xa

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/lit8 p0, p0, -0x30

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/2addr v0, p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    add-int/lit8 p0, p0, -0x30

    const/4 v3, 0x2

    move v4, v3

    return p0
.end method

.method private static c(Ljava/lang/String;)I
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v3}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/2addr v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    add-int/2addr v1, p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-int/lit16 v1, v1, -0x123

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/16 p0, 0x9

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq v1, p0, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v4, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eq v1, v4, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/16 v2, 0x16

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eq v1, v2, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 v0, 0x1a

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq v1, v0, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/16 v0, 0x1d

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eq v1, v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/16 v0, 0x20

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eq v1, v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/16 v0, 0x28

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eq v1, v0, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/16 v0, 0x2a

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eq v1, v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 v0, 0x30

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eq v1, v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    packed-switch v1, :pswitch_data_0

    const/4 v6, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    throw p0

    :pswitch_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/16 p0, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    return p0

    :pswitch_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 p0, 0x4

    :pswitch_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    return p0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v4

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 p0, 0x5

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    return p0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 p0, 0x6

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    return p0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 p0, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    return p0

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    return v3

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 p0, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x5

    return p0

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return v0

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v2

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/16 p0, 0xb

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    return p0

    :pswitch_data_0
    .packed-switch 0x23
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static d(Ljava/lang/String;)I
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x6

    move v7, v6

    if-ne v0, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-int/lit8 v0, v0, -0x30

    const/4 v7, 0x1

    const/4 v6, 0x7

    mul-int/lit8 v0, v0, 0xa

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/lit8 p0, p0, -0x30

    const/4 v6, 0x7

    move v7, v6

    add-int/2addr v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 p0, 0x46

    const/4 v7, 0x7

    const/4 v6, 0x4

    if-lt v0, p0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    add-int/lit16 v0, v0, 0x76c

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    return v0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit16 v0, v0, 0x7d0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    return v0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v4, 0x3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ne v0, v4, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    add-int/lit8 v0, v0, -0x30

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    mul-int/lit8 v0, v0, 0x64

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-int/lit8 v1, v1, -0x30

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    mul-int/lit8 v1, v1, 0xa

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-int/2addr v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    add-int/lit8 p0, p0, -0x30

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-int/2addr v0, p0

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-int/lit16 v0, v0, 0x76c

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    return v0

    :cond_2
    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v5, 0x4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ne v0, v5, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v0, v0, -0x30

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    mul-int/lit16 v0, v0, 0x3e8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v1, v1, -0x30

    const/4 v6, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    mul-int/lit8 v1, v1, 0x64

    const/4 v6, 0x3

    or-int/2addr v7, v6

    add-int/2addr v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/lit8 v1, v1, -0x30

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    mul-int/lit8 v1, v1, 0xa

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/2addr v0, v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v7, 0x7

    const/4 v6, 0x3

    add-int/lit8 p0, p0, -0x30

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    add-int/2addr v0, p0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    return v0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/16 p0, 0x7b2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    return p0
.end method

.method private static e(Ljava/lang/String;)Lcom/alipay/android/phone/mrpc/core/k$a;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/lit8 v0, v0, -0x30

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/16 v3, 0x3a

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eq v2, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    mul-int/lit8 v0, v0, 0xa

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int/lit8 v2, v2, -0x30

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/2addr v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    add-int/2addr v2, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-int/lit8 v3, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    add-int/lit8 v2, v2, -0x30

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    mul-int/lit8 v2, v2, 0xa

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    add-int/lit8 v4, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/lit8 v3, v3, -0x30

    const/4 v6, 0x4

    add-int/2addr v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    add-int/2addr v4, v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/lit8 v1, v4, 0x1

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v3, v3, -0x30

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    mul-int/lit8 v3, v3, 0xa

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    add-int/lit8 p0, p0, -0x30

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    add-int/2addr v3, p0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance p0, Lcom/alipay/android/phone/mrpc/core/k$a;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0, v0, v2, v3}, Lcom/alipay/android/phone/mrpc/core/k$a;-><init>(III)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object p0
.end method
