.class public final Lcom/alipay/android/phone/mrpc/core/l;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/android/phone/mrpc/core/ab;


# static fields
.field private static b:Lcom/alipay/android/phone/mrpc/core/l;

.field private static final i:Ljava/util/concurrent/ThreadFactory;


# instance fields
.field a:Landroid/content/Context;

.field private c:Ljava/util/concurrent/ThreadPoolExecutor;

.field private d:Lcom/alipay/android/phone/mrpc/core/b;

.field private e:J

.field private f:J

.field private g:J

.field private h:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/n;

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/alipay/android/phone/mrpc/core/n;-><init>()V

    const/4 v2, 0x3

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/l;->i:Ljava/util/concurrent/ThreadFactory;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string/jumbo p1, "odsaids"

    const-string/jumbo p1, "nosddia"

    const/4 v10, 0x4

    const-string p1, "diomran"

    const-string p1, "android"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {p1}, Lcom/alipay/android/phone/mrpc/core/b;->a(Ljava/lang/String;)Lcom/alipay/android/phone/mrpc/core/b;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->d:Lcom/alipay/android/phone/mrpc/core/b;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance p1, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/16 v1, 0xa

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/16 v2, 0xb

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v10, 0x5

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    new-instance v6, Ljava/util/concurrent/ArrayBlockingQueue;

    const/16 v0, 0x14

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-direct {v6, v0}, Ljava/util/concurrent/ArrayBlockingQueue;-><init>(I)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    sget-object v7, Lcom/alipay/android/phone/mrpc/core/l;->i:Ljava/util/concurrent/ThreadFactory;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor$CallerRunsPolicy;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct {v8}, Ljava/util/concurrent/ThreadPoolExecutor$CallerRunsPolicy;-><init>()V

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct/range {v0 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x2

    const/4 v0, 0x3

    const/4 v10, 0x0

    const/4 v0, 0x1

    :try_start_0
    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p1}, Landroid/webkit/CookieSyncManager;->createInstance(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Landroid/webkit/CookieManager;->setAcceptCookie(Z)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-void
.end method

.method public static final a(Landroid/content/Context;)Lcom/alipay/android/phone/mrpc/core/l;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  i@o~d~@@@u @ftK ~@l4n~@@t @@Ml~ ~~~@o 1@ ~S  -o~/b~@@ b@o@ v~b~@~oiy~@.~ ~oo   @ i~~mf~~/a~@rs"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/alipay/android/phone/mrpc/core/l;->b:Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/alipay/android/phone/mrpc/core/l;->b(Landroid/content/Context;)Lcom/alipay/android/phone/mrpc/core/l;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method private static final declared-synchronized b(Landroid/content/Context;)Lcom/alipay/android/phone/mrpc/core/l;
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    const-class v0, Lcom/alipay/android/phone/mrpc/core/l;

    const-class v0, Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v3, 0x4

    const-class v0, Lcom/alipay/android/phone/mrpc/core/l;

    const-class v0, Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lcom/alipay/android/phone/mrpc/core/l;->b:Lcom/alipay/android/phone/mrpc/core/l;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v1

    :cond_0
    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/l;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/alipay/android/phone/mrpc/core/l;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    or-int/2addr v3, v2

    sput-object v1, Lcom/alipay/android/phone/mrpc/core/l;->b:Lcom/alipay/android/phone/mrpc/core/l;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw p0
.end method


# virtual methods
.method public final a()Lcom/alipay/android/phone/mrpc/core/b;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->d:Lcom/alipay/android/phone/mrpc/core/b;

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public final a(Lcom/alipay/android/phone/mrpc/core/t;)Ljava/util/concurrent/Future;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alipay/android/phone/mrpc/core/t;",
            ")",
            "Ljava/util/concurrent/Future<",
            "Lcom/alipay/android/phone/mrpc/core/u;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x4

    move v11, v10

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->a:Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v0}, Lcom/alipay/android/phone/mrpc/core/s;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-eqz v0, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string v1, "Hpntebatram"

    const-string/jumbo v1, "taamHMtpner"

    const/4 v11, 0x7

    const-string v1, "HttpManager"

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-string v1, "% %riduoB tatsez,usaeet %o,,Asil   dA =ee ev  =m=nA ed m deie=e    l  vTtT n,sele,imeesnl %t  mlsioecsdeigta le   ts,m  =C%AmATnln,sl=tm/cA= laqudbSakrd, el=lc:pAeqdcy s io akteskd %Tu o %C p  Cst mttd%kmt %aeK  dS="

    const-string v1, "%e=,o enr  ,%t  tTs  aso miul=t d eT ei  eCs qmil a  t  :  tB,AdgqsA m stl l kdptSs%=ee=n =Avmimt Aeln i aAice ,l lezelkne,mTd%pd%=d t=ab kls mmus= K o%oetete e,le aAcvrAo ,%d S=e/, et ecTan CdcsCmsddausti%de  ylk%s"

    const/4 v11, 0x1

    const-string/jumbo v1, "msce%a pna c eA ,%i l,  %eue,= mSelz,e i=s= lrlsolAv dp deTetnims  t k, temi tKTo%=deBn t%A:dAl k pi nv eds==  sT, eted l%lte kad= ayl gttssmm/tm ce r %= os  Caen,bA=ic%Aeale  dmAu si dl me S sdau d tT,%eCq tsodtekq"

    const-string v1, ": Active Task = %d, Completed Task = %d, All Task = %d,Avarage Speed = %d KB/S, Connetct Time = %d ms, All data size = %d bytes, All enqueueConnect time = %d ms, All socket time = %d ms, All request times = %d times"

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/16 v1, 0x9

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/util/concurrent/ThreadPoolExecutor;->getActiveCount()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v3, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    aput-object v2, v1, v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v2}, Ljava/util/concurrent/ThreadPoolExecutor;->getCompletedTaskCount()J

    move-result-wide v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v3, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    aput-object v2, v1, v3

    const/4 v10, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/ThreadPoolExecutor;->getTaskCount()J

    move-result-wide v2

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/4 v3, 0x2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    aput-object v2, v1, v3

    const/4 v10, 0x3

    xor-int/2addr v11, v10

    iget-wide v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->g:J

    const/4 v11, 0x5

    const/4 v10, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    cmp-long v6, v2, v4

    const/4 v11, 0x4

    const/4 v10, 0x4

    if-nez v6, :cond_0

    move-wide v2, v4

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_0

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x3

    iget-wide v6, p0, Lcom/alipay/android/phone/mrpc/core/l;->e:J

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-wide/16 v8, 0x3e8

    const-wide/16 v8, 0x3e8

    const/4 v11, 0x6

    const-wide/16 v8, 0x3e8

    const-wide/16 v8, 0x3e8

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    mul-long/2addr v6, v8

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    div-long/2addr v6, v2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/16 v2, 0xa

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    shr-long v2, v6, v2

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    const/4 v3, 0x3

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    aput-object v2, v1, v3

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->h:I

    const/4 v11, 0x3

    if-nez v2, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_1

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget-wide v3, p0, Lcom/alipay/android/phone/mrpc/core/l;->f:J

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    int-to-long v5, v2

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    div-long v4, v3, v5

    :goto_1
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/4 v3, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    aput-object v2, v1, v3

    const/4 v11, 0x2

    iget-wide v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->e:J

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/4 v3, 0x5

    const/4 v10, 0x4

    move v11, v10

    aput-object v2, v1, v3

    const/4 v10, 0x7

    shr-int/2addr v11, v10

    iget-wide v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->f:J

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v11, 0x6

    const/4 v10, 0x4

    aput-object v2, v1, v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    iget-wide v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->g:J

    const/4 v10, 0x4

    const/4 v10, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v11, 0x4

    aput-object v2, v1, v3

    const/4 v11, 0x1

    const/4 v10, 0x4

    iget v2, p0, Lcom/alipay/android/phone/mrpc/core/l;->h:I

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/16 v3, 0x8

    const/4 v10, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    aput-object v2, v1, v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    check-cast p1, Lcom/alipay/android/phone/mrpc/core/o;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v0, Lcom/alipay/android/phone/mrpc/core/q;

    const/4 v11, 0x6

    invoke-direct {v0, p0, p1}, Lcom/alipay/android/phone/mrpc/core/q;-><init>(Lcom/alipay/android/phone/mrpc/core/l;Lcom/alipay/android/phone/mrpc/core/o;)V

    const/4 v11, 0x4

    new-instance p1, Lcom/alipay/android/phone/mrpc/core/m;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {p1, p0, v0, v0}, Lcom/alipay/android/phone/mrpc/core/m;-><init>(Lcom/alipay/android/phone/mrpc/core/l;Ljava/util/concurrent/Callable;Lcom/alipay/android/phone/mrpc/core/q;)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    return-object p1
.end method

.method public final a(J)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->e:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-long/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->e:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public final b(J)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->f:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-long/2addr v0, p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->f:J

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->h:I

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput p1, p0, Lcom/alipay/android/phone/mrpc/core/l;->h:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public final c(J)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->g:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-long/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/alipay/android/phone/mrpc/core/l;->g:J

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method
