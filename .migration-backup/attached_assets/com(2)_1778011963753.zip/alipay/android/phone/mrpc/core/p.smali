.class public final Lcom/alipay/android/phone/mrpc/core/p;
.super Lcom/alipay/android/phone/mrpc/core/u;


# instance fields
.field private c:I

.field private d:Ljava/lang/String;

.field private e:J

.field private f:J

.field private g:Ljava/lang/String;

.field private h:Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;


# direct methods
.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;ILjava/lang/String;[B)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/alipay/android/phone/mrpc/core/u;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/p;->h:Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p2, p0, Lcom/alipay/android/phone/mrpc/core/p;->c:I

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/alipay/android/phone/mrpc/core/p;->d:Ljava/lang/String;

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/alipay/android/phone/mrpc/core/u;->a:[B

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~/b@~@oic~i~~~  @uom~ @sSr~  @ 4 @@  @1@~~~@~~o -y/~o @nvaoi~ft@tl~MKd.bo~ f @ @ @bl @@@~~@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alipay/android/phone/mrpc/core/p;->h:Lcom/alipay/android/phone/mrpc/core/HttpUrlHeader;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public final a(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/alipay/android/phone/mrpc/core/p;->e:J

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/p;->g:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public final b(J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/alipay/android/phone/mrpc/core/p;->f:J

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method
