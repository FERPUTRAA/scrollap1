.class public final Lcom/alipay/android/phone/mrpc/core/z;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field private c:B

.field private d:Ljava/util/concurrent/atomic/AtomicInteger;

.field private e:Lcom/alipay/android/phone/mrpc/core/x;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/z;->a:Ljava/lang/ThreadLocal;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Lcom/alipay/android/phone/mrpc/core/z;->b:Ljava/lang/ThreadLocal;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Lcom/alipay/android/phone/mrpc/core/x;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-byte v0, p0, Lcom/alipay/android/phone/mrpc/core/z;->c:B

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/z;->e:Lcom/alipay/android/phone/mrpc/core/x;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/z;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Method;",
            "[",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    const-string/jumbo v12, "v~so. b~@@i@~/Ki~f~n~ o~@1t~~l~/~um @sf~c @~tob4~Mr@@~ @~ @@@d~ ob@~ ~S@@ly@@@~ ~@-oa @~  i o   "

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v1, 0x1

    const/4 v12, 0x5

    const/4 v2, 0x0

    const/4 v12, 0x7

    if-eqz v0, :cond_0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v12, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    const/4 v12, 0x3

    if-ne v0, v3, :cond_0

    const/4 v12, 0x7

    move v0, v1

    move v0, v1

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v12, 0x7

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v12, 0x2

    if-nez v0, :cond_5

    const/4 v12, 0x3

    const-class v0, Lcom/alipay/mobile/framework/service/annotation/OperationType;

    const-class v0, Lcom/alipay/mobile/framework/service/annotation/OperationType;

    const-class v0, Lcom/alipay/mobile/framework/service/annotation/OperationType;

    const-class v0, Lcom/alipay/mobile/framework/service/annotation/OperationType;

    const/4 v12, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v0

    const/4 v12, 0x4

    check-cast v0, Lcom/alipay/mobile/framework/service/annotation/OperationType;

    const/4 v12, 0x1

    const-class v3, Lcom/alipay/mobile/framework/service/annotation/ResetCookie;

    const-class v3, Lcom/alipay/mobile/framework/service/annotation/ResetCookie;

    const-class v3, Lcom/alipay/mobile/framework/service/annotation/ResetCookie;

    const-class v3, Lcom/alipay/mobile/framework/service/annotation/ResetCookie;

    const/4 v12, 0x2

    invoke-virtual {p1, v3}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v3

    const/4 v12, 0x7

    if-eqz v3, :cond_1

    move v10, v1

    move v10, v1

    move v10, v1

    move v10, v1

    const/4 v12, 0x0

    goto :goto_1

    :cond_1
    move v10, v2

    move v10, v2

    move v10, v2

    move v10, v2

    :goto_1
    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/reflect/Method;->getGenericReturnType()Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/reflect/AccessibleObject;->getAnnotations()[Ljava/lang/annotation/Annotation;

    const/4 v12, 0x4

    sget-object v2, Lcom/alipay/android/phone/mrpc/core/z;->a:Ljava/lang/ThreadLocal;

    const/4 v3, 0x0

    move v12, v3

    move v12, v3

    invoke-virtual {v2, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v12, 0x0

    sget-object v11, Lcom/alipay/android/phone/mrpc/core/z;->b:Ljava/lang/ThreadLocal;

    const/4 v12, 0x3

    invoke-virtual {v11, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v12, 0x4

    if-eqz v0, :cond_4

    const/4 v12, 0x7

    invoke-interface {v0}, Lcom/alipay/mobile/framework/service/annotation/OperationType;->value()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x2

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/z;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v12, 0x5

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result v7

    :try_start_0
    const/4 v12, 0x0

    iget-byte v4, p0, Lcom/alipay/android/phone/mrpc/core/z;->c:B

    const/4 v12, 0x0

    if-nez v4, :cond_3

    const/4 v12, 0x5

    new-instance v4, Lcom/alipay/android/phone/mrpc/core/a/e;

    const/4 v12, 0x7

    invoke-direct {v4, v7, v0, p2}, Lcom/alipay/android/phone/mrpc/core/a/e;-><init>(ILjava/lang/String;Ljava/lang/Object;)V

    const/4 v12, 0x6

    invoke-virtual {v11}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v12, 0x7

    if-eqz p2, :cond_2

    const/4 v12, 0x5

    invoke-virtual {v11}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v12, 0x7

    invoke-interface {v4, p2}, Lcom/alipay/android/phone/mrpc/core/a/f;->a(Ljava/lang/Object;)V

    :cond_2
    const/4 v12, 0x0

    invoke-interface {v4}, Lcom/alipay/android/phone/mrpc/core/a/f;->a()[B

    move-result-object v9

    const/4 v12, 0x1

    new-instance p2, Lcom/alipay/android/phone/mrpc/core/j;

    const/4 v12, 0x2

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/z;->e:Lcom/alipay/android/phone/mrpc/core/x;

    const/4 v12, 0x7

    invoke-virtual {v4}, Lcom/alipay/android/phone/mrpc/core/x;->a()Lcom/alipay/android/phone/mrpc/core/g;

    move-result-object v5

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    const/4 v12, 0x3

    invoke-direct/range {v4 .. v10}, Lcom/alipay/android/phone/mrpc/core/j;-><init>(Lcom/alipay/android/phone/mrpc/core/g;Ljava/lang/reflect/Method;ILjava/lang/String;[BZ)V

    const/4 v12, 0x0

    invoke-interface {p2}, Lcom/alipay/android/phone/mrpc/core/v;->a()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x0

    check-cast p1, [B

    const/4 v12, 0x1

    invoke-virtual {v11, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v12, 0x5

    new-instance p2, Lcom/alipay/android/phone/mrpc/core/a/d;

    invoke-direct {p2, v1, p1}, Lcom/alipay/android/phone/mrpc/core/a/d;-><init>(Ljava/lang/reflect/Type;[B)V

    const/4 v12, 0x6

    invoke-interface {p2}, Lcom/alipay/android/phone/mrpc/core/a/c;->a()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x0

    sget-object p2, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    if-eq v1, p2, :cond_3

    const/4 v12, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V
    :try_end_0
    .catch Lcom/alipay/android/phone/mrpc/core/RpcException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    const/4 v12, 0x3

    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x3

    return-object p1

    :catch_0
    move-exception p1

    const/4 v12, 0x6

    invoke-virtual {p1, v0}, Lcom/alipay/android/phone/mrpc/core/RpcException;->setOperationType(Ljava/lang/String;)V

    const/4 v12, 0x3

    throw p1

    :cond_4
    const/4 v12, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x5

    const-string p2, "Toem.p e uia ttsbtsrespmny"

    const-string/jumbo p2, "t seeTt snbop.terya umpeis"

    const-string p2, "eouaoeysmOTtipste .e tbrn "

    const-string p2, "OperationType must be set."

    const/4 v12, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x3

    throw p1

    :cond_5
    const/4 v12, 0x0

    new-instance p1, Ljava/lang/IllegalThreadStateException;

    const/4 v12, 0x3

    const-string/jumbo p2, "rrcmic  hnl dte.mpn/ aclaanat/i "

    const-string p2, " /lrnbta rcnmnh . c c tlaapdai/i"

    const-string p2, "can\'t in main thread call rpc ."

    const/4 v12, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalThreadStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    throw p1
.end method
