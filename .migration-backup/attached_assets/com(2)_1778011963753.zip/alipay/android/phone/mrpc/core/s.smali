.class public final Lcom/alipay/android/phone/mrpc/core/s;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static final a(Landroid/content/Context;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ois @K~ l~@@-~@ o vi~i@~Mu/@@s~o~~ ~ /b@o oy ~@@lc  m~a@@ ~o @@1 @~tf~~4 n@d~bb@@~~@t@ f~S~r~~. "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lcom/alipay/android/phone/mrpc/core/s;->a:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    move v2, v0

    move v2, v0

    :try_start_0
    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1, p0, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    and-int/lit8 p0, p0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    move p0, v0

    move p0, v0

    const/4 v3, 0x0

    move p0, v0

    move p0, v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    sput-object p0, Lcom/alipay/android/phone/mrpc/core/s;->a:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p0

    :catch_0
    const/4 v3, 0x0

    return v0
.end method
