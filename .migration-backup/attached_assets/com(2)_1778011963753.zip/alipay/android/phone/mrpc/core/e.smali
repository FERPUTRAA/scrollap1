.class final Lcom/alipay/android/phone/mrpc/core/e;
.super Lorg/apache/http/impl/client/DefaultRedirectHandler;


# instance fields
.field a:I

.field final synthetic b:Lcom/alipay/android/phone/mrpc/core/d;


# direct methods
.method constructor <init>(Lcom/alipay/android/phone/mrpc/core/d;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/e;->b:Lcom/alipay/android/phone/mrpc/core/d;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lorg/apache/http/impl/client/DefaultRedirectHandler;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final isRedirectRequested(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~osf~  - mbl@M1 ~ ~@@@@@@ ~@~ ~/uv~@@o~s@i t o@ @y ~@o~t@lr~~o~i~@K~~ad@@b/@Sno .ci~4~~    b~f~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget v0, p0, Lcom/alipay/android/phone/mrpc/core/e;->a:I

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x5

    move v3, v1

    move v3, v1

    const/4 v4, 0x4

    add-int/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v0, p0, Lcom/alipay/android/phone/mrpc/core/e;->a:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-super {p0, p1, p2}, Lorg/apache/http/impl/client/DefaultRedirectHandler;->isRedirectRequested(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez p2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v0, p0, Lcom/alipay/android/phone/mrpc/core/e;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ge v0, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p1}, Lorg/apache/http/HttpResponse;->getStatusLine()Lorg/apache/http/StatusLine;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {p1}, Lorg/apache/http/StatusLine;->getStatusCode()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/16 v0, 0x12d

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p1, v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/16 v0, 0x12e

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p1, v0, :cond_1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return p2
.end method
