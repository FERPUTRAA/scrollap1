.class public final Lcom/alipay/android/phone/mrpc/core/a/e;
.super Lcom/alipay/android/phone/mrpc/core/a/b;


# instance fields
.field private c:I

.field private d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p2, p3}, Lcom/alipay/android/phone/mrpc/core/a/b;-><init>(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/alipay/android/phone/mrpc/core/a/e;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s~ @oblro y@a sdib  @~4~~ ~n@@@  c-@@@/~it K voM@  ~o~ mf/@@~~~@ ~@~u~1S~ @@.~b@ l~i@~t~f@@ ~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alipay/android/phone/mrpc/core/a/e;->d:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public final a()[B
    .locals 7

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/a/e;->d:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Lorg/apache/http/message/BasicNameValuePair;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v2, "rtamsPme"

    const-string/jumbo v2, "tasraePm"

    const/4 v6, 0x5

    const-string v2, "aParomxe"

    const-string v2, "extParam"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/alipay/android/phone/mrpc/core/a/e;->d:Ljava/lang/Object;

    const/4 v6, 0x1

    invoke-static {v3}, Lcom/alipay/a/a/f;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3}, Lorg/apache/http/message/BasicNameValuePair;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v1, Lorg/apache/http/message/BasicNameValuePair;

    const/4 v6, 0x3

    const-string/jumbo v2, "rantybopepmTi"

    const-string/jumbo v2, "pipmetoyTarno"

    const/4 v6, 0x2

    const-string/jumbo v2, "oonaepueritTp"

    const-string/jumbo v2, "operationType"

    iget-object v3, p0, Lcom/alipay/android/phone/mrpc/core/a/b;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v1, v2, v3}, Lorg/apache/http/message/BasicNameValuePair;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v1, Lorg/apache/http/message/BasicNameValuePair;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v2, "di"

    const-string/jumbo v2, "id"

    const/4 v6, 0x1

    const-string v2, "di"

    const-string/jumbo v2, "id"

    const/4 v6, 0x6

    const/4 v5, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    iget v4, p0, Lcom/alipay/android/phone/mrpc/core/a/e;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v1, v2, v3}, Lorg/apache/http/message/BasicNameValuePair;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/alipay/android/phone/mrpc/core/a/b;->b:Ljava/lang/Object;

    const/4 v6, 0x5

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    new-instance v1, Lorg/apache/http/message/BasicNameValuePair;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v2, "osrDaetptua"

    const-string v2, "eqstoDuarta"

    const/4 v6, 0x4

    const-string/jumbo v2, "requestData"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/alipay/android/phone/mrpc/core/a/b;->b:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v3, "[]"

    const-string v3, "[]"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-static {v3}, Lcom/alipay/a/a/f;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v1, v2, v3}, Lorg/apache/http/message/BasicNameValuePair;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v1, "-ftqu"

    const-string v1, "buf-t"

    const/4 v6, 0x7

    const-string v1, "-8suf"

    const-string/jumbo v1, "utf-8"

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lorg/apache/http/client/utils/URLEncodedUtils;->format(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v1, Lcom/alipay/android/phone/mrpc/core/RpcException;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 v2, 0x9

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string v4, "esrmt= u q"

    const-string/jumbo v4, "q  ersu=tu"

    const/4 v6, 0x6

    const-string v4, " reeost=u "

    const-string/jumbo v4, "request  ="

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    or-int/2addr v6, v5

    iget-object v4, p0, Lcom/alipay/android/phone/mrpc/core/a/b;->b:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v4, ":"

    const-string v4, ":"

    const-string v4, ":"

    const-string v4, ":"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x3

    const-string v3, ""

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v1, v2, v3, v0}, Lcom/alipay/android/phone/mrpc/core/RpcException;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    move v6, v5

    throw v1
.end method
