.class Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alipay/android/app/IRemoteServiceCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/android/app/IRemoteServiceCallback$Stub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b~s~uf@~~o~l~4 /.@~ @voi  ~~y~  r@@@@~b bs@~d K~@ ot @M~f@~ ~ o@@@ton@~o~ @i1@ / ~ ic@~Sa~- m~l@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "yRpmaCdmaS.t.lermlpi.ercbodIpiloaoaacie.anekc"

    const-string v0, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public getVersion()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v2, "ava.oasRlmbtyoclk.eccipIadiarordlpp.SmCei.ane"

    const-string v2, "caspenmoiarlypvi.olirktddSRbc..Imape.Caaecale"

    const-string v2, "cacaebdIrdRiealociprilSeakaaev.ot.bonC..plymp"

    const-string v2, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v3, 0x4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    return v2

    :catchall_0
    move-exception v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    throw v2
.end method

.method public isHideLoadingScreen()Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v2, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v3, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x2

    and-int/2addr v6, v5

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v4, 0x1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v4

    :catchall_0
    move-exception v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    throw v2
.end method

.method public payEnd(ZLjava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v2, "leoacau.dieaak.RltaCeIcoe..pyiopSvlidpmmcbnam"

    const-string/jumbo v2, "onmmdpt.a.IpabaoklaarciemiplviedSeye.caoRClc."

    const/4 v4, 0x1

    const-string/jumbo v2, "lIe.eacppblcvidmieaool.dcampinayRCkrepat.S.ar"

    const-string v2, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v2, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 p1, 0x1

    move v4, p1

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    move p1, v2

    move p1, v2

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1, p2, v0, v1, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    throw p1
.end method

.method public r03(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "ieoaoCobdSkicm.ellnp.pare.IevairadcptmcRa.loy"

    const/4 v3, 0x7

    const-string/jumbo v1, "rSdcRevpqkbect.allyao.ilindme.amrcICo.oiapaap"

    const-string v1, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p3}, Landroid/os/Parcel;->writeMap(Ljava/util/Map;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p2, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p3, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p1, v1, v0, p2, p3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw p1
.end method

.method public startActivity(Ljava/lang/String;Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "dnsvopbrdcc.ellepai.cI.apitimoakylRmaarC.Sboa"

    const-string v2, "e..IebdpclrciRlaaambiaamidC.o.pSerlootcvnkyap"

    const/4 v4, 0x6

    const-string/jumbo v2, "rkpma.lIiiiaord.acocndamytpevpe.lcSeeRoaba.Cl"

    const-string v2, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 p1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz p4, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p4, v0, p2}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p3, p0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;->a:Landroid/os/IBinder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {p3, p1, v0, v1, p2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw p1
.end method
