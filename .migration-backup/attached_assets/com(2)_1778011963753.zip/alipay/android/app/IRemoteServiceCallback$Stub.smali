.class public abstract Lcom/alipay/android/app/IRemoteServiceCallback$Stub;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/alipay/android/app/IRemoteServiceCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alipay/android/app/IRemoteServiceCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "com.alipay.android.app.IRemoteServiceCallback"

.field static final TRANSACTION_getVersion:I = 0x4

.field static final TRANSACTION_isHideLoadingScreen:I = 0x3

.field static final TRANSACTION_payEnd:I = 0x2

.field static final TRANSACTION_r03:I = 0x5

.field static final TRANSACTION_startActivity:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string v0, "elsacimkRarcylt..iipSanalrCbdpvpoe.eIod.cmsao"

    const-string v0, "eks.oadoI.rvl.eSoRpapnaecamre.ymacdcCiliiltpb"

    const/4 v2, 0x4

    const-string v0, ".aamComloIli.a.einlrSeimcRayodbd.vceakcrpeapt"

    const-string v0, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/alipay/android/app/IRemoteServiceCallback;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "ai @o  @~~~@@@o1@oouit y@~f~ob~~ ~/~~ M@~b ~i@ o  ~@c.m @ ~ ~~~~ @f @~sl@b-nvK@@ d~/~@S @or@lt@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x2

    move v3, v2

    const/4 p0, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "bc.opbleClr.indelIi.amaidaervtpcmaoRakeaSpco."

    const-string v0, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    instance-of v1, v0, Lcom/alipay/android/app/IRemoteServiceCallback;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Lcom/alipay/android/app/IRemoteServiceCallback;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Lcom/alipay/android/app/IRemoteServiceCallback$Stub$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v0, "meaatiuSerRIcbodadvplkl.C.rpeca.nmaociempl.oa"

    const-string v0, "IcomyrmelvpkceSanbm.dlo.erRtadcaiCialpa.ap.eo"

    const/4 v4, 0x6

    const-string v0, "ateaa.mprclaprecan.dlbake.poCimySeIRo.picilov"

    const-string v0, "com.alipay.android.app.IRemoteServiceCallback"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x1

    if-eq p1, v1, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eq p1, v2, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v4, 0x3

    if-eq p1, v2, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eq p1, v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eq p1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const v2, 0x5f4e5446

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eq p1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    return p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v1

    :cond_1
    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p4}, Landroid/os/Parcel;->readHashMap(Ljava/lang/ClassLoader;)Ljava/util/HashMap;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p0, p1, p3, p2}, Lcom/alipay/android/app/IRemoteServiceCallback;->r03(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v1

    :cond_2
    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p0}, Lcom/alipay/android/app/IRemoteServiceCallback;->getVersion()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {p0}, Lcom/alipay/android/app/IRemoteServiceCallback;->isHideLoadingScreen()Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p1, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    move p1, v1

    move p1, v1

    const/4 v4, 0x2

    move p1, v1

    move p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x3

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-interface {p0, p1, p2}, Lcom/alipay/android/app/IRemoteServiceCallback;->payEnd(ZLjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    return v1

    :cond_6
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v2, :cond_7

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object v2, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x5

    move v4, v3

    invoke-interface {v2, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    check-cast p2, Landroid/os/Bundle;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_1

    :cond_7
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 p2, 0x0

    :goto_1
    const/4 v3, 0x2

    move v4, v3

    invoke-interface {p0, p1, p4, v0, p2}, Lcom/alipay/android/app/IRemoteServiceCallback;->startActivity(Ljava/lang/String;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1
.end method
