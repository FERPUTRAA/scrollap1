.class public final Lcom/adjust/sdk/AdjustInstance$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/adjust/sdk/IRunActivityHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/AdjustInstance;->addSessionCallbackParameter(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/AdjustInstance$a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/adjust/sdk/AdjustInstance$a;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run(Lcom/adjust/sdk/ActivityHandler;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@imS@  @~//nbo ~ yf~o@i co~@~f@ ~@@@~l@  ov~~t-~a@ @   ~o@du~ r@~~~Mt4@ @b~~~~ ~@@s~K.bi1l@ o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/AdjustInstance$a;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/AdjustInstance$a;->b:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Lcom/adjust/sdk/ActivityHandler;->addSessionCallbackParameterI(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method
