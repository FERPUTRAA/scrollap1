.class public Lcom/adjust/sdk/PackageBuilder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/adjust/sdk/PackageBuilder$a;
    }
.end annotation


# static fields
.field private static logger:Lcom/adjust/sdk/ILogger;


# instance fields
.field private activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

.field private adjustConfig:Lcom/adjust/sdk/AdjustConfig;

.field public attribution:Lcom/adjust/sdk/AdjustAttribution;

.field public clickTimeInMilliseconds:J

.field public clickTimeInSeconds:J

.field public clickTimeServerInSeconds:J

.field private createdAt:J

.field public deeplink:Ljava/lang/String;

.field private deviceInfo:Lcom/adjust/sdk/a;

.field public extraParameters:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public googlePlayInstant:Ljava/lang/Boolean;

.field public installBeginTimeInSeconds:J

.field public installBeginTimeServerInSeconds:J

.field public installVersion:Ljava/lang/String;

.field public preinstallLocation:Ljava/lang/String;

.field public preinstallPayload:Ljava/lang/String;

.field public rawReferrer:Ljava/lang/String;

.field public referrer:Ljava/lang/String;

.field public referrerApi:Ljava/lang/String;

.field public reftag:Ljava/lang/String;

.field private sessionParameters:Lcom/adjust/sdk/SessionParameters;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object v0, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/a;Lcom/adjust/sdk/ActivityState;Lcom/adjust/sdk/SessionParameters;J)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInSeconds:J

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInMilliseconds:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeInSeconds:J

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeServerInSeconds:J

    const/4 v2, 0x0

    and-int/2addr v3, v2

    iput-wide v0, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeServerInSeconds:J

    const/4 v3, 0x1

    const/4 v2, 0x5

    iput-wide p5, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance p1, Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p1, p3}, Lcom/adjust/sdk/PackageBuilder$a;-><init>(Lcom/adjust/sdk/ActivityState;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p4, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public static addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ")V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o-s ~~ @~@f@ l@  st i~ @ ~ @@c~~v@~~@@ ~u br@i~lofi @4~@mS /o @aM~@~@K~/b~n@1t.@@  ~y@~d~bo~~o o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    int-to-long v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method private static addDate(Ljava/util/Map;Ljava/lang/String;Ljava/util/Date;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Date;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez p2, :cond_0

    const/4 v1, 0x0

    and-int/2addr v2, v1

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/adjust/sdk/Util;->dateFormatter:Ljava/text/SimpleDateFormat;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method private static addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    cmp-long v0, p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-gtz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, p2, p3}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p1, v0}, Lcom/adjust/sdk/PackageBuilder;->addDate(Ljava/util/Map;Ljava/lang/String;Ljava/util/Date;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private static addDateInSeconds(Ljava/util/Map;Ljava/lang/String;J)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    cmp-long v0, p2, v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-gtz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/util/Date;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v4, 0x5

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v4, 0x3

    mul-long/2addr p2, v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p2, p3}, Ljava/util/Date;-><init>(J)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-static {p0, p1, v0}, Lcom/adjust/sdk/PackageBuilder;->addDate(Ljava/util/Map;Ljava/lang/String;Ljava/util/Date;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method private static addDouble(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Double;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/Double;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x3

    if-nez p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p2, "5f%."

    const-string p2, "f%.5"

    const/4 v3, 0x0

    const-string p2, "%.f5"

    const-string p2, "%.5f"

    const/4 v2, 0x4

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private static addDoubleWithoutRounding(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Double;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/Double;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private static addDuration(Ljava/util/Map;Ljava/lang/String;J)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    cmp-long v0, p2, v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-gez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x6

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v3, 0x3

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    add-long/2addr p2, v0

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x1

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    div-long/2addr p2, v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0, p1, p2, p3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v3, 0x7

    return-void
.end method

.method private static addInteger(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Integer;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public static addJsonObject(Ljava/util/Map;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Lorg/json/JSONObject;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-nez p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static addLong(Ljava/util/Map;Ljava/lang/String;J)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    cmp-long v0, p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-gez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p2, p3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public static addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Map;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p2}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p2}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v1, 0x6

    move v2, v1

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private checkDeviceIds(Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "in_msaiord"

    const-string/jumbo v0, "ndsiai_ord"

    const/4 v3, 0x2

    const-string v0, "_iaoodnird"

    const-string v0, "android_id"

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "diamgsd_"

    const/4 v3, 0x2

    const-string/jumbo v0, "sdpdib_g"

    const-string v0, "gps_adid"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, "eirfidu_o"

    const-string/jumbo v0, "i_adorfei"

    const/4 v3, 0x0

    const-string v0, "d_rdfiapi"

    const-string v0, "fire_adid"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "oida"

    const-string/jumbo v0, "idao"

    const/4 v3, 0x7

    const-string v0, "adio"

    const-string/jumbo v0, "oaid"

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "iemi"

    const-string v0, "emii"

    const/4 v3, 0x3

    const-string/jumbo v0, "imei"

    const/4 v2, 0x5

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "dime"

    const-string v0, "diem"

    const-string/jumbo v0, "idem"

    const-string/jumbo v0, "meid"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const-string/jumbo v0, "iide_dveq"

    const-string v0, "edid_bevi"

    const/4 v3, 0x1

    const-string v0, "evseciddi"

    const-string v0, "device_id"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v0, "imemi"

    const-string/jumbo v0, "imeis"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "dmuio"

    const-string/jumbo v0, "iudem"

    const/4 v3, 0x7

    const-string v0, "bemdi"

    const-string/jumbo v0, "meids"

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v0, "sdeeivcpid"

    const/4 v3, 0x7

    const-string v0, "device_ids"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-boolean p1, p1, Lcom/adjust/sdk/AdjustConfig;->coppaCompliantEnabled:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    sget-object p1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v2, 0x5

    const-string/jumbo v1, "s.dgO ueqeeeACP  .sDciI snnlMvDaib"

    const-string/jumbo v1, "snd CDeIqee aDsi.bcOlg v.esPiMin A"

    const/4 v3, 0x4

    const-string v1, " sbgn..pe saAedPDlviDeOnPi CsIi ce"

    const-string v1, "Missing Device IDs. COPPA enabled."

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1, v1, v0}, Lcom/adjust/sdk/ILogger;->info(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object p1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "eioiKkIDq  etcr edywc ttssn.Desftl egc Pra  Me dAr sPricjaioshegvu iucsDlhS s"

    const-string v1, " csjtsAM gi tSoecrPelD eui sssrI.d ce wuc kKhif sdiyoes rvrncDaeDats l geiPht"

    const/4 v3, 0x0

    const-string/jumbo v1, "iPsIscr fgtPrhdviyjclcrcoSeigt sss.uh ietDeeKA ic s  DMe  i wreteka dssulna o"

    const-string v1, "Missing Device IDs. Please check if Proguard is correctly set with Adjust SDK"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p1, v1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private containsFireIds(Ljava/util/Map;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "mrfmie_dd"

    const-string/jumbo v0, "id_mderaf"

    const/4 v2, 0x2

    const-string v0, "driioa_ed"

    const-string v0, "fire_adid"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p1
.end method

.method private containsPlayIds(Ljava/util/Map;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return p1

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo v0, "oaddsbgp"

    const-string v0, "dsdpogai"

    const-string v0, "_igddsup"

    const-string v0, "gps_adid"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p1
.end method

.method private getAdRevenueParameters(Lcom/adjust/sdk/AdjustAdRevenue;Z)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/AdjustAdRevenue;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez p2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->callbackParameters:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p1, Lcom/adjust/sdk/AdjustAdRevenue;->callbackParameters:Ljava/util/Map;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, "bCkclalp"

    const-string/jumbo v2, "kaClbblc"

    const/4 v5, 0x6

    const-string/jumbo v2, "qklCbaac"

    const-string v2, "Callback"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v1, "c_salapmbckruaa"

    const-string v1, "brcl_aumalkpcaa"

    const/4 v5, 0x1

    const-string/jumbo v1, "lammpcacksra_lb"

    const-string v1, "callback_params"

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p1, Lcom/adjust/sdk/AdjustAdRevenue;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v2, "tnPrope"

    const-string/jumbo v2, "pnarePt"

    const/4 v5, 0x5

    const-string/jumbo v2, "tarnebr"

    const-string v2, "Partner"

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "_pasamurnparqe"

    const-string/jumbo v1, "rsaprna_qaerpm"

    const/4 v5, 0x1

    const-string v1, "aea_raspnrptrm"

    const-string/jumbo v1, "partner_params"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p2, v1}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "ddudroiuq_ai"

    const-string v1, "android_uuid"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v1, "_gsasdip"

    const-string v1, "d_sagips"

    const/4 v5, 0x5

    const-string v1, "gpim_sdd"

    const-string v1, "gps_adid"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget p2, p2, Lcom/adjust/sdk/a;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    int-to-long v1, p2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string p2, "emsdot_dapatgpti"

    const-string p2, "gps_adid_attempt"

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v1, "rsp_ib_sdgcm"

    const-string v1, "_rgmacpsd_si"

    const/4 v5, 0x1

    const-string v1, "gps_adid_src"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v1, "ab_irgudlnnkaeto"

    const-string v1, "ear_ockagtbndinl"

    const/4 v5, 0x5

    const-string/jumbo v1, "ncbnde_pkialreat"

    const-string/jumbo v1, "tracking_enabled"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p2}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "beddfir_q"

    const-string v1, "dr_idbief"

    const/4 v5, 0x2

    const-string v1, "adsire_df"

    const-string v1, "fire_adid"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p2}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "nefmrira_eiglbeutndc_"

    const-string v1, "__rgdfuinaearniceletb"

    const/4 v5, 0x2

    const-string v1, "dreronlatfea_ikiegnbc"

    const-string v1, "fire_tracking_enabled"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result p2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez p2, :cond_3

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez p2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object p2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v2, "pissDbe gb ldeeaeiltnoGfe ailatnla wnnirpv i  DeFGgt ceynro sngnrAItal  l odAetev,Pii tI k oito rrioelodeoictcafde reFg lk "

    const-string/jumbo v2, "ldyA Agpto ldefa nlDg  olnr s,eeiiadanelrstIe irc fi inat Gae eocecsni DFgPolrI kee etattior be t gi klvtGFnwi ilnodporodev"

    const/4 v5, 0x4

    const-string v2, "eosFituleG oden iyn aiIiGr astkodtpeec ocaegnPd,Denvieal  dtv rdgelw Iftl  t Ad   ooAlbnka iottsrreFianrigDlnei l  rcieolef"

    const-string v2, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v4, 0x0

    move v5, v4

    invoke-interface {p2, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, "_odidadprq"

    const-string v1, "_iddnodrqa"

    const/4 v5, 0x7

    const-string/jumbo v1, "ianddr_oqd"

    const-string v1, "android_id"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x2

    const/4 v4, 0x2

    iget-object p2, p2, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v4, 0x0

    move v5, v4

    const-string v1, "eispsela_"

    const-string v1, "aesielpl_"

    const/4 v5, 0x4

    const-string v1, "epamleil_"

    const-string v1, "api_level"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v1, "rsm_oeppea"

    const-string v1, "ea_mescrpp"

    const/4 v5, 0x6

    const-string/jumbo v1, "pacprbsete"

    const-string v1, "app_secret"

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "onepkouta"

    const-string/jumbo v1, "opt_oanke"

    const/4 v5, 0x6

    const-string/jumbo v1, "p_konappt"

    const-string v1, "app_token"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x4

    move v5, v4

    iget-object p2, p2, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v1, "vpp_arseqno"

    const-string v1, "app_version"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    const-string/jumbo v1, "tesuitl_bbkndropanit"

    const-string/jumbo v1, "n_eknbptdrlubeaoitti"

    const/4 v5, 0x3

    const-string/jumbo v1, "rt_miipbieunetkdtnlo"

    const-string v1, "attribution_deeplink"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    int-to-long v1, v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v3, "tcceitu_eiynnytpv"

    const/4 v5, 0x4

    const-string v3, "_cnyooiniytcevept"

    const-string v3, "connectivity_type"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "untpobr"

    const-string/jumbo v2, "pntuorc"

    const/4 v5, 0x3

    const-string/jumbo v2, "uyorctu"

    const-string v2, "country"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "_petpuqp"

    const-string/jumbo v2, "qcpput_e"

    const/4 v5, 0x0

    const-string/jumbo v2, "qpytcepu"

    const-string v2, "cpu_type"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v4, 0x0

    move v5, v4

    const-string v3, "crsateet_d"

    const-string v3, "created_at"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->defaultTracker:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v2, "elamerkradut_sf"

    const-string/jumbo v2, "ulsefrtedkcra_a"

    const/4 v5, 0x7

    const-string/jumbo v2, "ra_eokfralucttd"

    const-string v2, "default_tracker"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "neniebdmwck_"

    const-string v2, "dwimenkc_vne"

    const/4 v5, 0x7

    const-string/jumbo v2, "oeedcnuv_kwn"

    const-string v2, "device_known"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "esencotpso"

    const-string/jumbo v2, "ons_oescet"

    const/4 v5, 0x0

    const-string/jumbo v2, "ncesds_tqo"

    const-string/jumbo v2, "needs_cost"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "nvsamceeritr_bdcuef"

    const-string/jumbo v2, "veemrbunut_cardfeic"

    const-string v2, "cenmrurfcdveteiaam_"

    const-string v2, "device_manufacturer"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v2, "uadiome_eec"

    const-string v2, "dameieuc_ev"

    const/4 v5, 0x1

    const-string v2, "e_nmibvdcee"

    const-string v2, "device_name"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v2, "e_pyvdcptie"

    const/4 v5, 0x0

    const-string/jumbo v2, "pede_iutycv"

    const-string v2, "device_type"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    int-to-long v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v3, "p_qdoeu"

    const-string v3, "dq_ueom"

    const/4 v5, 0x5

    const-string v3, "_qiuomd"

    const-string/jumbo v3, "ui_mode"

    const/4 v4, 0x3

    move v5, v4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v2, "sisghy_ihlteas"

    const-string v2, "_gslthipyahise"

    const/4 v5, 0x4

    const-string v2, "dslmhtpiheag_i"

    const-string v2, "display_height"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v5, 0x1

    const-string v2, "awhio_mpldtsi"

    const-string/jumbo v2, "ilsmpy_waihdt"

    const/4 v5, 0x4

    const-string v2, "dwadibilpsthy"

    const-string v2, "display_width"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo v2, "meorneutivn"

    const-string v2, "environment"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, "banf__fpidngerebvuelene"

    const-string v2, "event_buffering_enabled"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v2, "_xdldtviqnao_eicer"

    const-string/jumbo v2, "vcltoddn_iaxe_reei"

    const/4 v5, 0x4

    const-string v2, "_dsviedtcriealxee_"

    const-string v2, "external_device_id"

    const/4 v4, 0x2

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v5, 0x0

    const-string v2, "_bfmd"

    const-string v2, "b_fbd"

    const/4 v5, 0x3

    const-string v2, "fdb_o"

    const-string v2, "fb_id"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v2, "a_rrmbehauewn"

    const-string/jumbo v2, "rranweum_hade"

    const-string/jumbo v2, "ndwa_hurmraee"

    const-string v2, "hardware_name"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v2, "ta_dilsptpnl"

    const-string/jumbo v2, "lnld_siptate"

    const-string v2, "_leiatsdqlta"

    const-string/jumbo v2, "installed_at"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "qaauleng"

    const-string/jumbo v2, "ueslagga"

    const-string/jumbo v2, "language"

    const/4 v4, 0x5

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-wide v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->e:J

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v3, "_namvtreilass"

    const-string/jumbo v3, "rlsalisanevt_"

    const/4 v5, 0x1

    const-string v3, "elv_osintlatr"

    const-string/jumbo v3, "last_interval"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, "cmc"

    const-string v2, "cmc"

    const/4 v5, 0x2

    const-string v2, "ccm"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "nmc"

    const-string v2, "cmn"

    const/4 v5, 0x5

    const-string/jumbo v2, "mcn"

    const-string/jumbo v2, "mnc"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "ptemibs_nedssoslena_re"

    const-string v1, "aenmesdl_oi_epnssedrst"

    const/4 v5, 0x0

    const-string v1, "_eseaeuesesnsdodtlnpri"

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "lboso_up"

    const-string/jumbo v1, "slo_ouib"

    const/4 v5, 0x6

    const-string/jumbo v1, "qlusd_oi"

    const-string/jumbo v1, "os_build"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v1, "amsneo_"

    const-string v1, "am_eobn"

    const/4 v5, 0x4

    const-string/jumbo v1, "maomes_"

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo v1, "sniesouo_v"

    const-string/jumbo v1, "sonvoorie_"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "mpancbge_apk"

    const-string/jumbo v1, "n_emacgppkaa"

    const/4 v5, 0x6

    const-string v1, "egnacpuaa_ke"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v1, "ko_etsuppn"

    const-string/jumbo v1, "push_token"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v5, 0x5

    const-string v1, "edsnreynq_esti"

    const-string/jumbo v1, "screen_density"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "r_sreqnecotfs"

    const-string/jumbo v1, "rmrnces_qtfeo"

    const/4 v5, 0x5

    const-string/jumbo v1, "rfommtser_eca"

    const-string/jumbo v1, "screen_format"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    move v5, v4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "szcnos_esre"

    const-string v1, "eesssi_rnzc"

    const/4 v5, 0x6

    const-string/jumbo v1, "iceenbezs_s"

    const-string/jumbo v1, "screen_size"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "mescidu_r"

    const-string/jumbo v1, "resmcde_i"

    const/4 v5, 0x7

    const-string/jumbo v1, "st_ceerpi"

    const-string/jumbo v1, "secret_id"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->source:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v1, "reqsco"

    const-string/jumbo v1, "orcsoe"

    const/4 v5, 0x3

    const-string v1, "essocu"

    const-string/jumbo v1, "source"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->revenue:Ljava/lang/Double;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "vbemeen"

    const-string v1, "eeunebv"

    const/4 v5, 0x1

    const-string v1, "eevnoue"

    const-string/jumbo v1, "revenue"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDoubleWithoutRounding(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Double;)V

    const/4 v5, 0x2

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->currency:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v1, "cuercbru"

    const-string v1, "cncreuur"

    const/4 v5, 0x3

    const-string/jumbo v1, "ynruceuc"

    const-string v1, "currency"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->adImpressionsCount:Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "mppses_po_isainouncd"

    const-string/jumbo v1, "o__smippouiaedncsnts"

    const/4 v5, 0x0

    const-string v1, "_pcmaudoqsitnsi_orne"

    const-string v1, "ad_impressions_count"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addInteger(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->adRevenueNetwork:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, "_uswavtreerdeenok_"

    const-string/jumbo v1, "keeroeevqunt_radw_"

    const/4 v5, 0x0

    const-string v1, "ad_revenue_network"

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->adRevenueUnit:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v1, "rvuma_tneus_ede"

    const-string/jumbo v1, "u_sdeaeru_entiv"

    const/4 v5, 0x0

    const-string v1, "euedonvutr__nei"

    const-string v1, "ad_revenue_unit"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustAdRevenue;->adRevenuePlacement:Ljava/lang/String;

    const/4 v5, 0x6

    const-string/jumbo p2, "vaemdbtupceee_enma_n"

    const-string/jumbo p2, "vtemcenue_npeeldma_a"

    const/4 v5, 0x7

    const-string p2, "ad_revenue_placement"

    const/4 v5, 0x3

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    int-to-long p1, p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "niutseu_socso"

    const-string/jumbo v1, "soieot_cunssn"

    const/4 v5, 0x5

    const-string v1, "essnitspnoco_"

    const-string/jumbo v1, "session_count"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v1, "enss_otnqlibgh"

    const-string/jumbo v1, "soilhbg_stenen"

    const/4 v5, 0x0

    const-string/jumbo v1, "lnsonhssgees_t"

    const-string/jumbo v1, "session_length"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    int-to-long p1, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v1, "siomsuosusceubtn"

    const-string/jumbo v1, "tbisonussouus_ec"

    const/4 v5, 0x4

    const-string v1, "cenuosssosi_tbuo"

    const-string/jumbo v1, "subsession_count"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v5, 0x6

    const-string/jumbo v1, "mt_pebtpin"

    const-string/jumbo v1, "t_mipetpen"

    const/4 v5, 0x1

    const-string v1, "_einptuets"

    const-string/jumbo v1, "time_spent"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string p2, "_tadputpea"

    const-string/jumbo p2, "ut_aetdaqp"

    const/4 v5, 0x2

    const-string/jumbo p2, "uaatt_deqd"

    const-string/jumbo p2, "updated_at"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v0
.end method

.method private getAdRevenueParameters(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x1

    move v6, v5

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v2, "drsddi_saoui"

    const-string v2, "a_sddiioudru"

    const/4 v6, 0x7

    const-string v2, "duom_udiniad"

    const-string v2, "android_uuid"

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "_pimogad"

    const-string/jumbo v2, "p_dmagis"

    const/4 v6, 0x2

    const-string v2, "dg_sdbip"

    const-string v2, "gps_adid"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    int-to-long v1, v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v3, "go_seduttdpa_tap"

    const-string v3, "de_dopaaptgtmt_s"

    const/4 v6, 0x1

    const-string/jumbo v3, "pitd_gppa_mastet"

    const-string v3, "gps_adid_attempt"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v2, "sgsdip__qrda"

    const-string v2, "gps_adid_src"

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    const-string v2, "casdranneibetlbk"

    const-string/jumbo v2, "kaildb_tenaebncr"

    const/4 v6, 0x7

    const-string/jumbo v2, "ktlmangairbdee_n"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v2, "fridoud_i"

    const-string/jumbo v2, "idafdiur_"

    const/4 v6, 0x6

    const-string v2, "fire_adid"

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v2, "aie_nbireergbnalfd_kp"

    const-string/jumbo v2, "in_gcaepaenkdfrlebri_"

    const/4 v6, 0x6

    const-string/jumbo v2, "refndturniglaac_ebeki"

    const-string v2, "fire_tracking_enabled"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v1, :cond_2

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-nez v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    const-string/jumbo v3, "islafeFp  oacend Dly neai  c lraGiGtireIikvnoscei teontg eeii, Ildlbr aPtidellgetgdowFernknet drDtolo oqgo fA Aet sian dr  "

    const-string/jumbo v3, "r yeaeGtqies dcI rdi ikg,voDpd atefno  enDfoi tec  Paid lrFtiswr go bee klr dnoi aaieoinFAenltotgiAtlennecIdlrta leslG go l"

    const/4 v6, 0x7

    const-string v3, "ey dotttq tDeAdc evrlDrnfode   n lopni aniee,rennl  Psg sAeliltid i  teork lfe aeo aIlgsbron dioetatwlGi IFckFaceigvdrGoiia"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v2, "risaidddo_"

    const-string v2, "android_id"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v2, "i_pmaseel"

    const-string v2, "_eslpaiel"

    const/4 v6, 0x0

    const-string/jumbo v2, "la_eovlep"

    const-string v2, "api_level"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v2, "app_secret"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v2, "tpmkab_no"

    const-string v2, "_onmaeptk"

    const/4 v6, 0x1

    const-string/jumbo v2, "p_epkauot"

    const-string v2, "app_token"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v2, "pp_raoopsin"

    const-string/jumbo v2, "rospova_inp"

    const-string/jumbo v2, "vpspe_riqan"

    const-string v2, "app_version"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v2, "eostdtbinea_iubltink"

    const-string/jumbo v2, "trai_bnbkeoinltuidte"

    const/4 v6, 0x1

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    int-to-long v2, v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v4, "uiemtteccnvnt_iyo"

    const-string v4, "eyitioun_ctvcntye"

    const/4 v6, 0x7

    const-string v4, "ettcoiopynect_niv"

    const-string v4, "connectivity_type"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v3, "tycpnbu"

    const-string/jumbo v3, "pynucot"

    const/4 v6, 0x3

    const-string v3, "ctruyou"

    const-string v3, "country"

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v3, "tyep_uqp"

    const-string/jumbo v3, "qpetyuc_"

    const/4 v6, 0x6

    const-string/jumbo v3, "qceyuptp"

    const-string v3, "cpu_type"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v4, "eastdcsera"

    const-string v4, "d_staereac"

    const/4 v6, 0x3

    const-string/jumbo v4, "rcamedetat"

    const-string v4, "created_at"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->defaultTracker:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "katrotcd_fermua"

    const-string/jumbo v3, "ucrmaaekrd_fett"

    const/4 v6, 0x7

    const-string/jumbo v3, "utarfbrldeaec_t"

    const-string v3, "default_tracker"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v3, "device_known"

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    move v6, v5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v3, "n_sdsoutco"

    const-string/jumbo v3, "o_ctoessnd"

    const/4 v6, 0x6

    const-string/jumbo v3, "nssec_tpod"

    const-string/jumbo v3, "needs_cost"

    const/4 v6, 0x6

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x0

    move v6, v5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "dbmernvuqa_uritcaec"

    const-string/jumbo v3, "itrr_bneamcucefvuda"

    const/4 v6, 0x1

    const-string v3, "device_manufacturer"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v6, 0x5

    const-string/jumbo v3, "uesvca_need"

    const-string v3, "e_eciduenav"

    const/4 v6, 0x5

    const-string/jumbo v3, "vi_mnemcede"

    const-string v3, "device_name"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v3, "pe_eodpcvyt"

    const-string v3, "e_eycpdptvi"

    const/4 v6, 0x1

    const-string/jumbo v3, "id_tcbeeyep"

    const-string v3, "device_type"

    const/4 v6, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v2, v2, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    int-to-long v2, v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v4, "doimuqu"

    const-string v4, "dq_uiom"

    const/4 v6, 0x0

    const-string/jumbo v4, "pdomeu_"

    const-string/jumbo v4, "ui_mode"

    const/4 v6, 0x4

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v3, "sgdateysqi_ilp"

    const-string/jumbo v3, "sesghldt_iyiap"

    const/4 v6, 0x2

    const-string v3, "hyshlspde_iitg"

    const-string v3, "display_height"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v3, "hp_myditlawmi"

    const-string v3, "halmdt_diyipw"

    const-string v3, "d_ldoithasipy"

    const-string v3, "display_width"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v3, "rinonbovetm"

    const-string/jumbo v3, "rmvnoeinnot"

    const/4 v6, 0x0

    const-string/jumbo v3, "nmoenvurnei"

    const-string v3, "environment"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v5, 0x5

    move v6, v5

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v3, "av_iee_pbnbnnefgbefrudt"

    const-string v3, "brne_btbfvaundeegei_fen"

    const/4 v6, 0x6

    const-string v3, "dtbrfiueqennlgae_efevbn"

    const-string v3, "event_buffering_enabled"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const-string/jumbo v3, "uesxcvaldterei_n_e"

    const-string v3, "ecnev_utx_dlreieda"

    const/4 v6, 0x2

    const-string v3, "external_device_id"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v2, v2, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string v3, "bidm_"

    const-string v3, "bdpi_"

    const/4 v6, 0x1

    const-string v3, "bf_io"

    const-string v3, "fb_id"

    const/4 v5, 0x5

    move v6, v5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v6, 0x6

    const-string v3, "_mwhnbaraaeqd"

    const-string v3, "aewhaa_dqrmne"

    const/4 v6, 0x1

    const-string v3, "ahareeunwa_mr"

    const-string v3, "hardware_name"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    const-string/jumbo v3, "sdllsanpati_"

    const-string v3, "aasdl_tsnlie"

    const/4 v6, 0x5

    const-string/jumbo v3, "lilsteatq_nd"

    const-string/jumbo v3, "installed_at"

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "agsemgln"

    const-string/jumbo v3, "nalmgeag"

    const/4 v6, 0x1

    const-string/jumbo v3, "lgameagn"

    const-string/jumbo v3, "language"

    const/4 v6, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-wide v2, v2, Lcom/adjust/sdk/PackageBuilder$a;->e:J

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v4, "staloenvtlr_o"

    const-string v4, "_ltlonasitrev"

    const/4 v6, 0x3

    const-string v4, "_iatebsvllntr"

    const-string/jumbo v4, "last_interval"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v3, "cmc"

    const-string v3, "cmc"

    const/4 v6, 0x6

    const-string/jumbo v3, "mcc"

    const-string/jumbo v3, "mcc"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v3, "mcn"

    const-string/jumbo v3, "mnc"

    const/4 v6, 0x3

    const-string/jumbo v3, "nmc"

    const-string/jumbo v3, "mnc"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v2, "spsonluiseens_ddr_ebte"

    const-string v2, "_seesbsnerdlt_psdnieoe"

    const/4 v6, 0x7

    const-string v2, "dn_pierpeeoe_sselssntd"

    const-string/jumbo v2, "needs_response_details"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "qlsob_ud"

    const-string/jumbo v2, "olubsdu_"

    const-string v2, "_lsiobds"

    const-string/jumbo v2, "os_build"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v2, "aemm_sn"

    const-string/jumbo v2, "os_name"

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, "_srooenosv"

    const-string/jumbo v2, "res_oonpsv"

    const/4 v6, 0x3

    const-string/jumbo v2, "oeoirb_sns"

    const-string/jumbo v2, "os_version"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v2, "panme_uecgaq"

    const-string/jumbo v2, "pana_cemqekg"

    const/4 v6, 0x7

    const-string v2, "gapkcaepnae_"

    const-string/jumbo v2, "package_name"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string v2, "_tsshkpnqe"

    const-string v2, "e_shpsntok"

    const/4 v6, 0x0

    const-string/jumbo v2, "push_token"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v2, "dtsnenms_sryec"

    const-string/jumbo v2, "sydmnsere_tcne"

    const-string v2, "eydmisc_tnener"

    const-string/jumbo v2, "screen_density"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const-string/jumbo v2, "oe_morntscfre"

    const/4 v6, 0x3

    const-string/jumbo v2, "oremosfarnect"

    const-string/jumbo v2, "screen_format"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string/jumbo v2, "seebzbesri_"

    const-string/jumbo v2, "risnsbeeze_"

    const/4 v6, 0x2

    const-string/jumbo v2, "z_isceuesne"

    const-string/jumbo v2, "screen_size"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v2, "_ucdeerpt"

    const-string v2, "d_ecreuit"

    const/4 v6, 0x7

    const-string v2, "edrise_cq"

    const-string/jumbo v2, "secret_id"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v1, "pesscu"

    const-string/jumbo v1, "upcsre"

    const/4 v6, 0x4

    const-string v1, "eocmru"

    const-string/jumbo v1, "source"

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string/jumbo p1, "lqapoyd"

    const-string/jumbo p1, "poyaoal"

    const-string/jumbo p1, "payload"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addJsonObject(Ljava/util/Map;Ljava/lang/String;Lorg/json/JSONObject;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    int-to-long p1, p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v1, "istesbnos_cun"

    const-string/jumbo v1, "tssoeo_nscnui"

    const/4 v6, 0x5

    const-string/jumbo v1, "outc_eusossnn"

    const-string/jumbo v1, "session_count"

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v1, "toegn_hpimslse"

    const-string v1, "ehimegst_lsnon"

    const/4 v6, 0x1

    const-string v1, "enis_nseqgtolh"

    const-string/jumbo v1, "session_length"

    const/4 v6, 0x6

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    int-to-long p1, p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v1, "nosntbs_ouscieus"

    const-string/jumbo v1, "tuuconsnsb_seoio"

    const/4 v6, 0x2

    const-string/jumbo v1, "subsession_count"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v1, "tinmmteeb_"

    const-string/jumbo v1, "npttibme_e"

    const/4 v6, 0x7

    const-string/jumbo v1, "nsetoetmi_"

    const-string/jumbo v1, "time_spent"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    move v6, v5

    iget-object p1, p1, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string p2, "dpaeubtdta"

    const-string/jumbo p2, "updated_at"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v6, 0x7

    return-object v0
.end method

.method private getAttributionParameters(Ljava/lang/String;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x6

    move v6, v5

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v2, "iiandduu_ruo"

    const/4 v6, 0x1

    const-string v2, "aird_uuduion"

    const-string v2, "android_uuid"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "ppasddip"

    const-string v2, "dgadsipp"

    const/4 v6, 0x4

    const-string/jumbo v2, "qga_dids"

    const-string v2, "gps_adid"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    int-to-long v1, v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v3, "dtsimdatatp_spe_"

    const-string v3, "adstmadpqit_te_p"

    const/4 v6, 0x2

    const-string v3, "gemmddppttt_asa_"

    const-string v3, "gps_adid_attempt"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "dpd_oisrsa_s"

    const-string/jumbo v2, "rssd_icps_da"

    const/4 v6, 0x0

    const-string v2, "dcas_bgdpisr"

    const-string v2, "gps_adid_src"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v2, "na_dgbuiatknrcle"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v2, "diadmefpr"

    const-string/jumbo v2, "ridme_dfa"

    const-string/jumbo v2, "ie_fdidaq"

    const-string v2, "fire_adid"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v2, "aeslfgnrdciak_ieenot_"

    const-string/jumbo v2, "re_noektf_lgiaianecbd"

    const-string v2, "fire_tracking_enabled"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v3, ",simIenknirf ytlifeilano osIrl vrbaedtagiGtdPwoiere e i   vnisblnpc e tlnkdogdFeaolltDdlaier inD FctAot geAodcr eG aeot e g"

    const-string v3, "aaatrbetgDiie FlsAid wookril  o,ti GeIlDeFonltdgiagntoeolsee prk tA  iciidtdf gvtPeGoeeedfennion  vnr rcc Ie sdal  b llaryn"

    const/4 v6, 0x2

    const-string v3, "ao noIbrgetPiA lttGtnovdiD lDdeesyelncal neapnaottdioAcoeo sevoe  IF igi lifsecdrtGgF ,ek er enilig wiflarid t k o n ae rrl"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v2, "i_inubdaod"

    const-string/jumbo v2, "rdia_ouind"

    const/4 v6, 0x1

    const-string v2, "android_id"

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v2, "apvpeiule"

    const-string/jumbo v2, "peaelvip_"

    const/4 v6, 0x5

    const-string v2, "ee_lvpipl"

    const-string v2, "api_level"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x1

    const-string/jumbo v2, "rpetac_qqe"

    const-string v2, "ercaep_sqt"

    const-string/jumbo v2, "rpsesep_ca"

    const-string v2, "app_secret"

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string v2, "_tpmoapke"

    const-string v2, "app_token"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v2, "eiapovsosp_"

    const-string/jumbo v2, "o_ssnpaeivp"

    const/4 v6, 0x0

    const-string v2, "enpsibvap_r"

    const-string v2, "app_version"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "rapmkuutii_nbtedolen"

    const-string v2, "dtpmuoanekeribili_tn"

    const/4 v6, 0x5

    const-string/jumbo v2, "kopaintpbdute_rlitne"

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x4

    const-string v4, "deartce_qo"

    const-string/jumbo v4, "rdaeo_ctte"

    const/4 v6, 0x5

    const-string v4, "created_at"

    const/4 v6, 0x6

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v3, "ows_veiecknd"

    const-string v3, "device_known"

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v3, "oedm_sntec"

    const-string/jumbo v3, "tnecobdes_"

    const/4 v6, 0x5

    const-string v3, "_senocsdot"

    const-string/jumbo v3, "needs_cost"

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v3, "_uviebeendm"

    const-string v3, "cmee_iundev"

    const/4 v6, 0x2

    const-string v3, "device_name"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v3, "dpyceeuet_p"

    const-string/jumbo v3, "pv_yetdpcee"

    const/4 v6, 0x6

    const-string/jumbo v3, "tyecievp_dp"

    const-string v3, "device_type"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v2, v2, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    int-to-long v2, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-string/jumbo v4, "oqdiemu"

    const/4 v6, 0x1

    const-string v4, "_qmoudi"

    const-string/jumbo v4, "ui_mode"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v3, "iestevnomsr"

    const-string/jumbo v3, "misrovneent"

    const/4 v6, 0x7

    const-string/jumbo v3, "mtemrnnoenv"

    const-string v3, "environment"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v3, "gileodnnree_fuebamvetfb"

    const-string v3, "geamenl_uvbi_rfteefnedb"

    const/4 v6, 0x5

    const-string/jumbo v3, "vugltbfbdeenn_e_baenrfi"

    const-string v3, "event_buffering_enabled"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v3, "evitolcr_d_xedneea"

    const/4 v6, 0x0

    const-string/jumbo v3, "nreediue__dtviecxa"

    const-string v3, "external_device_id"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v2, "tbbdtnipaii_"

    const-string v2, "diet_bnbiiat"

    const-string v2, "btity_edqain"

    const-string/jumbo v2, "initiated_by"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0, v2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string p1, "_esensnlrdeeasedspto_s"

    const-string/jumbo p1, "needs_response_details"

    const/4 v6, 0x3

    invoke-static {v0, p1, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v1, "_usmmno"

    const-string v1, "an_osmu"

    const/4 v6, 0x4

    const-string v1, "aosno_e"

    const-string/jumbo v1, "os_name"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v1, "vsspnberoo"

    const-string/jumbo v1, "vrosenspoi"

    const/4 v6, 0x2

    const-string/jumbo v1, "oonsveur_s"

    const-string/jumbo v1, "os_version"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    const-string v1, "apqmgcepa_ak"

    const-string/jumbo v1, "macna_gkqpae"

    const/4 v6, 0x0

    const-string/jumbo v1, "nemaacg_qaep"

    const-string/jumbo v1, "package_name"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v6, 0x0

    const-string/jumbo v1, "khs_sesnop"

    const-string/jumbo v1, "nosseh_kpt"

    const/4 v6, 0x2

    const-string/jumbo v1, "pehmntsok_"

    const-string/jumbo v1, "push_token"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "setro_cem"

    const-string/jumbo v1, "secmi_rte"

    const/4 v6, 0x1

    const-string v1, "_seeibdrc"

    const-string/jumbo v1, "secret_id"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object v0
.end method

.method private getClickParameters(Ljava/lang/String;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    or-int/2addr v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const-string v2, "dnr_iiuoodau"

    const-string/jumbo v2, "rnudouiia_od"

    const/4 v6, 0x6

    const-string/jumbo v2, "uradnddpiuio"

    const-string v2, "android_uuid"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v2, "gps_adid"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    int-to-long v1, v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v3, "tiatpsptqg_ma_de"

    const-string v3, "agd_mbit_pseptat"

    const/4 v6, 0x5

    const-string v3, "_dst_patptamgdse"

    const-string v3, "gps_adid_attempt"

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v2, "ddsmi__parcg"

    const-string v2, "cdrapiud_sg_"

    const/4 v6, 0x5

    const-string v2, "dradocpsis__"

    const-string v2, "gps_adid_src"

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "r_adpbkaineelbng"

    const-string/jumbo v2, "krigalnpbe_cneda"

    const/4 v6, 0x5

    const-string v2, "eiacdrunealk_tbn"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const-string v2, "_frdqiapd"

    const-string v2, "dferi_daq"

    const/4 v6, 0x1

    const-string v2, "fdired_aq"

    const-string v2, "fire_adid"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "resrlfnabkiece_ngat_i"

    const-string v2, "ats_eifbneialrg_cenkr"

    const/4 v6, 0x5

    const-string v2, "fire_tracking_enabled"

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-nez v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v3, "Iagmiotar eer i  o i aDadtltt notevDfrebawef Ireket gn yAlollitdlidgdc nnP etec l keeinnA sgoGrcdpis, ne oFrioFmisio elv lG"

    const-string/jumbo v3, "prrmliGig   y rFildDtelgoitA fda agioPeGto  atAiIgl dIernir tcatoecve Dsb edeno cstl efldiani wdioeso o ,veklnnn tle neFekr"

    const-string v3, "Ft sotd nytbe fa iifinota agrAldew ikg,a dgcretgnvGAen d litl ocansoGedlre led veo nolaipnk r tDFieoeree PI Iotii eolisDl c"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x4

    const-string v2, "android_id"

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->attribution:Lcom/adjust/sdk/AdjustAttribution;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "tracker"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->attribution:Lcom/adjust/sdk/AdjustAttribution;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "aoapmbic"

    const-string/jumbo v2, "imcpogaa"

    const/4 v6, 0x7

    const-string v2, "amgnacui"

    const-string v2, "campaign"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->attribution:Lcom/adjust/sdk/AdjustAttribution;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "paugrpo"

    const-string v2, "aogurbp"

    const/4 v6, 0x7

    const-string/jumbo v2, "rqopadg"

    const-string v2, "adgroup"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->attribution:Lcom/adjust/sdk/AdjustAttribution;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "creative"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v2, "_vsallipu"

    const-string/jumbo v2, "l_vleiupa"

    const/4 v6, 0x0

    const-string/jumbo v2, "lpemi_eal"

    const-string v2, "api_level"

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v2, "_sepoprcta"

    const-string v2, "_sppreapct"

    const/4 v6, 0x2

    const-string v2, "epepsb_cra"

    const-string v2, "app_secret"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v5, 0x4

    const-string/jumbo v2, "kn_tapuep"

    const-string v2, "app_token"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v2, "paivpsnprqo"

    const-string/jumbo v2, "sivprnapqeo"

    const-string v2, "anep_vrpqso"

    const-string v2, "app_version"

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v2, "r_siaoltnneptteuiidk"

    const-string v2, "aosnkpe_littiirntedu"

    const-string/jumbo v2, "tilmpnr_aktoebitduie"

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/adjust/sdk/SessionParameters;->callbackParameters:Ljava/util/Map;

    const/4 v6, 0x4

    const-string/jumbo v3, "skabocalmclamrp"

    const-string/jumbo v3, "slamarbaapckmlc"

    const/4 v6, 0x7

    const-string v3, "b_paabslcamrklc"

    const-string v3, "callback_params"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInMilliseconds:J

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v4, "kictoec_ml"

    const/4 v6, 0x5

    const-string v4, "cmcktiue_i"

    const-string v4, "click_time"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInSeconds:J

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInSeconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeServerInSeconds:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const-string/jumbo v4, "rsbm_ecpicktr_eei"

    const-string v4, "ees_tbicv_rcerikm"

    const/4 v6, 0x3

    const-string/jumbo v4, "tseiemv_qrricelkc"

    const-string v4, "click_time_server"

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInSeconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    int-to-long v2, v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v4, "tys_etuocnpeicitn"

    const-string/jumbo v4, "ivccniutoteepytn_"

    const/4 v6, 0x4

    const-string/jumbo v4, "pycmvtneitto_eicy"

    const-string v4, "connectivity_type"

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v5, 0x5

    move v6, v5

    const-string/jumbo v3, "rpctoyo"

    const-string/jumbo v3, "porycut"

    const/4 v6, 0x5

    const-string/jumbo v3, "nrtucbo"

    const-string v3, "country"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v2, v2, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v6, 0x5

    const-string/jumbo v3, "petuqcup"

    const-string/jumbo v3, "qpcypuet"

    const/4 v6, 0x5

    const-string/jumbo v3, "ycptu_ep"

    const-string v3, "cpu_type"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v4, "eettcrsaq_"

    const-string v4, "eastce_trd"

    const/4 v6, 0x7

    const-string/jumbo v4, "tasredc_ea"

    const-string v4, "created_at"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deeplink:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v3, "lenmpdkm"

    const-string/jumbo v3, "lpemdnke"

    const/4 v6, 0x5

    const-string/jumbo v3, "lekiopdn"

    const-string v3, "deeplink"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const-string v3, "eonvwbkdocn_"

    const-string v3, "_dnoovcekniw"

    const/4 v6, 0x2

    const-string/jumbo v3, "kvd_niueonew"

    const-string v3, "device_known"

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v3, "ssbecoepdn"

    const-string/jumbo v3, "snde_boesc"

    const-string/jumbo v3, "t_sscoedqe"

    const-string/jumbo v3, "needs_cost"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v3, "vesaeer_utucunfmicd"

    const-string v3, "amcefdur_riunteecuv"

    const/4 v6, 0x2

    const-string v3, "_mnmeeraitcrudcufav"

    const-string v3, "device_manufacturer"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v3, "_edvoeamnpc"

    const-string v3, "_amnvecpeid"

    const/4 v6, 0x7

    const-string v3, "enmcdbiae_e"

    const-string v3, "device_name"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string v3, "cpvdeyueiqt"

    const-string/jumbo v3, "ytvciedeqpe"

    const/4 v6, 0x5

    const-string v3, "cyite_epedv"

    const-string v3, "device_type"

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v2, v2, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    int-to-long v2, v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const-string v4, "dqueims"

    const-string/jumbo v4, "musideo"

    const/4 v6, 0x0

    const-string v4, "_esmudi"

    const-string/jumbo v4, "ui_mode"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, v2, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v3, "hpamiiem_ytldh"

    const-string v3, "_himhaitplysed"

    const-string v3, "gyphot_isalhdi"

    const-string v3, "display_height"

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v6, 0x5

    const-string/jumbo v3, "ldyitbhi_sdwp"

    const-string/jumbo v3, "shipowddylit_"

    const/4 v6, 0x6

    const-string/jumbo v3, "l_yhpsuiwddia"

    const-string v3, "display_width"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v3, "nmoeivnpren"

    const-string v3, "enovmbinner"

    const/4 v6, 0x3

    const-string/jumbo v3, "motevnenqni"

    const-string v3, "environment"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v3, "edsebn_rbae_vtfieunulfn"

    const-string v3, "e_dievunb_rueanfenlbfet"

    const/4 v6, 0x4

    const-string v3, "bb_m_narvteelgfnefnediu"

    const-string v3, "event_buffering_enabled"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v3, "xae_oreidtvedli_nc"

    const-string v3, "external_device_id"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v3, "bpbif"

    const-string/jumbo v3, "ibpf_"

    const/4 v6, 0x1

    const-string v3, "fuid_"

    const-string v3, "fb_id"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v3, "lstnqtopgg_epo_yinl"

    const-string v3, "_ln_ptayqooegsntlgi"

    const/4 v6, 0x5

    const-string/jumbo v3, "ptylg_otqaosn_ealig"

    const-string v3, "google_play_instant"

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const-string v3, "das_nmeersraa"

    const-string/jumbo v3, "rasa_dnwmreea"

    const/4 v6, 0x7

    const-string/jumbo v3, "ranmwaeherm_d"

    const-string v3, "hardware_name"

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeInSeconds:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v4, "gtl_o_bsiitmnieame"

    const-string/jumbo v4, "istmmelgae_i_nlibt"

    const/4 v6, 0x3

    const-string/jumbo v4, "itlnabetilg__nesbi"

    const-string/jumbo v4, "install_begin_time"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInSeconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeServerInSeconds:J

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v4, "erne__uliobeatstgveini_rl"

    const-string/jumbo v4, "tn__obiev_lslgiemerteanir"

    const/4 v6, 0x4

    const-string/jumbo v4, "install_begin_time_server"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInSeconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->installVersion:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v3, "itensaipbrvll_o"

    const-string/jumbo v3, "neisnbollvi_art"

    const/4 v6, 0x3

    const-string v3, "_linlsotqesairv"

    const-string/jumbo v3, "install_version"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v2, v2, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v3, "assit_ldnuet"

    const-string v3, "_atlsluietdn"

    const/4 v6, 0x7

    const-string/jumbo v3, "ieam_ltdltan"

    const-string/jumbo v3, "installed_at"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v3, "agupogne"

    const-string v3, "agagenup"

    const/4 v6, 0x1

    const-string/jumbo v3, "nlguebag"

    const-string/jumbo v3, "language"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-wide v2, v2, Lcom/adjust/sdk/PackageBuilder$a;->e:J

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v4, "elanituvrqtsa"

    const-string/jumbo v4, "veatalnlqsrti"

    const/4 v6, 0x5

    const-string/jumbo v4, "rttlse_painla"

    const-string/jumbo v4, "last_interval"

    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v3, "ccm"

    const-string/jumbo v3, "mcc"

    const-string v3, "cmc"

    const-string/jumbo v3, "mcc"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v3, "ncm"

    const-string v3, "cmn"

    const/4 v6, 0x2

    const-string/jumbo v3, "mnc"

    const-string/jumbo v3, "mnc"

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    const-string/jumbo v2, "pensresaq_iese_sslednd"

    const-string v2, "_ssdesoerap_eenelndsis"

    const/4 v6, 0x2

    const-string v2, "_ssepese_snsradldietne"

    const-string/jumbo v2, "needs_response_details"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v2, "sbumdiol"

    const-string/jumbo v2, "oubmdils"

    const-string/jumbo v2, "liboosd_"

    const-string/jumbo v2, "os_build"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v2, "_onsome"

    const-string/jumbo v2, "nmoaeb_"

    const-string/jumbo v2, "os_name"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v2, "rievosunbo"

    const-string/jumbo v2, "srveibsnoo"

    const/4 v6, 0x0

    const-string/jumbo v2, "oove_rspin"

    const-string/jumbo v2, "os_version"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v2, "nce_pamgqkaa"

    const-string/jumbo v2, "package_name"

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->extraParameters:Ljava/util/Map;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const-string/jumbo v2, "susmra"

    const-string/jumbo v2, "usramp"

    const/4 v6, 0x6

    const-string/jumbo v2, "sramam"

    const-string/jumbo v2, "params"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x6

    and-int/2addr v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/SessionParameters;->partnerParameters:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v2, "_mteoarrpsanap"

    const-string/jumbo v2, "manrr_apprtsea"

    const/4 v6, 0x6

    const-string/jumbo v2, "rprtnbparams_e"

    const-string/jumbo v2, "partner_params"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string/jumbo v2, "unkthsueoq"

    const-string/jumbo v2, "spuenohtqk"

    const/4 v6, 0x3

    const-string v2, "_tuhenopks"

    const-string/jumbo v2, "push_token"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->rawReferrer:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v2, "rfrrrw_eqees"

    const-string/jumbo v2, "wrsr_rrfeeer"

    const/4 v6, 0x3

    const-string/jumbo v2, "resrefr_arre"

    const-string/jumbo v2, "raw_referrer"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->referrer:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v2, "rermeefr"

    const-string/jumbo v2, "rermeref"

    const/4 v6, 0x3

    const-string v2, "erefoerr"

    const-string/jumbo v2, "referrer"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->referrerApi:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v2, "rrre_brfpiao"

    const-string/jumbo v2, "peraof_rrier"

    const/4 v6, 0x3

    const-string v2, "efrrieur_aep"

    const-string/jumbo v2, "referrer_api"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->reftag:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "gpafbr"

    const-string v2, "fargtb"

    const/4 v6, 0x0

    const-string v2, "frqgea"

    const-string/jumbo v2, "reftag"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v2, "eisrnedtucs_ne"

    const-string v2, "csteneuid_nesr"

    const/4 v6, 0x6

    const-string/jumbo v2, "tenmercdesnsy_"

    const-string/jumbo v2, "screen_density"

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v2, "ftcropseeoamr"

    const-string v2, "ao_efrrptmsce"

    const/4 v6, 0x2

    const-string/jumbo v2, "screen_format"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    const-string/jumbo v2, "ierczbesenq"

    const-string/jumbo v2, "serzenesqci"

    const/4 v6, 0x2

    const-string/jumbo v2, "zcreinuse_s"

    const-string/jumbo v2, "screen_size"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v2, "rceidt_ps"

    const-string/jumbo v2, "siscrdet_"

    const/4 v6, 0x5

    const-string v2, "es_dteicq"

    const-string/jumbo v2, "secret_id"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v6, 0x0

    int-to-long v1, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const-string/jumbo v3, "tmso_nonssuce"

    const-string/jumbo v3, "ioomssunecn_t"

    const/4 v6, 0x2

    const-string/jumbo v3, "nosmoeucsnts_"

    const-string/jumbo v3, "session_count"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x7

    move v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-wide v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const/4 v6, 0x3

    const-string v3, "esilo_eonnhssg"

    const-string/jumbo v3, "tghso_nseleisn"

    const/4 v6, 0x3

    const-string/jumbo v3, "nstesb_hgsineo"

    const-string/jumbo v3, "session_length"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v1, "uesrub"

    const-string/jumbo v1, "sueorb"

    const/4 v6, 0x1

    const-string/jumbo v1, "opsceu"

    const-string/jumbo v1, "source"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    int-to-long v1, p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string p1, "cobtuesoqnssinsu"

    const-string/jumbo p1, "subsession_count"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-wide v1, p1, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo p1, "mpsti_tnes"

    const-string/jumbo p1, "snimttuep_"

    const/4 v6, 0x3

    const-string/jumbo p1, "mi_menspet"

    const-string/jumbo p1, "time_spent"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v1, "deadotaup_"

    const-string v1, "_atedtupad"

    const/4 v6, 0x7

    const-string v1, "a_tdabptue"

    const-string/jumbo v1, "updated_at"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->preinstallPayload:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v1, "yqodalu"

    const-string/jumbo v1, "lqpydao"

    const/4 v6, 0x3

    const-string/jumbo v1, "paolday"

    const-string/jumbo v1, "payload"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->preinstallLocation:Ljava/lang/String;

    const/4 v6, 0x5

    const-string v1, "ds_oitanqnoclf"

    const-string/jumbo v1, "nnsltoudfc_aoi"

    const/4 v6, 0x0

    const-string/jumbo v1, "ods_oaoilucntn"

    const-string v1, "found_location"

    const/4 v6, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object v0
.end method

.method private getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/adjust/sdk/ActivityPackage;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lcom/adjust/sdk/ActivityPackage;-><init>(Lcom/adjust/sdk/ActivityKind;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->h:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/ActivityPackage;->setClientSdk(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method private getDisableThirdPartySharingParameters()Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v5, 0x2

    and-int/2addr v6, v5

    const-string/jumbo v2, "mdumunad_ior"

    const-string v2, "ddrmaunu_ido"

    const/4 v6, 0x4

    const-string/jumbo v2, "uiuooidrna_d"

    const-string v2, "android_uuid"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v2, "goip_bds"

    const-string/jumbo v2, "spg_oaid"

    const-string v2, "_gspdaui"

    const-string v2, "gps_adid"

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    int-to-long v1, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v3, "tepgbdppdt_smat_"

    const-string/jumbo v3, "tt_tabaepsg_pdmd"

    const/4 v6, 0x0

    const-string v3, "gps_adid_attempt"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const-string/jumbo v2, "scdaiugrqs_p"

    const-string/jumbo v2, "igrsspu_ddac"

    const/4 v6, 0x4

    const-string/jumbo v2, "i_sagscrdsp_"

    const-string v2, "gps_adid_src"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v2, "rinec_bpeaatdgln"

    const/4 v6, 0x7

    const-string/jumbo v2, "takmnebrgc_ieald"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "iierofddq"

    const-string v2, "deiidfraq"

    const/4 v6, 0x3

    const-string v2, "eriidbfd_"

    const-string v2, "fire_adid"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string/jumbo v2, "rnrklaui_bin_adfegtec"

    const-string v2, "fire_tracking_enabled"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-nez v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-nez v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x6

    or-int/2addr v6, v5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v3, "ddleDttpFftoi wDnneaA ireresereet,pcygoI niocllvs eat  lAF d l gsiGobg Pee ifekIo de r oac diasl ag iioonritv atirn nkdGetl"

    const-string/jumbo v3, "rbsntdocDkInvi eroypore varets einlt naf  ifs deP tdsalrlet ice dk ti w,idli G tae lIeA l FcogoeiiGiFgoAo eaodeelDtagn nlrg"

    const/4 v6, 0x1

    const-string v3, "GItytgddqlt ree PriA ovbwADoi ecangfeeinikolniFepGagrdotdtdoe r a,elsFi anntl eseiega icoo  v csn itnrdDI l  felilola  ekt "

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v2, "_dsriadomd"

    const-string/jumbo v2, "odim_dradn"

    const/4 v6, 0x7

    const-string v2, "diamrnd_di"

    const-string v2, "android_id"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x1

    move v6, v5

    const-string v2, "_lveoleoa"

    const-string v2, "al_volepe"

    const/4 v6, 0x3

    const-string v2, "e_elabvpi"

    const-string v2, "api_level"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "_ecpabretp"

    const/4 v6, 0x7

    const-string/jumbo v2, "rcpea_upts"

    const-string v2, "app_secret"

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v2, "pknptuepa"

    const-string/jumbo v2, "p_pnteuka"

    const/4 v6, 0x6

    const-string/jumbo v2, "neotppakq"

    const-string v2, "app_token"

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    move v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v5, 0x1

    const-string v2, "eos_nvpripa"

    const-string v2, "ervsaonpp_i"

    const/4 v6, 0x3

    const-string/jumbo v2, "s_nmarpviop"

    const-string v2, "app_version"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v2, "kipaoiul_tetbtqondir"

    const-string/jumbo v2, "luikr_adqotbteeiitnp"

    const/4 v6, 0x5

    const-string/jumbo v2, "rbleabindtpn_uoiietk"

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v4, "_secdaurtt"

    const-string/jumbo v4, "trst_aceda"

    const/4 v6, 0x3

    const-string/jumbo v4, "radeettp_c"

    const-string v4, "created_at"

    const/4 v6, 0x6

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v3, "eowidvenqknm"

    const-string/jumbo v3, "kwdmeeivonnc"

    const/4 v6, 0x7

    const-string/jumbo v3, "icsdvnnkew_o"

    const-string v3, "device_known"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v3, "etdmsoc_en"

    const-string/jumbo v3, "needs_cost"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    move v6, v5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v3, "dineomvce_e"

    const-string v3, "e_ceoeinvmd"

    const/4 v6, 0x5

    const-string v3, "_deenbemivc"

    const-string v3, "device_name"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v3, "_ycveiuetdb"

    const-string v3, "e_ycdbtveip"

    const/4 v6, 0x1

    const-string v3, "cype_ivpete"

    const-string v3, "device_type"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v2, v2, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    int-to-long v2, v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v4, "uq_ioum"

    const-string/jumbo v4, "uom_eiu"

    const/4 v6, 0x7

    const-string/jumbo v4, "o_seidm"

    const-string/jumbo v4, "ui_mode"

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v3, "envmnnroptm"

    const-string/jumbo v3, "nmvetoepnnr"

    const/4 v6, 0x5

    const-string/jumbo v3, "retnoieonvm"

    const-string v3, "environment"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v3, "ubaegb__enqireenefvtdlf"

    const-string v3, "fgbinnteqnev_ua_lerfede"

    const/4 v6, 0x7

    const-string/jumbo v3, "urvfdeue_belannfnbeetig"

    const-string v3, "event_buffering_enabled"

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v3, "dcs_eeatvirxdi_eel"

    const/4 v6, 0x3

    const-string/jumbo v3, "tireeadpvdi_cxenl_"

    const-string v3, "external_device_id"

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v2, "entpn_edqressaedslseio"

    const-string/jumbo v2, "needs_response_details"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const-string/jumbo v2, "mss_nmo"

    const-string/jumbo v2, "nammo_s"

    const/4 v6, 0x7

    const-string/jumbo v2, "semmna_"

    const-string/jumbo v2, "os_name"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v2, "rnoso_eooi"

    const-string/jumbo v2, "nis_ooevor"

    const/4 v6, 0x4

    const-string v2, "_vesobnsri"

    const-string/jumbo v2, "os_version"

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v2, "e_canguamebk"

    const-string/jumbo v2, "m_aagbckeean"

    const/4 v6, 0x2

    const-string/jumbo v2, "pm_ecagpkaea"

    const-string/jumbo v2, "package_name"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string v2, "hes_ouptqu"

    const-string/jumbo v2, "tnspu_uoeh"

    const-string/jumbo v2, "phseuk_ton"

    const-string/jumbo v2, "push_token"

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    move v6, v5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v2, "r_emstepi"

    const-string v2, "_teseirpc"

    const/4 v6, 0x1

    const-string/jumbo v2, "icesoedtr"

    const-string/jumbo v2, "secret_id"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v6, 0x6

    return-object v0
.end method

.method private getEventSuffix(Lcom/adjust/sdk/AdjustEvent;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p1, Lcom/adjust/sdk/AdjustEvent;->revenue:Ljava/lang/Double;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustEvent;->eventToken:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    aput-object p1, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string p1, "/%/qsb"

    const-string p1, "/%q/s/"

    const-string/jumbo p1, "u/s%//"

    const-string p1, "\'%s\'"

    const/4 v4, 0x7

    move v5, v4

    invoke-static {p1, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    return-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    aput-object v0, v3, v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p1, Lcom/adjust/sdk/AdjustEvent;->currency:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput-object v0, v3, v1

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/AdjustEvent;->eventToken:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v0, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    aput-object p1, v3, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p1, " /%/s5,p(/.s%s%f/"

    const-string p1, "/%s %/(%/s/5 ,s.f"

    const/4 v5, 0x3

    const-string p1, " f/)5s//q%,.% s/("

    const-string p1, "(%.5f %s, \'%s\')"

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p1, v3}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object p1
.end method

.method private getGdprParameters()Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    move v6, v5

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x0

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v2, "dusiamniur_d"

    const-string/jumbo v2, "udrmniiaud_d"

    const/4 v6, 0x1

    const-string/jumbo v2, "udumndidar_i"

    const-string v2, "android_uuid"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v2, "_spoodda"

    const-string v2, "asdpod_i"

    const/4 v6, 0x3

    const-string v2, "gps_adid"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    int-to-long v1, v1

    const/4 v6, 0x5

    const-string/jumbo v3, "tabg_bipst_mtdea"

    const-string v3, "a_taibgedsptp_tm"

    const/4 v6, 0x7

    const-string/jumbo v3, "pdtaituts_gedamp"

    const-string v3, "gps_adid_attempt"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "s_r_ducpdgis"

    const-string v2, "ciprsgu_d_sd"

    const/4 v6, 0x5

    const-string v2, "_d_isgdcqaps"

    const-string v2, "gps_adid_src"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const-string/jumbo v2, "pasaibcn_eketnlr"

    const-string v2, "caekanbpe_rdtinl"

    const/4 v6, 0x6

    const-string v2, "clgm_dektinanabr"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    move v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "iqiaoedd_"

    const-string v2, "ar_ieddiq"

    const/4 v6, 0x2

    const-string v2, "drdfebiia"

    const-string v2, "fire_adid"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v2, "ftlakeudnierbgcei__ns"

    const-string/jumbo v2, "irsga_nnfetec_elibkad"

    const/4 v6, 0x5

    const-string/jumbo v2, "nlgenrdpfk_breia_ceit"

    const-string v2, "fire_tracking_enabled"

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x6

    or-int/2addr v6, v5

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v3, "reDsrIs qndlcdnndrgil a malpi iteoeenreegl eitw Aotfe  gcilon t eP krtfldy FDai eGInoroAFl e dtnivetao,ks tbGealiodi  vgio "

    const-string/jumbo v3, "itIm  i ge ae fwgi eddspol ia e ir rtgoddae tnfnFvdiraAnteronorcs,tG Ds lGDoilAyrteev onilPo l kagibleieonaFlt kedentcl  eI"

    const/4 v6, 0x0

    const-string v3, "Dgsldkyne,e  l  einsdr  fkeilicreIneaodne i   dAeiindteGaenoorsiawAogFotgiead ottov i saftglrll FGtcb pencI PD  rl olirtvte"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v2, "rodmidodi_"

    const-string/jumbo v2, "rnddoodi_i"

    const-string/jumbo v2, "rin_oiaddo"

    const-string v2, "android_id"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string/jumbo v2, "ilvb_beea"

    const-string/jumbo v2, "liealb_ev"

    const/4 v6, 0x2

    const-string v2, "eielvaupl"

    const-string v2, "api_level"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "prce_papst"

    const-string v2, "_atprpucse"

    const/4 v6, 0x6

    const-string v2, "at_esrppqe"

    const-string v2, "app_secret"

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "epsopa_pt"

    const-string v2, "ektopapp_"

    const/4 v6, 0x3

    const-string v2, "epnmp_tak"

    const-string v2, "app_token"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "vi_qoppnsre"

    const-string v2, "eanipvp_qsr"

    const-string/jumbo v2, "irvnabpespo"

    const-string v2, "app_version"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v2, "tiebiauurkdtoptisnnl"

    const-string v2, "btsni_ntotrealiipkud"

    const/4 v6, 0x2

    const-string v2, "autniodpknbtlrpi_ite"

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v4, "eatmerc_qa"

    const-string v4, "adcme_reat"

    const/4 v6, 0x6

    const-string/jumbo v4, "rdsea_taet"

    const-string v4, "created_at"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    move v6, v5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const-string/jumbo v3, "nodmkvnc_eoe"

    const-string v3, "cvkooneied_n"

    const-string/jumbo v3, "n_nwoeoidkev"

    const-string v3, "device_known"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v3, "osncbbeets"

    const-string/jumbo v3, "seotebdcsn"

    const/4 v6, 0x5

    const-string v3, "_tsneduocs"

    const-string/jumbo v3, "needs_cost"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v6, 0x0

    const-string v3, "diecuempnve"

    const-string v3, "e_midcuenve"

    const-string/jumbo v3, "meee_civqnd"

    const-string v3, "device_name"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x4

    move v6, v5

    const-string/jumbo v3, "itcpdevpy_e"

    const/4 v6, 0x5

    const-string v3, "_eseiptcdev"

    const-string v3, "device_type"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v2, v2, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    int-to-long v2, v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v4, "uq_moie"

    const-string/jumbo v4, "oqed_iu"

    const/4 v6, 0x1

    const-string v4, "_deioou"

    const-string/jumbo v4, "ui_mode"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v3, "ensnronveim"

    const/4 v6, 0x7

    const-string/jumbo v3, "itmeobnrenv"

    const-string v3, "environment"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const-string/jumbo v3, "vetnffu_rebn_geualdbeni"

    const-string/jumbo v3, "tb_mnblfeeegferianndu_v"

    const-string/jumbo v3, "v_lueiap_nenfngbefbedrt"

    const-string v3, "event_buffering_enabled"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v6, 0x4

    const-string/jumbo v3, "idedavoxq_nr_eitec"

    const-string v3, "etdroi_daeielc_xvn"

    const/4 v6, 0x6

    const-string/jumbo v3, "ivscr_eex_atldende"

    const-string v3, "external_device_id"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "eromdesedi_nesane_spst"

    const-string/jumbo v2, "needs_response_details"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x4

    const-string/jumbo v2, "smbno_a"

    const-string v2, "eamnsb_"

    const/4 v6, 0x6

    const-string/jumbo v2, "o_msabn"

    const-string/jumbo v2, "os_name"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x4

    const-string/jumbo v2, "ueosvourin"

    const-string/jumbo v2, "osersiunov"

    const/4 v6, 0x2

    const-string/jumbo v2, "isoonsvpe_"

    const-string/jumbo v2, "os_version"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v2, "ecm_gaepkaap"

    const/4 v6, 0x6

    const-string/jumbo v2, "kacmpe_aqang"

    const-string/jumbo v2, "package_name"

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v2, "k_stepqsuh"

    const-string/jumbo v2, "uothekspq_"

    const/4 v6, 0x0

    const-string/jumbo v2, "p_emsnhkou"

    const-string/jumbo v2, "push_token"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v6, 0x5

    const-string/jumbo v2, "sds_etcri"

    const/4 v6, 0x0

    const-string v2, "e_rsotdei"

    const-string/jumbo v2, "secret_id"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object v0
.end method

.method private getInfoParameters(Ljava/lang/String;)Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v2, "dmniobdriadu"

    const-string v2, "adimdirdnou_"

    const/4 v6, 0x4

    const-string v2, "durudiun_adi"

    const-string v2, "android_uuid"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const-string v2, "dpsaog_d"

    const-string v2, "dap_dsip"

    const-string v2, "gps_adid"

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    int-to-long v1, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v3, "tpattd_bqads_meg"

    const-string v3, "epitdb_ats_agmtd"

    const/4 v6, 0x3

    const-string v3, "e_stgpmtdaip_ast"

    const-string v3, "gps_adid_attempt"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v2, "ra_m_dipsguc"

    const-string v2, "argdc_us_sip"

    const/4 v6, 0x5

    const-string/jumbo v2, "ssc_opddia_g"

    const-string v2, "gps_adid_src"

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v2, "epnaibtldrcabken"

    const-string v2, "bglkeanpcinardte"

    const/4 v6, 0x3

    const-string/jumbo v2, "kna_leungbiecdrt"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v2, "difaeiqp_"

    const-string v2, "fdidiea_q"

    const/4 v6, 0x6

    const-string v2, "fire_adid"

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "bcaignreqrnta_edief_k"

    const-string v2, "fire_tracking_enabled"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v3, " ssaleoeei ldGieIntltad otlnigogl dciyoofglFeirra  tdorol rsiPptnie asd,eweIGlr foaADa v te iF tgDi   nsArdec n k eviktenne"

    const-string/jumbo v3, "trso t ,af ly IgrcpitGkncaedsi w Aig afon rnGredeln oeoAIio Fr  dPDe edolekanl adgivng De te nlidlF lctoi ialioetesisetvtre"

    const/4 v6, 0x7

    const-string v3, "eismnwtilceaDi logil rDGr t  ndnoyGeeftriagdoiAn  rettecfe ii drilol AerIealtn IgFvit  p  ko,kPdevotd n basadeFeo noalsle c"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "_mrnoidaid"

    const-string v2, "diamdrin_d"

    const/4 v6, 0x2

    const-string v2, "aiddnbdori"

    const-string v2, "android_id"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v2, "ce_tsaueor"

    const-string/jumbo v2, "secpoater_"

    const/4 v6, 0x0

    const-string/jumbo v2, "pseaprcpet"

    const-string v2, "app_secret"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    move v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v2, "etno_bpap"

    const/4 v6, 0x0

    const-string v2, "ek_anptpq"

    const-string v2, "app_token"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v2, "eosliunbeidtp_aktuin"

    const-string/jumbo v2, "litieuut_eonipnkatdb"

    const/4 v6, 0x3

    const-string/jumbo v2, "trnmetkildntouei_ipa"

    const-string v2, "attribution_deeplink"

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v6, 0x1

    const/4 v5, 0x4

    const-string v4, "ad_coepeat"

    const-string/jumbo v4, "raeeac_pdt"

    const/4 v6, 0x0

    const-string v4, "_deaebtatr"

    const-string v4, "created_at"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v4, v2, v3}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const-string v3, "dnwqevukionc"

    const-string/jumbo v3, "nwnoeikcqvd_"

    const/4 v6, 0x0

    const-string/jumbo v3, "v_ecnodpneki"

    const-string v3, "device_known"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v3, "nt_essodqs"

    const-string v3, "c_stoensds"

    const/4 v6, 0x6

    const-string v3, "_nssestoec"

    const-string/jumbo v3, "needs_cost"

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v5, 0x3

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v6, 0x7

    const-string/jumbo v3, "oivmetnmnnr"

    const-string/jumbo v3, "vnimnmnoert"

    const/4 v6, 0x1

    const-string/jumbo v3, "nnonoimever"

    const-string v3, "environment"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v2, v2, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "noendbufievebleb_atgn_f"

    const-string/jumbo v3, "ngv_oeetdeunle_ebaiffbn"

    const/4 v6, 0x5

    const-string v3, "drgteeu_nalnfevbeufein_"

    const-string v3, "event_buffering_enabled"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v3, "_eexddapivcbtnelre"

    const-string v3, "dvie_bxdniaeletcer"

    const/4 v6, 0x7

    const-string v3, "atev_inrq_elxdeiec"

    const-string v3, "external_device_id"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v3, v2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v2, "dessndretpnsu__eeesloa"

    const-string v2, "_pltesudsernn_eosseeda"

    const/4 v6, 0x1

    const-string v2, "esemdtposse__nndseaile"

    const-string/jumbo v2, "needs_response_details"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v2, "otsuopp_eh"

    const-string v2, "huntseopp_"

    const-string v2, "_usnobektp"

    const-string/jumbo v2, "push_token"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v5, 0x4

    const-string/jumbo v2, "stde_iuqr"

    const-string/jumbo v2, "redst_ciq"

    const/4 v6, 0x2

    const-string v2, "edire_cps"

    const-string/jumbo v2, "secret_id"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v1, "srqcue"

    const-string v1, "ecsrus"

    const/4 v6, 0x2

    const-string/jumbo v1, "oussre"

    const-string/jumbo v1, "source"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x7

    const/4 v5, 0x5

    return-object v0
.end method

.method private getMeasurementConsentParameters(Z)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x4

    if-eqz p1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string p1, "eemmnl"

    const-string p1, "ealmne"

    const/4 v5, 0x2

    const-string p1, "aelbon"

    const-string p1, "enable"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo p1, "oeliabd"

    const-string p1, "eadiosl"

    const/4 v5, 0x6

    const-string/jumbo p1, "idebsau"

    const-string p1, "disable"

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v1, "auemeetpnrb"

    const-string/jumbo v1, "unmeabertes"

    const/4 v5, 0x0

    const-string v1, "euesmemtqar"

    const-string/jumbo v1, "measurement"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "nisuuoaddu_d"

    const-string/jumbo v1, "iuodddunar_u"

    const/4 v5, 0x3

    const-string v1, "da_moidnurdu"

    const-string v1, "android_uuid"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "gaddsp_p"

    const/4 v5, 0x3

    const-string/jumbo v1, "siapogdd"

    const-string v1, "gps_adid"

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget p1, p1, Lcom/adjust/sdk/a;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    int-to-long v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo p1, "idtd_bqppgas_tmt"

    const-string/jumbo p1, "sapetdgiq_dptm_t"

    const/4 v5, 0x7

    const-string p1, "d_aimtuptp_egdsa"

    const-string p1, "gps_adid_attempt"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const-string/jumbo v1, "rpdidgapscs_"

    const-string v1, "ais_g_pdscrd"

    const/4 v5, 0x6

    const-string v1, "_ircdsgdqsa_"

    const-string v1, "gps_adid_src"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const-string/jumbo v1, "kescbanaegdmtil_"

    const-string v1, "ec_mtanabldrkeig"

    const/4 v5, 0x3

    const-string/jumbo v1, "nlemciedragbk_an"

    const-string/jumbo v1, "tracking_enabled"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v1, "e_daoofdi"

    const-string/jumbo v1, "i_eroadfd"

    const/4 v5, 0x4

    const-string v1, "ei_afbdir"

    const-string v1, "fire_adid"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    move v5, v4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "fkdr_buterlien_gecnba"

    const-string/jumbo v1, "lgce_baab_ierkfnndetr"

    const/4 v5, 0x7

    const-string v1, "_rreakipceetldfb_nagi"

    const-string v1, "fire_tracking_enabled"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez p1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object p1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    move v5, v1

    const/4 v4, 0x7

    move v5, v4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "Pcp  o fqgelnFen elI air iitudttegolrrFovainney nwe iDD,lela   rvgfe sdl tso adtknddeAdnGagoatkcI o  icletoebAiirer  Gtioie"

    const-string v2, "dsrecvuwogl ti rlefFlnonaeg e e eoGtIn aeiet kDdo eiAladntnlg iovrorc rkn aeitd dl c oedrisIGpF noifa tleltiay gtDiPA,e  bi"

    const/4 v5, 0x7

    const-string v2, "e sdeoefo   aaenoe , boinrnikgeIafopDlAts tIieceotivD oFelt dngeyise iadllPliAii cotenar i t lGeGcs  gaFklndgd r rdrtl tvwn"

    const-string v2, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p1, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "rdpmiiaodd"

    const-string/jumbo v1, "iar_diopdd"

    const/4 v5, 0x0

    const-string v1, "android_id"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v1, "lpaeovqil"

    const-string v1, "ealelpivq"

    const/4 v5, 0x7

    const-string/jumbo v1, "v_peabeli"

    const-string v1, "api_level"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const-string v1, "cte_spupsr"

    const-string v1, "ecss_ptrap"

    const/4 v5, 0x3

    const-string v1, "_septpapce"

    const-string v1, "app_secret"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v1, "pkmoae_nq"

    const-string/jumbo v1, "tkamnoep_"

    const/4 v5, 0x7

    const-string/jumbo v1, "oksanpte_"

    const-string v1, "app_token"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v1, "v_smoieapnp"

    const-string v1, "anieovps_pr"

    const/4 v5, 0x4

    const-string/jumbo v1, "vaipore_ops"

    const-string v1, "app_version"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v1, "knnbdbietptu_oitlrai"

    const-string v1, "eptinbrleu_ainktdoti"

    const/4 v5, 0x3

    const-string v1, "attribution_deeplink"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v3, "atredeu_ua"

    const-string v3, "edrtatue_a"

    const/4 v5, 0x1

    const-string/jumbo v3, "re_tadapet"

    const-string v3, "created_at"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "nndkevpeqcwo"

    const-string/jumbo v2, "kiowdvepennc"

    const/4 v5, 0x0

    const-string v2, "eesk_vcwndio"

    const-string v2, "device_known"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "eenm_dvecma"

    const-string/jumbo v2, "m_evanecqde"

    const/4 v5, 0x6

    const-string/jumbo v2, "nameoedicev"

    const-string v2, "device_name"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v2, "idesyb_ecet"

    const-string/jumbo v2, "i_septeyedc"

    const/4 v5, 0x1

    const-string v2, "dyicptuee_v"

    const-string v2, "device_type"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    int-to-long v1, v1

    const/4 v4, 0x4

    and-int/2addr v5, v4

    const-string/jumbo v3, "po_muei"

    const-string/jumbo v3, "umomei_"

    const/4 v5, 0x0

    const-string v3, "dq_eiuo"

    const-string/jumbo v3, "ui_mode"

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v2, "orsnetnomvi"

    const-string/jumbo v2, "nneiomnvort"

    const/4 v5, 0x2

    const-string/jumbo v2, "venmirmnnto"

    const-string v2, "environment"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v4, 0x1

    move v5, v4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v2, "gufro_nbteiadnvneel_bfe"

    const-string v2, "event_buffering_enabled"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v2, "e_eedbite_rblaxind"

    const-string/jumbo v2, "xdeeeb_rntlia_vied"

    const/4 v5, 0x2

    const-string v2, "_ietveuxa_ndliecre"

    const-string v2, "external_device_id"

    const/4 v4, 0x5

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "eedsdsrp_luepnit_essoa"

    const-string v1, "e_e_douaenslestpeissdr"

    const/4 v5, 0x6

    const-string v1, "ae_nsnloqssse_ddrtepee"

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object p1, p1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v1, "mssaepn"

    const-string/jumbo v1, "ps_neam"

    const/4 v5, 0x5

    const-string/jumbo v1, "onmm_ae"

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "n_esoviosq"

    const-string/jumbo v1, "osseoi_nqv"

    const/4 v5, 0x4

    const-string/jumbo v1, "roiosbsvn_"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v1, "gmpesauaace_"

    const-string v1, "eesgaackp_ma"

    const/4 v5, 0x1

    const-string v1, "cegaamnpapke"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v4, 0x0

    move v5, v4

    const-string/jumbo v1, "useopt_hqm"

    const-string v1, "_ntmseohup"

    const/4 v5, 0x3

    const-string/jumbo v1, "tpsheno_ks"

    const-string/jumbo v1, "push_token"

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v1, "drsmo_ece"

    const-string/jumbo v1, "rei_odecs"

    const/4 v5, 0x3

    const-string v1, "e_dtorsce"

    const-string/jumbo v1, "secret_id"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    return-object v0
.end method

.method private getSessionParameters(Z)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/SessionParameters;->callbackParameters:Ljava/util/Map;

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v1, "bab_rbccklasmpl"

    const-string/jumbo v1, "kacaablbcpmlrs_"

    const-string v1, "b_akcluacsplram"

    const-string v1, "callback_params"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p1, Lcom/adjust/sdk/SessionParameters;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v1, "_aapprmprnaute"

    const-string/jumbo v1, "reaantu_pamrpr"

    const/4 v5, 0x1

    const-string/jumbo v1, "partner_params"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x7

    move v5, v4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "pududa_rqoin"

    const-string v1, "ddoauirpiu_n"

    const/4 v5, 0x0

    const-string v1, "android_uuid"

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "d_sdsgiq"

    const-string/jumbo v1, "qdpsgdi_"

    const/4 v5, 0x3

    const-string/jumbo v1, "pigmsa_d"

    const-string v1, "gps_adid"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget p1, p1, Lcom/adjust/sdk/a;->c:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    int-to-long v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo p1, "tatiodgmsdseppt_"

    const-string/jumbo p1, "tsstgddpem__atip"

    const/4 v5, 0x5

    const-string p1, "ai_sdbtmtp_dgpae"

    const-string p1, "gps_adid_attempt"

    const/4 v5, 0x1

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x4

    or-int/2addr v5, v4

    iget-object p1, p1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v1, "riapssuddm_c"

    const-string/jumbo v1, "p_amrisdscd_"

    const/4 v5, 0x6

    const-string/jumbo v1, "rsid_dapgcp_"

    const-string v1, "gps_adid_src"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const-string v1, "_anoeidkqcaretbn"

    const-string/jumbo v1, "nntrodkegecbaa_i"

    const/4 v5, 0x0

    const-string/jumbo v1, "i_sdtaeeagcrklbn"

    const-string/jumbo v1, "tracking_enabled"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const-string v1, "afim_ridd"

    const-string v1, "fire_adid"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "rtleoacd_enkigbae_frb"

    const-string v1, "_kglcbfrnnieeabrta_ed"

    const/4 v5, 0x5

    const-string v1, "eirrbbfeni_kldacnt_ea"

    const-string v1, "fire_tracking_enabled"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez p1, :cond_3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez p1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object p1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    shl-int/2addr v5, v1

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v2, "dcoostuv nen seetDoroetinniGuedi eoigIaA itw rlfiaeDlrgrdlldl,e ale dtdgon  ntkrbF Iiek tFv e gr cacnPlA poie  f yseGtoaili"

    const-string v2, "asd leu, aoFatesegfDstdyindIeieekia rbFrnilftkegogel Gd  lgoolrvD   coAeiIenA dtaalit coPtnolvnti rr oierewil e cGni n p td"

    const/4 v5, 0x6

    const-string v2, "dtFotnnplIr lAevleiiwGecPte erinievnlasktlAefeiga onfioG,  ro arDF  gidrsa a ylaottnkgbdeop Iigl od dD  eeriecd netitl  cos"

    const-string v2, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {p1, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v1, "nrdoipi_qd"

    const-string v1, "ddii_nopra"

    const/4 v5, 0x3

    const-string/jumbo v1, "idsodadnri"

    const-string v1, "android_id"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v1, "qvpmi_lee"

    const-string/jumbo v1, "l_iveepaq"

    const-string v1, "api_level"

    const/4 v4, 0x2

    move v5, v4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const-string v1, "_eetopspsr"

    const-string/jumbo v1, "rpsptseae_"

    const/4 v5, 0x5

    const-string v1, "a_eppbretc"

    const-string v1, "app_secret"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "_aomtkupe"

    const-string v1, "aekmpo_tn"

    const/4 v5, 0x6

    const-string/jumbo v1, "o_tapkppn"

    const-string v1, "app_token"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v1, "ipenpos_qar"

    const-string v1, "es_noarippo"

    const/4 v5, 0x0

    const-string v1, "app_version"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const-string/jumbo v1, "ltsietudiarntnbb_oek"

    const-string v1, "detnpbelunarikbtt_io"

    const-string v1, "attribution_deeplink"

    const/4 v4, 0x0

    and-int/2addr v5, v4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    int-to-long v1, v1

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    const-string/jumbo v3, "onvmncyte_iucytte"

    const-string/jumbo v3, "yti_youictnvcteen"

    const-string v3, "_tiyoccynnoiepett"

    const-string v3, "connectivity_type"

    const/4 v5, 0x7

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v2, "tyornbc"

    const-string v2, "country"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v2, "yue_cpup"

    const-string v2, "_peuytcp"

    const/4 v5, 0x5

    const-string v2, "cpu_type"

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v3, "ctarteepdq"

    const-string v3, "d_tteceaqr"

    const/4 v5, 0x5

    const-string v3, "etat_aceqd"

    const-string v3, "created_at"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->defaultTracker:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const-string v2, "fesaelta_trudck"

    const-string v2, "default_tracker"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v2, "kiemdev_wnos"

    const-string/jumbo v2, "wdseke_voinn"

    const/4 v5, 0x7

    const-string/jumbo v2, "kdn_ooecievw"

    const-string v2, "device_known"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v2, "cdsnobee_t"

    const-string/jumbo v2, "sd_menocte"

    const/4 v5, 0x0

    const-string v2, "csoe_sunde"

    const-string/jumbo v2, "needs_cost"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "oreuvenpa_aceuditrm"

    const-string/jumbo v2, "meetoiccurv_udranea"

    const/4 v5, 0x1

    const-string v2, "device_manufacturer"

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v2, "_cmdbievqna"

    const-string v2, "_ednabvceim"

    const/4 v5, 0x5

    const-string v2, "device_name"

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v2, "uyspetee_vc"

    const-string v2, "eetiy_upcve"

    const/4 v5, 0x5

    const-string v2, "evimp_edtey"

    const-string v2, "device_type"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    int-to-long v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, "epodoi_"

    const-string/jumbo v3, "p_oeimd"

    const-string/jumbo v3, "iodumb_"

    const-string/jumbo v3, "ui_mode"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v4, 0x3

    move v5, v4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v2, "iaqgipuhd_lshe"

    const-string/jumbo v2, "i_lthsipqdeagh"

    const/4 v5, 0x5

    const-string v2, "display_height"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v2, "thd_iwlpiasyp"

    const-string v2, "_ssldwtyhiipa"

    const/4 v5, 0x6

    const-string/jumbo v2, "p_iwatldqsyih"

    const-string v2, "display_width"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v2, "vnstmrnnmio"

    const-string/jumbo v2, "nntmveinmro"

    const/4 v5, 0x6

    const-string/jumbo v2, "mneminevotr"

    const-string v2, "environment"

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "ton_oeivbgnunfabr_elfee"

    const-string v2, "afnbog_lfnitrveube_ende"

    const/4 v5, 0x5

    const-string v2, "_teafbevbn_neeelbdngiuf"

    const-string v2, "event_buffering_enabled"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v4, 0x1

    move v5, v4

    const-string v2, "eeedd_utvbcaxelrin"

    const-string/jumbo v2, "rndedblvaieiexect_"

    const-string/jumbo v2, "leiixa_pcnvdteered"

    const-string v2, "external_device_id"

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v5, 0x4

    const-string v2, "biuq_"

    const-string v2, "_uidb"

    const/4 v5, 0x1

    const-string v2, "b_sdf"

    const-string v2, "fb_id"

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x5

    move v5, v4

    iget-object v1, v1, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v2, "haamwedepnmar"

    const-string v2, "aemnarapewd_h"

    const/4 v5, 0x0

    const-string/jumbo v2, "na_roaearehdm"

    const-string v2, "hardware_name"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    const-string v2, "_ltadbqelait"

    const-string v2, "dltetalsqa_i"

    const/4 v5, 0x2

    const-string v2, "elsanlutid_a"

    const-string/jumbo v2, "installed_at"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "gnsugeal"

    const/4 v5, 0x5

    const-string v2, "gaguneap"

    const-string/jumbo v2, "language"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-wide v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->e:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const-string/jumbo v3, "svtlrnilq_ame"

    const-string v3, "aremavni_tlsl"

    const/4 v5, 0x0

    const-string/jumbo v3, "ils_artastenl"

    const-string/jumbo v3, "last_interval"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v2, "ccm"

    const-string v2, "cmc"

    const/4 v5, 0x7

    const-string/jumbo v2, "mcc"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v2, "mcn"

    const-string/jumbo v2, "ncm"

    const/4 v5, 0x0

    const-string v2, "cmn"

    const-string/jumbo v2, "mnc"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "psdmee_ea_tndesreonisl"

    const-string/jumbo v1, "tre_opd_ldeesneanoiess"

    const/4 v5, 0x1

    const-string v1, "_nilooseedapsedses_ret"

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v1, "ulb_obid"

    const-string/jumbo v1, "si_lubod"

    const/4 v5, 0x5

    const-string v1, "dsoliuu_"

    const-string/jumbo v1, "os_build"

    const/4 v4, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v1, "psu_ean"

    const-string v1, "_ensoau"

    const/4 v5, 0x4

    const-string v1, "eqosnam"

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "pnsiss_ooe"

    const-string/jumbo v1, "visnooeps_"

    const/4 v5, 0x0

    const-string/jumbo v1, "s_emsivnor"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x0

    const-string v1, "g_cqomnaakpa"

    const-string/jumbo v1, "mea_capnqakg"

    const/4 v5, 0x6

    const-string/jumbo v1, "nkmeebpacaag"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v4, 0x4

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v1, "hekonsupu_"

    const-string/jumbo v1, "kuss_epohn"

    const/4 v5, 0x3

    const-string/jumbo v1, "push_token"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "ynceesnpemis_t"

    const-string/jumbo v1, "iermssn_yetnec"

    const/4 v5, 0x3

    const-string/jumbo v1, "nictdersq_eysn"

    const-string/jumbo v1, "screen_density"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object p1, p1, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v1, "cosasornfm_re"

    const-string/jumbo v1, "rncrooemsef_a"

    const/4 v5, 0x1

    const-string v1, "_oemfrmtesrna"

    const-string/jumbo v1, "screen_format"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "eniroesecs_"

    const-string/jumbo v1, "rsieebec_sn"

    const-string v1, "ezecrbsies_"

    const-string/jumbo v1, "screen_size"

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "ectedsuur"

    const-string v1, "des_cruet"

    const/4 v5, 0x0

    const-string v1, "_teecdrpi"

    const-string/jumbo v1, "secret_id"

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    int-to-long v1, p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo p1, "tsnoucseqoip_"

    const-string/jumbo p1, "onicosepnuts_"

    const/4 v5, 0x0

    const-string p1, "cns_soteosuis"

    const-string/jumbo p1, "session_count"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-wide v1, p1, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const/4 v5, 0x6

    const-string p1, "ehsmg_tlqnessn"

    const-string p1, "gnsl_iesqsthen"

    const/4 v5, 0x0

    const-string/jumbo p1, "session_length"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    int-to-long v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string/jumbo p1, "tinuosssuoeobsn_"

    const-string/jumbo p1, "nss_seubsuitsoon"

    const/4 v5, 0x6

    const-string p1, "_octubnisounsbss"

    const-string/jumbo p1, "subsession_count"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-wide v1, p1, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string p1, "_tmemnuiet"

    const-string/jumbo p1, "nptmm_etie"

    const/4 v5, 0x7

    const-string p1, "_nestpmpet"

    const-string/jumbo p1, "time_spent"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    const-string/jumbo v1, "tpoddeauqt"

    const-string v1, "dtetopd_au"

    const-string/jumbo v1, "updated_at"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object v0
.end method

.method private getSubscriptionParameters(Lcom/adjust/sdk/AdjustPlayStoreSubscription;Z)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/AdjustPlayStoreSubscription;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v2, "o_sudbundida"

    const-string v2, "adiouburdd_n"

    const/4 v5, 0x4

    const-string/jumbo v2, "irumui_odndd"

    const-string v2, "android_uuid"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v2, "_saioudp"

    const-string v2, "_dagpsui"

    const/4 v5, 0x0

    const-string v2, "dadgsbi_"

    const-string v2, "gps_adid"

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, v1, Lcom/adjust/sdk/a;->c:I

    const/4 v5, 0x3

    int-to-long v1, v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v3, "d_mtepu_pigttsda"

    const-string/jumbo v3, "tm__aippstgtdped"

    const/4 v5, 0x2

    const-string/jumbo v3, "tm_ie_dpaptdpasg"

    const-string v3, "gps_adid_attempt"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "qad_psdrqg_s"

    const-string/jumbo v2, "ipgsrsdaq_d_"

    const/4 v5, 0x4

    const-string/jumbo v2, "sss__cgrpdai"

    const-string v2, "gps_adid_src"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, "animsna_cterdlbg"

    const-string/jumbo v2, "i_sabekrnngacdtl"

    const/4 v5, 0x5

    const-string v2, "aegaotbcde_nnlrk"

    const-string/jumbo v2, "tracking_enabled"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, "drdfibema"

    const-string v2, "adfmiiedr"

    const/4 v5, 0x2

    const-string v2, "dfe_aduii"

    const-string v2, "fire_adid"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v2, "ndaarceperog_bfln_kei"

    const-string/jumbo v2, "nibaoeigeanrd__cerlkf"

    const/4 v5, 0x3

    const-string v2, "fdec_kirqneglibea_nta"

    const-string v2, "fire_tracking_enabled"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v3, "dIsarrtk a oiernlaedDg o eettpid nAgskt ratne Fogen i eaolfnifeovwibiA o nstelci diG lta l D ieetecc br deo,PvGr lsFldliIng"

    const-string v3, "dnDAPb,Aesdebodra ngleglogi cIi ncs iae rtdc rF penielrnteGeni   eoig t lol Dlenli fwaselfiFekot doroka tiiGaItvt eatrod  v"

    const/4 v5, 0x7

    const-string v3, "eo,m  wsc  r delalcfFea tDigaii yl lnedeitnleddesrreeorsD kga Fivteifp d  nkAgAcntritI rtiobin il nt lnoGoIvoeeGd lga eooPt"

    const-string v3, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v1, v3, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const-string v2, "ai_uorodnd"

    const-string v2, "adrinoui_d"

    const/4 v5, 0x1

    const-string v2, "_rodibndia"

    const-string v2, "android_id"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez p2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->callbackParameters:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getCallbackParameters()Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v2, "Ckbalpuc"

    const-string v2, "Ckablclp"

    const/4 v5, 0x4

    const-string v2, "ackClabp"

    const-string v2, "Callback"

    const/4 v5, 0x7

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "racaamlcqsbklpa"

    const-string v1, "callback_params"

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getPartnerParameters()Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v2, "rasqPrn"

    const-string/jumbo v2, "rqranPt"

    const/4 v5, 0x6

    const-string v2, "Premtnr"

    const-string v2, "Partner"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v1, "aas_oatpsmpnrr"

    const-string v1, "epsaspra_tanmr"

    const/4 v5, 0x5

    const-string v1, "_anpaberatmsrp"

    const-string/jumbo v1, "partner_params"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "ime_llupe"

    const-string/jumbo v1, "i_emlplve"

    const/4 v5, 0x4

    const-string v1, "e_ivaelpl"

    const-string v1, "api_level"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v1, "ptpaeos_qr"

    const-string v1, "apcports_e"

    const/4 v5, 0x7

    const-string/jumbo v1, "p_sstaepre"

    const-string v1, "app_secret"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "ke_manbot"

    const-string/jumbo v1, "ketonb_pa"

    const/4 v5, 0x2

    const-string/jumbo v1, "tponoa_ek"

    const-string v1, "app_token"

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x2

    const-string/jumbo v1, "peparbonsi_"

    const-string v1, "app_version"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "oupetkun_dutieitnlra"

    const-string v1, "ek_plduirentiutontab"

    const/4 v5, 0x3

    const-string/jumbo v1, "iteulrepnndii_tpktba"

    const-string v1, "attribution_deeplink"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    int-to-long v1, v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo v3, "inetpcttqipyecv_o"

    const-string/jumbo v3, "nc_tiiepycoteyptv"

    const/4 v5, 0x6

    const-string/jumbo v3, "yiscnynvt_iceptoe"

    const-string v3, "connectivity_type"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v2, "qnymroc"

    const-string/jumbo v2, "uqrcoyn"

    const/4 v5, 0x4

    const-string/jumbo v2, "otrcoyn"

    const-string v2, "country"

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v2, "ucsy_btp"

    const-string/jumbo v2, "tys_upec"

    const/4 v5, 0x7

    const-string/jumbo v2, "upc_eyup"

    const-string v2, "cpu_type"

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v3, "ceadertp_m"

    const-string v3, "cadmar_tee"

    const/4 v5, 0x7

    const-string v3, "eadeattcq_"

    const-string v3, "created_at"

    const/4 v4, 0x2

    move v5, v4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->defaultTracker:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v2, "aasfrultetdrok_"

    const-string v2, "ct_uortdkarfeal"

    const/4 v5, 0x5

    const-string v2, "aflmuce_redtkta"

    const-string v2, "default_tracker"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "inncovo_bwed"

    const-string/jumbo v2, "wdvo_biecnnk"

    const/4 v5, 0x7

    const-string v2, "eekonbinwvc_"

    const-string v2, "device_known"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v2, "socut_ueds"

    const-string v2, "ctnosdu_se"

    const/4 v5, 0x1

    const-string/jumbo v2, "o_sdscepne"

    const-string/jumbo v2, "needs_cost"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v2, "fmareicrqvnuated_cp"

    const-string/jumbo v2, "uaecrfepicenmdtr_av"

    const/4 v5, 0x1

    const-string/jumbo v2, "uesurce_acaemntidfv"

    const-string v2, "device_manufacturer"

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v2, "m_emiancqee"

    const-string/jumbo v2, "navei_emqce"

    const/4 v5, 0x3

    const-string/jumbo v2, "vieeoed_nca"

    const-string v2, "device_name"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, "escpebdtiye"

    const-string/jumbo v2, "iescpvtedye"

    const/4 v5, 0x1

    const-string/jumbo v2, "tdyvepue_ie"

    const-string v2, "device_type"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    int-to-long v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v3, "pdmi_me"

    const-string/jumbo v3, "md_mieu"

    const/4 v5, 0x6

    const-string/jumbo v3, "uqoiemd"

    const-string/jumbo v3, "ui_mode"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v2, "dtsoi_shlphygi"

    const-string/jumbo v2, "ldtpo_sygahhii"

    const/4 v5, 0x4

    const-string v2, "display_height"

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo v2, "lwymdspabid_t"

    const-string/jumbo v2, "sdyiabdl_pwti"

    const-string v2, "dsyaotdip_hwl"

    const-string v2, "display_width"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v2, "ienorbvtmeu"

    const-string/jumbo v2, "rteienuomvn"

    const/4 v5, 0x4

    const-string/jumbo v2, "vnertmuoenn"

    const-string v2, "environment"

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x6

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v2, "n_berlipeebfnteufave_ng"

    const-string v2, "event_buffering_enabled"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v2, "ldeanveeqi_pixtrce"

    const-string v2, "eeltcd_pnxierea_iv"

    const/4 v5, 0x1

    const-string v2, "eesnricddxvi_etae_"

    const-string v2, "external_device_id"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const-string/jumbo v2, "idfq_"

    const/4 v5, 0x1

    const-string v2, "bidm_"

    const-string v2, "fb_id"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    iget-object v1, v1, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v2, "amrhosdaweear"

    const-string v2, "aesrmaewdahr_"

    const/4 v5, 0x2

    const-string v2, "amendbh_rware"

    const-string v2, "hardware_name"

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v5, 0x0

    const-string/jumbo v2, "iletasumdtln"

    const-string/jumbo v2, "tsamendlltia"

    const/4 v5, 0x7

    const-string v2, "_talnilpdtse"

    const-string/jumbo v2, "installed_at"

    const/4 v4, 0x7

    const/4 v4, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v2, "qelnggua"

    const-string v2, "anuloegg"

    const/4 v5, 0x2

    const-string/jumbo v2, "ugsgenal"

    const-string/jumbo v2, "language"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->e:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, "_namilvtarbet"

    const-string v3, "et_albirnvtla"

    const/4 v5, 0x6

    const-string/jumbo v3, "last_interval"

    const/4 v5, 0x3

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "mcc"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x3

    const-string/jumbo v2, "mcc"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v2, "cnm"

    const-string/jumbo v2, "mnc"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "sdonoenaieesdetse_rul_"

    const-string/jumbo v1, "is_esduenneepe_tarldso"

    const/4 v5, 0x2

    const-string/jumbo v1, "seeiobtn_nslaesedper_d"

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "idsobuu_"

    const-string/jumbo v1, "i_dusobp"

    const/4 v5, 0x5

    const-string/jumbo v1, "os_build"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "pa_sonq"

    const-string v1, "_qsnaeo"

    const/4 v5, 0x2

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "ses_rnsoqi"

    const-string/jumbo v1, "irsonse_so"

    const/4 v5, 0x1

    const-string/jumbo v1, "vosrs_sioe"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v1, "cgamenmka_ae"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v1, "up_noetshm"

    const-string/jumbo v1, "pshm_neotu"

    const/4 v5, 0x4

    const-string/jumbo v1, "shnptb_oeu"

    const-string/jumbo v1, "push_token"

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "_iynodutssrece"

    const-string/jumbo v1, "srndosye_enitc"

    const/4 v5, 0x7

    const-string/jumbo v1, "inrtdysp_encse"

    const-string/jumbo v1, "screen_density"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v1, "r_anobefqmtcs"

    const-string/jumbo v1, "ofcsmbr_ntare"

    const/4 v5, 0x3

    const-string/jumbo v1, "rtsnrcsmefeo_"

    const-string/jumbo v1, "screen_format"

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v5, 0x3

    const-string v1, "euem_zrince"

    const-string/jumbo v1, "rszcieuene_"

    const/4 v5, 0x6

    const-string v1, "_eneosreisc"

    const-string/jumbo v1, "screen_size"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v1, "eitrdb_cp"

    const-string v1, "c_isedrpt"

    const/4 v5, 0x5

    const-string v1, "_ieedtusc"

    const-string/jumbo v1, "secret_id"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    int-to-long v1, p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo p2, "ssnnut_piceos"

    const-string/jumbo p2, "session_count"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-wide v1, p2, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const-string/jumbo p2, "tngqesenqlhsis"

    const-string/jumbo p2, "lshgesitqesonn"

    const/4 v5, 0x7

    const-string/jumbo p2, "nsseitsoselnhg"

    const-string/jumbo p2, "session_length"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    int-to-long v1, p2

    const/4 v5, 0x5

    const-string/jumbo p2, "nsemuuoit_cosnsb"

    const-string/jumbo p2, "uissb_nueoonctss"

    const/4 v5, 0x0

    const-string/jumbo p2, "s_toosbnnceiossu"

    const-string/jumbo p2, "subsession_count"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-wide v1, p2, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string p2, "etnipb_tms"

    const-string p2, "eipmtents_"

    const/4 v5, 0x6

    const-string p2, "emt_ipuens"

    const-string/jumbo p2, "time_spent"

    const/4 v4, 0x6

    or-int/2addr v5, v4

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p2, p2, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v1, "_epaatdpou"

    const-string/jumbo v1, "u_ptodaeat"

    const/4 v5, 0x2

    const-string/jumbo v1, "t_tddapeqa"

    const-string/jumbo v1, "updated_at"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getBillingStore()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v1, "slsegilt_ibro"

    const-string/jumbo v1, "iirl_bogtbsle"

    const/4 v5, 0x4

    const-string/jumbo v1, "selmbigloni_r"

    const-string v1, "billing_store"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getCurrency()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "cuyuonrr"

    const-string/jumbo v1, "unryrcue"

    const/4 v5, 0x0

    const-string/jumbo v1, "uycerbnr"

    const-string v1, "currency"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getSku()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "d_uptpurdi"

    const-string/jumbo v1, "rpi_uddpot"

    const-string/jumbo v1, "i_pdtudpcr"

    const-string/jumbo v1, "product_id"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getPurchaseToken()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "n_ekuehsqqaprc"

    const-string/jumbo v1, "spc_eurnqetakh"

    const/4 v5, 0x7

    const-string v1, "eoskrcupnhstea"

    const-string/jumbo v1, "purchase_token"

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getSignature()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v1, "cprmeit"

    const-string/jumbo v1, "pcseirt"

    const/4 v5, 0x6

    const-string v1, "eecropt"

    const-string/jumbo v1, "receipt"

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getPrice()J

    move-result-wide v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p2, "uremeev"

    const/4 v5, 0x3

    const-string/jumbo p2, "vureebe"

    const-string/jumbo p2, "revenue"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getPurchaseTime()J

    move-result-wide v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string p2, "_roisaucndotatte"

    const-string/jumbo p2, "n_coordttsaiaaet"

    const/4 v5, 0x6

    const-string/jumbo p2, "ittanoapcnsed_at"

    const-string/jumbo p2, "transaction_date"

    const/4 v5, 0x4

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/adjust/sdk/AdjustPlayStoreSubscription;->getOrderId()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo p2, "isrtd_noqbacti"

    const-string p2, "aiitnbtscrn_do"

    const/4 v5, 0x6

    const-string/jumbo p2, "transaction_id"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    move v5, v4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object v0
.end method

.method private getThirdPartySharingParameters(Lcom/adjust/sdk/AdjustThirdPartySharing;)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/AdjustThirdPartySharing;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p1, Lcom/adjust/sdk/AdjustThirdPartySharing;->isEnabled:Ljava/lang/Boolean;

    const/4 v5, 0x5

    if-eqz v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v1, "nusbel"

    const-string/jumbo v1, "uanbel"

    const/4 v5, 0x1

    const-string/jumbo v1, "lnamee"

    const-string v1, "enable"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, "bapdosi"

    const-string/jumbo v1, "pdasebi"

    const/4 v5, 0x4

    const-string/jumbo v1, "iadlbbe"

    const-string v1, "disable"

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v2, "ahirgsu"

    const-string/jumbo v2, "sharing"

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p1, Lcom/adjust/sdk/AdjustThirdPartySharing;->granularOptions:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v2, "aynrhptpnrplirt_noighdassrat_r__giqu"

    const-string v2, "_tn_arapqihta_gusgpsnria_yrnhriroltd"

    const/4 v5, 0x7

    const-string/jumbo v2, "tg_r_ighqop_yn_ihtnatlouaasrnrpidars"

    const-string v2, "granular_third_party_sharing_options"

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/AdjustThirdPartySharing;->partnerSharingSettings:Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v1, "tesatpi_rinsrs_sagetsghn"

    const-string/jumbo v1, "pnstehne_gaair_stntsgris"

    const-string/jumbo v1, "partner_sharing_settings"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "iommddruidan"

    const-string/jumbo v1, "u_dmriodidan"

    const/4 v5, 0x0

    const-string/jumbo v1, "uad_odurindo"

    const-string v1, "android_uuid"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "_gsdobdi"

    const-string v1, "dsago_di"

    const/4 v5, 0x5

    const-string v1, "dipsdaug"

    const-string v1, "gps_adid"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget p1, p1, Lcom/adjust/sdk/a;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    int-to-long v1, p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p1, "__gastepttdmapdi"

    const-string p1, "gps_adid_attempt"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, p1, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, "_r_asdsbqidp"

    const-string v1, "adi_dbgs_spr"

    const/4 v5, 0x6

    const-string/jumbo v1, "rds_gcs_aspd"

    const-string v1, "gps_adid_src"

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, "dbam_ncgeunlrike"

    const-string/jumbo v1, "tbnlndui_kcreeag"

    const/4 v5, 0x1

    const-string v1, "gde_ontraliecnba"

    const-string/jumbo v1, "tracking_enabled"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v1, "aerpib_fi"

    const-string v1, "draefi_pi"

    const/4 v5, 0x6

    const-string v1, "aireidud_"

    const-string v1, "fire_adid"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v1, "eentefapadbig_ilq_rkn"

    const-string v1, "fnanegreqiicdl__tbeka"

    const-string v1, "dkirenetqegfairn_ab_c"

    const-string v1, "fire_tracking_enabled"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-nez p1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget-object p1, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v2, "ecspnA a elrgdDasod ocsna tvnldrdwaeoeG dektiellt AlcniF loeleaii kno fb eFtin  Ion tg ovtDoiireaPir egr sdf ,iI lyrsGti eg"

    const-string/jumbo v2, "rnsl P anoaobe tiItlseargiefyd eeed wD Gnf c oioniirklei odcettaaertAooiFt l ilc vk nn pnDlg sF ltAldidergev  roeg,Gd Iesai"

    const/4 v5, 0x4

    const-string/jumbo v2, "n  m iolg kinF ollIo  AkdPannrbirgtalt nd,rcaietyDoeoroecaeieG acdFt  t AselDiete ltIrgaeerget    dsifsl wd ieidnevnvGipoof"

    const-string v2, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {p1, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p1, p1, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, "_iiroadmon"

    const-string v1, "drnm_aoiid"

    const-string/jumbo v1, "idi_obddra"

    const-string v1, "android_id"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p1, p1, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v1, "vpolilu_a"

    const-string v1, "_vploiela"

    const/4 v5, 0x0

    const-string v1, "api_level"

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v1, "bar_cetpsp"

    const-string v1, "ca_etbpser"

    const/4 v5, 0x1

    const-string/jumbo v1, "tpers_pcqe"

    const-string v1, "app_secret"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v1, "ktsna_poe"

    const-string v1, "eapok_utn"

    const/4 v5, 0x4

    const-string/jumbo v1, "paemt_pko"

    const-string v1, "app_token"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v1, "paoioprnpe_"

    const-string v1, "avrp_ippeon"

    const/4 v5, 0x6

    const-string/jumbo v1, "inporbvpsae"

    const-string v1, "app_version"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "lbqiaiutntknp_roteed"

    const-string/jumbo v1, "pnite_lkqenuttbdaroi"

    const/4 v5, 0x5

    const-string v1, "eiiikerpunb_ptdtlatn"

    const-string v1, "attribution_deeplink"

    const/4 v4, 0x5

    move v5, v4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v4, 0x7

    move v5, v4

    const-string/jumbo v3, "tatcas_dqe"

    const-string v3, "dcsta_aete"

    const/4 v5, 0x3

    const-string v3, "ersdatt_ac"

    const-string v3, "created_at"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v2, "oewmdnn_evmi"

    const-string/jumbo v2, "wodmnece_nvi"

    const/4 v5, 0x1

    const-string/jumbo v2, "nwecoondk_ve"

    const-string v2, "device_known"

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x1

    move v5, v4

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "cndevbaeoim"

    const-string v2, "eiaeovnmcd_"

    const/4 v5, 0x4

    const-string v2, "eiecadu_mvn"

    const-string v2, "device_name"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x4

    const-string v2, "epeycbev_di"

    const/4 v5, 0x5

    const-string v2, "eiyet_vpdep"

    const-string v2, "device_type"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x2

    int-to-long v1, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v3, "iqmdeuu"

    const-string v3, "ed_uimu"

    const/4 v5, 0x5

    const-string v3, "e_sioum"

    const-string/jumbo v3, "ui_mode"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v2, "rtnmmenipno"

    const-string/jumbo v2, "vnreoitpnmn"

    const/4 v5, 0x3

    const-string/jumbo v2, "ormeonvnnit"

    const-string v2, "environment"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v2, "reneabtfbilvgeduebnnq_e"

    const-string v2, "bi_dtegaqeenevnf_lrnbeu"

    const/4 v5, 0x1

    const-string/jumbo v2, "ineerbu_e_favndebtlefun"

    const-string v2, "event_buffering_enabled"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v2, "asdletepvcexerni__"

    const-string/jumbo v2, "ivsler_d_neadcexet"

    const/4 v5, 0x2

    const-string v2, "_relteevqena_xdcdi"

    const-string v2, "external_device_id"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v1, "sesasrpnsidee_lsetomne"

    const-string/jumbo v1, "rsomeeetnnads_elsesipd"

    const-string v1, "ei_msnleen_spesdtsdoea"

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v1, "ao_oone"

    const-string v1, "a_enoom"

    const/4 v5, 0x5

    const-string v1, "asnembo"

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x3

    const-string v1, "_eroisuvbn"

    const-string/jumbo v1, "vso_sbeirn"

    const/4 v5, 0x2

    const-string v1, "_sveoorpin"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x7

    const-string/jumbo v1, "pu_anegeqkma"

    const-string v1, "amegenuka_pa"

    const/4 v5, 0x7

    const-string v1, "aescpakm_age"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v1, "uhemp_knts"

    const-string/jumbo v1, "push_token"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x5

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "ircdeetps"

    const/4 v5, 0x6

    const-string v1, "cesrode_i"

    const-string/jumbo v1, "secret_id"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object v0
.end method

.method private injectFeatureFlagsWithParameters(Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-boolean v0, v0, Lcom/adjust/sdk/AdjustConfig;->coppaCompliantEnabled:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v4, 0x1

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "fcfp_bpa"

    const-string v0, "ff_coppa"

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {p1, v0, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean v0, v0, Lcom/adjust/sdk/AdjustConfig;->playStoreKidsAppEnabled:Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v0, "s_lrpqu_yfe__ikfsdotpa"

    const-string/jumbo v0, "ol_a_krtqss__fifdepppy"

    const/4 v4, 0x7

    const-string v0, "f_ktpeopf__yripalpa_ds"

    const-string v0, "ff_play_store_kids_app"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1, v0, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method


# virtual methods
.method public buildAdRevenuePackage(Lcom/adjust/sdk/AdjustAdRevenue;Z)Lcom/adjust/sdk/ActivityPackage;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->getAdRevenueParameters(Lcom/adjust/sdk/AdjustAdRevenue;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->AD_REVENUE:Lcom/adjust/sdk/ActivityKind;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p0, v1}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v3, "/reaeedsqvn"

    const-string v3, "eds/neva_re"

    const/4 v7, 0x5

    const-string v3, "/asere_neud"

    const-string v3, "/ad_revenue"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v5, v4, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v4, v4, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {v0, v1, v3, v5, v4}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2, v0}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object p2, p1, Lcom/adjust/sdk/AdjustAdRevenue;->callbackParameters:Ljava/util/Map;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2, p2}, Lcom/adjust/sdk/ActivityPackage;->setCallbackParameters(Ljava/util/Map;)V

    const/4 v7, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustAdRevenue;->partnerParameters:Ljava/util/Map;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2, p1}, Lcom/adjust/sdk/ActivityPackage;->setPartnerParameters(Ljava/util/Map;)V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-object v2
.end method

.method public buildAdRevenuePackage(Ljava/lang/String;Lorg/json/JSONObject;)Lcom/adjust/sdk/ActivityPackage;
    .locals 6

    const/4 v5, 0x4

    invoke-direct {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->getAdRevenueParameters(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/util/Map;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object p2, Lcom/adjust/sdk/ActivityKind;->AD_REVENUE:Lcom/adjust/sdk/ActivityKind;

    invoke-direct {p0, p2}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "u_emv/ranee"

    const-string/jumbo v1, "verm_ue/aen"

    const-string/jumbo v1, "vdueoera_ne"

    const-string v1, "/ad_revenue"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v3, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1, p2, v1, v3, v2}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object v0
.end method

.method public buildAttributionPackage(Ljava/lang/String;)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getAttributionParameters(Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->ATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v2, "nttaobruoit"

    const-string/jumbo v2, "iaiuorttnto"

    const/4 v6, 0x7

    const-string/jumbo v2, "uirottuntab"

    const-string v2, "attribution"

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x1

    const-string v2, ""

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object v1
.end method

.method public buildClickPackage(Ljava/lang/String;)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getClickParameters(Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->CLICK:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v2, "/sdk_click"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInMilliseconds:J

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setClickTimeInMilliseconds(J)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeInSeconds:J

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setClickTimeInSeconds(J)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeInSeconds:J

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setInstallBeginTimeInSeconds(J)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->clickTimeServerInSeconds:J

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setClickTimeServerInSeconds(J)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-wide v2, p0, Lcom/adjust/sdk/PackageBuilder;->installBeginTimeServerInSeconds:J

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setInstallBeginTimeServerInSeconds(J)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->installVersion:Ljava/lang/String;

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setInstallVersion(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setGooglePlayInstant(Ljava/lang/Boolean;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object v1
.end method

.method public buildDisableThirdPartySharingPackage()Lcom/adjust/sdk/ActivityPackage;
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/adjust/sdk/PackageBuilder;->getDisableThirdPartySharingParameters()Ljava/util/Map;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->DISABLE_THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0, v1}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v3, "b_had_/psaerrinit_thpsgldryi"

    const-string/jumbo v3, "s_yriblh_tani/pardtgirdsaeh_"

    const/4 v7, 0x5

    const-string v3, "b_iseprhqtrdhriailadg_/at_ns"

    const-string v3, "/disable_third_party_sharing"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v5, v4, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v4, v4, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v0, v1, v3, v5, v4}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, v0}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-object v2
.end method

.method public buildEventPackage(Lcom/adjust/sdk/AdjustEvent;Z)Lcom/adjust/sdk/ActivityPackage;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->getEventParameters(Lcom/adjust/sdk/AdjustEvent;Z)Ljava/util/Map;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->EVENT:Lcom/adjust/sdk/ActivityKind;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p0, v1}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v3, "ees/vt"

    const-string/jumbo v3, "uv/eet"

    const/4 v7, 0x5

    const-string v3, "entmv/"

    const-string v3, "/event"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getEventSuffix(Lcom/adjust/sdk/AdjustEvent;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v5, v4, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v4, v4, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v1, v3, v5, v4}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {v2, v0}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz p2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object p2, p1, Lcom/adjust/sdk/AdjustEvent;->callbackParameters:Ljava/util/Map;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2, p2}, Lcom/adjust/sdk/ActivityPackage;->setCallbackParameters(Ljava/util/Map;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/AdjustEvent;->partnerParameters:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2, p1}, Lcom/adjust/sdk/ActivityPackage;->setPartnerParameters(Ljava/util/Map;)V

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v2
.end method

.method public buildGdprPackage()Lcom/adjust/sdk/ActivityPackage;
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/adjust/sdk/PackageBuilder;->getGdprParameters()Ljava/util/Map;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-direct {p0, v1}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v3, "e/otoip_ee_gpdrcfgd"

    const-string v3, "dfroietp_ee/cv_dgpg"

    const-string v3, "eipgebce_odfv_t/gdr"

    const-string v3, "/gdpr_forget_device"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v7, 0x1

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v5, v4, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v4, v4, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1, v3, v5, v4}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v2, v0}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-object v2
.end method

.method public buildInfoPackage(Ljava/lang/String;)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getInfoParameters(Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->INFO:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo v2, "qds_ofuk/"

    const-string/jumbo v2, "kod/isf_q"

    const/4 v6, 0x2

    const-string/jumbo v2, "sf_kdnip/"

    const-string v2, "/sdk_info"

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x0

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-object v1
.end method

.method public buildMeasurementConsentPackage(Z)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getMeasurementConsentParameters(Z)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->MEASUREMENT_CONSENT:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "e_ns/enuqtcasememsnr"

    const-string v2, "ersestenscuatnnem_/m"

    const/4 v6, 0x4

    const-string/jumbo v2, "sesmrsaeenun/_etotnc"

    const-string v2, "/measurement_consent"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, ""

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v1
.end method

.method public buildSessionPackage(Z)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getSessionParameters(Z)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->SESSION:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "snimso/m"

    const-string/jumbo v2, "oiemsns/"

    const/4 v6, 0x4

    const-string/jumbo v2, "oesno/ss"

    const-string v2, "/session"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, ""

    const/4 v6, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x4

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-object v1
.end method

.method public buildSubscriptionPackage(Lcom/adjust/sdk/AdjustPlayStoreSubscription;Z)Lcom/adjust/sdk/ActivityPackage;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p0, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->getSubscriptionParameters(Lcom/adjust/sdk/AdjustPlayStoreSubscription;Z)Ljava/util/Map;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object p2, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {p0, p2}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v1, "hc/u2bao/ers"

    const-string v1, "2/aeorhs/pcu"

    const/4 v5, 0x0

    const-string v1, "/v2/purchase"

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v3, v2, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, v2, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, p2, v1, v3, v2}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object v0
.end method

.method public buildThirdPartySharingPackage(Lcom/adjust/sdk/AdjustThirdPartySharing;)Lcom/adjust/sdk/ActivityPackage;
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p0, p1}, Lcom/adjust/sdk/PackageBuilder;->getThirdPartySharingParameters(Lcom/adjust/sdk/AdjustThirdPartySharing;)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->getDefaultActivityPackage(Lcom/adjust/sdk/ActivityKind;)Lcom/adjust/sdk/ActivityPackage;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string/jumbo v2, "iahrtb_shi_pdntrayr/"

    const/4 v6, 0x7

    const-string/jumbo v2, "ys_iiputadr_rh/rhgtn"

    const-string v2, "/third_party_sharing"

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setPath(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x0

    const-string v2, ""

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Lcom/adjust/sdk/ActivityPackage;->setSuffix(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v4, v3, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v3, v3, Lcom/adjust/sdk/AdjustConfig;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x0

    invoke-static {p1, v0, v2, v4, v3}, Lcom/adjust/sdk/AdjustSigner;->sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Lcom/adjust/sdk/ActivityPackage;->setParameters(Ljava/util/Map;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object v1
.end method

.method public getEventParameters(Lcom/adjust/sdk/AdjustEvent;Z)Ljava/util/Map;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/AdjustEvent;",
            "Z)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getImeiParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_0
    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget-object v2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->getOaidParameters(Lcom/adjust/sdk/AdjustConfig;Lcom/adjust/sdk/ILogger;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p2, :cond_2

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->callbackParameters:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p1, Lcom/adjust/sdk/AdjustEvent;->callbackParameters:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v2, "lckbaulp"

    const-string v2, "caCblluk"

    const/4 v5, 0x2

    const-string/jumbo v2, "qkcaClal"

    const-string v2, "Callback"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const-string v1, "cbsalmaks_aacpl"

    const-string v1, "almlkaap_pacscb"

    const/4 v5, 0x4

    const-string/jumbo v1, "kcpmlsa_laaramc"

    const-string v1, "callback_params"

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->sessionParameters:Lcom/adjust/sdk/SessionParameters;

    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/SessionParameters;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p1, Lcom/adjust/sdk/AdjustEvent;->partnerParameters:Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v2, "artroen"

    const-string v2, "Partner"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p2, v1, v2}, Lcom/adjust/sdk/Util;->mergeParameters(Ljava/util/Map;Ljava/util/Map;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v1, "tsmnabaeqppr_r"

    const-string/jumbo v1, "nmaspaprqaret_"

    const/4 v5, 0x2

    const-string v1, "amsrrtupra_pna"

    const-string/jumbo v1, "partner_params"

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addMapJson(Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p2, v1}, Lcom/adjust/sdk/a;->b(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->g:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "_ddiinopruas"

    const-string/jumbo v1, "oasidnri_udd"

    const/4 v5, 0x5

    const-string/jumbo v1, "n_idddouqrai"

    const-string v1, "android_uuid"

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const-string/jumbo v1, "pgssd_id"

    const-string v1, "gipmsd_d"

    const-string v1, "_samdipg"

    const-string v1, "gps_adid"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget p2, p2, Lcom/adjust/sdk/a;->c:I

    const/4 v4, 0x2

    move v5, v4

    int-to-long v1, p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string p2, "_os_omapiddttpte"

    const-string/jumbo p2, "tppeod_aitmd_sgt"

    const/4 v5, 0x0

    const-string/jumbo p2, "paia_bspedtmtgdt"

    const-string p2, "gps_adid_attempt"

    invoke-static {v0, p2, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object p2, p2, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v1, "disr__usbgca"

    const-string v1, "dsridbas_c_g"

    const/4 v5, 0x3

    const-string/jumbo v1, "srigdspp_cda"

    const-string v1, "gps_adid_src"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "gi_lbtadqekenuac"

    const-string v1, "etdlarungkabe_ic"

    const/4 v5, 0x3

    const-string/jumbo v1, "tracking_enabled"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    invoke-static {p2}, Lcom/adjust/sdk/Util;->getFireAdvertisingId(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, "aiseidprf"

    const-string/jumbo v1, "ra_feidpi"

    const/4 v5, 0x3

    const-string v1, "aiimdf_dr"

    const-string v1, "fire_adid"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p2}, Lcom/adjust/sdk/Util;->getFireTrackingEnabled(Lcom/adjust/sdk/AdjustConfig;)Ljava/lang/Boolean;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v1, "cedrogkiaaieet__nnqlf"

    const-string/jumbo v1, "regiak_tqefni_raeldnc"

    const/4 v5, 0x7

    const-string/jumbo v1, "ilcfgbken_rrdeeb_ntai"

    const-string v1, "fire_tracking_enabled"

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsPlayIds(Ljava/util/Map;)Z

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez p2, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->containsFireIds(Ljava/util/Map;)Z

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez p2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object p2, Lcom/adjust/sdk/PackageBuilder;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v2, "ewreD uGtr enodvslla iea dkc rtt ellni dA elr  i fnacA,eoPleDog too odI gessoGn ddpe iirlIerytigbeinof iniv acstkelFnaFaitt"

    const-string/jumbo v2, "tAs eifor  Ik iat lnnresD a ggoDGoodlfkI etdld  oitcvneprsol ,tFeest iletir aiiilcd rcPergin Ae aboFeaydeGlonet di l navnwe"

    const/4 v5, 0x5

    const-string/jumbo v2, "lecegddpctliA nakraitoeGnI F   nndv get itiieolss y PItpF dtgae ririwereik ctglvroeodst lneloieefbaG d n l nD,ilaoao feorD "

    const-string v2, "Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place"

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {p2, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p2, v1}, Lcom/adjust/sdk/a;->a(Lcom/adjust/sdk/AdjustConfig;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "_maonddiqr"

    const-string v1, "drdmaoid_n"

    const/4 v5, 0x3

    const-string v1, "disind_dro"

    const-string v1, "android_id"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v1, "_iomlveel"

    const-string/jumbo v1, "pe_eoilvl"

    const/4 v5, 0x2

    const-string v1, "apllov_ie"

    const-string v1, "api_level"

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appSecret:Ljava/lang/String;

    const/4 v4, 0x5

    move v5, v4

    const-string v1, "eabepbp_cs"

    const-string v1, "cesrabep_p"

    const/4 v5, 0x7

    const-string/jumbo v1, "ste_cpurea"

    const-string v1, "app_secret"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/AdjustConfig;->appToken:Ljava/lang/String;

    const/4 v5, 0x6

    const-string/jumbo v1, "oeu_kpppt"

    const-string v1, "etpp_kuoa"

    const/4 v5, 0x0

    const-string/jumbo v1, "tknaop_pq"

    const-string v1, "app_token"

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p2, p2, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x2

    const-string v1, "aesp_psoirn"

    const-string v1, "app_version"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "loemn_upndeitptkarii"

    const-string/jumbo v1, "t_eniruptteopnialdik"

    const/4 v5, 0x3

    const-string/jumbo v1, "tendotiibauktl_enipr"

    const-string v1, "attribution_deeplink"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getConnectivityType(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    int-to-long v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v3, "tycc_nipqveteniot"

    const-string v3, "connectivity_type"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v5, 0x0

    const-string/jumbo v2, "rctnubo"

    const-string/jumbo v2, "ousrctn"

    const/4 v5, 0x2

    const-string/jumbo v2, "ncuoyru"

    const-string v2, "country"

    const/4 v4, 0x4

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "ct_emypp"

    const-string/jumbo v2, "ytpmecp_"

    const/4 v5, 0x6

    const-string/jumbo v2, "qptyeup_"

    const-string v2, "cpu_type"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-wide v1, p0, Lcom/adjust/sdk/PackageBuilder;->createdAt:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v3, "_taaotrdee"

    const/4 v5, 0x0

    const-string v3, "ersdca_ate"

    const-string v3, "created_at"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addDateInMilliseconds(Ljava/util/Map;Ljava/lang/String;J)V

    iget-object v1, p1, Lcom/adjust/sdk/AdjustEvent;->currency:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "enbmcryu"

    const-string/jumbo v2, "urnecbyc"

    const/4 v5, 0x7

    const-string v2, "ccyuorne"

    const-string v2, "currency"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->deviceKnown:Ljava/lang/Boolean;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string/jumbo v2, "nedk_bcivuew"

    const-string/jumbo v2, "oikn_eudwvec"

    const/4 v5, 0x5

    const-string v2, "cni_ewudovne"

    const-string v2, "device_known"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->needsCost:Ljava/lang/Boolean;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v2, "netesocp_s"

    const-string v2, "_nscotepse"

    const/4 v5, 0x5

    const-string/jumbo v2, "tsecondsq_"

    const-string/jumbo v2, "needs_cost"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, v1, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v2, "ntarmfc_qcuieereuva"

    const/4 v5, 0x0

    const-string v2, "device_manufacturer"

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, "eisvmed_asc"

    const-string v2, "des_vaemcei"

    const/4 v5, 0x2

    const-string v2, "diamece_nmv"

    const-string v2, "device_name"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v2, "dymeopitevc"

    const-string v2, "edtmicyevpe"

    const/4 v5, 0x6

    const-string/jumbo v2, "tyciebdevp_"

    const-string v2, "device_type"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v1, v1, Lcom/adjust/sdk/a;->C:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    int-to-long v1, v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v3, "im_oeuu"

    const-string v3, "_dmioue"

    const/4 v5, 0x7

    const-string/jumbo v3, "poiedum"

    const-string/jumbo v3, "ui_mode"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v2, "d_siigeyqlhahp"

    const-string v2, "_hysibepldiagh"

    const/4 v5, 0x7

    const-string/jumbo v2, "phs_aiytshglei"

    const-string v2, "display_height"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v2, "itsmhdulaiy_p"

    const-string/jumbo v2, "tisawlui_dhyp"

    const/4 v5, 0x4

    const-string v2, "_hdaopslitywd"

    const-string v2, "display_width"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->environment:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v2, "inenmbotven"

    const-string v2, "enmnvotpine"

    const/4 v5, 0x7

    const-string/jumbo v2, "rnmnteunovi"

    const-string v2, "environment"

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p1, Lcom/adjust/sdk/AdjustEvent;->callbackId:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v2, "_blldtnpvc_qeekai"

    const-string/jumbo v2, "n_bekcllqicadevt_"

    const/4 v5, 0x6

    const-string v2, "etnleackqd_bvi_cl"

    const-string v2, "event_callback_id"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget v1, v1, Lcom/adjust/sdk/PackageBuilder$a;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    int-to-long v1, v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v3, "usste_cnten"

    const-string/jumbo v3, "nesectoun_t"

    const/4 v5, 0x3

    const-string/jumbo v3, "notmt_ecevn"

    const-string v3, "event_count"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v3, v1, v2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-boolean v1, v1, Lcom/adjust/sdk/AdjustConfig;->eventBufferingEnabled:Z

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v2, "fb_ioeevlmbfdreeaten_un"

    const-string v2, "ebnmeatfd_unevgerbef_il"

    const/4 v5, 0x0

    const-string/jumbo v2, "lbieebfue_fn_vardgeebtn"

    const-string v2, "event_buffering_enabled"

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v1, p1, Lcom/adjust/sdk/AdjustEvent;->eventToken:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string v2, "eteetkun_on"

    const-string v2, "event_token"

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->externalDeviceId:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "inedovtpxlr_ceeae_"

    const-string/jumbo v2, "r_dtoeicnal_xvieee"

    const/4 v5, 0x3

    const-string v2, "elxrivdeq_caeint_d"

    const-string v2, "external_device_id"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, "disfb"

    const-string v2, "bfdbi"

    const/4 v5, 0x1

    const-string v2, "fb_id"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "neam_dmaweurh"

    const-string v2, "hwaa_rueenmda"

    const/4 v5, 0x2

    const-string v2, "_nreoerawdhma"

    const-string v2, "hardware_name"

    const/4 v4, 0x0

    move v5, v4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    iget-object v1, v1, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const-string v2, "anegubag"

    const-string v2, "aeggnuap"

    const-string/jumbo v2, "lauangue"

    const-string/jumbo v2, "language"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMcc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "mcc"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x6

    const-string v2, "ccm"

    const-string/jumbo v2, "mcc"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getMnc(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo v2, "ncm"

    const-string/jumbo v2, "mnc"

    const/4 v5, 0x3

    const-string/jumbo v2, "nmc"

    const-string/jumbo v2, "mnc"

    const/4 v5, 0x4

    invoke-static {v0, v2, v1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v1, "eoeeq_lp_dtaensdsnpris"

    const-string v1, "dersa_eeqinn_sdeoslpst"

    const/4 v5, 0x6

    const-string/jumbo v1, "needs_response_details"

    const/4 v5, 0x1

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addBoolean(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v4, 0x4

    move v5, v4

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p2, p2, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v1, "qslid_uo"

    const-string v1, "dosiul_s"

    const/4 v5, 0x7

    const-string/jumbo v1, "ids_bsul"

    const-string/jumbo v1, "os_build"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x1

    iget-object p2, p2, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo v1, "osem_mn"

    const/4 v5, 0x1

    const-string/jumbo v1, "os_name"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p2, p2, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "e_omsrviso"

    const-string/jumbo v1, "se_ooviros"

    const/4 v5, 0x7

    const-string/jumbo v1, "invoosers_"

    const-string/jumbo v1, "os_version"

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "kgamebnepaca"

    const-string v1, "cpenabemagak"

    const-string v1, "aamepeun_akg"

    const-string/jumbo v1, "package_name"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p2, Lcom/adjust/sdk/PackageBuilder$a;->h:Ljava/lang/String;

    const/4 v5, 0x2

    const-string v1, "hunouspp_t"

    const-string/jumbo v1, "t_osneuhpu"

    const/4 v5, 0x4

    const-string v1, "_utkhsnpqo"

    const-string/jumbo v1, "push_token"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p2, p1, Lcom/adjust/sdk/AdjustEvent;->revenue:Ljava/lang/Double;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "prsveeu"

    const-string/jumbo v1, "prneuve"

    const-string/jumbo v1, "veumern"

    const-string/jumbo v1, "revenue"

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDouble(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Double;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/AdjustEvent;->orderId:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo p2, "iqapoonuldcdieid"

    const-string p2, "doduilanqiicdep_"

    const/4 v5, 0x6

    const-string/jumbo p2, "peauibiltdddcno_"

    const-string p2, "deduplication_id"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo p2, "ssscnderyete_i"

    const-string/jumbo p2, "nescn_udeityrs"

    const-string/jumbo p2, "screen_density"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p2, "arrsoecp_etmm"

    const-string p2, "eafms_rcoterm"

    const/4 v5, 0x2

    const-string/jumbo p2, "rmae_teoqcrsf"

    const-string/jumbo p2, "screen_format"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->deviceInfo:Lcom/adjust/sdk/a;

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p2, "eeszrci_nso"

    const-string/jumbo p2, "seceo_nzeir"

    const/4 v5, 0x3

    const-string/jumbo p2, "renmcszee_i"

    const-string/jumbo p2, "screen_size"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->adjustConfig:Lcom/adjust/sdk/AdjustConfig;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->secretId:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo p2, "its_obece"

    const-string p2, "ditcsbe_e"

    const/4 v5, 0x6

    const-string/jumbo p2, "serctbie_"

    const-string/jumbo p2, "secret_id"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, p2, p1}, Lcom/adjust/sdk/PackageBuilder;->addString(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    int-to-long p1, p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "usseoiuus_ncn"

    const-string/jumbo v1, "iusno_uncoses"

    const/4 v5, 0x4

    const-string/jumbo v1, "osonntspucie_"

    const-string/jumbo v1, "session_count"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->f:J

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v1, "egtinsshqsenpl"

    const-string/jumbo v1, "nssliheptoseng"

    const/4 v5, 0x0

    const-string/jumbo v1, "oisegltsssnn_e"

    const-string/jumbo v1, "session_length"

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v4, 0x1

    and-int/2addr v5, v4

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->c:I

    const/4 v4, 0x2

    move v5, v4

    int-to-long p1, p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "susmonoicequ_bts"

    const-string v1, "eosbssonquicus_t"

    const/4 v5, 0x4

    const-string/jumbo v1, "soiuotnuo_snssbc"

    const-string/jumbo v1, "subsession_count"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addLong(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/PackageBuilder;->activityStateCopy:Lcom/adjust/sdk/PackageBuilder$a;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-wide p1, p1, Lcom/adjust/sdk/PackageBuilder$a;->d:J

    const/4 v5, 0x4

    const-string/jumbo v1, "ietesbtnsm"

    const-string/jumbo v1, "ttsiesn_em"

    const/4 v5, 0x3

    const-string v1, "ep_metutin"

    const-string/jumbo v1, "time_spent"

    const/4 v5, 0x2

    invoke-static {v0, v1, p1, p2}, Lcom/adjust/sdk/PackageBuilder;->addDuration(Ljava/util/Map;Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->injectFeatureFlagsWithParameters(Ljava/util/Map;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/PackageBuilder;->checkDeviceIds(Ljava/util/Map;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object v0
.end method
