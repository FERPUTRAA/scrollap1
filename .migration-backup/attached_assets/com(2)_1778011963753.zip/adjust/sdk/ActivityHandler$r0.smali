.class public final Lcom/adjust/sdk/ActivityHandler$r0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->setOfflineMode(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$r0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-boolean p2, p0, Lcom/adjust/sdk/ActivityHandler$r0;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s~b@~Mocvf/bf~i@@~@o~~@ @~~  @~o  ~@K~@@@@ /n4i doa@~@~r@b s om  t~~y.  @-~ ~@ ~ou~~~S~ l@@1lt"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$r0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-boolean v1, p0, Lcom/adjust/sdk/ActivityHandler$r0;->a:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/adjust/sdk/ActivityHandler;->access$1200(Lcom/adjust/sdk/ActivityHandler;Z)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method
