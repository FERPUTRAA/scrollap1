.class public final Lcom/adjust/sdk/ActivityHandler$b0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->initI()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$b0;->a:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " /s@v~b1~m@~@ ~i@ @ib~o~oof @s~o@~ ~@ f~~@S~~~ ~@@@ o@y. c @@@ u@t~@~ ~~-aMl4~/tn K~@or@ ilb ~d "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$b0;->a:Lcom/adjust/sdk/ActivityHandler;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityHandler;->foregroundTimerFired()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method
