.class public final Lcom/adjust/sdk/SdkClickHandler$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/SdkClickHandler;->sendSdkClick(Lcom/adjust/sdk/ActivityPackage;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/ActivityPackage;

.field public final synthetic b:Lcom/adjust/sdk/SdkClickHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/SdkClickHandler;Lcom/adjust/sdk/ActivityPackage;)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    iput-object p1, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/adjust/sdk/SdkClickHandler$a;->a:Lcom/adjust/sdk/ActivityPackage;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@s biu~~o~@   /vl @@s @~mf~cl@@ y@~~n~i~~o@o~ Kdo~o@t~4-@~~@ b~S~@@@ i @~1far~b~ o  @/t@~@   .@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/SdkClickHandler;->access$000(Lcom/adjust/sdk/SdkClickHandler;)Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/SdkClickHandler$a;->a:Lcom/adjust/sdk/ActivityPackage;

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/SdkClickHandler;->access$100(Lcom/adjust/sdk/SdkClickHandler;)Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v3}, Lcom/adjust/sdk/SdkClickHandler;->access$000(Lcom/adjust/sdk/SdkClickHandler;)Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    aput-object v3, v2, v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "ksimddldAcde dsc_ "

    const-string/jumbo v3, "l s_A didsdckdcde%"

    const/4 v6, 0x1

    const-string v3, "A c%ocikdd_dk dled"

    const-string v3, "Added sdk_click %d"

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-interface {v0, v3, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/adjust/sdk/SdkClickHandler;->access$100(Lcom/adjust/sdk/SdkClickHandler;)Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/SdkClickHandler$a;->a:Lcom/adjust/sdk/ActivityPackage;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/adjust/sdk/ActivityPackage;->getExtendedString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    aput-object v2, v1, v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "s%"

    const-string/jumbo v2, "s%"

    const/4 v6, 0x0

    const-string/jumbo v2, "s%"

    const-string v2, "%s"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$a;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/adjust/sdk/SdkClickHandler;->access$200(Lcom/adjust/sdk/SdkClickHandler;)V

    const/4 v5, 0x6

    or-int/2addr v6, v5

    return-void
.end method
