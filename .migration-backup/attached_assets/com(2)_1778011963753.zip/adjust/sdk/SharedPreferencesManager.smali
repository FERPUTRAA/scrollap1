.class public Lcom/adjust/sdk/SharedPreferencesManager;
.super Ljava/lang/Object;


# static fields
.field private static final INDEX_CLICK_TIME:I = 0x1

.field private static final INDEX_IS_SENDING:I = 0x2

.field private static final INDEX_RAW_REFERRER:I = 0x0

.field private static final PREFS_KEY_DEEPLINK_CLICK_TIME:Ljava/lang/String; = "deeplink_click_time"

.field private static final PREFS_KEY_DEEPLINK_URL:Ljava/lang/String; = "deeplink_url"

.field private static final PREFS_KEY_DISABLE_THIRD_PARTY_SHARING:Ljava/lang/String; = "disable_third_party_sharing"

.field private static final PREFS_KEY_GDPR_FORGET_ME:Ljava/lang/String; = "gdpr_forget_me"

.field private static final PREFS_KEY_INSTALL_TRACKED:Ljava/lang/String; = "install_tracked"

.field private static final PREFS_KEY_PREINSTALL_PAYLOAD_READ_STATUS:Ljava/lang/String; = "preinstall_payload_read_status"

.field private static final PREFS_KEY_PREINSTALL_SYSTEM_INSTALLER_REFERRER:Ljava/lang/String; = "preinstall_system_installer_referrer"

.field private static final PREFS_KEY_PUSH_TOKEN:Ljava/lang/String; = "push_token"

.field private static final PREFS_KEY_RAW_REFERRERS:Ljava/lang/String; = "raw_referrers"

.field private static final PREFS_NAME:Ljava/lang/String; = "adjust_preferences"

.field private static final REFERRERS_COUNT:I = 0xa

.field private static defaultInstance:Lcom/adjust/sdk/SharedPreferencesManager;

.field private static sharedPreferences:Landroid/content/SharedPreferences;

.field private static sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const-string v1, "e_sujestsfcendrear"

    const-string/jumbo v1, "rasdtenc_fsereejsu"

    const/4 v4, 0x1

    const-string/jumbo v1, "spjmesn_creuetfade"

    const-string v1, "adjust_preferences"

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-virtual {p1, v1, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    sput-object p1, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferences:Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    sput-object p1, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput-object p1, v2, v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string/jumbo p1, "reehoarefas cnPo CncdcntesorsteSma"

    const-string p1, "CnemhPs cnnfrectssoeaedacareo terS"

    const/4 v4, 0x0

    const-string p1, "frSnabeees daetenshscooetarc r Pnc"

    const-string p1, "Cannot access to SharedPreferences"

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v1, p1, v2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 p1, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    sput-object p1, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferences:Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    sput-object p1, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method private declared-synchronized getBoolean(Ljava/lang/String;Z)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@b~/ ~u@om~~~ @i~@@ fa ~~1@dtl y   @cb@f~iM~~i~ @@u ~s~S@@ bot~/r -  4lo@@ ~~v @o@o~@ ~n@@@~~o.~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferences:Landroid/content/SharedPreferences;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    :try_start_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1
    :try_end_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1

    :catch_0
    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p2

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p2

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    throw p1
.end method

.method public static declared-synchronized getDefaultInstance(Landroid/content/Context;)Lcom/adjust/sdk/SharedPreferencesManager;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-class v0, Lcom/adjust/sdk/SharedPreferencesManager;

    const-class v0, Lcom/adjust/sdk/SharedPreferencesManager;

    const/4 v3, 0x3

    const-class v0, Lcom/adjust/sdk/SharedPreferencesManager;

    const-class v0, Lcom/adjust/sdk/SharedPreferencesManager;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v1, Lcom/adjust/sdk/SharedPreferencesManager;->defaultInstance:Lcom/adjust/sdk/SharedPreferencesManager;

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/adjust/sdk/SharedPreferencesManager;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/adjust/sdk/SharedPreferencesManager;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    sput-object v1, Lcom/adjust/sdk/SharedPreferencesManager;->defaultInstance:Lcom/adjust/sdk/SharedPreferencesManager;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object p0, Lcom/adjust/sdk/SharedPreferencesManager;->defaultInstance:Lcom/adjust/sdk/SharedPreferencesManager;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method

.method private declared-synchronized getLong(Ljava/lang/String;J)J
    .locals 3

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferences:Landroid/content/SharedPreferences;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    :try_start_1
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide p1
    :try_end_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-wide p1

    :catch_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-wide p2

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-wide p2

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p1
.end method

.method private declared-synchronized getRawReferrerIndex(Ljava/lang/String;J)I
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerArray()Lorg/json/JSONArray;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    move v2, v1

    move v2, v1

    const/4 v8, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v7, 0x3

    move v8, v7

    if-ge v2, v3, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v1, v4}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v4, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-nez v4, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    goto :goto_1

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v8, 0x6

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v6, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v3, v6, v4, v5}, Lorg/json/JSONArray;->optLong(IJ)J

    move-result-wide v3
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    cmp-long v3, v3, p2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v3, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    monitor-exit p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    return v2

    :cond_2
    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    monitor-exit p0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    throw p1

    :catch_0
    :cond_3
    const/4 v8, 0x5

    monitor-exit p0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 p1, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    return p1
.end method

.method private declared-synchronized getString(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferences:Landroid/content/SharedPreferences;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :catchall_0
    :try_start_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v0, "rsrewrfpraeer"

    const-string/jumbo v0, "raw_referrers"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    and-int/2addr v3, v2

    const-string p1, "er_waserqfrer"

    const-string/jumbo p1, "raw_referrers"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v1

    :catch_0
    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v1

    :catchall_1
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x5

    throw p1
.end method

.method private declared-synchronized remove(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    throw p1
.end method

.method private declared-synchronized saveBoolean(Ljava/lang/String;Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    monitor-exit p0

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p1
.end method

.method private declared-synchronized saveInteger(Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw p1
.end method

.method private declared-synchronized saveLong(Ljava/lang/String;J)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x6

    throw p1
.end method

.method private declared-synchronized saveString(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x3

    move v2, v1

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v1, 0x7

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1
.end method


# virtual methods
.method public declared-synchronized clear()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/adjust/sdk/SharedPreferencesManager;->sharedPreferencesEditor:Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x3

    throw v0
.end method

.method public declared-synchronized getDeeplinkClickTime()J
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, "edstekeinkoc_pliic_"

    const-string v0, "_eiiomkenpkcletcdi_"

    const/4 v4, 0x7

    const-string v0, "eenmcep_klklimcit_i"

    const-string v0, "deeplink_click_time"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x2

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0, v0, v1, v2}, Lcom/adjust/sdk/SharedPreferencesManager;->getLong(Ljava/lang/String;J)J

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x4

    return-wide v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw v0
.end method

.method public declared-synchronized getDeeplinkUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const-string/jumbo v0, "l_neordipeub"

    const-string/jumbo v0, "pn_edbullire"

    const/4 v2, 0x3

    const-string/jumbo v0, "plrukbine_dl"

    const-string v0, "deeplink_url"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw v0
.end method

.method public declared-synchronized getDisableThirdPartySharing()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v0, "sbsuituidaelr_aprhgry_i_dha"

    const-string v0, "dtaah_ug_y_rrhilepsribsdtai"

    const/4 v3, 0x2

    const-string v0, "edhatsrpai__ygbitlrnr_pdasi"

    const-string v0, "disable_third_party_sharing"

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x5

    return v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    throw v0
.end method

.method public declared-synchronized getGdprForgetMe()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v0, "pdr_feotqgger_"

    const-string v0, "gotrpr_pdeg_ef"

    const/4 v3, 0x1

    const-string v0, "dgstp_fgrrm_eo"

    const-string v0, "gdpr_forget_me"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    throw v0
.end method

.method public declared-synchronized getInstallTracked()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v0, "lqsmeian_ktcatl"

    const-string v0, "are_ntalqksctli"

    const/4 v3, 0x4

    const-string v0, "adiroseltkl_atn"

    const-string/jumbo v0, "install_tracked"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x5

    return v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw v0
.end method

.method public declared-synchronized getPreinstallPayloadReadStatus()J
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "daetsbiaunalpaoytssd_ls_re_tar"

    const-string v0, "_pstayuleistael_lrdaatosrsnd_a"

    const/4 v4, 0x7

    const-string v0, "es_ttauuyodstdinrlasppla_lre_a"

    const-string/jumbo v0, "preinstall_payload_read_status"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    invoke-direct {p0, v0, v1, v2}, Lcom/adjust/sdk/SharedPreferencesManager;->getLong(Ljava/lang/String;J)J

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-wide v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw v0
.end method

.method public declared-synchronized getPreinstallReferrer()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const-string/jumbo v0, "rsmpielplslrnteeit_r_e_rrralsatfnesm"

    const-string v0, "errmprsel__lalenrileysr_estmfrasttin"

    const/4 v2, 0x4

    const-string v0, "alarltsiq_tmeelre_nsperflrntrsirseye"

    const-string/jumbo v0, "preinstall_system_installer_referrer"

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized getPushToken()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "kss_nuotep"

    const-string/jumbo v0, "push_token"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x2

    throw v0
.end method

.method public declared-synchronized getRawReferrer(Ljava/lang/String;J)Lorg/json/JSONArray;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerIndex(Ljava/lang/String;J)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-ltz p1, :cond_0

    :try_start_1
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerArray()Lorg/json/JSONArray;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object p1
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v0, 0x5

    const/4 v0, 0x0

    monitor-exit p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1

    :catch_0
    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    monitor-exit p0

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v0, 0x3

    move v1, v0

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    monitor-exit p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    throw p1
.end method

.method public declared-synchronized getRawReferrerArray()Lorg/json/JSONArray;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x6

    const-string/jumbo v0, "rermawrsefoe_"

    const-string/jumbo v0, "raerosefr_ewr"

    const/4 v6, 0x7

    const-string v0, "fwrro_srearee"

    const-string/jumbo v0, "raw_referrers"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v0, :cond_2

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v1, Lorg/json/JSONArray;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v1, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/16 v3, 0xa

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-le v2, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v0, Lorg/json/JSONArray;

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ge v2, v3, :cond_0

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->saveRawReferrerArray(Lorg/json/JSONArray;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-exit p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object v0

    :cond_1
    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x0

    new-instance v1, Lorg/json/JSONArray;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v1, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x2

    monitor-exit p0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object v1

    :catch_0
    :catchall_0
    :cond_2
    :try_start_3
    const/4 v6, 0x4

    const/4 v5, 0x4

    new-instance v0, Lorg/json/JSONArray;

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    monitor-exit p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v0

    :catchall_1
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    monitor-exit p0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    throw v0
.end method

.method public declared-synchronized removeDeeplink()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo v0, "rnk_pbldlebu"

    const-string/jumbo v0, "ldnukbrl_eep"

    const/4 v2, 0x4

    const-string/jumbo v0, "ldkleiu_eunr"

    const-string v0, "deeplink_url"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "etkdenipcc_elpmkuii"

    const-string/jumbo v0, "ieneklu__imkccdptei"

    const/4 v2, 0x6

    const-string v0, "_llpinkmqcdk_ctieie"

    const-string v0, "deeplink_click_time"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    throw v0
.end method

.method public declared-synchronized removeDisableThirdPartySharing()V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "h_g_ydsparrahld_nesiipattbi"

    const/4 v2, 0x3

    const-string/jumbo v0, "ihsrhadari_i_dlta_stnebyrpg"

    const-string v0, "disable_third_party_sharing"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    move v2, v1

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw v0
.end method

.method public declared-synchronized removeGdprForgetMe()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "deompre_mrgtfq"

    const-string/jumbo v0, "r_fotgeeqpmdr_"

    const/4 v2, 0x0

    const-string/jumbo v0, "p_reoeggmfo_dt"

    const-string v0, "gdpr_forget_me"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    throw v0
.end method

.method public declared-synchronized removePreinstallReferrer()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    monitor-enter p0

    :try_start_0
    const-string/jumbo v0, "tlrptbflrra_rmrlsseeyelsesnaisieetrn"

    const-string/jumbo v0, "lrsnsftlirse_lareea_ritsmrenpyltseer"

    const/4 v2, 0x0

    const-string v0, "_tltmsul_enlaersrerflprteienr_iesrys"

    const-string/jumbo v0, "preinstall_system_installer_referrer"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw v0
.end method

.method public declared-synchronized removePushToken()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "_muonshpet"

    const-string v0, "_nemhtouks"

    const/4 v2, 0x0

    const-string v0, "hpkt_oesqn"

    const-string/jumbo v0, "push_token"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw v0
.end method

.method public declared-synchronized removeRawReferrer(Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-enter p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto/16 :goto_2

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, p1, p2, p3}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerIndex(Ljava/lang/String;J)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-gez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    return-void

    :cond_1
    :try_start_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerArray()Lorg/json/JSONArray;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p3, Lorg/json/JSONArray;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p3}, Lorg/json/JSONArray;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ge v0, v1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v0, p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    :try_start_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catch_0
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_3
    :try_start_3
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p3}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string p2, "ers_rresrfaer"

    const-string/jumbo p2, "reeroer_rasfr"

    const/4 v3, 0x3

    const-string/jumbo p2, "rremeerarrwsf"

    const-string/jumbo p2, "raw_referrers"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, p2, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw p1

    :cond_4
    :goto_2
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public declared-synchronized saveDeeplink(Landroid/net/Uri;J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-enter p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "ielporndk_ub"

    const-string/jumbo v0, "pln_kbdureil"

    const/4 v2, 0x4

    const-string/jumbo v0, "prleibl_kdun"

    const-string v0, "deeplink_url"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    move v2, v1

    const-string/jumbo p1, "ikiltkuud_mcliceee_"

    const-string/jumbo p1, "icpickue_tml_ildeek"

    const/4 v2, 0x4

    const-string p1, "eeilpkmpekndc_ci_il"

    const-string p1, "deeplink_click_time"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, p3}, Lcom/adjust/sdk/SharedPreferencesManager;->saveLong(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method public declared-synchronized savePreinstallReferrer(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const-string v0, "_rl_iystqeimr_senaettrsnfpelrlrlpsea"

    const-string/jumbo v0, "rtmilrapnpree_si_ylnrersflaelet_sest"

    const-string v0, "eesr_nrrallypss_reritsriet_sntmeafle"

    const-string/jumbo v0, "preinstall_system_installer_referrer"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw p1
.end method

.method public declared-synchronized savePushToken(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "qpnm_eshku"

    const-string/jumbo v0, "noehksp_qu"

    const/4 v2, 0x7

    const-string/jumbo v0, "s_ktopouhn"

    const-string/jumbo v0, "push_token"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p1
.end method

.method public declared-synchronized saveRawReferrer(Ljava/lang/String;J)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrer(Ljava/lang/String;J)Lorg/json/JSONArray;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerArray()Lorg/json/JSONArray;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/16 v2, 0xa

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_1
    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v1, Lorg/json/JSONArray;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONArray;->put(ILjava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 p1, 0x1

    invoke-virtual {v1, p1, p2, p3}, Lorg/json/JSONArray;->put(IJ)Lorg/json/JSONArray;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p1, v2}, Lorg/json/JSONArray;->put(II)Lorg/json/JSONArray;

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->saveRawReferrerArray(Lorg/json/JSONArray;)V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-exit p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p1

    :catch_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public declared-synchronized saveRawReferrerArray(Lorg/json/JSONArray;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "eesrrerf_rasr"

    const/4 v2, 0x6

    const-string v0, "errawbreefsrr"

    const-string/jumbo v0, "raw_referrers"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :catchall_0
    :try_start_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo p1, "srrmaeuwrrefe"

    const-string/jumbo p1, "wfrmereerrsar"

    const/4 v2, 0x6

    const-string/jumbo p1, "rwreferpa_rer"

    const-string/jumbo p1, "raw_referrers"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/adjust/sdk/SharedPreferencesManager;->remove(Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void

    :catchall_1
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method public declared-synchronized setDisableThirdPartySharing()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x6

    const-string v0, "aaoihda_qredt_htlgss_ybnpri"

    const-string v0, "dsiyorhablir_etgsrpdht_an_a"

    const/4 v3, 0x6

    const-string/jumbo v0, "n_slgibaayhtdsih_dsetrri_pa"

    const-string v0, "disable_third_party_sharing"

    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveBoolean(Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw v0
.end method

.method public declared-synchronized setGdprForgetMe()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v0, "g_tmrdgmrfb_po"

    const-string v0, "__rmtbdfoggrep"

    const-string v0, "_egfoero_dpgtr"

    const-string v0, "gdpr_forget_me"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveBoolean(Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw v0
.end method

.method public declared-synchronized setInstallTracked()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "crllabuikntstda"

    const-string/jumbo v0, "kdrtcnusatlial_"

    const/4 v3, 0x3

    const-string/jumbo v0, "k_tdanurlsieacl"

    const-string/jumbo v0, "install_tracked"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->saveBoolean(Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw v0
.end method

.method public declared-synchronized setPreinstallPayloadReadStatus(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "eilpatrpalnydosadsst_up_aatp_e"

    const-string v0, "aayoeliptnatstle_pa_srpa_udsld"

    const/4 v2, 0x7

    const-string v0, "a_dlalnoquasttel_sitasypra_rpd"

    const-string/jumbo v0, "preinstall_payload_read_status"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1, p2}, Lcom/adjust/sdk/SharedPreferencesManager;->saveLong(Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v1, 0x3

    move v2, v1

    throw p1
.end method

.method public declared-synchronized setSendingReferrersAsNotSent()V
    .locals 10

    const/4 v9, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/adjust/sdk/SharedPreferencesManager;->getRawReferrerArray()Lorg/json/JSONArray;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    move v2, v1

    move v2, v1

    const/4 v9, 0x2

    move v2, v1

    move v2, v1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    move v3, v2

    const/4 v9, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-ge v2, v4, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->getJSONArray(I)Lorg/json/JSONArray;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v5, -0x1

    const/4 v8, 0x0

    or-int/2addr v9, v8

    const/4 v6, 0x2

    move v9, v6

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONArray;->optInt(II)I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/4 v7, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-ne v5, v7, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v4, v6, v1}, Lorg/json/JSONArray;->put(II)Lorg/json/JSONArray;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    move v3, v7

    move v3, v7

    const/4 v9, 0x1

    move v3, v7

    move v3, v7

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_0

    :cond_1
    const/4 v9, 0x5

    if-eqz v3, :cond_2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p0, v0}, Lcom/adjust/sdk/SharedPreferencesManager;->saveRawReferrerArray(Lorg/json/JSONArray;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    monitor-exit p0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    throw v0

    :catch_0
    :cond_2
    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    monitor-exit p0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-void
.end method
