.class public final Lcom/adjust/sdk/ActivityHandler$p0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->trackEvent(Lcom/adjust/sdk/AdjustEvent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/AdjustEvent;

.field public final synthetic b:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/AdjustEvent;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$p0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v0, 0x7

    move v1, v0

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$p0;->a:Lcom/adjust/sdk/AdjustEvent;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "mfs~~o@ /@~ @@~4/o~@M~o~~~~1@s~@@r~@n  t~-i~iol@~u@  S ba@b @o  ~fi. y @b @~ cv~ t @@~@l o@@~Kd~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$p0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/adjust/sdk/ActivityHandler;->access$900(Lcom/adjust/sdk/ActivityHandler;)Lcom/adjust/sdk/ActivityHandler$InternalState;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityHandler$InternalState;->hasFirstSdkStartNotOcurred()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$p0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/ActivityHandler;->access$400(Lcom/adjust/sdk/ActivityHandler;)Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x3

    move v4, v3

    const-string v2, "i sfo ilar ors:k tltfpub fbpcgaonoh ce odmaren# crcrdtne o/eetjIe ttoietsairv sitrg/e/cim/ oopnelrehan ehlhvmp etesmaEniapti p-h eesoattdninn n-rsgvg ect -ao-ntdabt-nlescti-rlia..s e/  niintrtgcmP_eegkla msrnitueeusyuspnc lacnarihttakwahfas pdda aituoirv enfe/tdiAs mri toi .gn,tefd-ps e h"

    const/4 v4, 0x5

    const-string v2, " c_mrsapromnos rro/mofgha.n.lloneuip-tt-hgesda  .rigrn#h paajti dng nengtnotcpc etliue-s/aertEodisri m:ibi ir ehfilepsv c  tio  / ofnat   meh nekmdthesdyfat-.triit-//snifscend,finds pcIcabrtuaA/ u ta trivomntvcpotac- kputoPaahie rigkdelenstelapgntosaebeltisleieteewhesnnv  tar-aerce  emt a"

    const-string v2, "Event tracked before first activity resumed.\nIf it was triggered in the Application class, it might timestamp or even send an install long before the user opens the app.\nPlease check https://github.com/adjust/android_sdk#can-i-trigger-an-event-at-application-launch for more information."

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$p0;->b:Lcom/adjust/sdk/ActivityHandler;

    invoke-static {v0}, Lcom/adjust/sdk/ActivityHandler;->access$500(Lcom/adjust/sdk/ActivityHandler;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$p0;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$p0;->a:Lcom/adjust/sdk/AdjustEvent;

    const/4 v3, 0x6

    and-int/2addr v4, v3

    invoke-static {v0, v1}, Lcom/adjust/sdk/ActivityHandler;->access$1000(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/AdjustEvent;)V

    const/4 v4, 0x2

    return-void
.end method
