.class public final Lcom/adjust/sdk/InstallReferrer$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/InstallReferrer;->invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/reflect/Method;

.field public final synthetic c:[Ljava/lang/Object;

.field public final synthetic d:Lcom/adjust/sdk/InstallReferrer;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/InstallReferrer;Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/InstallReferrer$b;->d:Lcom/adjust/sdk/InstallReferrer;

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/InstallReferrer$b;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/adjust/sdk/InstallReferrer$b;->b:Ljava/lang/reflect/Method;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/adjust/sdk/InstallReferrer$b;->c:[Ljava/lang/Object;

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " rs@b@ ~@  n    @@t~oS~s~@ ~ @M~y~ @~t@l. ~~~oiK@- @~@ i/~b~u1o@fib@~ vlo~@4d~aoc@~@~@~m~/o @~ @"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer$b;->d:Lcom/adjust/sdk/InstallReferrer;

    const/4 v5, 0x3

    and-int/2addr v6, v5

    iget-object v1, p0, Lcom/adjust/sdk/InstallReferrer$b;->a:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/InstallReferrer$b;->b:Ljava/lang/reflect/Method;

    const/4 v6, 0x1

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer$b;->c:[Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/adjust/sdk/InstallReferrer;->access$000(Lcom/adjust/sdk/InstallReferrer;Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/InstallReferrer$b;->d:Lcom/adjust/sdk/InstallReferrer;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/adjust/sdk/InstallReferrer;->access$100(Lcom/adjust/sdk/InstallReferrer;)Lcom/adjust/sdk/ILogger;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v2, 0x2

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    aput-object v3, v2, v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    aput-object v0, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v0, "v)om%ne i osor(eb ywsn(r )ht %rr"

    const-string/jumbo v0, "invoke error (%s) thrown by (%s)"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1, v0, v2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method
