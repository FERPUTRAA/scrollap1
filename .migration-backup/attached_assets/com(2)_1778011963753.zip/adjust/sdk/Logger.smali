.class public Lcom/adjust/sdk/Logger;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/adjust/sdk/ILogger;


# static fields
.field private static formatErrorMessage:Ljava/lang/String; = "Error formating log message: %s, with params: %s"


# instance fields
.field private isProductionEnvironment:Z

.field private logLevel:Lcom/adjust/sdk/LogLevel;

.field private logLevelLocked:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/adjust/sdk/Logger;->logLevelLocked:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v1, Lcom/adjust/sdk/LogLevel;->INFO:Lcom/adjust/sdk/LogLevel;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, v1, v0}, Lcom/adjust/sdk/Logger;->setLogLevel(Lcom/adjust/sdk/LogLevel;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public varargs Assert(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "t~s~~~4t@n @~d@y~vi1@a ~bi@~  @u@o~M~@o K@. @oil~bo@m f~/S~~ o s @~o~r~@-  ~@bf~c  @@~~@@   @/@l"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const-string/jumbo v0, "stsjdA"

    const/4 v5, 0x5

    const-string/jumbo v0, "sjdmtA"

    const-string v0, "Adjust"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x7

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v2, v0, v1}, Landroid/util/Log;->println(ILjava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :catch_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x2

    const/4 v5, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    aput-object p1, v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 p2, 0x1

    move v5, p2

    aput-object p1, v2, p2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x7

    return-void
.end method

.method public varargs debug(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v0, "Autdoj"

    const-string v0, "Adjust"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v4, 0x5

    move v5, v4

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x6

    const/4 v2, 0x3

    const/4 v5, 0x5

    shr-int/2addr v4, v2

    const/4 v5, 0x2

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :catch_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    aput-object p1, v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 p2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    aput-object p1, v2, p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method public varargs error(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v0, "Asujmb"

    const-string/jumbo v0, "sjumAd"

    const/4 v5, 0x0

    const-string/jumbo v0, "utudsA"

    const-string v0, "Adjust"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :catch_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    aput-object p1, v2, v3

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 p2, 0x1

    const/4 v5, 0x7

    aput-object p1, v2, p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method public varargs info(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v0, "spdoju"

    const-string/jumbo v0, "sdtuoj"

    const/4 v5, 0x7

    const-string v0, "Auqdtj"

    const-string v0, "Adjust"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v4, 0x6

    move v5, v4

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :catch_0
    const/4 v5, 0x4

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    aput-object p1, v2, v3

    const/4 v5, 0x0

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 p2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    aput-object p1, v2, p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method

.method public lockLogLevel()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/Logger;->logLevelLocked:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public setLogLevel(Lcom/adjust/sdk/LogLevel;Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/adjust/sdk/Logger;->logLevelLocked:Z

    const/4 v1, 0x7

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-boolean p2, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setLogLevelString(Ljava/lang/String;Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/adjust/sdk/LogLevel;->valueOf(Ljava/lang/String;)Lcom/adjust/sdk/LogLevel;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, v0, p2}, Lcom/adjust/sdk/Logger;->setLogLevel(Lcom/adjust/sdk/LogLevel;Z)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :catch_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    aput-object p1, p2, v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p1, "als/fln //oe ogs /fld/grmfokib baL,Mt/ leie%voc/nla"

    const-string p1, "da %gbl/kiaecfm/nov/ll/o ,lgtfe / ibloLe a /f/ornsM"

    const/4 v2, 0x5

    const-string/jumbo p1, "o/bm/ r%flkf  g/eetMl,fognvs aail//l/oaeim/d L/cn o"

    const-string p1, "Malformed logLevel \'%s\', falling back to \'info\'"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/adjust/sdk/Logger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public varargs verbose(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v0, "usuAod"

    const-string/jumbo v0, "udAtus"

    const/4 v5, 0x7

    const-string/jumbo v0, "sjtAdb"

    const-string v0, "Adjust"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :catch_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    or-int/2addr v5, v4

    aput-object p1, v2, v3

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    aput-object p1, v2, p2

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void
.end method

.method public varargs warn(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v0, "udpAuj"

    const-string v0, "Apjsdu"

    const/4 v5, 0x0

    const-string v0, "Adjust"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-boolean v1, p0, Lcom/adjust/sdk/Logger;->isProductionEnvironment:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x5

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-gt v1, v2, :cond_1

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v4, 0x1

    aput-object p1, v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 p2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    aput-object p1, v2, p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void
.end method

.method public varargs warnInProduction(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v0, "Apstju"

    const-string/jumbo v0, "ujqtAs"

    const/4 v5, 0x0

    const-string/jumbo v0, "sdqtuj"

    const-string v0, "Adjust"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/Logger;->logLevel:Lcom/adjust/sdk/LogLevel;

    const/4 v4, 0x2

    move v5, v4

    iget v1, v1, Lcom/adjust/sdk/LogLevel;->androidLogLevel:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-gt v1, v2, :cond_0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v1, Lcom/adjust/sdk/Logger;->formatErrorMessage:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput-object p1, v2, v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 p2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object p1, v2, p2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method
