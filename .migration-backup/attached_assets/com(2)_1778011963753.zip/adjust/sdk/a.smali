.class public final Lcom/adjust/sdk/a;
.super Ljava/lang/Object;


# instance fields
.field public A:Ljava/lang/String;

.field public B:Ljava/lang/String;

.field public C:I

.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:I

.field public d:Ljava/lang/Boolean;

.field public e:Z

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public u:Ljava/lang/String;

.field public v:Ljava/lang/String;

.field public w:Ljava/lang/String;

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;

.field public z:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v0, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput v0, p0, Lcom/adjust/sdk/a;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/adjust/sdk/a;->e:Z

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/adjust/sdk/Util;->getLocale(Landroid/content/res/Configuration;)Ljava/util/Locale;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v3, v0, Landroid/content/res/Configuration;->screenLayout:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/adjust/sdk/a;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v4, p0, Lcom/adjust/sdk/a;->i:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/adjust/sdk/a;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    iput-object v4, p0, Lcom/adjust/sdk/a;->j:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Lcom/adjust/sdk/a;->a(Landroid/content/res/Configuration;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-object v4, p0, Lcom/adjust/sdk/a;->k:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->e()V

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput-object v4, p0, Lcom/adjust/sdk/a;->l:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->d()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object v4, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v4, p0, Lcom/adjust/sdk/a;->m:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const-string/jumbo v4, "irsdadn"

    const/4 v6, 0x5

    const-string v4, "android"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object v4, p0, Lcom/adjust/sdk/a;->n:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->g()V

    const/4 v6, 0x0

    sget-object v4, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v5, 0x2

    iput-object v4, p0, Lcom/adjust/sdk/a;->o:Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-object v4, p0, Lcom/adjust/sdk/a;->p:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v2}, Lcom/adjust/sdk/a;->b(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x1

    iput-object v4, p0, Lcom/adjust/sdk/a;->q:Ljava/lang/String;

    const/4 v6, 0x4

    invoke-virtual {p0, v2}, Lcom/adjust/sdk/a;->a(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object v2, p0, Lcom/adjust/sdk/a;->r:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, v3}, Lcom/adjust/sdk/a;->b(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput-object v2, p0, Lcom/adjust/sdk/a;->s:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0, v3}, Lcom/adjust/sdk/a;->a(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object v2, p0, Lcom/adjust/sdk/a;->t:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Lcom/adjust/sdk/a;->c(Landroid/util/DisplayMetrics;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v2, p0, Lcom/adjust/sdk/a;->u:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0, v1}, Lcom/adjust/sdk/a;->b(Landroid/util/DisplayMetrics;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput-object v2, p0, Lcom/adjust/sdk/a;->v:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0, v1}, Lcom/adjust/sdk/a;->a(Landroid/util/DisplayMetrics;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object v1, p0, Lcom/adjust/sdk/a;->w:Ljava/lang/String;

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p0, p2}, Lcom/adjust/sdk/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/a;->h:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/adjust/sdk/a;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x4

    iput-object p2, p0, Lcom/adjust/sdk/a;->g:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->f()V

    const/4 v6, 0x6

    sget-object p2, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-object p2, p0, Lcom/adjust/sdk/a;->x:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->a()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput-object p2, p0, Lcom/adjust/sdk/a;->y:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/adjust/sdk/a;->c()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-object p2, p0, Lcom/adjust/sdk/a;->z:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Lcom/adjust/sdk/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object p2, p0, Lcom/adjust/sdk/a;->A:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/adjust/sdk/a;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/a;->B:Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Lcom/adjust/sdk/a;->b(Landroid/content/res/Configuration;)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput p1, p0, Lcom/adjust/sdk/a;->C:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " is @o~~~~~buf i~~@m @~  ~f~K/@~~~ @~v  t@@.l@  @aoy@co@S @4oit~@~  o~@~~1b/@rl@@M -@s @@ no~~b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-static {}, Lcom/adjust/sdk/Util;->getSupportedAbis()[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    array-length v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    aget-object v0, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/adjust/sdk/Util;->getCpuAbi()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public final a(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    and-int/lit8 p1, p1, 0x30

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/16 v0, 0x10

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p1, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x20

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p1, "long"

    const-string/jumbo p1, "olng"

    const/4 v2, 0x3

    const-string/jumbo p1, "lgno"

    const-string/jumbo p1, "long"

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const-string/jumbo p1, "omrmma"

    const-string/jumbo p1, "mlomra"

    const/4 v2, 0x1

    const-string/jumbo p1, "onamor"

    const-string/jumbo p1, "normal"

    const/4 v2, 0x7

    return-object p1
.end method

.method public final a(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/16 v1, 0x1000

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v0, Lcom/adjust/sdk/Util;->dateFormatter:Ljava/text/SimpleDateFormat;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Ljava/util/Date;

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-wide v2, p1, Landroid/content/pm/PackageInfo;->firstInstallTime:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3}, Ljava/util/Date;-><init>(J)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object p1

    :catch_0
    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object p1
.end method

.method public final a(Landroid/content/res/Configuration;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p1, Landroid/content/res/Configuration;->uiMode:I

    const/4 v3, 0x0

    and-int/lit8 v0, v0, 0xf

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    move v3, v1

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const-string/jumbo p1, "tv"

    const-string/jumbo p1, "vt"

    const/4 v3, 0x2

    const-string/jumbo p1, "vt"

    const-string/jumbo p1, "tv"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget p1, p1, Landroid/content/res/Configuration;->screenLayout:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    and-int/lit8 p1, p1, 0xf

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq p1, v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p1, v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq p1, v0, :cond_1

    const/4 v3, 0x5

    if-eq p1, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo p1, "ltbteb"

    const-string p1, "btelot"

    const/4 v3, 0x0

    const-string/jumbo p1, "utabte"

    const-string/jumbo p1, "tablet"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p1

    :cond_2
    const/4 v3, 0x6

    const-string/jumbo p1, "onppb"

    const-string p1, "bnohp"

    const/4 v3, 0x3

    const-string p1, "ehnqo"

    const-string/jumbo p1, "phone"

    const/4 v3, 0x5

    return-object p1
.end method

.method public final a(Landroid/util/DisplayMetrics;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    iget p1, p1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public final a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v0, "iusa.nd4330.d"

    const-string v0, "3n0id.ura43.d"

    const/4 v4, 0x7

    const-string v0, "a.dm3id3n40r."

    const-string v0, "android4.33.0"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    aput-object p1, v1, v2

    const/4 p1, 0x1

    shl-int/2addr v3, p1

    const/4 v4, 0x4

    aput-object v0, v1, p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo p1, "p%s%o"

    const-string/jumbo p1, "s%p%@"

    const/4 v4, 0x6

    const-string p1, "bs%@s"

    const-string p1, "%s@%s"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p1
.end method

.method public final a(Ljava/util/Locale;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public final a(Lcom/adjust/sdk/AdjustConfig;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/Util;->canReadNonPlayIds(Lcom/adjust/sdk/AdjustConfig;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/adjust/sdk/a;->e:Z

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getAndroidId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/a;->f:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-boolean p1, p0, Lcom/adjust/sdk/a;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public final b(Landroid/content/res/Configuration;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p1, p1, Landroid/content/res/Configuration;->uiMode:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    and-int/lit8 p1, p1, 0xf

    const/4 v1, 0x7

    return p1
.end method

.method public final b()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public final b(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 p1, p1, 0xf

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eq p1, v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p1, v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x7

    if-eq p1, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 p1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo p1, "uaxleg"

    const-string p1, "axqlge"

    const-string p1, "eplaxr"

    const-string/jumbo p1, "xlarge"

    const/4 v1, 0x3

    move v2, v1

    return-object p1

    :cond_1
    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo p1, "lesag"

    const/4 v2, 0x5

    const-string p1, "glrqe"

    const-string/jumbo p1, "large"

    const/4 v1, 0x1

    move v2, v1

    return-object p1

    :cond_2
    const/4 v2, 0x5

    const-string/jumbo p1, "lrsmmn"

    const-string/jumbo p1, "larmnm"

    const/4 v2, 0x1

    const-string/jumbo p1, "malmno"

    const-string/jumbo p1, "normal"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo p1, "loaso"

    const-string/jumbo p1, "laslo"

    const/4 v2, 0x1

    const-string p1, "bslml"

    const-string/jumbo p1, "small"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1
.end method

.method public final b(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/16 v1, 0x1000

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v0, Lcom/adjust/sdk/Util;->dateFormatter:Ljava/text/SimpleDateFormat;

    const/4 v5, 0x2

    const/4 v4, 0x6

    new-instance v1, Ljava/util/Date;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-wide v2, p1, Landroid/content/pm/PackageInfo;->lastUpdateTime:J

    invoke-direct {v1, v2, v3}, Ljava/util/Date;-><init>(J)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p1

    :catch_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p1
.end method

.method public final b(Landroid/util/DisplayMetrics;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget p1, p1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public final b(Ljava/util/Locale;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public final b(Lcom/adjust/sdk/AdjustConfig;)V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p1}, Lcom/adjust/sdk/Util;->canReadPlayIds(Lcom/adjust/sdk/AdjustConfig;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v0, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x4

    move v9, v8

    iget-object p1, p1, Lcom/adjust/sdk/AdjustConfig;->context:Landroid/content/Context;

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v8, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    iput-object v2, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    iput-object v2, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x6

    iput-object v2, p0, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v2, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    iput v2, p0, Lcom/adjust/sdk/a;->c:I

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v2, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    const/4 v9, 0x6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-gt v3, v4, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    mul-int/lit16 v4, v3, 0xbb8

    const/4 v8, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    int-to-long v4, v4

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-static {p1, v4, v5}, Lcom/adjust/sdk/GooglePlayServicesClient;->getGooglePlayServicesInfo(Landroid/content/Context;J)Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v5, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v4}, Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;->getGpsAdid()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    iput-object v5, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    :cond_1
    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez v5, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v4}, Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;->isTrackingEnabled()Ljava/lang/Boolean;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    iput-object v4, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v4, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v4, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v4, :cond_3

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    const-string/jumbo v4, "rcesibu"

    const-string v4, "esrcebi"

    const/4 v9, 0x1

    const-string/jumbo v4, "pcereiv"

    const-string/jumbo v4, "service"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    iput-object v4, p0, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x3

    iput v3, p0, Lcom/adjust/sdk/a;->c:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void

    :catch_0
    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_0

    :cond_4
    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x7

    if-gt v2, v4, :cond_9

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-wide/16 v5, 0x2af8

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p1, v5, v6}, Lcom/adjust/sdk/Util;->getAdvertisingInfoObject(Landroid/content/Context;J)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-nez v3, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_2

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-nez v5, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {p1, v3, v6, v7}, Lcom/adjust/sdk/Util;->getPlayAdId(Landroid/content/Context;Ljava/lang/Object;J)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iput-object v5, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v5, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-nez v5, :cond_7

    const/4 v9, 0x5

    invoke-static {p1, v3, v6, v7}, Lcom/adjust/sdk/Util;->isPlayTrackingEnabled(Landroid/content/Context;Ljava/lang/Object;J)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    iput-object v3, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    :cond_7
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v3, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v3, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz v3, :cond_8

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string p1, "bqruliy"

    const-string/jumbo p1, "lbyriru"

    const/4 v9, 0x1

    const-string p1, "bislyar"

    const-string/jumbo p1, "library"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput-object p1, p0, Lcom/adjust/sdk/a;->b:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x2

    iput v2, p0, Lcom/adjust/sdk/a;->c:I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    return-void

    :cond_8
    :goto_2
    const/4 v9, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    goto/16 :goto_1

    :cond_9
    const/4 v9, 0x5

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez p1, :cond_a

    const/4 v8, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/a;->a:Ljava/lang/String;

    :cond_a
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez p1, :cond_b

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    iput-object v1, p0, Lcom/adjust/sdk/a;->d:Ljava/lang/Boolean;

    :cond_b
    const/4 v8, 0x4

    const/4 v9, 0x1

    return-void
.end method

.method public final c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Landroid/os/Build;->ID:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public final c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object p1, p1, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    return-object p1

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p1
.end method

.method public final c(Landroid/util/DisplayMetrics;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    move v1, p1

    move v1, p1

    const/4 v2, 0x2

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/16 v0, 0x8c

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo p1, "lwo"

    const-string/jumbo p1, "olw"

    const/4 v2, 0x2

    const-string/jumbo p1, "low"

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 v0, 0xc8

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-le p1, v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string p1, "hhig"

    const-string p1, "hihg"

    const/4 v2, 0x1

    const-string p1, "hgih"

    const-string p1, "high"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p1

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo p1, "mummip"

    const-string p1, "dpmumi"

    const/4 v2, 0x3

    const-string p1, "dmieou"

    const-string/jumbo p1, "medium"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p1
.end method

.method public final d(Landroid/content/Context;)Ljava/lang/String;
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string v0, "adi"

    const-string v0, "aid"

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const-string v3, "coatmbac.b.aokknqof"

    const-string/jumbo v3, "k.mocbaoqaeftknca.o"

    const/4 v12, 0x7

    const-string/jumbo v3, "mk.aonukaoatec.baof"

    const-string v3, "com.facebook.katana"

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/16 v4, 0x40

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-virtual {v2, v3, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget-object v2, v2, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v12, 0x2

    if-eqz v2, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    array-length v3, v2

    const/4 v12, 0x6

    const/4 v4, 0x1

    const/4 v11, 0x5

    and-int/2addr v12, v11

    if-eq v3, v4, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x5

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    aget-object v2, v2, v3

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-string v5, "2674053p0112f36b366ef6f663e08000235c149c4ad441c99fa25e5a34662f3f0acb3366211fd31e0000bc9c18c602e45060658305e5f7f0807e3763589096046026626d5321f8192f106ca6f40b484324663440162518a005ff085ef8910f63e784f60b0cc512e90280f2018062743e1311ffd3120b5750172305b1b0c11325880a02e6696304d60a33900b546cd3d80151560ac51000b16f6708b125115606685500c1f109dcce06f681ab80c54136386050116c50765962b54071810d1461f3060dce7a10647a650b2612364468413f570da3c1216a78eae30652c054a091721031c6610705b66be56404330a386433f84e723d60696f021933a4165134001d465081964468260163397c3fb0a4b6ace8baf701734005840362268150660700a64a636513831613168055bd46b3d9164012344610352fb676aa930a1610220553c7256c94b401660f2510d101304707336f2297693e058c95303f9555e1c33d2f162300d6f001519803621176a0096f6503bf7237068df2305b7f8a84034a22003224c1bdf66f7001940307d147130d214750d020a9660601135206476ca9133088116f0739045302c166f11b57b7348064586da670324fce3536431451163e893fd0be509070b6ed27159f90b0c20574ad48001b1b10739b16b8331101204794b20c3a15d4d3f78889265009313fafcae601020b0b216387751159688bc233f38360668406031473f193d62ad1133004332960166035062da880d9d001c059efd50040b0533720066f158b2a4b55706033e1d2a16126008683fdcff08415cccd35c2f183320s603630d1366001643d020c5403a20b22339680503107100fa0e24208603abcbf41c64f2d"

    const-string v5, "cfsa9d50883082030816b786edc43214568cf3a033c786bfc53a4f005545380db07052029701100466061aa143667d1760f35d8ee09c4625bf41379815e3a0011020118d1432b5ff40834645510426615306f4e7b0f733e04566640e8a70f3308613b806031018803d26d370c135e0b061f031235f59600431a141196600352fd0ff9a15b568c96f6131e535e465694a50a8c9ab45013b0ab610b3e9c53581060f41f487870516644028821b00bb8136202636215b1811cf262a7823eacb67b03166f44d646b546f60e220460103b372fb319e6093566301308242eb800c9b5407e2f5191f9e47333cb246306541666d5d9766c00102210610bfd5306fac7b2a0a3097f1ff010d20a17941107313d061460684040f4b6c506641322a7c6138e0e064f663c7871f80505fd6032c05086761423066a0d1226240064412255f141313136b63250af64f48203603d8c2751823690a660181676a536636a85d01d0330d31620d011fe26e9c52f25a40307800c1793461003a65a90b3b120ee44780c0c139234c013065546d242d30017273fdc0918f9615a790cd66f98785d73348a02b42107f8036001b01216f6a92432109503706b30d4859c3ffc3021653028260fb460c0f2e530175a661564b3f5005a6013159963620269962c5e72e0612f551df6c11160304b18365fab9c0b481920f363103901106005a7fce3cd036004ba82362815320550096b072b63518a880130251301302301dd01c06307308250616b0148935060423038700177fcc7a50b033f0f60a130536342360593006d0f1ca5d7b6d06711984e64686201649106611f0d31c4d3c0730d00451056da4691d66053218ce3dc3928ac0a346f7"

    const/4 v12, 0x3

    const-string v5, "5f135230q24f85d62436111002832d23fc88263240600003d060155156d56663f3b27169bb631302ac9be2f0865ce4655a166193633133d36b1b07d0d683438c267368cff04493f06174e3b5606d0303c7f2140fc10934af656f4fb956423101e0c4223df077616005980c6102410b61b34a4a1010c6006b77655203dd6d768b0085c86c24000d5ddb3400c96aaf96d3a80fc0c06b70b1018fed00400241c03530baef23c0de437b0968e48df00ab307924166d0303491ce38f77ca090a35504a69a70052436800db00067310020d386f302f2811871116ed4532834299f3840f10d6416f050441b1669054d0938651035680604700140130c130020302d1066b963524c1de50303611443d3287311d902b5df0d6b57e46f2814f00f09934ae636000837c7cf3403561600404876b8660c56100c58b076020515e662a040c1a4899355f4df3440760e67606326613927372010f05a0264b40049c1813fa1277501b31c304758121066610613030607af668db2890b18546355676e50b36f833bc303016d050130a3c96a2e10bf3250b9071c1af515216e55eed166b619885b2c674741c12fa1d2886661b1af11e0f9611611b60c3798401ae6033af005a0d356699600660f355631b9a1033652965105660b20382440061807233768de5e735709631f318e139c1323234f10415f21661116c2ad896f833c137c4857df72622c560a90d28c30f2802021342517ca565f06344841acc2ea233303e346094615aaa8140f16261152f0356650fb31af460f32bf24b1003bb512280090098611553f01a07a6ac519b608011220dee586005230843841666f850a2515970765200136300a33167704f68cf4205731"

    const-string v5, "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2"

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v2}, Landroid/content/pm/Signature;->toCharsString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x7

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    if-nez v2, :cond_1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    return-object v1

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string p1, ".us/nrvevftItdoioerattckaetn.epcrdootnr:anmiikbAbcma.o/odriP"

    const-string p1, "IPamt:a.iti.uknbt.Arodvnfrdemeap/cnroe.toctrkcivbe/oitrodoan"

    const/4 v12, 0x6

    const-string p1, "acomn/atiiri.r.e/kaoudtdovec.no.anemvorirenPdtbpktIrtoAto:fc"

    const-string p1, "content://com.facebook.katana.provider.AttributionIdProvider"

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x5

    new-array v7, v4, [Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    aput-object v0, v7, v3

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v8, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v9, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    const/4 v10, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual/range {v5 .. v10}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-nez p1, :cond_2

    const/4 v11, 0x5

    shr-int/2addr v12, v11

    return-object v1

    :cond_2
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    if-nez v2, :cond_3

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-object v1

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x0

    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    return-object v0

    :catch_0
    :cond_4
    :goto_0
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    return-object v1
.end method

.method public final d()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public final e(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public final e()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public final f()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public final g()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-void
.end method
