.class public Lcom/adjust/sdk/AdjustAttribution;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialPersistentFields:[Ljava/io/ObjectStreamField;

.field private static final serialVersionUID:J = 0x1L


# instance fields
.field public adgroup:Ljava/lang/String;

.field public adid:Ljava/lang/String;

.field public campaign:Ljava/lang/String;

.field public clickLabel:Ljava/lang/String;

.field public costAmount:Ljava/lang/Double;

.field public costCurrency:Ljava/lang/String;

.field public costType:Ljava/lang/String;

.field public creative:Ljava/lang/String;

.field public fbInstallReferrer:Ljava/lang/String;

.field public network:Ljava/lang/String;

.field public trackerName:Ljava/lang/String;

.field public trackerToken:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/16 v0, 0xc

    const/4 v6, 0x6

    new-array v0, v0, [Ljava/io/ObjectStreamField;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v2, "aeskertTocks"

    const-string/jumbo v2, "rTsekoecatkn"

    const/4 v6, 0x0

    const-string/jumbo v2, "rnkmTcetkaro"

    const-string/jumbo v2, "trackerToken"

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v6, 0x0

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    aput-object v1, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v2, "Ntmcoeekrrm"

    const-string/jumbo v2, "rrcmmaeetkN"

    const/4 v6, 0x7

    const-string/jumbo v2, "mrrkabtNeca"

    const-string/jumbo v2, "trackerName"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x3

    const/4 v2, 0x7

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v2, "tkeoorw"

    const/4 v6, 0x2

    const-string/jumbo v2, "ntoreku"

    const-string/jumbo v2, "network"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x3

    move v6, v5

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v2, "cimanbpg"

    const/4 v6, 0x4

    const-string v2, "campaign"

    const/4 v5, 0x6

    move v6, v5

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v2, 0x3

    const/4 v5, 0x0

    and-int/2addr v6, v5

    aput-object v1, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v2, "popgauu"

    const-string v2, "dupogau"

    const/4 v6, 0x6

    const-string/jumbo v2, "oqpdgur"

    const-string v2, "adgroup"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v2, "prsvaete"

    const-string v2, "avteirep"

    const/4 v6, 0x1

    const-string v2, "ceimvatr"

    const-string v2, "creative"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    aput-object v1, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const-string v2, "clickLabel"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x6

    const/4 v5, 0x7

    or-int/2addr v6, v5

    aput-object v1, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, "dadi"

    const-string v2, "diad"

    const-string/jumbo v2, "idda"

    const-string v2, "adid"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v2, 0x7

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    aput-object v1, v0, v2

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v2, "soyqoteT"

    const-string/jumbo v2, "qteTypos"

    const/4 v6, 0x5

    const-string/jumbo v2, "tpTcobse"

    const-string v2, "costType"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/16 v2, 0x8

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    aput-object v1, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "utootAusmc"

    const-string/jumbo v2, "oustmncoAt"

    const-string/jumbo v2, "tucmsnopAo"

    const-string v2, "costAmount"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-class v4, Ljava/lang/Double;

    const-class v4, Ljava/lang/Double;

    const/4 v6, 0x1

    const-class v4, Ljava/lang/Double;

    const-class v4, Ljava/lang/Double;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v2, 0x9

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    aput-object v1, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const-string/jumbo v2, "msroCryeqncu"

    const-string/jumbo v2, "senmytCuorcr"

    const/4 v6, 0x3

    const-string v2, "costCurrency"

    const/4 v6, 0x1

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v2, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "rrsloefrenalIftRb"

    const-string/jumbo v2, "tesloarflIrbrenfR"

    const/4 v6, 0x5

    const-string/jumbo v2, "rramrtnfllfRbeeIe"

    const-string v2, "fbInstallReferrer"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/16 v2, 0xb

    const/4 v6, 0x4

    const/4 v5, 0x6

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    sput-object v0, Lcom/adjust/sdk/AdjustAttribution;->serialPersistentFields:[Ljava/io/ObjectStreamField;

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static fromJson(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Lcom/adjust/sdk/AdjustAttribution;
    .locals 12

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, Lcom/adjust/sdk/AdjustAttribution;

    invoke-direct {v0}, Lcom/adjust/sdk/AdjustAttribution;-><init>()V

    const-string/jumbo v1, "ubtno"

    const-string v1, "bniut"

    const-string v1, "biunt"

    const-string/jumbo v1, "unity"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const-string v1, "arreleui_bfuesrtn_r"

    const-string v1, "esbe_fui_trernlrfra"

    const-string v1, "fn_alftprrilbr_eeer"

    const-string v1, "fb_install_referrer"

    const-string/jumbo v2, "orscuytpqrcnc"

    const-string v2, "_urctcopsrncy"

    const-string/jumbo v2, "rnseoyus_tccc"

    const-string v2, "cost_currency"

    const-string v3, "_somtnmauto"

    const-string/jumbo v3, "o_aomtstqnu"

    const-string/jumbo v3, "to_soutmnco"

    const-string v3, "cost_amount"

    const-string v4, "_oesybscp"

    const-string v4, "csse_tpyo"

    const-string v4, "c_peytuot"

    const-string v4, "cost_type"

    const-string/jumbo v5, "laillkmpcbe"

    const-string/jumbo v5, "kbimecllacl"

    const-string/jumbo v5, "ile_cbllqca"

    const-string v5, "click_label"

    const-string v6, "creative"

    const-string v7, "gosdoua"

    const-string v7, "durgooa"

    const-string/jumbo v7, "pdamrug"

    const-string v7, "adgroup"

    const-string v8, "amiponac"

    const-string v8, "anpcibma"

    const-string/jumbo v8, "ipamgbna"

    const-string v8, "campaign"

    const-string/jumbo v9, "orktewu"

    const-string/jumbo v9, "network"

    const-string/jumbo v10, "kraertnp_ame"

    const-string/jumbo v10, "tracker_name"

    const-string/jumbo v11, "rkta_tukqeoce"

    const-string v11, "caotrtuek_rke"

    const-string v11, "atsnrecreotk_"

    const-string/jumbo v11, "tracker_token"

    if-eqz p2, :cond_2

    const-string p2, ""

    const-string p2, ""

    const-string p2, ""

    const-string p2, ""

    invoke-virtual {p0, v11, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iput-object v11, v0, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    invoke-virtual {p0, v10, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iput-object v10, v0, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    invoke-virtual {p0, v9, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    iput-object v9, v0, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    invoke-virtual {p0, v8, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v0, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    invoke-virtual {p0, v7, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    iput-object v7, v0, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    invoke-virtual {p0, v6, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, v0, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    invoke-virtual {p0, v5, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v0, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_0
    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    invoke-virtual {p0, v4, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    invoke-virtual {p0, v3, v4, v5}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    invoke-virtual {p0, v2, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    invoke-virtual {p0, v1, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_2
    invoke-virtual {p0, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    invoke-virtual {p0, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    invoke-virtual {p0, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    invoke-virtual {p0, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    invoke-virtual {p0, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    invoke-virtual {p0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    invoke-virtual {p0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iput-object p2, v0, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    invoke-virtual {p0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;)D

    move-result-wide p1

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    invoke-virtual {p0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, v0, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_1
    iput-object p0, v0, Lcom/adjust/sdk/AdjustAttribution;->fbInstallReferrer:Ljava/lang/String;

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne p1, p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v1, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eq v2, v3, :cond_2

    const/4 v5, 0x5

    return v1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast p1, Lcom/adjust/sdk/AdjustAttribution;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v1

    :cond_4
    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x2

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v2, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    return v1

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v1

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v2, :cond_7

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v1

    :cond_7
    const/4 v5, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v2, :cond_8

    const/4 v5, 0x0

    return v1

    :cond_8
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v2, :cond_9

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v1

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v2, :cond_a

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1

    :cond_a
    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v2, :cond_b

    const/4 v5, 0x4

    return v1

    :cond_b
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalsDouble(Ljava/lang/Double;Ljava/lang/Double;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v2, :cond_c

    const/4 v4, 0x0

    and-int/2addr v5, v4

    return v1

    :cond_c
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v3, p1, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v2, :cond_d

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v1

    :cond_d
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/adjust/sdk/AdjustAttribution;->fbInstallReferrer:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/AdjustAttribution;->fbInstallReferrer:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v2, p1}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez p1, :cond_e

    const/4 v5, 0x7

    const/4 v4, 0x6

    return v1

    :cond_e
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v0
.end method

.method public hashCode()I
    .locals 4

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/lit16 v0, v0, 0x275

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x1

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashDouble(Ljava/lang/Double;)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    mul-int/lit8 v0, v0, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->fbInstallReferrer:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr v1, v0

    const/4 v2, 0x6

    move v3, v2

    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/16 v0, 0xc

    const/4 v4, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerToken:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->trackerName:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->network:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->campaign:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v4, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->adgroup:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v3, 0x7

    move v4, v3

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->creative:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->clickLabel:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->adid:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    move v4, v3

    aput-object v1, v0, v2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->costType:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/16 v2, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->costAmount:Ljava/lang/Double;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 v2, 0x9

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->costCurrency:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/16 v2, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustAttribution;->fbInstallReferrer:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/16 v2, 0xb

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput-object v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "tsdmr  f:%%g %:sd2:p%ni es sasdnc::s::s:s %a%c ascfs%cmtts: :e%lttc% i%a  r:.:%c"

    const-string v1, ":is: %sp sts:mla:%  :nf2sit%:csccgr fa% s s%sdst% .c n:e:%%ea:arc%%%ct: %:tsd: d"

    const/4 v4, 0x1

    const-string v1, "e:alotsi%d:%dr%%%a%  c:  s%cs:%2:ss:cs tsgt%:n ace:r:ads: n%cfs fs: t:% tc.mi%sc"

    const-string/jumbo v1, "tt:%s tn:%s net:%s cam:%s adg:%s cre:%s cl:%s adid:%s ct:%s ca:%.2f cc:%s fir:%s"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v1, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0
.end method
