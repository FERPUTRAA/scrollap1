.class public final Lcom/adjust/sdk/PackageHandler$f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/PackageHandler;->updatePackages(Lcom/adjust/sdk/SessionParameters;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/SessionParameters;

.field public final synthetic b:Lcom/adjust/sdk/PackageHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/PackageHandler;Lcom/adjust/sdk/SessionParameters;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/PackageHandler$f;->b:Lcom/adjust/sdk/PackageHandler;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/adjust/sdk/PackageHandler$f;->a:Lcom/adjust/sdk/SessionParameters;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s ~oM ~ ~n1i@o~~r ~@~ fol./ @@ ~@@  i/S~ b~~t~~@mby @@v~t~s@@d-a~~@u~K@o ~~@l4~@o @i ocb f@ ~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/PackageHandler$f;->b:Lcom/adjust/sdk/PackageHandler;

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/PackageHandler$f;->a:Lcom/adjust/sdk/SessionParameters;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/PackageHandler;->updatePackagesI(Lcom/adjust/sdk/SessionParameters;)V

    const/4 v3, 0x5

    return-void
.end method
