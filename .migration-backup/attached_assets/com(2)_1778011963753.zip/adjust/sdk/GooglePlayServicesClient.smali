.class public Lcom/adjust/sdk/GooglePlayServicesClient;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/adjust/sdk/GooglePlayServicesClient$a;,
        Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static getGooglePlayServicesInfo(Landroid/content/Context;J)Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "lis~ oKu@@s~4@~~b ~@@/tol ~~i ~.@/@@@@  ro f~~S co~~oMan-@ot@b~ m@v@ @f  ~ @@~ y~@ ~~i @~~1~@ ~b"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    const-string/jumbo v0, "sermnvvmeddofgtt.SiAangorrriisIoeg.id.acI.c.egsrn.ondneiedisdt.iimll"

    const-string v0, "..siIrimiSngor.dtsre.gn.odndgIisnAsdevtiveldeaidalcoaeogcnri.irfme.t"

    const/4 v8, 0x1

    const-string v0, "eriroivng.SoAotae.dig.tc.imoti..dngcsl.rdeeaaimIfIrdsoedeedvnlrngnii"

    const-string v0, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService"

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eq v1, v2, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v2, "mdravbo.innomdiegcd"

    const-string/jumbo v2, "rcdm.gnmionvniedoda"

    const/4 v8, 0x2

    const-string v2, "com.android.vending"

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x5

    move v7, v3

    move v7, v3

    const/4 v8, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    new-instance v1, Lcom/adjust/sdk/GooglePlayServicesClient$a;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {v1, p1, p2}, Lcom/adjust/sdk/GooglePlayServicesClient$a;-><init>(J)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance p1, Landroid/content/Intent;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo p2, "rv.edgusafgsineorceTsinodieiR.ASo.eacdt.do.iT.r.lmm"

    const-string p2, "com.google.android.gms.ads.identifier.service.START"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string/jumbo p2, "onola.mpg.dmgcdooosgr."

    const-string p2, "go.dod.lggocm.nimorsao"

    const/4 v8, 0x2

    const-string p2, "com.google.android.gms"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 p2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0, p1, v1, p2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v1}, Lcom/adjust/sdk/GooglePlayServicesClient$a;->a()Landroid/os/IBinder;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v2, Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {p1, p2, v4, v5, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v5}, Landroid/os/Parcel;->readException()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v5}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v4, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v0, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {p1, v0, v4, v5, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v5}, Landroid/os/Parcel;->readException()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v5}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz p1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v3, p2

    move v3, p2

    const/4 v8, 0x1

    move v3, p2

    move v3, p2

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x4

    invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz p1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    xor-int/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v2, v6, p1}, Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    const/4 v8, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v8, 0x2

    return-object v2

    :catchall_0
    move-exception p1

    :try_start_5
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    throw p1

    :catchall_1
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v5}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    throw p1
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_6
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    throw p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    throw p1

    :cond_2
    const/4 v8, 0x4

    new-instance p0, Ljava/io/IOException;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string p1, "engotncnqP edlfoa ooa iyGcelb"

    const-string/jumbo p1, "oeyPfblGicnnioa tlenaoedg  co"

    const/4 v8, 0x5

    const-string/jumbo p1, "ies oP ellcclaGgaoifnytd onen"

    const-string p1, "Google Play connection failed"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    throw p0

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string/jumbo p1, "toemayshr ce uld/  ftrebr a oe aniociecgms/nhsnvecft GeSeaoPia l "

    const-string/jumbo p1, "nhe i/ueo  l/ssde torfcth cGgaaeeccdayonvm af  tlrsiroS ei aenbPe"

    const/4 v8, 0x4

    const-string/jumbo p1, "t  eo   rh acni/iiv Gsmet/af eeeecals dyabrrnoafdonePSocs otlcghe"

    const-string p1, "Google Play Services info can\'t be accessed from the main thread"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    throw p0
.end method
