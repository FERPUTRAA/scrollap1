.class public final Lcom/adjust/sdk/AttributionHandler$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/AttributionHandler;->checkAttributionResponse(Lcom/adjust/sdk/AttributionResponseData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/AttributionResponseData;

.field public final synthetic b:Lcom/adjust/sdk/AttributionHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/AttributionHandler;Lcom/adjust/sdk/AttributionResponseData;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/AttributionHandler$e;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/adjust/sdk/AttributionHandler$e;->a:Lcom/adjust/sdk/AttributionResponseData;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/rs y@ K-~4~~  @b~~~~ ~~~sofuv~M~@o ib@t@o~ @@ @~@c~il~ @@ ot~@S@~a@.@@i@~@nb lo@  f@  ~o~  1m~/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/AttributionHandler$e;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/adjust/sdk/AttributionHandler;->access$300(Lcom/adjust/sdk/AttributionHandler;)Ljava/lang/ref/WeakReference;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    check-cast v0, Lcom/adjust/sdk/IActivityHandler;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/AttributionHandler$e;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    iget-object v2, p0, Lcom/adjust/sdk/AttributionHandler$e;->a:Lcom/adjust/sdk/AttributionResponseData;

    invoke-static {v1, v0, v2}, Lcom/adjust/sdk/AttributionHandler;->access$600(Lcom/adjust/sdk/AttributionHandler;Lcom/adjust/sdk/IActivityHandler;Lcom/adjust/sdk/AttributionResponseData;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method
