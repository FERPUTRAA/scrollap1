.class public final Lcom/adjust/sdk/ActivityHandler$s0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->readOpenUrl(Landroid/net/Uri;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/net/Uri;

.field public final synthetic b:J

.field public final synthetic c:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Landroid/net/Uri;J)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$s0;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$s0;->a:Landroid/net/Uri;

    const/4 v1, 0x3

    iput-wide p3, p0, Lcom/adjust/sdk/ActivityHandler$s0;->b:J

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@su@/@~@~~ ~@1r~bK~~~ ~@~@@sf@o@o~ ~ob @ t ~@fSib~  loi y/tdloMi~ @-@  @4~  .m a~ v~c@@ ~@@on@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$s0;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$s0;->a:Landroid/net/Uri;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityHandler$s0;->b:J

    const/4 v5, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/adjust/sdk/ActivityHandler;->access$1300(Lcom/adjust/sdk/ActivityHandler;Landroid/net/Uri;J)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-void
.end method
