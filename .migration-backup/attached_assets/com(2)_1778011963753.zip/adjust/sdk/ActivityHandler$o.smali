.class public final Lcom/adjust/sdk/ActivityHandler$o;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->setPushToken(Ljava/lang/String;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;ZLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$o;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-boolean p2, p0, Lcom/adjust/sdk/ActivityHandler$o;->a:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/adjust/sdk/ActivityHandler$o;->b:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b~s@y-.~@~~  ~@t  f ~@~~d ib @ c~ov @~~sMulort@  ~o~i~b/~oi@  ~~@@@lKm~@@@~ 4@1n @~/o~ oS@a@@f ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/adjust/sdk/ActivityHandler$o;->a:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$o;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityHandler;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/SharedPreferencesManager;->getDefaultInstance(Landroid/content/Context;)Lcom/adjust/sdk/SharedPreferencesManager;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$o;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/SharedPreferencesManager;->savePushToken(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$o;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/adjust/sdk/ActivityHandler;->access$900(Lcom/adjust/sdk/ActivityHandler;)Lcom/adjust/sdk/ActivityHandler$InternalState;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/adjust/sdk/ActivityHandler$InternalState;->hasFirstSdkStartNotOcurred()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$o;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$o;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/adjust/sdk/ActivityHandler;->access$2300(Lcom/adjust/sdk/ActivityHandler;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void
.end method
