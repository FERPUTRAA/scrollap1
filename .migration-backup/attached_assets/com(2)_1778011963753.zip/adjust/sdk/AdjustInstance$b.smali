.class public final Lcom/adjust/sdk/AdjustInstance$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/adjust/sdk/IRunActivityHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/AdjustInstance;->addSessionPartnerParameter(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/adjust/sdk/AdjustInstance$b;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/AdjustInstance$b;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run(Lcom/adjust/sdk/ActivityHandler;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ssd~   bi ~@  ~~@s@/~ bn@   a ~@ ou~~/.oK-rot4~@~ ~~@~~f@o1@fv~@~l@~@b @ ~Mioimtc@@~@@o~l@ @@~y"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/AdjustInstance$b;->a:Ljava/lang/String;

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/AdjustInstance$b;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Lcom/adjust/sdk/ActivityHandler;->addSessionPartnerParameterI(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method
