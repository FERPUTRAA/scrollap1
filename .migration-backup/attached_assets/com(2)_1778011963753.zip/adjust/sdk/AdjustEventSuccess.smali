.class public Lcom/adjust/sdk/AdjustEventSuccess;
.super Ljava/lang/Object;


# instance fields
.field public adid:Ljava/lang/String;

.field public callbackId:Ljava/lang/String;

.field public eventToken:Ljava/lang/String;

.field public jsonResponse:Lorg/json/JSONObject;

.field public message:Ljava/lang/String;

.field public timestamp:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s ~r1  l@uS~@t /~@/-@d ~i~@@o s@~@  ib~@  af@.t o@bK@m@~@~c y@@ b~ln~ ~~ov@@o fM o4~o@~~i@~~~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const/4 v0, 0x6

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->message:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->timestamp:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x4

    aput-object v1, v0, v2

    const/4 v3, 0x5

    or-int/2addr v4, v3

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->adid:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    move v4, v3

    aput-object v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->eventToken:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->callbackId:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v3, 0x3

    move v4, v3

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventSuccess;->jsonResponse:Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "vdemv%d smdcssgj:: n%a%osemt %isE ss :tsi%tues :in:cs%s:enSc"

    const-string v1, " cs:nts%:E%vs miSnmu:d:ss od%v:s  scssdnt%jtecs:i igee%a%s e"

    const/4 v4, 0x7

    const-string/jumbo v1, "v esos  gsiosde:%Sidn%ndus mctEess:tevat:jm:i :c:ss %%%n%esc"

    const-string v1, "Event Success msg:%s time:%s adid:%s event:%s cid:%s json:%s"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    return-object v0
.end method
