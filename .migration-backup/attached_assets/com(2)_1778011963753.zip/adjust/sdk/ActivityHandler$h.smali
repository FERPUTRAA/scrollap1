.class public final Lcom/adjust/sdk/ActivityHandler$h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->addSessionCallbackParameter(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$h;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$h;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/adjust/sdk/ActivityHandler$h;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "b1s@b y@o ~ld@@i@~@ v~ti~ ~@b.oS@M a~ 4@ @@~@o~c ~@/oK~ ~@~  @~~~of~s  l@/~u  @-~ if~ ~~@nt@@o~m"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$h;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$h;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/ActivityHandler$h;->b:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/adjust/sdk/ActivityHandler;->addSessionCallbackParameterI(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method
