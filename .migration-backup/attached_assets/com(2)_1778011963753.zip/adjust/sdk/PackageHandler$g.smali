.class public final Lcom/adjust/sdk/PackageHandler$g;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/PackageHandler;->flush()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/PackageHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/PackageHandler;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/adjust/sdk/PackageHandler$g;->a:Lcom/adjust/sdk/PackageHandler;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1isf @ iso@@@@t  /aSM~ ~@~@.~~ @-bo@n~~@@~@l  ~~~K@@@~~~ ~o~vml @dy/i @~o~uf~~@too  b~ cb@   r@4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/PackageHandler$g;->a:Lcom/adjust/sdk/PackageHandler;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/PackageHandler;->access$600(Lcom/adjust/sdk/PackageHandler;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
