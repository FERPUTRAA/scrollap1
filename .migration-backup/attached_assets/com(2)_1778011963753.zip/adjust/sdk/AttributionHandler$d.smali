.class public final Lcom/adjust/sdk/AttributionHandler$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/AttributionHandler;->checkSdkClickResponse(Lcom/adjust/sdk/SdkClickResponseData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/SdkClickResponseData;

.field public final synthetic b:Lcom/adjust/sdk/AttributionHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/AttributionHandler;Lcom/adjust/sdk/SdkClickResponseData;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/adjust/sdk/AttributionHandler$d;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/AttributionHandler$d;->a:Lcom/adjust/sdk/SdkClickResponseData;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~sb@~~- @1bru  ~~c~l@o~@~n  M@~~y~o@~~s4 @l~m@~ @i S@  Ko.~@ @~~ v @oft@o@a~@d ~ i~ibf/@o @ /~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/AttributionHandler$d;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/AttributionHandler;->access$300(Lcom/adjust/sdk/AttributionHandler;)Ljava/lang/ref/WeakReference;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast v0, Lcom/adjust/sdk/IActivityHandler;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    iget-object v1, p0, Lcom/adjust/sdk/AttributionHandler$d;->b:Lcom/adjust/sdk/AttributionHandler;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/AttributionHandler$d;->a:Lcom/adjust/sdk/SdkClickResponseData;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {v1, v0, v2}, Lcom/adjust/sdk/AttributionHandler;->access$500(Lcom/adjust/sdk/AttributionHandler;Lcom/adjust/sdk/IActivityHandler;Lcom/adjust/sdk/SdkClickResponseData;)V

    const/4 v4, 0x4

    return-void
.end method
