.class public final Lcom/adjust/sdk/ActivityHandler$c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->launchEventResponseTasks(Lcom/adjust/sdk/EventResponseData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/EventResponseData;

.field public final synthetic b:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/EventResponseData;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$c;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$c;->a:Lcom/adjust/sdk/EventResponseData;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s@@@@b/f  m/o l1o@yS d~ l@o@ ar~~ ~@ics@~~~~o~ ~~  t@i@vK4@~~n@o~ @f~@ob~@~~~t@@-@M~  . u~ @ i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$c;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$c;->a:Lcom/adjust/sdk/EventResponseData;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/adjust/sdk/ActivityHandler;->access$1800(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/EventResponseData;)V

    const/4 v3, 0x0

    return-void
.end method
