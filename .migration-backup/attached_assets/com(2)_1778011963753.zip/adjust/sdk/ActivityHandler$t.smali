.class public final Lcom/adjust/sdk/ActivityHandler$t;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->trackAdRevenue(Ljava/lang/String;Lorg/json/JSONObject;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Lorg/json/JSONObject;

.field public final synthetic c:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$t;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$t;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    iput-object p3, p0, Lcom/adjust/sdk/ActivityHandler$t;->b:Lorg/json/JSONObject;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "Mfson1 yv@ 4 @K bl @f@/@~~@~ roo~@S @~ @@~-@~ bc @~i ~@l~~~~ @o~s~@~~a~ @u@i~m~  bio.~ @@o/@td~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$t;->c:Lcom/adjust/sdk/ActivityHandler;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$t;->a:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/ActivityHandler$t;->b:Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1, v2}, Lcom/adjust/sdk/ActivityHandler;->access$2800(Lcom/adjust/sdk/ActivityHandler;Ljava/lang/String;Lorg/json/JSONObject;)V

    const/4 v3, 0x6

    move v4, v3

    return-void
.end method
