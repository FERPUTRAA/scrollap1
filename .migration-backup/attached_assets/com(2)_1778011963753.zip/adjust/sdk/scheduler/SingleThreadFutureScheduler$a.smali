.class public final Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/RejectedExecutionHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;-><init>(Ljava/lang/String;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$a;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final rejectedExecution(Ljava/lang/Runnable;Ljava/util/concurrent/ThreadPoolExecutor;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/ s@b~ m~n 4~ @~bM@o~ @   y@  1@~ico @~tat@~-o~sK~b o@uS ~r d~ ~@v@ @~~@f@l@~~@o@~o~~@~~/lf@i i."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    aput-object p1, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$a;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p1, v0, v1

    const/4 v3, 0x1

    const-string/jumbo p1, "ub]mjen ot armed]c[r ne%fl%ssse R"

    const-string/jumbo p1, "srsrosm nee]t%n Rb adjlue][f [%ce"

    const/4 v3, 0x0

    const-string p1, "f]n oen t[srb [ jeR]dolas%e%mu er"

    const-string p1, "Runnable [%s] rejected from [%s] "

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p2, p1, v0}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method
