.class public Lcom/adjust/sdk/scheduler/TimerCycle;
.super Ljava/lang/Object;


# instance fields
.field private command:Ljava/lang/Runnable;

.field private cycleDelay:J

.field private initialDelay:J

.field private isPaused:Z

.field private logger:Lcom/adjust/sdk/ILogger;

.field private name:Ljava/lang/String;

.field private scheduler:Lcom/adjust/sdk/scheduler/FutureScheduler;

.field private waitingTask:Ljava/util/concurrent/ScheduledFuture;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;JJLjava/lang/String;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0, p6, v1}, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;-><init>(Ljava/lang/String;Z)V

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->scheduler:Lcom/adjust/sdk/scheduler/FutureScheduler;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-object p6, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->command:Ljava/lang/Runnable;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-wide p2, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->initialDelay:J

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-wide p4, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->cycleDelay:J

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-boolean v1, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->isPaused:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object p1, Lcom/adjust/sdk/Util;->SecondsDisplayFormat:Ljava/text/DecimalFormat;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    long-to-double p4, p4

    const/4 v5, 0x5

    const/4 v4, 0x1

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const/4 v5, 0x3

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const/4 v4, 0x1

    and-int/2addr v5, v4

    div-double/2addr p4, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, p4, p5}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    move-result-object p4

    const/4 v5, 0x2

    const/4 v4, 0x2

    long-to-double p2, p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    div-double/2addr p2, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, p2, p3}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 p3, 0x3

    const/4 v5, 0x3

    new-array p3, p3, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 p5, 0x0

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput-object p6, p3, p5

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    aput-object p1, p3, v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 p1, 0x2

    move v5, p1

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    aput-object p4, p3, p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string p1, "%rsyn nsdfdee %dcrooassigyl seroafes%n ss so ngnftttectd rcucif    esavsee  or"

    const-string p1, "efsrte%oe fno cisa vsot% rrguefya td n otesdl n sesrscgod%  ssnncrsecey ai cdf"

    const/4 v5, 0x5

    const-string p1, " n m orrcd aiet daecfnd g%ie rvuny ss secaosfcoee rtsssoedsrfygn toisn f lec%t"

    const-string p1, "%s configured to fire after %s seconds of starting and cycles every %s seconds"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {p2, p1, p3}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method

.method public static synthetic access$000(Lcom/adjust/sdk/scheduler/TimerCycle;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@~ o-@S~~n~u@1.iob@o~~ @@@a~@i t bl@  t @~cv~oo @@Kfd~l~m ~~@s@~~4  iM@ ~~ @f~@/r@o ~~@o y~ ~/ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public static synthetic access$100(Lcom/adjust/sdk/scheduler/TimerCycle;)Lcom/adjust/sdk/ILogger;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public static synthetic access$200(Lcom/adjust/sdk/scheduler/TimerCycle;)Ljava/lang/Runnable;
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iget-object p0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->command:Ljava/lang/Runnable;

    return-object p0
.end method

.method private cancel(Z)V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->waitingTask:Ljava/util/concurrent/ScheduledFuture;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->waitingTask:Ljava/util/concurrent/ScheduledFuture;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public start()V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-boolean v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->isPaused:Z

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v1, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v2, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x3

    if-nez v0, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget-object v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    aput-object v3, v1, v2

    const/4 v10, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v2, "tlertbi yar asdeds as"

    const-string v2, "%s is already started"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    return-void

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v11, 0x4

    iget-object v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v11, 0x2

    aput-object v3, v1, v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v3, " s%trguisan"

    const-string/jumbo v3, "isrm s%tagn"

    const/4 v11, 0x3

    const-string v3, " sgrts%pnit"

    const-string v3, "%s starting"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-interface {v0, v3, v1}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object v4, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->scheduler:Lcom/adjust/sdk/scheduler/FutureScheduler;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    new-instance v5, Lcom/adjust/sdk/scheduler/TimerCycle$a;

    const/4 v11, 0x4

    const/4 v10, 0x5

    invoke-direct {v5, p0}, Lcom/adjust/sdk/scheduler/TimerCycle$a;-><init>(Lcom/adjust/sdk/scheduler/TimerCycle;)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-wide v6, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->initialDelay:J

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-wide v8, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->cycleDelay:J

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-interface/range {v4 .. v9}, Lcom/adjust/sdk/scheduler/FutureScheduler;->scheduleFutureWithFixedDelay(Ljava/lang/Runnable;JJ)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    iput-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->waitingTask:Ljava/util/concurrent/ScheduledFuture;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    iput-boolean v2, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->isPaused:Z

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    return-void
.end method

.method public suspend()V
    .locals 9

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-boolean v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->isPaused:Z

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    and-int/2addr v8, v7

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v8, 0x3

    aput-object v3, v1, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v2, "edisdrnyqada oe% uple s"

    const-string v2, "eydeosus d i a%nsredapl"

    const/4 v8, 0x1

    const-string v2, "%s is already suspended"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x4

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->waitingTask:Ljava/util/concurrent/ScheduledFuture;

    const/4 v8, 0x4

    const/4 v7, 0x3

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {v0, v3}, Ljava/util/concurrent/Delayed;->getDelay(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    iput-wide v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->initialDelay:J

    const/4 v8, 0x2

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->waitingTask:Ljava/util/concurrent/ScheduledFuture;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {v0, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    sget-object v0, Lcom/adjust/sdk/Util;->SecondsDisplayFormat:Ljava/text/DecimalFormat;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-wide v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->initialDelay:J

    const/4 v8, 0x2

    long-to-double v3, v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v8, 0x7

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    div-double/2addr v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v4}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x1

    const/4 v4, 0x2

    const/4 v8, 0x0

    move v7, v4

    move v7, v4

    const/4 v8, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x5

    iget-object v5, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->name:Ljava/lang/String;

    const/4 v8, 0x6

    aput-object v5, v4, v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    aput-object v0, v4, v1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo v0, "s si%wd ce n fstndsheeosstdpusel "

    const-string/jumbo v0, "tu ftb le n ednhse%cdio sssespdsw"

    const/4 v8, 0x5

    const-string/jumbo v0, "ndsmtp sfs ewe ocnsue ss %thdid%l"

    const-string v0, "%s suspended with %s seconds left"

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v3, v0, v4}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    iput-boolean v1, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->isPaused:Z

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    return-void
.end method

.method public teardown()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/adjust/sdk/scheduler/TimerCycle;->cancel(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->scheduler:Lcom/adjust/sdk/scheduler/FutureScheduler;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/adjust/sdk/scheduler/FutureScheduler;->teardown()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/adjust/sdk/scheduler/TimerCycle;->scheduler:Lcom/adjust/sdk/scheduler/FutureScheduler;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
