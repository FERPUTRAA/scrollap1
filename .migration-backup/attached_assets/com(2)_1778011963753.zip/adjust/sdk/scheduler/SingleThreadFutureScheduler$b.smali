.class public final Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduleFutureWithReturn(Ljava/util/concurrent/Callable;J)Ljava/util/concurrent/ScheduledFuture;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "TV;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Ljava/util/concurrent/Callable;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$b;->a:Ljava/util/concurrent/Callable;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TV;"
        }
    .end annotation

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "o-sv@/~~K  @~Mi~ iy@~ u   ~ @@  f~~~@~@bs S~lmbfo~@1 @lo~t@ a~@~~@~~n@@@o~c~ @dot@@~o@b~i/4@r . "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$b;->a:Ljava/util/concurrent/Callable;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    aput-object v3, v2, v4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x1

    shl-int/2addr v6, v3

    const/4 v5, 0x0

    const/4 v5, 0x6

    aput-object v0, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v0, " ]lmrs ]paerlstCre% % [yfe[ol as"

    const-string v0, " fsa%C]er % altbsoyp  e][ellrrs["

    const/4 v6, 0x2

    const-string/jumbo v0, "opl%oef  asre%ar]lser [[ybt]  oC"

    const-string v0, "Callable error [%s] of type [%s]"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v1, v0, v2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v0, 0x0

    xor-int/2addr v6, v0

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-object v0
.end method
