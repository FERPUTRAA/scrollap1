.class public final Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;->execute([Ljava/lang/Object;)Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:[Ljava/lang/Object;

.field public final synthetic b:Landroid/os/Handler;

.field public final synthetic c:Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;[Ljava/lang/Object;Landroid/os/Handler;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->c:Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->a:[Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->b:Landroid/os/Handler;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  s~ tiy-@b~o~b~@@@@tlr.@c   @@/dbav ~m~f ~M~@~ @ @/@i@@~sS~f~~~@~o~io@@o ~~   u~ 4@~~~ @n o@olK"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->c:Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->a:[Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor;->doInBackground([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;->b:Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v2, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v2, p0, v0}, Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a$a;-><init>(Lcom/adjust/sdk/scheduler/AsyncTaskExecutor$a;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
