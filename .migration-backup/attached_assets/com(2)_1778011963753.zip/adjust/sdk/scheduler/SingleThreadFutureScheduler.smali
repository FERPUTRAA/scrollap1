.class public Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/adjust/sdk/scheduler/FutureScheduler;


# instance fields
.field private scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;


# direct methods
.method public constructor <init>(Ljava/lang/String;Z)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Lcom/adjust/sdk/scheduler/ThreadFactoryWrapper;

    const/4 v3, 0x5

    or-int/2addr v4, v3

    invoke-direct {v1, p1}, Lcom/adjust/sdk/scheduler/ThreadFactoryWrapper;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v2, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v2, p1}, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$a;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    and-int/2addr v4, v3

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v0, p1, v1, v2}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;-><init>(ILjava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez p2, :cond_0

    const/4 v4, 0x7

    sget-object p2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const-wide/16 v1, 0xa

    const-wide/16 v1, 0xa

    const/4 v4, 0x6

    const-wide/16 v1, 0xa

    const-wide/16 v1, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2, p2}, Ljava/util/concurrent/ThreadPoolExecutor;->setKeepAliveTime(JLjava/util/concurrent/TimeUnit;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public scheduleFuture(Ljava/lang/Runnable;J)Ljava/util/concurrent/ScheduledFuture;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Runnable;",
            "J)",
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " fsi@~d@~@~vb@@l@ @~S~~o@s~K@ @~o aot@-~ b@o4io~~r@ ~~@fb~n~.y@l~c~1m  oi @  /~@~/ ~t~ @  uM@  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance v1, Lcom/adjust/sdk/scheduler/RunnableWrapper;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v1, p1}, Lcom/adjust/sdk/scheduler/RunnableWrapper;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p2, p3, p1}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1
.end method

.method public scheduleFutureWithFixedDelay(Ljava/lang/Runnable;JJ)Ljava/util/concurrent/ScheduledFuture;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Runnable;",
            "JJ)",
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-instance v1, Lcom/adjust/sdk/scheduler/RunnableWrapper;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {v1, p1}, Lcom/adjust/sdk/scheduler/RunnableWrapper;-><init>(Ljava/lang/Runnable;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    move-wide v2, p2

    move-wide v4, p4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual/range {v0 .. v6}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    return-object p1
.end method

.method public scheduleFutureWithReturn(Ljava/util/concurrent/Callable;J)Ljava/util/concurrent/ScheduledFuture;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Callable<",
            "TV;>;J)",
            "Ljava/util/concurrent/ScheduledFuture<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$b;

    const/4 v2, 0x6

    move v3, v2

    invoke-direct {v1, p1}, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler$b;-><init>(Ljava/util/concurrent/Callable;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p2, p3, p1}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;->schedule(Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-object p1
.end method

.method public teardown()V
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/adjust/sdk/scheduler/SingleThreadFutureScheduler;->scheduledThreadPoolExecutor:Ljava/util/concurrent/ScheduledThreadPoolExecutor;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;->shutdownNow()Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
