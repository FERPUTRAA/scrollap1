.class public final Lcom/adjust/sdk/scheduler/ThreadFactoryWrapper$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/scheduler/ThreadFactoryWrapper;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "n@s~1~~4il~@ ~ .t~r@i oS~s@  @~al~o~~ovo~y /bffm@-~ ~ @~t~@ @iM bK@uo@~o@@~ d @ /@@c@~~ @~ @~b @"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput-object p1, v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 p2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    aput-object p1, v1, p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo p1, "we[mdr os]s]eTshr[rra%h  it"

    const-string p1, "%hses htrTr]rwres%[ ][ao di"

    const/4 v4, 0x6

    const-string p1, "hrd oiTe e[a[%]rhrs]sr o wt"

    const-string p1, "Thread [%s] with error [%s]"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method
