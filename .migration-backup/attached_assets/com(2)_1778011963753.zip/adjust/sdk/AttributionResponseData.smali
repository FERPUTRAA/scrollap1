.class public Lcom/adjust/sdk/AttributionResponseData;
.super Lcom/adjust/sdk/ResponseData;


# instance fields
.field public deeplink:Landroid/net/Uri;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/adjust/sdk/ResponseData;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method
