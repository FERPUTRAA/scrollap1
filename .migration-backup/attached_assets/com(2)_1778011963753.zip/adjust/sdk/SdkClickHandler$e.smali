.class public final Lcom/adjust/sdk/SdkClickHandler$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/SdkClickHandler;->sendNextSdkClickI()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/ActivityPackage;

.field public final synthetic b:Lcom/adjust/sdk/SdkClickHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/SdkClickHandler;Lcom/adjust/sdk/ActivityPackage;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/SdkClickHandler$e;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/adjust/sdk/SdkClickHandler$e;->a:Lcom/adjust/sdk/ActivityPackage;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$e;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/SdkClickHandler$e;->a:Lcom/adjust/sdk/ActivityPackage;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/adjust/sdk/SdkClickHandler;->access$500(Lcom/adjust/sdk/SdkClickHandler;Lcom/adjust/sdk/ActivityPackage;)V

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/SdkClickHandler$e;->b:Lcom/adjust/sdk/SdkClickHandler;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/SdkClickHandler;->access$200(Lcom/adjust/sdk/SdkClickHandler;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
