.class public final enum Lcom/adjust/sdk/ActivityKind;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/adjust/sdk/ActivityKind;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/adjust/sdk/ActivityKind;

.field public static final enum AD_REVENUE:Lcom/adjust/sdk/ActivityKind;

.field public static final enum ATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

.field public static final enum CLICK:Lcom/adjust/sdk/ActivityKind;

.field public static final enum DISABLE_THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

.field public static final enum EVENT:Lcom/adjust/sdk/ActivityKind;

.field public static final enum GDPR:Lcom/adjust/sdk/ActivityKind;

.field public static final enum INFO:Lcom/adjust/sdk/ActivityKind;

.field public static final enum MEASUREMENT_CONSENT:Lcom/adjust/sdk/ActivityKind;

.field public static final enum REATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

.field public static final enum REVENUE:Lcom/adjust/sdk/ActivityKind;

.field public static final enum SESSION:Lcom/adjust/sdk/ActivityKind;

.field public static final enum SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

.field public static final enum THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

.field public static final enum UNKNOWN:Lcom/adjust/sdk/ActivityKind;


# direct methods
.method public static constructor <clinit>()V
    .locals 17

    new-instance v0, Lcom/adjust/sdk/ActivityKind;

    const-string v1, "NOsUsNN"

    const-string v1, "NOsNKUN"

    const-string v1, "KNOmWUN"

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/adjust/sdk/ActivityKind;->UNKNOWN:Lcom/adjust/sdk/ActivityKind;

    new-instance v1, Lcom/adjust/sdk/ActivityKind;

    const-string v3, "ENImOSS"

    const-string v3, "SINOoSS"

    const-string v3, "SESSION"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lcom/adjust/sdk/ActivityKind;->SESSION:Lcom/adjust/sdk/ActivityKind;

    new-instance v3, Lcom/adjust/sdk/ActivityKind;

    const-string v5, "bNETE"

    const-string v5, "EENTo"

    const-string v5, "TuNVE"

    const-string v5, "EVENT"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lcom/adjust/sdk/ActivityKind;->EVENT:Lcom/adjust/sdk/ActivityKind;

    new-instance v5, Lcom/adjust/sdk/ActivityKind;

    const-string v7, "KIpbC"

    const-string v7, "bKLIC"

    const-string v7, "CIKqL"

    const-string v7, "CLICK"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lcom/adjust/sdk/ActivityKind;->CLICK:Lcom/adjust/sdk/ActivityKind;

    new-instance v7, Lcom/adjust/sdk/ActivityKind;

    const-string v9, "ITsTNABURIT"

    const-string v9, "TTNRABuITUI"

    const-string v9, "IATmUTRTBON"

    const-string v9, "ATTRIBUTION"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lcom/adjust/sdk/ActivityKind;->ATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

    new-instance v9, Lcom/adjust/sdk/ActivityKind;

    const-string v11, "RENUoEp"

    const-string/jumbo v11, "pEUENER"

    const-string v11, "UEENRbV"

    const-string v11, "REVENUE"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lcom/adjust/sdk/ActivityKind;->REVENUE:Lcom/adjust/sdk/ActivityKind;

    new-instance v11, Lcom/adjust/sdk/ActivityKind;

    const-string v13, "TBTOqNuIIREUT"

    const-string v13, "UTERNTITqBORI"

    const-string v13, "TAUBIREpIOTTR"

    const-string v13, "REATTRIBUTION"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lcom/adjust/sdk/ActivityKind;->REATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

    new-instance v13, Lcom/adjust/sdk/ActivityKind;

    const-string v15, "NOFI"

    const-string v15, "NIFO"

    const-string v15, "OFIN"

    const-string v15, "INFO"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v13, Lcom/adjust/sdk/ActivityKind;->INFO:Lcom/adjust/sdk/ActivityKind;

    new-instance v15, Lcom/adjust/sdk/ActivityKind;

    const-string v14, "RPDG"

    const-string v14, "RDPG"

    const-string v14, "DPRG"

    const-string v14, "GDPR"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v15, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    new-instance v14, Lcom/adjust/sdk/ActivityKind;

    const-string v12, "EAER_UDEqV"

    const-string v12, "R_sEUEDAVE"

    const-string v12, "VEsEREUDA_"

    const-string v12, "AD_REVENUE"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v14, Lcom/adjust/sdk/ActivityKind;->AD_REVENUE:Lcom/adjust/sdk/ActivityKind;

    new-instance v12, Lcom/adjust/sdk/ActivityKind;

    const-string v10, "DISABLE_THIRD_PARTY_SHARING"

    const/16 v8, 0xa

    invoke-direct {v12, v10, v8}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v12, Lcom/adjust/sdk/ActivityKind;->DISABLE_THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    new-instance v10, Lcom/adjust/sdk/ActivityKind;

    const-string v8, "RSPmOmUNISTI"

    const-string v8, "ROPmNUSIITBS"

    const-string v8, "SNIToIBCUPOR"

    const-string v8, "SUBSCRIPTION"

    const/16 v6, 0xb

    invoke-direct {v10, v8, v6}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v10, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    new-instance v8, Lcom/adjust/sdk/ActivityKind;

    const-string v6, "_AIRoSDTRY_HINHTPRG"

    const-string v6, "RTHSDbARGYA_HRTINI_"

    const-string v6, "THIRD_PARTY_SHARING"

    const/16 v4, 0xc

    invoke-direct {v8, v6, v4}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lcom/adjust/sdk/ActivityKind;->THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    new-instance v6, Lcom/adjust/sdk/ActivityKind;

    const-string v4, "TMbAENuE_UMTESSOENC"

    const-string v4, "AECEEbNNS_EUTONMTMS"

    const-string v4, "ENENCTUp_MMERETASNO"

    const-string v4, "MEASUREMENT_CONSENT"

    const/16 v2, 0xd

    invoke-direct {v6, v4, v2}, Lcom/adjust/sdk/ActivityKind;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lcom/adjust/sdk/ActivityKind;->MEASUREMENT_CONSENT:Lcom/adjust/sdk/ActivityKind;

    const/16 v4, 0xe

    new-array v4, v4, [Lcom/adjust/sdk/ActivityKind;

    const/16 v16, 0x0

    aput-object v0, v4, v16

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v0, 0x2

    aput-object v3, v4, v0

    const/4 v0, 0x3

    aput-object v5, v4, v0

    const/4 v0, 0x4

    aput-object v7, v4, v0

    const/4 v0, 0x5

    aput-object v9, v4, v0

    const/4 v0, 0x6

    aput-object v11, v4, v0

    const/4 v0, 0x7

    aput-object v13, v4, v0

    const/16 v0, 0x8

    aput-object v15, v4, v0

    const/16 v0, 0x9

    aput-object v14, v4, v0

    const/16 v0, 0xa

    aput-object v12, v4, v0

    const/16 v0, 0xb

    aput-object v10, v4, v0

    const/16 v0, 0xc

    aput-object v8, v4, v0

    aput-object v6, v4, v2

    sput-object v4, Lcom/adjust/sdk/ActivityKind;->$VALUES:[Lcom/adjust/sdk/ActivityKind;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static fromString(Ljava/lang/String;)Lcom/adjust/sdk/ActivityKind;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b~/~l @~q~b/~n~~~4  o@i@@l ~dit ~@@r@~@yo~@a ~ ffK ~~ @ ~-~  bM@@o~otm @@So~@i~@c.@~u@s v 1 o @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-string/jumbo v0, "sssisoe"

    const-string/jumbo v0, "session"

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->SESSION:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "entmu"

    const-string v0, "eunet"

    const/4 v2, 0x4

    const-string/jumbo v0, "nveto"

    const-string v0, "event"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->EVENT:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x2

    return-object p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, "bpckl"

    const-string v0, "clpkc"

    const-string/jumbo v0, "iuclk"

    const-string v0, "click"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->CLICK:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "tttoqnupbai"

    const-string/jumbo v0, "oauntrbtqti"

    const/4 v2, 0x3

    const-string v0, "attribution"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->ATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "onif"

    const-string/jumbo v0, "onfi"

    const/4 v2, 0x6

    const-string/jumbo v0, "nfoi"

    const-string/jumbo v0, "info"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_4

    const/4 v1, 0x3

    move v2, v1

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->INFO:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "gdpr"

    const-string/jumbo v0, "pdgr"

    const/4 v2, 0x4

    const-string v0, "dprg"

    const-string v0, "gdpr"

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz v0, :cond_5

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x7

    return-object p0

    :cond_5
    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string/jumbo v0, "rbrhaes_qlap_tndgtrshdiaiis"

    const-string v0, "_rsgiahast_irpdyahsebrldtni"

    const/4 v2, 0x2

    const-string v0, "g_sspdairtiabehayds_n_hrilr"

    const-string v0, "disable_third_party_sharing"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_6

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->DISABLE_THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0

    :cond_6
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "rmemne_edv"

    const-string v0, "enamre_vde"

    const/4 v2, 0x2

    const-string/jumbo v0, "udeeo_narv"

    const-string v0, "ad_revenue"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_7

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->AD_REVENUE:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0

    :cond_7
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "iupiobcrosns"

    const-string/jumbo v0, "stisoucopirn"

    const/4 v2, 0x4

    const-string/jumbo v0, "uoiirbupcstn"

    const-string/jumbo v0, "subscription"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_8

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object p0

    :cond_8
    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo v0, "syiirahpraphtg_nbdr"

    const-string/jumbo v0, "p_taibdrygrsihnrhta"

    const/4 v2, 0x6

    const-string/jumbo v0, "third_party_sharing"

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_9

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->THIRD_PARTY_SHARING:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0

    :cond_9
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "nctnrueuqsoamstmn_e"

    const-string v0, "ent_tsuemsrmaocnenu"

    const/4 v2, 0x0

    const-string v0, "eosesstn_ermcennuat"

    const-string/jumbo v0, "measurement_consent"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p0, :cond_a

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->MEASUREMENT_CONSENT:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_a
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object p0, Lcom/adjust/sdk/ActivityKind;->UNKNOWN:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/adjust/sdk/ActivityKind;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-class v0, Lcom/adjust/sdk/ActivityKind;

    const-class v0, Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    check-cast p0, Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lcom/adjust/sdk/ActivityKind;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->$VALUES:[Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/adjust/sdk/ActivityKind;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, [Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/adjust/sdk/ActivityKind$a;->a:[I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    aget v0, v0, v1

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v0, "opwmnun"

    const-string/jumbo v0, "pwknuno"

    const/4 v3, 0x5

    const-string/jumbo v0, "nnwkoon"

    const-string/jumbo v0, "unknown"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :pswitch_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "eqsanbmuerseetmon_n"

    const-string v0, "eaumnes_qsroetntnem"

    const/4 v3, 0x5

    const-string/jumbo v0, "ntensounraeucstem_e"

    const-string/jumbo v0, "measurement_consent"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :pswitch_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "spt_ahiphidt_nrasrr"

    const-string/jumbo v0, "p_sitaartdhrynhrsi_"

    const/4 v3, 0x2

    const-string v0, "_payigh_qhtidatnrsr"

    const-string/jumbo v0, "third_party_sharing"

    const/4 v3, 0x4

    return-object v0

    :pswitch_2
    const/4 v3, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "ispmtnurcibo"

    const/4 v3, 0x1

    const-string/jumbo v0, "stsuprsioibn"

    const-string/jumbo v0, "subscription"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :pswitch_3
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, "eromduea_v"

    const-string/jumbo v0, "ndauoerve_"

    const/4 v3, 0x7

    const-string v0, "e_reoednva"

    const-string v0, "ad_revenue"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :pswitch_4
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v0, "sh_drbiaglayteabspntirhbr__"

    const-string v0, "atpy_bi_ihnedratlsrghrbsa_d"

    const/4 v3, 0x1

    const-string v0, "ditlgauinrdea_srht__rbyiasp"

    const-string v0, "disable_third_party_sharing"

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object v0

    :pswitch_5
    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string v0, "gprd"

    const-string v0, "gpdr"

    const/4 v3, 0x4

    const-string/jumbo v0, "rdgp"

    const-string v0, "gdpr"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :pswitch_6
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "foni"

    const-string/jumbo v0, "info"

    const/4 v3, 0x3

    const-string v0, "fnio"

    const-string/jumbo v0, "info"

    const/4 v3, 0x3

    return-object v0

    :pswitch_7
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "uobrniuptat"

    const-string v0, "bntriouttua"

    const/4 v3, 0x1

    const-string/jumbo v0, "niatttuiqbr"

    const-string v0, "attribution"

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object v0

    :pswitch_8
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v0, "piscc"

    const-string/jumbo v0, "kcpic"

    const/4 v3, 0x0

    const-string v0, "cikmc"

    const-string v0, "click"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :pswitch_9
    const/4 v3, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "teevo"

    const-string v0, "event"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :pswitch_a
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v0, "insosbq"

    const-string/jumbo v0, "iqnosss"

    const/4 v3, 0x6

    const-string/jumbo v0, "ssoesiu"

    const-string/jumbo v0, "session"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
