.class public Lcom/adjust/sdk/SdkClickResponseData;
.super Lcom/adjust/sdk/ResponseData;


# instance fields
.field public clickTime:J

.field public clickTimeServer:J

.field public googlePlayInstant:Ljava/lang/Boolean;

.field public installBegin:J

.field public installBeginServer:J

.field public installReferrer:Ljava/lang/String;

.field public installVersion:Ljava/lang/String;

.field public isInstallReferrer:Z

.field public referrerApi:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/adjust/sdk/ResponseData;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
