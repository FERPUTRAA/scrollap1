.class public Lcom/adjust/sdk/AdjustSigner;
.super Ljava/lang/Object;


# static fields
.field private static volatile signerInstance:Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static disableSigning(Lcom/adjust/sdk/ILogger;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "b@sbc/~n/o@M~ ~t dry~@s@~@~~b~to ~-@4~~~i@@ff l~uS~~@@ @~i~~@   @ a@io .1 ~@ o o o m~ ~@@~Kl@v@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/adjust/sdk/AdjustSigner;->getSignerInstance()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object v0, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    sget-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "aebmlniSgiinsg"

    const-string/jumbo v2, "iesSnnigiagbsl"

    const/4 v6, 0x2

    const-string/jumbo v2, "isinoebdignagl"

    const-string v2, "disableSigning"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v1, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    aput-object v1, v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v0, "enbreb]seInininl(egcodv%rvigng[  Siiranrroe a)des mg  i"

    const-string v0, " nimeigeescnnlrrgesd g(niIe Sivn )dgie r%rnrk a]voibao["

    const/4 v6, 0x6

    const-string/jumbo v0, "ile(d)uoSe%ebra  knernirgcsro]gnrnig iI[a sni v iSedvgn"

    const-string v0, "Invoking Signer disableSigning() received an error [%s]"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {p0, v0, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v6, 0x4

    return-void
.end method

.method public static enableSigning(Lcom/adjust/sdk/ILogger;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {}, Lcom/adjust/sdk/AdjustSigner;->getSignerInstance()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget-object v0, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x0

    move v6, v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v2, "bggiennpSeoia"

    const-string v2, "beneoiglSngia"

    const/4 v6, 0x3

    const-string v2, "gbniengeqnial"

    const-string v2, "enableSigning"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v1, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    aput-object v1, v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v0, " essb%v)lni( ] [rIek rne agnrerngei vidoecrnSSigbonnag"

    const-string v0, "gn(c)b SaeilsgSn[ Ioe i n%rnri]erbnrvenedvkrge ienga o"

    const-string/jumbo v0, "vobmeve) r niiin Sr]nakIdreg[ngnon( %aSggcnesliieerre "

    const-string v0, "Invoking Signer enableSigning() received an error [%s]"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {p0, v0, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void
.end method

.method private static getSignerInstance()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-class v0, Lcom/adjust/sdk/AdjustSigner;

    const-class v0, Lcom/adjust/sdk/AdjustSigner;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const-string v1, "eks.os.agucmddiSisgj.rtn."

    const-string/jumbo v1, "mdktsau.oigse..nsg.rdjcSi"

    const/4 v3, 0x7

    const-string v1, ".dsicbsggnikmjSd.uaoset.."

    const-string v1, "com.adjust.sdk.sig.Signer"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/adjust/sdk/Reflection;->createDefaultInstance(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public static onResume(Lcom/adjust/sdk/ILogger;)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {}, Lcom/adjust/sdk/AdjustSigner;->getSignerInstance()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v0, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    sget-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const-string v2, "Ropmenuu"

    const-string/jumbo v2, "unoesRmp"

    const/4 v6, 0x3

    const-string v2, "eenuoRsp"

    const-string/jumbo v2, "onResume"

    const/4 v5, 0x2

    and-int/2addr v6, v5

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    aput-object v1, v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v0, " ]seeuv%qgooeerIcgdivsqeme)r[  iin rRrSor n(annne"

    const-string/jumbo v0, "vr%dsegiqmvonnai eooSRrr( ninseuIen re[ecg)  r e]"

    const/4 v6, 0x7

    const-string v0, "g)s[eumidns rneo v rarreokcnI Srie g s(nevn]e%eoR"

    const-string v0, "Invoking Signer onResume() received an error [%s]"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {p0, v0, v2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method public static sign(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lcom/adjust/sdk/ILogger;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Landroid/content/Context;",
            "Lcom/adjust/sdk/ILogger;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x6

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x3

    invoke-static {}, Lcom/adjust/sdk/AdjustSigner;->getSignerInstance()V

    const/4 v9, 0x5

    sget-object v1, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const/4 v9, 0x3

    if-nez v1, :cond_0

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x5

    const/4 v1, 0x1

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v3, 0x2

    :try_start_0
    const/4 v9, 0x3

    sget-object v4, Lcom/adjust/sdk/AdjustSigner;->signerInstance:Ljava/lang/Object;

    const-string v5, "gnis"

    const-string/jumbo v5, "igsn"

    const-string/jumbo v5, "nigs"

    const-string/jumbo v5, "sign"

    const/4 v9, 0x2

    const/4 v6, 0x4

    const/4 v9, 0x7

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v9, 0x4

    const-class v8, Landroid/content/Context;

    const-class v8, Landroid/content/Context;

    const-class v8, Landroid/content/Context;

    const/4 v9, 0x3

    aput-object v8, v7, v2

    const/4 v9, 0x2

    const-class v8, Ljava/util/Map;

    const-class v8, Ljava/util/Map;

    const-class v8, Ljava/util/Map;

    const-class v8, Ljava/util/Map;

    const/4 v9, 0x5

    aput-object v8, v7, v1

    const/4 v9, 0x1

    aput-object v0, v7, v3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    aput-object v0, v7, v8

    const/4 v9, 0x1

    new-array v0, v6, [Ljava/lang/Object;

    const/4 v9, 0x0

    aput-object p3, v0, v2

    aput-object p0, v0, v1

    const/4 v9, 0x3

    aput-object p1, v0, v3

    const/4 v9, 0x3

    aput-object p2, v0, v8

    const/4 v9, 0x1

    invoke-static {v4, v5, v7, v0}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v9, 0x5

    new-array p2, v3, [Ljava/lang/Object;

    const/4 v9, 0x0

    aput-object p1, p2, v2

    const/4 v9, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    aput-object p0, p2, v1

    const/4 v9, 0x4

    const-string/jumbo p0, "n  mS%rsfiagiI (s cen[endrrr %virenv]eoo)r gieosks g"

    const-string p0, "esse  rroisi%rrneogig[co den]rks  ig(ae nvfn% Ir Sv)"

    const-string p0, "eIeoo r gnisdrkr fgnio%nosrvrn(eier [gav cs  )nei ]%"

    const-string p0, "Invoking Signer sign() for %s received an error [%s]"

    invoke-interface {p4, p0, p2}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v9, 0x6

    return-void
.end method
