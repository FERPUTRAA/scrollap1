.class public final Lcom/adjust/sdk/ActivityHandler$f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->launchAttributionResponseTasks(Lcom/adjust/sdk/AttributionResponseData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/AttributionResponseData;

.field public final synthetic b:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/AttributionResponseData;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$f;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput-object p2, p0, Lcom/adjust/sdk/ActivityHandler$f;->a:Lcom/adjust/sdk/AttributionResponseData;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i@s~ fv~K@m~St   ~. o~ @~~/on @ b@@@do~~@ @  /ubM~@s~o4-~ @@ cf  ~@ia@ @@~ @ytb~~r@@~l~oo~@~1i~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$f;->b:Lcom/adjust/sdk/ActivityHandler;

    const/4 v2, 0x7

    move v3, v2

    iget-object v1, p0, Lcom/adjust/sdk/ActivityHandler$f;->a:Lcom/adjust/sdk/AttributionResponseData;

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/adjust/sdk/ActivityHandler;->access$2100(Lcom/adjust/sdk/ActivityHandler;Lcom/adjust/sdk/AttributionResponseData;)V

    const/4 v3, 0x0

    return-void
.end method
