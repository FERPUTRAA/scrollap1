.class public Lcom/adjust/sdk/InstallReferrer;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# static fields
.field private static final PACKAGE_BASE_NAME:Ljava/lang/String; = "com.android.installreferrer."

.field private static final STATUS_DEVELOPER_ERROR:I = 0x3

.field private static final STATUS_FEATURE_NOT_SUPPORTED:I = 0x2

.field private static final STATUS_OK:I = 0x0

.field private static final STATUS_SERVICE_DISCONNECTED:I = -0x1

.field private static final STATUS_SERVICE_UNAVAILABLE:I = 0x1


# instance fields
.field private context:Landroid/content/Context;

.field private executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

.field private logger:Lcom/adjust/sdk/ILogger;

.field private playInstallReferrer:Ljava/lang/Object;

.field private final referrerCallback:Lcom/adjust/sdk/InstallReferrerReadListener;

.field private referrerClient:Ljava/lang/Object;

.field private retries:I

.field private retryTimer:Lcom/adjust/sdk/scheduler/TimerOnce;

.field private retryWaitTime:I

.field private final shouldTryToRead:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/adjust/sdk/InstallReferrerReadListener;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/16 v0, 0xbb8

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput v0, p0, Lcom/adjust/sdk/InstallReferrer;->retryWaitTime:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/adjust/sdk/InstallReferrer;->createInstallReferrer(Landroid/content/Context;Lcom/adjust/sdk/InstallReferrerReadListener;Lcom/adjust/sdk/ILogger;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->playInstallReferrer:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->context:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->shouldTryToRead:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    const/4 p1, 0x5

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput p1, p0, Lcom/adjust/sdk/InstallReferrer;->retries:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Lcom/adjust/sdk/scheduler/TimerOnce;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Lcom/adjust/sdk/InstallReferrer$a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/adjust/sdk/InstallReferrer$a;-><init>(Lcom/adjust/sdk/InstallReferrer;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "elsfanrsrleIsRe"

    const-string v1, "aeserrsnlRIeflr"

    const/4 v3, 0x6

    const-string/jumbo v1, "ralmtnRefrerseI"

    const-string v1, "InstallReferrer"

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-direct {p1, v0, v1}, Lcom/adjust/sdk/scheduler/TimerOnce;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->retryTimer:Lcom/adjust/sdk/scheduler/TimerOnce;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->referrerCallback:Lcom/adjust/sdk/InstallReferrerReadListener;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p1, Lcom/adjust/sdk/scheduler/SingleThreadCachedScheduler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, v1}, Lcom/adjust/sdk/scheduler/SingleThreadCachedScheduler;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public static synthetic access$000(Lcom/adjust/sdk/InstallReferrer;Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/adjust/sdk/InstallReferrer;->invokeI(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static synthetic access$100(Lcom/adjust/sdk/InstallReferrer;)Lcom/adjust/sdk/ILogger;
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    iget-object p0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method private closeReferrerClient()V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->referrerClient:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x0

    move v6, v1

    move v6, v1

    const/4 v7, 0x5

    const/4 v2, 0x0

    move v6, v2

    move v6, v2

    :try_start_0
    const/4 v7, 0x3

    const-string v3, "domnooeicnten"

    const-string/jumbo v3, "ntnmonnedieco"

    const/4 v7, 0x5

    const-string/jumbo v3, "netniboCdecnn"

    const-string v3, "endConnection"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v0, v3, v1, v4}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v3, " lecicuoAenrRlPnetroseI fIcntoon r lda"

    const-string/jumbo v3, "nrPnocRselcA noer ldtlreIaoI ecsfntio "

    const/4 v7, 0x4

    const-string/jumbo v3, "oct seeponlIAerIlnotindasrreec c nlRP "

    const-string v3, "Install Referrer API connection closed"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v7, 0x1

    invoke-interface {v0, v3, v4}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x5

    const/4 v4, 0x2

    const/4 v7, 0x4

    move v6, v4

    move v6, v4

    const/4 v7, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    aput-object v5, v4, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    aput-object v0, v4, v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string v0, "closeReferrerClient error (%s) thrown by (%s)"

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-interface {v3, v0, v4}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-object v1, p0, Lcom/adjust/sdk/InstallReferrer;->referrerClient:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-void
.end method

.method private createInstallReferrer(Landroid/content/Context;Lcom/adjust/sdk/InstallReferrerReadListener;Lcom/adjust/sdk/ILogger;)Ljava/lang/Object;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v0, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-array v1, v0, [Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x0

    aput-object v2, v1, v3

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-class v2, Lcom/adjust/sdk/InstallReferrerReadListener;

    const-class v2, Lcom/adjust/sdk/InstallReferrerReadListener;

    const/4 v7, 0x1

    const-class v2, Lcom/adjust/sdk/InstallReferrerReadListener;

    const-class v2, Lcom/adjust/sdk/InstallReferrerReadListener;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    aput-object v2, v1, v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-class v2, Lcom/adjust/sdk/ILogger;

    const-class v2, Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v5, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    aput-object v2, v1, v5

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v6, 0x4

    move v7, v6

    aput-object p1, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    aput-object p2, v0, v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    aput-object p3, v0, v5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo p1, "pscuslmaqRtdstell.rn.rokedar.yfea.b"

    const-string p1, ".emrpbRyorlsjleaest.ncrk.adfd.utsla"

    const/4 v7, 0x3

    const-string/jumbo p1, "lrs.m.kp.uoRtlaarnerdasses.ecIydtlj"

    const-string p1, "com.adjust.sdk.play.InstallReferrer"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1, v1, v0}, Lcom/adjust/sdk/Reflection;->createInstance(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object p1
.end method

.method private createInstallReferrerClient(Landroid/content/Context;)Ljava/lang/Object;
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v0, 0x0

    const/4 v9, 0x2

    const/4 v1, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v2, 0x1

    const/4 v9, 0x6

    const/4 v3, 0x3

    const/4 v9, 0x2

    const/4 v3, 0x0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string v4, "fdtmrpaseen.rlRelmaaaur.iroleiCfcrneitl.inneorrtresI."

    const-string/jumbo v4, "rl.ecausdarrm.apC.neItorrienfrloilietlsa.Rirntdfreeen"

    const/4 v9, 0x4

    const-string/jumbo v4, "recro.tmf.oRIensdeili.aneirellinnCrserfl.adtaaerlpror"

    const-string v4, "com.android.installreferrer.api.InstallReferrerClient"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string/jumbo v5, "iweplbdBue"

    const-string v5, "dlrBweepiu"

    const/4 v9, 0x7

    const-string v5, "ereuinuwdl"

    const-string/jumbo v5, "newBuilder"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-array v6, v2, [Ljava/lang/Class;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v9, 0x1

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    aput-object v7, v6, v3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-array v7, v2, [Ljava/lang/Object;

    const/4 v9, 0x6

    aput-object p1, v7, v3

    const/4 v9, 0x7

    invoke-static {v4, v5, v6, v7}, Lcom/adjust/sdk/Reflection;->invokeStaticMethod(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v4, "bdplu"

    const-string v4, "dbuql"

    const/4 v9, 0x2

    const-string/jumbo v4, "ildqb"

    const-string v4, "build"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-array v5, v3, [Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {p1, v4, v0, v5}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-object p1

    :catch_0
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    aput-object v5, v1, v3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    aput-object p1, v1, v2

    const/4 v9, 0x2

    const-string/jumbo p1, "rts rea Cfrrst%noi(es eerleoR%)etrr lns)Ifa(clmr"

    const-string p1, "createInstallReferrerClient error (%s) from (%s)"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-interface {v4, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_0

    :catch_1
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v4, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    aput-object v5, v1, v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    aput-object p1, v1, v2

    const/4 v9, 0x7

    const-string p1, " r mnlrornrea% r l rsostoefee tRwi)sdp%eniy Ite b(thcj()ngast"

    const-string/jumbo p1, "nRsidw srn nsyrote fa( ajeortlbrtieot%(rhenelcIs%t)g p r ne) "

    const/4 v9, 0x2

    const-string/jumbo p1, "wtslo rjscl %irpe)ne(n eyrtoroeart(g ndI)f  sRhet neba%ttn io"

    const-string p1, "InstallReferrer not integrated in project (%s) thrown by (%s)"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {v4, p1, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-object v0
.end method

.method private createProxyInstallReferrerStateListener(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    aput-object p1, v2, v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1, v2, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_1

    :catch_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "yllIrbntsstm omee dtl epsfgxarreruR Nluoe apa"

    const-string/jumbo v1, "u rmexeetlf o plasdyaIrsorseN tnaeplg lrmuRrt"

    const-string/jumbo v1, "or pfuulxtleeuargspetle  raIy rrlNanm edostRs"

    const-string v1, "Null argument passed to InstallReferrer proxy"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p1, v1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :catch_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x7

    const-string/jumbo v1, "rerItiaptrosves ctrpnr perxaisa ge nrloeiaoireRytnfllt"

    const-string v1, "InstallReferrer proxy violating parameter restrictions"

    const/4 v4, 0x7

    invoke-interface {p1, v1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x0

    :goto_1
    const/4 v4, 0x0

    return-object p1
.end method

.method private getBooleanGooglePlayInstantParam(Ljava/lang/Object;)Ljava/lang/Boolean;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "ogImotolegysnatPaatrPalGn"

    const/4 v4, 0x1

    const-string/jumbo v1, "otrnosaaqaaegIlmygttPGelP"

    const-string v1, "getGooglePlayInstantParam"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x1

    invoke-static {p1, v1, v0, v2}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p1

    :catch_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v0
.end method

.method private getInstallBeginTimestampSeconds(Ljava/lang/Object;)J
    .locals 8

    const/4 v7, 0x0

    const-wide/16 v0, -0x1

    const/4 v7, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    if-nez p1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-wide v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v3, "lssoslsSeitaIenBtdbmgimeTencagt"

    const-string/jumbo v3, "maotsbSgeBsslltiepdaienegnmtcTI"

    const/4 v7, 0x4

    const-string v3, "gmBmesnieapgilettaceTstmoIdsnSl"

    const-string v3, "getInstallBeginTimestampSeconds"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    or-int/2addr v7, v6

    invoke-static {p1, v3, v5, v4}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    check-cast p1, Ljava/lang/Long;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-wide v0

    :catch_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v4, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    aput-object v5, v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    aput-object p1, v4, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string p1, ")rh(Bnuat% iglcIrsiemw r te Seoss)(ynnomteessartTdlpb%no "

    const/4 v7, 0x7

    const-string p1, "g (roI netonnoishe sa)deersimwrpct%So%Bgy ret(lasbn ts)Tm"

    const-string p1, "getInstallBeginTimestampSeconds error (%s) thrown by (%s)"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v3, p1, v4}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-wide v0
.end method

.method private getInstallBeginTimestampServerSeconds(Ljava/lang/Object;)J
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    if-nez p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-wide v0

    :cond_0
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "siiIebtSeslonetnrvsalprenSpecmtdaBmTg"

    const-string v2, "dettmvsptrsllrepnganoSTBesneiacSeiIem"

    const/4 v6, 0x4

    const-string v2, "dcnslputggelmioseenrtsairtIaBvSenemTS"

    const-string v2, "getInstallBeginTimestampServerSeconds"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    invoke-static {p1, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    check-cast p1, Ljava/lang/Long;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-wide v0
.end method

.method private getInstallReferrer()Ljava/lang/Object;
    .locals 8

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->referrerClient:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v3, "qlIafRrplreeegrtts"

    const-string/jumbo v3, "rtaerrefqeIegltsRl"

    const/4 v7, 0x3

    const-string v3, "fntgreeIqsetaRrell"

    const-string v3, "getInstallReferrer"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v3, v1, v4}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object v0

    :catch_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v4, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    aput-object v5, v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    aput-object v0, v4, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo v0, "rls(eorfs))rtbtRrg%r%rswo( ser  Itaneesy ehn"

    const-string v0, "ens)rb l%ehr( ywse(ro tsrret)r%nsg oe aRtfIr"

    const/4 v7, 0x6

    const-string v0, ")osmrgryo%eR snelertf( rtsebwrt%( r)arl Ihe "

    const-string v0, "getInstallReferrer error (%s) thrown by (%s)"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v3, v0, v4}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-object v1
.end method

.method private getInstallReferrerStateListenerClass()Ljava/lang/Class;
    .locals 7

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const-class v0, Lcom/android/installreferrer/api/InstallReferrerStateListener;

    const-class v0, Lcom/android/installreferrer/api/InstallReferrerStateListener;

    const/4 v6, 0x5

    const-class v0, Lcom/android/installreferrer/api/InstallReferrerStateListener;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    aput-object v3, v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-object v0, v2, v3

    const/4 v5, 0x7

    const/4 v5, 0x0

    const-string/jumbo v0, "lorlortesStieamonae%mrreRrt s rsItreglt(e ssfa(e)fCs)re%L"

    const-string/jumbo v0, "tr)m %lRtrs(oselSieaatLeeletrsms rIseCtrff(arro)e eg %rns"

    const/4 v6, 0x1

    const-string v0, "i s%(b ffrroeL gesr rreeeatrSImaelest%ls)rRonl(Ctrtat)ses"

    const-string v0, "getInstallReferrerStateListenerClass error (%s) from (%s)"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v1, v0, v2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v0
.end method

.method private getReferrerClickTimestampSeconds(Ljava/lang/Object;)J
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v7, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-nez p1, :cond_0

    return-wide v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v3, "tCresRuemSeetrTkcnfmoegcsiadreio"

    const-string v3, "eimsoeeaiSrdReckoeCrnmfeptTstgcr"

    const/4 v7, 0x0

    const-string/jumbo v3, "kfoTreepeRmSsarretgcdcCnlmitpsei"

    const-string v3, "getReferrerClickTimestampSeconds"

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {p1, v3, v5, v4}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x0

    check-cast p1, Ljava/lang/Long;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-wide v0

    :catch_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v4, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    aput-object v5, v4, v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput-object p1, v4, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo p1, "rnfSTbioqc onewsesRrrlarty)rke%g%(m)setmh Csrrcdp tee b oi"

    const-string/jumbo p1, "piTcrbSatsfen rekRwm%rt y)nbrderoC oigso cher((lesre%ms )t"

    const-string/jumbo p1, "t saso ne hsrCtsdpiemgbceef% wy()t leeTRirorro(rmncrs)%erk"

    const-string p1, "getReferrerClickTimestampSeconds error (%s) thrown by (%s)"

    const/4 v7, 0x1

    invoke-interface {v3, p1, v4}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-wide v0
.end method

.method private getReferrerClickTimestampServerSeconds(Ljava/lang/Object;)J
    .locals 7

    const/4 v6, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-wide v0

    :cond_0
    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v2, "eafdCeumgtTiprRsmcrreleekrnsitvocSeeSe"

    const/4 v6, 0x6

    const-string v2, "egimemaliSTeRnrCSrtetcdvocrpsrmrseefee"

    const-string v2, "getReferrerClickTimestampServerSeconds"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p1, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast p1, Ljava/lang/Long;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-wide v0
.end method

.method private getStringInstallReferrer(Ljava/lang/Object;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    xor-int/2addr v6, v0

    const/4 v5, 0x2

    move v6, v5

    if-nez p1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x3

    move v6, v5

    const/4 v1, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "apeeoIleefsrrnRtrl"

    const-string v2, "esnteIfprrRelrlage"

    const/4 v6, 0x4

    const-string/jumbo v2, "rReltbsIfrertnleae"

    const-string v2, "getInstallReferrer"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1, v2, v0, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object p1

    :catch_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    aput-object v4, v3, v1

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput-object p1, v3, v1

    const/4 v6, 0x2

    const-string p1, " lqeetur er%r%rlSs(rneo)RwnrsghtoIt (rir)n bagt se"

    const-string/jumbo p1, "tr thrsRq%r% se tsgeatewoof e)(eliSbrIrrrngnnl)(r "

    const/4 v6, 0x6

    const-string/jumbo p1, "rg gSeRpns aonrrriy)el stne%I (t htf)%rerbrwt(olre"

    const-string p1, "getStringInstallReferrer error (%s) thrown by (%s)"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v2, p1, v3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x0

    or-int/2addr v6, v5

    return-object v0
.end method

.method private getStringInstallVersion(Ljava/lang/Object;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v1, "ietsnVIoqtnreslgs"

    const-string v1, "gtsIlsstoerlVnnie"

    const/4 v4, 0x7

    const-string/jumbo v1, "nnsssVagIotlletei"

    const-string v1, "getInstallVersion"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, v1, v0, v2}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object p1

    :catch_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method private invokeI(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 p1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x1

    xor-int/2addr v8, v7

    if-nez p2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v0, "oRhme nrrslmuoneflnevlieedmratlIt "

    const-string/jumbo v0, "nIemee trf lvoenRhildamerr ntlulos"

    const/4 v8, 0x4

    const-string/jumbo v0, "norIovlRllflrotrni n h tkseeadeeeu"

    const-string v0, "InstallReferrer invoke method null"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-interface {p2, v0, p3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object p1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez p2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string/jumbo v0, "nltrhblod se Ilkunam  rfeetmaonevlenioR"

    const-string/jumbo v0, "inamonfehleero  ul er tmkoealnvtIsrlnRd"

    const/4 v8, 0x6

    const-string v0, "ednl auaelltleoruRteorhmn ni s Inevekfm"

    const-string v0, "InstallReferrer invoke method name null"

    invoke-interface {p2, v0, p3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-object p1

    :cond_1
    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    aput-object p2, v3, v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const-string/jumbo v4, "nofeirspktIe%eeemhrtos ndRvral: nlbaem"

    const-string v4, "aoht%bIeie eRernrltnmandee  or:ssvmkfl"

    const/4 v8, 0x3

    const-string v4, "almn fmrq tstRovee:iodrn %Ieereklsha n"

    const-string v4, "InstallReferrer invoke method name: %s"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v1, v4, v3}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    if-nez p3, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object p3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v7, 0x0

    const-string v3, "fes ksIeunlre llsRtn arugvorlien"

    const-string/jumbo v3, "l nuaeuvesrnnfsotrRel lrIek girl"

    const/4 v8, 0x7

    const-string v3, "InstallReferrer invoke args null"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {p3, v3, v1}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    new-array p3, v0, [Ljava/lang/Object;

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    array-length v1, p3

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-ge v3, v1, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    aget-object v4, p3, v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v5, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-array v6, v2, [Ljava/lang/Object;

    const/4 v8, 0x3

    aput-object v4, v6, v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string/jumbo v4, "laemnrgrr pea% IR:v koteelinsf"

    const-string v4, "eakgrRrps:f ae%tle riv oelrnnI"

    const/4 v8, 0x1

    const-string v4, "erkgo RaIell:f  eore%anvirstsn"

    const-string v4, "InstallReferrer invoke arg: %s"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {v5, v4, v6}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    move v8, v7

    goto :goto_0

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v1, "sIulsbehnSeerlerRdfFpinaettoni"

    const-string/jumbo v1, "onInstallReferrerSetupFinished"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    if-eqz v1, :cond_7

    const/4 v7, 0x3

    move v8, v7

    array-length p2, p3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-eq p2, v2, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    array-length p3, p3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    aput-object p3, v1, v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo p3, "indeFeulnshRleIeaSgreree  r aartqnervtrIl1in:o sdok nl%ftgnprRis uoshttfn e"

    const-string p3, "hnsr sagqeal inSoIt rrnsrfeenn s einelr1geuForetl:RadkIldie efrvttoh%pnl Rt"

    const/4 v8, 0x3

    const-string p3, "anrsll:pRnloonuepIt %geeSeeletngrosnretd  RtirfI irren teksa1nha svlhFrfi d"

    const-string p3, "InstallReferrer invoke onInstallReferrerSetupFinished args lenght not 1: %d"

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {p2, p3, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object p1

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    aget-object p2, p3, v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    instance-of p3, p2, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-nez p3, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v0, "tSrhieFkqrt nnopeRee rnIinrifIn tttrserfulrolse as gneaeiaRsdlove"

    const-string v0, "R sooenFaIetlelerRnnineretiktiuafod  lrnsvtSagr  fhretsserIipennr"

    const/4 v8, 0x4

    const-string/jumbo v0, "itsrrlnvrit nepeosot SR reIitlenle dFIrtnrgrssealaeRufnnkfonehae "

    const-string v0, "InstallReferrer invoke onInstallReferrerSetupFinished arg not int"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {p2, v0, p3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-object p1

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    check-cast p2, Ljava/lang/Integer;

    const/4 v8, 0x4

    const/4 v7, 0x0

    if-nez p2, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v0, "nrImtrddCIn ninenmsrltlnesreS eR vriersfereRgefh slntooeapiroe alueFossepkuila"

    const-string/jumbo v0, "regmfruioIusRe pC lsoatetnenesdnlski eSellehdneteniressiIlealr o RfFvrnrpanrro"

    const/4 v8, 0x6

    const-string/jumbo v0, "se povrneenI f o lrhilteFeratrep snenilniRrtlorseasrgnSRe srIkdeuoColelifadusn"

    const-string v0, "InstallReferrer invoke onInstallReferrerSetupFinished responseCode arg is null"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {p2, v0, p3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-object p1

    :cond_6
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {p0, p2}, Lcom/adjust/sdk/InstallReferrer;->onInstallReferrerSetupFinishedIntI(I)V

    const/4 v8, 0x4

    goto :goto_1

    :cond_7
    const/4 v8, 0x1

    const-string/jumbo p3, "nderfbecrnIsieeDterleincoacrvSsetnRl"

    const-string/jumbo p3, "onInstallReferrerServiceDisconnected"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz p2, :cond_8

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string/jumbo v0, "rtenelureiowi  o.evc.ssrrrtnl iotsCeR nratsigen nto fo. cy .l"

    const-string v0, " nltogoat  .nl no.wc stseeeRfirenes eyiiv.r.rr oCntroclt iers"

    const/4 v8, 0x4

    const-string/jumbo v0, "yiree tpracttontvrtes.n w.eoilefcsnesrRon   ol. e.nagr i Clsi"

    const-string v0, "Connection to install referrer service was lost. Retrying ..."

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {p2, v0, p3}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/adjust/sdk/InstallReferrer;->retryI()V

    :cond_8
    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    return-object p1
.end method

.method private onInstallReferrerSetupFinishedIntI(I)V
    .locals 19

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    const/4 v2, -0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eq v0, v2, :cond_4

    const/4 v2, 0x3

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    if-eq v0, v3, :cond_2

    if-eq v0, v5, :cond_1

    if-eq v0, v2, :cond_0

    iget-object v2, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v3, v3, [Ljava/lang/Object;

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v3, v4

    const-string v0, " eipterrqnnso:csl%leUcperenordsndfop.c Coi xdelcotsogn nente eb fen iaerss  e"

    const-string/jumbo v0, "lccspbasg el: rie cendocnrelxr eptedeoss   dtnnfrfeetio%nUoesoeri  Cnnesop.on"

    const-string/jumbo v0, "sesngo:.otfedtdrcsplo  e nUnt reoao isre l inrfrrcoesC  clninescesneee%xeppdn"

    const-string v0, "Unexpected response code of install referrer response: %d. Closing connection"

    invoke-interface {v2, v0, v3}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_0
    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v2, v4, [Ljava/lang/Object;

    const-string/jumbo v5, "n rmrur.icsste.sngIraa ecf eeg Al.g e.riaP noetlucrdr asreRlIRuyreyb er tn"

    const-string/jumbo v5, "ne arIue eAfsc.nePeRot  ctcgi  e ..snldrrrtlsler.uyreryirna asgeRga Irrebu"

    const-string/jumbo v5, "r tuoRnegiaoI sacr gyuARe ace. dol.re.ePlsItsraere  rr clsrente nrrfny.ige"

    const-string v5, "Install Referrer API general errors caused by incorrect usage. Retrying..."

    invoke-interface {v0, v5, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_1
    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v2, v4, [Ljava/lang/Object;

    const-string/jumbo v3, "pA ttbrtoterC inesag ot.e polny  yIsRlatPhaeoo iissp S lbu o flcplpn dtrnncneIPreldeea"

    const-string/jumbo v3, "n.Sl tfptog ycnnsnel b asedaeR prstc etrr p iilteoo onlaueI pldlihato APosPpyICrnere t"

    const-string/jumbo v3, "niesfPuyno ro e ipll dtas epsn CntrbItnu PeoatpllIS rd htncnRso. atia lecrelyte Aergoo"

    const-string v3, "Install Referrer API not supported by the installed Play Store app. Closing connection"

    invoke-interface {v0, v3, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_2
    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v2, v4, [Ljava/lang/Object;

    const-string v5, "iCteaRup gfeceani yc . itsetd. innirlteoree ltlhiv cn.qeoroonoRsrn rtI ett"

    const-string/jumbo v5, "tetr nnlqoleinonrI o laete t.irs .oge.scitee  tcfcirR teiR. venaituoyCrndh"

    const-string v5, " vcngnotq.ntfoeiso lnc rolits tet iylerI ec n aeenitCda.e.nR.ire tiouRretr"

    const-string v5, "Could not initiate connection to the Install Referrer service. Retrying..."

    invoke-interface {v0, v5, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_3
    :try_start_0
    invoke-direct/range {p0 .. p0}, Lcom/adjust/sdk/InstallReferrer;->getInstallReferrer()Ljava/lang/Object;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getStringInstallReferrer(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getReferrerClickTimestampSeconds(Ljava/lang/Object;)J

    move-result-wide v8

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getInstallBeginTimestampSeconds(Ljava/lang/Object;)J

    move-result-wide v10

    iget-object v6, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const-string v12, "a:se,ef% s scl,ntn:mt sglae en%ir Tk%iriRdTieirim:dlBlse"

    const-string/jumbo v12, "mts%f:lsaca:lcretsm%dei dl  e TgTnens:irr%kei,Bi neiR,il"

    const-string v12, " iemera,fensid%cgtr%:llB:d%sa RT:c ,li erteimslm Telinik"

    const-string/jumbo v12, "installReferrer: %s, clickTime: %d, installBeginTime: %d"

    new-array v13, v2, [Ljava/lang/Object;

    aput-object v7, v13, v4

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    aput-object v14, v13, v3

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    aput-object v14, v13, v5

    invoke-interface {v6, v12, v13}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getStringInstallVersion(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getReferrerClickTimestampServerSeconds(Ljava/lang/Object;)J

    move-result-wide v12

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getInstallBeginTimestampServerSeconds(Ljava/lang/Object;)J

    move-result-wide v14

    invoke-direct {v1, v0}, Lcom/adjust/sdk/InstallReferrer;->getBooleanGooglePlayInstantParam(Ljava/lang/Object;)Ljava/lang/Boolean;

    move-result-object v17

    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const-string v6, " r:iolrlsecat vgSnI :l,%T%gm ,st,edkrnlndvSibrBe i:teniPclloes ntegarsVeai%mynlo: e%sa"

    const-string/jumbo v6, "kcdmr y:ale agg:beeTrnlatiPnt:rSisoV ,viI gn%lee ts%sldnSrnvit o%ceeir:emlBsl,al,s% ni"

    const-string v6, ":lygabtelt:i,nocTi%, o en%lVrrcinnbSoaSs%,enPkmalI eedsigl  ar Bedg:serinlvsrt:%ie stv"

    const-string/jumbo v6, "installVersion: %s, clickTimeServer: %d, installBeginServer: %d, googlePlayInstant: %b"

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    aput-object v16, v2, v4

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v18

    aput-object v18, v2, v3

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v18

    aput-object v18, v2, v5

    const/4 v5, 0x3

    aput-object v17, v2, v5

    invoke-interface {v0, v6, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const-string v2, "ef gaiusyRrtier oIc.e rsCrnlctcno loluleeendssl snoufn"

    const-string/jumbo v2, "sesroeeuntlnurfaIlcf t . drccr lsenolRCcss oeiegyinnol"

    const-string v2, "alsscnopts delo eagliosrIefcclfyes li  rctr.CnnunenerR"

    const-string v2, "Install Referrer read successfully. Closing connection"

    new-array v5, v4, [Ljava/lang/Object;

    invoke-interface {v0, v2, v5}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v0, Lcom/adjust/sdk/ReferrerDetails;

    move-object v6, v0

    move-object v6, v0

    invoke-direct/range {v6 .. v17}, Lcom/adjust/sdk/ReferrerDetails;-><init>(Ljava/lang/String;JJJJLjava/lang/String;Ljava/lang/Boolean;)V

    iget-object v2, v1, Lcom/adjust/sdk/InstallReferrer;->referrerCallback:Lcom/adjust/sdk/InstallReferrerReadListener;

    const-string v5, "bgqogl"

    const-string v5, "ggoleb"

    const-string v5, "google"

    invoke-interface {v2, v0, v5}, Lcom/adjust/sdk/InstallReferrerReadListener;->onInstallReferrerRead(Lcom/adjust/sdk/ReferrerDetails;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    move v3, v4

    move v3, v4

    goto :goto_1

    :catch_0
    move-exception v0

    iget-object v2, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v5, v3, [Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    aput-object v0, v5, v4

    const-string v0, " ls.eftRei.rgnuufCaogln.m/o.n% clseretslire( it  rdtyt/)er n"

    const-string v0, "cts )turi.eeonme(loiiy %fsdgRrrr/ lnelr.ft ne  gCla.ttune ./"

    const-string/jumbo v0, "nlem /trot )rr.Rnossy.utte l e miaen itnc fglr/f(eri.rg.leC%"

    const-string v0, "Couldn\'t get install referrer from client (%s). Retrying..."

    invoke-interface {v2, v0, v5}, Lcom/adjust/sdk/ILogger;->warn(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_1

    :cond_4
    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    new-array v2, v4, [Ljava/lang/Object;

    const-string/jumbo v5, "w eyo. r pya Sioencivet s.ctletgr.cnRoniePoo t.res d"

    const-string/jumbo v5, "orSt i pi.tea ev reidegcncs ynlsP nn ooetwyRte.rc..o"

    const-string/jumbo v5, "tcR gb.e. rrteocnoP nnei.ona nyrdo  e liSseivwtc.ety"

    const-string v5, "Play Store service is not connected now. Retrying..."

    invoke-interface {v0, v5, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_1
    if-eqz v3, :cond_5

    invoke-direct/range {p0 .. p0}, Lcom/adjust/sdk/InstallReferrer;->retryI()V

    goto :goto_2

    :cond_5
    iget-object v0, v1, Lcom/adjust/sdk/InstallReferrer;->shouldTryToRead:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-direct/range {p0 .. p0}, Lcom/adjust/sdk/InstallReferrer;->closeReferrerClient()V

    :goto_2
    return-void
.end method

.method private retryI()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->shouldTryToRead:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v2, "Srereuullt rqrterfI ody  oenalstd trnh "

    const-string/jumbo v2, "terrSyr qlef rhodserlurn otltn a doIte "

    const/4 v8, 0x7

    const-string/jumbo v2, "rtrorleprydoaerud nShI  tntlf e eot rla"

    const-string v2, "Should not try to read Install referrer"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x1

    invoke-direct {p0}, Lcom/adjust/sdk/InstallReferrer;->closeReferrerClient()V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    iget v0, p0, Lcom/adjust/sdk/InstallReferrer;->retries:I

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    add-int/2addr v0, v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v3, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-le v0, v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object v3, v2, v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const-string v1, " eeremr qf a smrbdrtoe opfsesrlitsrafu fetnir%rr sLudly o "

    const-string/jumbo v1, "tdsfeebnrsrmaLf earrsutmutssreo iro difl l peo y ef rnr %r"

    const/4 v8, 0x1

    const-string v1, " ys f bs rff oursrdm osarditeer m istraorfrni lLtrele%peun"

    const-string v1, "Limit number of retry of %d for install referrer surpassed"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v0, v1, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    return-void

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->retryTimer:Lcom/adjust/sdk/scheduler/TimerOnce;

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/adjust/sdk/scheduler/TimerOnce;->getFireIn()J

    move-result-wide v3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    cmp-long v0, v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-lez v0, :cond_2

    const/4 v7, 0x5

    move v8, v7

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-object v3, v2, v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v1, "Already waiting to retry to read install referrer in %d milliseconds"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v0, v1, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-void

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x4

    iget v0, p0, Lcom/adjust/sdk/InstallReferrer;->retries:I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    add-int/2addr v0, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput v0, p0, Lcom/adjust/sdk/InstallReferrer;->retries:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    aput-object v0, v2, v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string/jumbo v0, "r emtrr Pfn n sRtbcA ytuelnIittmeon lreo  mrdeeoa%"

    const-string v0, "errmrsotPcte   nnraltode  frtIon rmu %eAly nieebtR"

    const/4 v8, 0x4

    const-string/jumbo v0, "liIAoelumr brenrct  e netrRfrtnn se to%ePtoyo dacr"

    const-string v0, "Retry number %d to connect to install referrer API"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v3, v0, v2}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->retryTimer:Lcom/adjust/sdk/scheduler/TimerOnce;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget v1, p0, Lcom/adjust/sdk/InstallReferrer;->retryWaitTime:I

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    int-to-long v1, v1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/adjust/sdk/scheduler/TimerOnce;->startIn(J)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void
.end method

.method private startConnection(Ljava/lang/Class;Ljava/lang/Object;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/InstallReferrer;->referrerClient:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "ocosnbotienrttC"

    const-string/jumbo v3, "titnooncCnoetsr"

    const/4 v6, 0x4

    const-string v3, "ecrnstuinCntooa"

    const-string/jumbo v3, "startConnection"

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-array v4, v0, [Ljava/lang/Class;

    const/4 v5, 0x6

    move v6, v5

    aput-object p1, v4, v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    new-array p1, v0, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    aput-object p2, p1, v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2, v3, v4, p1}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-object v3, v2, v1

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-object p1, v2, v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo p1, "syr (ospc)erens r%ritbttnCo h nbr(oaw)tno"

    const-string p1, " Ctn boih%e(rse%n)otrrcotsyr rns)w(bn oat"

    const/4 v6, 0x7

    const-string/jumbo p1, "startConnection error (%s) thrown by (%s)"

    const/4 v6, 0x5

    invoke-interface {p2, p1, v2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :catch_1
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/Util;->hasRootCause(Ljava/lang/Exception;)Z

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz p2, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/adjust/sdk/Util;->getRootCause(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    aput-object p1, v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string p1, "cRooIenrqecg ncti ETeuseluo%nvearrtfeanloten ptersantxaInd "

    const-string/jumbo p1, "na c euoeuripneanIlntEcixcsRnrteo%reesfnt vtlron aegdaToIet"

    const/4 v6, 0x5

    const-string p1, "InstallReferrer encountered an InvocationTargetException %s"

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-interface {p2, p1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v1, Lcom/adjust/sdk/InstallReferrer$b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/adjust/sdk/InstallReferrer$b;-><init>(Lcom/adjust/sdk/InstallReferrer;Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Lcom/adjust/sdk/scheduler/ThreadExecutor;->submit(Ljava/lang/Runnable;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method public startConnection()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->playInstallReferrer:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const-string/jumbo v2, "ptsncnntrooates"

    const-string/jumbo v2, "nncnasCpoettotr"

    const/4 v6, 0x3

    const-string/jumbo v2, "rsnmittCotoncan"

    const-string/jumbo v2, "startConnection"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v2, v4, v3}, Lcom/adjust/sdk/Reflection;->invokeInstanceMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    return-void

    :catch_0
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    aput-object v0, v3, v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v0, "Ceraotroettyl nt% oonraP: qolsnaic  lC"

    const-string/jumbo v0, "lyai ocrqrtCtnseolanPeat%oonCt lr:r   "

    const/4 v6, 0x6

    const-string/jumbo v0, "yoionbo: elrlsnlaaortert t C%nP acC sr"

    const-string v0, "Call to Play startConnection error: %s"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v2, v0, v3}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getTryInstallReferrer()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/adjust/sdk/InstallReferrer;->closeReferrerClient()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->shouldTryToRead:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-nez v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v2, "treerruS e loldtnyt alarrfrhnsdIooute s"

    const-string/jumbo v2, "res oelI lfuorotnhtral Sdedrttr yesran "

    const/4 v6, 0x5

    const-string v2, "Sedteltptur trndorl norraI fly hasr oee"

    const-string v2, "Should not try to read Install referrer"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v0, v2, v1}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->context:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-nez v0, :cond_3

    const/4 v6, 0x5

    return-void

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/adjust/sdk/InstallReferrer;->createInstallReferrerClient(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/InstallReferrer;->referrerClient:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v0, :cond_4

    return-void

    :cond_4
    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/adjust/sdk/InstallReferrer;->getInstallReferrerStateListenerClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v0, :cond_5

    const/4 v6, 0x5

    return-void

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/InstallReferrer;->createProxyInstallReferrerStateListener(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v1, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p0, v0, v1}, Lcom/adjust/sdk/InstallReferrer;->startConnection(Ljava/lang/Class;Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-void
.end method
