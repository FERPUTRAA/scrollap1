.class public final enum Lcom/adjust/sdk/TrackingState;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/adjust/sdk/TrackingState;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/adjust/sdk/TrackingState;

.field public static final enum OPTED_OUT:Lcom/adjust/sdk/TrackingState;


# instance fields
.field private value:I


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v0, Lcom/adjust/sdk/TrackingState;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const-string v1, "OUsTPTE_O"

    const-string v1, "TPs_TOEOU"

    const-string v1, "ETOmUOPD_"

    const-string v1, "OPTED_OUT"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v0, v1, v2, v3}, Lcom/adjust/sdk/TrackingState;-><init>(Ljava/lang/String;II)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-object v0, Lcom/adjust/sdk/TrackingState;->OPTED_OUT:Lcom/adjust/sdk/TrackingState;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-array v1, v3, [Lcom/adjust/sdk/TrackingState;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    aput-object v0, v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    sput-object v1, Lcom/adjust/sdk/TrackingState;->$VALUES:[Lcom/adjust/sdk/TrackingState;

    const/4 v5, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    iput p3, p0, Lcom/adjust/sdk/TrackingState;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/adjust/sdk/TrackingState;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~@~of v~@~n  b~~~~@~ -o   ~  @o@c~.iM @1 @ @m~@bs@@yo4@~t @/o ~~@ S@d~i@i@@~Kt~ul~fb/r~@@ o~oa "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-class v0, Lcom/adjust/sdk/TrackingState;

    const-class v0, Lcom/adjust/sdk/TrackingState;

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lcom/adjust/sdk/TrackingState;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lcom/adjust/sdk/TrackingState;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/adjust/sdk/TrackingState;->$VALUES:[Lcom/adjust/sdk/TrackingState;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lcom/adjust/sdk/TrackingState;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast v0, [Lcom/adjust/sdk/TrackingState;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public getValue()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/adjust/sdk/TrackingState;->value:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method
