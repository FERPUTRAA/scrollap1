.class public Lcom/adjust/sdk/AdjustEventFailure;
.super Ljava/lang/Object;


# instance fields
.field public adid:Ljava/lang/String;

.field public callbackId:Ljava/lang/String;

.field public eventToken:Ljava/lang/String;

.field public jsonResponse:Lorg/json/JSONObject;

.field public message:Ljava/lang/String;

.field public timestamp:Ljava/lang/String;

.field public willRetry:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s@~M~ .@l~@1 foo   ~~ ~~ b@@i~~~ ~mo@ ~ tSi@ @~@i/r@uvl@c~d~yn~~a    @ f-4@~/s@@b ~@o@o~o~@bt@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x7

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->message:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->timestamp:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x4

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->adid:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->eventToken:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-object v1, v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->callbackId:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    move v4, v2

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object v1, v0, v2

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->willRetry:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/AdjustEventFailure;->jsonResponse:Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x6

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "nrvm:vme%net% %sso :%e:reads%m  i:sa%sd uls: ti yss:tb%niFE:gdretjces"

    const-string/jumbo v1, "n:s Enist :en %se:eiatag% sdrl% rb ymt%::mess t uvocesjerd%:d:sv%s%Fi"

    const-string v1, "a rmo:soe s%e%rtd:ycrE:% e%gsist:ltad%i ee j:ssv%v dnmiebt :%is :unsF"

    const-string v1, "Event Failure msg:%s time:%s adid:%s event:%s cid:%s retry:%b json:%s"

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method
