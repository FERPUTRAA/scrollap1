.class public Lcom/adjust/sdk/ActivityState;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;
.implements Ljava/lang/Cloneable;


# static fields
.field private static final ORDER_ID_MAXCOUNT:I = 0xa

.field private static final serialPersistentFields:[Ljava/io/ObjectStreamField;

.field private static final serialVersionUID:J = 0x7d728a246d4bab64L


# instance fields
.field public adid:Ljava/lang/String;

.field public askingAttribution:Z

.field public clickTime:J

.field public clickTimeHuawei:J

.field public clickTimeSamsung:J

.field public clickTimeServer:J

.field public clickTimeServerXiaomi:J

.field public clickTimeXiaomi:J

.field public enabled:Z

.field public eventCount:I

.field public googlePlayInstant:Ljava/lang/Boolean;

.field public installBegin:J

.field public installBeginHuawei:J

.field public installBeginSamsung:J

.field public installBeginServer:J

.field public installBeginServerXiaomi:J

.field public installBeginXiaomi:J

.field public installReferrer:Ljava/lang/String;

.field public installReferrerHuawei:Ljava/lang/String;

.field public installReferrerHuaweiAppGallery:Ljava/lang/String;

.field public installReferrerSamsung:Ljava/lang/String;

.field public installReferrerXiaomi:Ljava/lang/String;

.field public installVersion:Ljava/lang/String;

.field public installVersionXiaomi:Ljava/lang/String;

.field public isGdprForgotten:Z

.field public isThirdPartySharingDisabled:Z

.field public isThirdPartySharingDisabledForCoppa:Z

.field public lastActivity:J

.field public lastInterval:J

.field private transient logger:Lcom/adjust/sdk/ILogger;

.field public orderIds:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public pushToken:Ljava/lang/String;

.field public sessionCount:I

.field public sessionLength:J

.field public subsessionCount:I

.field public timeSpent:J

.field public updatePackages:Z

.field public uuid:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/16 v0, 0x25

    const/4 v8, 0x7

    new-array v0, v0, [Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo v2, "uidu"

    const-string v2, "duui"

    const/4 v8, 0x3

    const-string/jumbo v2, "iudu"

    const-string/jumbo v2, "uuid"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    aput-object v1, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v4, "alsnseb"

    const-string v4, "edsnabl"

    const/4 v8, 0x5

    const-string v4, "dlemean"

    const-string v4, "enabled"

    const/4 v8, 0x2

    invoke-direct {v1, v4, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x0

    const/4 v4, 0x7

    const/4 v8, 0x5

    const/4 v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    aput-object v1, v0, v4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v4, "rgmtoosirGeFotd"

    const-string/jumbo v4, "sgpmotrriodetGF"

    const/4 v8, 0x6

    const-string/jumbo v4, "isGdprForgotten"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {v1, v4, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v4, 0x2

    const/4 v7, 0x7

    move v8, v7

    aput-object v1, v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v4, "bDdagbsieltyirdoirsiarnPSTa"

    const-string v4, "degaorrsdSniiPaiisyabtDlhrT"

    const/4 v8, 0x5

    const-string/jumbo v4, "rtbladuriPerhysThgdiaisSnDa"

    const-string/jumbo v4, "isThirdPartySharingDisabled"

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-direct {v1, v4, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v4, 0x3

    const/4 v8, 0x7

    const/4 v7, 0x1

    aput-object v1, v0, v4

    const/4 v8, 0x2

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v4, "tgrntbiibAksoniau"

    const/4 v8, 0x6

    const-string v4, "atnbrkipugioAtnis"

    const-string v4, "askingAttribution"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v1, v4, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v4, 0x4

    const/4 v8, 0x3

    aput-object v1, v0, v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v5, "uteoCnntqe"

    const-string/jumbo v5, "nCeutnutoe"

    const/4 v8, 0x4

    const-string/jumbo v5, "onseuvtCte"

    const-string v5, "eventCount"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    aput-object v1, v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v5, "stsmenCsnoup"

    const-string/jumbo v5, "toenusspCsno"

    const/4 v8, 0x7

    const-string/jumbo v5, "niCsotouosen"

    const-string/jumbo v5, "sessionCount"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v5, 0x6

    const/4 v8, 0x0

    const/4 v7, 0x6

    aput-object v1, v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const-string/jumbo v5, "neCiubuqsnbosos"

    const-string/jumbo v5, "souenisnqsuCbos"

    const/4 v8, 0x6

    const-string/jumbo v5, "useCuoutbisnsso"

    const-string/jumbo v5, "subsessionCount"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x6

    const/4 v4, 0x7

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    aput-object v1, v0, v4

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    sget-object v4, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string/jumbo v5, "seeLsnspntosg"

    const-string v5, "eesoLnshssgtn"

    const/4 v8, 0x5

    const-string/jumbo v5, "oehnnsiLqegst"

    const-string/jumbo v5, "sessionLength"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/16 v5, 0x8

    const/4 v7, 0x1

    move v8, v7

    aput-object v1, v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo v5, "mtsSpneit"

    const-string/jumbo v5, "mntmSepit"

    const/4 v8, 0x2

    const-string/jumbo v5, "mptmnSeie"

    const-string/jumbo v5, "timeSpent"

    const/4 v8, 0x1

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v5, 0x9

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v1, v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo v5, "ttcyoiaiAltv"

    const-string/jumbo v5, "lastActivity"

    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/16 v5, 0xa

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    aput-object v1, v0, v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v5, "nsevlbtIltra"

    const-string/jumbo v5, "lastInterval"

    const/4 v7, 0x7

    move v8, v7

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/16 v5, 0xb

    const/4 v8, 0x1

    aput-object v1, v0, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v5, "tuapgsukadPeca"

    const-string/jumbo v5, "updatePackages"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1, v5, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v7, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/16 v5, 0xc

    const/4 v7, 0x6

    move v8, v7

    aput-object v1, v0, v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v5, "roeIsddp"

    const-string/jumbo v5, "rsIrodde"

    const/4 v8, 0x0

    const-string/jumbo v5, "qsorIdde"

    const-string/jumbo v5, "orderIds"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-class v6, Ljava/util/LinkedList;

    const-class v6, Ljava/util/LinkedList;

    const/4 v8, 0x1

    const-class v6, Ljava/util/LinkedList;

    const-class v6, Ljava/util/LinkedList;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v1, v5, v6}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/16 v5, 0xd

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v1, v0, v5

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v5, "ehspTkuns"

    const-string/jumbo v5, "pushToken"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/16 v5, 0xe

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v1, v0, v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const-string v5, "ddai"

    const-string v5, "addi"

    const/4 v8, 0x0

    const-string v5, "ddia"

    const-string v5, "adid"

    const/4 v8, 0x5

    const/4 v7, 0x2

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/16 v5, 0xf

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    aput-object v1, v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v7, 0x5

    or-int/2addr v8, v7

    const-string v5, "ckbmeicli"

    const-string/jumbo v5, "mcicibelk"

    const/4 v8, 0x2

    const-string v5, "cemioklTi"

    const-string v5, "clickTime"

    const/4 v8, 0x4

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/16 v5, 0x10

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    aput-object v1, v0, v5

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v5, "elBglbniiant"

    const-string/jumbo v5, "installBegin"

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/16 v5, 0x11

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    aput-object v1, v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string v5, "erusnfurteierla"

    const-string v5, "enrltlufaeirsre"

    const/4 v8, 0x6

    const-string/jumbo v5, "realRteperilnfs"

    const-string/jumbo v5, "installReferrer"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/16 v5, 0x12

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    aput-object v1, v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v5, "gapyslnlqgooPaIet"

    const-string/jumbo v5, "ogeIasypgPlaltont"

    const/4 v8, 0x2

    const-string/jumbo v5, "lIsaoytnnPgstaoeg"

    const-string v5, "googlePlayInstant"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-class v6, Ljava/lang/Boolean;

    const-class v6, Ljava/lang/Boolean;

    const/4 v8, 0x7

    const-class v6, Ljava/lang/Boolean;

    const-class v6, Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v1, v5, v6}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/16 v5, 0x13

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    aput-object v1, v0, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const-string v5, "SlcmqrivkmeeciT"

    const-string/jumbo v5, "vrTkeSciqeicrlm"

    const/4 v8, 0x0

    const-string v5, "SeirorkvlcTcmei"

    const-string v5, "clickTimeServer"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/16 v5, 0x14

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    aput-object v1, v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v5, "snngibeSBlaeersilr"

    const-string/jumbo v5, "nrslslieeBvnegiSar"

    const/4 v8, 0x6

    const-string/jumbo v5, "sieavruSrleelnBtng"

    const-string/jumbo v5, "installBeginServer"

    const/4 v8, 0x0

    const/4 v7, 0x5

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x1

    const/16 v5, 0x15

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    aput-object v1, v0, v5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v5, "Veltnsspraimol"

    const-string/jumbo v5, "lnlmetsasoVrii"

    const/4 v8, 0x3

    const-string v5, "elnriontqlVsia"

    const-string/jumbo v5, "installVersion"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/16 v5, 0x16

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    aput-object v1, v0, v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v5, "cesHiwaoTmiceil"

    const-string v5, "TciHoelwceiuiam"

    const/4 v8, 0x5

    const-string/jumbo v5, "iHcmkeiwculimae"

    const-string v5, "clickTimeHuawei"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/16 v5, 0x17

    const/4 v8, 0x1

    aput-object v1, v0, v5

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string/jumbo v5, "swBioiaanlbetlegni"

    const-string/jumbo v5, "ilnunbsagaewietliB"

    const/4 v8, 0x5

    const-string/jumbo v5, "lgsiabtHiewlBunaei"

    const-string/jumbo v5, "installBeginHuawei"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v1, v5, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/16 v5, 0x18

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput-object v1, v0, v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const-string v5, "eerlHeurufewlRrunatsi"

    const-string v5, "fRsrieutnalrlareewueH"

    const/4 v8, 0x4

    const-string/jumbo v5, "rreatsepRwnillueaerif"

    const-string/jumbo v5, "installReferrerHuawei"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/16 v5, 0x19

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    aput-object v1, v0, v5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const-string/jumbo v5, "peapeAGyqrRreantreHlilfluiplsae"

    const-string/jumbo v5, "lrefitnppallyGwiaeeRerplAeuHars"

    const/4 v8, 0x0

    const-string v5, "fesawreturelrlsepayARGileprnail"

    const-string/jumbo v5, "installReferrerHuaweiAppGallery"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v1, v5, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/16 v5, 0x1a

    const/4 v8, 0x5

    aput-object v1, v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v5, "oeomdypCsarirhlhbaPiFgiapqiardrTtDS"

    const-string/jumbo v5, "raahsieDqFSadplTorbaipgCrtdihrPysio"

    const/4 v8, 0x5

    const-string/jumbo v5, "rhlyooeDdrahiptoiragTPdCrSipabainsF"

    const-string/jumbo v5, "isThirdPartySharingDisabledForCoppa"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v1, v5, v2}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/16 v2, 0x1b

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v1, v0, v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v2, "eisciklmacioTmX"

    const/4 v8, 0x0

    const-string v2, "clickTimeXiaomi"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/16 v2, 0x1c

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    aput-object v1, v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v2, "iiXsmbaioenganmliB"

    const-string v2, "animiilnselXmogaiB"

    const/4 v8, 0x3

    const-string/jumbo v2, "imloiXueinaagsnitB"

    const-string/jumbo v2, "installBeginXiaomi"

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/16 v2, 0x1d

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    aput-object v1, v0, v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x3

    const-string/jumbo v2, "orifleXporamnRaertiis"

    const-string/jumbo v2, "terloXsfeianraiioRrem"

    const-string v2, "eeamaRtiqirislrlnerof"

    const-string/jumbo v2, "installReferrerXiaomi"

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v2, 0x1e

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput-object v1, v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v2, "mlsTbeiaXikocmerSivei"

    const-string/jumbo v2, "imkcibrviToerelamiXeS"

    const/4 v8, 0x7

    const-string/jumbo v2, "rermceicieToXmkaimiSv"

    const-string v2, "clickTimeServerXiaomi"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/16 v2, 0x1f

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    aput-object v1, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v7, 0x7

    move v8, v7

    const-string/jumbo v2, "inveoglsularoaBiemSiirte"

    const-string/jumbo v2, "ovBineueilrsmgirteXSaila"

    const/4 v8, 0x3

    const-string v2, "eernibairnlevSgslBiioXat"

    const-string/jumbo v2, "installBeginServerXiaomi"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/16 v2, 0x20

    const/4 v8, 0x7

    const/4 v7, 0x1

    aput-object v1, v0, v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v2, "ntVimsuaopiieXialslr"

    const-string v2, "easalnipsVliXtorioim"

    const-string/jumbo v2, "saaoiomplXtniensiiVl"

    const-string/jumbo v2, "installVersionXiaomi"

    const/4 v7, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v2, 0x21

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    aput-object v1, v0, v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x7

    const-string/jumbo v2, "nmiTgcauqmSikcql"

    const-string/jumbo v2, "muTlikacqnieSgcm"

    const/4 v8, 0x1

    const-string v2, "clsiuakgcmesmiTn"

    const-string v2, "clickTimeSamsung"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/16 v2, 0x22

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    aput-object v1, v0, v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const-string/jumbo v2, "nmBmesnsitlgnSiulas"

    const-string/jumbo v2, "mssnenantaBlgiSsliu"

    const/4 v8, 0x1

    const-string v2, "esgnoiunitBlansmgSa"

    const-string/jumbo v2, "installBeginSamsung"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v1, v2, v4}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/16 v2, 0x23

    const/4 v7, 0x7

    move v8, v7

    aput-object v1, v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v1, Ljava/io/ObjectStreamField;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string/jumbo v2, "ssgmebeStRmarrlenaiunf"

    const-string v2, "gfimltneuRerenrssmSaar"

    const/4 v8, 0x7

    const-string/jumbo v2, "rlnrieutSsgRneaeruamsl"

    const-string/jumbo v2, "installReferrerSamsung"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v1, v2, v3}, Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/16 v2, 0x24

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    aput-object v1, v0, v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    sput-object v0, Lcom/adjust/sdk/ActivityState;->serialPersistentFields:[Ljava/io/ObjectStreamField;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/adjust/sdk/Util;->createUuid()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x1

    or-int/2addr v4, v3

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->enabled:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isGdprForgotten:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabled:Z

    const/4 v3, 0x3

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabledForCoppa:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->askingAttribution:Z

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v4, 0x0

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v4, 0x7

    const/4 v1, -0x1

    and-int/2addr v3, v1

    const/4 v4, 0x4

    iput v1, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->lastActivity:J

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->updatePackages:Z

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->pushToken:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->adid:Ljava/lang/String;

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTime:J

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBegin:J

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrer:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServer:J

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginServer:J

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installVersion:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeHuawei:J

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginHuawei:J

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuawei:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuaweiAppGallery:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeXiaomi:J

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginXiaomi:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerXiaomi:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServerXiaomi:J

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginServerXiaomi:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installVersionXiaomi:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeSamsung:J

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginSamsung:J

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerSamsung:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@ ~@~Mlp@/y fob@  @mi  t~~~~~~~~@@od@l   . ~ai@ S@4io@to@@b @~~n@~@~ov~~o~~@@b fs-~~@1 u  /K@r~ "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readFields()Ljava/io/ObjectInputStream$GetField;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v0, "oeentCnvqo"

    const-string/jumbo v0, "otCtoenenv"

    const/4 v7, 0x2

    const-string v0, "evsCtonunt"

    const-string v0, "eventCount"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readIntField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v0, "oismCsnensut"

    const-string/jumbo v0, "nCoeibsstsun"

    const/4 v7, 0x0

    const-string/jumbo v0, "ousootsenCns"

    const-string/jumbo v0, "sessionCount"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readIntField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo v0, "suooibetnssuuCb"

    const-string v0, "Cosuinussuesbto"

    const/4 v7, 0x2

    const-string/jumbo v0, "insbnuutseosuoC"

    const-string/jumbo v0, "subsessionCount"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v2, -0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {p1, v0, v2}, Lcom/adjust/sdk/Util;->readIntField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v0, "oiepsgLphnnst"

    const-string v0, "eLinshsptgosn"

    const-string v0, "gnteLissqehon"

    const-string/jumbo v0, "sessionLength"

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v4, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v0, "mispeqSte"

    const-string/jumbo v0, "inSemtepq"

    const/4 v7, 0x0

    const-string v0, "etnmmpeit"

    const-string/jumbo v0, "timeSpent"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-wide v4, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v7, 0x5

    const/4 v6, 0x0

    const-string/jumbo v0, "yatiovlAtisc"

    const-string v0, "aisticvysltA"

    const/4 v7, 0x4

    const-string/jumbo v0, "lvAitbyciast"

    const-string/jumbo v0, "lastActivity"

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-wide v4, p0, Lcom/adjust/sdk/ActivityState;->lastActivity:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string/jumbo v0, "raaletuItlms"

    const-string/jumbo v0, "tatmvlrseIal"

    const/4 v7, 0x1

    const-string/jumbo v0, "trlInlspevat"

    const-string/jumbo v0, "lastInterval"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput-wide v4, p0, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v0, "uudi"

    const-string v0, "duiu"

    const/4 v7, 0x3

    const-string/jumbo v0, "uiud"

    const-string/jumbo v0, "uuid"

    const/4 v7, 0x2

    const/4 v4, 0x3

    const/4 v7, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v0, "dqnaboe"

    const-string v0, "ebadonl"

    const/4 v7, 0x4

    const-string v0, "elsdnab"

    const-string v0, "enabled"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p1, v0, v5}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->enabled:Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v0, "nGrmoerFigsopdt"

    const-string/jumbo v0, "trrgnbepGoisFod"

    const/4 v7, 0x3

    const-string/jumbo v0, "ttsnopoeFiroGrg"

    const-string/jumbo v0, "isGdprForgotten"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isGdprForgotten:Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v0, "DguhrbhiaTrediibsraytndasiP"

    const-string/jumbo v0, "rPSthDurssdhiaanTygibaiierd"

    const/4 v7, 0x0

    const-string/jumbo v0, "iresisunrdhPiladTabgtDiSyhr"

    const-string/jumbo v0, "isThirdPartySharingDisabled"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabled:Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v0, "aprTaSdptprnCiyrioPpasierlsaFhbgohi"

    const-string/jumbo v0, "rPrprghppTiboShdyaiCalnisFosaedrati"

    const/4 v7, 0x7

    const-string/jumbo v0, "iTrnsiDSqbaolodpaFytrrhsiPahCegdrai"

    const-string/jumbo v0, "isThirdPartySharingDisabledForCoppa"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabledForCoppa:Z

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string/jumbo v0, "tanAitsbqtkgoiiru"

    const/4 v7, 0x0

    const-string v0, "askingAttribution"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->askingAttribution:Z

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v0, "pksaaesauPgsdt"

    const-string/jumbo v0, "peseksuagatPda"

    const/4 v7, 0x6

    const-string/jumbo v0, "ktcmaPgepaeuds"

    const-string/jumbo v0, "updatePackages"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {p1, v0, v1}, Lcom/adjust/sdk/Util;->readBooleanField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iput-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->updatePackages:Z

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v0, "rormddes"

    const/4 v7, 0x2

    const-string/jumbo v0, "oerrodsI"

    const-string/jumbo v0, "orderIds"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readObjectField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v0, Ljava/util/LinkedList;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const-string/jumbo v0, "sponobkhu"

    const-string v0, "ehkuoospn"

    const/4 v7, 0x5

    const-string v0, "Tpnuhouks"

    const-string/jumbo v0, "pushToken"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->pushToken:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v0, "adid"

    const/4 v7, 0x6

    const-string v0, "dadi"

    const-string v0, "adid"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->adid:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v0, "iieTkmlpc"

    const-string v0, "clickTime"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTime:J

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v0, "laiBgtniqnbs"

    const-string v0, "Bisnlblgiatn"

    const/4 v7, 0x4

    const-string v0, "gisBanslitne"

    const-string/jumbo v0, "installBegin"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBegin:J

    const/4 v7, 0x0

    const-string/jumbo v0, "lesmutlnfaireRr"

    const-string v0, "Rerlsfutnailree"

    const/4 v7, 0x5

    const-string/jumbo v0, "tlinoreerrsaRel"

    const-string/jumbo v0, "installReferrer"

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrer:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v0, "entosblpnlaIgtyPa"

    const-string v0, "PeslgaIpytlootnna"

    const/4 v7, 0x0

    const-string/jumbo v0, "noPasIulgoynltgea"

    const-string v0, "googlePlayInstant"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readObjectField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    check-cast v0, Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v0, "qrliTkipeerScec"

    const-string/jumbo v0, "iclreikeqmreSTc"

    const/4 v7, 0x2

    const-string v0, "clickTimeServer"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServer:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v0, "etnlriegqiBSanrses"

    const-string/jumbo v0, "sgserlenitBSrainel"

    const/4 v7, 0x3

    const-string/jumbo v0, "sesrevnSiritglBnea"

    const-string/jumbo v0, "installBeginServer"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBeginServer:J

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v0, "nnVmieslmsotal"

    const-string/jumbo v0, "oVlmsanietrlns"

    const/4 v7, 0x2

    const-string/jumbo v0, "inlsoVsnteoira"

    const-string/jumbo v0, "installVersion"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installVersion:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v0, "ikHmebucTwioaei"

    const-string v0, "ecHiouickweTmai"

    const/4 v7, 0x1

    const-string/jumbo v0, "iHcukculemiewaT"

    const-string v0, "clickTimeHuawei"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTimeHuawei:J

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v0, "uiibHlnpweBgtisane"

    const-string/jumbo v0, "negBibtwliieunasHl"

    const/4 v7, 0x2

    const-string/jumbo v0, "installBeginHuawei"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBeginHuawei:J

    const-string/jumbo v0, "itesRwniqurrealalfree"

    const-string v0, "efRHaruiratswlreleine"

    const/4 v7, 0x5

    const-string v0, "easnwsHuelRafiterrire"

    const-string/jumbo v0, "installReferrerHuawei"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuawei:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string v0, "alsmyiurreAplGHrieftpapelalnewR"

    const-string v0, "erlyaeaptuleApGfwRarelplinrHisr"

    const/4 v7, 0x2

    const-string v0, "GnreoerpueltieysRaeaarHlriAlflw"

    const-string/jumbo v0, "installReferrerHuaweiAppGallery"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuaweiAppGallery:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const-string/jumbo v0, "iimklbaioecqiXm"

    const-string v0, "amimociXqeilikc"

    const/4 v7, 0x5

    const-string/jumbo v0, "icmikiuoTicXalm"

    const-string v0, "clickTimeXiaomi"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTimeXiaomi:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v0, "nmtiglspiXBanisole"

    const-string/jumbo v0, "sisaollBnigiemXtin"

    const/4 v7, 0x0

    const-string/jumbo v0, "mignXBiaqisntaliol"

    const-string/jumbo v0, "installBeginXiaomi"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBeginXiaomi:J

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v0, "iestXlrmrneleiairosRf"

    const-string/jumbo v0, "reemstirfmeXrnRoillai"

    const/4 v7, 0x3

    const-string/jumbo v0, "lRfmenlaXrosmreetiari"

    const-string/jumbo v0, "installReferrerXiaomi"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerXiaomi:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v0, "meokoXaervrcceoSTiimi"

    const-string/jumbo v0, "iXeaociTovmiScerkrmie"

    const/4 v7, 0x6

    const-string v0, "clickTimeServerXiaomi"

    const/4 v7, 0x5

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServerXiaomi:J

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string v0, "BsignbvrrmeaeleiiSltXian"

    const-string/jumbo v0, "installBeginServerXiaomi"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBeginServerXiaomi:J

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string v0, "XeinlbVosaniimrotisl"

    const/4 v7, 0x2

    const-string/jumbo v0, "nsiralueimaiitlnoXsV"

    const-string/jumbo v0, "installVersionXiaomi"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->installVersionXiaomi:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v0, "esulScgpuTmmickn"

    const-string/jumbo v0, "scnikguclTSummae"

    const-string v0, "TgsmciakqunlcSme"

    const-string v0, "clickTimeSamsung"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->clickTimeSamsung:J

    const/4 v6, 0x6

    move v7, v6

    const-string/jumbo v0, "lBspgnulsSistmageni"

    const-string/jumbo v0, "ilmnaslpgeniuSsntgB"

    const/4 v7, 0x6

    const-string v0, "elsmSBntunsnmaglgii"

    const-string/jumbo v0, "installBeginSamsung"

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p1, v0, v2, v3}, Lcom/adjust/sdk/Util;->readLongField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->installBeginSamsung:J

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v0, "nrgsoelarteaSuinRelsfm"

    const-string/jumbo v0, "installReferrerSamsung"

    const/4 v6, 0x4

    move v7, v6

    invoke-static {p1, v0, v4}, Lcom/adjust/sdk/Util;->readStringField(Ljava/io/ObjectInputStream$GetField;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/adjust/sdk/ActivityState;->installReferrerSamsung:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {}, Lcom/adjust/sdk/Util;->createUuid()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-object p1, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-void
.end method

.method private static stamp(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p0, 0x3

    const/4 v2, 0x4

    new-array p0, p0, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 p1, 0xb

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    aput-object p1, p0, v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 p1, 0xc

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    aput-object p1, p0, v0

    const/4 v2, 0x0

    const/16 p1, 0xd

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    aput-object p1, p0, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo p1, "q%2d2b000dd%:2"

    const-string p1, "0%00:d%2qd:22d"

    const/4 v2, 0x2

    const-string p1, "0d0:2%u2%d:d%0"

    const-string p1, "%02d:%02d:%02d"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1, p0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public addOrderId(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/util/LinkedList;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/LinkedList;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 v1, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-lt v0, v1, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/LinkedList;->removeLast()Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-ne p1, p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    return v0

    :cond_0
    const/4 v5, 0x7

    move v6, v5

    const/4 v1, 0x0

    shr-int/2addr v6, v1

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-nez p1, :cond_1

    const/4 v6, 0x2

    return v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eq v2, v3, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast p1, Lcom/adjust/sdk/ActivityState;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x7

    return v1

    :cond_3
    const/4 v6, 0x0

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->enabled:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->enabled:Z

    const/4 v5, 0x2

    xor-int/2addr v6, v5

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v2, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v1

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->isGdprForgotten:Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->isGdprForgotten:Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v2, :cond_5

    const/4 v6, 0x3

    return v1

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabled:Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabled:Z

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v2, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v1

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabledForCoppa:Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabledForCoppa:Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v2, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v1

    :cond_7
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->askingAttribution:Z

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->askingAttribution:Z

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v2, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v1

    :cond_8
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v2, p0, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v3, p1, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalInt(Ljava/lang/Integer;Ljava/lang/Integer;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v2, :cond_9

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    return v1

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v2, p0, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget v3, p1, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalInt(Ljava/lang/Integer;Ljava/lang/Integer;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-nez v2, :cond_a

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    return v1

    :cond_a
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget v2, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v3, p1, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalInt(Ljava/lang/Integer;Ljava/lang/Integer;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v2, :cond_b

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v1

    :cond_b
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v2, :cond_c

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v1

    :cond_c
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v2, :cond_d

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    return v1

    :cond_d
    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v2, :cond_e

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v1

    :cond_e
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-boolean v2, p0, Lcom/adjust/sdk/ActivityState;->updatePackages:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-boolean v3, p1, Lcom/adjust/sdk/ActivityState;->updatePackages:Z

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v2, :cond_f

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v1

    :cond_f
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalObject(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v2, :cond_10

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    return v1

    :cond_10
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->pushToken:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->pushToken:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v2, :cond_11

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v1

    :cond_11
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->adid:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->adid:Ljava/lang/String;

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v2, :cond_12

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    return v1

    :cond_12
    const/4 v6, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTime:J

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v5, 0x3

    move v6, v5

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTime:J

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v2, :cond_13

    const/4 v6, 0x1

    return v1

    :cond_13
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBegin:J

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBegin:J

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v2, :cond_14

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v1

    :cond_14
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installReferrer:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installReferrer:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v2, :cond_15

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    return v1

    :cond_15
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x2

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalBoolean(Ljava/lang/Boolean;Ljava/lang/Boolean;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v2, :cond_16

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    return v1

    :cond_16
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServer:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTimeServer:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v2, :cond_17

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    return v1

    :cond_17
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginServer:J

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBeginServer:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v2, :cond_18

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    return v1

    :cond_18
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installVersion:Ljava/lang/String;

    const/4 v6, 0x6

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installVersion:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-nez v2, :cond_19

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    return v1

    :cond_19
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeHuawei:J

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTimeHuawei:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-nez v2, :cond_1a

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v1

    :cond_1a
    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginHuawei:J

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBeginHuawei:J

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    if-nez v2, :cond_1b

    const/4 v6, 0x7

    return v1

    :cond_1b
    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuawei:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x5

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installReferrerHuawei:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v2, :cond_1c

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v1

    :cond_1c
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuaweiAppGallery:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installReferrerHuaweiAppGallery:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v2, :cond_1d

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    return v1

    :cond_1d
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeXiaomi:J

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTimeXiaomi:J

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v2, :cond_1e

    const/4 v6, 0x0

    return v1

    :cond_1e
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginXiaomi:J

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBeginXiaomi:J

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v2, :cond_1f

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    return v1

    :cond_1f
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installReferrerXiaomi:Ljava/lang/String;

    const/4 v5, 0x6

    or-int/2addr v6, v5

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installReferrerXiaomi:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v2, :cond_20

    const/4 v6, 0x2

    const/4 v5, 0x7

    return v1

    :cond_20
    const/4 v6, 0x7

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServerXiaomi:J

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTimeServerXiaomi:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-nez v2, :cond_21

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    return v1

    :cond_21
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginServerXiaomi:J

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBeginServerXiaomi:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v2, :cond_22

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    return v1

    :cond_22
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installVersionXiaomi:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v3, p1, Lcom/adjust/sdk/ActivityState;->installVersionXiaomi:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v2, :cond_23

    const/4 v6, 0x5

    const/4 v5, 0x2

    return v1

    :cond_23
    const/4 v6, 0x1

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeSamsung:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->clickTimeSamsung:J

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v2, :cond_24

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v1

    :cond_24
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginSamsung:J

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-wide v3, p1, Lcom/adjust/sdk/ActivityState;->installBeginSamsung:J

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2, v3}, Lcom/adjust/sdk/Util;->equalLong(Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v2, :cond_25

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v1

    :cond_25
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/adjust/sdk/ActivityState;->installReferrerSamsung:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/ActivityState;->installReferrerSamsung:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2, p1}, Lcom/adjust/sdk/Util;->equalString(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez p1, :cond_26

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    return v1

    :cond_26
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v0
.end method

.method public findOrderId(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p1
.end method

.method public hashCode()I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit16 v0, v0, 0x275

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    mul-int/lit8 v0, v0, 0x25

    const/4 v4, 0x0

    move v5, v4

    iget-boolean v1, p0, Lcom/adjust/sdk/ActivityState;->enabled:Z

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/2addr v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isGdprForgotten:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-int/2addr v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-boolean v1, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabled:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-boolean v0, p0, Lcom/adjust/sdk/ActivityState;->isThirdPartySharingDisabledForCoppa:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v0

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-boolean v1, p0, Lcom/adjust/sdk/ActivityState;->askingAttribution:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/2addr v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget v0, p0, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v5, 0x5

    add-int/2addr v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v0, p0, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget v0, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v5, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-boolean v1, p0, Lcom/adjust/sdk/ActivityState;->updatePackages:Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/2addr v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->orderIds:Ljava/util/LinkedList;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashObject(Ljava/lang/Object;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->pushToken:Ljava/lang/String;

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->adid:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x25

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTime:J

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    add-int/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBegin:J

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/2addr v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->installReferrer:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/2addr v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->googlePlayInstant:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashBoolean(Ljava/lang/Boolean;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServer:J

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginServer:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/2addr v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x25

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->installVersion:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    add-int/2addr v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeHuawei:J

    const/4 v5, 0x4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/2addr v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginHuawei:J

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    add-int/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuawei:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->installReferrerHuaweiAppGallery:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    add-int/2addr v1, v0

    const/4 v4, 0x0

    move v5, v4

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeXiaomi:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x2

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginXiaomi:J

    const/4 v4, 0x3

    move v5, v4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    add-int/2addr v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerXiaomi:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->clickTimeServerXiaomi:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->installBeginServerXiaomi:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->installVersionXiaomi:Ljava/lang/String;

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/adjust/sdk/ActivityState;->clickTimeSamsung:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    mul-int/lit8 v0, v0, 0x25

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->installBeginSamsung:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/adjust/sdk/Util;->hashLong(Ljava/lang/Long;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    add-int/2addr v1, v0

    const/4 v5, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/ActivityState;->installReferrerSamsung:Ljava/lang/String;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-static {v0}, Lcom/adjust/sdk/Util;->hashString(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    add-int/2addr v0, v1

    const/4 v4, 0x6

    move v5, v4

    return v0
.end method

.method public resetSessionAttributes(J)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v0, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    iput-wide p1, p0, Lcom/adjust/sdk/ActivityState;->lastActivity:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-wide/16 p1, -0x1

    const-wide/16 p1, -0x1

    const/4 v3, 0x6

    const-wide/16 p1, -0x1

    const-wide/16 p1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide p1, p0, Lcom/adjust/sdk/ActivityState;->lastInterval:J

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x0

    const/4 v0, 0x7

    const/4 v6, 0x7

    move v5, v0

    move v5, v0

    const/4 v6, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v1, p0, Lcom/adjust/sdk/ActivityState;->eventCount:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    aput-object v1, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v1, p0, Lcom/adjust/sdk/ActivityState;->sessionCount:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object v1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    iget v1, p0, Lcom/adjust/sdk/ActivityState;->subsessionCount:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object v1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->sessionLength:J

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    long-to-double v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-wide v3, 0x408f400000000000L    # 1000.0

    const-wide v3, 0x408f400000000000L    # 1000.0

    const/4 v6, 0x3

    const-wide v3, 0x408f400000000000L    # 1000.0

    const-wide v3, 0x408f400000000000L    # 1000.0

    const/4 v5, 0x1

    move v6, v5

    div-double/2addr v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v2, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    aput-object v1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->timeSpent:J

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    long-to-double v1, v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    div-double/2addr v1, v3

    const/4 v6, 0x7

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v2, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-wide v1, p0, Lcom/adjust/sdk/ActivityState;->lastActivity:J

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1, v2}, Lcom/adjust/sdk/ActivityState;->stamp(J)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    aput-object v1, v0, v2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/adjust/sdk/ActivityState;->uuid:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x6

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    aput-object v1, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v1, ":dtd%:ips es%sfs .%%du  %f:dcl1sl.:  cs:%1s:%a:u"

    const-string v1, " .s:fd:s%ul%%d:%iu%f  s cssas%1%c:dd:s: : st1l.e"

    const/4 v6, 0x1

    const-string/jumbo v1, "s%%:1dcdqsa.%e:: %sl:s %u%d  1lts: s:. if:sd%ccu"

    const-string v1, "ec:%d sc:%d ssc:%d sl:%.1f ts:%.1f la:%s uuid:%s"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object v0
.end method
