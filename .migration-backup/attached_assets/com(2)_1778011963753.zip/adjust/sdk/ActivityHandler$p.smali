.class public final Lcom/adjust/sdk/ActivityHandler$p;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/adjust/sdk/ActivityHandler;->gdprForgetMe()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/adjust/sdk/ActivityHandler;


# direct methods
.method public constructor <init>(Lcom/adjust/sdk/ActivityHandler;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/ActivityHandler$p;->a:Lcom/adjust/sdk/ActivityHandler;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c.s@@@l@~@by@@rdii~~ b@   @m@@ oo-~ uS~f4l~t~st ~~~f~v~ ~@/ M1n~ @ i@@o ~oK@o@bo ~  ~ ~@~~@@~/ a"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/adjust/sdk/ActivityHandler$p;->a:Lcom/adjust/sdk/ActivityHandler;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/adjust/sdk/ActivityHandler;->access$2400(Lcom/adjust/sdk/ActivityHandler;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
