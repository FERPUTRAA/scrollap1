.class public Lcom/adjust/sdk/network/UtilNetworking;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;,
        Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;
    }
.end annotation


# static fields
.field private static userAgent:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic access$000()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~tiv~~c~  mt~~y1M@~@i4@bbf~@@ @ ~~s@lKoaof @ n@r@@@b ~ @o~~ ~ @~d~ Si @~.u~ /~~@- o@@@  ol~/o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/adjust/sdk/network/UtilNetworking;->userAgent:Ljava/lang/String;

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method

.method public static createDefaultConnectionOptions()Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lcom/adjust/sdk/network/UtilNetworking$a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/adjust/sdk/network/UtilNetworking$a;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static createDefaultHttpsURLConnectionProvider()Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/adjust/sdk/network/UtilNetworking$b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/adjust/sdk/network/UtilNetworking$b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static extractJsonLong(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    instance-of p1, p0, Ljava/lang/Long;

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v0, 0x1

    const/4 v0, 0x5

    check-cast p0, Ljava/lang/Long;

    const/4 v0, 0x5

    move v1, v0

    return-object p0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    instance-of p1, p0, Ljava/lang/Number;

    const/4 v1, 0x5

    if-eqz p1, :cond_1

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    check-cast p0, Ljava/lang/Number;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p0, Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    double-to-long p0, p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0

    :catch_0
    :cond_2
    const/4 v1, 0x3

    const/4 p0, 0x6

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method public static extractJsonString(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    instance-of p1, p0, Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    check-cast p0, Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-eqz p0, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p0, 0x0

    const/4 v0, 0x0

    move v1, v0

    return-object p0
.end method

.method private static getLogger()Lcom/adjust/sdk/ILogger;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public static setUserAgent(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    sput-object p0, Lcom/adjust/sdk/network/UtilNetworking;->userAgent:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
