.class public Lcom/adjust/sdk/network/UrlStrategy;
.super Ljava/lang/Object;


# static fields
.field private static final BASE_URL_CHINA:Ljava/lang/String; = "https://app.adjust.world"

.field private static final BASE_URL_EU:Ljava/lang/String; = "https://app.eu.adjust.com"

.field private static final BASE_URL_INDIA:Ljava/lang/String; = "https://app.adjust.net.in"

.field private static final BASE_URL_TR:Ljava/lang/String; = "https://app.tr.adjust.com"

.field private static final BASE_URL_US:Ljava/lang/String; = "https://app.us.adjust.com"

.field private static final GDPR_URL_CHINA:Ljava/lang/String; = "https://gdpr.adjust.world"

.field private static final GDPR_URL_EU:Ljava/lang/String; = "https://gdpr.eu.adjust.com"

.field private static final GDPR_URL_INDIA:Ljava/lang/String; = "https://gdpr.adjust.net.in"

.field private static final GDPR_URL_TR:Ljava/lang/String; = "https://gdpr.tr.adjust.com"

.field private static final GDPR_URL_US:Ljava/lang/String; = "https://gdpr.us.adjust.com"

.field private static final SUBSCRIPTION_URL_CHINA:Ljava/lang/String; = "https://subscription.adjust.world"

.field private static final SUBSCRIPTION_URL_EU:Ljava/lang/String; = "https://subscription.eu.adjust.com"

.field private static final SUBSCRIPTION_URL_INDIA:Ljava/lang/String; = "https://subscription.adjust.net.in"

.field private static final SUBSCRIPTION_URL_TR:Ljava/lang/String; = "https://subscription.tr.adjust.com"

.field private static final SUBSCRIPTION_URL_US:Ljava/lang/String; = "https://subscription.us.adjust.com"


# instance fields
.field public final baseUrlChoicesList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final baseUrlOverwrite:Ljava/lang/String;

.field public choiceIndex:I

.field public final gdprUrlChoicesList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final gdprUrlOverwrite:Ljava/lang/String;

.field public startingChoiceIndex:I

.field public final subscriptionUrlChoicesList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final subscriptionUrlOverwrite:Ljava/lang/String;

.field public wasLastAttemptSuccess:Z

.field public wasLastAttemptWithOverwrittenUrl:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    iput-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlOverwrite:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlOverwrite:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlOverwrite:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p4}, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlChoices(Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlChoicesList:Ljava/util/List;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p4}, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlChoices(Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlChoicesList:Ljava/util/List;

    const/4 v1, 0x6

    invoke-static {p4}, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlChoices(Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlChoicesList:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptSuccess:Z

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->choiceIndex:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->startingChoiceIndex:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private static baseUrlChoices(Ljava/lang/String;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ s@i~@@@~sd ~~ b~@~~b1  ~@u~/@ @ @@l/@~o ~@.y@i~f ~m~l o-4cit~@ K a ooof@vo~ M@n~~~  @t~~~rS b@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const-string/jumbo v0, "ntimdialurgyr_tssa"

    const-string v0, "_lsrnadt_itsyigaur"

    const/4 v5, 0x5

    const-string/jumbo v0, "url_strategy_india"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v1, "/tjeosta./msptiu.tph:n.ap"

    const-string v1, "atnmtp.ash/i.pjp.estu/nt:"

    const/4 v5, 0x1

    const-string v1, ".dsnubhpptti.pans.j//et:a"

    const-string v1, "https://app.adjust.net.in"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string v2, "/s.tmpupaoo/:hastupdj."

    const-string/jumbo v2, "us/oo:pajtcspa./tph.md"

    const/4 v5, 0x7

    const-string/jumbo v2, "oc/aap/pdpjhtutmp.ss:."

    const-string v2, "https://app.adjust.com"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v0, "gtrinschqaeatb_yl_"

    const-string v0, "alar_bng_tyseuctih"

    const/4 v5, 0x6

    const-string/jumbo v0, "uysre_tar_nhgsalit"

    const-string/jumbo v0, "url_strategy_china"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "wjpm/:l.d/duta.hrpaoutpt"

    const-string v3, "adrpwputs/ud.thjtpl.:oa/"

    const/4 v5, 0x2

    const-string v3, "a/uto/.:drptphp.daojsstw"

    const-string v3, "https://app.adjust.world"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    filled-new-array {v3, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object p0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const-string v0, "_epntbeuid_recady"

    const-string/jumbo v0, "uedecsepiy_dantr_"

    const/4 v5, 0x0

    const-string/jumbo v0, "nucayeu_airseted_"

    const-string v0, "data_residency_eu"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const-string p0, ".t.umpqpsat.ae/popj/:dhst"

    const-string/jumbo p0, "p/ot:aahqtessd/j.up.tup.m"

    const/4 v5, 0x5

    const-string p0, "/h/c.tj:q.tpsdaaus.tppuoe"

    const-string p0, "https://app.eu.adjust.com"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-object p0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v0, "y_sdadarcetstisr_"

    const-string/jumbo v0, "rescnsd_yttraaid_"

    const/4 v5, 0x4

    const-string v0, "aaemcetst_idydr_r"

    const-string v0, "data_residency_tr"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    const/4 v4, 0x5

    const-string p0, "ajopoat.sm.rsptpttd./mh/c"

    const-string p0, ".srmtj/.uphc/dm.atappttso"

    const/4 v5, 0x0

    const-string/jumbo p0, "ttt/hbosp.pcts.u:ajpd.m/a"

    const-string p0, "https://app.tr.adjust.com"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-object p0

    :cond_3
    const/4 v5, 0x1

    const-string/jumbo v0, "ty_aseueosadc_dir"

    const-string v0, "dyusot_eacr_iaeds"

    const/4 v5, 0x7

    const-string v0, "aesers_pcytd_dain"

    const-string v0, "data_residency_us"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz p0, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p0, "j/shs.muqt/.sbtp:aocup.dp"

    const-string/jumbo p0, "puu..bma./sopajh/cs:pdstt"

    const/4 v5, 0x1

    const-string/jumbo p0, "posths:m/jpuaatd.tpssu./c"

    const-string p0, "https://app.us.adjust.com"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    return-object p0

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    filled-new-array {v2, v1, v3}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object p0
.end method

.method private static gdprUrlChoices(Ljava/lang/String;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v0, "luamiyt__suarnerit"

    const-string/jumbo v0, "uiley_uiragasr_ntt"

    const/4 v5, 0x2

    const-string/jumbo v0, "rua_olntys_dratieg"

    const-string/jumbo v0, "url_strategy_india"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const-string v1, "gnrapb/te..tshd.p/ptntd:iu"

    const-string/jumbo v1, "pds/.etppr./itn:sahd.tngtu"

    const/4 v5, 0x3

    const-string/jumbo v1, "nhjpguurstd.ae/n..p:tidtst"

    const-string v1, "https://gdpr.adjust.net.in"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, "dpq.ctgp./mtdsh/saurtjo"

    const-string v2, "cuht.s/oqrdp/mpjsdgt.ta"

    const/4 v5, 0x7

    const-string/jumbo v2, "tag.opdsqhp/ujttsr.c/:d"

    const-string v2, "https://gdpr.adjust.com"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string/jumbo v0, "usserarlgithas_ntc"

    const-string/jumbo v0, "u_slgtrrhtaincsae_"

    const/4 v5, 0x7

    const-string/jumbo v0, "inamy_l_trasgehtcr"

    const-string/jumbo v0, "url_strategy_china"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string v3, ".sdrot:wdutsplh.gtmrd/opj"

    const-string/jumbo v3, "wsgmahjds.upttr./lrdt:odp"

    const/4 v5, 0x5

    const-string/jumbo v3, "td/.lbw.:trutdrdpsg/jpsoh"

    const-string v3, "https://gdpr.adjust.world"

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    filled-new-array {v3, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object p0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v0, "_estueuciradoa_yd"

    const-string/jumbo v0, "nticoeradd_uy_sea"

    const/4 v5, 0x6

    const-string v0, "_ciaduep_erasyent"

    const-string v0, "data_residency_eu"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const-string p0, ".gp:ru.jq/mstasd.ep/hucbto"

    const-string p0, "d.dumbcpg/uost/tsej:..aphr"

    const/4 v5, 0x2

    const-string p0, "https://gdpr.eu.adjust.com"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v0, "crs_iardstdenea_y"

    const-string v0, "driyeeutn_sd_caar"

    const/4 v5, 0x1

    const-string/jumbo v0, "t__mrsietecanydrd"

    const-string v0, "data_residency_tr"

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    const-string/jumbo p0, "pc:totdd./.gjprhatp.tmrsuo"

    const-string p0, ":cmratgppp/hjdt.osd..sturt"

    const/4 v5, 0x7

    const-string p0, ".uogtbm:./tptt/sdrdcarp.js"

    const-string p0, "https://gdpr.tr.adjust.com"

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v0, "su_yaauic_eqtrnsd"

    const-string/jumbo v0, "se_ensdrqa_iyauct"

    const/4 v5, 0x7

    const-string v0, "aee_nctp_rssaydud"

    const-string v0, "data_residency_us"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string p0, "/ot..dg.qsums/htutd:apcpjs"

    const-string/jumbo p0, "pgs.ptamct:sot/u.hds/d.jsu"

    const/4 v5, 0x6

    const-string/jumbo p0, "j.sudt.o/ps/ushsgdm.pra:tc"

    const-string p0, "https://gdpr.us.adjust.com"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p0

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    filled-new-array {v2, v1, v3}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    return-object p0
.end method

.method private static subscriptionUrlChoices(Ljava/lang/String;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x1

    const-string/jumbo v0, "t_emdimiynragulrat"

    const-string/jumbo v0, "iygmtdiarratn_leu_"

    const/4 v5, 0x3

    const-string/jumbo v0, "tladorisyrnegtu_a_"

    const-string/jumbo v0, "url_strategy_india"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string/jumbo v1, "os.ctb.hit/naus:ti.pnbipstut/dnjoe"

    const-string/jumbo v1, "tihnoseiantno.u/prbsptutt.i:/ds.cj"

    const/4 v5, 0x4

    const-string/jumbo v1, "jtsi.eupbhn.u:us/oiisdctnntprstt./"

    const-string v1, "https://subscription.adjust.net.in"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "tch/:appcni/stosjtu.r.sbptumbid"

    const-string/jumbo v2, "pr.jubm:ui.tconstst/thica/opbsd"

    const-string/jumbo v2, "tsrmusioqp./.jtb:nttca/scsohuid"

    const-string v2, "https://subscription.adjust.com"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object p0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v0, "slsinuctt_ehyguarr"

    const-string v0, "_shyttuaeg_lnricru"

    const/4 v5, 0x3

    const-string v0, "_yamnr_ethucagtsil"

    const-string/jumbo v0, "url_strategy_china"

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v3, "bupsohsp.rwuptss:dcliatrn//.dotji"

    const/4 v5, 0x0

    const-string/jumbo v3, "titlo:u/wdstjbass.d/porprtsc.iuno"

    const-string v3, "https://subscription.adjust.world"

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    filled-new-array {v3, v2}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v0, "crduqbeaea_tsiyed"

    const-string v0, "cere_ueaqdysi_atd"

    const/4 v5, 0x7

    const-string v0, "eurytiueec_daasdn"

    const-string v0, "data_residency_eu"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string p0, ".usiupsp:t.orehndp/u/bmttsc.ijacst"

    const-string p0, "https://subscription.eu.adjust.com"

    const/4 v5, 0x0

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const-string v0, "eysc_asnriettdda_"

    const/4 v5, 0x0

    const-string v0, "ancs_ireqdeyrtd_t"

    const-string v0, "data_residency_tr"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo p0, "ossrbcsnc.udpstomt/m.pu:istiratt/h"

    const-string p0, ".osmpphdcamott/tt.rbutisr:/ucsns.i"

    const/4 v5, 0x7

    const-string/jumbo p0, "usmmrtar/opujd:ic.hpic.tobtssstn/."

    const-string p0, "https://subscription.tr.adjust.com"

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object p0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "uddros_aeansy_coe"

    const-string/jumbo v0, "udcyoe_eatsdr_nas"

    const/4 v5, 0x7

    const-string/jumbo v0, "stycubidada_r_een"

    const-string v0, "data_residency_us"

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz p0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p0, "trpjpsuubmhs.tauso/:us/itc.cdsn.to"

    const-string/jumbo p0, "titt/b.opb.ujsucspto.:ucssnsdmah/r"

    const/4 v5, 0x1

    const-string/jumbo p0, "s.:/busppsnaui.pso.rctctijotdsmhut"

    const-string p0, "https://subscription.us.adjust.com"

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object p0

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    filled-new-array {v2, v1, v3}, [Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0
.end method


# virtual methods
.method public resetAfterSuccess()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/adjust/sdk/network/UrlStrategy;->choiceIndex:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/adjust/sdk/network/UrlStrategy;->startingChoiceIndex:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-boolean v0, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptSuccess:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public shouldRetryAfterFailure(Lcom/adjust/sdk/ActivityKind;)Z
    .locals 5

    const/4 v3, 0x3

    move v4, v3

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    move v4, v3

    iput-boolean v0, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptSuccess:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    const/4 v4, 0x4

    if-ne p1, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlChoicesList:Ljava/util/List;

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v1, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v3, 0x0

    move v4, v3

    if-ne p1, v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlChoicesList:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlChoicesList:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->choiceIndex:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/2addr v1, v2

    const/4 v4, 0x0

    rem-int/2addr v1, p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->choiceIndex:I

    const/4 v3, 0x4

    move v4, v3

    iget p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->startingChoiceIndex:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v1, p1, :cond_3

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    const/4 v4, 0x5

    move v0, v2

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v0
.end method

.method public targetUrlByActivityKind(Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    move v4, v3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlOverwrite:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-boolean v2, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->gdprUrlChoicesList:Ljava/util/List;

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    iget v0, p0, Lcom/adjust/sdk/network/UrlStrategy;->choiceIndex:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast p1, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne p1, v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlOverwrite:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-boolean v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-boolean v2, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->subscriptionUrlChoicesList:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlOverwrite:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-boolean v1, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x2

    iput-boolean v2, p0, Lcom/adjust/sdk/network/UrlStrategy;->wasLastAttemptWithOverwrittenUrl:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/network/UrlStrategy;->baseUrlChoicesList:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0
.end method
