.class public Lcom/adjust/sdk/network/ActivityPackageSender;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/adjust/sdk/network/IActivityPackageSender;


# instance fields
.field private basePath:Ljava/lang/String;

.field private clientSdk:Ljava/lang/String;

.field private connectionOptions:Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;

.field private executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

.field private gdprPath:Ljava/lang/String;

.field private httpsURLConnectionProvider:Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;

.field private logger:Lcom/adjust/sdk/ILogger;

.field private subscriptionPath:Ljava/lang/String;

.field private urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->basePath:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->gdprPath:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->subscriptionPath:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p5, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->clientSdk:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getLogger()Lcom/adjust/sdk/ILogger;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-instance p2, Lcom/adjust/sdk/scheduler/SingleThreadCachedScheduler;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    const-string p3, "eestygAaiictsSredcnaP"

    const-string/jumbo p3, "tesgnkirtAecPdycieaaS"

    const/4 v1, 0x1

    const-string/jumbo p3, "yatmPtvaedrnkeiecAigS"

    const-string p3, "ActivityPackageSender"

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p2, p3}, Lcom/adjust/sdk/scheduler/SingleThreadCachedScheduler;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-instance p2, Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v1, 0x4

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getBaseUrl()Ljava/lang/String;

    move-result-object p3

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getGdprUrl()Ljava/lang/String;

    move-result-object p4

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getSubscriptionUrl()Ljava/lang/String;

    move-result-object p5

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p2, p3, p4, p5, p1}, Lcom/adjust/sdk/network/UrlStrategy;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v1, 0x5

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getHttpsURLConnectionProvider()Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->httpsURLConnectionProvider:Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {}, Lcom/adjust/sdk/AdjustFactory;->getConnectionOptions()Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->connectionOptions:Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method private buildAndExtractAuthorizationHeader(Ljava/util/Map;Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/adjust/sdk/ActivityKind;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "/~a~o4o~f@~@d@   l@~b~ @i o@~iM ~@ot~~@ ~s-i1oo r @K~~v~.@@@b ~  u nb@y~t@l  f~~o@S @@~c@~~m@ ~@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    invoke-virtual {p2}, Lcom/adjust/sdk/ActivityKind;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractSecretId(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractHeadersId(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractSignature(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractAlgorithm(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractNativeVersion(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/adjust/sdk/network/ActivityPackageSender;->buildAuthorizationHeaderV2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-object v0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractAppSecret(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {p0, p1, v0, v6, p2}, Lcom/adjust/sdk/network/ActivityPackageSender;->buildAuthorizationHeaderV1(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object p1
.end method

.method private buildAuthorizationHeaderV1(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz p2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0, p1, p4, p2}, Lcom/adjust/sdk/network/ActivityPackageSender;->getSignature(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo p2, "tgnclbareue_aim"

    const-string p2, "euamntcilgare_s"

    const/4 v4, 0x2

    const-string p2, "at_uscuegrirnel"

    const-string p2, "clear_signature"

    const/4 v4, 0x1

    invoke-interface {p1, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast p2, Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p2}, Lcom/adjust/sdk/Util;->sha256(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p4, "ipdeof"

    const-string/jumbo p4, "lidfoe"

    const/4 v4, 0x0

    const-string p4, "flqdie"

    const-string p4, "fields"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-interface {p1, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast p1, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p4, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array v0, p4, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    aput-object p3, v0, v1

    const/4 v4, 0x4

    const-string p3, "/_s/s/ebc/%iesd="

    const-string p3, "/s=/sbed/%e_icr/"

    const/4 v4, 0x4

    const-string/jumbo p3, "s/=me/ics%_der//"

    const-string/jumbo p3, "secret_id=\"%s\""

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p3, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-array v0, p4, [Ljava/lang/Object;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    aput-object p2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p2, "ue//ots/%=r/igun"

    const-string/jumbo p2, "tae//sugu%ni=//r"

    const/4 v4, 0x0

    const-string p2, "/%ne/bu/=tgsa/si"

    const-string/jumbo p2, "signature=\"%s\""

    const/4 v4, 0x0

    invoke-static {p2, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-array v0, p4, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const-string/jumbo v2, "us2hp6"

    const-string v2, "2ph6sa"

    const/4 v4, 0x0

    const-string v2, "2ph65a"

    const-string/jumbo v2, "sha256"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const-string/jumbo v2, "mgroh%/aq/t=//ls"

    const/4 v4, 0x0

    const-string v2, "/lo%ari/qths//gm"

    const-string v2, "algorithm=\"%s\""

    const/4 v3, 0x0

    move v4, v3

    invoke-static {v2, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array v2, p4, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    aput-object p1, v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo p1, "s/s/=hree%sda/"

    const-string p1, "essa//=r/hd%e/"

    const/4 v4, 0x5

    const-string p1, "/=/msrs/dha/e%"

    const-string p1, "headers=\"%s\""

    const/4 v4, 0x6

    invoke-static {p1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    aput-object p3, v2, v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    aput-object p2, v2, p4

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    aput-object v0, v2, p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p2, 0x3

    const/4 v3, 0x7

    move v4, v3

    aput-object p1, v2, p2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p1, "e%,sogsnS%tir%a, ums%"

    const-string p1, "Ssem%%us sn,i%a,rt,g%"

    const/4 v4, 0x0

    const-string p1, ",S%e%b su%in,sr%gstas"

    const-string p1, "Signature %s,%s,%s,%s"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, v2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-array p3, p4, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput-object p1, p3, v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p4, "sritrnua%aetoo :azHodui"

    const-string p4, "anrdoozitsoaH%etu arie:"

    const/4 v4, 0x5

    const-string p4, "eu:thr%pardoztaHisi oen"

    const-string p4, "authorizationHeader: %s"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {p2, p4, p3}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object p1

    :cond_1
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p1
.end method

.method private buildAuthorizationHeaderV2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x2

    move v4, v3

    if-nez p3, :cond_0

    const/4 v3, 0x2

    move v4, v3

    goto/16 :goto_2

    :cond_0
    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x3

    aput-object p1, v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const-string p1, "bsg%t/niqs=a/uer"

    const-string p1, "/a/sib%gsnue=t/r"

    const/4 v4, 0x0

    const-string p1, "/%san//=tusegs/r"

    const-string/jumbo p1, "signature=\"%s\""

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object p2, v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string p2, "%//mstc/_dree=ui"

    const-string p2, "e//d_iuc/te/sr=%"

    const/4 v4, 0x4

    const-string/jumbo p2, "t=/ioc//%ds_/esr"

    const-string/jumbo p2, "secret_id=\"%s\""

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p2, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput-object p3, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo p3, "s=rdabhde/p/_%e//"

    const-string p3, "h=i///rpadsdee/%_"

    const/4 v4, 0x7

    const-string/jumbo p3, "rs=_/iuedsda/eh//"

    const-string p3, "headers_id=\"%s\""

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p3, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz p4, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const-string p4, "adj1"

    const-string p4, "daj1"

    const/4 v4, 0x4

    const-string p4, "adj1"

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    aput-object p4, v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo p4, "tos/%/ipla=mhgqr"

    const-string/jumbo p4, "s/air/=tqmoh/g%l"

    const/4 v4, 0x1

    const-string p4, "//ahmil%qsg/tr=/"

    const-string p4, "algorithm=\"%s\""

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p4, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    if-eqz p5, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string p5, ""

    const-string p5, ""

    const/4 v4, 0x4

    const-string p5, ""

    const-string p5, ""

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    aput-object p5, v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo p5, "s=svr%nniavs_soti/ee/"

    const-string p5, "ess%as/enrv/=_oi/tinv"

    const/4 v4, 0x2

    const-string p5, "_sem/i/nis=envrtav/%/"

    const-string/jumbo p5, "native_version=\"%s\""

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p5, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    aput-object p1, v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput-object p2, v1, v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object p4, v1, p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 p1, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object p3, v1, p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p1, 0x4

    const/4 v4, 0x2

    aput-object p5, v1, p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string p1, "%tsgo,Sesms%i,r, ,%%s%su"

    const-string p1, " ,,m%%g,r%ssisuSnses%t,%"

    const/4 v4, 0x1

    const-string p1, ",s,%sbn s,%g%%e%uaS,tssr"

    const-string p1, "Signature %s,%s,%s,%s,%s"

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1, v1}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-array p3, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    aput-object p1, p3, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const-string/jumbo p4, "zurt%Huo:aasoeentaioi r"

    const-string/jumbo p4, "ntrrodeauaooe %izH:tias"

    const/4 v4, 0x1

    const-string p4, "ar aztepsroit%ihnoeuad:"

    const-string p4, "authorizationHeader: %s"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p2, p4, p3}, Lcom/adjust/sdk/ILogger;->verbose(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p1

    :cond_3
    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object p1
.end method

.method private configConnectionForGET(Ljavax/net/ssl/HttpsURLConnection;)Ljava/io/DataOutputStream;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "GET"

    const-string v0, "GTE"

    const/4 v2, 0x2

    const-string v0, "TGE"

    const-string v0, "GET"

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    move v2, v1

    return-object p1
.end method

.method private configConnectionForPOST(Ljavax/net/ssl/HttpsURLConnection;Ljava/util/Map;Ljava/util/Map;)Ljava/io/DataOutputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljavax/net/ssl/HttpsURLConnection;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/io/DataOutputStream;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, "OSPT"

    const/4 v2, 0x7

    const-string v0, "STPO"

    const-string v0, "POST"

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v2, 0x7

    const/4 v0, 0x1

    move v1, v0

    move v1, v0

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, p2, p3}, Lcom/adjust/sdk/network/ActivityPackageSender;->generatePOSTBodyString(Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p3, Ljava/io/DataOutputStream;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p3, p1}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p3, p2}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p3
.end method

.method private errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p3}, Lcom/adjust/sdk/ActivityPackage;->getFailureMessage()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/adjust/sdk/Util;->getReasonString(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    aput-object p3, p2, v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p3, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    aput-object p1, p2, p3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo p1, "q(s). sb"

    const-string/jumbo p1, "s(%.)b s"

    const/4 v2, 0x6

    const-string p1, ")(sss %."

    const-string p1, "%s. (%s)"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method private static extractAlgorithm(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo v0, "iogmrhlta"

    const-string v0, "hlriotuag"

    const/4 v2, 0x1

    const-string/jumbo v0, "tarlohmig"

    const-string v0, "algorithm"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method private static extractAppSecret(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "pcp_ebpres"

    const-string v0, "_estrepppc"

    const/4 v2, 0x6

    const-string/jumbo v0, "tsapecue_r"

    const-string v0, "app_secret"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    return-object p0
.end method

.method private static extractEventCallbackId(Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "ctqkbaeplilvane_c"

    const-string v0, "acdvcebnqti_allek"

    const/4 v2, 0x2

    const-string v0, "ecbnv_lcqkleadi_t"

    const-string v0, "event_callback_id"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method private static extractHeadersId(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x4

    const-string v0, "hrsidsaees"

    const-string v0, "dishesader"

    const/4 v2, 0x6

    const-string/jumbo v0, "seemidra_h"

    const-string v0, "headers_id"

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x6

    return-object p0
.end method

.method private static extractNativeVersion(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "ovisoiann_tevr"

    const-string/jumbo v0, "native_version"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method private static extractSecretId(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "_erdibsec"

    const-string v0, "edrmcies_"

    const/4 v2, 0x2

    const-string/jumbo v0, "sde_reutc"

    const-string/jumbo v0, "secret_id"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method private static extractSignature(Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo v0, "rtnsugapo"

    const-string/jumbo v0, "urstoagni"

    const/4 v2, 0x2

    const-string v0, "egstarniq"

    const-string/jumbo v0, "signature"

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method private generatePOSTBodyString(Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->injectParametersToPOSTStringBuilder(Ljava/util/Map;Ljava/lang/StringBuilder;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p2, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->injectParametersToPOSTStringBuilder(Ljava/util/Map;Ljava/lang/StringBuilder;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-lez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 p2, 0x26

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne p1, p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method private generateUrlStringForGET(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/ActivityKind;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/network/UrlStrategy;->targetUrlByActivityKind(Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, p1, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->urlWithExtraPathByActivityKind(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Ljava/net/URL;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p1, Landroid/net/Uri$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p1}, Landroid/net/Uri$Builder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/net/URL;->getAuthority()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Landroid/net/Uri$Builder;->encodedAuthority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/net/URL;->getPath()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Landroid/net/Uri$Builder;->path(Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    move v4, v0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/net/Uri$Builder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "t:si oug  etrqek% aubnrls"

    const-string v1, "% os baeMurtkglu t qeir:n"

    const/4 v4, 0x0

    const-string/jumbo v1, "rsqm%ueietkto : uMn al rs"

    const-string v1, "Making request to url: %s"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {p2, v1, v0}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p3, :cond_0

    const/4 v4, 0x1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast p3, Ljava/util/Map$Entry;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-interface {p3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast p3, Ljava/lang/String;

    const/4 v4, 0x1

    invoke-virtual {p1, v0, p3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz p4, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {p4}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast p3, Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p4

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p4, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast p3, Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, p4, p3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    return-object p1
.end method

.method private generateUrlStringForPOST(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/network/UrlStrategy;->targetUrlByActivityKind(Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->urlWithExtraPathByActivityKind(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    move v3, v2

    aput-object p1, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    aput-object p2, v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo p2, "s%%s"

    const-string p2, "%s%s"

    const-string p2, "%s%s"

    const-string p2, "%s%s"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p2, v0}, Lcom/adjust/sdk/Util;->formatString(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    aput-object p2, p1, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "gattouMruo % eqsi  :sln rk"

    const-string v1, "Making request to url : %s"

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, v1, p1}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p2
.end method

.method private getSignature(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string v0, "_tteebcrad"

    const-string v0, "created_at"

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct {p0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->getValidIdentifier(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    check-cast v3, Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string/jumbo v4, "uueorc"

    const-string/jumbo v4, "source"

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    check-cast v5, Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string/jumbo v6, "ppoaayd"

    const-string/jumbo v6, "payload"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {p1, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    new-instance v7, Ljava/util/HashMap;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const-string/jumbo v8, "treepau_qc"

    const-string/jumbo v8, "r_sectueap"

    const/4 v10, 0x5

    const-string/jumbo v8, "tpscspeae_"

    const-string v8, "app_secret"

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v7, v8, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v7, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const-string/jumbo p3, "pntmtkiadvyic"

    const-string/jumbo p3, "intict_pyvkad"

    const/4 v10, 0x6

    const-string p3, "_iciotdkvaniy"

    const-string p3, "activity_kind"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v7, p3, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v7, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v5, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v7, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz p1, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v7, v6, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-virtual {v7}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x7

    const-string p2, ""

    const-string p2, ""

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    :cond_2
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz v0, :cond_3

    const/4 v9, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eqz v1, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    shr-int/2addr v10, v9

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    check-cast p2, Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string p2, " "

    const-string p2, " "

    const/4 v10, 0x6

    const-string p2, " "

    const-string p2, " "

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    check-cast p3, Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    const/4 v10, 0x4

    const/4 v9, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v0, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p2, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p2, Ljava/util/HashMap;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string/jumbo v0, "rceiebaugasntl_"

    const-string v0, "clear_signature"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v0, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string/jumbo p3, "udefiq"

    const-string/jumbo p3, "idqlfe"

    const/4 v10, 0x1

    const-string p3, "fpesil"

    const-string p3, "fields"

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p2, p3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x3

    return-object p2
.end method

.method private getValidIdentifier(Ljava/util/Map;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "qdpsa_gd"

    const-string v0, "gdsdspa_"

    const/4 v3, 0x2

    const-string/jumbo v0, "sgsadipd"

    const-string v0, "gps_adid"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "eidmadi_f"

    const-string v0, "ai_meifdd"

    const/4 v3, 0x5

    const-string v0, "fid_oared"

    const-string v0, "fire_adid"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "oa_idbrdin"

    const-string v0, "android_id"

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "aodiduuoiunr"

    const-string/jumbo v0, "rdnuoouiaddi"

    const/4 v3, 0x5

    const-string v0, "dud_ndapioiu"

    const-string v0, "android_uuid"

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1
.end method

.method private injectParametersToPOSTStringBuilder(Ljava/util/Map;Ljava/lang/StringBuilder;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/StringBuilder;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, "FbUq8"

    const-string v2, "bF8U-"

    const-string v2, "F8sT-"

    const-string v2, "UTF-8"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1, v2}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v2}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x0

    const-string v0, ""

    const-string v0, ""

    :goto_1
    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v1, "="

    const-string v1, "="

    const/4 v4, 0x5

    const-string v1, "="

    const-string v1, "="

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, "&"

    const-string v0, "&"

    const/4 v4, 0x5

    const-string v0, "&"

    const-string v0, "&"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto/16 :goto_0

    :cond_2
    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method

.method private localError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p3, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p2, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, p3, Lcom/adjust/sdk/ResponseData;->message:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p3, Lcom/adjust/sdk/ResponseData;->willRetry:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private parseResponse(Lcom/adjust/sdk/ResponseData;Ljava/lang/String;)V
    .locals 5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v0, "gysm nnto sprstreepEu"

    const-string/jumbo v0, "ngpstsu yEs mnerprteo"

    const/4 v4, 0x4

    const-string v0, "i soonr ptEserpsymeng"

    const-string v0, "Empty response string"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {p1, v0, p2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x0

    invoke-direct {v0, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "lrpeebrsdeJNiaOosaSnpep  F ot"

    const-string v2, "Nsrasrlpenpo S  eFoO tapdJeei"

    const/4 v4, 0x1

    const-string/jumbo v2, "soFa euopnSi prs eJte dlaseOr"

    const-string v2, "Failed to parse JSON response"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0, p2, v2, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {v0, p2, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p1, Lcom/adjust/sdk/ResponseData;->jsonResponse:Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo p2, "peqgems"

    const-string/jumbo p2, "sqegmea"

    const/4 v4, 0x6

    const-string p2, "aqesems"

    const-string/jumbo p2, "message"

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonString(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->message:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p2, "addi"

    const-string/jumbo p2, "idad"

    const/4 v4, 0x1

    const-string p2, "ddai"

    const-string p2, "adid"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonString(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->adid:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo p2, "saseispmm"

    const-string/jumbo p2, "tmsempsia"

    const/4 v4, 0x7

    const-string/jumbo p2, "impmseamt"

    const-string/jumbo p2, "timestamp"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonString(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->timestamp:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string p2, "gmakocttia_rne"

    const-string/jumbo p2, "t_imrkaanetcgt"

    const/4 v4, 0x4

    const-string/jumbo p2, "tie_cbttagankr"

    const-string/jumbo p2, "tracking_state"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonString(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v1, "tdet_ouou"

    const-string/jumbo v1, "opted_out"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object p2, Lcom/adjust/sdk/TrackingState;->OPTED_OUT:Lcom/adjust/sdk/TrackingState;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->trackingState:Lcom/adjust/sdk/TrackingState;

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo p2, "spoi_n"

    const-string/jumbo p2, "kin_os"

    const/4 v4, 0x0

    const-string/jumbo p2, "skqn_i"

    const-string p2, "ask_in"

    const/4 v4, 0x0

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonLong(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->askIn:Ljava/lang/Long;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo p2, "nystrebr"

    const-string/jumbo p2, "yne_rbrt"

    const/4 v4, 0x0

    const-string/jumbo p2, "neymrr_t"

    const-string/jumbo p2, "retry_in"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonLong(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->retryIn:Ljava/lang/Long;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string p2, "ecniniutnu_"

    const/4 v4, 0x5

    const-string p2, "cnotonu_iin"

    const-string p2, "continue_in"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0, p2}, Lcom/adjust/sdk/network/UtilNetworking;->extractJsonLong(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->continueIn:Ljava/lang/Long;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo p2, "nitoabittpr"

    const-string p2, "btrinitpoat"

    const/4 v4, 0x3

    const-string/jumbo p2, "oaittruntbu"

    const-string p2, "attribution"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p1, Lcom/adjust/sdk/ResponseData;->adid:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->clientSdk:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/adjust/sdk/Util;->getSdkPrefixPlatform(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p2, v0, v1}, Lcom/adjust/sdk/AdjustAttribution;->fromJson(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Lcom/adjust/sdk/AdjustAttribution;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object p2, p1, Lcom/adjust/sdk/ResponseData;->attribution:Lcom/adjust/sdk/AdjustAttribution;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method

.method private remoteError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p3, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v3, 0x2

    invoke-direct {p0, p1, p2, v1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string p1, "i eltr pl rrqtylW"

    const-string/jumbo p1, "rre  Wlyqtrtlile "

    const/4 v3, 0x7

    const-string/jumbo p1, "lraylWt qer le it"

    const-string p1, " Will retry later"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    invoke-interface {p2, p1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, p3, Lcom/adjust/sdk/ResponseData;->message:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-boolean p1, p3, Lcom/adjust/sdk/ResponseData;->willRetry:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private shouldRetryToSend(Lcom/adjust/sdk/ResponseData;)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-boolean v0, p1, Lcom/adjust/sdk/ResponseData;->willRetry:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v2, "t scrlwet titsey asronehrWrl  tgnlrtu yu"

    const-string/jumbo v2, "ttsnnca yi rrtreluuer tWrolltsewy h g ti"

    const/4 v4, 0x7

    const-string/jumbo v2, "yl msittwtgre tl rilWe nrnrr  htecturyau"

    const-string v2, "Will not retry with current url strategy"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p1, v2, v0}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/adjust/sdk/network/UrlStrategy;->resetAfterSuccess()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->urlStrategy:Lcom/adjust/sdk/network/UrlStrategy;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityKind:Lcom/adjust/sdk/ActivityKind;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lcom/adjust/sdk/network/UrlStrategy;->shouldRetryAfterFailure(Lcom/adjust/sdk/ActivityKind;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v1, "yrnroatttermuwe wt iiwrci,tn e rywgeir diabutl  l tt l Fsueh"

    const-string/jumbo v1, "iremlt  e agFieetticwbtnrl,w  r iurlt uw   wenrttshyiuydatlr"

    const/4 v4, 0x7

    const-string/jumbo v1, "nly  bwalrehrigtswtnr rletiFi ewtdb,tri   lutr w htee aiyucu"

    const-string v1, "Failed with current url strategy, but it will retry with new"

    const/4 v4, 0x5

    invoke-interface {p1, v1, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v2, "e aeotu tea oiawllnrui tlg hriyntrttdt s Fw  uilrcrrne"

    const-string v2, "dtt onwrh  lrietg iiyctyrwloF lnrausla r ttt inaeue re"

    const/4 v4, 0x4

    const-string v2, "htaituap  Fee yrrngrtw nrltiwoee   llrdrda ltsnii uytt"

    const-string v2, "Failed with current url strategy and it will not retry"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p1, v2, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v1
.end method

.method private tryToGetResponse(Lcom/adjust/sdk/ResponseData;)V
    .locals 13

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string/jumbo v0, "ogFmdss qn nlh oeaiclnurtainngtocet cui tuspb"

    const-string/jumbo v0, "mc nhbntilccolue prunn tugsda Fsogensoati int"

    const/4 v12, 0x4

    const-string/jumbo v0, "ldstrhpi coeunisnostneotcg  o asltgnna niuFcm"

    const-string v0, "Flushing and closing connection output stream"

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    const/4 v1, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/4 v2, 0x0

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    iget-object v3, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-instance v4, Ljava/util/HashMap;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getParameters()Ljava/util/Map;

    move-result-object v5

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-direct {v4, v5}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget-object v5, p1, Lcom/adjust/sdk/ResponseData;->sendingParameters:Ljava/util/Map;

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getActivityKind()Lcom/adjust/sdk/ActivityKind;

    move-result-object v6

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-direct {p0, v4, v6}, Lcom/adjust/sdk/network/ActivityPackageSender;->buildAndExtractAuthorizationHeader(Ljava/util/Map;Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v7, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x4

    invoke-virtual {v7}, Lcom/adjust/sdk/ActivityPackage;->getActivityKind()Lcom/adjust/sdk/ActivityKind;

    move-result-object v7

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    sget-object v8, Lcom/adjust/sdk/ActivityKind;->ATTRIBUTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    const/4 v9, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x3

    if-ne v7, v8, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    move v7, v9

    move v7, v9

    const/4 v12, 0x0

    move v7, v9

    move v7, v9

    const/4 v12, 0x2

    goto :goto_0

    :cond_0
    const/4 v12, 0x3

    const/4 v11, 0x0

    move v7, v1

    move v7, v1

    move v7, v1

    move v7, v1

    :goto_0
    const/4 v12, 0x6

    const/4 v11, 0x7

    if-eqz v7, :cond_1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-static {v4}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractEventCallbackId(Ljava/util/Map;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getActivityKind()Lcom/adjust/sdk/ActivityKind;

    move-result-object v8

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getPath()Ljava/lang/String;

    move-result-object v10

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-direct {p0, v8, v10, v4, v5}, Lcom/adjust/sdk/network/ActivityPackageSender;->generateUrlStringForGET(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    goto :goto_1

    :cond_1
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getActivityKind()Lcom/adjust/sdk/ActivityKind;

    move-result-object v8

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getPath()Ljava/lang/String;

    move-result-object v10

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {p0, v8, v10}, Lcom/adjust/sdk/network/ActivityPackageSender;->generateUrlStringForPOST(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    :goto_1
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    new-instance v10, Ljava/net/URL;

    const/4 v12, 0x1

    invoke-direct {v10, v8}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v8, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->httpsURLConnectionProvider:Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-interface {v8, v10}, Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;->generateHttpsURLConnection(Ljava/net/URL;)Ljavax/net/ssl/HttpsURLConnection;

    move-result-object v8

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-object v10, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->connectionOptions:Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;

    const/4 v12, 0x0

    invoke-virtual {v3}, Lcom/adjust/sdk/ActivityPackage;->getClientSdk()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {v10, v8, v3}, Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;->applyConnectionOptions(Ljavax/net/ssl/HttpsURLConnection;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-eqz v6, :cond_2

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-string/jumbo v3, "urtmiAoiunoah"

    const-string/jumbo v3, "ihnutzuiAraoo"

    const/4 v12, 0x2

    const-string/jumbo v3, "ontioAhzuiaot"

    const-string v3, "Authorization"

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-virtual {v8, v3, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v12, 0x6

    const/4 v11, 0x4

    if-eqz v7, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {p0, v8}, Lcom/adjust/sdk/network/ActivityPackageSender;->configConnectionForGET(Ljavax/net/ssl/HttpsURLConnection;)Ljava/io/DataOutputStream;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    goto :goto_2

    :cond_3
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {v4}, Lcom/adjust/sdk/network/ActivityPackageSender;->extractEventCallbackId(Ljava/util/Map;)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-direct {p0, v8, v4, v5}, Lcom/adjust/sdk/network/ActivityPackageSender;->configConnectionForPOST(Ljavax/net/ssl/HttpsURLConnection;Ljava/util/Map;Ljava/util/Map;)Ljava/io/DataOutputStream;

    move-result-object v2

    :goto_2
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p0, v8, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->readConnectionResponse(Ljavax/net/ssl/HttpsURLConnection;Lcom/adjust/sdk/ResponseData;)Ljava/lang/Integer;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v4, p1, Lcom/adjust/sdk/ResponseData;->jsonResponse:Lorg/json/JSONObject;

    const/4 v12, 0x0

    const/4 v11, 0x3

    if-eqz v4, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-object v4, p1, Lcom/adjust/sdk/ResponseData;->retryIn:Ljava/lang/Long;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-nez v4, :cond_4

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    if-eqz v3, :cond_4

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/16 v4, 0xc8

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-ne v3, v4, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x5

    move v3, v9

    move v3, v9

    const/4 v12, 0x0

    move v3, v9

    move v3, v9

    const/4 v12, 0x5

    const/4 v11, 0x6

    goto :goto_3

    :cond_4
    const/4 v11, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    move v3, v1

    const/4 v12, 0x6

    move v3, v1

    move v3, v1

    :goto_3
    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    iput-boolean v3, p1, Lcom/adjust/sdk/ResponseData;->success:Z

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-object v3, p1, Lcom/adjust/sdk/ResponseData;->jsonResponse:Lorg/json/JSONObject;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-eqz v3, :cond_6

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-object v3, p1, Lcom/adjust/sdk/ResponseData;->retryIn:Ljava/lang/Long;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-eqz v3, :cond_5

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    goto :goto_4

    :cond_5
    const/4 v12, 0x3

    move v9, v1

    move v9, v1

    const/4 v12, 0x3

    move v9, v1

    move v9, v1

    :cond_6
    :goto_4
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    iput-boolean v9, p1, Lcom/adjust/sdk/ResponseData;->willRetry:Z
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_c
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_a
    .catch Ljava/net/ProtocolException; {:try_start_0 .. :try_end_0} :catch_8
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_6
    .catch Ljavax/net/ssl/SSLHandshakeException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-eqz v2, :cond_7

    :try_start_1
    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x4

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    goto/16 :goto_5

    :catch_0
    move-exception v2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    goto/16 :goto_5

    :catchall_0
    move-exception v3

    :try_start_2
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string v4, "dnKgnbD  geepapacSk"

    const-string/jumbo v4, "nSpe dipKkecaDnagg "

    const/4 v12, 0x0

    const-string v4, "aSgep uked ainSngKD"

    const-string v4, "Sending SDK package"

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->localError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-eqz v2, :cond_7

    :try_start_3
    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    goto/16 :goto_5

    :catch_1
    move-exception v2

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    goto/16 :goto_5

    :catch_2
    move-exception v3

    :try_start_4
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string/jumbo v4, "qRlqa dpeeieuf"

    const-string/jumbo v4, "qf eieuaqdselR"

    const/4 v12, 0x4

    const-string v4, "e qfiReaqsudle"

    const-string v4, "Request failed"

    const/4 v12, 0x0

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->remoteError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v12, 0x7

    const/4 v11, 0x5

    if-eqz v2, :cond_7

    :try_start_5
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v11, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    goto/16 :goto_5

    :catch_3
    move-exception v2

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x1

    goto/16 :goto_5

    :catch_4
    move-exception v3

    :try_start_6
    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string v4, "dlseateiascftCiei "

    const-string/jumbo v4, "itsa Cdlafitfceeei"

    const/4 v12, 0x6

    const-string v4, " Cimefiftcaetidael"

    const-string v4, "Certificate failed"

    const/4 v12, 0x3

    const/4 v11, 0x6

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->remoteError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v11, 0x2

    move v12, v11

    if-eqz v2, :cond_7

    :try_start_7
    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x5

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_5

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    goto/16 :goto_5

    :catch_5
    move-exception v2

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    goto/16 :goto_5

    :catch_6
    move-exception v3

    :try_start_8
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    const-string v4, "Rs dooutti ueeqmt"

    const-string/jumbo v4, "itqmsue ott uRdem"

    const/4 v12, 0x3

    const-string v4, " tt mbisueRuotqde"

    const-string v4, "Request timed out"

    const/4 v12, 0x0

    const/4 v11, 0x3

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->remoteError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    if-eqz v2, :cond_7

    :try_start_9
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_7

    const/4 v12, 0x5

    goto/16 :goto_5

    :catch_7
    move-exception v2

    const/4 v12, 0x0

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    goto/16 :goto_5

    :catch_8
    move-exception v3

    :try_start_a
    const/4 v12, 0x0

    const-string v4, " rocorrooortlP"

    const/4 v12, 0x4

    const-string v4, "PolrtouErrcoro"

    const-string v4, "Protocol Error"

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->localError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    if-eqz v2, :cond_7

    :try_start_b
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_9

    goto/16 :goto_5

    :catch_9
    move-exception v2

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    goto/16 :goto_5

    :catch_a
    move-exception v3

    :try_start_c
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-string/jumbo v4, "maeMf opLRbdl"

    const-string v4, "LfmolbadMreR "

    const/4 v12, 0x4

    const-string v4, "ao mLfdMqRrle"

    const-string v4, "Malformed URL"

    const/4 v11, 0x1

    move v12, v11

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->localError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    const/4 v12, 0x0

    if-eqz v2, :cond_7

    :try_start_d
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x7

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_b

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    goto :goto_5

    :catch_b
    move-exception v2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    goto :goto_5

    :catch_c
    move-exception v3

    :try_start_e
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    const-string/jumbo v4, "odsltarFid eusreanopaemeect"

    const-string/jumbo v4, "odapr ueatiFnatlmocsee eder"

    const/4 v12, 0x5

    const-string/jumbo v4, "m amsFcpneretle rtadaieedoo"

    const-string v4, "Failed to encode parameters"

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-direct {p0, v3, v4, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->localError(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    if-eqz v2, :cond_7

    :try_start_f
    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_f} :catch_d

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    goto :goto_5

    :catch_d
    move-exception v2

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x5

    const/4 v11, 0x1

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_7
    :goto_5
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    return-void

    :catchall_1
    move-exception v3

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-eqz v2, :cond_8

    :try_start_10
    const/4 v11, 0x4

    move v12, v11

    invoke-virtual {v2}, Ljava/io/DataOutputStream;->flush()V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_e

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    goto :goto_6

    :catch_e
    move-exception v2

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-object p1, p1, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {p0, v2, v0, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-interface {v0, p1, v1}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_8
    :goto_6
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    throw v3
.end method

.method private urlWithExtraPathByActivityKind(Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->GDPR:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-ne p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->gdprPath:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->gdprPath:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p2

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/adjust/sdk/ActivityKind;->SUBSCRIPTION:Lcom/adjust/sdk/ActivityKind;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ne p1, v0, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->subscriptionPath:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->subscriptionPath:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p2

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->basePath:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->basePath:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_4
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p2
.end method


# virtual methods
.method public readConnectionResponse(Ljavax/net/ssl/HttpsURLConnection;Lcom/adjust/sdk/ResponseData;)Ljava/lang/Integer;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v3

    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/16 v4, 0x190

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-lt v3, v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v4, Ljava/io/InputStreamReader;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v4, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-instance v3, Ljava/io/BufferedReader;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v4, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_1

    :catchall_0
    move-exception p2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto/16 :goto_3

    :catch_0
    move-exception v3

    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo v4, "nneeo srggdnsiapne dtoCpernaci "

    const-string/jumbo v4, "rree onpanio gendgecnspaC ndsit"

    const/4 v7, 0x0

    const-string/jumbo v4, "ogonsbnidgeaCne apditnr rcsne e"

    const-string v4, "Connecting and reading response"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v5, p2, Lcom/adjust/sdk/ResponseData;->activityPackage:Lcom/adjust/sdk/ActivityPackage;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-direct {p0, v3, v4, v5}, Lcom/adjust/sdk/network/ActivityPackageSender;->errorMessage(Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-array v5, v1, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v4, v3, v5}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz p1, :cond_2

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez p1, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const-string v0, "fEsbrep qepit tno ufreyngrss"

    const/4 v7, 0x6

    const-string/jumbo v0, "pregbuuEy sfrin spesnfreto t"

    const-string v0, "Empty response string buffer"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {p1, v0, p2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-object v2

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/16 v3, 0x1ad

    const/4 v7, 0x3

    if-ne p1, v3, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v0, "u n9f tpetetosr teh4 eo sqeiuq2rsnTt(endopo"

    const-string/jumbo v0, "rqsstito f)oh(qTt utunods4 e ep9noe eener2t"

    const/4 v7, 0x0

    const-string v0, "eqr eeoeq oetunnett4sd h  u9s)i T(2foqtotrp"

    const-string v0, "Too frequent requests to the endpoint (429)"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-interface {p1, v0, p2}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object v2

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    aput-object p1, v4, v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v5, "pnsn% :rteoRmisgsse"

    const-string/jumbo v5, "s:emtoignsR r%esnps"

    const/4 v7, 0x5

    const-string v5, "gpomn reeRs%ssi nts"

    const-string v5, "Response string: %s"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v0, v5, v4}, Lcom/adjust/sdk/ILogger;->debug(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {p0, p2, p1}, Lcom/adjust/sdk/network/ActivityPackageSender;->parseResponse(Lcom/adjust/sdk/ResponseData;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object p1, p2, Lcom/adjust/sdk/ResponseData;->message:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-nez p1, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object v2

    :cond_5
    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/16 v0, 0xc8

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v4, "e%geoossRss  meoapn:"

    const-string/jumbo v4, "mnpso e:esesoa%s gsR"

    const/4 v7, 0x2

    const-string v4, "Response message: %s"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ne p2, v0, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    aput-object p1, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {p2, v4, v0}, Lcom/adjust/sdk/ILogger;->info(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    goto :goto_2

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object p2, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->logger:Lcom/adjust/sdk/ILogger;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    aput-object p1, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p2, v4, v0}, Lcom/adjust/sdk/ILogger;->error(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v2

    :goto_3
    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz p1, :cond_7

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_7
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    throw p2
.end method

.method public sendActivityPackage(Lcom/adjust/sdk/ActivityPackage;Ljava/util/Map;Lcom/adjust/sdk/network/IActivityPackageSender$ResponseDataCallbackSubscriber;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/ActivityPackage;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/adjust/sdk/network/IActivityPackageSender$ResponseDataCallbackSubscriber;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/adjust/sdk/network/ActivityPackageSender;->executor:Lcom/adjust/sdk/scheduler/ThreadExecutor;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v1, Lcom/adjust/sdk/network/ActivityPackageSender$a;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1, p0, p3, p1, p2}, Lcom/adjust/sdk/network/ActivityPackageSender$a;-><init>(Lcom/adjust/sdk/network/ActivityPackageSender;Lcom/adjust/sdk/network/IActivityPackageSender$ResponseDataCallbackSubscriber;Lcom/adjust/sdk/ActivityPackage;Ljava/util/Map;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Lcom/adjust/sdk/scheduler/ThreadExecutor;->submit(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public sendActivityPackageSync(Lcom/adjust/sdk/ActivityPackage;Ljava/util/Map;)Lcom/adjust/sdk/ResponseData;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/adjust/sdk/ActivityPackage;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/adjust/sdk/ResponseData;"
        }
    .end annotation

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, p2}, Lcom/adjust/sdk/ResponseData;->buildResponseData(Lcom/adjust/sdk/ActivityPackage;Ljava/util/Map;)Lcom/adjust/sdk/ResponseData;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->tryToGetResponse(Lcom/adjust/sdk/ResponseData;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/adjust/sdk/network/ActivityPackageSender;->shouldRetryToSend(Lcom/adjust/sdk/ResponseData;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method
