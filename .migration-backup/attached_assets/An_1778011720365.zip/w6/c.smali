.class public abstract Lw6/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSVGABitmapDecoder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SVGABitmapDecoder.kt\ncom/opensource/svgaplayer/bitmap/SVGABitmapDecoder\n*L\n1#1,35:1\n*E\n"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;II)Landroid/graphics/Bitmap;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;II)",
            "Landroid/graphics/Bitmap;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x0

    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    const/4 v4, 0x1

    move v5, v4

    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    and-int/2addr v5, v4

    if-lez p2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-lez p3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-boolean v2, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v2, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object v2, v0, Landroid/graphics/BitmapFactory$Options;->inPreferredConfig:Landroid/graphics/Bitmap$Config;

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    invoke-virtual {p0, p1, v0}, Lw6/c;->b(Ljava/lang/Object;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-boolean v3, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object v2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v2, Lw6/a;->a:Lw6/a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2, v0, p2, p3}, Lw6/a;->a(Landroid/graphics/BitmapFactory$Options;II)I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput p2, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v5, 0x4

    invoke-virtual {p0, p1, v0}, Lw6/c;->b(Ljava/lang/Object;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p1
.end method

.method public abstract b(Ljava/lang/Object;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    .param p2    # Landroid/graphics/BitmapFactory$Options;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Landroid/graphics/BitmapFactory$Options;",
            ")",
            "Landroid/graphics/Bitmap;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end method
