.class public final Lw6/b;
.super Lw6/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw6/c<",
        "[B>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSVGABitmapByteArrayDecoder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SVGABitmapByteArrayDecoder.kt\ncom/opensource/svgaplayer/bitmap/SVGABitmapByteArrayDecoder\n*L\n1#1,16:1\n*E\n"
.end annotation


# static fields
.field public static final a:Lw6/b;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lw6/b;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Lw6/b;-><init>()V

    const/4 v2, 0x3

    sput-object v0, Lw6/b;->a:Lw6/b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lw6/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic b(Ljava/lang/Object;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f s f@m M~-o1o@@@vu/~t@yi@ ~@@Kt~.b c4o Si@~ @~@s  b~@i~~ ~d n~~~o @@  @/@~ l @~@~~ ~o~~~ol@b~ra"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, [B

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lw6/b;->c([BLandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public c([BLandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    .locals 4
    .param p1    # [B
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/BitmapFactory$Options;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "tada"

    const/4 v3, 0x1

    const-string v0, "aatd"

    const-string v0, "data"

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "pso"

    const-string/jumbo v0, "osp"

    const/4 v3, 0x1

    const-string/jumbo v0, "spo"

    const-string/jumbo v0, "ops"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    array-length v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v1, v0, p2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    return-object p1
.end method
