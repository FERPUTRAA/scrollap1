.class public final Lw6/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBitmapSampleSizeCalculator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BitmapSampleSizeCalculator.kt\ncom/opensource/svgaplayer/bitmap/BitmapSampleSizeCalculator\n*L\n1#1,33:1\n*E\n"
.end annotation


# static fields
.field public static final a:Lw6/a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lw6/a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Lw6/a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    sput-object v0, Lw6/a;->a:Lw6/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/BitmapFactory$Options;II)I
    .locals 5
    .param p1    # Landroid/graphics/BitmapFactory$Options;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s~~~@~bf~@@  ~@ob-@@~@  @ oom@@@u/@n r~bdl~ ~s~ o~~@. f~~iM~~@a@~ t1@~@c @~ o t@ /ioi l~Kv4Sy "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const-string/jumbo v0, "sopmsto"

    const-string/jumbo v0, "oostpis"

    const/4 v4, 0x0

    const-string/jumbo v0, "options"

    const/4 v4, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p1, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget p1, p1, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1}, Lkotlin/u0;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast v0, Ljava/lang/Number;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lkotlin/u0;->b()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast p1, Ljava/lang/Number;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-lez p3, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-gtz p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-gt v0, p3, :cond_1

    const/4 v4, 0x2

    if-le p1, p2, :cond_2

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    div-int/lit8 v0, v0, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    div-int/lit8 p1, p1, 0x2

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    div-int v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-lt v2, p3, :cond_2

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    div-int v2, p1, v1

    const/4 v4, 0x0

    if-lt v2, p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    mul-int/lit8 v1, v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v1
.end method
