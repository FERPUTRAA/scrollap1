.class public final Lk6/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/zxing/p;


# instance fields
.field private final a:Lcom/google/zxing/p;


# direct methods
.method public constructor <init>(Lcom/google/zxing/p;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method private static b([Lcom/google/zxing/t;II)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@cs@~o~b /to  n~~~ ~@ ~~K@~tf.@ol@~@b ~ab~i~l@i  @~uy@@@@~ Ss o @~ ~io~ o ~@ @~@ @-Md/4m f~@r@v1"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    if-eqz p0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x1

    array-length v1, p0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ge v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    aget-object v1, p0, v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v2, Lcom/google/zxing/t;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1}, Lcom/google/zxing/t;->c()F

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    int-to-float v4, p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-float/2addr v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/google/zxing/t;->d()F

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    int-to-float v4, p2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-float/2addr v1, v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-direct {v2, v3, v1}, Lcom/google/zxing/t;-><init>(FF)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    aput-object v2, p0, v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x2

    and-int/2addr v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method


# virtual methods
.method public a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/zxing/c;",
            "Ljava/util/Map<",
            "Lcom/google/zxing/e;",
            "*>;)",
            "Lcom/google/zxing/r;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/google/zxing/c;->e()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/google/zxing/c;->d()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    div-int/lit8 v0, v0, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    div-int/lit8 v1, v1, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v3, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1, v2, v2, v0, v1}, Lcom/google/zxing/c;->a(IIII)Lcom/google/zxing/c;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v3, v4, p2}, Lcom/google/zxing/p;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object p1
    :try_end_0
    .catch Lcom/google/zxing/m; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object p1

    :catch_0
    :try_start_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v3, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1, v0, v2, v0, v1}, Lcom/google/zxing/c;->a(IIII)Lcom/google/zxing/c;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v3, v4, p2}, Lcom/google/zxing/p;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/google/zxing/r;->f()[Lcom/google/zxing/t;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v4, v0, v2}, Lk6/a;->b([Lcom/google/zxing/t;II)V
    :try_end_1
    .catch Lcom/google/zxing/m; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object v3

    :catch_1
    :try_start_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1, v2, v1, v0, v1}, Lcom/google/zxing/c;->a(IIII)Lcom/google/zxing/c;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v3, v4, p2}, Lcom/google/zxing/p;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3}, Lcom/google/zxing/r;->f()[Lcom/google/zxing/t;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v4, v2, v1}, Lk6/a;->b([Lcom/google/zxing/t;II)V
    :try_end_2
    .catch Lcom/google/zxing/m; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v3

    :catch_2
    :try_start_3
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, v0, v1, v0, v1}, Lcom/google/zxing/c;->a(IIII)Lcom/google/zxing/c;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2, v3, p2}, Lcom/google/zxing/p;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Lcom/google/zxing/r;->f()[Lcom/google/zxing/t;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v3, v0, v1}, Lk6/a;->b([Lcom/google/zxing/t;II)V
    :try_end_3
    .catch Lcom/google/zxing/m; {:try_start_3 .. :try_end_3} :catch_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v2

    :catch_3
    const/4 v6, 0x3

    const/4 v5, 0x0

    div-int/lit8 v2, v0, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x4

    div-int/lit8 v3, v1, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v2, v3, v0, v1}, Lcom/google/zxing/c;->a(IIII)Lcom/google/zxing/c;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v0, p1, p2}, Lcom/google/zxing/p;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Lcom/google/zxing/r;->f()[Lcom/google/zxing/t;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p2, v2, v3}, Lk6/a;->b([Lcom/google/zxing/t;II)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object p1
.end method

.method public c(Lcom/google/zxing/c;)Lcom/google/zxing/r;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lk6/a;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public reset()V
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lk6/a;->a:Lcom/google/zxing/p;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/google/zxing/p;->reset()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
