.class public Li7/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/rd/draw/drawer/type/b;

.field private b:Lcom/rd/draw/drawer/type/c;

.field private c:Lcom/rd/draw/drawer/type/g;

.field private d:Lcom/rd/draw/drawer/type/k;

.field private e:Lcom/rd/draw/drawer/type/h;

.field private f:Lcom/rd/draw/drawer/type/e;

.field private g:Lcom/rd/draw/drawer/type/j;

.field private h:Lcom/rd/draw/drawer/type/d;

.field private i:Lcom/rd/draw/drawer/type/i;

.field private j:Lcom/rd/draw/drawer/type/f;

.field private k:I

.field private l:I

.field private m:I


# direct methods
.method public constructor <init>(Lcom/rd/draw/data/a;)V
    .locals 4
    .param p1    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Landroid/graphics/Paint;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    const/4 v3, 0x6

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v1, Lcom/rd/draw/drawer/type/b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/b;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    iput-object v1, p0, Li7/a;->a:Lcom/rd/draw/drawer/type/b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v1, Lcom/rd/draw/drawer/type/c;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/c;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x3

    iput-object v1, p0, Li7/a;->b:Lcom/rd/draw/drawer/type/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v1, Lcom/rd/draw/drawer/type/g;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/g;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v1, p0, Li7/a;->c:Lcom/rd/draw/drawer/type/g;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/rd/draw/drawer/type/k;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/k;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v1, p0, Li7/a;->d:Lcom/rd/draw/drawer/type/k;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v1, Lcom/rd/draw/drawer/type/h;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/h;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x2

    iput-object v1, p0, Li7/a;->e:Lcom/rd/draw/drawer/type/h;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v1, Lcom/rd/draw/drawer/type/e;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/e;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Li7/a;->f:Lcom/rd/draw/drawer/type/e;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v1, Lcom/rd/draw/drawer/type/j;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/j;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Li7/a;->g:Lcom/rd/draw/drawer/type/j;

    const/4 v2, 0x7

    move v3, v2

    new-instance v1, Lcom/rd/draw/drawer/type/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/d;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v1, p0, Li7/a;->h:Lcom/rd/draw/drawer/type/d;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/rd/draw/drawer/type/i;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/i;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Li7/a;->i:Lcom/rd/draw/drawer/type/i;

    const/4 v3, 0x1

    new-instance v1, Lcom/rd/draw/drawer/type/f;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v1, v0, p1}, Lcom/rd/draw/drawer/type/f;-><init>(Landroid/graphics/Paint;Lcom/rd/draw/data/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v1, p0, Li7/a;->j:Lcom/rd/draw/drawer/type/f;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;Z)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@@s@oi@ @@@ ~~@~bd/~~~b @o@@t~  @/~~o @   .oK  ~ o@~~@ty~- a@b~~@rM@l~@i~ 1lmu~so if4 ~ nv~~~cfS"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    iget-object v0, p0, Li7/a;->b:Lcom/rd/draw/drawer/type/c;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v1, p0, Li7/a;->a:Lcom/rd/draw/drawer/type/b;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget v3, p0, Li7/a;->k:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget v5, p0, Li7/a;->l:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget v6, p0, Li7/a;->m:I

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    move v4, p2

    move v4, p2

    const/4 v8, 0x6

    move v4, p2

    move v4, p2

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    invoke-virtual/range {v1 .. v6}, Lcom/rd/draw/drawer/type/b;->a(Landroid/graphics/Canvas;IZII)V

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-void
.end method

.method public b(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x6

    iget-object v0, p0, Li7/a;->b:Lcom/rd/draw/drawer/type/c;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    move v7, v6

    iget v3, p0, Li7/a;->k:I

    iget v4, p0, Li7/a;->l:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget v5, p0, Li7/a;->m:I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual/range {v0 .. v5}, Lcom/rd/draw/drawer/type/c;->a(Landroid/graphics/Canvas;Lf7/b;III)V

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void
.end method

.method public c(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Li7/a;->h:Lcom/rd/draw/drawer/type/d;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v1, p0, Li7/a;->l:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v2, p0, Li7/a;->m:I

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/rd/draw/drawer/type/d;->a(Landroid/graphics/Canvas;Lf7/b;II)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public d(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Li7/a;->f:Lcom/rd/draw/drawer/type/e;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v3, p0, Li7/a;->k:I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v4, p0, Li7/a;->l:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v5, p0, Li7/a;->m:I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual/range {v0 .. v5}, Lcom/rd/draw/drawer/type/e;->a(Landroid/graphics/Canvas;Lf7/b;III)V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void
.end method

.method public e(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v0, p0, Li7/a;->c:Lcom/rd/draw/drawer/type/g;

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget v3, p0, Li7/a;->k:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget v4, p0, Li7/a;->l:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v5, p0, Li7/a;->m:I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Lcom/rd/draw/drawer/type/g;->a(Landroid/graphics/Canvas;Lf7/b;III)V

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-void
.end method

.method public f(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x3

    iget-object v0, p0, Li7/a;->j:Lcom/rd/draw/drawer/type/f;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v3, p0, Li7/a;->k:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v4, p0, Li7/a;->l:I

    const/4 v7, 0x1

    iget v5, p0, Li7/a;->m:I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual/range {v0 .. v5}, Lcom/rd/draw/drawer/type/f;->a(Landroid/graphics/Canvas;Lf7/b;III)V

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-void
.end method

.method public g(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Li7/a;->e:Lcom/rd/draw/drawer/type/h;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Li7/a;->l:I

    const/4 v4, 0x6

    iget v2, p0, Li7/a;->m:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/rd/draw/drawer/type/h;->a(Landroid/graphics/Canvas;Lf7/b;II)V

    :cond_0
    const/4 v4, 0x2

    return-void
.end method

.method public h(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Li7/a;->i:Lcom/rd/draw/drawer/type/i;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    iget v3, p0, Li7/a;->k:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget v4, p0, Li7/a;->l:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v5, p0, Li7/a;->m:I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Lcom/rd/draw/drawer/type/i;->a(Landroid/graphics/Canvas;Lf7/b;III)V

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-void
.end method

.method public i(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Li7/a;->g:Lcom/rd/draw/drawer/type/j;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Li7/a;->l:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v2, p0, Li7/a;->m:I

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/rd/draw/drawer/type/j;->a(Landroid/graphics/Canvas;Lf7/b;II)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method

.method public j(Landroid/graphics/Canvas;Lf7/b;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lf7/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Li7/a;->d:Lcom/rd/draw/drawer/type/k;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v1, p0, Li7/a;->l:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v2, p0, Li7/a;->m:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/rd/draw/drawer/type/k;->a(Landroid/graphics/Canvas;Lf7/b;II)V

    :cond_0
    const/4 v4, 0x4

    return-void
.end method

.method public k(III)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Li7/a;->k:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Li7/a;->l:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p3, p0, Li7/a;->m:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
