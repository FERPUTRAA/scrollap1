.class public final Lh6/c;
.super Ljava/lang/Object;


# static fields
.field private static final h:I = 0xa

.field private static final i:I = 0x1


# instance fields
.field private final a:Lcom/google/zxing/common/b;

.field private final b:I

.field private final c:I

.field private final d:I

.field private final e:I

.field private final f:I

.field private final g:I


# direct methods
.method public constructor <init>(Lcom/google/zxing/common/b;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/zxing/common/b;->l()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    div-int/lit8 v0, v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/zxing/common/b;->h()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    div-int/lit8 v1, v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 v2, 0xa

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0, p1, v2, v0, v1}, Lh6/c;-><init>(Lcom/google/zxing/common/b;III)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/google/zxing/common/b;III)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object p1, p0, Lh6/c;->a:Lcom/google/zxing/common/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/zxing/common/b;->h()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p0, Lh6/c;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/zxing/common/b;->l()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput p1, p0, Lh6/c;->c:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    div-int/lit8 p2, p2, 0x2

    const/4 v3, 0x2

    move v4, v3

    sub-int v1, p3, p2

    const/4 v3, 0x1

    move v4, v3

    iput v1, p0, Lh6/c;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/2addr p3, p2

    const/4 v4, 0x5

    const/4 v3, 0x0

    iput p3, p0, Lh6/c;->e:I

    const/4 v4, 0x4

    sub-int v2, p4, p2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v2, p0, Lh6/c;->g:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/2addr p4, p2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput p4, p0, Lh6/c;->f:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ltz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ltz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ge p4, v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    if-ge p3, p1, :cond_0

    const/4 v3, 0x5

    move v4, v3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw p1
.end method

.method private a(Lcom/google/zxing/t;Lcom/google/zxing/t;Lcom/google/zxing/t;Lcom/google/zxing/t;)[Lcom/google/zxing/t;
    .locals 11

    invoke-virtual {p1}, Lcom/google/zxing/t;->c()F

    move-result v0

    invoke-virtual {p1}, Lcom/google/zxing/t;->d()F

    move-result p1

    invoke-virtual {p2}, Lcom/google/zxing/t;->c()F

    move-result v1

    invoke-virtual {p2}, Lcom/google/zxing/t;->d()F

    move-result p2

    invoke-virtual {p3}, Lcom/google/zxing/t;->c()F

    move-result v2

    invoke-virtual {p3}, Lcom/google/zxing/t;->d()F

    move-result p3

    invoke-virtual {p4}, Lcom/google/zxing/t;->c()F

    move-result v3

    invoke-virtual {p4}, Lcom/google/zxing/t;->d()F

    move-result p4

    iget v4, p0, Lh6/c;->c:I

    int-to-float v4, v4

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    cmpg-float v4, v0, v4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/high16 v10, 0x3f800000    # 1.0f

    if-gez v4, :cond_0

    new-array v4, v9, [Lcom/google/zxing/t;

    new-instance v9, Lcom/google/zxing/t;

    sub-float/2addr v3, v10

    add-float/2addr p4, v10

    invoke-direct {v9, v3, p4}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object v9, v4, v8

    new-instance p4, Lcom/google/zxing/t;

    add-float/2addr v1, v10

    add-float/2addr p2, v10

    invoke-direct {p4, v1, p2}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p4, v4, v7

    new-instance p2, Lcom/google/zxing/t;

    sub-float/2addr v2, v10

    sub-float/2addr p3, v10

    invoke-direct {p2, v2, p3}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p2, v4, v6

    new-instance p2, Lcom/google/zxing/t;

    add-float/2addr v0, v10

    sub-float/2addr p1, v10

    invoke-direct {p2, v0, p1}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p2, v4, v5

    return-object v4

    :cond_0
    new-array v4, v9, [Lcom/google/zxing/t;

    new-instance v9, Lcom/google/zxing/t;

    add-float/2addr v3, v10

    add-float/2addr p4, v10

    invoke-direct {v9, v3, p4}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object v9, v4, v8

    new-instance p4, Lcom/google/zxing/t;

    add-float/2addr v1, v10

    sub-float/2addr p2, v10

    invoke-direct {p4, v1, p2}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p4, v4, v7

    new-instance p2, Lcom/google/zxing/t;

    sub-float/2addr v2, v10

    add-float/2addr p3, v10

    invoke-direct {p2, v2, p3}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p2, v4, v6

    new-instance p2, Lcom/google/zxing/t;

    sub-float/2addr v0, v10

    sub-float/2addr p1, v10

    invoke-direct {p2, v0, p1}, Lcom/google/zxing/t;-><init>(FF)V

    aput-object p2, v4, v5

    return-object v4
.end method

.method private b(IIIZ)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    if-eqz p4, :cond_1

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-gt p1, p2, :cond_3

    const/4 v1, 0x7

    move v2, v1

    iget-object p4, p0, Lh6/c;->a:Lcom/google/zxing/common/b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p4, p1, p3}, Lcom/google/zxing/common/b;->e(II)Z

    move-result p4

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p4, :cond_0

    const/4 v2, 0x7

    return v0

    :cond_0
    const/4 v2, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v2, 0x2

    if-gt p1, p2, :cond_3

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p4, p0, Lh6/c;->a:Lcom/google/zxing/common/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p4, p3, p1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result p4

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-eqz p4, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x1

    goto :goto_1

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method private d(FFFF)Lcom/google/zxing/t;
    .locals 7

    invoke-static {p1, p2, p3, p4}, Lh6/a;->a(FFFF)F

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0}, Lh6/a;->c(F)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    sub-float/2addr p3, p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    int-to-float v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    div-float/2addr p3, v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    sub-float/2addr p4, p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    div-float/2addr p4, v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    if-ge v1, v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    int-to-float v2, v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    mul-float v3, v2, p3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    add-float/2addr v3, p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v3}, Lh6/a;->c(F)I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    mul-float/2addr v2, p4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-float/2addr v2, p2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v2}, Lh6/a;->c(F)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v4, p0, Lh6/c;->a:Lcom/google/zxing/common/b;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4, v3, v2}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance p1, Lcom/google/zxing/t;

    const/4 v6, 0x1

    int-to-float p2, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    int-to-float p3, v2

    const/4 v5, 0x7

    and-int/2addr v6, v5

    invoke-direct {p1, p2, p3}, Lcom/google/zxing/t;-><init>(FF)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 p1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-object p1
.end method


# virtual methods
.method public c()[Lcom/google/zxing/t;
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget v0, p0, Lh6/c;->d:I

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x5

    iget v1, p0, Lh6/c;->e:I

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x7

    iget v2, p0, Lh6/c;->g:I

    const/4 v14, 0x7

    const/4 v13, 0x7

    iget v3, p0, Lh6/c;->f:I

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x7

    const/4 v4, 0x0

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x7

    const/4 v5, 0x1

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x6

    move v7, v4

    move v7, v4

    const/4 v14, 0x4

    move v7, v4

    move v7, v4

    const/4 v14, 0x4

    move v8, v7

    move v8, v7

    const/4 v14, 0x0

    move v8, v7

    move v8, v7

    const/4 v13, 0x3

    const/4 v14, 0x6

    move v9, v8

    move v9, v8

    const/4 v14, 0x3

    move v9, v8

    move v9, v8

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x4

    move v10, v9

    move v10, v9

    const/4 v14, 0x4

    move v10, v9

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x2

    move v11, v10

    move v11, v10

    const/4 v14, 0x4

    move v11, v10

    move v11, v10

    const/4 v14, 0x3

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :cond_0
    :goto_0
    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x7

    if-eqz v6, :cond_15

    const/4 v14, 0x7

    move v12, v4

    move v12, v4

    const/4 v14, 0x0

    move v12, v4

    move v12, v4

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x5

    move v6, v5

    move v6, v5

    const/4 v14, 0x6

    move v6, v5

    move v6, v5

    :cond_1
    :goto_1
    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x5

    if-nez v6, :cond_2

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x7

    if-nez v7, :cond_4

    :cond_2
    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x1

    iget v6, p0, Lh6/c;->c:I

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x2

    if-ge v1, v6, :cond_4

    const/4 v14, 0x3

    invoke-direct {p0, v2, v3, v1, v4}, Lh6/c;->b(IIIZ)Z

    move-result v6

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    if-eqz v6, :cond_3

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x0

    move v7, v5

    move v7, v5

    const/4 v14, 0x6

    move v7, v5

    move v7, v5

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x4

    move v12, v7

    move v12, v7

    const/4 v14, 0x1

    move v12, v7

    move v12, v7

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x6

    goto :goto_1

    :cond_3
    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x1

    if-nez v7, :cond_1

    const/4 v14, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x7

    goto :goto_1

    :cond_4
    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x6

    iget v6, p0, Lh6/c;->c:I

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x0

    if-lt v1, v6, :cond_5

    :goto_2
    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x6

    move v4, v5

    const/4 v14, 0x2

    move v4, v5

    move v4, v5

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x5

    goto/16 :goto_6

    :cond_5
    const/4 v14, 0x4

    const/4 v13, 0x3

    move v6, v5

    const/4 v14, 0x7

    move v6, v5

    move v6, v5

    :cond_6
    :goto_3
    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x6

    if-nez v6, :cond_7

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-nez v8, :cond_9

    :cond_7
    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x0

    iget v6, p0, Lh6/c;->b:I

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x4

    if-ge v3, v6, :cond_9

    const/4 v14, 0x3

    invoke-direct {p0, v0, v1, v3, v5}, Lh6/c;->b(IIIZ)Z

    move-result v6

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x0

    if-eqz v6, :cond_8

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x1

    move v8, v5

    const/4 v14, 0x0

    move v8, v5

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x3

    move v12, v8

    move v12, v8

    const/4 v14, 0x3

    move v12, v8

    move v12, v8

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x3

    goto :goto_3

    :cond_8
    const/4 v13, 0x1

    const/4 v14, 0x3

    if-nez v8, :cond_6

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x4

    goto :goto_3

    :cond_9
    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget v6, p0, Lh6/c;->b:I

    const/4 v14, 0x4

    const/4 v13, 0x4

    if-lt v3, v6, :cond_a

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x6

    goto :goto_2

    :cond_a
    const/4 v14, 0x2

    move v6, v5

    move v6, v5

    const/4 v14, 0x4

    move v6, v5

    move v6, v5

    :cond_b
    :goto_4
    const/4 v14, 0x3

    if-nez v6, :cond_c

    const/4 v14, 0x4

    if-nez v9, :cond_e

    :cond_c
    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x4

    if-ltz v0, :cond_e

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x5

    invoke-direct {p0, v2, v3, v0, v4}, Lh6/c;->b(IIIZ)Z

    move-result v6

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x7

    if-eqz v6, :cond_d

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x0

    move v9, v5

    move v9, v5

    const/4 v14, 0x5

    move v9, v5

    move v9, v5

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x3

    move v12, v9

    move v12, v9

    const/4 v14, 0x0

    move v12, v9

    const/4 v14, 0x1

    const/4 v13, 0x0

    goto :goto_4

    :cond_d
    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x1

    if-nez v9, :cond_b

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x7

    goto :goto_4

    :cond_e
    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x7

    if-gez v0, :cond_f

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x1

    goto/16 :goto_2

    :cond_f
    const/4 v14, 0x7

    move v6, v12

    move v6, v12

    move v6, v12

    move v6, v12

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x5

    move v12, v5

    move v12, v5

    const/4 v14, 0x5

    move v12, v5

    :cond_10
    :goto_5
    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x5

    if-nez v12, :cond_11

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x4

    if-nez v11, :cond_13

    :cond_11
    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x4

    if-ltz v2, :cond_13

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-direct {p0, v0, v1, v2, v5}, Lh6/c;->b(IIIZ)Z

    move-result v12

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x5

    if-eqz v12, :cond_12

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x3

    add-int/lit8 v2, v2, -0x1

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x0

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x3

    move v11, v6

    const/4 v14, 0x4

    move v11, v6

    move v11, v6

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x4

    goto :goto_5

    :cond_12
    const/4 v13, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x3

    if-nez v11, :cond_10

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x2

    add-int/lit8 v2, v2, -0x1

    const/4 v14, 0x1

    const/4 v13, 0x6

    goto :goto_5

    :cond_13
    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x1

    if-gez v2, :cond_14

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x1

    goto/16 :goto_2

    :cond_14
    const/4 v14, 0x4

    if-eqz v6, :cond_0

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x4

    move v10, v5

    move v10, v5

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x7

    goto/16 :goto_0

    :cond_15
    :goto_6
    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x6

    if-nez v4, :cond_1e

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x1

    if-eqz v10, :cond_1e

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x5

    sub-int v4, v1, v0

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x3

    const/4 v6, 0x0

    const/4 v14, 0x5

    move v8, v5

    move v8, v5

    const/4 v14, 0x5

    move v8, v5

    move v8, v5

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    :goto_7
    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x5

    if-nez v7, :cond_16

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x1

    if-ge v8, v4, :cond_16

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    int-to-float v7, v0

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x5

    sub-int v9, v3, v8

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x0

    int-to-float v9, v9

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x5

    add-int v10, v0, v8

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x6

    int-to-float v10, v10

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x2

    int-to-float v11, v3

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-direct {p0, v7, v9, v10, v11}, Lh6/c;->d(FFFF)Lcom/google/zxing/t;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x7

    add-int/lit8 v8, v8, 0x1

    const/4 v14, 0x6

    goto :goto_7

    :cond_16
    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x1

    if-eqz v7, :cond_1d

    const/4 v13, 0x7

    move v14, v13

    move v9, v5

    move v9, v5

    move v9, v5

    move v9, v5

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    :goto_8
    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x2

    if-nez v8, :cond_17

    const/4 v14, 0x0

    if-ge v9, v4, :cond_17

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x2

    int-to-float v8, v0

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x7

    add-int v10, v2, v9

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x4

    int-to-float v10, v10

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x6

    add-int v11, v0, v9

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x1

    int-to-float v11, v11

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x2

    int-to-float v12, v2

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x3

    invoke-direct {p0, v8, v10, v11, v12}, Lh6/c;->d(FFFF)Lcom/google/zxing/t;

    move-result-object v8

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x3

    add-int/lit8 v9, v9, 0x1

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x5

    goto :goto_8

    :cond_17
    const/4 v14, 0x3

    if-eqz v8, :cond_1c

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    move v9, v5

    move v9, v5

    const/4 v14, 0x2

    move v9, v5

    move v9, v5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    :goto_9
    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x5

    if-nez v0, :cond_18

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x1

    if-ge v9, v4, :cond_18

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x4

    int-to-float v0, v1

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x5

    add-int v10, v2, v9

    const/4 v14, 0x1

    int-to-float v10, v10

    const/4 v14, 0x4

    sub-int v11, v1, v9

    const/4 v14, 0x2

    const/4 v13, 0x4

    int-to-float v11, v11

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x0

    int-to-float v12, v2

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-direct {p0, v0, v10, v11, v12}, Lh6/c;->d(FFFF)Lcom/google/zxing/t;

    move-result-object v0

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x6

    add-int/lit8 v9, v9, 0x1

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x6

    goto :goto_9

    :cond_18
    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x2

    if-eqz v0, :cond_1b

    :goto_a
    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x0

    if-nez v6, :cond_19

    const/4 v13, 0x7

    const/4 v13, 0x4

    if-ge v5, v4, :cond_19

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x5

    int-to-float v2, v1

    const/4 v14, 0x7

    const/4 v13, 0x0

    sub-int v6, v3, v5

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x5

    int-to-float v6, v6

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    sub-int v9, v1, v5

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x0

    int-to-float v9, v9

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x6

    int-to-float v10, v3

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x6

    invoke-direct {p0, v2, v6, v9, v10}, Lh6/c;->d(FFFF)Lcom/google/zxing/t;

    move-result-object v6

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x6

    add-int/lit8 v5, v5, 0x1

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x0

    goto :goto_a

    :cond_19
    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x1

    if-eqz v6, :cond_1a

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x6

    invoke-direct {p0, v6, v7, v0, v8}, Lh6/c;->a(Lcom/google/zxing/t;Lcom/google/zxing/t;Lcom/google/zxing/t;Lcom/google/zxing/t;)[Lcom/google/zxing/t;

    move-result-object v0

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x0

    return-object v0

    :cond_1a
    const/4 v14, 0x1

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    throw v0

    :cond_1b
    const/4 v14, 0x1

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x3

    throw v0

    :cond_1c
    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x3

    throw v0

    :cond_1d
    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x5

    throw v0

    :cond_1e
    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x7

    throw v0
.end method
