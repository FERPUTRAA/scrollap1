.class public final Lh6/b;
.super Ljava/lang/Object;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final b:I = 0x20


# instance fields
.field private final a:Lcom/google/zxing/common/b;


# direct methods
.method public constructor <init>(Lcom/google/zxing/common/b;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lh6/b;->a:Lcom/google/zxing/common/b;

    return-void
.end method

.method private a(IIIIZ)[I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@bso r~id~~@ n@@~o ~~ ~t@@K/1~o ~ ~~M@/f~~@~~ub@4  @@c@@~@tlo ~lm ~vay o@b-@@  i~o~~@S . f si@@ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    add-int v0, p3, p4

    const/4 v5, 0x7

    div-int/lit8 v0, v0, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-lt v1, p3, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, p0, Lh6/b;->a:Lcom/google/zxing/common/b;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz p5, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v1, p1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, p1, v1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v1, v1, -0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    move v2, v1

    const/4 v5, 0x3

    move v2, v1

    move v2, v1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    add-int/lit8 v2, v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-lt v2, p3, :cond_4

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v3, p0, Lh6/b;->a:Lcom/google/zxing/common/b;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p5, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v3, v2, p1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_2

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v3, p1, v2}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    :cond_4
    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    sub-int v3, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-lt v2, p3, :cond_6

    const/4 v4, 0x1

    move v5, v4

    if-le v3, p2, :cond_5

    const/4 v5, 0x3

    goto :goto_3

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x1

    move v1, v2

    move v1, v2

    const/4 v5, 0x2

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_6
    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/lit8 v1, v1, 0x1

    :goto_4
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ge v0, p4, :cond_d

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p3, p0, Lh6/b;->a:Lcom/google/zxing/common/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p5, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3, v0, p1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result p3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz p3, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x5

    goto :goto_5

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p3, p1, v0}, Lcom/google/zxing/common/b;->e(II)Z

    move-result p3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz p3, :cond_8

    :goto_5
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_4

    :cond_8
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    move p3, v0

    move p3, v0

    const/4 v5, 0x4

    move p3, v0

    move p3, v0

    :cond_9
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 p3, p3, 0x1

    const/4 v4, 0x4

    move v5, v4

    if-ge p3, p4, :cond_b

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v2, p0, Lh6/b;->a:Lcom/google/zxing/common/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    if-eqz p5, :cond_a

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, p3, p1}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_6

    :cond_a
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, p1, p3}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v2, :cond_9

    :cond_b
    :goto_6
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    sub-int v2, p3, v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ge p3, p4, :cond_d

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-le v2, p2, :cond_c

    const/4 v4, 0x3

    move v5, v4

    goto :goto_7

    :cond_c
    const/4 v5, 0x4

    const/4 v4, 0x5

    move v0, p3

    move v0, p3

    const/4 v5, 0x2

    move v0, p3

    move v0, p3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto/16 :goto_4

    :cond_d
    :goto_7
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-le v0, v1, :cond_e

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    filled-new-array {v1, v0}, [I

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-object p1

    :cond_e
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object p1
.end method

.method private c(IIIIIIIII)Lcom/google/zxing/t;
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v1, p5

    move/from16 v1, p5

    move/from16 v1, p5

    move/from16 v1, p5

    const/4 v2, 0x0

    move/from16 v9, p8

    move/from16 v9, p8

    move/from16 v9, p8

    move/from16 v9, p8

    move v11, v0

    move v11, v0

    move v11, v0

    move v11, v0

    move v10, v1

    move v10, v1

    move v10, v1

    move v10, v1

    :goto_0
    if-ge v10, v9, :cond_a

    move/from16 v12, p7

    move/from16 v12, p7

    move/from16 v12, p7

    move/from16 v12, p7

    if-lt v10, v12, :cond_a

    move/from16 v13, p4

    move/from16 v13, p4

    move/from16 v13, p4

    move/from16 v13, p4

    if-ge v11, v13, :cond_a

    move/from16 v14, p3

    move/from16 v14, p3

    move/from16 v14, p3

    move/from16 v14, p3

    if-lt v11, v14, :cond_a

    if-nez p2, :cond_0

    const/4 v8, 0x1

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move v4, v10

    move v4, v10

    move v4, v10

    move v4, v10

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    invoke-direct/range {v3 .. v8}, Lh6/b;->a(IIIIZ)[I

    move-result-object v3

    goto :goto_1

    :cond_0
    const/4 v8, 0x0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move v4, v11

    move v4, v11

    move v4, v11

    move v4, v11

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v5, p9

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v7, p8

    move/from16 v7, p8

    move/from16 v7, p8

    move/from16 v7, p8

    invoke-direct/range {v3 .. v8}, Lh6/b;->a(IIIIZ)[I

    move-result-object v3

    :goto_1
    if-nez v3, :cond_9

    if-eqz v2, :cond_8

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p2, :cond_4

    sub-int v10, v10, p6

    aget v1, v2, v3

    if-ge v1, v0, :cond_3

    aget v5, v2, v4

    if-le v5, v0, :cond_2

    new-instance v0, Lcom/google/zxing/t;

    if-lez p6, :cond_1

    goto :goto_2

    :cond_1
    move v3, v4

    move v3, v4

    move v3, v4

    move v3, v4

    :goto_2
    aget v1, v2, v3

    int-to-float v1, v1

    int-to-float v2, v10

    invoke-direct {v0, v1, v2}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v0

    :cond_2
    new-instance v0, Lcom/google/zxing/t;

    int-to-float v1, v1

    int-to-float v2, v10

    invoke-direct {v0, v1, v2}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v0

    :cond_3
    new-instance v0, Lcom/google/zxing/t;

    aget v1, v2, v4

    int-to-float v1, v1

    int-to-float v2, v10

    invoke-direct {v0, v1, v2}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v0

    :cond_4
    sub-int v11, v11, p2

    aget v0, v2, v3

    if-ge v0, v1, :cond_7

    aget v5, v2, v4

    if-le v5, v1, :cond_6

    new-instance v0, Lcom/google/zxing/t;

    int-to-float v1, v11

    if-gez p2, :cond_5

    goto :goto_3

    :cond_5
    move v3, v4

    move v3, v4

    move v3, v4

    move v3, v4

    :goto_3
    aget v2, v2, v3

    int-to-float v2, v2

    invoke-direct {v0, v1, v2}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v0

    :cond_6
    new-instance v1, Lcom/google/zxing/t;

    int-to-float v2, v11

    int-to-float v0, v0

    invoke-direct {v1, v2, v0}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v1

    :cond_7
    new-instance v0, Lcom/google/zxing/t;

    int-to-float v1, v11

    aget v2, v2, v4

    int-to-float v2, v2

    invoke-direct {v0, v1, v2}, Lcom/google/zxing/t;-><init>(FF)V

    return-object v0

    :cond_8
    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    throw v0

    :cond_9
    add-int v10, v10, p6

    add-int v11, v11, p2

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    goto/16 :goto_0

    :cond_a
    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object v0

    throw v0
.end method


# virtual methods
.method public b()[Lcom/google/zxing/t;
    .locals 24
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    move-object/from16 v10, p0

    move-object/from16 v10, p0

    move-object/from16 v10, p0

    move-object/from16 v10, p0

    iget-object v0, v10, Lh6/b;->a:Lcom/google/zxing/common/b;

    invoke-virtual {v0}, Lcom/google/zxing/common/b;->h()I

    move-result v11

    iget-object v0, v10, Lh6/b;->a:Lcom/google/zxing/common/b;

    invoke-virtual {v0}, Lcom/google/zxing/common/b;->l()I

    move-result v12

    div-int/lit8 v13, v11, 0x2

    div-int/lit8 v14, v12, 0x2

    div-int/lit16 v0, v11, 0x100

    const/4 v15, 0x1

    invoke-static {v15, v0}, Ljava/lang/Math;->max(II)I

    move-result v9

    div-int/lit16 v0, v12, 0x100

    invoke-static {v15, v0}, Ljava/lang/Math;->max(II)I

    move-result v8

    const/4 v2, 0x0

    const/4 v3, 0x0

    neg-int v7, v9

    const/16 v16, 0x0

    div-int/lit8 v17, v14, 0x2

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move v1, v14

    move v1, v14

    move v1, v14

    move v4, v12

    move v4, v12

    move v4, v12

    move v4, v12

    move v5, v13

    move v5, v13

    move v5, v13

    move v5, v13

    move v6, v7

    move v6, v7

    move v6, v7

    move v6, v7

    move/from16 v18, v7

    move/from16 v18, v7

    move/from16 v18, v7

    move/from16 v18, v7

    move/from16 v7, v16

    move/from16 v7, v16

    move/from16 v7, v16

    move/from16 v7, v16

    move/from16 v19, v8

    move/from16 v19, v8

    move/from16 v19, v8

    move/from16 v19, v8

    move v8, v11

    move v8, v11

    move/from16 v16, v9

    move/from16 v16, v9

    move/from16 v16, v9

    move/from16 v16, v9

    move/from16 v9, v17

    move/from16 v9, v17

    move/from16 v9, v17

    move/from16 v9, v17

    invoke-direct/range {v0 .. v9}, Lh6/b;->c(IIIIIIIII)Lcom/google/zxing/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/zxing/t;->d()F

    move-result v0

    float-to-int v0, v0

    add-int/lit8 v20, v0, -0x1

    move/from16 v9, v19

    move/from16 v9, v19

    move/from16 v9, v19

    move/from16 v9, v19

    neg-int v2, v9

    const/4 v6, 0x0

    div-int/lit8 v19, v13, 0x2

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v7, v20

    move/from16 v7, v20

    move/from16 v7, v20

    move/from16 v7, v20

    move/from16 v21, v9

    move/from16 v21, v9

    move/from16 v21, v9

    move/from16 v21, v9

    move/from16 v9, v19

    move/from16 v9, v19

    move/from16 v9, v19

    move/from16 v9, v19

    invoke-direct/range {v0 .. v9}, Lh6/b;->c(IIIIIIIII)Lcom/google/zxing/t;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Lcom/google/zxing/t;->c()F

    move-result v0

    float-to-int v0, v0

    add-int/lit8 v23, v0, -0x1

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v2, v21

    move/from16 v2, v21

    move/from16 v3, v23

    move/from16 v3, v23

    move/from16 v3, v23

    move/from16 v3, v23

    invoke-direct/range {v0 .. v9}, Lh6/b;->c(IIIIIIIII)Lcom/google/zxing/t;

    move-result-object v12

    invoke-virtual {v12}, Lcom/google/zxing/t;->c()F

    move-result v0

    float-to-int v0, v0

    add-int/lit8 v19, v0, 0x1

    const/4 v2, 0x0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v6, v16

    move/from16 v6, v16

    move/from16 v6, v16

    move/from16 v6, v16

    move/from16 v9, v17

    move/from16 v9, v17

    move/from16 v9, v17

    move/from16 v9, v17

    invoke-direct/range {v0 .. v9}, Lh6/b;->c(IIIIIIIII)Lcom/google/zxing/t;

    move-result-object v11

    invoke-virtual {v11}, Lcom/google/zxing/t;->d()F

    move-result v0

    float-to-int v0, v0

    add-int/lit8 v8, v0, 0x1

    div-int/lit8 v9, v14, 0x4

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v6, v18

    invoke-direct/range {v0 .. v9}, Lh6/b;->c(IIIIIIIII)Lcom/google/zxing/t;

    move-result-object v0

    const/4 v1, 0x4

    new-array v1, v1, [Lcom/google/zxing/t;

    aput-object v0, v1, v2

    aput-object v22, v1, v15

    const/4 v0, 0x2

    aput-object v12, v1, v0

    const/4 v0, 0x3

    aput-object v11, v1, v0

    return-object v1
.end method
