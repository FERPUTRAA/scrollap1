.class public final Lh6/a;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static a(FFFF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~c~sa@ ~bM@~@@~ifo~o@li~@rS d     ~K/l@i @b~@@~@@4f b@o/1~@ot @. ~~~~yv@-o~ ~n ~ @@tm @~o ~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    sub-float/2addr p0, p2

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    sub-float/2addr p1, p3

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    mul-float/2addr p0, p0

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    mul-float/2addr p1, p1

    const/4 v0, 0x5

    const/4 v1, 0x3

    add-float/2addr p0, p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    float-to-double p0, p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    double-to-float p0, p0

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    return p0
.end method

.method public static b(IIII)F
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    sub-int/2addr p0, p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    sub-int/2addr p1, p3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    mul-int/2addr p0, p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    mul-int/2addr p1, p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    add-int/2addr p0, p1

    const/4 v1, 0x7

    int-to-double p0, p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0, p1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    double-to-float p0, p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p0
.end method

.method public static c(F)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    cmpg-float v0, p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-gez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/high16 v0, -0x41000000    # -0.5f

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/high16 v0, 0x3f000000    # 0.5f

    :goto_0
    const/4 v1, 0x3

    const/4 v2, 0x7

    add-float/2addr p0, v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    float-to-int p0, p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p0
.end method

.method public static d([I)I
    .locals 6

    const/4 v5, 0x3

    array-length v0, p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    const/4 v5, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ge v1, v0, :cond_0

    const/4 v5, 0x1

    aget v3, p0, v1

    const/4 v5, 0x1

    add-int/2addr v2, v3

    const/4 v4, 0x6

    move v5, v4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    return v2
.end method
