.class public Lk7/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v0, Lk7/c;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method private static a()I
    .locals 6

    :cond_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@1si@~n.byK  @ ~/ b/ a~~ ~~~@os~@i@@  @4@ c- ~@ ~f@ @@blo  @u~~~~olf~o @~M@  d~@rtS~@vo~m~ti~@o~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    sget-object v0, Lk7/c;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const v3, 0xffffff

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-le v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x1

    and-int/2addr v5, v2

    :cond_1
    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v1
.end method

.method public static b()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method
