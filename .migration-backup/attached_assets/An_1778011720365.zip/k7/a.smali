.class public Lk7/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Lcom/rd/draw/data/a;I)I
    .locals 4
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->g()Lcom/rd/draw/data/b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v1, Lcom/rd/draw/data/b;->a:Lcom/rd/draw/data/b;

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lk7/a;->g(Lcom/rd/draw/data/a;I)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    return p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lk7/a;->h(Lcom/rd/draw/data/a;I)I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p0
.end method

.method private static b(Lcom/rd/draw/data/a;FF)I
    .locals 12
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->c()I

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->m()I

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->s()I

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->h()I

    move-result v3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->g()Lcom/rd/draw/data/b;

    move-result-object v4

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    sget-object v5, Lcom/rd/draw/data/b;->a:Lcom/rd/draw/data/b;

    const/4 v11, 0x1

    const/4 v10, 0x0

    if-ne v4, v5, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->d()I

    move-result p0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto :goto_0

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->v()I

    move-result p0

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    move v5, v4

    move v5, v4

    const/4 v11, 0x0

    move v5, v4

    move v5, v4

    const/4 v11, 0x3

    const/4 v10, 0x1

    move v6, v5

    move v6, v5

    const/4 v11, 0x1

    move v6, v5

    move v6, v5

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-ge v5, v0, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-lez v5, :cond_1

    const/4 v11, 0x3

    move v7, v3

    move v7, v3

    const/4 v11, 0x4

    move v7, v3

    move v7, v3

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    goto :goto_2

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    div-int/lit8 v7, v3, 0x2

    :goto_2
    const/4 v11, 0x3

    mul-int/lit8 v8, v1, 0x2

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    div-int/lit8 v9, v2, 0x2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    add-int/2addr v8, v9

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    add-int/2addr v8, v7

    const/4 v11, 0x0

    const/4 v10, 0x2

    add-int/2addr v8, v6

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    int-to-float v6, v6

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    cmpl-float v6, p1, v6

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x4

    if-ltz v6, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    int-to-float v6, v8

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    cmpg-float v6, p1, v6

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-gtz v6, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x2

    move v6, v7

    move v6, v7

    const/4 v11, 0x2

    move v6, v7

    move v6, v7

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    goto :goto_3

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    move v6, v4

    move v6, v4

    const/4 v11, 0x7

    move v6, v4

    move v6, v4

    :goto_3
    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v9, 0x0

    const/4 v11, 0x1

    cmpl-float v9, p2, v9

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-ltz v9, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    int-to-float v9, p0

    const/4 v11, 0x2

    const/4 v10, 0x1

    cmpg-float v9, p2, v9

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-gtz v9, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto :goto_4

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    move v7, v4

    move v7, v4

    const/4 v11, 0x0

    move v7, v4

    move v7, v4

    :goto_4
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz v6, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v7, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x2

    return v5

    :cond_4
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    move v6, v8

    move v6, v8

    const/4 v11, 0x4

    move v6, v8

    move v6, v8

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    goto/16 :goto_1

    :cond_5
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/4 p0, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    return p0
.end method

.method private static c(Lcom/rd/draw/data/a;I)I
    .locals 10
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->c()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->m()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->s()I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->h()I

    move-result v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v5, v4

    move v5, v4

    const/4 v9, 0x7

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-ge v4, v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    div-int/lit8 v6, v2, 0x2

    const/4 v9, 0x2

    const/4 v8, 0x1

    add-int v7, v1, v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    add-int/2addr v5, v7

    const/4 v8, 0x4

    move v9, v8

    if-ne p1, v4, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    return v5

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    add-int v7, v1, v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    add-int/2addr v7, v6

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    add-int/2addr v5, v7

    const/4 v9, 0x3

    const/4 v8, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_0

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->b()Lcom/rd/animation/type/a;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    sget-object p1, Lcom/rd/animation/type/a;->h:Lcom/rd/animation/type/a;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-ne p0, p1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    mul-int/lit8 v1, v1, 0x2

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    add-int/2addr v5, v1

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    return v5
.end method

.method public static d(Lcom/rd/draw/data/a;FF)I
    .locals 5
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x1

    move v4, v3

    const/4 p0, -0x1

    xor-int/2addr v4, p0

    const/4 v3, 0x0

    move v4, v3

    return p0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->g()Lcom/rd/draw/data/b;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v1, Lcom/rd/draw/data/b;->a:Lcom/rd/draw/data/b;

    const/4 v4, 0x1

    if-ne v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    move v2, p2

    move v2, p2

    const/4 v4, 0x2

    move v2, p2

    move v2, p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    move p2, p1

    move p2, p1

    const/4 v4, 0x7

    move p2, p1

    move p2, p1

    const/4 v4, 0x0

    move p1, v2

    move p1, v2

    const/4 v4, 0x6

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p0, p1, p2}, Lk7/a;->b(Lcom/rd/draw/data/a;FF)I

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return p0
.end method

.method public static e(Lcom/rd/draw/data/a;IFZ)Landroid/util/Pair;
    .locals 7
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/rd/draw/data/a;",
            "IFZ)",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->c()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->q()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz p3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v2, v0, -0x1

    sub-int p1, v2, p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gez p1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    move p1, v2

    move p1, v2

    const/4 v6, 0x0

    move p1, v2

    move p1, v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    sub-int/2addr v0, v3

    const/4 v6, 0x3

    if-le p1, v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    move p1, v0

    move p1, v0

    const/4 v6, 0x1

    move p1, v0

    move p1, v0

    :cond_2
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-le p1, v1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    move v0, v3

    move v0, v3

    const/4 v6, 0x3

    move v0, v3

    move v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v5, 0x2

    move v6, v5

    if-eqz p3, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v4, p1, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    if-ge v4, v1, :cond_4

    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    move v4, v3

    move v4, v3

    const/4 v6, 0x5

    move v4, v3

    move v4, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_3

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    move v4, v2

    move v4, v2

    const/4 v6, 0x5

    move v4, v2

    move v4, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_3

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v4, p1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ge v4, v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x4

    goto :goto_2

    :goto_3
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez v0, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v4, :cond_7

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/rd/draw/data/a;->W(I)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    move v1, p1

    const/4 v6, 0x4

    move v1, p1

    move v1, p1

    :cond_7
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 p0, 0x0

    if-ne v1, p1, :cond_8

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    cmpl-float v0, p2, p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v0, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    const/4 v6, 0x7

    move v2, v3

    move v2, v3

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v6, 0x7

    if-eqz v2, :cond_a

    const/4 v6, 0x4

    const/4 v5, 0x0

    if-eqz p3, :cond_9

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_4

    :cond_9
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_4

    :cond_a
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    sub-float p2, v0, p2

    :goto_4
    const/4 v6, 0x0

    const/4 v5, 0x4

    cmpl-float p3, p2, v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-lez p3, :cond_b

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    move p0, v0

    move p0, v0

    const/4 v6, 0x3

    move p0, v0

    move p0, v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_5

    :cond_b
    const/4 v6, 0x6

    const/4 v5, 0x0

    cmpg-float p3, p2, p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-gez p3, :cond_c

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_5

    :cond_c
    const/4 v6, 0x6

    const/4 v5, 0x1

    move p0, p2

    move p0, p2

    const/4 v6, 0x0

    move p0, p2

    move p0, p2

    :goto_5
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance p2, Landroid/util/Pair;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-direct {p2, p1, p0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object p2
.end method

.method private static f(Lcom/rd/draw/data/a;)I
    .locals 4
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->m()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->b()Lcom/rd/animation/type/a;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v1, Lcom/rd/animation/type/a;->h:Lcom/rd/animation/type/a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne p0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    mul-int/lit8 v0, v0, 0x3

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v0
.end method

.method public static g(Lcom/rd/draw/data/a;I)I
    .locals 4
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->g()Lcom/rd/draw/data/b;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lcom/rd/draw/data/b;->a:Lcom/rd/draw/data/b;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ne v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lk7/a;->c(Lcom/rd/draw/data/a;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0}, Lk7/a;->f(Lcom/rd/draw/data/a;)I

    move-result p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->j()I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/2addr p1, p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1
.end method

.method public static h(Lcom/rd/draw/data/a;I)I
    .locals 4
    .param p0    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x3

    return p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->g()Lcom/rd/draw/data/b;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v1, Lcom/rd/draw/data/b;->a:Lcom/rd/draw/data/b;

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lk7/a;->f(Lcom/rd/draw/data/a;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0, p1}, Lk7/a;->c(Lcom/rd/draw/data/a;I)I

    move-result p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/rd/draw/data/a;->l()I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/2addr p1, p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return p1
.end method
