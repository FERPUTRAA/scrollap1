.class public final Li6/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/zxing/p;


# static fields
.field private static final b:[Lcom/google/zxing/t;


# instance fields
.field private final a:Lcom/google/zxing/datamatrix/decoder/d;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-array v0, v0, [Lcom/google/zxing/t;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Li6/a;->b:[Lcom/google/zxing/t;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/zxing/datamatrix/decoder/d;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/zxing/datamatrix/decoder/d;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Li6/a;->a:Lcom/google/zxing/datamatrix/decoder/d;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private static b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/b;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v11, "Kcs@~@ro~@ M~ oo~@4m ~l~b@@@o/t~S~~  @b~~ n~.~/ ~~foi  @@ @oyv  @ulb 1@@@~i@@~ @t-@d~f~s@ a ~~~ "

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x5

    invoke-virtual {p0}, Lcom/google/zxing/common/b;->k()[I

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {p0}, Lcom/google/zxing/common/b;->f()[I

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-eqz v0, :cond_4

    const/4 v12, 0x6

    if-eqz v1, :cond_4

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v0, p0}, Li6/a;->d([ILcom/google/zxing/common/b;)I

    move-result v2

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    const/4 v3, 0x1

    const/4 v12, 0x5

    aget v4, v0, v3

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    aget v5, v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x1

    const/4 v6, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    aget v0, v0, v6

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    aget v1, v1, v6

    const/4 v12, 0x2

    const/4 v11, 0x2

    sub-int/2addr v1, v0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-int/2addr v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x7

    div-int/2addr v1, v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    sub-int/2addr v5, v4

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    add-int/2addr v5, v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    div-int/2addr v5, v2

    const/4 v11, 0x1

    move v12, v11

    if-lez v1, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-lez v5, :cond_3

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    div-int/lit8 v3, v2, 0x2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-int/2addr v4, v3

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    add-int/2addr v0, v3

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    new-instance v3, Lcom/google/zxing/common/b;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {v3, v1, v5}, Lcom/google/zxing/common/b;-><init>(II)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-ge v7, v5, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    mul-int v8, v7, v2

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    add-int/2addr v8, v4

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    move v9, v6

    move v9, v6

    const/4 v12, 0x0

    move v9, v6

    move v9, v6

    :goto_1
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-ge v9, v1, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    mul-int v10, v9, v2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    add-int/2addr v10, v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {p0, v10, v8}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v10

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    if-eqz v10, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v3, v9, v7}, Lcom/google/zxing/common/b;->o(II)V

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    add-int/lit8 v9, v9, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    goto :goto_1

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    goto :goto_0

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    return-object v3

    :cond_3
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    throw p0

    :cond_4
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    throw p0
.end method

.method private static d([ILcom/google/zxing/common/b;)I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/google/zxing/common/b;->l()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v5, 0x5

    aget v2, p0, v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v3, 0x1

    const/4 v6, 0x6

    aget v3, p0, v3

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ge v2, v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1, v2, v3}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v4

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eq v2, v0, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    aget p0, p0, v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    sub-int/2addr v2, p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    return v2

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    throw p0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    throw p0
.end method


# virtual methods
.method public a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/zxing/c;",
            "Ljava/util/Map<",
            "Lcom/google/zxing/e;",
            "*>;)",
            "Lcom/google/zxing/r;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object v0, Lcom/google/zxing/e;->b:Lcom/google/zxing/e;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {p2, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz p2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/google/zxing/c;->b()Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Li6/a;->b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object p2, p0, Li6/a;->a:Lcom/google/zxing/datamatrix/decoder/d;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p2, p1}, Lcom/google/zxing/datamatrix/decoder/d;->b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/e;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    sget-object p2, Li6/a;->b:[Lcom/google/zxing/t;

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance p2, Lcom/google/zxing/datamatrix/detector/a;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/google/zxing/c;->b()Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p2, p1}, Lcom/google/zxing/datamatrix/detector/a;-><init>(Lcom/google/zxing/common/b;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p2}, Lcom/google/zxing/datamatrix/detector/a;->c()Lcom/google/zxing/common/g;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object p2, p0, Li6/a;->a:Lcom/google/zxing/datamatrix/decoder/d;

    const/4 v6, 0x1

    invoke-virtual {p1}, Lcom/google/zxing/common/g;->a()Lcom/google/zxing/common/b;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p2, v0}, Lcom/google/zxing/datamatrix/decoder/d;->b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/e;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/google/zxing/common/g;->b()[Lcom/google/zxing/t;

    move-result-object p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v0, Lcom/google/zxing/r;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->g()[B

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    sget-object v3, Lcom/google/zxing/a;->f:Lcom/google/zxing/a;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v0, v1, v2, p2, v3}, Lcom/google/zxing/r;-><init>(Ljava/lang/String;[B[Lcom/google/zxing/t;Lcom/google/zxing/a;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->a()Ljava/util/List;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz p2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object v1, Lcom/google/zxing/s;->c:Lcom/google/zxing/s;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, v1, p2}, Lcom/google/zxing/r;->j(Lcom/google/zxing/s;Ljava/lang/Object;)V

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz p1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget-object p2, Lcom/google/zxing/s;->d:Lcom/google/zxing/s;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, p2, p1}, Lcom/google/zxing/r;->j(Lcom/google/zxing/s;Ljava/lang/Object;)V

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    return-object v0
.end method

.method public c(Lcom/google/zxing/c;)Lcom/google/zxing/r;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Li6/a;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public reset()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method
