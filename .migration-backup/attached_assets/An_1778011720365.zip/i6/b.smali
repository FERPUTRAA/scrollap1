.class public final Li6/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/zxing/v;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private static c(Lcom/google/zxing/qrcode/encoder/b;)Lcom/google/zxing/common/b;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "lSs~@~ni@@c/m@@~ s~-@~oo/@r~K ~~  1@ylM~~ o@d@~@ @@@    4 ao@ib~ @f~tio  @~@ufo~b.~ ~~b~@v~~~  @"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/google/zxing/qrcode/encoder/b;->e()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/google/zxing/qrcode/encoder/b;->d()I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-instance v2, Lcom/google/zxing/common/b;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {v2, v0, v1}, Lcom/google/zxing/common/b;-><init>(II)V

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v2}, Lcom/google/zxing/common/b;->b()V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    move v4, v3

    move v4, v3

    const/4 v9, 0x3

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ge v4, v0, :cond_2

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    move v5, v3

    move v5, v3

    const/4 v9, 0x6

    move v5, v3

    move v5, v3

    :goto_1
    const/4 v9, 0x2

    if-ge v5, v1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0, v4, v5}, Lcom/google/zxing/qrcode/encoder/b;->b(II)B

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 v7, 0x1

    const/4 v9, 0x3

    if-ne v6, v7, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v2, v4, v5}, Lcom/google/zxing/common/b;->o(II)V

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x3

    const/4 v8, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-object v2
.end method

.method private static d(Lcom/google/zxing/datamatrix/encoder/e;Lcom/google/zxing/datamatrix/encoder/k;)Lcom/google/zxing/common/b;
    .locals 13

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->i()I

    move-result v0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->h()I

    move-result v1

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    new-instance v2, Lcom/google/zxing/qrcode/encoder/b;

    const/4 v11, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->k()I

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->j()I

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x6

    invoke-direct {v2, v3, v4}, Lcom/google/zxing/qrcode/encoder/b;-><init>(II)V

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/4 v3, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x6

    move v4, v3

    move v4, v3

    const/4 v12, 0x5

    move v4, v3

    move v4, v3

    const/4 v12, 0x6

    const/4 v11, 0x6

    move v5, v4

    move v5, v4

    const/4 v12, 0x1

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    if-ge v4, v1, :cond_9

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget v6, p1, Lcom/google/zxing/datamatrix/encoder/k;->e:I

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    rem-int v6, v4, v6

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v7, 0x1

    const/4 v12, 0x1

    if-nez v6, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    move v6, v3

    move v6, v3

    const/4 v12, 0x1

    move v6, v3

    move v6, v3

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    move v8, v6

    move v8, v6

    const/4 v12, 0x2

    move v8, v6

    move v8, v6

    :goto_1
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->k()I

    move-result v9

    const/4 v12, 0x2

    const/4 v11, 0x7

    if-ge v6, v9, :cond_1

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    rem-int/lit8 v9, v6, 0x2

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-nez v9, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x0

    move v9, v7

    move v9, v7

    const/4 v12, 0x7

    move v9, v7

    move v9, v7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    goto :goto_2

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    move v9, v3

    move v9, v3

    const/4 v12, 0x7

    move v9, v3

    move v9, v3

    :goto_2
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v2, v8, v5, v9}, Lcom/google/zxing/qrcode/encoder/b;->h(IIZ)V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    add-int/2addr v8, v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    add-int/lit8 v6, v6, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    goto :goto_1

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    add-int/lit8 v5, v5, 0x1

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    move v6, v3

    move v6, v3

    const/4 v12, 0x4

    move v6, v3

    move v6, v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    move v8, v6

    move v8, v6

    :goto_3
    const/4 v12, 0x1

    if-ge v6, v0, :cond_6

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget v9, p1, Lcom/google/zxing/datamatrix/encoder/k;->d:I

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    rem-int v9, v6, v9

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    if-nez v9, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v2, v8, v5, v7}, Lcom/google/zxing/qrcode/encoder/b;->h(IIZ)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    add-int/lit8 v8, v8, 0x1

    :cond_3
    const/4 v12, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, v6, v4}, Lcom/google/zxing/datamatrix/encoder/e;->e(II)Z

    move-result v9

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v2, v8, v5, v9}, Lcom/google/zxing/qrcode/encoder/b;->h(IIZ)V

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    add-int/2addr v8, v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget v9, p1, Lcom/google/zxing/datamatrix/encoder/k;->d:I

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    rem-int v10, v6, v9

    const/4 v12, 0x7

    sub-int/2addr v9, v7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-ne v10, v9, :cond_5

    const/4 v12, 0x1

    rem-int/lit8 v9, v4, 0x2

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    if-nez v9, :cond_4

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    move v9, v7

    move v9, v7

    const/4 v12, 0x3

    move v9, v7

    move v9, v7

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    goto :goto_4

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    :goto_4
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v2, v8, v5, v9}, Lcom/google/zxing/qrcode/encoder/b;->h(IIZ)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    add-int/lit8 v8, v8, 0x1

    :cond_5
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    add-int/lit8 v6, v6, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    goto :goto_3

    :cond_6
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget v6, p1, Lcom/google/zxing/datamatrix/encoder/k;->e:I

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    rem-int v8, v4, v6

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    sub-int/2addr v6, v7

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-ne v8, v6, :cond_8

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x4

    move v6, v3

    move v6, v3

    const/4 v12, 0x7

    move v6, v3

    move v6, v3

    const/4 v12, 0x7

    move v8, v6

    move v8, v6

    :goto_5
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {p1}, Lcom/google/zxing/datamatrix/encoder/k;->k()I

    move-result v9

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-ge v6, v9, :cond_7

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v2, v8, v5, v7}, Lcom/google/zxing/qrcode/encoder/b;->h(IIZ)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x0

    add-int/2addr v8, v7

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    add-int/lit8 v6, v6, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    goto :goto_5

    :cond_7
    const/4 v12, 0x0

    add-int/lit8 v5, v5, 0x1

    :cond_8
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    goto/16 :goto_0

    :cond_9
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {v2}, Li6/b;->c(Lcom/google/zxing/qrcode/encoder/b;)Lcom/google/zxing/common/b;

    move-result-object p0

    const/4 v12, 0x2

    const/4 v11, 0x5

    return-object p0
.end method


# virtual methods
.method public a(Ljava/lang/String;Lcom/google/zxing/a;IILjava/util/Map;)Lcom/google/zxing/common/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/google/zxing/a;",
            "II",
            "Ljava/util/Map<",
            "Lcom/google/zxing/g;",
            "*>;)",
            "Lcom/google/zxing/common/b;"
        }
    .end annotation

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/zxing/a;->f:Lcom/google/zxing/a;

    if-ne p2, v0, :cond_5

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ltz p3, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-ltz p4, :cond_4

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object p2, Lcom/google/zxing/datamatrix/encoder/l;->a:Lcom/google/zxing/datamatrix/encoder/l;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz p5, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x0

    sget-object p4, Lcom/google/zxing/g;->c:Lcom/google/zxing/g;

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p5, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p4, Lcom/google/zxing/datamatrix/encoder/l;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p4, :cond_0

    move-object p2, p4

    move-object p2, p4

    move-object p2, p4

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object p4, Lcom/google/zxing/g;->d:Lcom/google/zxing/g;

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    invoke-interface {p5, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p4, Lcom/google/zxing/f;

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-eqz p4, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    move-object p4, p3

    move-object p4, p3

    move-object p4, p3

    move-object p4, p3

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/google/zxing/g;->e:Lcom/google/zxing/g;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p5, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p5, Lcom/google/zxing/f;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz p5, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_1

    :cond_2
    move-object p5, p3

    move-object p5, p3

    :goto_1
    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_2

    :cond_3
    move-object p5, p3

    move-object p5, p3

    move-object p5, p3

    move-object p5, p3

    :goto_2
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, p2, p3, p5}, Lcom/google/zxing/datamatrix/encoder/j;->c(Ljava/lang/String;Lcom/google/zxing/datamatrix/encoder/l;Lcom/google/zxing/f;Lcom/google/zxing/f;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p4

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p4, p2, p3, p5, v0}, Lcom/google/zxing/datamatrix/encoder/k;->o(ILcom/google/zxing/datamatrix/encoder/l;Lcom/google/zxing/f;Lcom/google/zxing/f;Z)Lcom/google/zxing/datamatrix/encoder/k;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/google/zxing/datamatrix/encoder/i;->c(Ljava/lang/String;Lcom/google/zxing/datamatrix/encoder/k;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p3, Lcom/google/zxing/datamatrix/encoder/e;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/google/zxing/datamatrix/encoder/k;->i()I

    move-result p4

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/google/zxing/datamatrix/encoder/k;->h()I

    move-result p5

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p3, p1, p4, p5}, Lcom/google/zxing/datamatrix/encoder/e;-><init>(Ljava/lang/CharSequence;II)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p3}, Lcom/google/zxing/datamatrix/encoder/e;->k()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p3, p2}, Li6/b;->d(Lcom/google/zxing/datamatrix/encoder/e;Lcom/google/zxing/datamatrix/encoder/k;)Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string p5, "Rt m:o smqide orunees a ienostsalmde"

    const-string p5, ": soieqmdao tmseoslna tlene  isreduR"

    const/4 v2, 0x5

    const-string/jumbo p5, "sss:ouiaRrl ntmmdai eoooed  ene lste"

    const-string p5, "Requested dimensions are too small: "

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p2, p5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 p3, 0x78

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p1

    :cond_5
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p4, "Can only encode DATA_MATRIX, but got "

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p1

    :cond_6
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo p2, "mtnmnbcyoot tdupeFns"

    const-string/jumbo p2, "p nmdoctF ymsetontnu"

    const/4 v2, 0x7

    const-string/jumbo p2, "styoFtuntuon mcep de"

    const-string p2, "Found empty contents"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    throw p1
.end method

.method public b(Ljava/lang/String;Lcom/google/zxing/a;II)Lcom/google/zxing/common/b;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    move v3, p3

    move v3, p3

    const/4 v7, 0x5

    move v3, p3

    move v3, p3

    const/4 v7, 0x3

    move v4, p4

    move v4, p4

    const/4 v7, 0x5

    move v4, p4

    move v4, p4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual/range {v0 .. v5}, Li6/b;->a(Ljava/lang/String;Lcom/google/zxing/a;IILjava/util/Map;)Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object p1
.end method
