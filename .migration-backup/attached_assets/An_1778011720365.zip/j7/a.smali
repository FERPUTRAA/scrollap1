.class public final Lj7/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "com.rd.pageindicatorview"

.field public static final c:Ljava/lang/String; = "release"

.field public static final d:Ljava/lang/String; = ""

.field public static final e:I = 0x1

.field public static final f:Ljava/lang/String; = "1.0"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method
