.class public interface abstract Lu6/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onDenied()V
.end method

.method public abstract onGranted()V
.end method
