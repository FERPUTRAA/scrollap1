.class public Lu6/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = 0x2766

.field private static b:Lu6/a;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;[Ljava/lang/String;)Z
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@os /@l~bso~ iu    d @~~i~@@@c r@K @o~bn~~~@~@~~ @Mo@~@~@o~m~@@~t@b~~~1tlv a.@/o~4-y@S ~  f   fi"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    array-length v0, p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x7

    move v2, v1

    move v2, v1

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-ge v2, v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    aget-object v3, p1, v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v4, v3}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v1, 0x1

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v1
.end method

.method public static b()Lu6/a;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lu6/a;->b:Lu6/a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-class v0, Lu6/a;

    const-class v0, Lu6/a;

    const-class v0, Lu6/a;

    const-class v0, Lu6/a;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Lu6/a;->b:Lu6/a;

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Lu6/a;

    const/4 v3, 0x7

    invoke-direct {v1}, Lu6/a;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    sput-object v1, Lu6/a;->b:Lu6/a;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object v0, Lu6/a;->b:Lu6/a;

    const/4 v3, 0x5

    return-object v0
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "npsmsnai..RisimdroeECrAMd"

    const-string v0, "iCsonER..oMAadinsrepdirms"

    const/4 v2, 0x0

    const-string/jumbo v0, "irCAoper.snAiMoE.idmoadsR"

    const-string v0, "android.permission.CAMERA"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lu6/a;->a(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p0
.end method

.method public static d(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "AdrRnb.SimR_NXAsOGoDLEmeo.RiEEdAarETpiTn"

    const-string v0, "dDRm_mETRio.pASroAXGnNaiATEseni.EdRE_LOr"

    const/4 v2, 0x3

    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v2, 0x5

    const/4 v1, 0x4

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lu6/a;->a(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0
.end method

.method public static e(Landroid/content/Context;[Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lu6/a;->a(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p0
.end method

.method public static f(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "dRG.TNuoOnIAELeiRomEsXoi_.AdTWESpisanrrET"

    const-string v0, ".anioE_E.dWerRrTnsITOAiLRATiopEGENso_SdXm"

    const/4 v2, 0x1

    const-string v0, "dnoRXISpEpNiaETLEW.ET.OrsndeR__orsAiRAmTi"

    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v2, 0x4

    const/4 v1, 0x6

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lu6/a;->a(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p0
.end method

.method private h(Landroidx/fragment/app/Fragment;Ljava/util/List;ILu6/c;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/fragment/app/Fragment;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;I",
            "Lu6/c;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    instance-of v0, p1, Lcom/luck/picture/lib/basic/e;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v0, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v2, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    check-cast v2, [Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    array-length v3, v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x5

    if-ge v4, v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    aget-object v5, v2, v4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v0, v5}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eqz v6, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v1, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-lez p2, :cond_4

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    check-cast p2, Lcom/luck/picture/lib/basic/e;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p2, p4}, Lcom/luck/picture/lib/basic/e;->Q0(Lu6/c;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-array p2, p2, [Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v1, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1, p2, p3}, Landroidx/fragment/app/Fragment;->requestPermissions([Ljava/lang/String;I)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v0, p2, p3}, Landroidx/core/app/b;->m(Landroid/app/Activity;[Ljava/lang/String;I)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz p4, :cond_5

    const/4 v8, 0x3

    invoke-interface {p4}, Lu6/c;->onGranted()V

    :cond_5
    :goto_1
    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method public g([ILu6/c;)V
    .locals 2

    const/4 v1, 0x4

    invoke-static {p1}, Lu6/d;->c([I)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-interface {p2}, Lu6/c;->onGranted()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-interface {p2}, Lu6/c;->onDenied()V

    :goto_0
    return-void
.end method

.method public i(Landroidx/fragment/app/Fragment;Ljava/util/List;Lu6/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/fragment/app/Fragment;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;",
            "Lu6/c;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x2766

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0, p3}, Lu6/a;->h(Landroidx/fragment/app/Fragment;Ljava/util/List;ILu6/c;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public j(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Lu6/c;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 p2, 0x2766

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0, p2, p3}, Lu6/a;->h(Landroidx/fragment/app/Fragment;Ljava/util/List;ILu6/c;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method
