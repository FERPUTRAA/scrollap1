.class public Lu6/b;
.super Ljava/lang/Object;


# static fields
.field public static a:[Ljava/lang/String;

.field public static final b:[Ljava/lang/String;

.field public static final c:[Ljava/lang/String;

.field public static final d:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v0, "_sseRRNESLEr.iOG.oDTEns_XpardToAsiAnARiE"

    const-string/jumbo v0, "rEsTisAdpnANsGTEEo_RRL.anoDiriESAe.Om_RX"

    const/4 v3, 0x6

    const-string v0, "ATsmniTNniRASRLiamsDErdEGoRdo_._OArp.EeE"

    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, "TdpioEoAGI.r.OSTiRmnRRT_eEmWEsXds_EoALraN"

    const-string/jumbo v1, "nidmAieGOa._sREdWXorSAsETpERT.LonIrERNT_m"

    const/4 v3, 0x5

    const-string v1, "WpoIRbGTeriRoAdTLmE.isRiNES_aOXnAd._ErTEn"

    const-string v1, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v3, 0x2

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v0, Lu6/b;->b:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    sput-object v0, Lu6/b;->c:[Ljava/lang/String;

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "dsrpoonEaiMAsR..erAiodCim"

    const/4 v3, 0x2

    const-string v0, "dAedCnuoRonEs.ri.iMampirA"

    const-string v0, "android.permission.CAMERA"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object v0, Lu6/b;->d:[Ljava/lang/String;

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method
