.class public Lu6/d;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroidx/fragment/app/Fragment;ZI)V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s~nb@uyot da@o~~fo~ @~~@~@b~K@1~@~@~@ r/@ sb @@i@ m/ -fi~~ ~@~@@v ~  @S  c i @. ~4l~~ ~o~tMlo@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x4

    or-int/2addr v4, v3

    const-string v0, "MSLmntSAsONii.Sa_I.noRsIGtESeE_LEdsM_SLAAPEFrN_CdAI"

    const-string v0, "GSsiSiaI_s_snSer_S.EAIECIOLNPnLAoRLE_NdEAt.CAFdMStM"

    const/4 v4, 0x7

    const-string v0, "FPNEoS_IASSrsEOGALMsnELMie_ACISSo_RdANI_Lt.CgEtdnia"

    const-string v0, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {p0, p1, p2}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x4

    move v4, v3

    const-string v0, "IrsSEbTPSdNEtNISe.iOdmTLoLg_AT_nPTtIIs.ACGAiD"

    const-string/jumbo v0, "sIdmT_SLSigPArE_eAODTCTPLiIoGIEA.SstT.dNINntn"

    const/4 v4, 0x3

    const-string v0, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v0, "agaopku"

    const-string v0, "ckpgoaa"

    const/4 v4, 0x7

    const-string/jumbo v0, "pakgpae"

    const-string/jumbo v0, "package"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p1, p2}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x2

    return-void
.end method

.method public static varargs b(Landroid/content/Context;[Ljava/lang/String;)Z
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/c1;
            min = 0x1L
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    array-length v0, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x0

    and-int/2addr v5, v1

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    move v2, v1

    move v2, v1

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ge v2, v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    aget-object v3, p1, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p0, v3}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 p0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x7

    return p0
.end method

.method public static c([I)Z
    .locals 6

    const/4 v4, 0x0

    const/4 v5, 0x1

    array-length v0, p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-lez v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    array-length v0, p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    const/4 v5, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v2, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    aget v3, p0, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 p0, 0x1

    move v5, p0

    const/4 v4, 0x0

    move v5, v4

    move v1, p0

    move v1, p0

    const/4 v5, 0x4

    move v1, p0

    move v1, p0

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v1
.end method
