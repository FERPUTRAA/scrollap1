.class public Le7/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/rd/animation/controller/a;


# direct methods
.method public constructor <init>(Lcom/rd/draw/data/a;Lcom/rd/animation/controller/b$a;)V
    .locals 3
    .param p1    # Lcom/rd/draw/data/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/rd/animation/controller/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/rd/animation/controller/a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, p1, p2}, Lcom/rd/animation/controller/a;-><init>(Lcom/rd/draw/data/a;Lcom/rd/animation/controller/b$a;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Le7/a;->a:Lcom/rd/animation/controller/a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~@4o@@f f@~to a~~ b~ @o~ bm  d~~@  ~/@~oKi@ol@y  ~~ns~c@~ ~~@@@r/@ .@@v~~ t~@S- @ui@ iMlo@1~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Le7/a;->a:Lcom/rd/animation/controller/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/rd/animation/controller/a;->e()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Le7/a;->a:Lcom/rd/animation/controller/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/rd/animation/controller/a;->b()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Le7/a;->a:Lcom/rd/animation/controller/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/rd/animation/controller/a;->e()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public c(F)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Le7/a;->a:Lcom/rd/animation/controller/a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Lcom/rd/animation/controller/a;->g(F)V

    :cond_0
    const/4 v2, 0x2

    return-void
.end method
