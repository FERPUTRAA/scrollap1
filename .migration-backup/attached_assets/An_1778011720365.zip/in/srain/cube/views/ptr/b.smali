.class public abstract Lin/srain/cube/views/ptr/b;
.super Lin/srain/cube/views/ptr/c;

# interfaces
.implements Lin/srain/cube/views/ptr/d;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Lin/srain/cube/views/ptr/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static canChildScrollDown(Landroid/view/View;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~s@t@ @ oo S@ ~~ ~u.@i~~b@@iM ~~@l~~1@of ~~  i@a@Kdt lr~/4no~@@~@ ~-b~~/ b s@@@~fom@ ~y v @ @c~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return p0
.end method

.method public static checkContentCanBePulledUp(Lin/srain/cube/views/ptr/PtrFrameLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1}, Lin/srain/cube/views/ptr/b;->canChildScrollDown(Landroid/view/View;)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    xor-int/lit8 p0, p0, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p0
.end method


# virtual methods
.method public checkCanDoLoadMore(Lin/srain/cube/views/ptr/PtrFrameLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p1, p2, p3}, Lin/srain/cube/views/ptr/b;->checkContentCanBePulledUp(Lin/srain/cube/views/ptr/PtrFrameLayout;Landroid/view/View;Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method
