.class public final Ld7/c;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ld7/r;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:Ld7/b;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "pb"

    const-string/jumbo v0, "pb"

    const/4 v2, 0x7

    const-string v0, "bp"

    const-string/jumbo v0, "pb"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "snssckTha"

    const-string/jumbo v0, "kcsnTiahs"

    const/4 v2, 0x5

    const-string/jumbo v0, "kacmsTain"

    const-string v0, "chainTask"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Ld7/c;->a:Ld7/r;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p2, p0, Ld7/c;->b:Ld7/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public static synthetic e(Ld7/c;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b S o1~@~~@@ir~ @o@ @@f/u~n@~ @o ~ Mm~. bt~~4@~l  @@a/@~  ~@so@i~@~o~il f-c@K~ b~o~@d~~ ~@  @vto"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    and-int/lit8 p5, p5, 0x8

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-eqz p5, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 p4, 0x1

    const/4 p4, 0x0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3, p4}, Ld7/c;->d(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Lcom/permissionx/guolindev/dialog/c;)V
    .locals 5
    .param p1    # Lcom/permissionx/guolindev/dialog/c;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x0

    const-string v0, "aldmgo"

    const/4 v4, 0x7

    const-string/jumbo v0, "iolgdb"

    const-string v0, "dialog"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Ld7/c;->a:Ld7/r;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Ld7/c;->b:Ld7/b;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2, p1}, Ld7/r;->F(Ld7/b;ZLcom/permissionx/guolindev/dialog/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public final b(Lcom/permissionx/guolindev/dialog/d;)V
    .locals 5
    .param p1    # Lcom/permissionx/guolindev/dialog/d;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v0, "nmraodFtgolaeg"

    const/4 v4, 0x5

    const-string v0, "ganaeduimFtorl"

    const-string v0, "dialogFragment"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x3

    iget-object v0, p0, Ld7/c;->a:Ld7/r;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Ld7/c;->b:Ld7/b;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2, p1}, Ld7/r;->G(Ld7/b;ZLcom/permissionx/guolindev/dialog/d;)V

    const/4 v4, 0x7

    return-void
.end method

.method public final c(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string/jumbo v0, "oipimsspbne"

    const-string/jumbo v0, "neiisbromsp"

    const-string/jumbo v0, "simisnorqep"

    const-string/jumbo v0, "permissions"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v0, "eesasug"

    const-string v0, "egeamsu"

    const/4 v9, 0x4

    const-string/jumbo v0, "message"

    const/4 v9, 0x5

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v0, "iTemsivptoet"

    const-string v0, "exvtiTipsteo"

    const/4 v9, 0x1

    const-string/jumbo v0, "vtixoTepiseo"

    const-string/jumbo v0, "positiveText"

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v5, 0x0

    const/4 v9, 0x2

    const/16 v6, 0x8

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v7, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static/range {v1 .. v7}, Ld7/c;->e(Ld7/c;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-void
.end method

.method public final d(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v0, "imqepbsnsro"

    const-string/jumbo v0, "ssprnemsqio"

    const/4 v9, 0x2

    const-string/jumbo v0, "psnersuoimi"

    const-string/jumbo v0, "permissions"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo v0, "pssemga"

    const-string v0, "agsessm"

    const/4 v9, 0x3

    const-string v0, "eqsmgae"

    const-string/jumbo v0, "message"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v0, "vtstioisemTx"

    const-string/jumbo v0, "xeTmtpitisov"

    const/4 v9, 0x0

    const-string/jumbo v0, "iepmttviToxe"

    const-string/jumbo v0, "positiveText"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v1, p0, Ld7/c;->a:Ld7/r;

    const/4 v9, 0x5

    const/4 v8, 0x0

    iget-object v2, p0, Ld7/c;->b:Ld7/b;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v3, 0x1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v6, p3

    move-object v6, p3

    move-object v7, p4

    move-object v7, p4

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual/range {v1 .. v7}, Ld7/r;->H(Ld7/b;ZLjava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    return-void
.end method
