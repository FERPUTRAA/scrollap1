.class public final synthetic Ld7/n;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/permissionx/guolindev/dialog/d;

.field public final synthetic b:Ld7/b;


# direct methods
.method public synthetic constructor <init>(Lcom/permissionx/guolindev/dialog/d;Ld7/b;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Ld7/n;->a:Lcom/permissionx/guolindev/dialog/d;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Ld7/n;->b:Ld7/b;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s~  r@ @/f~@li/@ ~@ oi t@m@- @u~.oo@~ ~ ~ ~Ka~f b~1b@@M@4@ov d~cl  i~@~~~@~b@@y ~~~@So@so~~~tn"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Ld7/n;->a:Lcom/permissionx/guolindev/dialog/d;

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Ld7/n;->b:Ld7/b;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1, p1}, Ld7/r;->c(Lcom/permissionx/guolindev/dialog/d;Ld7/b;Landroid/view/View;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method
