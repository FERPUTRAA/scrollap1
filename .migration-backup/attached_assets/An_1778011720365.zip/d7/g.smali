.class public final synthetic Ld7/g;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Ld7/l;


# direct methods
.method public synthetic constructor <init>(Ld7/l;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    iput-object p1, p0, Ld7/g;->a:Ld7/l;

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " fsb~~@~@c iK @4@d ml@@My~~ai~  @ o@t/of    ~ @@Sn~tl~~~@ob@u~o~@@~o./~ - @~~bo~rs@@@~@1 v @~~ i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Ld7/g;->a:Ld7/l;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p1, Landroidx/activity/result/ActivityResult;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p1}, Ld7/l;->f0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
