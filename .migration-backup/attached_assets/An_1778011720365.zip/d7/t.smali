.class public final Ld7/t;
.super Ljava/lang/Object;


# instance fields
.field private a:Ld7/a;
    .annotation build Lia/e;
    .end annotation
.end field

.field private b:Ld7/a;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Ld7/a;)V
    .locals 3
    .param p1    # Ld7/a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ys ~~d/ cl1~.~t@m @@u S ~ f l~t@~ obo@@@~M/bin@ ~@r @ b~4 o~~@~~@~ @~@ a@s@ @o~Kio~io@ ~~~-f@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-string/jumbo v0, "skat"

    const-string/jumbo v0, "task"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-object v0, p0, Ld7/t;->a:Ld7/a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Ld7/t;->a:Ld7/a;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, p0, Ld7/t;->b:Ld7/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, v0, Ld7/a;->b:Ld7/b;

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Ld7/t;->b:Ld7/a;

    const/4 v2, 0x0

    return-void
.end method

.method public final b()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Ld7/t;->a:Ld7/a;

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0}, Ld7/b;->request()V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
