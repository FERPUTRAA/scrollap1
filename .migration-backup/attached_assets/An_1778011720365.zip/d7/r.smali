.class public final Ld7/r;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld7/r$a;
    }
.end annotation


# static fields
.field public static final u:Ld7/r$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final v:Ljava/lang/String; = "InvisibleFragment"
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field public a:Landroidx/fragment/app/FragmentActivity;

.field private b:Landroidx/fragment/app/Fragment;
    .annotation build Lia/e;
    .end annotation
.end field

.field private c:I

.field private d:I

.field private e:I

.field public f:Landroid/app/Dialog;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public g:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public h:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public i:Z
    .annotation build Lh8/e;
    .end annotation
.end field

.field public j:Z
    .annotation build Lh8/e;
    .end annotation
.end field

.field public k:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public l:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public m:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public n:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public o:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public p:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public q:Lb7/d;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public r:Lb7/a;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public s:Lb7/b;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public t:Lb7/c;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ld7/r$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ld7/r$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Ld7/r;->u:Ld7/r$a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Landroidx/fragment/app/FragmentActivity;Landroidx/fragment/app/Fragment;Ljava/util/Set;Ljava/util/Set;)V
    .locals 3
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Landroidx/fragment/app/Fragment;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Ljava/util/Set;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Ljava/util/Set;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/fragment/app/FragmentActivity;",
            "Landroidx/fragment/app/Fragment;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "rasnrmoelsmniPssi"

    const-string/jumbo v0, "srsrisnPmmonilsae"

    const/4 v2, 0x0

    const-string/jumbo v0, "oesmsrmimralnsioP"

    const-string/jumbo v0, "normalPermissions"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo v0, "isesomnPseosimpiac"

    const-string/jumbo v0, "smimcrsanesiseoPip"

    const/4 v2, 0x4

    const-string v0, "Pepcsbmolaierisiss"

    const-string/jumbo v0, "specialPermissions"

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput v0, p0, Ld7/r;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Ld7/r;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Ld7/r;->e:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Ld7/r;->k:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Ld7/r;->l:Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Ld7/r;->m:Ljava/util/Set;

    const/4 v2, 0x0

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Ld7/r;->n:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Ld7/r;->o:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x1

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Ld7/r;->p:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Ld7/r;->y(Landroidx/fragment/app/FragmentActivity;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p1

    const/4 v2, 0x0

    const-string/jumbo v0, "nc(eiru)yieo.Aiaqtvrufgrtt"

    const-string v0, "cquAotte)griti(enfayvr.mri"

    const/4 v2, 0x5

    const-string/jumbo v0, "tAeqmi)p.nirurrtgafe(vtyec"

    const-string v0, "fragment.requireActivity()"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Ld7/r;->y(Landroidx/fragment/app/FragmentActivity;)V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p2, p0, Ld7/r;->b:Landroidx/fragment/app/Fragment;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p3, p0, Ld7/r;->g:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p4, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method private static final I(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "S~lm @~~qu/~@/y~ o~~~fbo~ @@@@ ~at c~@ ~-~o~i .@@iMs@~it@~vln~ ~@@f1o  @ bd rK @@~b4@@   ~oo~@~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const-string/jumbo p5, "liga$bd"

    const/4 v1, 0x7

    const-string p5, "i$saolg"

    const-string p5, "$dialog"

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x5

    const-string p5, "huamiaTscn"

    const-string/jumbo p5, "kaanihucTs"

    const/4 v1, 0x5

    const-string p5, "hna$ocTska"

    const-string p5, "$chainTask"

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p2, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    const-string/jumbo p5, "pisenmsps$ir"

    const/4 v1, 0x5

    const-string p5, "$permissions"

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p3, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    const-string/jumbo p5, "t0h$ib"

    const-string/jumbo p5, "this$0"

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p4, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-interface {p2, p3}, Ld7/b;->a(Ljava/util/List;)V

    const/4 v0, 0x4

    move v1, v0

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-direct {p4, p3}, Ld7/r;->g(Ljava/util/List;)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method private static final J(Lcom/permissionx/guolindev/dialog/c;Ld7/b;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    const-string/jumbo p2, "oq$dali"

    const/4 v1, 0x7

    const-string p2, "glio$au"

    const-string p2, "$dialog"

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p2}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x5

    const-string p2, "csaikn$pha"

    const-string/jumbo p2, "iksh$Tcnaa"

    const/4 v1, 0x1

    const-string/jumbo p2, "sncaT$khqa"

    const-string p2, "$chainTask"

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p1}, Ld7/b;->finish()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method private static final K(Ld7/r;Landroid/content/DialogInterface;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string p1, "hts$i0"

    const-string/jumbo p1, "this$0"

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Ld7/r;->f:Landroid/app/Dialog;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method private static final L(Lcom/permissionx/guolindev/dialog/d;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x2

    const-string/jumbo p5, "nF$maiogmrdgltm"

    const-string/jumbo p5, "mgomailtganFd$r"

    const/4 v1, 0x2

    const-string p5, "dFmtoaelgno$igr"

    const-string p5, "$dialogFragment"

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p5, "icn$kbTsaa"

    const-string p5, "$chainTask"

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p2, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-string p5, "eis$mousorpi"

    const-string/jumbo p5, "imsioosserp$"

    const/4 v1, 0x4

    const-string p5, "$permissions"

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-static {p3, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    const-string/jumbo p5, "sp0hi$"

    const-string p5, "$sih0b"

    const/4 v1, 0x6

    const-string p5, "i$qs0h"

    const-string/jumbo p5, "this$0"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p4, p5}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/c;->dismiss()V

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p2, p3}, Ld7/b;->a(Ljava/util/List;)V

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p4, p3}, Ld7/r;->g(Ljava/util/List;)V

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method private static final M(Lcom/permissionx/guolindev/dialog/d;Ld7/b;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string/jumbo p2, "ndsaFgit$lrgoam"

    const-string p2, "$Fgntluriaomadg"

    const/4 v1, 0x6

    const-string p2, "goimltdmFgr$aan"

    const-string p2, "$dialogFragment"

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0, p2}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const-string p2, "ahasonTci$"

    const-string p2, "$chainTask"

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/c;->dismiss()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-interface {p1}, Ld7/b;->finish()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public static synthetic a(Lcom/permissionx/guolindev/dialog/c;Ld7/b;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Ld7/r;->J(Lcom/permissionx/guolindev/dialog/c;Ld7/b;Landroid/view/View;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method

.method public static synthetic b(Lcom/permissionx/guolindev/dialog/d;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static/range {p0 .. p5}, Ld7/r;->L(Lcom/permissionx/guolindev/dialog/d;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static synthetic c(Lcom/permissionx/guolindev/dialog/d;Ld7/b;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Ld7/r;->M(Lcom/permissionx/guolindev/dialog/d;Ld7/b;Landroid/view/View;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static synthetic d(Ld7/r;Landroid/content/DialogInterface;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Ld7/r;->K(Ld7/r;Landroid/content/DialogInterface;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static synthetic e(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x0

    invoke-static/range {p0 .. p5}, Ld7/r;->I(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private final g(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Ld7/r;->p:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v2, 0x5

    iget-object v0, p0, Ld7/r;->p:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Ld7/l;->l0()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method private final i()Landroidx/fragment/app/FragmentManager;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Ld7/r;->b:Landroidx/fragment/app/Fragment;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "racyubritavtistMgeF.agrpmponpnt"

    const-string/jumbo v1, "rgtasegpvparor.MmtiatynnpiFauct"

    const/4 v3, 0x2

    const-string v1, "eapmoyueiavgcittgruFttsrnparn.a"

    const-string v1, "activity.supportFragmentManager"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method private final j()Ld7/l;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0}, Ld7/r;->i()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-string v1, "aenlgbvmqitnIeirF"

    const/4 v4, 0x4

    const-string/jumbo v1, "nargeivpeFimslnbt"

    const-string v1, "InvisibleFragment"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v0, Ld7/l;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    new-instance v0, Ld7/l;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0}, Ld7/l;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0}, Ld7/r;->i()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, v0, v1}, Landroidx/fragment/app/a0;->k(Landroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->t()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0
.end method

.method private final l()V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SourceLockedOrientationActivity"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/app/Activity;->getRequestedOrientation()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Ld7/r;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v1, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public final A()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "dosaCnmsSADriCoENUrpSiOCL.GRO.As_iAO_KCBendTI"

    const/4 v3, 0x3

    const-string v1, ".sTEoC_CqA_iLndOKNrpiCBAmOUADRnaedoNSGOi.srIC"

    const-string v1, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public final B()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const-string v1, "PdsiNAeSomRCiKSTU.mAGEnasAQIsorE_LESTn_rLp."

    const-string v1, "epsmSn_SATEAoENQEaIRi.Pord_GKCrdLi.mASTnLsU"

    const/4 v3, 0x7

    const-string/jumbo v1, "oiCmeTI_QL_aP.ASRAsEnEKSELimiorNAd.rUpGsnTS"

    const-string v1, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public final C()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, "AA_ropeEsnM.AEGooET.miRoNNrd_ESiasiLnRGOTA"

    const-string/jumbo v1, "sG.EoAAndNMrLGEeo_SRa.n_mEiisOAdiRTANEpoTr"

    const/4 v3, 0x7

    const-string v1, "aMArAb.dENsG_GOLEo.AripomindieRTSnRXEEATNs"

    const-string v1, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method public final D()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "iOWWonuSiTIsAM_aNsLErmEdoRT_n.bpSDe.dY"

    const-string/jumbo v1, "oiTpAbSdWYWIEre_NdnOiEim._DMoLRTnas.Ss"

    const/4 v3, 0x5

    const-string/jumbo v1, "seSrpErpsS.WiaToi.DToWniEd_nILAdY_ONRm"

    const-string v1, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method public final E()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Ld7/r;->h:Ljava/util/Set;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "iousdTEGqeSraSTTRs_piNoiIdnE.mW.n"

    const-string v1, "_dIEoiudTNT.s.STIWGmRprEainnieSso"

    const/4 v3, 0x3

    const-string/jumbo v1, "sds.ESE.WasSI_IRTdTnmieGnrrioiNpo"

    const-string v1, "android.permission.WRITE_SETTINGS"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0
.end method

.method public final F(Ld7/b;ZLcom/permissionx/guolindev/dialog/c;)V
    .locals 12
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lcom/permissionx/guolindev/dialog/c;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo v0, "siamkTnpc"

    const-string v0, "iTscankph"

    const/4 v11, 0x3

    const-string v0, "Tiasokhcn"

    const-string v0, "chainTask"

    const/4 v11, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v0, "lqdoib"

    const-string v0, "dlqoai"

    const/4 v11, 0x0

    const-string/jumbo v0, "uaidgo"

    const-string v0, "dialog"

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v0, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput-boolean v0, p0, Ld7/r;->j:Z

    const/4 v11, 0x5

    const/4 v10, 0x5

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/c;->b()Ljava/util/List;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const-string/jumbo v1, "lsotiaqpmngioesR.seipsoeTdr"

    const-string v1, "eRsiT.eidstoiolqspsmeasnorg"

    const/4 v11, 0x5

    const-string/jumbo v1, "onissqdrqosaieesui.mogeTplR"

    const-string v1, "dialog.permissionsToRequest"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v5, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-eqz v1, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {p1}, Ld7/b;->finish()V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    return-void

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    iput-object p3, p0, Ld7/r;->f:Landroid/app/Dialog;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p3}, Landroid/app/Dialog;->show()V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    instance-of v1, p3, Lcom/permissionx/guolindev/dialog/a;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-eqz v1, :cond_1

    move-object v1, p3

    move-object v1, p3

    move-object v1, p3

    move-object v1, p3

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x2

    check-cast v1, Lcom/permissionx/guolindev/dialog/a;

    const/4 v11, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1}, Lcom/permissionx/guolindev/dialog/a;->f()Z

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-eqz v1, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p3}, Landroid/app/Dialog;->dismiss()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-interface {p1}, Ld7/b;->finish()V

    :cond_1
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/c;->c()Landroid/view/View;

    move-result-object v7

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string/jumbo v1, "losiitt.piBgvdsaoutom"

    const-string v1, "gtvmiottpBlisnodi.aou"

    const/4 v11, 0x2

    const-string/jumbo v1, "olimtBnvgtdiooaetsui."

    const-string v1, "dialog.positiveButton"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {v7, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/c;->a()Landroid/view/View;

    move-result-object v8

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v1, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p3, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {p3, v1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v7, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-instance v9, Ld7/o;

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    move v3, p2

    const/4 v11, 0x2

    move v3, p2

    move v3, p2

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-direct/range {v1 .. v6}, Ld7/o;-><init>(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v7, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v10, 0x4

    move v11, v10

    if-eqz v8, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v8, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v11, 0x3

    new-instance p2, Ld7/p;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-direct {p2, p3, p1}, Ld7/p;-><init>(Lcom/permissionx/guolindev/dialog/c;Ld7/b;)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v8, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_2
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-object p1, p0, Ld7/r;->f:Landroid/app/Dialog;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-nez p1, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    goto :goto_0

    :cond_3
    const/4 v11, 0x2

    const/4 v10, 0x0

    new-instance p2, Ld7/q;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-direct {p2, p0}, Ld7/q;-><init>(Ld7/r;)V

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {p1, p2}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-void
.end method

.method public final G(Ld7/b;ZLcom/permissionx/guolindev/dialog/d;)V
    .locals 12
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lcom/permissionx/guolindev/dialog/d;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string v0, "Tkncoahos"

    const-string v0, "hsTaocikn"

    const/4 v11, 0x0

    const-string/jumbo v0, "ihncabkaT"

    const-string v0, "chainTask"

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x1

    const-string/jumbo v0, "mtalonuFreggab"

    const-string v0, "altFgbmngierao"

    const/4 v11, 0x7

    const-string v0, "gndgletpamaroi"

    const-string v0, "dialogFragment"

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v0, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x2

    iput-boolean v0, p0, Ld7/r;->j:Z

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/d;->f0()Ljava/util/List;

    move-result-object v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string/jumbo v1, "moniTeetq.sqosdeieamlitgoFaRrsguusp"

    const-string/jumbo v1, "sgmsueu.ideoRoTespartrltianesgoFqmi"

    const/4 v11, 0x1

    const-string/jumbo v1, "itseoRo.nnmrageomrFssssdiueTltaeqpg"

    const-string v1, "dialogFragment.permissionsToRequest"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v5, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-eqz v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {p1}, Ld7/b;->finish()V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    return-void

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {p0}, Ld7/r;->i()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string v2, "etamXsasomnoPgRgiFtimoaenDarinille"

    const-string v2, "PermissionXRationaleDialogFragment"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p3, v1, v2}, Landroidx/fragment/app/c;->showNow(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/d;->g0()Landroid/view/View;

    move-result-object v7

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string/jumbo v1, "itmtogBtinogrpnsooi.eavdtepFu"

    const-string/jumbo v1, "sgteroBpoiuvFtnnpe.toatdigmia"

    const/4 v11, 0x3

    const-string/jumbo v1, "teosgbnltonBFraapdotgmeutviii"

    const-string v1, "dialogFragment.positiveButton"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v7, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v11, 0x2

    invoke-virtual {p3}, Lcom/permissionx/guolindev/dialog/d;->e0()Landroid/view/View;

    move-result-object v8

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/4 v1, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-virtual {p3, v1}, Landroidx/fragment/app/c;->setCancelable(Z)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v7, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    new-instance v9, Ld7/m;

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    move v3, p2

    move v3, p2

    const/4 v11, 0x5

    move v3, p2

    move v3, p2

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct/range {v1 .. v6}, Ld7/m;-><init>(Lcom/permissionx/guolindev/dialog/d;ZLd7/b;Ljava/util/List;Ld7/r;)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v7, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-eqz v8, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v8, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    new-instance p2, Ld7/n;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {p2, p3, p1}, Ld7/n;-><init>(Lcom/permissionx/guolindev/dialog/d;Ld7/b;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v8, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    return-void
.end method

.method public final H(Ld7/b;ZLjava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld7/b;",
            "Z",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const-string v0, "hkcTasuna"

    const-string v0, "chainTask"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "spsiqsmpero"

    const-string/jumbo v0, "rsnposieqms"

    const-string/jumbo v0, "sormsisnqpe"

    const-string/jumbo v0, "permissions"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "gssaese"

    const-string v0, "emsgsae"

    const-string/jumbo v0, "message"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v0, "tvxmtiTmsoei"

    const-string v0, "eximiTvostte"

    const-string/jumbo v0, "vtesoiotxeTp"

    const-string/jumbo v0, "positiveText"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/permissionx/guolindev/dialog/a;

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v2

    iget v7, p0, Ld7/r;->c:I

    iget v8, p0, Ld7/r;->d:I

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    invoke-direct/range {v1 .. v8}, Lcom/permissionx/guolindev/dialog/a;-><init>(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-virtual {p0, p1, p2, v0}, Ld7/r;->F(Ld7/b;ZLcom/permissionx/guolindev/dialog/c;)V

    return-void
.end method

.method public final f()Ld7/r;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-boolean v0, p0, Ld7/r;->i:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public final h()Landroidx/fragment/app/FragmentActivity;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Ld7/r;->a:Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "oiiatbvc"

    const-string/jumbo v0, "vctioiat"

    const/4 v2, 0x3

    const-string/jumbo v0, "tvyctaui"

    const-string v0, "activity"

    const/4 v2, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-object v0
.end method

.method public final k()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    return v0
.end method

.method public final m(Lb7/a;)Ld7/r;
    .locals 2
    .param p1    # Lb7/a;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Ld7/r;->r:Lb7/a;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public final n(Lb7/b;)Ld7/r;
    .locals 2
    .param p1    # Lb7/b;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Ld7/r;->s:Lb7/b;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public final o(Lb7/c;)Ld7/r;
    .locals 2
    .param p1    # Lb7/c;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Ld7/r;->t:Lb7/c;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method public final p()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Ld7/r;->i()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "bagIebntemriivlsF"

    const/4 v3, 0x1

    const-string v1, "grtFanbplnimsiIve"

    const-string v1, "InvisibleFragment"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Ld7/r;->i()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/fragment/app/a0;->r()I

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public final q(Lb7/d;)V
    .locals 3
    .param p1    # Lb7/d;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Ld7/r;->q:Lb7/d;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Ld7/r;->l()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Ld7/t;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-direct {p1}, Ld7/t;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Ld7/w;

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Ld7/w;-><init>(Ld7/r;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ld7/s;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Ld7/s;-><init>(Ld7/r;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Ld7/x;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Ld7/x;-><init>(Ld7/r;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ld7/y;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Ld7/y;-><init>(Ld7/r;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x4

    new-instance v0, Ld7/v;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ld7/v;-><init>(Ld7/r;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Ld7/u;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Ld7/u;-><init>(Ld7/r;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ld7/t;->a(Ld7/a;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Ld7/t;->b()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public final r(Ld7/b;)V
    .locals 3
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "aasikchTq"

    const-string v0, "chainTask"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p0, p1}, Ld7/l;->z0(Ld7/r;Ld7/b;)V

    const/4 v1, 0x1

    and-int/2addr v2, v1

    return-void
.end method

.method public final s(Ld7/b;)V
    .locals 3
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, "aknaTcuis"

    const/4 v2, 0x5

    const-string v0, "chskanais"

    const-string v0, "chainTask"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1}, Ld7/l;->C0(Ld7/r;Ld7/b;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public final t(Ld7/b;)V
    .locals 3
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const-string/jumbo v0, "kapmanchT"

    const-string v0, "hanckiapT"

    const/4 v2, 0x2

    const-string/jumbo v0, "ihnToacak"

    const-string v0, "chainTask"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1}, Ld7/l;->E0(Ld7/r;Ld7/b;)V

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return-void
.end method

.method public final u(Ljava/util/Set;Ld7/b;)V
    .locals 3
    .param p1    # Ljava/util/Set;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ld7/b;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "psonrbeisiq"

    const-string/jumbo v0, "ireisnspqso"

    const/4 v2, 0x4

    const-string/jumbo v0, "isnosmueips"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const-string v0, "akcasnTph"

    const-string v0, "hcssTkaan"

    const/4 v2, 0x3

    const-string v0, "hcTnaiakq"

    const-string v0, "chainTask"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1, p2}, Ld7/l;->G0(Ld7/r;Ljava/util/Set;Ld7/b;)V

    const/4 v2, 0x7

    return-void
.end method

.method public final v(Ld7/b;)V
    .locals 3
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "asscmaThn"

    const-string v0, "cTaminsha"

    const-string/jumbo v0, "saimTcnah"

    const-string v0, "chainTask"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0, p0, p1}, Ld7/l;->I0(Ld7/r;Ld7/b;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public final w(Ld7/b;)V
    .locals 3
    .param p1    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "ahTsoocnk"

    const-string v0, "ahkTosicn"

    const/4 v2, 0x5

    const-string v0, "chainTask"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    invoke-direct {p0}, Ld7/r;->j()Ld7/l;

    move-result-object v0

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    invoke-virtual {v0, p0, p1}, Ld7/l;->K0(Ld7/r;Ld7/b;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public final x()V
    .locals 4

    const/4 v3, 0x3

    invoke-virtual {p0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, p0, Ld7/r;->e:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public final y(Landroidx/fragment/app/FragmentActivity;)V
    .locals 3
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string v0, "<b?seb>"

    const-string v0, "?s<t>be"

    const/4 v2, 0x2

    const-string v0, "<set-?>"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Ld7/r;->a:Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public final z(II)Ld7/r;
    .locals 2
    .annotation build Lia/d;
    .end annotation

    const/4 v0, 0x3

    move v1, v0

    iput p1, p0, Ld7/r;->c:I

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p2, p0, Ld7/r;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method
