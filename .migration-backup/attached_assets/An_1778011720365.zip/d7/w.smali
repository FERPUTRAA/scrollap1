.class public final Ld7/w;
.super Ld7/a;


# direct methods
.method public constructor <init>(Ld7/r;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "npsissmulsirdieBe"

    const-string/jumbo v0, "resBusimiisrdnple"

    const/4 v2, 0x6

    const-string/jumbo v0, "rrumeioiBsspmnlid"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v1, 0x0

    move v2, v1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Ld7/a;-><init>(Ld7/r;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 4
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ @ os   ~~omi r @~~@tl @ @ @c~Soi~K. dnva  ~~@@@@b@ ~f@ ft@@~- ~ib1~@bo~~M~~~@~/o~@y@l~o/~~o4 @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const-string/jumbo v0, "nmspobimeir"

    const-string/jumbo v0, "seomirinmsp"

    const/4 v3, 0x3

    const-string/jumbo v0, "pimoesusinr"

    const-string/jumbo v0, "permissions"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v1, Ljava/util/Collection;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    xor-int/lit8 p1, p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Ld7/a;->a:Ld7/r;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v0, p0}, Ld7/r;->u(Ljava/util/Set;Ld7/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Ld7/a;->finish()V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public request()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, v1, Ld7/r;->g:Ljava/util/Set;

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v3, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v3}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v3, v2}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    iget-object v3, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v3, v3, Ld7/r;->l:Ljava/util/Set;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v3, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-boolean v2, v1, Ld7/r;->i:Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, v1, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, v1, Ld7/r;->s:Lb7/b;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v2, :cond_5

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-boolean v2, v1, Ld7/r;->i:Z

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, v1, Ld7/r;->m:Ljava/util/Set;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, v1, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v2, v1, v0, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, v1, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v1, v2, v0}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, v1, Ld7/r;->g:Ljava/util/Set;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v0, p0}, Ld7/r;->u(Ljava/util/Set;Ld7/b;)V

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method
