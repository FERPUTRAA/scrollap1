.class public final Ld7/l;
.super Landroidx/fragment/app/Fragment;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInvisibleFragment.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InvisibleFragment.kt\ncom/permissionx/guolindev/request/InvisibleFragment\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,433:1\n37#2,2:434\n*S KotlinDebug\n*F\n+ 1 InvisibleFragment.kt\ncom/permissionx/guolindev/request/InvisibleFragment\n*L\n108#1:434,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/i0;
    d1 = {
        "\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000f\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\r\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u00086\u00107J\u001c\u0010\u0007\u001a\u00020\u00062\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00040\u0002H\u0002J\u0010\u0010\t\u001a\u00020\u00062\u0006\u0010\u0008\u001a\u00020\u0004H\u0002J\u0008\u0010\n\u001a\u00020\u0006H\u0002J\u0008\u0010\u000b\u001a\u00020\u0006H\u0002J\u0008\u0010\u000c\u001a\u00020\u0006H\u0002J\u0008\u0010\r\u001a\u00020\u0006H\u0002J\u0008\u0010\u000e\u001a\u00020\u0004H\u0002J$\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u000c\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u00112\u0006\u0010\u0014\u001a\u00020\u0013J\u0016\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u0013J\u0016\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u0013J\u0016\u0010\u0018\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u0013J\u0016\u0010\u0019\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u0013J\u0016\u0010\u001a\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u0013J\u0006\u0010\u001b\u001a\u00020\u0006J\u0008\u0010\u001c\u001a\u00020\u0006H\u0016R\u0016\u0010\u001f\u001a\u00020\u000f8\u0002@\u0002X\u0082.\u00a2\u0006\u0006\n\u0004\u0008\u001d\u0010\u001eR\u0016\u0010\"\u001a\u00020\u00138\u0002@\u0002X\u0082.\u00a2\u0006\u0006\n\u0004\u0008 \u0010!R@\u0010(\u001a.\u0012*\u0012(\u0012\u000c\u0012\n %*\u0004\u0018\u00010\u00030\u0003 %*\u0014\u0012\u000e\u0008\u0001\u0012\n %*\u0004\u0018\u00010\u00030\u0003\u0018\u00010$0$0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008&\u0010\'R\"\u0010*\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010\u00030\u00030#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008)\u0010\'R\"\u0010-\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010+0+0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008,\u0010\'R\"\u0010/\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010+0+0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008.\u0010\'R\"\u00101\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010+0+0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u00080\u0010\'R\"\u00103\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010+0+0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u00082\u0010\'R\"\u00105\u001a\u0010\u0012\u000c\u0012\n %*\u0004\u0018\u00010+0+0#8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u00084\u0010\'\u00a8\u00068"
    }
    d2 = {
        "Ld7/l;",
        "Landroidx/fragment/app/Fragment;",
        "",
        "",
        "",
        "grantResults",
        "Lkotlin/s2;",
        "t0",
        "granted",
        "o0",
        "v0",
        "x0",
        "r0",
        "q0",
        "j0",
        "Ld7/r;",
        "permissionBuilder",
        "",
        "permissions",
        "Ld7/b;",
        "chainTask",
        "G0",
        "z0",
        "I0",
        "K0",
        "E0",
        "C0",
        "l0",
        "onDestroy",
        "a",
        "Ld7/r;",
        "pb",
        "b",
        "Ld7/b;",
        "task",
        "Landroidx/activity/result/h;",
        "",
        "kotlin.jvm.PlatformType",
        "c",
        "Landroidx/activity/result/h;",
        "requestNormalPermissionLauncher",
        "d",
        "requestBackgroundLocationLauncher",
        "Landroid/content/Intent;",
        "e",
        "requestSystemAlertWindowLauncher",
        "f",
        "requestWriteSettingsLauncher",
        "g",
        "requestManageExternalStorageLauncher",
        "h",
        "requestInstallPackagesLauncher",
        "i",
        "forwardToSettingsLauncher",
        "<init>",
        "()V",
        "permissionx_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x5,
        0x1
    }
.end annotation


# instance fields
.field private a:Ld7/r;

.field private b:Ld7/b;

.field private final c:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final d:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final f:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final g:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final h:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final i:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/4 v3, 0x6

    move v4, v3

    new-instance v0, Ld/b$k;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0}, Ld/b$k;-><init>()V

    const/4 v3, 0x5

    move v4, v3

    new-instance v1, Ld7/e;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v1, p0}, Ld7/e;-><init>(Ld7/l;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v1, "lssle)tg u  tl}togeretrseRis/2yAv2tarnsur 0cui(F6Rssiut/"

    const-string/jumbo v1, "vss/gr 2lr/i2lAy eeel )uutReeRttsst0iacirso}Frnu gt6(tus"

    const-string/jumbo v1, "stumRu2eA}gRe sts(i/lrlcure rsttvr/st)i0F 2iuty 6alongne"

    const-string/jumbo v1, "registerForActivityResul\u2026esult(grantResults)\n    }"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v0, p0, Ld7/l;->c:Landroidx/activity/result/h;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Ld/b$l;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0}, Ld/b$l;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Ld7/f;

    const/4 v4, 0x7

    invoke-direct {v1, p0}, Ld7/f;-><init>(Ld7/l;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v1, "gtncoo/me0s R)eArFoaee2nit 6ir/(srt}uiltgsdtRuy svn eliu"

    const-string/jumbo v1, "ttnm  eno iovley0eg}Rgdcs2R6a(/tr tiAr)es/i2uuteFnrssuli"

    const/4 v4, 0x7

    const-string/jumbo v1, "seiaFbive/tAsgis(g R/}oter 2)2nnutcrlo6iurnRtdsylte er0u"

    const-string/jumbo v1, "registerForActivityResul\u2026sionResult(granted)\n    }"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object v0, p0, Ld7/l;->d:Landroidx/activity/result/h;

    const/4 v3, 0x6

    move v4, v3

    new-instance v0, Ld/b$m;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0}, Ld/b$m;-><init>()V

    const/4 v4, 0x7

    new-instance v1, Ld7/g;

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Ld7/g;-><init>(Ld7/l;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const-string v1, " c 2rnuss}rirsi2iiwRe0Ree )tAlyuun/ou/gtFm6 tPrseio(vtos"

    const-string/jumbo v1, "riPsoe/nste/sttl()wrstR0lucv2Fi}mu egu62riosniAR reo y i"

    const/4 v4, 0x5

    const-string v1, "/snrnerptsAi0uueisR}l Rosv/iw c uisePet rt6tF)l2ye(mrgoi"

    const-string/jumbo v1, "registerForActivityResul\u2026wPermissionResult()\n    }"

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object v0, p0, Ld7/l;->e:Landroidx/activity/result/h;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v0, Ld/b$m;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0}, Ld/b$m;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Ld7/h;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, p0}, Ld7/h;-><init>(Ld7/l;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "r6nsFur q2RiouPs)t//r2 RteygsiAntce e0osl}itl (esieismrv"

    const-string/jumbo v1, "registerForActivityResul\u2026sPermissionResult()\n    }"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Ld7/l;->f:Landroidx/activity/result/h;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Ld/b$m;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Ld/b$m;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v2, Ld7/i;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-direct {v2, p0}, Ld7/i;-><init>(Ld7/l;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v2}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "nisuRtlli)s} ett0rcer F/6e/2v gmebAseosor uuRstse(iPy2ri"

    const-string/jumbo v2, "rulieb2t e(roP/itrs et6iRrFAstev)mc0eo}eu n/sliRgisuy 2s"

    const-string v2, "i/ymterReculrisu}t2rR0uge6Fesn/PtsiiAomeo2e)n  rivl s (t"

    const-string/jumbo v2, "registerForActivityResul\u2026ePermissionResult()\n    }"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object v0, p0, Ld7/l;->g:Landroidx/activity/result/h;

    const/4 v4, 0x0

    new-instance v0, Ld/b$m;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ld/b$m;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v2, Ld7/j;

    const/4 v3, 0x1

    const/4 v3, 0x1

    invoke-direct {v2, p0}, Ld7/j;-><init>(Ld7/l;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0, v0, v2}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    iput-object v0, p0, Ld7/l;->h:Landroidx/activity/result/h;

    const/4 v4, 0x0

    const/4 v3, 0x7

    new-instance v0, Ld/b$m;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0}, Ld/b$m;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Ld7/k;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Ld7/k;-><init>(Ld7/l;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "iguroc)0uy ist/rine2eessFnmeliP rr/6ws vri)AsR raoo2ttdo"

    const-string/jumbo v1, "registerForActivityResul\u2026orwardPermissions))\n    }"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Ld7/l;->i:Landroidx/activity/result/h;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method private static final A0(Ld7/l;Ljava/lang/Boolean;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  @@ bSi/~m @v~~~u~o @~ Mon@~b~~4@y c K~~oo@~~1~ @@/@ba~~i~b@o if~@ ~f@@l~.trlod -@~ s@@t @@  ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-string/jumbo v0, "uis$hu"

    const-string/jumbo v0, "ut$hsi"

    const-string/jumbo v0, "ipts0$"

    const-string/jumbo v0, "this$0"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    const-string/jumbo v0, "rqedpgn"

    const-string/jumbo v0, "pangrde"

    const/4 v2, 0x4

    const-string v0, "granted"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Ld7/l;->o0(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method private static final B0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    const-string/jumbo p1, "shs0ti"

    const-string/jumbo p1, "isqh0t"

    const/4 v1, 0x5

    const-string p1, "0thms$"

    const-string/jumbo p1, "this$0"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ld7/l;->q0()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method private static final D0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string/jumbo p1, "ist0oh"

    const-string p1, "hisst0"

    const/4 v1, 0x3

    const-string p1, "hi0s$b"

    const-string/jumbo p1, "this$0"

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ld7/l;->r0()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method private static final F0(Ld7/l;Ljava/util/Map;)V
    .locals 3

    const/4 v2, 0x0

    const-string v0, "0t$mhs"

    const/4 v2, 0x3

    const-string/jumbo v0, "u0ihs$"

    const-string/jumbo v0, "this$0"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "atenrlgpuosR"

    const-string v0, "gusRoernltta"

    const/4 v2, 0x3

    const-string v0, "Rlgrstesquta"

    const-string v0, "grantResults"

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ld7/l;->t0(Ljava/util/Map;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method private static final H0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    const-string/jumbo p1, "this$0"

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ld7/l;->v0()V

    const/4 v1, 0x1

    return-void
.end method

.method private static final J0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    const-string/jumbo p1, "thssb$"

    const-string/jumbo p1, "t0$shb"

    const/4 v1, 0x4

    const-string p1, "i0hmst"

    const-string/jumbo p1, "this$0"

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ld7/l;->x0()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public static synthetic c0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x5

    invoke-static {p0, p1}, Ld7/l;->n0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public static synthetic d0(Ld7/l;Ljava/util/Map;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Ld7/l;->F0(Ld7/l;Ljava/util/Map;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic e0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1}, Ld7/l;->J0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public static synthetic f0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1}, Ld7/l;->H0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static synthetic g0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0, p1}, Ld7/l;->D0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static synthetic h0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0, p1}, Ld7/l;->B0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static synthetic i0(Ld7/l;Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Ld7/l;->A0(Ld7/l;Ljava/lang/Boolean;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private final j0()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    or-int/2addr v3, v2

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "XiiuosemnPs"

    const-string/jumbo v0, "mrseiiunXPs"

    const/4 v3, 0x0

    const-string v0, "PermissionX"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, " no,ubsTat asahn tehraepl a nueCoi istaneiB ldmlidhiluwh  g nisi n ntsb onsscionetr .koPd t cs ieoh"

    const-string v1, "d sh P pito olie i l. et htldiahognrcn adm u o sCdo ils rbt eTtuihusssnoiihsa,n Beiwsecannantenk an"

    const/4 v3, 0x6

    const-string v1, "ekislauaithgT    onw asn isnotmor   bn,uhdunn ui ol ise. a mdse aelcctldtettCshinBno snahdsiroie iP"

    const-string v1, "PermissionBuilder and ChainTask should not be null at this time, so we can do nothing in this case."

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0
.end method

.method private static final n0(Ld7/l;Landroidx/activity/result/ActivityResult;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string p1, "$pithq"

    const-string p1, "i0qht$"

    const/4 v3, 0x4

    const-string p1, "h$q0is"

    const-string/jumbo p1, "this$0"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Ld7/l;->b:Ld7/b;

    const/4 v3, 0x0

    const/4 v0, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo p1, "skat"

    const-string p1, "akts"

    const/4 v3, 0x6

    const-string/jumbo p1, "tsak"

    const-string/jumbo p1, "task"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p0, p0, Ld7/l;->a:Ld7/r;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez p0, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo p0, "pb"

    const-string p0, "bp"

    const/4 v3, 0x3

    const-string/jumbo p0, "pb"

    const-string/jumbo p0, "pb"

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p0, v0, Ld7/r;->p:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast p0, Ljava/util/Collection;

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p1, v1}, Ld7/b;->a(Ljava/util/List;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method private final o0(Z)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {p0}, Ld7/l;->j0()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    if-eqz v0, :cond_16

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v0, "task"

    const-string/jumbo v0, "task"

    const/4 v7, 0x5

    const-string/jumbo v0, "tsak"

    const-string/jumbo v0, "task"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v1, "OmsoKALOAdDEC_iTsreUoBRCi_sACNpCIsn.anGSSrNi."

    const-string/jumbo v1, "nOsArGnLICioB.Sa_dRCsUDeKTEp_ANSO.soONmrACiCi"

    const/4 v7, 0x6

    const-string/jumbo v1, "mCOmdseo.CAC_KrA_TSonisiCdnODEO.ARSBGrLpNINiU"

    const-string v1, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v2, "pb"

    const-string/jumbo v2, "pb"

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x7

    shr-int/2addr v6, v3

    if-eqz p1, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object p1, p1, Ld7/r;->l:Ljava/util/Set;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {p1, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x0

    if-nez p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object p1, p1, Ld7/r;->m:Ljava/util/Set;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {p1, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez p1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p1, p1, Ld7/r;->n:Ljava/util/Set;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {p1, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object p1, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez p1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v3}, Ld7/b;->finish()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto/16 :goto_3

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0, v1}, Landroidx/fragment/app/Fragment;->shouldShowRequestPermissionRationale(Ljava/lang/String;)Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x6

    const/4 v6, 0x5

    if-nez v4, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v4, v4, Ld7/r;->r:Lb7/a;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v4, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x5

    if-nez v4, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v4, v4, Ld7/r;->s:Lb7/b;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v4, :cond_e

    :cond_7
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz p1, :cond_e

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v1, :cond_8

    const/4 v7, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_8
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v1, v1, Ld7/r;->s:Lb7/b;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_b

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez v1, :cond_9

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_9
    const/4 v7, 0x5

    const/4 v6, 0x7

    iget-object v1, v1, Ld7/r;->s:Lb7/b;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v4, p0, Ld7/l;->b:Ld7/b;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez v4, :cond_a

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_a
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v4}, Ld7/b;->b()Ld7/c;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {v1, v4, p1, v5}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_b
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v1, :cond_c

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_c
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v1, v1, Ld7/r;->r:Lb7/a;

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v4, p0, Ld7/l;->b:Ld7/b;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-nez v4, :cond_d

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_d
    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-interface {v4}, Ld7/b;->b()Ld7/c;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v1, v4, p1}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_1

    :cond_e
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    if-nez v4, :cond_f

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_f
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v4, v4, Ld7/r;->t:Lb7/c;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v4, :cond_12

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-nez p1, :cond_12

    const/4 v7, 0x1

    new-instance p1, Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v1, :cond_10

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_10
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v1, v1, Ld7/r;->t:Lb7/c;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v4, p0, Ld7/l;->b:Ld7/b;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-nez v4, :cond_11

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :cond_11
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {v4}, Ld7/b;->c()Ld7/d;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v1, v4, p1}, Lb7/c;->a(Ld7/d;Ljava/util/List;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_1

    :cond_12
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v5, 0x1

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v5, :cond_14

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v7, 0x4

    if-nez p1, :cond_13

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :cond_13
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-boolean p1, p1, Ld7/r;->j:Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-nez p1, :cond_16

    :cond_14
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object p1, p0, Ld7/l;->b:Ld7/b;

    const/4 v7, 0x5

    if-nez p1, :cond_15

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v7, 0x5

    goto :goto_2

    :cond_15
    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {v3}, Ld7/b;->finish()V

    :cond_16
    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-void
.end method

.method private final q0()V
    .locals 7

    const/4 v6, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x4

    move v6, v5

    const/16 v1, 0x1a

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v2, "ktas"

    const-string v2, "askt"

    const/4 v6, 0x6

    const-string/jumbo v2, "ksat"

    const-string/jumbo v2, "task"

    const/4 v6, 0x0

    const/4 v3, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x2

    and-int/2addr v6, v5

    if-lt v0, v1, :cond_b

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/hjq/permissions/e;->a(Landroid/content/pm/PackageManager;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v3}, Ld7/b;->finish()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto/16 :goto_4

    :cond_1
    const/4 v6, 0x1

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v1, "bp"

    const-string v1, "bp"

    const/4 v6, 0x3

    const-string/jumbo v1, "pb"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez v0, :cond_3

    const/4 v5, 0x4

    const/4 v5, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_d

    :cond_4
    const/4 v6, 0x4

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v0, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v4, "Sns.oePIGLUENEaooA.mLKSdCr_idTQismrSpAE_nAR"

    const-string/jumbo v4, "rp_ms_L.RSoAiECnndKadGoTANsmQELSieESA.UiPIr"

    const/4 v6, 0x0

    const-string v4, "_NEdRb.pP_AATLUmESCeLraToonsSnESKrAQsiIiGi."

    const-string v4, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez v0, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v1, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x5

    goto :goto_1

    :cond_7
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v3}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v0, v1, v2, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_4

    :cond_8
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v0, :cond_9

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_9
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v1, :cond_a

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_2

    :cond_a
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v3}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v0, v1, v2}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_4

    :cond_b
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v0, :cond_c

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_3

    :cond_c
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_3
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v3}, Ld7/b;->finish()V

    :cond_d
    :goto_4
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method private final r0()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x3

    move v6, v5

    const/16 v1, 0x1e

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v2, "ktas"

    const-string/jumbo v2, "taks"

    const/4 v6, 0x5

    const-string/jumbo v2, "tsak"

    const-string/jumbo v2, "task"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-lt v0, v1, :cond_b

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v3}, Ld7/b;->finish()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto/16 :goto_4

    :cond_1
    const/4 v5, 0x5

    move v6, v5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v1, "pb"

    const-string v1, "bp"

    const/4 v6, 0x1

    const-string v1, "bp"

    const-string/jumbo v1, "pb"

    if-nez v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x3

    if-nez v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x6

    if-nez v0, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x1

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x2

    if-eqz v0, :cond_d

    :cond_4
    const/4 v5, 0x6

    move v6, v5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x7

    if-nez v0, :cond_5

    const/4 v6, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x3

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string/jumbo v4, "onrGoNEG_i_dA.AOdLArseESEsRE.iaNMnATToXiRp"

    const/4 v6, 0x6

    const-string v4, "NeEAsouirTETAA_piRidEnRaoLsN.O.SAGGdnXrEMm"

    const-string v4, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v0, :cond_8

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v0, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x4

    if-nez v1, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_1

    :cond_7
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-interface {v3}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0, v1, v2, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_4

    :cond_8
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v3

    move-object v0, v3

    :cond_9
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v1, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v1, :cond_a

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x4

    goto :goto_2

    :cond_a
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v3}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v0, v1, v2}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_4

    :cond_b
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez v0, :cond_c

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_3

    :cond_c
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v3}, Ld7/b;->finish()V

    :cond_d
    :goto_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void
.end method

.method private final t0(Ljava/util/Map;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const/4 v9, 0x5

    invoke-direct {p0}, Ld7/l;->j0()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v0, :cond_2f

    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const-string/jumbo v1, "pb"

    const-string v1, "bp"

    const-string/jumbo v1, "pb"

    const/4 v8, 0x6

    or-int/2addr v9, v8

    const/4 v2, 0x0

    xor-int/2addr v9, v2

    const/4 v8, 0x4

    move v9, v8

    if-nez v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v0, v0, Ld7/r;->l:Ljava/util/Set;

    const/4 v8, 0x4

    shr-int/2addr v9, v8

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    new-instance v3, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v4, :cond_9

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    check-cast v5, Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    check-cast v4, Ljava/lang/Boolean;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v4, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x5

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez v4, :cond_1

    const/4 v9, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v4, v4, Ld7/r;->l:Ljava/util/Set;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {v4, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x7

    move v9, v8

    if-nez v4, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v4, v4, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v4, v5}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x1

    move v9, v8

    if-nez v4, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v4, v4, Ld7/r;->n:Ljava/util/Set;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {v4, v5}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->shouldShowRequestPermissionRationale(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v4, :cond_6

    const/4 v8, 0x1

    move v9, v8

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-nez v4, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v4, v4, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {v4, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_6
    const/4 v9, 0x1

    const/4 v8, 0x0

    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x1

    const/4 v8, 0x3

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez v4, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_7
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v4, v4, Ld7/r;->n:Ljava/util/Set;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface {v4, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-nez v4, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_8
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v4, v4, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v4, v5}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x5

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_9
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v4, :cond_a

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_a
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v4, v4, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    check-cast v4, Ljava/util/Collection;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {p1, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x2

    if-nez v4, :cond_b

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_b
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v4, v4, Ld7/r;->n:Ljava/util/Set;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    check-cast v4, Ljava/util/Collection;

    invoke-interface {p1, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_c
    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x2

    if-eqz v4, :cond_f

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast v4, Ljava/lang/String;

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v5

    const/4 v9, 0x5

    invoke-static {v5, v4}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v5, :cond_c

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v5, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v5, :cond_d

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v5, v2

    move-object v5, v2

    :cond_d
    const/4 v9, 0x5

    const/4 v8, 0x0

    iget-object v5, v5, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v5, v4}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v8, 0x0

    shr-int/2addr v9, v8

    iget-object v5, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-nez v5, :cond_e

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    :cond_e
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v5, v5, Ld7/r;->l:Ljava/util/Set;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v5, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    goto :goto_1

    :cond_f
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez p1, :cond_10

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_10
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object p1, p1, Ld7/r;->l:Ljava/util/Set;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v4, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-nez v4, :cond_11

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_11
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v4, v4, Ld7/r;->g:Ljava/util/Set;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v6, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-ne p1, v4, :cond_12

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    move p1, v5

    move p1, v5

    const/4 v9, 0x6

    move p1, v5

    move p1, v5

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_2

    :cond_12
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    move p1, v6

    move p1, v6

    const/4 v9, 0x7

    move p1, v6

    move p1, v6

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v4, "askt"

    const-string/jumbo v4, "stak"

    const/4 v9, 0x5

    const-string/jumbo v4, "ktas"

    const-string/jumbo v4, "task"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz p1, :cond_14

    const/4 v9, 0x3

    const/4 v8, 0x5

    iget-object p1, p0, Ld7/l;->b:Ld7/b;

    const/4 v9, 0x0

    if-nez p1, :cond_13

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v4}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto :goto_3

    :cond_13
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_3
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v2}, Ld7/b;->finish()V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto/16 :goto_8

    :cond_14
    const/4 v9, 0x7

    const/4 v8, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez p1, :cond_15

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_15
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object p1, p1, Ld7/r;->r:Lb7/a;

    const/4 v8, 0x3

    or-int/2addr v9, v8

    if-nez p1, :cond_17

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez p1, :cond_16

    const/4 v9, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_16
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object p1, p1, Ld7/r;->s:Lb7/b;

    const/4 v9, 0x2

    if-eqz p1, :cond_21

    :cond_17
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    xor-int/2addr p1, v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz p1, :cond_21

    const/4 v9, 0x4

    const/4 v8, 0x7

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-nez p1, :cond_18

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_18
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object p1, p1, Ld7/r;->s:Lb7/b;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz p1, :cond_1c

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-nez p1, :cond_19

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_19
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object p1, p1, Ld7/r;->s:Lb7/b;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-nez v0, :cond_1a

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v4}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_1a
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {v0}, Ld7/b;->b()Ld7/c;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v5, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v7, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x3

    if-nez v7, :cond_1b

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    :cond_1b
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v7, v7, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    check-cast v7, Ljava/util/Collection;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x3

    invoke-interface {p1, v0, v5, v6}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    goto :goto_4

    :cond_1c
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez p1, :cond_1d

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_1d
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object p1, p1, Ld7/r;->r:Lb7/a;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez v0, :cond_1e

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v4}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_1e
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-interface {v0}, Ld7/b;->b()Ld7/c;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance v5, Ljava/util/ArrayList;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v7, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v7, :cond_1f

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v7, v2

    move-object v7, v2

    :cond_1f
    const/4 v9, 0x6

    const/4 v8, 0x5

    iget-object v7, v7, Ld7/r;->m:Ljava/util/Set;

    const/4 v9, 0x4

    const/4 v8, 0x6

    check-cast v7, Ljava/util/Collection;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {p1, v0, v5}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    :goto_4
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez p1, :cond_20

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_20
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object p1, p1, Ld7/r;->o:Ljava/util/Set;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {p1, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    :goto_5
    const/4 v8, 0x2

    move v5, v6

    move v5, v6

    const/4 v9, 0x3

    move v5, v6

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto/16 :goto_6

    :cond_21
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez p1, :cond_22

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_22
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object p1, p1, Ld7/r;->t:Lb7/c;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz p1, :cond_29

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    xor-int/2addr p1, v5

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez p1, :cond_24

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x5

    if-nez p1, :cond_23

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_23
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object p1, p1, Ld7/r;->o:Ljava/util/Set;

    const/4 v9, 0x1

    check-cast p1, Ljava/util/Collection;

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    xor-int/2addr p1, v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz p1, :cond_29

    :cond_24
    const/4 v8, 0x4

    move v9, v8

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v8, 0x1

    move v9, v8

    if-nez p1, :cond_25

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_25
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object p1, p1, Ld7/r;->o:Ljava/util/Set;

    const/4 v9, 0x7

    invoke-interface {p1}, Ljava/util/Set;->clear()V

    const/4 v9, 0x3

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez p1, :cond_26

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_26
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object p1, p1, Ld7/r;->t:Lb7/c;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {p1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez v0, :cond_27

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v4}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_27
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-interface {v0}, Ld7/b;->c()Ld7/d;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    new-instance v3, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v5, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-nez v5, :cond_28

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    :cond_28
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v5, v5, Ld7/r;->n:Ljava/util/Set;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    check-cast v5, Ljava/util/Collection;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {p1, v0, v3}, Lb7/c;->a(Ld7/d;Ljava/util/List;)V

    const/4 v8, 0x2

    move v9, v8

    goto/16 :goto_5

    :cond_29
    :goto_6
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-nez v5, :cond_2b

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-nez p1, :cond_2a

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_2a
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-boolean p1, p1, Ld7/r;->j:Z

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez p1, :cond_2d

    :cond_2b
    const/4 v9, 0x7

    const/4 v8, 0x4

    iget-object p1, p0, Ld7/l;->b:Ld7/b;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez p1, :cond_2c

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v4}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :cond_2c
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {p1}, Ld7/b;->finish()V

    :cond_2d
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-nez p1, :cond_2e

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_7

    :cond_2e
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_7
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    iput-boolean v6, v2, Ld7/r;->j:Z

    :cond_2f
    :goto_8
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    return-void
.end method

.method private final v0()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v1, "askt"

    const-string/jumbo v1, "stka"

    const/4 v6, 0x4

    const-string/jumbo v1, "task"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {v2}, Ld7/b;->finish()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto/16 :goto_3

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "bp"

    const/4 v6, 0x5

    const-string/jumbo v3, "pb"

    const-string/jumbo v3, "pb"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v0, :cond_b

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string/jumbo v4, "siSOi.LpDEipRAoMrT_NnnsES_WmTYdoIra.eW"

    const-string v4, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_8

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v3, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x2

    if-nez v3, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_1

    :cond_7
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-interface {v2}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x1

    invoke-interface {v0, v1, v2, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_3

    :cond_8
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x0

    if-nez v0, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_9
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v3, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v3, :cond_a

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x5

    goto :goto_2

    :cond_a
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {v2}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v0, v1, v2}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    :cond_b
    :goto_3
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-void
.end method

.method private final x0()V
    .locals 7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string/jumbo v1, "ksta"

    const-string/jumbo v1, "skat"

    const-string/jumbo v1, "task"

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v2}, Ld7/b;->finish()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto/16 :goto_3

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v3, "pb"

    const-string/jumbo v3, "pb"

    const/4 v6, 0x1

    const-string v3, "bp"

    const-string/jumbo v3, "pb"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x1

    if-nez v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_3

    const/4 v5, 0x2

    and-int/2addr v6, v5

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_b

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v0, :cond_5

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v4, "r_W.SiIiqSNnoiRmTGbaTpEosdrenTIE."

    const-string/jumbo v4, "iiG_EbsrmnWRoon.ad.pNidSETITeSTIr"

    const/4 v6, 0x6

    const-string v4, "STsomdnsTT.o_esWiR.drnGriipaSNIIE"

    const-string v4, "android.permission.WRITE_SETTINGS"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v0, :cond_8

    const/4 v6, 0x3

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x1

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x5

    if-nez v3, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_1

    :cond_7
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v2}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0, v1, v2, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_3

    :cond_8
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v6, 0x6

    if-nez v0, :cond_9

    const/4 v6, 0x1

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_9
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, v0, Ld7/r;->r:Lb7/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v3, p0, Ld7/l;->b:Ld7/b;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v3, :cond_a

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_2

    :cond_a
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v2}, Ld7/b;->b()Ld7/c;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v4}, Lkotlin/collections/u;->k(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v0, v1, v2}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    :cond_b
    :goto_3
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void
.end method


# virtual methods
.method public final C0(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "oudmieesrsmirBipn"

    const-string/jumbo v0, "riormsusipdleBine"

    const/4 v2, 0x7

    const-string v0, "Biinoirspslderoem"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string v0, "aknspbhac"

    const-string v0, "hsckaanpi"

    const/4 v2, 0x6

    const-string/jumbo v0, "nckaTiuha"

    const-string v0, "chainTask"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p2, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 p2, 0x1a

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-lt p1, p2, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string p2, "OUnsE.MpN_NAiKPAEeSNPstNGqAdo_diSUagOR_Wn.t"

    const-string/jumbo p2, "sU_PaCdOqtMnANRnAdENU.G_AESs_P.SONoKWiigetN"

    const/4 v2, 0x7

    const-string p2, ".r_NiU__qENtGPNNPU.MAdaESdRAoesKnSACtgnOsiW"

    const-string p2, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, ":espgcka"

    const-string/jumbo v0, "package:"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p2}, Lkotlin/jvm/internal/l0;->C(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p2, p0, Ld7/l;->h:Landroidx/activity/result/h;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v1, 0x3

    and-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ld7/l;->q0()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public final E0(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "orrmeissluesdiBin"

    const-string/jumbo v0, "rrsssoiuBmndlieie"

    const/4 v2, 0x2

    const-string/jumbo v0, "isrloeunomsrieipB"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "hinmcTsak"

    const-string v0, "iTnakbsac"

    const-string v0, "chainTask"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p2, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x6

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 p2, 0x1e

    const/4 v2, 0x1

    if-lt p1, p2, :cond_0

    const/4 v2, 0x1

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string p2, "_n.dLGu_Io_PNstF.SiCsaAIACLiS_MAEStAMrNESnOgEIeLdoS"

    const-string p2, "_G_MotAMLESnrSaeSdAAEFsOSg_ESNIdIsLLPIo._CAitECN.ni"

    const-string p2, "LCE_gEnpAMeSMsadSOEFI_AAPi_NStdAICsNS.rSL.tRGLIionE"

    const-string p2, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    move v2, v1

    iget-object p2, p0, Ld7/l;->g:Landroidx/activity/result/h;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2, p1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0}, Ld7/l;->r0()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public final G0(Ld7/r;Ljava/util/Set;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/util/Set;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld7/r;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ld7/b;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "morsenedqusiBbiip"

    const-string v0, "dsiBnbseiopreluim"

    const/4 v2, 0x0

    const-string/jumbo v0, "risdemupseilsoBin"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "opsmrusiesm"

    const-string v0, "erpismuioss"

    const-string v0, "empiossiron"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const-string v0, "aTpncbski"

    const-string/jumbo v0, "inhkcsapT"

    const/4 v2, 0x1

    const-string v0, "chainTask"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v2, 0x1

    iput-object p3, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Ld7/l;->c:Landroidx/activity/result/h;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p2, Ljava/util/Collection;

    const/4 v2, 0x7

    const/4 p3, 0x5

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-array p3, p3, [Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p2, p3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p2, "anlya u. rioyse<et>nqt-ta ulp  nolnbulkoolntn trnc c"

    const-string/jumbo p2, "lAtynnylq cnea.ll tou< -o  rnaapruc toesnotnn litkb>"

    const/4 v2, 0x0

    const-string/jumbo p2, "lunn> .pkt slnrtlt a t ycra<nynlceul AonanTo bo-tipe"

    const-string/jumbo p2, "null cannot be cast to non-null type kotlin.Array<T>"

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public final I0(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "ilBnrpseqsrsieoim"

    const-string/jumbo v0, "nrsileidoimpssBer"

    const/4 v2, 0x1

    const-string/jumbo v0, "udsmsBreiiielsrpn"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const-string v0, "akTmnhmis"

    const-string/jumbo v0, "nkTmihasc"

    const/4 v2, 0x4

    const-string v0, "aicnosTha"

    const-string v0, "chainTask"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p2, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p1, Landroid/content/Intent;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const-string p2, "MgtAIbASiGtnIiSLNMdsoRaNVRsaEiOEYen.d_ErA.oPt.c_O"

    const-string p2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "kacpoag:"

    const/4 v2, 0x7

    const-string/jumbo v0, "kap:cgua"

    const-string/jumbo v0, "package:"

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {v0, p2}, Lkotlin/jvm/internal/l0;->C(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p2, p0, Ld7/l;->e:Landroidx/activity/result/h;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Ld7/l;->v0()V

    :goto_0
    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public final K0(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "nesiroepmbrdiusBi"

    const-string/jumbo v0, "nrsmsbeBuiidilreo"

    const/4 v2, 0x6

    const-string/jumbo v0, "spiiieolqrrmBeund"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "ncsahTusi"

    const-string v0, "cinaTauhs"

    const-string v0, "chainTask"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p2, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string p2, "Gg_mtWdn.RMaipcSnSi.EEiNrTTt_.otssaeIGAIAdTon"

    const-string p2, "NaMno.sptsGiT_iTWAESSeRId.nrAIE_iotd.nGEgcTat"

    const/4 v2, 0x2

    const-string p2, "GoTAoR.aGMo.iItdi.rSAEa__SNcENtiedtTgsnnsITnE"

    const-string p2, "android.settings.action.MANAGE_WRITE_SETTINGS"

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "gqa:ebck"

    const-string/jumbo v0, "qekca:ga"

    const-string v0, "c:gaeauk"

    const-string/jumbo v0, "package:"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p2}, Lkotlin/jvm/internal/l0;->C(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p2, p0, Ld7/l;->f:Landroidx/activity/result/h;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Ld7/l;->x0()V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public final l0()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v1, "Pssr.tLpaSNeATIoOTLPIdSTDtAnNI.g_TEiSAiCGd_Es"

    const-string v1, "L_sGorPIsA_detPNiOATtnADSSIEITdCsNS.La.TTgEni"

    const/4 v5, 0x5

    const-string v1, ".rgLSTSiqAOEtENSNGTPIIDiToA.ddnTPAnLs__sICatI"

    const-string v1, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const-string v3, "agskpec"

    const-string v3, "akgmcpe"

    const-string/jumbo v3, "pacmaek"

    const-string/jumbo v3, "package"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v3, v1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Ld7/l;->i:Landroidx/activity/result/h;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method public onDestroy()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroy()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Ld7/l;->j0()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Ld7/l;->a:Ld7/r;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "pb"

    const-string v0, "bp"

    const/4 v3, 0x0

    const-string/jumbo v0, "pb"

    const-string/jumbo v0, "pb"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v0, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, v0, Ld7/r;->f:Landroid/app/Dialog;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_2
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public final z0(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo v0, "pimloeeiuroinodsr"

    const-string/jumbo v0, "nosBomeupilriider"

    const/4 v2, 0x0

    const-string/jumbo v0, "iieirbBsdslnoupem"

    const-string/jumbo v0, "permissionBuilder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "kiahcTubs"

    const-string/jumbo v0, "shnaibkcT"

    const/4 v2, 0x2

    const-string v0, "aichakspn"

    const-string v0, "chainTask"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Ld7/l;->a:Ld7/r;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    iput-object p2, p0, Ld7/l;->b:Ld7/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p1, p0, Ld7/l;->d:Landroidx/activity/result/h;

    const/4 v2, 0x6

    const-string/jumbo p2, "ooEC.NArqiisDAdCCOSriLKsepSmONId_Un.OGBC_naAT"

    const-string p2, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method
