.class public final Ld7/x;
.super Ld7/a;


# direct methods
.method public constructor <init>(Ld7/r;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "dssuenrrspmileoBs"

    const-string v0, "edssumionrBiprlse"

    const/4 v2, 0x0

    const-string/jumbo v0, "lnrmmesiBduoireip"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ld7/a;-><init>(Ld7/r;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "K b o@o~~~4 ~ ~mob .~@i@@l f~/~~ @@v M@a~ ~~@~~l c@-o i~@ ~o1r@@ @~o@f~~@  @@bo/  y~@isdS~t@@tn~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-string/jumbo v0, "rmponbisism"

    const-string/jumbo v0, "irsmsnsoimp"

    const/4 v2, 0x0

    const-string/jumbo v0, "ssrpiousnie"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1, p0}, Ld7/r;->v(Ld7/b;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public request()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Ld7/r;->D()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v0, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ld7/r;->k()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v1, 0x17

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "nTWrDOipRToioIpEmnWSaoNE.eAS_r._ddsLiM"

    const-string v2, "REnToITa_oN.dSipsdirWOo.SYADminrLMeEW_"

    const/4 v5, 0x5

    const-string/jumbo v2, "oNs_SEeAqmdnnOrMYisSEDIa..ipTdRiorW_WT"

    const-string v2, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-lt v0, v1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, v0, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0}, Lkotlin/collections/u;->P([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v4, 0x7

    const/4 v4, 0x7

    iget-object v2, v1, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v2, v1, v0, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x2

    iget-object v1, v1, Ld7/r;->r:Lb7/a;

    const/4 v4, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x0

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1, v2, v0}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x7

    iget-object v0, v0, Ld7/r;->l:Ljava/util/Set;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, v0, Ld7/r;->h:Ljava/util/Set;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Ld7/a;->finish()V

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method
