.class public final synthetic Ld7/e;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Ld7/l;


# direct methods
.method public synthetic constructor <init>(Ld7/l;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Ld7/e;->a:Ld7/l;

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ys l/Kf ~lb@/b~~~@~i~@~m.~ @~o  ~@ @i~~So @~-~ob@@i@ tu~o@s v@ @@@~1~o~ a@r@  o~t@ M d@n ~~4~ f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Ld7/e;->a:Ld7/l;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p1, Ljava/util/Map;

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0, p1}, Ld7/l;->d0(Ld7/l;Ljava/util/Map;)V

    const/4 v1, 0x0

    move v2, v1

    return-void
.end method
