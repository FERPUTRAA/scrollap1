.class public final synthetic Ld7/h;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Ld7/l;


# direct methods
.method public synthetic constructor <init>(Ld7/l;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Ld7/h;->a:Ld7/l;

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~so~~lmb~@-@@~M~ ~S@oc @~~~r4@ulo@~@@~o/@i ~~  @@@~ ~~@so1  b  yfv @@/o @n @@ ib i~~at @~d.~ Kt"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Ld7/h;->a:Ld7/l;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p1, Landroidx/activity/result/ActivityResult;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-static {v0, p1}, Ld7/l;->e0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v2, 0x1

    return-void
.end method
