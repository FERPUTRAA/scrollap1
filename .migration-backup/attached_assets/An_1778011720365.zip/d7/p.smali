.class public final synthetic Ld7/p;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/permissionx/guolindev/dialog/c;

.field public final synthetic b:Ld7/b;


# direct methods
.method public synthetic constructor <init>(Lcom/permissionx/guolindev/dialog/c;Ld7/b;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Ld7/p;->a:Lcom/permissionx/guolindev/dialog/c;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p2, p0, Ld7/p;->b:Ld7/b;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4@s ~oo~bMS~~@dt/@b /@fv~@~  @mK~la~ yfni~ lo@~i~ s@ @@~@b@ ct ~~~~~i~@@@1ou -~ r@ .~@o ~@@ o@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Ld7/p;->a:Lcom/permissionx/guolindev/dialog/c;

    const/4 v3, 0x3

    const/4 v2, 0x5

    iget-object v1, p0, Ld7/p;->b:Ld7/b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, v1, p1}, Ld7/r;->a(Lcom/permissionx/guolindev/dialog/c;Ld7/b;Landroid/view/View;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method
