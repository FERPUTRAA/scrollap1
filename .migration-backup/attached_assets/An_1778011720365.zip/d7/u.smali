.class public final Ld7/u;
.super Ld7/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld7/u$a;
    }
.end annotation


# static fields
.field public static final e:Ld7/u$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final f:Ljava/lang/String; = "android.permission.REQUEST_INSTALL_PACKAGES"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ld7/u$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ld7/u$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x3

    sput-object v0, Ld7/u;->e:Ld7/u$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>(Ld7/r;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "iisromdslenirseBs"

    const-string v0, "Bssriosilnieedpmr"

    const/4 v2, 0x4

    const-string/jumbo v0, "ielmsderprsoimBin"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Ld7/a;-><init>(Ld7/r;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~t ov@bi@~o@ @~@ i~1 @f~ m~ @ o@ @~~sla~@o/~4-ro@/~@c  i~l@  ~o ~@ub@ K~~@~f~  @o~t@~ d.~@bMSn@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-string/jumbo v0, "ommsrbissip"

    const-string/jumbo v0, "mprmoisises"

    const/4 v2, 0x1

    const-string/jumbo v0, "opminiusrse"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object p1, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1, p0}, Ld7/r;->s(Ld7/b;)V

    return-void
.end method

.method public request()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Ld7/r;->B()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/16 v1, 0x1a

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-lt v0, v1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ld7/r;->k()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-lt v0, v1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/hjq/permissions/e;->a(Landroid/content/pm/PackageManager;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, v0, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v0, "CpaeRropGAiEK.NA_nLrPTiSQ.TmAdLd_SsoIoESEUn"

    const-string v0, "G.SUooA.sKAINLSPsEEdCEndRrpmeLSaQio_nTT_irA"

    const/4 v5, 0x4

    const-string v0, "i.rGETRnqACaESdLd._STisi_IAnUEePALsKSroopNQ"

    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0}, Lkotlin/collections/u;->P([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, v1, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v2, v1, v0, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, v1, Ld7/r;->r:Lb7/a;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v1, v2, v0}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Ld7/a;->finish()V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method
