.class public interface abstract Ld7/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract b()Ld7/c;
.end method

.method public abstract c()Ld7/d;
.end method

.method public abstract finish()V
.end method

.method public abstract request()V
.end method
