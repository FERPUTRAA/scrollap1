.class public final synthetic Ld7/o;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lcom/permissionx/guolindev/dialog/c;

.field public final synthetic b:Z

.field public final synthetic c:Ld7/b;

.field public final synthetic d:Ljava/util/List;

.field public final synthetic e:Ld7/r;


# direct methods
.method public synthetic constructor <init>(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Ld7/o;->a:Lcom/permissionx/guolindev/dialog/c;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p2, p0, Ld7/o;->b:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p3, p0, Ld7/o;->c:Ld7/b;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p4, p0, Ld7/o;->d:Ljava/util/List;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p5, p0, Ld7/o;->e:Ld7/r;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "iis~/@~~@s~~Kdbc~   ~/@@-no  @r~~~ ~l@1oM.S~4l@@v@ o~ y~@f  @@i@@b@~   ~~t o ~@oftm @@@ a~@u~b~o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    iget-object v0, p0, Ld7/o;->a:Lcom/permissionx/guolindev/dialog/c;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-boolean v1, p0, Ld7/o;->b:Z

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Ld7/o;->c:Ld7/b;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v3, p0, Ld7/o;->d:Ljava/util/List;

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget-object v4, p0, Ld7/o;->e:Ld7/r;

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Ld7/r;->e(Lcom/permissionx/guolindev/dialog/c;ZLd7/b;Ljava/util/List;Ld7/r;Landroid/view/View;)V

    const/4 v7, 0x5

    return-void
.end method
