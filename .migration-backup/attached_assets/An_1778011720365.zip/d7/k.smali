.class public final synthetic Ld7/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Ld7/l;


# direct methods
.method public synthetic constructor <init>(Ld7/l;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Ld7/k;->a:Ld7/l;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cis@s ~ b~ @n@@oK~o o f~~~@@ /~of~b~-S1m@l @~~ 4o@~ @@~bdM~@@a~ @v@u@yl t@@@ /~~.o  ir  ~@i~~ ~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Ld7/k;->a:Ld7/l;

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Landroidx/activity/result/ActivityResult;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p1}, Ld7/l;->c0(Ld7/l;Landroidx/activity/result/ActivityResult;)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method
