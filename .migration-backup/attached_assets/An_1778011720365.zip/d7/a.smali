.class public abstract Ld7/a;
.super Ljava/lang/Object;

# interfaces
.implements Ld7/b;


# instance fields
.field public a:Ld7/r;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public b:Ld7/b;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private c:Ld7/c;
    .annotation build Lia/d;
    .end annotation
.end field

.field private d:Ld7/d;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ld7/r;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const-string/jumbo v0, "pb"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Ld7/a;->a:Ld7/r;

    const/4 v1, 0x2

    move v2, v1

    new-instance v0, Ld7/c;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0, p1, p0}, Ld7/c;-><init>(Ld7/r;Ld7/b;)V

    const/4 v1, 0x4

    move v2, v1

    iput-object v0, p0, Ld7/a;->c:Ld7/c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Ld7/d;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, v0, p0}, Ld7/d;-><init>(Ld7/r;Ld7/b;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Ld7/a;->d:Ld7/d;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Ld7/c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1, v0, p0}, Ld7/c;-><init>(Ld7/r;Ld7/b;)V

    const/4 v2, 0x3

    iput-object p1, p0, Ld7/a;->c:Ld7/c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p1, Ld7/d;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1, v0, p0}, Ld7/d;-><init>(Ld7/r;Ld7/b;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Ld7/a;->d:Ld7/d;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public b()Ld7/c;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "a-s@~@~oo4/   t@n~~~@biMy~@~@ v1Kts  m~~l~@~o @ib @~S.ocf@l~r@~~@ ~b  ~@/~@~fu@@@  ~@~  oi @d~@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Ld7/a;->c:Ld7/c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public c()Ld7/d;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Ld7/a;->d:Ld7/d;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public finish()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Ld7/a;->b:Ld7/b;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0}, Ld7/b;->request()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_d

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, v1, Ld7/r;->m:Ljava/util/Set;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v1, Ljava/util/Collection;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, v1, Ld7/r;->n:Ljava/util/Set;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v1, Ljava/util/Collection;

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, v1, Ld7/r;->k:Ljava/util/Set;

    const/4 v6, 0x5

    check-cast v1, Ljava/util/Collection;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v6, 0x1

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1}, Ld7/r;->A()Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "IsAmNdA..eiKnpSRNsaCiOodCor_rGOnsLSCDOAm_CEUB"

    const-string v2, "EGspNoDOKNoimr.UnCAdsr_CesLAROi.CCIABidaS_SOn"

    const/4 v6, 0x1

    const-string v2, "iGBaoDrdSOC.nToiipsCSNERUNmdC.KeoA_LAsCA_rIOO"

    const-string v2, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v2}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    :goto_1
    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Ld7/r;->D()Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/16 v2, 0x17

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1}, Ld7/r;->k()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-lt v1, v2, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v1}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v3, "oraLYbnsoi_.ITTS_mEEensdiWOiMpmSW.DrdR"

    const-string v3, "T.dmYia_eELWpI.OnnAorrosmMsSERiiTSD_Wd"

    const-string/jumbo v3, "inpWM.ueRiTSrOamTDWiE_LAISdNorso._nEsY"

    const-string v3, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v1, :cond_3

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v1, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_2

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Ld7/r;->E()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Ld7/r;->k()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-lt v1, v2, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v1}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v2, "IpdI.Tnp.ENmTa_EisoRiTdWnrsiSoGSe"

    const-string v2, "airsodiEidmRrIpTGSn._eEIWNTS.Tson"

    const/4 v6, 0x6

    const-string v2, "android.permission.WRITE_SETTINGS"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_3

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    :goto_3
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x7

    invoke-virtual {v1}, Ld7/r;->C()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/16 v2, 0x1e

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v3, "mdisooapqsNnASb.eGTX_rd.AEGERrTLERnANMEAO_"

    const-string v3, "AnNnGbrAATrpGXRA.RoEdd_EeMSimsETaioEOL._sN"

    const/4 v6, 0x4

    const-string v3, ".nsOeiAsNTnGdAdEiRiX_EorpLMTSA_sEmRENaGro."

    const-string v3, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v6, 0x2

    if-lt v1, v2, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v1, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_4

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    :goto_4
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1}, Ld7/r;->B()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_b

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/16 v2, 0x1a

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "nromLQKp.mdLUTsANoCEP_sSR.AArEiea_iETduGiIS"

    const-string v3, "QGiESduPrIsCApoSLTn_AmSLNEoAdEsiR.Te_.KUari"

    const/4 v6, 0x2

    const-string/jumbo v3, "sNAAoIQip.odanEURLiSmLAPoseiKdGST_n_SErCrTE"

    const-string v3, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-lt v1, v2, :cond_a

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Ld7/r;->k()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    if-lt v1, v2, :cond_a

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/hjq/permissions/e;->a(Landroid/content/pm/PackageManager;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v1, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, v1, Ld7/r;->l:Ljava/util/Set;

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_5

    :cond_9
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_5

    :cond_a
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_b
    :goto_5
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, v1, Ld7/r;->q:Lb7/d;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v1, :cond_c

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v3, Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v4, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v4, v4, Ld7/r;->l:Ljava/util/Set;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v4, Ljava/util/Collection;

    const/4 v6, 0x6

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3, v0}, Lb7/d;->a(ZLjava/util/List;Ljava/util/List;)V

    :cond_c
    const/4 v6, 0x0

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Ld7/r;->p()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ld7/r;->x()V

    :cond_d
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method
