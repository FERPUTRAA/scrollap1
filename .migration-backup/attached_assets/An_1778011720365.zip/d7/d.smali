.class public final Ld7/d;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ld7/r;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:Ld7/b;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ld7/r;Ld7/b;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ld7/b;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "pb"

    const-string/jumbo v0, "pb"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const-string v0, "Tishascas"

    const-string v0, "casakhisT"

    const/4 v2, 0x6

    const-string v0, "acsmhkTna"

    const-string v0, "chainTask"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    iput-object p1, p0, Ld7/d;->a:Ld7/r;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p2, p0, Ld7/d;->b:Ld7/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static synthetic e(Ld7/d;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~@ ol@o b@s4cy uof~@~a @i~/@~@ o@ @b~~ @@@~~o@ v.o~i ~~   l@~-S ri/ @bdmo@KfM~~~ ~~@ 1~@@n~t @t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    and-int/lit8 p5, p5, 0x8

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-eqz p5, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p4, 0x0

    :cond_0
    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Ld7/d;->d(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a(Lcom/permissionx/guolindev/dialog/c;)V
    .locals 5
    .param p1    # Lcom/permissionx/guolindev/dialog/c;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, "gamilb"

    const-string/jumbo v0, "lagmdi"

    const-string/jumbo v0, "ulgdio"

    const-string v0, "dialog"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    iget-object v0, p0, Ld7/d;->a:Ld7/r;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Ld7/d;->b:Ld7/b;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2, p1}, Ld7/r;->F(Ld7/b;ZLcom/permissionx/guolindev/dialog/c;)V

    const/4 v4, 0x4

    return-void
.end method

.method public final b(Lcom/permissionx/guolindev/dialog/d;)V
    .locals 5
    .param p1    # Lcom/permissionx/guolindev/dialog/d;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, "ardilompogaenF"

    const-string v0, "golgodranaFmei"

    const-string/jumbo v0, "mtarngilqagdFe"

    const-string v0, "dialogFragment"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Ld7/d;->a:Ld7/r;

    const/4 v4, 0x5

    iget-object v1, p0, Ld7/d;->b:Ld7/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2, p1}, Ld7/r;->G(Ld7/b;ZLcom/permissionx/guolindev/dialog/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public final c(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string/jumbo v0, "sisrsbpnmos"

    const-string/jumbo v0, "spesmbonisr"

    const/4 v9, 0x3

    const-string/jumbo v0, "srimimsnsep"

    const-string/jumbo v0, "permissions"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo v0, "saueogm"

    const-string v0, "easmsgu"

    const/4 v9, 0x0

    const-string/jumbo v0, "message"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string/jumbo v0, "peexsbtviipo"

    const-string/jumbo v0, "xotspevpitei"

    const/4 v9, 0x5

    const-string/jumbo v0, "oteepTutiisx"

    const-string/jumbo v0, "positiveText"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v5, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/16 v6, 0x8

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v7, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static/range {v1 .. v7}, Ld7/d;->e(Ld7/d;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-void
.end method

.method public final d(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo v0, "repsiospqsn"

    const-string/jumbo v0, "ieirsnopqss"

    const/4 v9, 0x0

    const-string/jumbo v0, "sonseprsqim"

    const-string/jumbo v0, "permissions"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v0, "eesasmg"

    const-string/jumbo v0, "sasegme"

    const/4 v9, 0x1

    const-string v0, "eegmsam"

    const-string/jumbo v0, "message"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v0, "iepioesTtxmt"

    const-string/jumbo v0, "xtTmoiipetes"

    const/4 v9, 0x4

    const-string v0, "Tioeebtvisxt"

    const-string/jumbo v0, "positiveText"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v1, p0, Ld7/d;->a:Ld7/r;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v2, p0, Ld7/d;->b:Ld7/b;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v3, 0x0

    move v9, v3

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual/range {v1 .. v7}, Ld7/r;->H(Ld7/b;ZLjava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    return-void
.end method
