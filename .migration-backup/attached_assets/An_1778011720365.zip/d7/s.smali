.class public final Ld7/s;
.super Ld7/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld7/s$a;
    }
.end annotation


# static fields
.field public static final e:Ld7/s$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final f:Ljava/lang/String; = "android.permission.ACCESS_BACKGROUND_LOCATION"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    new-instance v0, Ld7/s$a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ld7/s$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x5

    sput-object v0, Ld7/s;->e:Ld7/s$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Ld7/r;)V
    .locals 3
    .param p1    # Ld7/r;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const-string/jumbo v0, "misilpurniBssredo"

    const-string/jumbo v0, "permissionBuilder"

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Ld7/a;-><init>(Ld7/r;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " mom@ft@Ki @@n@~ @~~ @b ol ~~@o~~@@i ~@@ @r@~y l s@ ~~~~@@t~~b~cd ao~ -@. 4~u ~ o/~~fvbM @@i1~S/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string v0, "eissoopimsr"

    const-string/jumbo v0, "isssoprisem"

    const-string/jumbo v0, "ieoribnsssp"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    iget-object p1, p0, Ld7/a;->a:Ld7/r;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, p0}, Ld7/r;->r(Ld7/b;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public request()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ld7/r;->A()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x4

    const/16 v1, 0x1d

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v2, "OiOm.C_CeEdIOLpoo_BdNAnAiRUCG.DmSiASrCNsaKTsr"

    const/4 v5, 0x2

    const-string v2, "Up_irdu_ONaDBCRosnesCmInOOEdKSrCSA.TL.CiAAiNo"

    const-string v2, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v0, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, v0, Ld7/r;->h:Ljava/util/Set;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, v0, Ld7/r;->k:Ljava/util/Set;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v2}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "sdCIoTCpEe.L.oEAsOniSA_amnir_pOoiINCFNr"

    const-string v1, "Fr.AoesNsdOmniSinOE.oCI_odrTCC_EiIAapLN"

    const/4 v5, 0x6

    const-string v1, "NTdSisFiqoiN..aL_nCmESpIE_rdAsenCCoIrOA"

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v1}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1}, Ld7/r;->h()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const-string v3, "aCssAd_mAdONE_SieisICSni.pSLOR.ConoEACrOb"

    const-string v3, "Od_nCbEIAOSCN_RdiLsAeoOCSSrEiapisTC.n.oAm"

    const/4 v5, 0x3

    const-string v3, "Sram_CRCOroAdTd._ANsO.sOeLniCCmEIEiAoSSpn"

    const-string v3, "android.permission.ACCESS_COARSE_LOCATION"

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1, v3}, La7/c;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_6

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, v0, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v1, :cond_4

    iget-object v0, v0, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v5, 0x3

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Ld7/s;->a(Ljava/util/List;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v5, 0x6

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Lkotlin/collections/u;->P([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Ld7/a;->a:Ld7/r;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, v1, Ld7/r;->s:Lb7/b;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v2, v1, v0, v3}, Lb7/b;->a(Ld7/c;Ljava/util/List;Z)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, v1, Ld7/r;->r:Lb7/a;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Ld7/a;->b()Ld7/c;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v1, v2, v0}, Lb7/a;->a(Ld7/c;Ljava/util/List;)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void

    :cond_6
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Ld7/a;->finish()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method
