.class public final synthetic Ld7/f;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Ld7/l;


# direct methods
.method public synthetic constructor <init>(Ld7/l;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object p1, p0, Ld7/f;->a:Ld7/l;

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~@~ ~/o  bob@o~v @@m~st~aKuo/i~@S ~@~r-c~d~l l~ ~~~@@ n@@fot@@1 ~~i @   i. oM~  @@@y@~b@@~~~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Ld7/f;->a:Ld7/l;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p1}, Ld7/l;->i0(Ld7/l;Ljava/lang/Boolean;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method
