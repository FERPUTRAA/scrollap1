.class public interface abstract Ls6/h;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end method
