.class public interface abstract Ls6/u;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a([Ljava/lang/String;Z)V
.end method
