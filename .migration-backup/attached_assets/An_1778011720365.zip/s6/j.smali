.class public interface abstract Ls6/j;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;[Ljava/lang/String;)V
.end method

.method public abstract b(Landroidx/fragment/app/Fragment;)V
.end method
