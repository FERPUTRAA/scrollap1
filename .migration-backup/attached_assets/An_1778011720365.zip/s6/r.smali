.class public interface abstract Ls6/r;
.super Ljava/lang/Object;


# virtual methods
.method public abstract A()V
.end method
