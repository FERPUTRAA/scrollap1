.class public interface abstract Ls6/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(ILcom/luck/picture/lib/entity/LocalMediaFolder;)V
.end method
