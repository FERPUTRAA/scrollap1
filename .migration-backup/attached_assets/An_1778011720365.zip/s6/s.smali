.class public interface abstract Ls6/s;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)V
.end method

.method public abstract b(II)V
.end method
