.class public interface abstract Ls6/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;I)I
.end method
