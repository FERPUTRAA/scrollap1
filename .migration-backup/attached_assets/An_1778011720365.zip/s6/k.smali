.class public interface abstract Ls6/k;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Ls6/u;)V
.end method

.method public abstract b(Landroidx/fragment/app/Fragment;[Ljava/lang/String;)Z
.end method
