.class public interface abstract Ls6/i;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;[Ljava/lang/String;ILs6/c;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/fragment/app/Fragment;",
            "[",
            "Ljava/lang/String;",
            "I",
            "Ls6/c<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation
.end method
