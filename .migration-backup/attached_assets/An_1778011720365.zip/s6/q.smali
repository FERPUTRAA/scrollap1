.class public interface abstract Ls6/q;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;I)V
.end method
