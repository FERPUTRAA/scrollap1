.class public interface abstract Ls6/w;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/luck/picture/lib/entity/LocalMedia;)Z
.end method
