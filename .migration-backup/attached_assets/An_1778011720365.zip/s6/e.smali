.class public interface abstract Ls6/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/luck/picture/lib/entity/LocalMedia;)Z
.end method

.method public abstract b(I)V
.end method
