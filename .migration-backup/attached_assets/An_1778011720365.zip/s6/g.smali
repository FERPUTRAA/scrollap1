.class public interface abstract Ls6/g;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/View;I)V
.end method
