.class public interface abstract Ls6/x;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;I)Z
.end method
