.class public interface abstract Ls6/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroidx/fragment/app/Fragment;II)V
.end method
