.class public interface abstract Lb7/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ld7/c;Ljava/util/List;Z)V
    .param p1    # Ld7/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld7/c;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation
.end method
