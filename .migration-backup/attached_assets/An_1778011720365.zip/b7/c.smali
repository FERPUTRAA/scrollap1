.class public interface abstract Lb7/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ld7/d;Ljava/util/List;)V
    .param p1    # Ld7/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld7/d;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation
.end method
