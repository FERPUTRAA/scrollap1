.class public Ln6/a;
.super Ljava/lang/Object;

# interfaces
.implements Lokhttp3/Interceptor;


# instance fields
.field private final a:Lcom/localebro/okhttpprofiler/transfer/a;

.field private final b:Ljava/text/DateFormat;

.field private final c:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lcom/localebro/okhttpprofiler/transfer/b;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Lcom/localebro/okhttpprofiler/transfer/b;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v0, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "SdsShSshdsm"

    const-string v1, "ddhhmmssSSS"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Ln6/a;->b:Ljava/text/DateFormat;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v0, p0, Ln6/a;->c:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method private declared-synchronized a()Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@om @@ o fd@o@~~@i~K ~~@iiy~m~~@o c~u~@~ @b  @r~~ ~  ~~a ~1@f~@btl-o4@@b o~l/ ~@@@ v~S s.@M/t ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Ln6/a;->b:Ljava/text/DateFormat;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v1, Ljava/util/Date;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Ln6/a;->c:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    cmp-long v4, v0, v2

    const/4 v6, 0x3

    if-gtz v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    add-long/2addr v0, v2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v2, p0, Ln6/a;->c:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/16 v2, 0x24

    const/4 v5, 0x7

    move v6, v5

    invoke-static {v0, v1, v2}, Ljava/lang/Long;->toString(JI)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    monitor-exit p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    monitor-exit p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    throw v0
.end method


# virtual methods
.method public intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {p0}, Ln6/a;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v3, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Request;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v3, v0, v4}, Lcom/localebro/okhttpprofiler/transfer/a;->d(Ljava/lang/String;Lokhttp3/Request;)V

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Request;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {p1, v3}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Request;)Lokhttp3/Response;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    iget-object v3, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v3, v0, p1}, Lcom/localebro/okhttpprofiler/transfer/a;->a(Ljava/lang/String;Lokhttp3/Response;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v3, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    sub-long/2addr v4, v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v3, v0, v4, v5}, Lcom/localebro/okhttpprofiler/transfer/a;->c(Ljava/lang/String;J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-object p1

    :catch_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v3, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v6, 0x5

    move v7, v6

    invoke-interface {v3, v0, p1}, Lcom/localebro/okhttpprofiler/transfer/a;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p0, Ln6/a;->a:Lcom/localebro/okhttpprofiler/transfer/a;

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    sub-long/2addr v4, v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {v3, v0, v4, v5}, Lcom/localebro/okhttpprofiler/transfer/a;->c(Ljava/lang/String;J)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    throw p1
.end method
