.class public final Lx6/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSVGAVideoSpriteEntity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SVGAVideoSpriteEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoSpriteEntity\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,61:1\n1313#2:62\n1382#2,3:63\n*E\n*S KotlinDebug\n*F\n+ 1 SVGAVideoSpriteEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoSpriteEntity\n*L\n43#1:62\n43#1,3:63\n*E\n"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final b:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lx6/h;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/opensource/svgaplayer/proto/SpriteEntity;)V
    .locals 7
    .param p1    # Lcom/opensource/svgaplayer/proto/SpriteEntity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v0, "bjo"

    const-string/jumbo v0, "jbo"

    const/4 v6, 0x3

    const-string/jumbo v0, "obj"

    const-string/jumbo v0, "obj"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/SpriteEntity;->imageKey:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput-object v0, p0, Lx6/g;->a:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/SpriteEntity;->matteKey:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object v0, p0, Lx6/g;->b:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/SpriteEntity;->frames:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz p1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/16 v1, 0xa

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p1, v1}, Lkotlin/collections/u;->Y(Ljava/lang/Iterable;I)I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    check-cast v2, Lcom/opensource/svgaplayer/proto/FrameEntity;

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v3, Lx6/h;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const-string/jumbo v4, "ti"

    const/4 v6, 0x6

    const-string/jumbo v4, "it"

    const-string/jumbo v4, "it"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v2, v4}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v3, v2}, Lx6/h;-><init>(Lcom/opensource/svgaplayer/proto/FrameEntity;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-virtual {v3}, Lx6/h;->d()Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    xor-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3}, Lx6/h;->d()Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v2}, Lkotlin/collections/u;->y2(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v2, Lx6/d;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Lx6/d;->k()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1}, Lx6/h;->d()Ljava/util/List;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {v3, v1}, Lx6/h;->i(Ljava/util/List;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v0, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v0, p0, Lx6/g;->c:Ljava/util/List;

    const/4 v6, 0x7

    return-void
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .locals 7
    .param p1    # Lorg/json/JSONObject;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v0, "bjo"

    const-string/jumbo v0, "ojb"

    const/4 v6, 0x4

    const-string/jumbo v0, "obj"

    const-string/jumbo v0, "obj"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v0, "gesKieys"

    const-string v0, "gasyeKie"

    const/4 v6, 0x3

    const-string v0, "eiameKyg"

    const-string/jumbo v0, "imageKey"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-object v0, p0, Lx6/g;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v0, "atyeotmm"

    const-string v0, "amtmeyKt"

    const/4 v6, 0x6

    const-string/jumbo v0, "matteKey"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput-object v0, p0, Lx6/g;->b:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo v1, "rasefb"

    const-string v1, "frames"

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz p1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ge v2, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v4, Lx6/h;

    const/4 v6, 0x5

    invoke-direct {v4, v3}, Lx6/h;-><init>(Lorg/json/JSONObject;)V

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v4}, Lx6/h;->d()Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    xor-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v4}, Lx6/h;->d()Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v3}, Lkotlin/collections/u;->y2(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v3, Lx6/d;

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3}, Lx6/d;->k()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-lez v3, :cond_0

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    invoke-static {v0}, Lkotlin/collections/u;->m3(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    check-cast v3, Lx6/h;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3}, Lx6/h;->d()Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v4, v3}, Lx6/h;->i(Ljava/util/List;)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    invoke-static {v0}, Lkotlin/collections/u;->S5(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-object p1, p0, Lx6/g;->c:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lx6/h;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lx6/g;->c:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public final b()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lx6/g;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public final c()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lx6/g;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method
