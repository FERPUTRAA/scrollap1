.class public final Lx6/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 20

    const-string v0, "M"

    const-string v0, "M"

    const-string v0, "M"

    const-string v0, "M"

    const-string v1, "L"

    const-string v1, "L"

    const-string v1, "L"

    const-string v1, "L"

    const-string v2, "H"

    const-string v2, "H"

    const-string v2, "H"

    const-string v2, "H"

    const-string v3, "V"

    const-string v3, "V"

    const-string v3, "V"

    const-string v4, "C"

    const-string v4, "C"

    const-string v4, "C"

    const-string v5, "S"

    const-string v5, "S"

    const-string v5, "S"

    const-string v6, "Q"

    const-string v6, "Q"

    const-string v6, "Q"

    const-string v6, "Q"

    const-string v7, "R"

    const-string v7, "R"

    const-string v7, "R"

    const-string v7, "R"

    const-string v8, "A"

    const-string v8, "A"

    const-string v8, "A"

    const-string v8, "A"

    const-string v9, "Z"

    const-string v9, "Z"

    const-string v9, "Z"

    const-string v9, "Z"

    const-string/jumbo v10, "m"

    const-string/jumbo v10, "m"

    const-string/jumbo v10, "m"

    const-string/jumbo v10, "m"

    const-string/jumbo v11, "l"

    const-string/jumbo v11, "l"

    const-string v12, "h"

    const-string v12, "h"

    const-string v12, "h"

    const-string v12, "h"

    const-string/jumbo v13, "v"

    const-string/jumbo v13, "v"

    const-string/jumbo v13, "v"

    const-string v14, "c"

    const-string v14, "c"

    const-string v14, "c"

    const-string v14, "c"

    const-string/jumbo v15, "s"

    const-string/jumbo v15, "s"

    const-string/jumbo v15, "s"

    const-string/jumbo v15, "s"

    const-string/jumbo v16, "q"

    const-string/jumbo v16, "q"

    const-string/jumbo v16, "q"

    const-string/jumbo v16, "q"

    const-string/jumbo v17, "r"

    const-string/jumbo v17, "r"

    const-string/jumbo v17, "r"

    const-string/jumbo v17, "r"

    const-string v18, "a"

    const-string v18, "a"

    const-string v18, "a"

    const-string v18, "a"

    const-string/jumbo v19, "z"

    const-string/jumbo v19, "z"

    const-string/jumbo v19, "z"

    const-string/jumbo v19, "z"

    filled-new-array/range {v0 .. v19}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/j1;->u([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lx6/c;->a:Ljava/util/Set;

    return-void
.end method

.method public static final synthetic a()Ljava/util/Set;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sm@  o @@c b@yo4K u  nbr@~l~ot~i~f~/t~@  ~i o~  ~a1@-~. /b@ ~@~ v@M@~o~@@ @d~@~~i @lSof@@~~~s@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lx6/c;->a:Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method
