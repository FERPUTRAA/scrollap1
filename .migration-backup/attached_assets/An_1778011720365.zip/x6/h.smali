.class public final Lx6/h;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSVGAVideoSpriteFrameEntity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SVGAVideoSpriteFrameEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoSpriteFrameEntity\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,95:1\n1313#2:96\n1382#2,3:97\n*E\n*S KotlinDebug\n*F\n+ 1 SVGAVideoSpriteFrameEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoSpriteFrameEntity\n*L\n89#1:96\n89#1,3:97\n*E\n"
.end annotation


# instance fields
.field private a:D

.field private b:Ly6/d;
    .annotation build Lia/d;
    .end annotation
.end field

.field private c:Landroid/graphics/Matrix;
    .annotation build Lia/d;
    .end annotation
.end field

.field private d:Lx6/b;
    .annotation build Lia/e;
    .end annotation
.end field

.field private e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lx6/d;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/opensource/svgaplayer/proto/FrameEntity;)V
    .locals 14
    .param p1    # Lcom/opensource/svgaplayer/proto/FrameEntity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x2

    const-string/jumbo v0, "ojb"

    const/4 v13, 0x5

    const-string/jumbo v0, "obj"

    const/4 v13, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x1

    new-instance v0, Ly6/d;

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v13, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x1

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v13, 0x7

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v13, 0x3

    const/4 v12, 0x1

    invoke-direct/range {v1 .. v9}, Ly6/d;-><init>(DDDD)V

    const/4 v13, 0x4

    iput-object v0, p0, Lx6/h;->b:Ly6/d;

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x5

    iput-object v0, p0, Lx6/h;->c:Landroid/graphics/Matrix;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x7

    iput-object v0, p0, Lx6/h;->e:Ljava/util/List;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x2

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/FrameEntity;->alpha:Ljava/lang/Float;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v1, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    if-eqz v0, :cond_0

    const/4 v13, 0x0

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x7

    goto :goto_0

    :cond_0
    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x6

    move v0, v1

    move v0, v1

    const/4 v13, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x4

    float-to-double v2, v0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    iput-wide v2, p0, Lx6/h;->a:D

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x1

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/FrameEntity;->layout:Lcom/opensource/svgaplayer/proto/Layout;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-eqz v0, :cond_5

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    new-instance v11, Ly6/d;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x5

    iget-object v2, v0, Lcom/opensource/svgaplayer/proto/Layout;->x:Ljava/lang/Float;

    const/4 v13, 0x2

    const/4 v12, 0x1

    if-eqz v2, :cond_1

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x2

    goto :goto_1

    :cond_1
    const/4 v13, 0x0

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x2

    float-to-double v3, v2

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x3

    iget-object v2, v0, Lcom/opensource/svgaplayer/proto/Layout;->y:Ljava/lang/Float;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    if-eqz v2, :cond_2

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    goto :goto_2

    :cond_2
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    move v2, v1

    move v2, v1

    const/4 v13, 0x1

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v12, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x7

    float-to-double v5, v2

    const/4 v13, 0x2

    iget-object v2, v0, Lcom/opensource/svgaplayer/proto/Layout;->width:Ljava/lang/Float;

    const/4 v13, 0x7

    if-eqz v2, :cond_3

    const/4 v13, 0x6

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    goto :goto_3

    :cond_3
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x6

    move v2, v1

    move v2, v1

    const/4 v13, 0x3

    move v2, v1

    move v2, v1

    :goto_3
    const/4 v12, 0x6

    move v13, v12

    float-to-double v7, v2

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x5

    iget-object v0, v0, Lcom/opensource/svgaplayer/proto/Layout;->height:Ljava/lang/Float;

    const/4 v13, 0x2

    const/4 v12, 0x1

    if-eqz v0, :cond_4

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x6

    goto :goto_4

    :cond_4
    const/4 v12, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x5

    move v0, v1

    const/4 v13, 0x1

    move v0, v1

    move v0, v1

    :goto_4
    const/4 v13, 0x5

    float-to-double v9, v0

    move-object v2, v11

    move-object v2, v11

    move-object v2, v11

    move-object v2, v11

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-direct/range {v2 .. v10}, Ly6/d;-><init>(DDDD)V

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x2

    iput-object v11, p0, Lx6/h;->b:Ly6/d;

    :cond_5
    const/4 v12, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x1

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/FrameEntity;->transform:Lcom/opensource/svgaplayer/proto/Transform;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v2, 0x1

    move v13, v2

    const/4 v12, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x6

    const/4 v3, 0x0

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x3

    if-eqz v0, :cond_c

    const/4 v12, 0x2

    xor-int/2addr v13, v12

    const/16 v4, 0x9

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x5

    new-array v4, v4, [F

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x4

    iget-object v5, v0, Lcom/opensource/svgaplayer/proto/Transform;->a:Ljava/lang/Float;

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x1

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v12, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-eqz v5, :cond_6

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x6

    goto :goto_5

    :cond_6
    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    move v5, v6

    move v5, v6

    const/4 v13, 0x3

    move v5, v6

    move v5, v6

    :goto_5
    const/4 v12, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x0

    iget-object v7, v0, Lcom/opensource/svgaplayer/proto/Transform;->b:Ljava/lang/Float;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    if-eqz v7, :cond_7

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_6

    :cond_7
    const/4 v13, 0x0

    const/4 v12, 0x2

    move v7, v1

    move v7, v1

    const/4 v13, 0x5

    move v7, v1

    move v7, v1

    :goto_6
    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x3

    iget-object v8, v0, Lcom/opensource/svgaplayer/proto/Transform;->c:Ljava/lang/Float;

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x6

    if-eqz v8, :cond_8

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    move-result v8

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    goto :goto_7

    :cond_8
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x0

    move v8, v1

    move v8, v1

    const/4 v13, 0x4

    move v8, v1

    move v8, v1

    :goto_7
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x5

    iget-object v9, v0, Lcom/opensource/svgaplayer/proto/Transform;->d:Ljava/lang/Float;

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x1

    if-eqz v9, :cond_9

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v9}, Ljava/lang/Float;->floatValue()F

    move-result v9

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x7

    goto :goto_8

    :cond_9
    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x5

    move v9, v6

    move v9, v6

    const/4 v13, 0x1

    move v9, v6

    move v9, v6

    :goto_8
    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x2

    iget-object v10, v0, Lcom/opensource/svgaplayer/proto/Transform;->tx:Ljava/lang/Float;

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x4

    if-eqz v10, :cond_a

    const/4 v12, 0x5

    shl-int/2addr v13, v12

    invoke-virtual {v10}, Ljava/lang/Float;->floatValue()F

    move-result v10

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x5

    goto :goto_9

    :cond_a
    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x2

    move v10, v1

    move v10, v1

    const/4 v13, 0x5

    move v10, v1

    move v10, v1

    :goto_9
    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x7

    iget-object v0, v0, Lcom/opensource/svgaplayer/proto/Transform;->ty:Ljava/lang/Float;

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x0

    if-eqz v0, :cond_b

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x4

    goto :goto_a

    :cond_b
    const/4 v13, 0x2

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    :goto_a
    const/4 v13, 0x1

    aput v5, v4, v3

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x1

    aput v8, v4, v2

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x5

    const/4 v5, 0x2

    const/4 v13, 0x4

    aput v10, v4, v5

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x7

    const/4 v5, 0x3

    const/4 v13, 0x7

    const/4 v12, 0x2

    aput v7, v4, v5

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x4

    const/4 v5, 0x4

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x3

    aput v9, v4, v5

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x0

    const/4 v5, 0x5

    const/4 v12, 0x1

    or-int/2addr v13, v12

    aput v0, v4, v5

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v0, 0x6

    shr-int/2addr v13, v0

    const/4 v12, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x2

    aput v1, v4, v0

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x3

    const/4 v0, 0x7

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x5

    aput v1, v4, v0

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/16 v0, 0x8

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    aput v6, v4, v0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x4

    iget-object v0, p0, Lx6/h;->c:Landroid/graphics/Matrix;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v0, v4}, Landroid/graphics/Matrix;->setValues([F)V

    :cond_c
    const/4 v12, 0x6

    move v13, v12

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/FrameEntity;->clipPath:Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x0

    if-eqz v0, :cond_f

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x5

    if-lez v1, :cond_d

    const/4 v12, 0x1

    goto :goto_b

    :cond_d
    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x6

    move v2, v3

    move v2, v3

    const/4 v13, 0x0

    move v2, v3

    move v2, v3

    :goto_b
    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x2

    if-eqz v2, :cond_e

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x3

    goto :goto_c

    :cond_e
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x6

    const/4 v0, 0x0

    :goto_c
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x0

    if-eqz v0, :cond_f

    const/4 v12, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x5

    new-instance v1, Lx6/b;

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-direct {v1, v0}, Lx6/b;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x4

    iput-object v1, p0, Lx6/h;->d:Lx6/b;

    :cond_f
    const/4 v13, 0x3

    const/4 v12, 0x6

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/FrameEntity;->shapes:Ljava/util/List;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x7

    const-string/jumbo v0, "sjseospash"

    const-string/jumbo v0, "pashsojbse"

    const/4 v13, 0x4

    const-string v0, "ajom.pehbs"

    const-string/jumbo v0, "obj.shapes"

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/16 v1, 0xa

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-static {p1, v1}, Lkotlin/collections/u;->Y(Ljava/lang/Iterable;I)I

    move-result v1

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v13, 0x6

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_d
    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x6

    if-eqz v1, :cond_10

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x3

    check-cast v1, Lcom/opensource/svgaplayer/proto/ShapeEntity;

    const/4 v13, 0x0

    new-instance v2, Lx6/d;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x3

    const-string/jumbo v3, "it"

    const-string/jumbo v3, "ti"

    const/4 v13, 0x6

    const-string/jumbo v3, "ti"

    const-string/jumbo v3, "it"

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v12, 0x4

    shr-int/2addr v13, v12

    invoke-direct {v2, v1}, Lx6/d;-><init>(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-interface {v0, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x3

    goto :goto_d

    :cond_10
    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x7

    iput-object v0, p0, Lx6/h;->e:Ljava/util/List;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    return-void
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .locals 17
    .param p1    # Lorg/json/JSONObject;
        .annotation build Lia/d;
        .end annotation
    .end param

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    const-string v2, "boj"

    const-string/jumbo v2, "job"

    const-string/jumbo v2, "obj"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    new-instance v2, Ly6/d;

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    invoke-direct/range {v3 .. v11}, Ly6/d;-><init>(DDDD)V

    iput-object v2, v0, Lx6/h;->b:Ly6/d;

    new-instance v2, Landroid/graphics/Matrix;

    invoke-direct {v2}, Landroid/graphics/Matrix;-><init>()V

    iput-object v2, v0, Lx6/h;->c:Landroid/graphics/Matrix;

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v2

    iput-object v2, v0, Lx6/h;->e:Ljava/util/List;

    const-string/jumbo v2, "phlao"

    const-string/jumbo v2, "palmh"

    const-string v2, "blaah"

    const-string v2, "alpha"

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v5

    iput-wide v5, v0, Lx6/h;->a:D

    const-string/jumbo v2, "ultaoo"

    const-string/jumbo v2, "olauot"

    const-string/jumbo v2, "lpuota"

    const-string/jumbo v2, "layout"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    if-eqz v2, :cond_0

    new-instance v14, Ly6/d;

    const-string/jumbo v5, "x"

    const-string/jumbo v5, "x"

    invoke-virtual {v2, v5, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v6

    const-string/jumbo v5, "y"

    const-string/jumbo v5, "y"

    const-string/jumbo v5, "y"

    const-string/jumbo v5, "y"

    invoke-virtual {v2, v5, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v8

    const-string/jumbo v5, "wdtqi"

    const-string/jumbo v5, "width"

    invoke-virtual {v2, v5, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v10

    const-string v5, "ghsteh"

    const-string v5, "height"

    invoke-virtual {v2, v5, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v12

    move-object v5, v14

    move-object v5, v14

    move-object v5, v14

    invoke-direct/range {v5 .. v13}, Ly6/d;-><init>(DDDD)V

    iput-object v14, v0, Lx6/h;->b:Ly6/d;

    :cond_0
    const-string/jumbo v2, "rbomrfsmn"

    const-string/jumbo v2, "rfonmbrts"

    const-string/jumbo v2, "transform"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    if-eqz v2, :cond_1

    const/16 v7, 0x9

    new-array v7, v7, [F

    const-string v8, "a"

    const-string v8, "a"

    const-string v8, "a"

    const-string v8, "a"

    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v9, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v2, v8, v9, v10}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v11

    const-string v8, "b"

    const-string v8, "b"

    const-string v8, "b"

    const-string v8, "b"

    invoke-virtual {v2, v8, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v13

    const-string v8, "c"

    const-string v8, "c"

    const-string v8, "c"

    invoke-virtual {v2, v8, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v5

    const-string v8, "d"

    const-string v8, "d"

    const-string v8, "d"

    const-string v8, "d"

    invoke-virtual {v2, v8, v9, v10}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v0

    const-string/jumbo v8, "xt"

    const-string/jumbo v8, "xt"

    const-string/jumbo v8, "tx"

    const-string/jumbo v8, "tx"

    invoke-virtual {v2, v8, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v9

    const-string/jumbo v8, "ty"

    const-string/jumbo v8, "ty"

    move-wide v15, v0

    invoke-virtual {v2, v8, v3, v4}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v0

    double-to-float v2, v11

    const/4 v8, 0x0

    aput v2, v7, v8

    double-to-float v2, v5

    const/4 v5, 0x1

    aput v2, v7, v5

    const/4 v2, 0x2

    double-to-float v6, v9

    aput v6, v7, v2

    const/4 v2, 0x3

    double-to-float v6, v13

    aput v6, v7, v2

    const/4 v2, 0x4

    move-wide v9, v15

    double-to-float v6, v9

    aput v6, v7, v2

    const/4 v2, 0x5

    double-to-float v0, v0

    aput v0, v7, v2

    double-to-float v0, v3

    const/4 v1, 0x6

    aput v0, v7, v1

    const/4 v1, 0x7

    aput v0, v7, v1

    const/16 v0, 0x8

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    double-to-float v1, v1

    aput v1, v7, v0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-object v1, v0, Lx6/h;->c:Landroid/graphics/Matrix;

    invoke-virtual {v1, v7}, Landroid/graphics/Matrix;->setValues([F)V

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v8, 0x0

    :goto_0
    const-string v1, "Ppcaolut"

    const-string v1, "Phltcaup"

    const-string/jumbo v1, "pihaPblt"

    const-string v1, "clipPath"

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_2

    goto :goto_1

    :cond_2
    move v5, v8

    move v5, v8

    move v5, v8

    move v5, v8

    :goto_1
    if-eqz v5, :cond_3

    new-instance v3, Lx6/b;

    invoke-direct {v3, v1}, Lx6/b;-><init>(Ljava/lang/String;)V

    iput-object v3, v0, Lx6/h;->d:Lx6/b;

    :cond_3
    const-string/jumbo v1, "uppsah"

    const-string v1, "hpseap"

    const-string v1, "apseph"

    const-string/jumbo v1, "shapes"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    if-eqz v1, :cond_6

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    move v6, v8

    move v6, v8

    move v6, v8

    move v6, v8

    :goto_2
    if-ge v6, v3, :cond_5

    invoke-virtual {v1, v6}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_4

    new-instance v5, Lx6/d;

    invoke-direct {v5, v4}, Lx6/d;-><init>(Lorg/json/JSONObject;)V

    invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_5
    invoke-static {v2}, Lkotlin/collections/u;->S5(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    iput-object v1, v0, Lx6/h;->e:Ljava/util/List;

    :cond_6
    return-void
.end method


# virtual methods
.method public final a()D
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y~ S@di@qb~ fa  /~o@~ t@~~@~1~@sb@~o~~~niv@oM @c @m4@b ~@ .r/  ~@- @f~ ~ K@lou ~ol~@o~i @ ~t~@@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-wide v0, p0, Lx6/h;->a:D

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-wide v0
.end method

.method public final b()Ly6/d;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    iget-object v0, p0, Lx6/h;->b:Ly6/d;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public final c()Lx6/b;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lx6/h;->d:Lx6/b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public final d()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lx6/d;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lx6/h;->e:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method

.method public final e()Landroid/graphics/Matrix;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lx6/h;->c:Landroid/graphics/Matrix;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public final f(D)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-wide p1, p0, Lx6/h;->a:D

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public final g(Ly6/d;)V
    .locals 3
    .param p1    # Ly6/d;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "?>s<est"

    const-string v0, "<q?ets>"

    const-string v0, "<?ems>t"

    const-string v0, "<set-?>"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lx6/h;->b:Ly6/d;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public final h(Lx6/b;)V
    .locals 2
    .param p1    # Lx6/b;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lx6/h;->d:Lx6/b;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public final i(Ljava/util/List;)V
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lx6/d;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "?s<to>-"

    const-string v0, "ets<-?>"

    const/4 v2, 0x6

    const-string v0, "-<se>bt"

    const-string v0, "<set-?>"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lx6/h;->e:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public final j(Landroid/graphics/Matrix;)V
    .locals 3
    .param p1    # Landroid/graphics/Matrix;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "?>es<tu"

    const-string v0, "<set-?>"

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lx6/h;->c:Landroid/graphics/Matrix;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
