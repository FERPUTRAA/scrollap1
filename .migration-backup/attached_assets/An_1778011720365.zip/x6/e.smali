.class public final synthetic Lx6/e;
.super Ljava/lang/Object;


# static fields
.field public static final synthetic a:[I

.field public static final synthetic b:[I

.field public static final synthetic c:[I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 8

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {}, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;->values()[Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    array-length v0, v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x1

    move v7, v6

    sput-object v0, Lx6/e;->a:[I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;->SHAPE:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    aput v2, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;->RECT:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v3, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    aput v3, v0, v1

    const/4 v7, 0x4

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;->ELLIPSE:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v4, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    aput v4, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;->KEEP:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v5, 0x4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput v5, v0, v1

    const/4 v7, 0x3

    invoke-static {}, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;->values()[Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    array-length v0, v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-array v0, v0, [I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    sput-object v0, Lx6/e;->b:[I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;->LineCap_BUTT:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput v2, v0, v1

    const/4 v7, 0x0

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;->LineCap_ROUND:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    aput v3, v0, v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;->LineCap_SQUARE:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    aput v4, v0, v1

    invoke-static {}, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;->values()[Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    array-length v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    sput-object v0, Lx6/e;->c:[I

    const/4 v6, 0x7

    move v7, v6

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;->LineJoin_BEVEL:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    aput v2, v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;->LineJoin_MITER:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    aput v3, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget-object v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;->LineJoin_ROUND:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput v4, v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method
