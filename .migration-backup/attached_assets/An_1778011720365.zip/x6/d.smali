.class public final Lx6/d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lx6/d$b;,
        Lx6/d$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSVGAVideoShapeEntity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SVGAVideoShapeEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoShapeEntity\n+ 2 Iterators.kt\nkotlin/collections/CollectionsKt__IteratorsKt\n*L\n1#1,357:1\n32#2,2:358\n*E\n*S KotlinDebug\n*F\n+ 1 SVGAVideoShapeEntity.kt\ncom/opensource/svgaplayer/entities/SVGAVideoShapeEntity\n*L\n107#1,2:358\n*E\n"
.end annotation


# instance fields
.field private a:Lx6/d$b;
    .annotation build Lia/d;
    .end annotation
.end field

.field private b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private c:Lx6/d$a;
    .annotation build Lia/e;
    .end annotation
.end field

.field private d:Landroid/graphics/Matrix;
    .annotation build Lia/e;
    .end annotation
.end field

.field private e:Landroid/graphics/Path;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V
    .locals 3
    .param p1    # Lcom/opensource/svgaplayer/proto/ShapeEntity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const-string/jumbo v0, "jbo"

    const/4 v2, 0x4

    const-string/jumbo v0, "obj"

    const-string/jumbo v0, "obj"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    sget-object v0, Lx6/d$b;->a:Lx6/d$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lx6/d;->r(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lx6/d;->l(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lx6/d;->n(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lx6/d;->p(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .locals 3
    .param p1    # Lorg/json/JSONObject;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "obj"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lx6/d$b;->a:Lx6/d$b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput-object v0, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lx6/d;->s(Lorg/json/JSONObject;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lx6/d;->m(Lorg/json/JSONObject;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lx6/d;->o(Lorg/json/JSONObject;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lx6/d;->q(Lorg/json/JSONObject;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method private final b(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@-s ~ @4ot/ @~/bbiu@1~v@b~s ~l @ ~@y~~i @S@~o@doo@@ ~rmt@ ~~~@@~.f~M~@o l n@K~f i~c o ~ @ ~a~@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->a:Ljava/lang/Float;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    cmpg-float p1, p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-gtz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/high16 v0, 0x437f0000    # 255.0f

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method private final c(Lorg/json/JSONArray;)F
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 p1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    int-to-double v2, p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    cmpg-double p1, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-gtz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/high16 p1, 0x437f0000    # 255.0f

    const/4 v4, 0x2

    move v5, v4

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v5, 0x5

    const/high16 p1, 0x3f800000    # 1.0f

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    return p1
.end method

.method private final d(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->r:Ljava/lang/Float;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x7

    int-to-float v2, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    cmpg-float v0, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-gtz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->g:Ljava/lang/Float;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    cmpg-float v0, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-gtz v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->b:Ljava/lang/Float;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    cmpg-float p1, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-gtz p1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/high16 p1, 0x437f0000    # 255.0f

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/high16 p1, 0x3f800000    # 1.0f

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return p1
.end method

.method private final e(Lorg/json/JSONArray;)F
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x2

    int-to-double v3, v2

    const/4 v6, 0x4

    cmpg-double v0, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-gtz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    cmpg-double v0, v0, v3

    const/4 v6, 0x4

    if-gtz v0, :cond_0

    const/4 v6, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v0

    const/4 v6, 0x1

    cmpg-double p1, v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-gtz p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/high16 p1, 0x437f0000    # 255.0f

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/high16 p1, 0x3f800000    # 1.0f

    :goto_0
    const/4 v6, 0x1

    return p1
.end method

.method private final l(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x1

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->shape:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeArgs;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v1, :cond_0

    const/4 v7, 0x6

    move v8, v7

    iget-object v1, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeArgs;->d:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v1, :cond_0

    const/4 v7, 0x0

    or-int/2addr v8, v7

    const-string v2, "d"

    const/4 v8, 0x5

    const-string v2, "d"

    const-string v2, "d"

    const/4 v8, 0x2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->ellipse:Lcom/opensource/svgaplayer/proto/ShapeEntity$EllipseArgs;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v2, "y"

    const-string/jumbo v2, "y"

    const/4 v8, 0x7

    const-string/jumbo v2, "y"

    const-string/jumbo v2, "y"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string/jumbo v3, "x"

    const-string/jumbo v3, "x"

    const/4 v8, 0x2

    const-string/jumbo v3, "x"

    const-string/jumbo v3, "x"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v1, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$EllipseArgs;->x:Ljava/lang/Float;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v3, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$EllipseArgs;->y:Ljava/lang/Float;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v5, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x5

    goto :goto_1

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$EllipseArgs;->radiusX:Ljava/lang/Float;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v5, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_2

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo v6, "usrmsXi"

    const-string v6, "Xussria"

    const/4 v8, 0x0

    const-string/jumbo v6, "sairodX"

    const-string/jumbo v6, "radiusX"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v1, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$EllipseArgs;->radiusY:Ljava/lang/Float;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v1, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_3

    :cond_4
    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_3
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v5, "sruadbY"

    const-string/jumbo v5, "radiusY"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->rect:Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz p1, :cond_b

    const/4 v8, 0x0

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;->x:Ljava/lang/Float;

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v1, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_4

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_4
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;->y:Ljava/lang/Float;

    const/4 v8, 0x7

    if-eqz v1, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x7

    goto :goto_5

    :cond_7
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_5
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x6

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;->width:Ljava/lang/Float;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v1, :cond_8

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_6

    :cond_8
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_6
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v2, "wudmt"

    const-string/jumbo v2, "tdhmw"

    const/4 v8, 0x7

    const-string/jumbo v2, "itpwd"

    const-string/jumbo v2, "width"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;->height:Ljava/lang/Float;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v1, :cond_9

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_7

    :cond_9
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_7
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo v2, "ieqhhg"

    const-string/jumbo v2, "ighhoe"

    const/4 v8, 0x3

    const-string v2, "hhstie"

    const-string v2, "height"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$RectArgs;->cornerRadius:Ljava/lang/Float;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz p1, :cond_a

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_8

    :cond_a
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    :goto_8
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v1, "srembrnicaud"

    const-string v1, "duinRbraresc"

    const/4 v8, 0x6

    const-string/jumbo v1, "irsdorneoacR"

    const-string v1, "cornerRadius"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    iput-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void
.end method

.method private final m(Lorg/json/JSONObject;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x5

    const-string/jumbo v1, "rags"

    const-string v1, "gsra"

    const/4 v5, 0x1

    const-string v1, "asgr"

    const-string v1, "args"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v2, "ekuelb(avu.y)"

    const-string/jumbo v2, "veyl(uuk.as)e"

    const/4 v5, 0x5

    const-string/jumbo v2, "u)le.vusea(ky"

    const-string/jumbo v2, "values.keys()"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void
.end method

.method private final n(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->styles:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz p1, :cond_17

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v0, Lx6/d$a;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v0}, Lx6/d$a;-><init>()V

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->fill:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v1, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {p0, v1}, Lx6/d;->d(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {p0, v1}, Lx6/d;->b(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->a:Ljava/lang/Float;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz v5, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    move v5, v2

    move v5, v2

    const/4 v9, 0x5

    move v5, v2

    move v5, v2

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    mul-float/2addr v5, v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    float-to-int v4, v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->r:Ljava/lang/Float;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v5, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    move v5, v2

    move v5, v2

    const/4 v9, 0x1

    move v5, v2

    move v5, v2

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    mul-float/2addr v5, v3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    float-to-int v5, v5

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v6, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->g:Ljava/lang/Float;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v6, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_2

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    move v6, v2

    move v6, v2

    const/4 v9, 0x7

    move v6, v2

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    mul-float/2addr v6, v3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    float-to-int v6, v6

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->b:Ljava/lang/Float;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v1, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_3

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v9, 0x7

    mul-float/2addr v1, v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    float-to-int v1, v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v4, v5, v6, v1}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lx6/d$a;->h(I)V

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->stroke:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;

    const/4 v9, 0x5

    const/4 v8, 0x4

    if-eqz v1, :cond_9

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-direct {p0, v1}, Lx6/d;->d(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-direct {p0, v1}, Lx6/d;->b(Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;)F

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->a:Ljava/lang/Float;

    const/4 v9, 0x2

    if-eqz v5, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_4

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v5, v2

    move v5, v2

    const/4 v9, 0x2

    move v5, v2

    move v5, v2

    :goto_4
    const/4 v8, 0x6

    const/4 v9, 0x7

    mul-float/2addr v5, v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    float-to-int v4, v5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v5, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->r:Ljava/lang/Float;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v5, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_5

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x4

    move v5, v2

    move v5, v2

    const/4 v9, 0x6

    move v5, v2

    move v5, v2

    :goto_5
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    mul-float/2addr v5, v3

    const/4 v9, 0x0

    float-to-int v5, v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v6, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->g:Ljava/lang/Float;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v6, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_6

    :cond_7
    const/4 v8, 0x3

    const/4 v9, 0x6

    move v6, v2

    move v6, v2

    const/4 v9, 0x2

    move v6, v2

    :goto_6
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    mul-float/2addr v6, v3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    float-to-int v6, v6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, v1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$RGBAColor;->b:Ljava/lang/Float;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v1, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_7

    :cond_8
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :goto_7
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    mul-float/2addr v1, v3

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    float-to-int v1, v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v4, v5, v6, v1}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lx6/d$a;->m(I)V

    :cond_9
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->strokeWidth:Ljava/lang/Float;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v1, :cond_a

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_8

    :cond_a
    const/4 v8, 0x3

    const/4 v9, 0x4

    move v1, v2

    move v1, v2

    const/4 v9, 0x5

    move v1, v2

    :goto_8
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Lx6/d$a;->n(F)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->lineCap:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineCap;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo v3, "rnpud"

    const-string v3, "dupnr"

    const/4 v9, 0x7

    const-string/jumbo v3, "oruqn"

    const-string/jumbo v3, "round"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v4, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v5, 0x2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v6, 0x1

    const/4 v9, 0x6

    if-eqz v1, :cond_e

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    sget-object v7, Lx6/e;->b:[I

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    aget v1, v7, v1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eq v1, v6, :cond_d

    const/4 v8, 0x7

    move v9, v8

    if-eq v1, v5, :cond_c

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eq v1, v4, :cond_b

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_9

    :cond_b
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string v1, "ausrqq"

    const-string/jumbo v1, "uqqsar"

    const/4 v9, 0x1

    const-string v1, "euqmsa"

    const-string/jumbo v1, "square"

    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Lx6/d$a;->i(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_9

    :cond_c
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0, v3}, Lx6/d$a;->i(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_9

    :cond_d
    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo v1, "tbut"

    const-string v1, "butt"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Lx6/d$a;->i(Ljava/lang/String;)V

    :cond_e
    :goto_9
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->lineJoin:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle$LineJoin;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eqz v1, :cond_12

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    sget-object v7, Lx6/e;->c:[I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    aget v1, v7, v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eq v1, v6, :cond_11

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eq v1, v5, :cond_10

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eq v1, v4, :cond_f

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto :goto_a

    :cond_f
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v0, v3}, Lx6/d$a;->k(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_a

    :cond_10
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v1, "msito"

    const-string/jumbo v1, "miset"

    const/4 v9, 0x7

    const-string/jumbo v1, "miter"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0, v1}, Lx6/d$a;->k(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    goto :goto_a

    :cond_11
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v1, "blebe"

    const-string v1, "bevel"

    const/4 v9, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Lx6/d$a;->k(Ljava/lang/String;)V

    :cond_12
    :goto_a
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->miterLimit:Ljava/lang/Float;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v1, :cond_13

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v2

    :cond_13
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    float-to-int v1, v2

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Lx6/d$a;->l(I)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-array v1, v4, [F

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-virtual {v0, v1}, Lx6/d$a;->j([F)V

    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->lineDashI:Ljava/lang/Float;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v1, :cond_14

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v0}, Lx6/d$a;->c()[F

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    aput v1, v2, v3

    :cond_14
    const/4 v9, 0x5

    const/4 v8, 0x4

    iget-object v1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->lineDashII:Ljava/lang/Float;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v1, :cond_15

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0}, Lx6/d$a;->c()[F

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    aput v1, v2, v6

    :cond_15
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeStyle;->lineDashIII:Ljava/lang/Float;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz p1, :cond_16

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0}, Lx6/d$a;->c()[F

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    aput p1, v1, v5

    :cond_16
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    iput-object v0, p0, Lx6/d;->c:Lx6/d$a;

    :cond_17
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    return-void
.end method

.method private final o(Lorg/json/JSONObject;)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    const-string/jumbo v1, "usmset"

    const-string/jumbo v1, "stemsl"

    const-string/jumbo v1, "yplest"

    const-string/jumbo v1, "styles"

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v1, :cond_3

    new-instance v2, Lx6/d$a;

    invoke-direct {v2}, Lx6/d$a;-><init>()V

    const-string/jumbo v3, "lfli"

    const-string/jumbo v3, "llfi"

    const-string/jumbo v3, "lilf"

    const-string v3, "fill"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ne v9, v6, :cond_0

    invoke-direct {v0, v3}, Lx6/d;->e(Lorg/json/JSONArray;)F

    move-result v9

    invoke-direct {v0, v3}, Lx6/d;->c(Lorg/json/JSONArray;)F

    move-result v10

    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v11

    float-to-double v13, v10

    mul-double/2addr v11, v13

    double-to-int v10, v11

    invoke-virtual {v3, v8}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v11

    float-to-double v13, v9

    mul-double/2addr v11, v13

    double-to-int v9, v11

    invoke-virtual {v3, v7}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v11

    mul-double/2addr v11, v13

    double-to-int v11, v11

    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v15

    mul-double v12, v15, v13

    double-to-int v3, v12

    invoke-static {v10, v9, v11, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v2, v3}, Lx6/d$a;->h(I)V

    :cond_0
    const-string/jumbo v3, "osqeko"

    const-string v3, "esrook"

    const-string/jumbo v3, "tosrsk"

    const-string/jumbo v3, "stroke"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ne v9, v6, :cond_1

    invoke-direct {v0, v3}, Lx6/d;->e(Lorg/json/JSONArray;)F

    move-result v6

    invoke-direct {v0, v3}, Lx6/d;->c(Lorg/json/JSONArray;)F

    move-result v9

    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v10

    float-to-double v12, v9

    mul-double/2addr v10, v12

    double-to-int v5, v10

    invoke-virtual {v3, v8}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v9

    float-to-double v11, v6

    mul-double/2addr v9, v11

    double-to-int v6, v9

    invoke-virtual {v3, v7}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v9

    mul-double/2addr v9, v11

    double-to-int v7, v9

    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->optDouble(I)D

    move-result-wide v3

    mul-double/2addr v3, v11

    double-to-int v3, v3

    invoke-static {v5, v6, v7, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v2, v3}, Lx6/d$a;->m(I)V

    :cond_1
    const-string/jumbo v3, "rkbmosettid"

    const-string/jumbo v3, "itedobsrktW"

    const-string/jumbo v3, "seWtotoirhd"

    const-string/jumbo v3, "strokeWidth"

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    invoke-virtual {v1, v3, v4, v5}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v6

    double-to-float v3, v6

    invoke-virtual {v2, v3}, Lx6/d$a;->n(F)V

    const-string v3, "eCiupbn"

    const-string v3, "Ceainpu"

    const-string v3, "apinClu"

    const-string/jumbo v3, "lineCap"

    const-string v6, "butt"

    const-string/jumbo v6, "tbut"

    const-string v6, "butt"

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "/ori//,p/piuntSpn/gC/p(ttt/ebtlai./"

    const-string v6, "a(lCgn.p/,tS/eo/rtbi)pt//tit/ip/un/"

    const-string v6, "i grtCliqatb./tep,/)(/p/u/o//tSint/"

    const-string/jumbo v6, "it.optString(\"lineCap\", \"butt\")"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Lx6/d$a;->i(Ljava/lang/String;)V

    const-string/jumbo v3, "iqsoelin"

    const-string/jumbo v3, "qeJoilni"

    const-string v3, "iJemnlon"

    const-string/jumbo v3, "lineJoin"

    const-string/jumbo v6, "miser"

    const-string/jumbo v6, "miter"

    invoke-virtual {v1, v3, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "/,t(o)rt/p/Se/ir/.entmnm/tgoii//ion l"

    const-string v6, " /(m,tlrm/eopS/ettJn./ro/i/inn)//igti"

    const-string/jumbo v6, "o/t. brp(Sgt/lin//tir/o//ii/,etm)niJn"

    const-string/jumbo v6, "it.optString(\"lineJoin\", \"miter\")"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Lx6/d$a;->k(Ljava/lang/String;)V

    const-string/jumbo v3, "iotimtuLie"

    const-string/jumbo v3, "immioeittL"

    const-string v3, "eLmmritpit"

    const-string/jumbo v3, "miterLimit"

    invoke-virtual {v1, v3, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    invoke-virtual {v2, v3}, Lx6/d$a;->l(I)V

    const-string/jumbo v3, "qaDlnseb"

    const-string/jumbo v3, "nelshbaD"

    const-string v3, "Dsshneai"

    const-string/jumbo v3, "lineDash"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    new-array v3, v3, [F

    invoke-virtual {v2, v3}, Lx6/d$a;->j([F)V

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    :goto_0
    if-ge v8, v3, :cond_2

    invoke-virtual {v2}, Lx6/d$a;->c()[F

    move-result-object v6

    invoke-virtual {v1, v8, v4, v5}, Lorg/json/JSONArray;->optDouble(ID)D

    move-result-wide v9

    double-to-float v7, v9

    aput v7, v6, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_2
    iput-object v2, v0, Lx6/d;->c:Lx6/d$a;

    :cond_3
    return-void
.end method

.method private final p(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->transform:Lcom/opensource/svgaplayer/proto/Transform;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-eqz p1, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x0

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v10, 0x5

    and-int/2addr v11, v10

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/16 v1, 0x9

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-array v1, v1, [F

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v2, p1, Lcom/opensource/svgaplayer/proto/Transform;->a:Ljava/lang/Float;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v2, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    move v2, v3

    move v2, v3

    const/4 v11, 0x5

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x2

    iget-object v4, p1, Lcom/opensource/svgaplayer/proto/Transform;->b:Ljava/lang/Float;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v5, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x0

    if-eqz v4, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    goto :goto_1

    :cond_1
    const/4 v11, 0x0

    move v4, v5

    move v4, v5

    const/4 v11, 0x5

    move v4, v5

    move v4, v5

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget-object v6, p1, Lcom/opensource/svgaplayer/proto/Transform;->c:Ljava/lang/Float;

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v6, :cond_2

    const/4 v11, 0x0

    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    goto :goto_2

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    move v6, v5

    move v6, v5

    const/4 v11, 0x6

    move v6, v5

    move v6, v5

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    iget-object v7, p1, Lcom/opensource/svgaplayer/proto/Transform;->d:Ljava/lang/Float;

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v7, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_3

    :cond_3
    const/4 v10, 0x3

    const/4 v11, 0x0

    move v7, v3

    move v7, v3

    const/4 v11, 0x6

    move v7, v3

    move v7, v3

    :goto_3
    const/4 v11, 0x3

    const/4 v10, 0x4

    iget-object v8, p1, Lcom/opensource/svgaplayer/proto/Transform;->tx:Ljava/lang/Float;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v8, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    move-result v8

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto :goto_4

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    move v8, v5

    move v8, v5

    const/4 v11, 0x0

    move v8, v5

    move v8, v5

    :goto_4
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/Transform;->ty:Ljava/lang/Float;

    const/4 v11, 0x1

    if-eqz p1, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto :goto_5

    :cond_5
    const/4 v11, 0x5

    move p1, v5

    move p1, v5

    const/4 v11, 0x2

    move p1, v5

    :goto_5
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v9, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    aput v2, v1, v9

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v2, 0x1

    const/4 v11, 0x7

    aput v6, v1, v2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v2, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    aput v8, v1, v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v2, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    aput v4, v1, v2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    const/4 v2, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    aput v7, v1, v2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v2, 0x5

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    aput p1, v1, v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 p1, 0x6

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    aput v5, v1, p1

    const/4 v11, 0x4

    const/4 p1, 0x2

    const/4 v11, 0x2

    const/4 p1, 0x7

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    aput v5, v1, p1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/16 p1, 0x8

    const/4 v11, 0x7

    const/4 v10, 0x6

    aput v3, v1, p1

    const/4 v11, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->setValues([F)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    iput-object v0, p0, Lx6/d;->d:Landroid/graphics/Matrix;

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    return-void
.end method

.method private final q(Lorg/json/JSONObject;)V
    .locals 16

    const-string/jumbo v0, "tmnmuaros"

    const-string/jumbo v0, "mosrnaurt"

    const-string/jumbo v0, "transform"

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    const/16 v2, 0x9

    new-array v2, v2, [F

    const-string v3, "a"

    const-string v3, "a"

    const-string v3, "a"

    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v0, v3, v4, v5}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v6

    const-string v3, "b"

    const-string v3, "b"

    const-string v3, "b"

    const-string v3, "b"

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    invoke-virtual {v0, v3, v8, v9}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v10

    const-string v3, "c"

    const-string v3, "c"

    const-string v3, "c"

    const-string v3, "c"

    invoke-virtual {v0, v3, v8, v9}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v12

    const-string v3, "d"

    const-string v3, "d"

    const-string v3, "d"

    invoke-virtual {v0, v3, v4, v5}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v14

    const-string/jumbo v3, "tx"

    const-string/jumbo v3, "xt"

    const-string/jumbo v3, "tx"

    const-string/jumbo v3, "tx"

    invoke-virtual {v0, v3, v8, v9}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v4

    const-string/jumbo v3, "ty"

    const-string/jumbo v3, "ty"

    const-string/jumbo v3, "ty"

    const-string/jumbo v3, "ty"

    move-object/from16 p1, v1

    move-object/from16 p1, v1

    move-object/from16 p1, v1

    move-object/from16 p1, v1

    invoke-virtual {v0, v3, v8, v9}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v0

    const/4 v3, 0x0

    double-to-float v6, v6

    aput v6, v2, v3

    const/4 v3, 0x1

    double-to-float v6, v12

    aput v6, v2, v3

    const/4 v3, 0x2

    double-to-float v4, v4

    aput v4, v2, v3

    const/4 v3, 0x3

    double-to-float v4, v10

    aput v4, v2, v3

    const/4 v3, 0x4

    double-to-float v4, v14

    aput v4, v2, v3

    const/4 v3, 0x5

    double-to-float v0, v0

    aput v0, v2, v3

    double-to-float v0, v8

    const/4 v1, 0x6

    aput v0, v2, v1

    const/4 v1, 0x7

    aput v0, v2, v1

    const/16 v0, 0x8

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    double-to-float v1, v3

    aput v1, v2, v0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    invoke-virtual {v0, v2}, Landroid/graphics/Matrix;->setValues([F)V

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    iput-object v0, v1, Lx6/d;->d:Landroid/graphics/Matrix;

    goto :goto_0

    :cond_0
    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :goto_0
    return-void
.end method

.method private final r(Lcom/opensource/svgaplayer/proto/ShapeEntity;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/opensource/svgaplayer/proto/ShapeEntity;->type:Lcom/opensource/svgaplayer/proto/ShapeEntity$ShapeType;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object v0, Lx6/e;->a:[I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    aget p1, v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p1, v0, :cond_3

    const/4 v1, 0x6

    move v2, v1

    const/4 v0, 0x2

    and-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eq p1, v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p1, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object p1, Lx6/d$b;->d:Lx6/d$b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Lkotlin/j0;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1}, Lkotlin/j0;-><init>()V

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    throw p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object p1, Lx6/d$b;->c:Lx6/d$b;

    const/4 v2, 0x5

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object p1, Lx6/d$b;->b:Lx6/d$b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object p1, Lx6/d$b;->a:Lx6/d$b;

    :goto_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Lx6/d;->a:Lx6/d$b;

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private final s(Lorg/json/JSONObject;)V
    .locals 4

    const/4 v3, 0x4

    const-string/jumbo v0, "pety"

    const/4 v3, 0x7

    const-string/jumbo v0, "type"

    const-string/jumbo v0, "type"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, "hpapo"

    const-string/jumbo v0, "papsh"

    const-string v0, "bhaep"

    const-string/jumbo v0, "shape"

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1, v0, v1}, Lkotlin/text/v;->K1(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object p1, Lx6/d$b;->a:Lx6/d$b;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object p1, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "ertc"

    const-string/jumbo v0, "tcre"

    const/4 v3, 0x2

    const-string v0, "ertc"

    const-string/jumbo v0, "rect"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lkotlin/text/v;->K1(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    sget-object p1, Lx6/d$b;->b:Lx6/d$b;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v0, "pqlesli"

    const/4 v3, 0x3

    const-string v0, "ellipse"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lkotlin/text/v;->K1(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object p1, Lx6/d$b;->c:Lx6/d$b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object p1, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v0, "eekp"

    const-string/jumbo v0, "keep"

    const/4 v3, 0x7

    invoke-static {p1, v0, v1}, Lkotlin/text/v;->K1(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object p1, Lx6/d$b;->d:Lx6/d$b;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p1, p0, Lx6/d;->a:Lx6/d$b;

    :cond_3
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v0, p0, Lx6/d;->e:Landroid/graphics/Path;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-void

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {}, Lx6/f;->a()Landroid/graphics/Path;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v0, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    sget-object v1, Lx6/d$b;->a:Lx6/d$b;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v2, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ne v0, v1, :cond_3

    const/4 v8, 0x1

    shr-int/2addr v9, v8

    iget-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz v0, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    const-string v1, "d"

    const-string v1, "d"

    const-string v1, "d"

    const-string v1, "d"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_1
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez v1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_1

    :cond_2
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-eqz v2, :cond_19

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v0, Lx6/b;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-direct {v0, v2}, Lx6/b;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {}, Lx6/f;->a()Landroid/graphics/Path;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Lx6/b;->a(Landroid/graphics/Path;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    goto/16 :goto_d

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget-object v1, Lx6/d$b;->c:Lx6/d$b;

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v3, "y"

    const/4 v9, 0x3

    const-string/jumbo v3, "y"

    const-string/jumbo v3, "y"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string/jumbo v4, "x"

    const-string/jumbo v4, "x"

    const/4 v9, 0x5

    if-ne v0, v1, :cond_d

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_2

    :cond_4
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x6

    instance-of v1, v0, Ljava/lang/Number;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-nez v1, :cond_5

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    check-cast v0, Ljava/lang/Number;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v0, :cond_c

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v1, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v1, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto :goto_3

    :cond_6
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_3
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    instance-of v3, v1, Ljava/lang/Number;

    const/4 v9, 0x1

    const/4 v8, 0x3

    if-nez v3, :cond_7

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :cond_7
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    check-cast v1, Ljava/lang/Number;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v1, :cond_c

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v3, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v3, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v4, "Xusasru"

    const-string/jumbo v4, "udsaXrs"

    const/4 v9, 0x7

    const-string/jumbo v4, "pXdauir"

    const-string/jumbo v4, "radiusX"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_4

    :cond_8
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_4
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    instance-of v4, v3, Ljava/lang/Number;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-nez v4, :cond_9

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :cond_9
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    check-cast v3, Ljava/lang/Number;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-eqz v3, :cond_c

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v4, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x1

    const/4 v8, 0x3

    if-eqz v4, :cond_a

    const/4 v9, 0x2

    const-string/jumbo v5, "mqidauY"

    const-string v5, "iYumdra"

    const/4 v9, 0x4

    const-string/jumbo v5, "rdsaYiu"

    const-string/jumbo v5, "radiusY"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto :goto_5

    :cond_a
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_5
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    instance-of v5, v4, Ljava/lang/Number;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-nez v5, :cond_b

    const/4 v9, 0x0

    const/4 v8, 0x0

    goto :goto_6

    :cond_b
    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :goto_6
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    check-cast v2, Ljava/lang/Number;

    const/4 v9, 0x5

    const/4 v8, 0x1

    if-eqz v2, :cond_c

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {}, Lx6/f;->a()Landroid/graphics/Path;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v5, Landroid/graphics/RectF;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    sub-float v6, v0, v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    sub-float v7, v1, v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    add-float/2addr v0, v3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    add-float/2addr v1, v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {v5, v6, v7, v0, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    sget-object v0, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-virtual {v4, v5, v0}, Landroid/graphics/Path;->addOval(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    goto/16 :goto_d

    :cond_c
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    return-void

    :cond_d
    const/4 v9, 0x3

    const/4 v8, 0x5

    sget-object v1, Lx6/d$b;->b:Lx6/d$b;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-ne v0, v1, :cond_19

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x2

    if-eqz v0, :cond_e

    const/4 v9, 0x4

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_7

    :cond_e
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_7
    const/4 v9, 0x4

    const/4 v8, 0x4

    instance-of v1, v0, Ljava/lang/Number;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez v1, :cond_f

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_f
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    check-cast v0, Ljava/lang/Number;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v0, :cond_18

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v1, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v1, :cond_10

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_8

    :cond_10
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_8
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    instance-of v3, v1, Ljava/lang/Number;

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v3, :cond_11

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :cond_11
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    check-cast v1, Ljava/lang/Number;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v1, :cond_18

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v3, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v3, :cond_12

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v4, "htomd"

    const-string v4, "hwdto"

    const/4 v9, 0x3

    const-string v4, "dthwo"

    const-string/jumbo v4, "width"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_9

    :cond_12
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_9
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    instance-of v4, v3, Ljava/lang/Number;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-nez v4, :cond_13

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :cond_13
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    check-cast v3, Ljava/lang/Number;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v3, :cond_18

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v4, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v4, :cond_14

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string v5, "eghihb"

    const/4 v9, 0x3

    const-string/jumbo v5, "ihhegb"

    const-string v5, "height"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_a

    :cond_14
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_a
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    instance-of v5, v4, Ljava/lang/Number;

    const/4 v9, 0x1

    if-nez v5, :cond_15

    move-object v4, v2

    move-object v4, v2

    :cond_15
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    check-cast v4, Ljava/lang/Number;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v4, :cond_18

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v5, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eqz v5, :cond_16

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v6, "ncaduouRurri"

    const-string/jumbo v6, "odnsRruciuar"

    const/4 v9, 0x3

    const-string/jumbo v6, "soudnrcpareR"

    const-string v6, "cornerRadius"

    const/4 v9, 0x6

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto :goto_b

    :cond_16
    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    :goto_b
    const/4 v9, 0x7

    const/4 v8, 0x2

    instance-of v6, v5, Ljava/lang/Number;

    if-nez v6, :cond_17

    const/4 v9, 0x6

    const/4 v8, 0x2

    goto :goto_c

    :cond_17
    move-object v2, v5

    move-object v2, v5

    :goto_c
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    check-cast v2, Ljava/lang/Number;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v2, :cond_18

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {}, Lx6/f;->a()Landroid/graphics/Path;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v6, Landroid/graphics/RectF;

    const/4 v8, 0x3

    move v9, v8

    add-float/2addr v3, v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    add-float/2addr v4, v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {v6, v0, v1, v3, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget-object v0, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v5, v6, v2, v2, v0}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    const/4 v8, 0x0

    and-int/2addr v9, v8

    goto :goto_d

    :cond_18
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void

    :cond_19
    :goto_d
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v0, Landroid/graphics/Path;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    iput-object v0, p0, Lx6/d;->e:Landroid/graphics/Path;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {}, Lx6/f;->a()Landroid/graphics/Path;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/Path;->set(Landroid/graphics/Path;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    return-void
.end method

.method public final f()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lx6/d;->b:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public final g()Landroid/graphics/Path;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lx6/d;->e:Landroid/graphics/Path;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public final h()Lx6/d$a;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lx6/d;->c:Lx6/d$a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object v0
.end method

.method public final i()Landroid/graphics/Matrix;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lx6/d;->d:Landroid/graphics/Matrix;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public final j()Lx6/d$b;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object v0
.end method

.method public final k()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lx6/d;->a:Lx6/d$b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lx6/d$b;->d:Lx6/d$b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    and-int/2addr v2, v0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public final t(Landroid/graphics/Path;)V
    .locals 2
    .param p1    # Landroid/graphics/Path;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lx6/d;->e:Landroid/graphics/Path;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
