.class public Lp6/a;
.super Landroidx/recyclerview/widget/RecyclerView$o;


# instance fields
.field private final a:I

.field private final b:I

.field private final c:Z


# direct methods
.method public constructor <init>(IIZ)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$o;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lp6/a;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p2, p0, Lp6/a;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-boolean p3, p0, Lp6/a;->c:Z

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y@sb~@s@@ o ~ ao~K@~@~~St@@~l@u~ ~@od@~@@c@~f @oi~i@4n-~/bmi1/t  ~~obM~. rlo   @ @~~~ @v~~~ @  f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget p3, p0, Lp6/a;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    rem-int p4, p2, p3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean v0, p0, Lp6/a;->c:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p0, Lp6/a;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int v1, p4, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    div-int/2addr v1, p3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    sub-int v1, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/lit8 p4, p4, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    mul-int/2addr p4, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    div-int/2addr p4, p3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput p4, p1, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v0, p0, Lp6/a;->b:I

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    mul-int v1, p4, v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    div-int/2addr v1, p3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 p4, p4, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    mul-int/2addr p4, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    div-int/2addr p4, p3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    sub-int/2addr v0, p4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p1, Landroid/graphics/Rect;->right:I

    :goto_0
    const/4 v3, 0x5

    if-ge p2, p3, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget p2, p0, Lp6/a;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput p2, p1, Landroid/graphics/Rect;->top:I

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget p2, p0, Lp6/a;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput p2, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v2, 0x2

    or-int/2addr v3, v2

    return-void
.end method
