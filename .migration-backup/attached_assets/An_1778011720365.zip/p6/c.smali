.class public Lp6/c;
.super Landroidx/recyclerview/widget/RecyclerView$o;


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$o;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lp6/c;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p2, p0, Lp6/c;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 3
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget p3, p0, Lp6/c;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    rem-int/2addr p2, p3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget p4, p0, Lp6/c;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    mul-int v0, p2, p4

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    div-int/2addr v0, p3

    const/4 v1, 0x7

    or-int/2addr v2, v1

    sub-int v0, p4, v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p1, Landroid/graphics/Rect;->left:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x7

    mul-int/2addr p2, p4

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    div-int/2addr p2, p3

    const/4 v1, 0x4

    move v2, v1

    iput p2, p1, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method
