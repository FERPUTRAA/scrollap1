.class public Lp6/b;
.super Landroidx/recyclerview/widget/RecyclerView$o;


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$o;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lp6/b;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p2, p0, Lp6/b;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o.sS@ ~/r~4 ~ ~~ uo~bd/o   sf~@ M@c~yti~@1i@@K~~~ o@@ll@t ~@@ @@o ~o~  ~bv~@~-fna ~ @~~~@@@bi@ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget p3, p0, Lp6/b;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    rem-int p4, p2, p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x0

    iget v0, p0, Lp6/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int v1, p4, v0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    div-int/2addr v1, p3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v0, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lp6/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    mul-int/2addr v0, p4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    div-int/2addr v0, p3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p1, Landroid/graphics/Rect;->left:I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v0, p0, Lp6/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-int/lit8 p4, p4, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    mul-int/2addr p4, v0

    const/4 v3, 0x6

    div-int/2addr p4, p3

    const/4 v3, 0x5

    const/4 v2, 0x4

    sub-int p4, v0, p4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p4, p1, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ge p2, p3, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput v0, p1, Landroid/graphics/Rect;->top:I

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method
