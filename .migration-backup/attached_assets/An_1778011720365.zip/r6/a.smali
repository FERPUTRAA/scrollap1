.class public Lr6/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "TAG_FAKE_STATUS_BAR_VIEW"

.field private static final b:Ljava/lang/String; = "TAG_MARGIN_ADDED"

.field private static final c:Ljava/lang/String; = "TAG_NAVIGATION_BAR_VIEW"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroidx/appcompat/app/AppCompatActivity;IIZ)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~s~i~ o~ ~~@o~~sv @@Koim~~~~@y@@t- fo@@~  / f~~~  ~oo u   @@i@@@lb@tb~4. @r @MS~bd1 a~/c@@ @l~n"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    move v3, p1

    move v3, p1

    const/4 v7, 0x3

    move v3, p1

    move v3, p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    move v4, p2

    move v4, p2

    const/4 v7, 0x6

    move v4, p2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v5, p3

    move v5, p3

    const/4 v7, 0x5

    move v5, p3

    move v5, p3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lr6/a;->b(Landroidx/appcompat/app/AppCompatActivity;ZZIIZ)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void
.end method

.method public static b(Landroidx/appcompat/app/AppCompatActivity;ZZIIZ)V
    .locals 7

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/high16 v1, -0x80000000

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/high16 v2, 0xc000000

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Landroid/view/Window;->clearFlags(I)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez p3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v3, v4

    move v3, v4

    const/4 v6, 0x4

    move v3, v4

    move v3, v4

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p0, v4, v4, v3, p5}, Lr6/b;->e(Landroid/app/Activity;ZZZZ)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez p2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v4}, Landroid/view/Window;->requestFeature(I)Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Landroid/view/Window;->clearFlags(I)V

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez p3, :cond_2

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v4, v3

    move v4, v3

    const/4 v6, 0x5

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p0, v3, v3, v4, p5}, Lr6/b;->e(Landroid/app/Activity;ZZZZ)V

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_2

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez p1, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0, v4}, Landroid/view/Window;->requestFeature(I)Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Landroid/view/Window;->clearFlags(I)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez p3, :cond_4

    const/4 v6, 0x4

    move p1, v4

    move p1, v4

    const/4 v6, 0x7

    move p1, v4

    move p1, v4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    move p1, v3

    move p1, v3

    const/4 v6, 0x3

    move p1, v3

    move p1, v3

    :goto_1
    const/4 v6, 0x2

    invoke-static {p0, v3, v4, p1, p5}, Lr6/b;->e(Landroid/app/Activity;ZZZZ)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, p3}, Landroid/view/Window;->setStatusBarColor(I)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p4}, Landroid/view/Window;->setNavigationBarColor(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_3

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :catch_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_3
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-void
.end method

.method private static c(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/high16 v1, 0x4000000

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0}, Lr6/a;->e(Landroid/app/Activity;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->l(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/high16 v1, 0x8000000

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0}, Lr6/a;->d(Landroid/app/Activity;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private static d(Landroid/app/Activity;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v2, "TN_m_WVG_TIsVEGOIRAAABA"

    const-string v2, "A_sA_EGTVGO_RNAVTIABIWN"

    const/4 v4, 0x2

    const-string v2, "IIBAo_VTENNGVIROATA_W_G"

    const-string v2, "TAG_NAVIGATION_BAR_VIEW"

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v1, Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->m(Landroid/app/Activity;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->c(Landroid/content/Context;)I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, v2, p0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x6

    const/16 p0, 0x50

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput p0, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->d(Landroid/content/Context;)I

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, p0, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const p0, 0x800005

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput p0, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 p0, 0x0

    shr-int/2addr v4, p0

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    invoke-virtual {v1, p0}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method private static e(Landroid/app/Activity;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v2, "WEmIAb__FTAVUARSABESTTG_"

    const-string v2, "VEFmAUB_SGT__TA_RTSEAWAI"

    const/4 v6, 0x5

    const-string v2, "ARGSEIuSWTA___UKAAVTE_BF"

    const-string v2, "TAG_FAKE_STATUS_BAR_VIEW"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    new-instance v1, Landroid/view/View;

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x1

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v4, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result p0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v3, v4, p0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/16 p0, 0x30

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput p0, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const-string p0, "ADMAoNTEI_DA_DRG"

    const-string p0, "MDRAD_GpN_TGAEAI"

    const-string p0, "TAG_MARGIN_ADDED"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1, p0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void
.end method

.method public static f(Landroid/app/Activity;Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/high16 v0, -0x80000000

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/high16 v0, 0x4000000

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/Window;->clearFlags(I)V

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 p1, 0x2500

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/16 v1, 0x500

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const p1, 0x1020002

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setFitsSystemWindows(Z)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/view/k1;->v1(Landroid/view/View;)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
