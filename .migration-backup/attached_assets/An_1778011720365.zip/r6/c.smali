.class public Lr6/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lr6/c$a;
    }
.end annotation


# static fields
.field private static final a:[Ljava/lang/String;

.field private static final b:Ljava/lang/String; = "unknown"

.field private static c:Ljava/lang/Integer;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "gsssmua"

    const-string v0, "ansumgs"

    const/4 v2, 0x1

    const-string/jumbo v0, "snmmagu"

    const-string/jumbo v0, "samsung"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    sput-object v0, Lr6/c;->a:[Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private static a()Ljava/lang/String;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@@ o @@ct~o~@m4~f ~  @u~ ~ . @o1~ori il/~db ~M@ -@~~ @t ~S~al@f sb~@ ~~@K~oiy~b@~~@@o/@o@@v ~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :catchall_0
    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "nwkumbn"

    const-string/jumbo v0, "wnnmukn"

    const/4 v3, 0x6

    const-string/jumbo v0, "knuwonu"

    const-string/jumbo v0, "unknown"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method public static b()I
    .locals 6

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object v0, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v1, "lFpym"

    const-string/jumbo v1, "mFlyo"

    const/4 v5, 0x3

    const-string v1, "Flyme"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x2

    const-string v3, ""

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "SO"

    const-string v1, "OS"

    const/4 v5, 0x2

    const-string v1, "OS"

    const-string v1, "OS"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, " "

    const-string v1, " "

    const/4 v5, 0x0

    const-string v1, " "

    const-string v1, " "

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Lr6/c;->l(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    return v2
.end method

.method public static c()I
    .locals 3

    sget-object v0, Lr6/c;->c:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x6

    invoke-static {}, Lr6/c;->i()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object v0, Lr6/c;->c:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Lr6/c;->h()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lr6/c;->c:Ljava/lang/Integer;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lr6/c;->g()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lr6/c;->c:Ljava/lang/Integer;

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lr6/c;->c:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public static d()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lr6/c;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    move v3, v2

    return v0
.end method

.method private static e()Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :catchall_0
    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "oquwnbk"

    const-string/jumbo v0, "unkwobn"

    const/4 v3, 0x3

    const-string/jumbo v0, "knsnouw"

    const-string/jumbo v0, "unknown"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method private static f()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v2, "dummc.e.u.i uorigop.etpirvnrsie"

    const-string v2, "eduitcurr u.e.psoiv.ooii.pmnreg"

    const/4 v5, 0x1

    const-string v2, ".iuoopvo.drectimupro.ei nrsgeio"

    const-string v2, "getprop ro.miui.ui.version.code"

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v3, Ljava/io/InputStreamReader;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v3, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/16 v1, 0x400

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v2, v3, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object v1

    :catchall_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    goto :goto_1

    :catchall_1
    move-exception v1

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    :try_start_3
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_2

    :catch_1
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    throw v0

    :catch_2
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :catch_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    :try_start_4
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4

    const/4 v5, 0x6

    goto :goto_3

    :catch_4
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v0
.end method

.method private static g()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method private static h()Z
    .locals 4

    const/4 v3, 0x7

    invoke-static {}, Lr6/c;->b()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0
.end method

.method private static i()Z
    .locals 4

    const/4 v2, 0x0

    move v3, v2

    invoke-static {}, Lr6/c;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v1, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x1

    move v2, v0

    move v2, v0

    const/4 v3, 0x6

    return v0
.end method

.method private static varargs j(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    array-length v0, p2

    const/4 v5, 0x0

    move v6, v5

    const/4 v1, 0x0

    or-int/2addr v6, v1

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x4

    if-ge v2, v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    aget-object v3, p2, v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v4, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :cond_0
    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x1

    const/4 p0, 0x1

    const/4 v6, 0x4

    move v5, p0

    move v5, p0

    const/4 v6, 0x1

    return p0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v1
.end method

.method public static k()Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lr6/c;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lr6/c;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object v2, Lr6/c;->a:[Ljava/lang/String;

    const/4 v4, 0x4

    invoke-static {v0, v1, v2}, Lr6/c;->j(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v0
.end method

.method public static l(Ljava/lang/String;)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, "++/d/b[p/]-[/^?"

    const-string v0, "d[^/-+/p/?]/+$["

    const/4 v2, 0x0

    const-string v0, "^[-\\+]?[\\d]+$"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x6

    move v2, v1

    return p0
.end method
