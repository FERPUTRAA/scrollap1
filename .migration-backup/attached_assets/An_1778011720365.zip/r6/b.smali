.class public Lr6/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method private static a(Landroid/app/Activity;ZZ)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " is i @~@~b b~~~.@@/fb~ K @dn /@@~@m~S~a ~~@@@olM~ ~ool@i@@  ~-4r@ uo  ~@t~1~@fto~@y @ ~~ sc@~~v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/16 p1, 0x100

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/16 v0, 0x500

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez p1, :cond_2

    const/4 v2, 0x5

    if-eqz p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    :cond_2
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method private static b(Landroid/app/Activity;ZZZZ)V
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0xb
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eqz p3, :cond_6

    :try_start_0
    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz p2, :cond_1

    const/4 v2, 0x4

    if-eqz p4, :cond_0

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 p1, 0x2100

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/16 p1, 0x100

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/16 p3, 0x2500

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/16 v0, 0x500

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p1, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez p2, :cond_3

    const/4 v1, 0x4

    move v2, v1

    if-eqz p4, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p3}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_3
    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p1, :cond_5

    const/4 v1, 0x3

    move v2, v1

    if-eqz p2, :cond_5

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p4, :cond_4

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p3}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_4
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    goto :goto_0

    :cond_5
    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void

    :cond_6
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p4, :cond_7

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 p1, 0x2000

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_7
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private static c(Landroid/app/Activity;ZZZZ)Z
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-class v0, Landroid/view/WindowManager$LayoutParams;

    const-class v0, Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p0, :cond_2

    const/4 v7, 0x2

    invoke-static {p0, p1, p2}, Lr6/b;->a(Landroid/app/Activity;ZZ)V

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v3, "AREmAAADFGBCIO_L_sIS_ZMT_U_SUTR"

    const-string v3, "_RsBDAZALITIUEFT_CAUSRSMOG__A_K"

    const/4 v7, 0x3

    const-string v3, "CLGSoD__ANIASM_UOITARUKR_ZT_AFB"

    const-string v3, "MEIZU_FLAG_DARK_STATUS_BAR_ICON"

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v4, "masegbizFl"

    const-string v4, "giemzsamFl"

    const/4 v7, 0x4

    const-string v4, "eFmsguuial"

    const-string/jumbo v4, "meizuFlags"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v4, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v5, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3, v5}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz p4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    or-int/2addr v3, v5

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    not-int v3, v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    and-int/2addr v3, v5

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Field;->setInt(Ljava/lang/Object;I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {}, Lr6/c;->b()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v1, 0x7

    const/4 v6, 0x1

    or-int/2addr v7, v6

    if-lt v0, v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->b(Landroid/app/Activity;ZZZZ)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    move v1, v4

    move v1, v4

    const/4 v7, 0x4

    move v1, v4

    move v1, v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_1

    :catch_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v1, v4

    move v1, v4

    const/4 v7, 0x7

    move v1, v4

    move v1, v4

    :catch_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->b(Landroid/app/Activity;ZZZZ)V

    :cond_2
    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    return v1
.end method

.method public static d(Landroid/app/Activity;Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    invoke-static {p0, v0, v0, v0, p1}, Lr6/b;->e(Landroid/app/Activity;ZZZZ)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public static e(Landroid/app/Activity;ZZZZ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lr6/c;->c()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eq v0, v1, :cond_2

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x7

    and-int/2addr v2, v1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->b(Landroid/app/Activity;ZZZZ)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->c(Landroid/app/Activity;ZZZZ)Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lr6/c;->d()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v3, 0x4

    if-lt v0, v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->b(Landroid/app/Activity;ZZZZ)V

    const/4 v3, 0x6

    goto :goto_0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->g(Landroid/app/Activity;ZZZZ)Z

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public static f(Landroid/app/Activity;ZZZZ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->e(Landroid/app/Activity;ZZZZ)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private static g(Landroid/app/Activity;ZZZZ)Z
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p0, p1, p2}, Lr6/b;->a(Landroid/app/Activity;ZZ)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x7

    const-string v2, "eurni.epPaaraoiiaLwmuay.woviWstnM$ndrdidoog"

    const-string/jumbo v2, "oMwmoisWiPro$Lvaenoaiideraytr.ud.udaMngawni"

    const-string/jumbo v2, "wiPuesi.qmdentuinnooa$viMaordwLWrgadiraaaMy"

    const-string v2, "android.view.MiuiWindowManager$LayoutParams"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v3, "RRs__MESAAFTb_LXBEADRDS_TUOKAAT"

    const-string v3, "BASS_bAAT__UAER_RTXOTK_LDAEFRMD"

    const/4 v9, 0x1

    const-string v3, "ARUmS_E_LDTKRADTTX_A_FAMGBAS_RE"

    const-string v3, "EXTRA_FLAG_STATUS_BAR_DARK_MODE"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v3, v2}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v3, "FEugostxrtaal"

    const-string/jumbo v3, "teEaagusxFrlt"

    const/4 v9, 0x6

    const-string/jumbo v3, "setExtraFlags"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v4, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x3

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x1

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v9, 0x5

    aput-object v6, v5, v1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/4 v7, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    aput-object v6, v5, v7

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v9, 0x4

    if-eqz p4, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    move v5, v2

    move v5, v2

    const/4 v9, 0x1

    move v5, v2

    move v5, v2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    move v5, v1

    move v5, v1

    const/4 v9, 0x2

    move v5, v1

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    aput-object v5, v4, v1

    const/4 v9, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    aput-object v2, v4, v7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v0, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    return v7

    :catch_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p0, p1, p2, p3, p4}, Lr6/b;->b(Landroid/app/Activity;ZZZZ)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    return v1
.end method
