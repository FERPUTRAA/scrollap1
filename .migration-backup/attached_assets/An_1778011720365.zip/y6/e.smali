.class public final synthetic Ly6/e;
.super Ljava/lang/Object;


# static fields
.field public static final synthetic a:[I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Landroid/widget/ImageView$ScaleType;->values()[Landroid/widget/ImageView$ScaleType;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    array-length v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-array v0, v0, [I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    sput-object v0, Ly6/e;->a:[I

    const/4 v4, 0x3

    sget-object v1, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    aput v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v1, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    aput v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    sget-object v1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    aput v2, v0, v1

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    aput v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_START:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput v2, v0, v1

    const/4 v4, 0x3

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_END:Landroid/widget/ImageView$ScaleType;

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    aput v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v1, Landroid/widget/ImageView$ScaleType;->FIT_XY:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v2, 0x7

    and-int/2addr v4, v2

    const/4 v3, 0x6

    and-int/2addr v4, v3

    aput v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method
