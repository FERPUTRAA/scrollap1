.class public final Ly6/f;
.super Ljava/lang/Object;


# instance fields
.field private a:F

.field private b:F

.field private c:F

.field private d:F

.field private e:F

.field private f:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput v0, p0, Ly6/f;->c:F

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Ly6/f;->d:F

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Ly6/f;->e:F

    const/4 v2, 0x5

    return-void
.end method

.method private final h()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "a@s~K@om ~c@~.@1/~@@@~i@~lb  ~flo  ~f@-~t@@ nb~~u ysS@o~~4oo~ro@~@  ~  /M~idv@@@ ~b    @~~ @t@~i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    iput v0, p0, Ly6/f;->a:F

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Ly6/f;->b:F

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput v0, p0, Ly6/f;->c:F

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput v0, p0, Ly6/f;->d:F

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Ly6/f;->e:F

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-boolean v0, p0, Ly6/f;->f:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Ly6/f;->e:F

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public final b()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Ly6/f;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public final c()F
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget v0, p0, Ly6/f;->c:F

    const/4 v2, 0x1

    const/4 v1, 0x2

    return v0
.end method

.method public final d()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Ly6/f;->d:F

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final e()F
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Ly6/f;->a:F

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public final f()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Ly6/f;->b:F

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public final g(FFFFLandroid/widget/ImageView$ScaleType;)V
    .locals 10
    .param p5    # Landroid/widget/ImageView$ScaleType;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v9, 0x0

    const-string v0, "aecmesysT"

    const-string v0, "Tcspeeays"

    const-string/jumbo v0, "sTplocyae"

    const-string/jumbo v0, "scaleType"

    const/4 v9, 0x3

    invoke-static {p5, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v0, 0x0

    const/4 v9, 0x4

    cmpg-float v1, p1, v0

    if-eqz v1, :cond_8

    const/4 v9, 0x6

    cmpg-float v1, p2, v0

    const/4 v9, 0x0

    if-eqz v1, :cond_8

    const/4 v9, 0x4

    cmpg-float v1, p3, v0

    const/4 v9, 0x4

    if-eqz v1, :cond_8

    const/4 v9, 0x0

    cmpg-float v0, p4, v0

    const/4 v9, 0x2

    if-nez v0, :cond_0

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x7

    invoke-direct {p0}, Ly6/f;->h()V

    const/4 v9, 0x2

    sub-float v0, p1, p3

    const/4 v9, 0x3

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v9, 0x7

    div-float/2addr v0, v1

    const/4 v9, 0x4

    sub-float v2, p2, p4

    const/4 v9, 0x0

    div-float/2addr v2, v1

    const/4 v9, 0x2

    div-float v3, p3, p4

    div-float v4, p1, p2

    const/4 v9, 0x7

    div-float v5, p2, p4

    const/4 v9, 0x2

    div-float v6, p1, p3

    const/4 v9, 0x6

    sget-object v7, Ly6/e;->a:[I

    const/4 v9, 0x6

    invoke-virtual {p5}, Ljava/lang/Enum;->ordinal()I

    move-result p5

    const/4 v9, 0x6

    aget p5, v7, p5

    const/4 v9, 0x2

    const/4 v7, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    packed-switch p5, :pswitch_data_0

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x5

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x7

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x4

    iput v6, p0, Ly6/f;->d:F

    const/4 v9, 0x1

    goto/16 :goto_0

    :pswitch_0
    const/4 v9, 0x2

    invoke-static {v6, v5}, Ljava/lang/Math;->max(FF)F

    move-result p1

    const/4 v9, 0x4

    iput p1, p0, Ly6/f;->e:F

    const/4 v9, 0x4

    cmpl-float p1, v6, v5

    const/4 v9, 0x2

    if-lez p1, :cond_1

    const/4 v9, 0x6

    move v7, v8

    move v7, v8

    move v7, v8

    :cond_1
    const/4 v9, 0x1

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x6

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x2

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x4

    goto/16 :goto_0

    :pswitch_1
    const/4 v9, 0x6

    cmpl-float p5, v3, v4

    const/4 v9, 0x5

    if-lez p5, :cond_2

    const/4 v9, 0x4

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x0

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x0

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x4

    iput v6, p0, Ly6/f;->d:F

    const/4 v9, 0x6

    mul-float/2addr p4, v6

    const/4 v9, 0x0

    sub-float/2addr p2, p4

    iput p2, p0, Ly6/f;->b:F

    const/4 v9, 0x6

    goto/16 :goto_0

    :cond_2
    iput v5, p0, Ly6/f;->e:F

    const/4 v9, 0x3

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x6

    iput v5, p0, Ly6/f;->c:F

    const/4 v9, 0x7

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x0

    mul-float/2addr p3, v5

    const/4 v9, 0x0

    sub-float/2addr p1, p3

    const/4 v9, 0x0

    iput p1, p0, Ly6/f;->a:F

    const/4 v9, 0x2

    goto/16 :goto_0

    :pswitch_2
    const/4 v9, 0x1

    cmpl-float p1, v3, v4

    const/4 v9, 0x3

    if-lez p1, :cond_3

    const/4 v9, 0x5

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x2

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x4

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x0

    iput v6, p0, Ly6/f;->d:F

    const/4 v9, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x7

    iput v5, p0, Ly6/f;->e:F

    const/4 v9, 0x6

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x1

    iput v5, p0, Ly6/f;->c:F

    const/4 v9, 0x1

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x6

    goto/16 :goto_0

    :pswitch_3
    const/4 v9, 0x6

    cmpl-float p5, v3, v4

    const/4 v9, 0x5

    if-lez p5, :cond_4

    const/4 v9, 0x1

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x6

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x3

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x7

    iput v6, p0, Ly6/f;->d:F

    const/4 v9, 0x7

    mul-float/2addr p4, v6

    const/4 v9, 0x3

    sub-float/2addr p2, p4

    const/4 v9, 0x1

    div-float/2addr p2, v1

    const/4 v9, 0x5

    iput p2, p0, Ly6/f;->b:F

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x6

    iput v5, p0, Ly6/f;->e:F

    const/4 v9, 0x4

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x5

    iput v5, p0, Ly6/f;->c:F

    const/4 v9, 0x7

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x6

    mul-float/2addr p3, v5

    const/4 v9, 0x0

    sub-float/2addr p1, p3

    const/4 v9, 0x0

    div-float/2addr p1, v1

    const/4 v9, 0x5

    iput p1, p0, Ly6/f;->a:F

    const/4 v9, 0x7

    goto/16 :goto_0

    :pswitch_4
    const/4 v9, 0x6

    cmpg-float p5, p3, p1

    const/4 v9, 0x2

    if-gez p5, :cond_5

    const/4 v9, 0x2

    cmpg-float p5, p4, p2

    const/4 v9, 0x6

    if-gez p5, :cond_5

    const/4 v9, 0x7

    iput v0, p0, Ly6/f;->a:F

    const/4 v9, 0x3

    iput v2, p0, Ly6/f;->b:F

    const/4 v9, 0x0

    goto :goto_0

    :cond_5
    const/4 v9, 0x0

    cmpl-float p5, v3, v4

    const/4 v9, 0x4

    if-lez p5, :cond_6

    const/4 v9, 0x3

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x1

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x1

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x0

    iput v6, p0, Ly6/f;->d:F

    mul-float/2addr p4, v6

    const/4 v9, 0x6

    sub-float/2addr p2, p4

    const/4 v9, 0x3

    div-float/2addr p2, v1

    const/4 v9, 0x5

    iput p2, p0, Ly6/f;->b:F

    const/4 v9, 0x5

    goto :goto_0

    :cond_6
    const/4 v9, 0x4

    iput v5, p0, Ly6/f;->e:F

    const/4 v9, 0x2

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x4

    iput v5, p0, Ly6/f;->c:F

    const/4 v9, 0x3

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x1

    mul-float/2addr p3, v5

    const/4 v9, 0x6

    sub-float/2addr p1, p3

    const/4 v9, 0x1

    div-float/2addr p1, v1

    const/4 v9, 0x7

    iput p1, p0, Ly6/f;->a:F

    const/4 v9, 0x6

    goto :goto_0

    :pswitch_5
    cmpl-float p5, v3, v4

    const/4 v9, 0x4

    if-lez p5, :cond_7

    const/4 v9, 0x4

    iput v5, p0, Ly6/f;->e:F

    const/4 v9, 0x1

    iput-boolean v7, p0, Ly6/f;->f:Z

    const/4 v9, 0x5

    iput v5, p0, Ly6/f;->c:F

    const/4 v9, 0x5

    iput v5, p0, Ly6/f;->d:F

    const/4 v9, 0x7

    mul-float/2addr p3, v5

    const/4 v9, 0x2

    sub-float/2addr p1, p3

    const/4 v9, 0x7

    div-float/2addr p1, v1

    const/4 v9, 0x5

    iput p1, p0, Ly6/f;->a:F

    const/4 v9, 0x3

    goto :goto_0

    :cond_7
    const/4 v9, 0x3

    iput v6, p0, Ly6/f;->e:F

    const/4 v9, 0x0

    iput-boolean v8, p0, Ly6/f;->f:Z

    const/4 v9, 0x6

    iput v6, p0, Ly6/f;->c:F

    const/4 v9, 0x4

    iput v6, p0, Ly6/f;->d:F

    const/4 v9, 0x6

    mul-float/2addr p4, v6

    const/4 v9, 0x4

    sub-float/2addr p2, p4

    const/4 v9, 0x7

    div-float/2addr p2, v1

    const/4 v9, 0x1

    iput p2, p0, Ly6/f;->b:F

    const/4 v9, 0x6

    goto :goto_0

    :pswitch_6
    iput v0, p0, Ly6/f;->a:F

    const/4 v9, 0x7

    iput v2, p0, Ly6/f;->b:F

    :cond_8
    :goto_0
    const/4 v9, 0x7

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i(F)V
    .locals 2

    const/4 v1, 0x4

    iput p1, p0, Ly6/f;->e:F

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public final j(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p1, p0, Ly6/f;->f:Z

    const/4 v1, 0x5

    return-void
.end method

.method public final k(F)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Ly6/f;->c:F

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public final l(F)V
    .locals 2

    const/4 v1, 0x5

    iput p1, p0, Ly6/f;->d:F

    const/4 v1, 0x2

    return-void
.end method

.method public final m(F)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Ly6/f;->a:F

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public final n(F)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Ly6/f;->b:F

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method
