.class public final Ly6/b;
.super Ljava/lang/Object;


# instance fields
.field private final a:F

.field private final b:F

.field private final c:F


# direct methods
.method public constructor <init>(FFF)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Ly6/b;->a:F

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p2, p0, Ly6/b;->b:F

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p3, p0, Ly6/b;->c:F

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a()F
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "afs@ov-o~ @~t~.1b~ M@@ ~ ~~~ @ @@~@ b y @/mo~/u@b~@~d@~ t~lKrso  f @o@~ ~~~ @ inS4o@ic~i~~l@~@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget v0, p0, Ly6/b;->c:F

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public final b()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Ly6/b;->a:F

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public final c()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Ly6/b;->b:F

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
