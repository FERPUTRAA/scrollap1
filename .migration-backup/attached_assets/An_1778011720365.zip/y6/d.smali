.class public final Ly6/d;
.super Ljava/lang/Object;


# instance fields
.field private final a:D

.field private final b:D

.field private final c:D

.field private final d:D


# direct methods
.method public constructor <init>(DDDD)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-wide p1, p0, Ly6/d;->a:D

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-wide p3, p0, Ly6/d;->b:D

    const/4 v1, 0x3

    iput-wide p5, p0, Ly6/d;->c:D

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p7, p0, Ly6/d;->d:D

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public final a()D
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @sm@@o~~vou~st /- @~~ @~o d@~faKS@f  ~l@r@@ @~@M~ o.~ b @n~@~cl/o@b~~@ b ~y4  @oi~~~@ @~ t1~i@i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-wide v0, p0, Ly6/d;->d:D

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-wide v0
.end method

.method public final b()D
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-wide v0, p0, Ly6/d;->c:D

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-wide v0
.end method

.method public final c()D
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-wide v0, p0, Ly6/d;->a:D

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide v0
.end method

.method public final d()D
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-wide v0, p0, Ly6/d;->b:D

    const/4 v2, 0x7

    move v3, v2

    return-wide v0
.end method
