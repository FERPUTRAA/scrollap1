.class public final Ly6/c;
.super Ljava/lang/Object;


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Ly6/c;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p2, p0, Ly6/c;->b:I

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b s-~ @l yd ~ ~~u4 @o~ a~ttv f1b@@o~~@@@ @~ @@@~c~~  @rnioi@ ~/~~@@Mo @ o@/@~~o.bsSi~ ~~ K@fl~m~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Ly6/c;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public final b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Ly6/c;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method
