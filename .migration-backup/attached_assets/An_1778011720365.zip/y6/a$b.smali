.class public Ly6/a$b;
.super Ljava/lang/Object;

# interfaces
.implements Ly6/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ly6/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ly6/a$a<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPools.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Pools.kt\ncom/opensource/svgaplayer/utils/Pools$SimplePool\n*L\n1#1,102:1\n*E\n"
.end annotation


# instance fields
.field private final a:[Ljava/lang/Object;

.field private b:I


# direct methods
.method public constructor <init>(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-lez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v1, 0x2

    iput-object p1, p0, Ly6/a$b;->a:[Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, " ms h moe osa sel>uxib T0 ept"

    const-string/jumbo v0, "usseos eh b  >0axTpm tm lioe "

    const/4 v2, 0x0

    const-string v0, "easmoz e p sT tm xulh io0m> b"

    const-string v0, "The max pool size must be > 0"

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    throw p1
.end method

.method private final c(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~@do ~~m  lo  M@~  ~@@io~@f s@ f~~@~y ~u@b@~oi4@bo~l~b-~1~.@~@o @ ~Sn K@/@~c~@ @~ / @ar~v@ti to"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget v0, p0, Ly6/a$b;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    move v2, v1

    move v2, v1

    const/4 v5, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x1

    if-ge v2, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, p0, Ly6/a$b;->a:[Ljava/lang/Object;

    const/4 v5, 0x3

    aget-object v3, v3, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne v3, p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 p1, 0x1

    shl-int/2addr v5, p1

    const/4 v4, 0x2

    const/4 v4, 0x7

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v1
.end method


# virtual methods
.method public a(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p0, p1}, Ly6/a$b;->c(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    xor-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v0, p0, Ly6/a$b;->b:I

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    iget-object v2, p0, Ly6/a$b;->a:[Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    array-length v3, v2

    const/4 v5, 0x6

    if-ge v0, v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    aput-object p1, v2, v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v0, p0, Ly6/a$b;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    return p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v0, "l oetbpy!Arh lmaden "

    const-string/jumbo v0, "t !moeryl  epalAdihn"

    const/4 v5, 0x0

    const-string v0, "dotl! ueihA alpeoy r"

    const-string v0, "Already in the pool!"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw p1
.end method

.method public b()Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget v0, p0, Ly6/a$b;->b:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x5

    if-lez v0, :cond_0

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/lit8 v2, v0, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v3, p0, Ly6/a$b;->a:[Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-object v4, v3, v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    aput-object v1, v3, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x3

    iput v0, p0, Ly6/a$b;->b:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object v4

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v1
.end method
