.class public Lh7/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/rd/draw/data/a;

.field private b:Lcom/rd/draw/controller/b;

.field private c:Lcom/rd/draw/controller/c;

.field private d:Lcom/rd/draw/controller/a;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Lcom/rd/draw/data/a;

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/rd/draw/data/a;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v1, Lcom/rd/draw/controller/b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v1, v0}, Lcom/rd/draw/controller/b;-><init>(Lcom/rd/draw/data/a;)V

    const/4 v3, 0x1

    iput-object v1, p0, Lh7/a;->b:Lcom/rd/draw/controller/b;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/rd/draw/controller/c;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/rd/draw/controller/c;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lh7/a;->c:Lcom/rd/draw/controller/c;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/rd/draw/controller/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/rd/draw/controller/a;-><init>(Lcom/rd/draw/data/a;)V

    const/4 v3, 0x4

    iput-object v0, p0, Lh7/a;->d:Lcom/rd/draw/controller/a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "m@s~~o~@4/i ~~ s@@@ vi~~ dtiS  b@ oo~~~o@@~~@~~ ~r@o~~@@-/@@ucl @ ~~ ~ y~1.Kft@@f@~b bal@Mn@  o "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lh7/a;->b:Lcom/rd/draw/controller/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/rd/draw/controller/b;->a(Landroid/graphics/Canvas;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public b()Lcom/rd/draw/data/a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-object v0, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lcom/rd/draw/data/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/rd/draw/data/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    iget-object v0, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public c(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lh7/a;->d:Lcom/rd/draw/controller/a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Lcom/rd/draw/controller/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public d(II)Landroid/util/Pair;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lh7/a;->c:Lcom/rd/draw/controller/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lh7/a;->a:Lcom/rd/draw/data/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1, p2}, Lcom/rd/draw/controller/c;->a(Lcom/rd/draw/data/a;II)Landroid/util/Pair;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1
.end method

.method public e(Lcom/rd/draw/controller/b$b;)V
    .locals 3
    .param p1    # Lcom/rd/draw/controller/b$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lh7/a;->b:Lcom/rd/draw/controller/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/rd/draw/controller/b;->e(Lcom/rd/draw/controller/b$b;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public f(Landroid/view/MotionEvent;)V
    .locals 3
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lh7/a;->b:Lcom/rd/draw/controller/b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/rd/draw/controller/b;->f(Landroid/view/MotionEvent;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public g(Lf7/b;)V
    .locals 3
    .param p1    # Lf7/b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lh7/a;->b:Lcom/rd/draw/controller/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Lcom/rd/draw/controller/b;->g(Lf7/b;)V

    const/4 v2, 0x4

    return-void
.end method
