.class public La7/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroidx/fragment/app/Fragment;)La7/b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s@~@a ~~~@~dtf-~ v@ ~l~o ~u  @~o@/K@@1i@nb 4~o ~mi@fc@bS~.@s/@o ~M~@@to rlo @~  @@@ ~~~b~~ y@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, La7/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {v0, p0}, La7/b;-><init>(Landroidx/fragment/app/Fragment;)V

    const/4 v2, 0x4

    return-object v0
.end method

.method public static b(Landroidx/fragment/app/FragmentActivity;)La7/b;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, La7/b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0}, La7/b;-><init>(Landroidx/fragment/app/FragmentActivity;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-nez p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p0, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 p0, 0x0

    move v1, p0

    :goto_0
    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method
