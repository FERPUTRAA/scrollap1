.class public final La7/b;
.super Ljava/lang/Object;


# instance fields
.field private a:Landroidx/fragment/app/FragmentActivity;
    .annotation build Lia/e;
    .end annotation
.end field

.field private b:Landroidx/fragment/app/Fragment;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/fragment/app/Fragment;)V
    .locals 3
    .param p1    # Landroidx/fragment/app/Fragment;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo v0, "mnsgtfea"

    const-string v0, "fragment"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, La7/b;->b:Landroidx/fragment/app/Fragment;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroidx/fragment/app/FragmentActivity;)V
    .locals 3
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "ycimatst"

    const-string v0, "ctsyiavt"

    const/4 v2, 0x1

    const-string v0, "aitcoivy"

    const-string v0, "activity"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, La7/b;->a:Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/List;)Ld7/r;
    .locals 8
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ld7/r;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v0, "srnsmboseii"

    const-string/jumbo v0, "nrimsssepio"

    const/4 v7, 0x6

    const-string v0, "eomiisunrsp"

    const-string/jumbo v0, "permissions"

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance v1, Ljava/util/LinkedHashSet;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v3, p0, La7/b;->a:Landroidx/fragment/app/FragmentActivity;

    const/4 v7, 0x7

    if-eqz v3, :cond_0

    const/4 v7, 0x0

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget v3, v3, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, p0, La7/b;->b:Landroidx/fragment/app/Fragment;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x7

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget v3, v3, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    :goto_0
    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {}, Lcom/permissionx/guolindev/dialog/b;->a()Ljava/util/Set;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v5, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v5, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    or-int/2addr v7, v6

    goto :goto_1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    const-string p1, "ITe.nadpm_NOpnrLosAoAdUiSiCCRCGDosNEOAB_KO.iS"

    const-string p1, "dimIo_BOEOCAAK.SN.URaCOpNLrnoSD_ionAsdTCesirG"

    const-string/jumbo p1, "n.iAGTCnqKsBdDrAo_CdSOi._aUNOSOirCLECpNsoIARm"

    const-string p1, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v4, :cond_4

    const/4 v7, 0x1

    const/16 v4, 0x1d

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eq v2, v4, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/16 v4, 0x1e

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ne v2, v4, :cond_4

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ge v3, v4, :cond_4

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance p1, Ld7/r;

    const/4 v7, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, La7/b;->a:Landroidx/fragment/app/FragmentActivity;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v3, p0, La7/b;->b:Landroidx/fragment/app/Fragment;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {p1, v2, v3, v0, v1}, Ld7/r;-><init>(Landroidx/fragment/app/FragmentActivity;Landroidx/fragment/app/Fragment;Ljava/util/Set;Ljava/util/Set;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-object p1
.end method

.method public final varargs b([Ljava/lang/String;)Ld7/r;
    .locals 3
    .param p1    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "issbenpsois"

    const-string/jumbo v0, "ssepsbnimio"

    const/4 v2, 0x2

    const-string/jumbo v0, "opsmermssii"

    const-string/jumbo v0, "permissions"

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    array-length v0, p1

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Lkotlin/collections/u;->L([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, La7/b;->a(Ljava/util/List;)Ld7/r;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1
.end method
