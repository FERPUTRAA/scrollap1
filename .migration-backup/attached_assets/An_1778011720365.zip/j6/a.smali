.class public final Lj6/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/zxing/p;


# static fields
.field private static final b:[Lcom/google/zxing/t;

.field private static final c:I = 0x1e

.field private static final d:I = 0x21


# instance fields
.field private final a:Lcom/google/zxing/maxicode/decoder/c;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-array v0, v0, [Lcom/google/zxing/t;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lj6/a;->b:[Lcom/google/zxing/t;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/zxing/maxicode/decoder/c;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/zxing/maxicode/decoder/c;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lj6/a;->a:Lcom/google/zxing/maxicode/decoder/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private static b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/b;
    .locals 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;
        }
    .end annotation

    invoke-virtual {p0}, Lcom/google/zxing/common/b;->g()[I

    move-result-object v0

    if-eqz v0, :cond_3

    const/4 v1, 0x0

    aget v2, v0, v1

    const/4 v3, 0x1

    aget v3, v0, v3

    const/4 v4, 0x2

    aget v5, v0, v4

    const/4 v6, 0x3

    aget v0, v0, v6

    new-instance v6, Lcom/google/zxing/common/b;

    const/16 v7, 0x1e

    const/16 v8, 0x21

    invoke-direct {v6, v7, v8}, Lcom/google/zxing/common/b;-><init>(II)V

    move v9, v1

    move v9, v1

    move v9, v1

    move v9, v1

    :goto_0
    if-ge v9, v8, :cond_2

    mul-int v10, v9, v0

    div-int/lit8 v11, v0, 0x2

    add-int/2addr v10, v11

    div-int/2addr v10, v8

    add-int/2addr v10, v3

    move v11, v1

    move v11, v1

    move v11, v1

    move v11, v1

    :goto_1
    if-ge v11, v7, :cond_1

    mul-int v12, v11, v5

    div-int/lit8 v13, v5, 0x2

    add-int/2addr v12, v13

    and-int/lit8 v13, v9, 0x1

    mul-int/2addr v13, v5

    div-int/2addr v13, v4

    add-int/2addr v12, v13

    div-int/2addr v12, v7

    add-int/2addr v12, v2

    invoke-virtual {p0, v12, v10}, Lcom/google/zxing/common/b;->e(II)Z

    move-result v12

    if-eqz v12, :cond_0

    invoke-virtual {v6, v11, v9}, Lcom/google/zxing/common/b;->o(II)V

    :cond_0
    add-int/lit8 v11, v11, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    :cond_2
    return-object v6

    :cond_3
    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p0

    throw p0
.end method


# virtual methods
.method public a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/zxing/c;",
            "Ljava/util/Map<",
            "Lcom/google/zxing/e;",
            "*>;)",
            "Lcom/google/zxing/r;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x4

    if-eqz p2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v0, Lcom/google/zxing/e;->b:Lcom/google/zxing/e;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p2, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/zxing/c;->b()Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Lj6/a;->b(Lcom/google/zxing/common/b;)Lcom/google/zxing/common/b;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lj6/a;->a:Lcom/google/zxing/maxicode/decoder/c;

    const/4 v5, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/google/zxing/maxicode/decoder/c;->c(Lcom/google/zxing/common/b;Ljava/util/Map;)Lcom/google/zxing/common/e;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p2, Lcom/google/zxing/r;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->j()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->g()[B

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v2, Lj6/a;->b:[Lcom/google/zxing/t;

    const/4 v5, 0x1

    sget-object v3, Lcom/google/zxing/a;->j:Lcom/google/zxing/a;

    const/4 v5, 0x5

    invoke-direct {p2, v0, v1, v2, v3}, Lcom/google/zxing/r;-><init>(Ljava/lang/String;[B[Lcom/google/zxing/t;Lcom/google/zxing/a;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/zxing/common/e;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v0, Lcom/google/zxing/s;->d:Lcom/google/zxing/s;

    const/4 v5, 0x0

    invoke-virtual {p2, v0, p1}, Lcom/google/zxing/r;->j(Lcom/google/zxing/s;Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v4, 0x0

    return-object p2

    :cond_1
    const/4 v5, 0x6

    invoke-static {}, Lcom/google/zxing/m;->a()Lcom/google/zxing/m;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p1
.end method

.method public c(Lcom/google/zxing/c;)Lcom/google/zxing/r;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/zxing/m;,
            Lcom/google/zxing/d;,
            Lcom/google/zxing/h;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lj6/a;->a(Lcom/google/zxing/c;Ljava/util/Map;)Lcom/google/zxing/r;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public reset()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method
