.class public interface abstract Lo7/c;
.super Ljava/lang/Object;

# interfaces
.implements Lo7/a;


# virtual methods
.method public abstract setNoMoreData(Z)Z
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;,
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;,
            .enum Landroidx/annotation/a1$a;->f:Landroidx/annotation/a1$a;
        }
    .end annotation
.end method
