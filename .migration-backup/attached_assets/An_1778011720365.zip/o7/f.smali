.class public interface abstract Lo7/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract A(Lo7/d;)Lo7/f;
    .param p1    # Lo7/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract B(I)Lo7/f;
.end method

.method public varargs abstract C([I)Lo7/f;
    .param p1    # [I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
.end method

.method public abstract D(I)Lo7/f;
.end method

.method public abstract E()Z
.end method

.method public abstract F(Z)Lo7/f;
.end method

.method public abstract G(Z)Lo7/f;
.end method

.method public abstract H(Z)Lo7/f;
.end method

.method public abstract I(Z)Lo7/f;
.end method

.method public abstract J(Z)Lo7/f;
.end method

.method public abstract K(Z)Lo7/f;
.end method

.method public abstract L(F)Lo7/f;
.end method

.method public abstract M(IZLjava/lang/Boolean;)Lo7/f;
.end method

.method public abstract N()Z
.end method

.method public abstract O(Z)Lo7/f;
.end method

.method public abstract P(Z)Lo7/f;
.end method

.method public abstract Q(Z)Lo7/f;
.end method

.method public abstract R(I)Z
.end method

.method public abstract S(Z)Lo7/f;
.end method

.method public abstract T()Lo7/f;
.end method

.method public abstract U(I)Lo7/f;
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
.end method

.method public abstract V(Lq7/f;)Lo7/f;
.end method

.method public abstract W()Lo7/f;
.end method

.method public abstract X(Z)Lo7/f;
.end method

.method public abstract Y(I)Lo7/f;
.end method

.method public abstract Z(F)Lo7/f;
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 1.0
            to = 10.0
        .end annotation
    .end param
.end method

.method public abstract a(Z)Lo7/f;
.end method

.method public abstract a0(IIFZ)Z
.end method

.method public abstract b()Z
.end method

.method public abstract b0()Z
.end method

.method public abstract c(Lq7/j;)Lo7/f;
.end method

.method public abstract c0(I)Lo7/f;
.end method

.method public abstract d()Z
.end method

.method public abstract d0(Lq7/e;)Lo7/f;
.end method

.method public abstract e(Z)Lo7/f;
.end method

.method public abstract e0(I)Lo7/f;
.end method

.method public abstract f(Landroid/view/View;)Lo7/f;
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract f0(Landroid/view/View;II)Lo7/f;
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract g(Lq7/g;)Lo7/f;
.end method

.method public abstract g0()Lo7/f;
.end method

.method public abstract getLayout()Landroid/view/ViewGroup;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public abstract getRefreshFooter()Lo7/c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end method

.method public abstract getRefreshHeader()Lo7/d;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end method

.method public abstract getState()Lcom/scwang/smart/refresh/layout/constant/b;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public abstract h(F)Lo7/f;
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
.end method

.method public abstract h0(F)Lo7/f;
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 1.0
            to = 10.0
        .end annotation
    .end param
.end method

.method public abstract i(I)Z
.end method

.method public abstract i0()Z
.end method

.method public abstract j(Z)Lo7/f;
.end method

.method public abstract j0(Z)Lo7/f;
.end method

.method public abstract k(Lo7/c;II)Lo7/f;
    .param p1    # Lo7/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract l(F)Lo7/f;
.end method

.method public abstract l0(Lo7/d;II)Lo7/f;
    .param p1    # Lo7/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract m(I)Lo7/f;
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
.end method

.method public abstract n(Z)Lo7/f;
.end method

.method public abstract n0()Lo7/f;
.end method

.method public abstract o(I)Lo7/f;
.end method

.method public abstract o0(Lq7/h;)Lo7/f;
.end method

.method public abstract p()Lo7/f;
.end method

.method public abstract q(Lo7/c;)Lo7/f;
    .param p1    # Lo7/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract q0(IZZ)Lo7/f;
.end method

.method public abstract r(Z)Lo7/f;
.end method

.method public abstract r0(Landroid/view/animation/Interpolator;)Lo7/f;
    .param p1    # Landroid/view/animation/Interpolator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract setNoMoreData(Z)Lo7/f;
.end method

.method public varargs abstract setPrimaryColors([I)Lo7/f;
    .param p1    # [I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
.end method

.method public abstract t()Lo7/f;
.end method

.method public abstract t0(Z)Lo7/f;
.end method

.method public abstract u(IIFZ)Z
.end method

.method public abstract v(F)Lo7/f;
.end method

.method public abstract v0(F)Lo7/f;
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
.end method

.method public abstract w(F)Lo7/f;
.end method

.method public abstract x(F)Lo7/f;
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
.end method

.method public abstract x0(I)Lo7/f;
.end method

.method public abstract y(Z)Lo7/f;
.end method

.method public abstract z(I)Lo7/f;
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
.end method

.method public abstract z0(I)Lo7/f;
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
.end method
