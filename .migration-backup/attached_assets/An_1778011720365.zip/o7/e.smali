.class public interface abstract Lo7/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(F)Lo7/e;
.end method

.method public abstract b()Lo7/e;
.end method

.method public abstract c(I)Landroid/animation/ValueAnimator;
.end method

.method public abstract d(Lo7/a;I)Lo7/e;
    .param p1    # Lo7/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract e(Lo7/a;Z)Lo7/e;
    .param p1    # Lo7/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract f(I)Lo7/e;
.end method

.method public abstract g(Z)Lo7/e;
.end method

.method public abstract h(IZ)Lo7/e;
.end method

.method public abstract i(Lo7/a;Z)Lo7/e;
    .param p1    # Lo7/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract j(Lo7/a;)Lo7/e;
    .param p1    # Lo7/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract k()Lo7/b;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public abstract l()Lo7/f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public abstract m(Lcom/scwang/smart/refresh/layout/constant/b;)Lo7/e;
    .param p1    # Lcom/scwang/smart/refresh/layout/constant/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
