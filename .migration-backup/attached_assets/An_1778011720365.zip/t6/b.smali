.class public Lt6/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public static a(I)Ljava/util/Locale;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~dsM-~ri~4~@o~~l fl@n@t m f@~1v ~ ~/~@ ~io @b@~ ~ o~o@~ ~b co@@  ~a/  @~oKs~ti.~@@@ @y@ S~@bu~@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    packed-switch p0, :pswitch_data_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    sget-object p0, Ljava/util/Locale;->CHINESE:Ljava/util/Locale;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0

    :pswitch_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p0, Ljava/util/Locale;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v0, "ur"

    const-string/jumbo v0, "ru"

    const/4 v3, 0x7

    const-string/jumbo v0, "ur"

    const-string/jumbo v0, "ru"

    const/4 v2, 0x0

    move v3, v2

    const-string/jumbo v1, "rUR"

    const-string v1, "RUr"

    const/4 v3, 0x7

    const-string v1, "URr"

    const-string/jumbo v1, "rRU"

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-direct {p0, v0, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object p0

    :pswitch_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p0, Ljava/util/Locale;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const-string v0, "ar"

    const-string/jumbo v0, "ra"

    const/4 v3, 0x3

    const-string v0, "ar"

    const-string v0, "ar"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "AE"

    const-string v1, "EA"

    const/4 v3, 0x2

    const-string v1, "EA"

    const-string v1, "AE"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, v0, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    move v3, v2

    return-object p0

    :pswitch_2
    const/4 v2, 0x6

    new-instance p0, Ljava/util/Locale;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "tp"

    const-string/jumbo v0, "tp"

    const/4 v3, 0x0

    const-string/jumbo v0, "pt"

    const-string/jumbo v0, "pt"

    const/4 v3, 0x0

    const-string v1, "PT"

    const-string v1, "TP"

    const/4 v3, 0x3

    const-string v1, "PT"

    const-string v1, "PT"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0

    :pswitch_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/util/Locale;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v0, "se"

    const/4 v3, 0x1

    const-string v0, "es"

    const-string v0, "es"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "SE"

    const-string v1, "SE"

    const/4 v3, 0x0

    const-string v1, "SE"

    const-string v1, "ES"

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p0, v0, v1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object p0

    :pswitch_4
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p0, Ljava/util/Locale;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "vi"

    const/4 v3, 0x2

    const-string/jumbo v0, "iv"

    const-string/jumbo v0, "vi"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p0

    :pswitch_5
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object p0, Ljava/util/Locale;->JAPAN:Ljava/util/Locale;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :pswitch_6
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object p0, Ljava/util/Locale;->FRANCE:Ljava/util/Locale;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :pswitch_7
    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object p0, Ljava/util/Locale;->GERMANY:Ljava/util/Locale;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0

    :pswitch_8
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object p0, Ljava/util/Locale;->KOREA:Ljava/util/Locale;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p0

    :pswitch_9
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object p0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v3, 0x0

    return-object p0

    :pswitch_a
    const/4 v3, 0x2

    const/4 v2, 0x6

    sget-object p0, Ljava/util/Locale;->TRADITIONAL_CHINESE:Ljava/util/Locale;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
