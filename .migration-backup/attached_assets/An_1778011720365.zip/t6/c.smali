.class public Lt6/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "KEY_LOCALE"

.field private static final b:Ljava/lang/String; = "VALUE_FOLLOW_SYSTEM"


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "n.st utasa/ec..tmtn s /nii"

    const-string v1, " tsnatnm tin.s.u/ceait.a /"

    const-string/jumbo v1, "nsnma tcaattui/em.t/i e n."

    const-string/jumbo v1, "u can\'t instantiate me..."

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    throw v0
.end method

.method private static a(Landroid/content/Context;Ljava/util/Locale;)V
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/Locale;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@~ ob a @1~y i~i ~i~dc~~M~K~rlb@~4.~@m~@-t/bs@o~@ @ oo@/  ~f~@ ~oSo@@~v @o ~l@ @~@@ @u~tf @~@ n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lt6/c;->b(Landroid/content/Context;Ljava/util/Locale;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method private static b(Landroid/content/Context;Ljava/util/Locale;Z)V
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/Locale;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    move v4, v3

    const-string v0, "YLACLbOmE_"

    const-string v0, "CEYmLOL_AE"

    const/4 v4, 0x2

    const-string v0, "CEOA_KuYLE"

    const-string v0, "KEY_LOCALE"

    const/4 v4, 0x3

    if-eqz p2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string p2, "AOTOoSWpL_F_EELUYLM"

    const-string p2, "SM_WoOLAF_ETLLVUEOY"

    const/4 v4, 0x6

    const-string p2, "LELOFVESqW_AOSULTM_"

    const-string p2, "VALUE_FOLLOW_SYSTEM"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p0, v0, p2}, Lcom/luck/picture/lib/utils/q;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p2, "$"

    const-string p2, "$"

    const/4 v4, 0x0

    const-string p2, "$"

    const-string p2, "$"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v0, p2}, Lcom/luck/picture/lib/utils/q;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, p1}, Lt6/c;->f(Landroid/content/Context;Ljava/util/Locale;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method private static c(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-ne p0, p1, :cond_0

    const/4 v7, 0x4

    return v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p0, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x3

    if-eqz p1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ne v2, v3, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    instance-of v3, p0, Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v3, :cond_1

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    instance-of v3, p1, Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    return p0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge v3, v2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {p0, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p1, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eq v4, v5, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    return v1

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    return v0

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    return v1
.end method

.method public static d(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-ltz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p0, Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lt6/b;->a(I)Ljava/util/Locale;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lt6/c;->a(Landroid/content/Context;Ljava/util/Locale;)V

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lt6/c;->e(Landroid/content/Context;)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method private static e(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v3}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void
.end method

.method private static f(Landroid/content/Context;Ljava/util/Locale;)V
    .locals 7

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, v1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-static {v3, v4}, Lt6/c;->c(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lt6/c;->c(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0, v1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    const/4 v6, 0x7

    return-void
.end method
