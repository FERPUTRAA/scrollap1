.class public final Lg6/a;
.super Lcom/google/zxing/common/g;


# instance fields
.field private final c:Z

.field private final d:I

.field private final e:I


# direct methods
.method public constructor <init>(Lcom/google/zxing/common/b;[Lcom/google/zxing/t;ZII)V
    .locals 2

    invoke-direct {p0, p1, p2}, Lcom/google/zxing/common/g;-><init>(Lcom/google/zxing/common/b;[Lcom/google/zxing/t;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-boolean p3, p0, Lg6/a;->c:Z

    const/4 v1, 0x1

    iput p4, p0, Lg6/a;->d:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p5, p0, Lg6/a;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public c()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@s~  @  m ~orb  b/~@   s@obnoi@fl@ @t/S~ @u~y~ -d@ ~ ~4~@~.~fv@~ ~1@~@ ~@M@~o~la@c~@o~K~t~@~i@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget v0, p0, Lg6/a;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lg6/a;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public e()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-boolean v0, p0, Lg6/a;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method
