.class public final Lc7/b;
.super Ljava/lang/Object;

# interfaces
.implements Ln0/b;


# instance fields
.field private final a:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final b:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final c:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/ImageView;Landroid/widget/TextView;)V
    .locals 2
    .param p1    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lc7/b;->a:Landroid/widget/LinearLayout;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lc7/b;->b:Landroid/widget/ImageView;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p3, p0, Lc7/b;->c:Landroid/widget/TextView;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/view/View;)Lc7/b;
    .locals 5
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "y.si~@M~ @~vf  t~S~@@ /o f~~ /-od@o~~ bm~@u@@o@~~n  ~i b @~ r@1~@b ~@  @~la~@~~ @ ~@@osK4@t~@cil"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    sget v0, Lcom/permissionx/guolindev/R$id;->permissionIcon:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v1, Landroid/widget/ImageView;

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget v0, Lcom/permissionx/guolindev/R$id;->permissionText:I

    const/4 v4, 0x1

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast v2, Landroid/widget/TextView;

    const/4 v3, 0x3

    move v4, v3

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lc7/b;

    const/4 v3, 0x4

    move v4, v3

    check-cast p0, Landroid/widget/LinearLayout;

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1, v2}, Lc7/b;-><init>(Landroid/widget/LinearLayout;Landroid/widget/ImageView;Landroid/widget/TextView;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "isimns ue iMrrs qw vDid ithIge:"

    const-string/jumbo v1, "vwsud si ir rteegqihiDi es Mn:I"

    const/4 v4, 0x3

    const-string v1, " gseoentww:vq Murhi I ri dieiis"

    const-string v1, "Missing required view with ID: "

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    move v4, v3

    throw v0
.end method

.method public static c(Landroid/view/LayoutInflater;)Lc7/b;
    .locals 4
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    shr-int/2addr v2, v1

    const/4 v3, 0x4

    invoke-static {p0, v0, v1}, Lc7/b;->d(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lc7/b;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0
.end method

.method public static d(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lc7/b;
    .locals 4
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget v0, Lcom/permissionx/guolindev/R$layout;->permissionx_permission_item:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Lc7/b;->a(Landroid/view/View;)Lc7/b;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0
.end method


# virtual methods
.method public b()Landroid/widget/LinearLayout;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lc7/b;->a:Landroid/widget/LinearLayout;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Lc7/b;->b()Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method
