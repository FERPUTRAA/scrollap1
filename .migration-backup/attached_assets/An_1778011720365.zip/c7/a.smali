.class public final Lc7/a;
.super Ljava/lang/Object;

# interfaces
.implements Ln0/b;


# instance fields
.field private final a:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final b:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final c:Landroid/widget/Button;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final d:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final e:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final f:Landroid/widget/Button;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final g:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/Button;Landroid/widget/LinearLayout;)V
    .locals 2
    .param p1    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/widget/Button;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p6    # Landroid/widget/Button;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lc7/a;->a:Landroid/widget/LinearLayout;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lc7/a;->b:Landroid/widget/TextView;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p3, p0, Lc7/a;->c:Landroid/widget/Button;

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput-object p4, p0, Lc7/a;->d:Landroid/widget/LinearLayout;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p5, p0, Lc7/a;->e:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p6, p0, Lc7/a;->f:Landroid/widget/Button;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p7, p0, Lc7/a;->g:Landroid/widget/LinearLayout;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/view/View;)Lc7/a;
    .locals 12
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v10, "~os@@~~t@@@ /M~ b  @@@ ~tl@@1@~ ~~l~f@@o  @ y di~~~~uS  @ ~v~o@rso o~@@ia f-~~ .m/icn b~@~boK~@4"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x2

    sget v0, Lcom/permissionx/guolindev/R$id;->messageText:I

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    const/4 v11, 0x0

    const/4 v10, 0x2

    check-cast v4, Landroid/widget/TextView;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-eqz v4, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget v0, Lcom/permissionx/guolindev/R$id;->negativeBtn:I

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    check-cast v5, Landroid/widget/Button;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-eqz v5, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    sget v0, Lcom/permissionx/guolindev/R$id;->negativeLayout:I

    const/4 v11, 0x2

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    check-cast v6, Landroid/widget/LinearLayout;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-eqz v6, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    sget v0, Lcom/permissionx/guolindev/R$id;->permissionsLayout:I

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    check-cast v7, Landroid/widget/LinearLayout;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz v7, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    sget v0, Lcom/permissionx/guolindev/R$id;->positiveBtn:I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    check-cast v8, Landroid/widget/Button;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-eqz v8, :cond_0

    const/4 v10, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    sget v0, Lcom/permissionx/guolindev/R$id;->positiveLayout:I

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {p0, v0}, Ln0/c;->a(Landroid/view/View;I)Landroid/view/View;

    move-result-object v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    check-cast v9, Landroid/widget/LinearLayout;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz v9, :cond_0

    const/4 v10, 0x7

    move v11, v10

    new-instance v0, Lc7/a;

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    check-cast v3, Landroid/widget/LinearLayout;

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct/range {v2 .. v9}, Lc7/a;-><init>(Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/Button;Landroid/widget/LinearLayout;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    return-object v0

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string/jumbo v1, "wg mh:vriu   edseMwirisnIie ist"

    const-string v1, "  seiws:e qgir tdvnuIre iiishwM"

    const-string v1, "Missing required view with ID: "

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {v0, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x3

    throw v0
.end method

.method public static c(Landroid/view/LayoutInflater;)Lc7/a;
    .locals 4
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const/4 v1, 0x0

    shr-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x5

    invoke-static {p0, v0, v1}, Lc7/a;->d(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lc7/a;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p0
.end method

.method public static d(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lc7/a;
    .locals 4
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget v0, Lcom/permissionx/guolindev/R$layout;->permissionx_default_dialog_layout:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0}, Lc7/a;->a(Landroid/view/View;)Lc7/a;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method


# virtual methods
.method public b()Landroid/widget/LinearLayout;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    iget-object v0, p0, Lc7/a;->a:Landroid/widget/LinearLayout;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getRoot()Landroid/view/View;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lc7/a;->b()Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method
