.class public interface abstract Lq6/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;)V
.end method

.method public abstract b(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract c(Landroid/content/Context;)V
.end method

.method public abstract d(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract e(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract f(Landroid/content/Context;Ljava/lang/String;IILs6/c;)V
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "II",
            "Ls6/c<",
            "Landroid/graphics/Bitmap;",
            ">;)V"
        }
    .end annotation
.end method
