.class public interface abstract Lq6/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;ZILcom/luck/picture/lib/entity/LocalMedia;Ls6/b;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "ZI",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            "Ls6/b<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation
.end method
