.class public interface abstract Lq6/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;Ljava/util/ArrayList;Ls6/c;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;",
            "Ls6/c<",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;>;)V"
        }
    .end annotation
.end method
