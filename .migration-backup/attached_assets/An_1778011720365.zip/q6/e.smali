.class public interface abstract Lq6/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Lq6/c;
.end method

.method public abstract b()Lq6/a;
.end method

.method public abstract c()Ls6/v;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end method

.method public abstract d()Lq6/d;
.end method

.method public abstract e()Ls6/f;
.end method

.method public abstract f()Lq6/f;
.end method
