.class public final Lz6/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "SVGALog"

.field public static final b:Lz6/c;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lz6/c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Lz6/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lz6/c;->b:Lz6/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public static synthetic b(Lz6/c;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~is @~lfo/~@ t~  tv4o~ @@~~~@@~ @ m ~i1oS ~K~b~~~~c dl@fy@@@@@i@o r@~ ~@. u@aM @~~/ ~o @n@-~o sb"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    const-string p1, "VLomsgA"

    const-string p1, "SLsAoVg"

    const/4 v1, 0x4

    const-string p1, "gLGooAV"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lz6/c;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic f(Lz6/c;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const-string p1, "LmVGAbS"

    const-string p1, "VSgmGAL"

    const/4 v1, 0x1

    const-string p1, "VgSAGLu"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lz6/c;->c(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic g(Lz6/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x5

    and-int/lit8 p4, p4, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eqz p4, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    const-string/jumbo p1, "pGVoALg"

    const-string p1, "LAgGooV"

    const/4 v1, 0x5

    const-string p1, "gqAGLVo"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lz6/c;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic i(Lz6/c;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    const-string p1, "LgsbAGo"

    const-string/jumbo p1, "oGVLAbg"

    const/4 v1, 0x6

    const-string p1, "GSomAgL"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lz6/c;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic k(Lz6/c;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string p1, "VuLgooG"

    const-string p1, "AVogLGu"

    const-string p1, "AVSGLbg"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lz6/c;->j(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static synthetic m(Lz6/c;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    const-string p1, "SGpVgAu"

    const-string/jumbo p1, "pgAoVSG"

    const/4 v1, 0x2

    const-string/jumbo p1, "pSgGVLo"

    const-string p1, "SVGALog"

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lz6/c;->l(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v0, "gta"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x1

    const-string v0, "atg"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v0, "mgs"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v0, p1, p2}, Lz6/b;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public final c(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, "gta"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x6

    const-string/jumbo v0, "tga"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const-string/jumbo v0, "mgs"

    const/4 v3, 0x3

    const-string/jumbo v0, "msg"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v2, 0x3

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    invoke-interface {v0, p1, p2, v1}, Lz6/b;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public final d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "gta"

    const-string/jumbo v0, "tga"

    const/4 v3, 0x3

    const-string v0, "atg"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "mgs"

    const-string/jumbo v0, "msg"

    const/4 v2, 0x5

    move v3, v2

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v0, "qrrqo"

    const-string/jumbo v0, "orrqe"

    const/4 v3, 0x7

    const-string/jumbo v0, "rrsoe"

    const-string v0, "error"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x3

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, p1, p2, p3}, Lz6/b;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "gat"

    const-string/jumbo v0, "tga"

    const/4 v3, 0x7

    const-string/jumbo v0, "tag"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v0, "rrsmr"

    const-string v0, "ersrr"

    const/4 v3, 0x5

    const-string/jumbo v0, "orrro"

    const-string v0, "error"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, p1, v1, p2}, Lz6/b;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v2, 0x1

    move v3, v2

    return-void
.end method

.method public final h(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "gta"

    const-string/jumbo v0, "tga"

    const/4 v3, 0x7

    const-string/jumbo v0, "tag"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v0, "sgm"

    const/4 v3, 0x4

    const-string/jumbo v0, "smg"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x3

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2}, Lz6/b;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public final j(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v0, "atg"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "smg"

    const-string v0, "gsm"

    const/4 v3, 0x0

    const-string/jumbo v0, "smg"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x4

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Lz6/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public final l(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v0, "tag"

    const-string v0, "gta"

    const/4 v3, 0x3

    const-string v0, "atg"

    const-string/jumbo v0, "tag"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, "gsm"

    const-string/jumbo v0, "smg"

    const/4 v3, 0x2

    const-string/jumbo v0, "smg"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x0

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    sget-object v0, Lz6/d;->c:Lz6/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lz6/d;->c()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lz6/d;->a()Lz6/b;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, p1, p2}, Lz6/b;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method
