.class public final Lz6/d;
.super Ljava/lang/Object;


# static fields
.field private static a:Lz6/b;

.field private static b:Z

.field public static final c:Lz6/d;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lz6/d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Lz6/d;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    sput-object v0, Lz6/d;->c:Lz6/d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    new-instance v0, Lz6/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0}, Lz6/a;-><init>()V

    const/4 v1, 0x4

    move v2, v1

    sput-object v0, Lz6/d;->a:Lz6/b;

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final a()Lz6/b;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lz6/d;->a:Lz6/b;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public final b(Lz6/b;)Lz6/d;
    .locals 3
    .param p1    # Lz6/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "lIsmgs"

    const-string/jumbo v0, "losmgI"

    const/4 v2, 0x2

    const-string/jumbo v0, "pImmlg"

    const-string/jumbo v0, "logImp"

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object p1, Lz6/d;->a:Lz6/b;

    const/4 v2, 0x7

    return-object p0
.end method

.method public final c()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-boolean v0, Lz6/d;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public final d(Z)Lz6/d;
    .locals 2
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    sput-boolean p1, Lz6/d;->b:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    return-object p0
.end method
