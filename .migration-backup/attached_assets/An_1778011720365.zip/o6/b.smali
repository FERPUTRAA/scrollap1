.class public Lo6/b;
.super Ljava/lang/Object;

# interfaces
.implements Lo6/a;


# static fields
.field private static b:Lo6/b;


# instance fields
.field private a:Lo6/a;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static d()Lo6/b;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ols@bof~@b/ ~ o~m@@ n@  @t~ u~i~i~@v@~@f~oK@~o  b @~ adr@~~@~~ ~  slyt@~-~.@/@S@cM@o  @~ ~4~@i ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lo6/b;->b:Lo6/b;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-class v0, Lo6/b;

    const-class v0, Lo6/b;

    const/4 v3, 0x2

    const-class v0, Lo6/b;

    const-class v0, Lo6/b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v1, Lo6/b;->b:Lo6/b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    if-nez v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v1, Lo6/b;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v1}, Lo6/b;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    sput-object v1, Lo6/b;->b:Lo6/b;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lo6/b;->b:Lo6/b;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method public a()Lq6/e;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lo6/b;->a:Lo6/a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Lo6/a;->a()Lq6/e;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public b()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lo6/b;->a:Lo6/a;

    const/4 v2, 0x2

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0}, Lo6/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object v0
.end method

.method public c()Lo6/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lo6/b;->a:Lo6/a;

    const/4 v2, 0x3

    return-object v0
.end method

.method public e(Lo6/a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lo6/b;->a:Lo6/a;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
