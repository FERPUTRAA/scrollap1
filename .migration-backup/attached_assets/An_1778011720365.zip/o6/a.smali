.class public interface abstract Lo6/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Lq6/e;
.end method

.method public abstract b()Landroid/content/Context;
.end method
