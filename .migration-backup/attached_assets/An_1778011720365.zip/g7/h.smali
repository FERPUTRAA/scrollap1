.class public Lg7/h;
.super Ljava/lang/Object;

# interfaces
.implements Lf7/b;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ost~~ou@~~i~oi@@ ~~oa tlm bf~ ~ @S@@c@~ ~r  @~1@@y - ov~@4~/@@@~@@M @ ~ @/@ sKi. ~~n~@bb~f~d l~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget v0, p0, Lg7/h;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lg7/h;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    return v0
.end method

.method public c(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lg7/h;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-void
.end method

.method public d(I)V
    .locals 2

    iput p1, p0, Lg7/h;->a:I

    const/4 v1, 0x2

    return-void
.end method
