.class public Lg7/g;
.super Lg7/h;

# interfaces
.implements Lf7/b;


# instance fields
.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lg7/h;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public e()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~ ~s@~@tao/~o~ b cf~~i~@tf~  ni~~m@ ~~~ @So ~-o   @r~@l@1@@~@~ul b @@ 4i/@@Kyv@ b@ @~~doMo@~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget v0, p0, Lg7/g;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public f(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lg7/g;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
