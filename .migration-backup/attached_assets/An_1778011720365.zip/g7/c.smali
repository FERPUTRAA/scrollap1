.class public Lg7/c;
.super Lg7/a;

# interfaces
.implements Lf7/b;


# instance fields
.field private c:I

.field private d:I

.field private e:I

.field private f:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lg7/a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public e()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lg7/c;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lg7/c;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lg7/c;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public h()I
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lg7/c;->f:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public i(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lg7/c;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public j(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lg7/c;->d:I

    const/4 v1, 0x6

    return-void
.end method

.method public k(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lg7/c;->e:I

    const/4 v1, 0x0

    return-void
.end method

.method public l(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lg7/c;->f:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
