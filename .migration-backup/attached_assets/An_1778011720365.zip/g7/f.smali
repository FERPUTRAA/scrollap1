.class public Lg7/f;
.super Ljava/lang/Object;

# interfaces
.implements Lf7/b;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~is~t-~@4 @io b  uns@1@~~ @~fo@ c@ o~@K@l~@~m~at @ ~lv~@~~@.~@ b ~o@b  @ o~@fS~/@~yMd  ~~o~i @r/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lg7/f;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lg7/f;->b:I

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public c(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Lg7/f;->a:I

    const/4 v0, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method public d(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lg7/f;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
