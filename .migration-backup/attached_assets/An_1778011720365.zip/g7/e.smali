.class public Lg7/e;
.super Ljava/lang/Object;

# interfaces
.implements Lf7/b;


# instance fields
.field private a:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~M~d~1~a.v@@ @tou~~  @cfm@ Ki yo@llS~b@/ tf ~n@i~@ ~@~@~ ~~- @  @~~~i/oo @ rb@ o~~ ~@s@~@@o@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget v0, p0, Lg7/e;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public b(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lg7/e;->a:I

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method
