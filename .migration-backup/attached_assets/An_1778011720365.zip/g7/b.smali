.class public Lg7/b;
.super Ljava/lang/Object;

# interfaces
.implements Lf7/b;


# instance fields
.field private a:I

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s@@~o ~Mi@s -~o@ @~@~f~d1~.@t~ @~~ ySm~~io  @ ~u @  @~@Kn@bl@ ~~t@@/cb~f@r  o v~~al@b~~io 4/ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lg7/b;->b:I

    const/4 v2, 0x1

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lg7/b;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lg7/b;->a:I

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public d(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput p1, p0, Lg7/b;->b:I

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public e(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lg7/b;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public f(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lg7/b;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-void
.end method
