.class public Lg7/d;
.super Lg7/a;

# interfaces
.implements Lf7/b;


# instance fields
.field private c:I

.field private d:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lg7/a;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public e()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ms  / @@~@r o@ yl@v@@S /~~@iost b~~df tbf@ ~@o @~~@@ol~~  ~.@@@ub i~@ ~1~@ncM i-~o~~~~@ o@4~a~K"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Lg7/d;->c:I

    const/4 v1, 0x4

    move v2, v1

    return v0
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lg7/d;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public g(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput p1, p0, Lg7/d;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public h(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lg7/d;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
