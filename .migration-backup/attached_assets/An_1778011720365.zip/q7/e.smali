.class public interface abstract Lq7/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onLoadMore(Lo7/f;)V
    .param p1    # Lo7/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
