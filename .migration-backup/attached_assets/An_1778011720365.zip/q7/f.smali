.class public interface abstract Lq7/f;
.super Ljava/lang/Object;

# interfaces
.implements Lq7/h;
.implements Lq7/i;


# virtual methods
.method public abstract k0(Lo7/c;II)V
.end method

.method public abstract m0(Lo7/c;ZFIII)V
.end method

.method public abstract p0(Lo7/d;ZFIII)V
.end method

.method public abstract s(Lo7/c;II)V
.end method

.method public abstract s0(Lo7/d;Z)V
.end method

.method public abstract u0(Lo7/d;II)V
.end method

.method public abstract w0(Lo7/c;Z)V
.end method

.method public abstract y0(Lo7/d;II)V
.end method
