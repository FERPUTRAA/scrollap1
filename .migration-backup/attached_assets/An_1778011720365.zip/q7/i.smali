.class public interface abstract Lq7/i;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onStateChanged(Lo7/f;Lcom/scwang/smart/refresh/layout/constant/b;Lcom/scwang/smart/refresh/layout/constant/b;)V
    .param p1    # Lo7/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/scwang/smart/refresh/layout/constant/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/scwang/smart/refresh/layout/constant/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;,
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;,
            .enum Landroidx/annotation/a1$a;->f:Landroidx/annotation/a1$a;
        }
    .end annotation
.end method
