.class public interface abstract Lq7/g;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onRefresh(Lo7/f;)V
    .param p1    # Lo7/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
