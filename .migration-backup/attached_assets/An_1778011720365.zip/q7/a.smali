.class public interface abstract Lq7/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract b(ZZ)V
.end method
