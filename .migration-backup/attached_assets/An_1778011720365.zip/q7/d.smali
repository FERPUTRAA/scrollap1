.class public interface abstract Lq7/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;Lo7/f;)V
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lo7/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
