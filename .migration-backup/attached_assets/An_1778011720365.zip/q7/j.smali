.class public interface abstract Lq7/j;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/View;)Z
.end method

.method public abstract b(Landroid/view/View;)Z
.end method
