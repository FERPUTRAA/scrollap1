.class public Lf7/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lg7/a;

.field private b:Lg7/d;

.field private c:Lg7/h;

.field private d:Lg7/c;

.field private e:Lg7/g;

.field private f:Lg7/b;

.field private g:Lg7/f;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public a()Lg7/a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~@yn-  @   SM@o@if i~i~~m uf @~~/.~@oo~ @~@ @bK@~@l@~1~~b~@ ~~4@a@tt@ ~~do~ls b~r~@@/  vo co "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lf7/a;->a:Lg7/a;

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lg7/a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Lg7/a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lf7/a;->a:Lg7/a;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lf7/a;->a:Lg7/a;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()Lg7/b;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lf7/a;->f:Lg7/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x5

    new-instance v0, Lg7/b;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Lg7/b;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lf7/a;->f:Lg7/b;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object v0, p0, Lf7/a;->f:Lg7/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public c()Lg7/c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    iget-object v0, p0, Lf7/a;->d:Lg7/c;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lg7/c;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0}, Lg7/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lf7/a;->d:Lg7/c;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lf7/a;->d:Lg7/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public d()Lg7/d;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lf7/a;->b:Lg7/d;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lg7/d;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Lg7/d;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lf7/a;->b:Lg7/d;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lf7/a;->b:Lg7/d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Lg7/f;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    iget-object v0, p0, Lf7/a;->g:Lg7/f;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lg7/f;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Lg7/f;-><init>()V

    const/4 v1, 0x5

    move v2, v1

    iput-object v0, p0, Lf7/a;->g:Lg7/f;

    :cond_0
    const/4 v2, 0x6

    iget-object v0, p0, Lf7/a;->g:Lg7/f;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public f()Lg7/g;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lf7/a;->e:Lg7/g;

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lg7/g;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Lg7/g;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    iput-object v0, p0, Lf7/a;->e:Lg7/g;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lf7/a;->e:Lg7/g;

    const/4 v2, 0x1

    return-object v0
.end method

.method public g()Lg7/h;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lf7/a;->c:Lg7/h;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Lg7/h;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0}, Lg7/h;-><init>()V

    const/4 v2, 0x4

    iput-object v0, p0, Lf7/a;->c:Lg7/h;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lf7/a;->c:Lg7/h;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method
