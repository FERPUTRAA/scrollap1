.class public interface abstract Lh1/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()I
.end method

.method public abstract c()I
.end method
