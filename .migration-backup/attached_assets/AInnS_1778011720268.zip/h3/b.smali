.class public Lh3/b;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/engagelab/privates/core/api/Address; = null

.field private static b:Z = true

.field private static c:Z = true

.field private static d:Z = true

.field private static e:J = 0x0L

.field private static f:I = -0x1

.field private static g:J = 0x0L

.field private static h:Ljava/lang/String; = null

.field private static i:Ljava/lang/String; = null

.field private static j:I = 0x0

.field private static k:I = 0x0

.field private static l:J = 0x0L

.field private static m:J = 0x46cd0L

.field private static n:I = 0x3


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static A(I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "orsb@~to@@u.~@mvn4 lii~~ b@ Sf K1 ~ ~@ b@o/@d~~~a~@~i~~f~o~ @@-~o~ ~@ ~  @@M@o s ~y@/ @@ @t~ l@c"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    sput p0, Lh3/b;->k:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static B(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    sput-wide p0, Lh3/b;->l:J

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    return-void
.end method

.method public static C(J)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    sput-wide p0, Lh3/b;->g:J

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static D(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    sput-boolean p0, Lh3/b;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/engagelab/privates/core/api/Address;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v0, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v0, :cond_3

    const/4 v4, 0x5

    move v5, v4

    const-class v0, Lh3/b;

    const-class v0, Lh3/b;

    const/4 v5, 0x1

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object v1, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-boolean v1, Ly2/b;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    move v5, v4

    invoke-static {p0}, Ly2/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0}, Lh3/a;->b(Ljava/lang/String;)Lcom/engagelab/privates/core/api/Address;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const-string/jumbo v1, "ssdmdAe"

    const-string v1, "dssAdes"

    const/4 v5, 0x7

    const-string v1, "essrodA"

    const-string v1, "Address"

    :try_start_1
    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v3, "in ofbmd"

    const-string/jumbo v3, "oinmfnd "

    const/4 v5, 0x2

    const-string v3, " ofnn ui"

    const-string/jumbo v3, "no find "

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string p0, "aets. lpuletde s sPdketsht aepaa  sddore ts"

    const-string/jumbo p0, "steao t tlassrsd. ddePuelieatds  pet  sahek"

    const/4 v5, 0x3

    const-string p0, ".s adtteqdtesasslhr aelts tasudipk eed ee  "

    const-string p0, " site address. Please update the latest sdk"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p0, Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/engagelab/privates/core/api/Address;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    sput-object p0, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    sput-object v1, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p0, Lcom/engagelab/privates/core/api/Address;

    const/4 v4, 0x5

    move v5, v4

    invoke-direct {p0}, Lcom/engagelab/privates/core/api/Address;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-object p0, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    :cond_2
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    throw p0

    :cond_3
    :goto_1
    const/4 v5, 0x6

    sget-object p0, Lh3/b;->a:Lcom/engagelab/privates/core/api/Address;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p0
.end method

.method public static b()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget v0, Lh3/b;->n:I

    const/4 v2, 0x0

    return v0
.end method

.method public static c()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget-wide v0, Lh3/b;->m:J

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-wide v0
.end method

.method public static d(Landroid/content/Context;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0}, Lh3/b;->e(Landroid/content/Context;)Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method private static e(Landroid/content/Context;)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->q(Landroid/content/Context;)Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-static {p0}, Lh3/b;->a(Landroid/content/Context;)Lcom/engagelab/privates/core/api/Address;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p0}, Lcom/engagelab/privates/core/api/Address;->e()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v2, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v3, 0x3

    return-object v0
.end method

.method public static f(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget v0, Lh3/b;->j:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-static {p0}, Lo2/q;->u(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    sput p0, Lh3/b;->j:I

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    sget p0, Lh3/b;->j:I

    const/4 v2, 0x4

    move v3, v2

    return p0
.end method

.method public static g()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-boolean v0, Ly2/b;->d:Z

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-boolean v0, Ly2/b;->f:Z

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-boolean v0, Lh3/b;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public static h()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-boolean v0, Ly2/b;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    sget-boolean v0, Ly2/b;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-boolean v0, Lh3/b;->d:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public static i(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    sget-object v0, Lh3/b;->i:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput-object p0, Lh3/b;->i:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object p0, Lh3/b;->i:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public static j(Landroid/content/Context;)B
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-static {p0}, Lo2/q;->x(Landroid/content/Context;)B

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    return p0
.end method

.method public static k(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget v0, Lh3/b;->f:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0}, Lo2/q;->y(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput p0, Lh3/b;->f:I

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget p0, Lh3/b;->f:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return p0
.end method

.method public static l(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lh3/b;->h:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0}, Lo2/q;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    sput-object p0, Lh3/b;->h:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x4

    sget-object p0, Lh3/b;->h:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public static m()J
    .locals 10

    const/4 v8, 0x7

    const/4 v9, 0x5

    sget-wide v0, Lh3/b;->e:J

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-wide/16 v2, 0x2

    const-wide/16 v2, 0x2

    const/4 v9, 0x7

    const-wide/16 v2, 0x2

    const-wide/16 v2, 0x2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    rem-long v4, v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    cmp-long v4, v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez v4, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    add-long/2addr v0, v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-wide/16 v2, 0x7fff

    const/4 v9, 0x5

    const-wide/16 v2, 0x7fff

    const-wide/16 v2, 0x7fff

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    rem-long/2addr v0, v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    sput-wide v0, Lh3/b;->e:J

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-wide v0
.end method

.method public static n(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget v0, Lh3/b;->k:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    invoke-static {p0}, Lo2/q;->A(Landroid/content/Context;)I

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput p0, Lh3/b;->k:I

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget p0, Lh3/b;->k:I

    const/4 v2, 0x7

    return p0
.end method

.method public static o(Landroid/content/Context;)J
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-wide v0, Lh3/b;->l:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0}, Lo2/q;->B(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    sput-wide v0, Lh3/b;->l:J

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-wide v0, Lh3/b;->l:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-wide v0
.end method

.method public static p(Landroid/content/Context;)J
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-wide v0, Lh3/b;->g:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x5

    move v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    sput-wide v0, Lh3/b;->g:J

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-wide v0, Lh3/b;->g:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-wide v0
.end method

.method public static q()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-boolean v0, Lh3/b;->b:Z

    const/4 v2, 0x4

    return v0
.end method

.method public static r(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-ge p0, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput v0, Lh3/b;->n:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    sput p0, Lh3/b;->n:I

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public static s(J)V
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    cmp-long v0, p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-gtz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-wide/32 p0, 0x46cd0

    const-wide/32 p0, 0x46cd0

    const/4 v3, 0x5

    sput-wide p0, Lh3/b;->m:J

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput-wide p0, Lh3/b;->m:J

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public static t(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    sput p0, Lh3/b;->j:I

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method public static u(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-boolean v0, Ly2/b;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-boolean v0, Ly2/b;->f:Z

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-boolean p0, Lh3/b;->c:Z

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public static v(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-boolean v0, Ly2/b;->d:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v1, 0x0

    move v2, v1

    sget-boolean v0, Ly2/b;->f:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    sput-boolean p0, Lh3/b;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public static w(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    sput-object p0, Lh3/b;->i:Ljava/lang/String;

    const/4 v0, 0x4

    const/4 v0, 0x1

    return-void
.end method

.method public static x(Landroid/content/Context;B)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lo2/q;->b(Landroid/content/Context;B)V

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static y(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    sput p0, Lh3/b;->f:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static z(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    sput-object p0, Lh3/b;->h:Ljava/lang/String;

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    return-void
.end method
