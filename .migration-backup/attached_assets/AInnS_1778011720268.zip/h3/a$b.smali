.class public Lh3/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lh3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:[Ljava/lang/String;

.field public b:[Ljava/lang/String;

.field public c:I


# direct methods
.method public constructor <init>([Ljava/lang/String;[Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lh3/a$b;->a:[Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lh3/a$b;->b:[Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p3, p0, Lh3/a$b;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()[Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  saM@~ on~b mo@@@~S@Kl -t1~~i~~ ~@ ~@yb@ob~i   ~@@ ~ /ls ~~ @@@d@ i~@@c@ .~r/~f 4@o@~f~~uo~to@v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lh3/a$b;->a:[Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lh3/a$b;->b:[Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    iget v0, p0, Lh3/a$b;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method
