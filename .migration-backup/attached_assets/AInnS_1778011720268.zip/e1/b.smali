.class public Le1/b;
.super Ljava/lang/Object;

# interfaces
.implements Le1/a;


# static fields
.field private static a:Le1/a;

.field private static b:Lcom/alipay/security/mobile/module/http/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)Le1/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " .sa1~@ -@Kctd~~ l o@r~ ~@~om~4b@@t@ ~ ~~@@ ~S~ @iiofof ~b ny M/@b@@ o/~@ou~@l@~~@@ ~vs  ~~@~~i "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Le1/b;->a:Le1/a;

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lcom/alipay/security/mobile/module/http/d;->a(Landroid/content/Context;Ljava/lang/String;)Lcom/alipay/security/mobile/module/http/a;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object p0, Le1/b;->b:Lcom/alipay/security/mobile/module/http/a;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p0, Le1/b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Le1/b;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object p0, Le1/b;->a:Le1/a;

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p0, Le1/b;->a:Le1/a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method


# virtual methods
.method public a(Ld1/d;)Ld1/c;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Ld1/b;->a(Ld1/d;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Le1/b;->b:Lcom/alipay/security/mobile/module/http/a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/alipay/security/mobile/module/http/a;->a(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1}, Ld1/b;->b(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;)Ld1/c;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method public a(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Le1/b;->b:Lcom/alipay/security/mobile/module/http/a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/alipay/security/mobile/module/http/a;->a(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p1
.end method
