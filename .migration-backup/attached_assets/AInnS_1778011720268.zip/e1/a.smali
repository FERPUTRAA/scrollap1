.class public interface abstract Le1/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ld1/d;)Ld1/c;
.end method

.method public abstract a(Ljava/lang/String;)Z
.end method
