.class public final Lk/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "androidx.browser.trusted.KEY_SPLASH_SCREEN_VERSION"

.field public static final b:Ljava/lang/String; = "androidx.browser.trusted.trusted.KEY_SPLASH_SCREEN_BACKGROUND_COLOR"

.field public static final c:Ljava/lang/String; = "androidx.browser.trusted.KEY_SPLASH_SCREEN_SCALE_TYPE"

.field public static final d:Ljava/lang/String; = "androidx.browser.trusted.KEY_SPLASH_SCREEN_TRANSFORMATION_MATRIX"

.field public static final e:Ljava/lang/String; = "androidx.browser.trusted.KEY_SPLASH_SCREEN_FADE_OUT_DURATION"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
