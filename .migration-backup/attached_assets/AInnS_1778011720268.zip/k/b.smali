.class public final Lk/b;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "androidx.browser.trusted.category.TrustedWebActivitySplashScreensV1"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method
