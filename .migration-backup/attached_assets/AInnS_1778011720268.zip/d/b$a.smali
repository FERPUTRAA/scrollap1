.class public Ld/b$a;
.super Ld/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Landroid/net/Uri;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~sbfd~fbs~@S ny@t~@ i@~@@o~ci@~  @ ~ ~@u@4o ~  ~/   r@t~~ /~o-~@l@@ o~Ko~iMm@ .@~@b@o la@ ~~~v1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    check-cast p2, Landroid/net/Uri;

    const/4 v0, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Ld/b$a;->d(Landroid/content/Context;Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    check-cast p2, Landroid/net/Uri;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Ld/b$a;->e(Landroid/content/Context;Landroid/net/Uri;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Ld/b$a;->f(ILandroid/content/Intent;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public d(Landroid/content/Context;Landroid/net/Uri;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "nsemcxt"

    const-string/jumbo v0, "oesxnct"

    const/4 v2, 0x6

    const-string v0, "eocnotx"

    const-string v0, "context"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string p1, "bnmpi"

    const-string/jumbo p1, "tinmp"

    const/4 v2, 0x5

    const-string/jumbo p1, "puuti"

    const-string/jumbo p1, "input"

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "TCtoEoap.enPmiAaDV.dIdOaiirU_o.cdn"

    const-string v0, "dDV.oCtdrnRnIAiiTo.dPaEc_aaieUoO.m"

    const/4 v2, 0x2

    const-string v0, "..dVUooEqc.taARnddriDeE_iiICaaPnOT"

    const-string v0, "android.media.action.VIDEO_CAPTURE"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "tpsuut"

    const-string/jumbo v0, "uttpub"

    const/4 v2, 0x0

    const-string/jumbo v0, "topmut"

    const-string/jumbo v0, "output"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string p2, "Intent(MediaStore.ACTION\u2026tore.EXTRA_OUTPUT, input)"

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1
.end method

.method public final e(Landroid/content/Context;Landroid/net/Uri;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/net/Uri;",
            ")",
            "Ld/a$a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "ncutoxt"

    const-string/jumbo v0, "xcnottu"

    const/4 v2, 0x6

    const-string/jumbo v0, "onttxbe"

    const-string v0, "context"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo p1, "pupin"

    const-string/jumbo p1, "tppin"

    const/4 v2, 0x7

    const-string/jumbo p1, "itpnp"

    const-string/jumbo p1, "input"

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x6

    shr-int/2addr v2, p1

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Ljava/lang/Boolean;
    .locals 2
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p2, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-ne p1, p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method
