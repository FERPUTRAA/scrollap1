.class public final Ld/b$k;
.super Ld/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld/b$k$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "[",
        "Ljava/lang/String;",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        ">;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,959:1\n12541#2,2:960\n8676#2,2:962\n9358#2,4:964\n11365#2:968\n11700#2,3:969\n*S KotlinDebug\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n*L\n188#1:960,2\n195#1:962,2\n195#1:964,4\n208#1:968\n208#1:969,3\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,959:1\n12541#2,2:960\n8676#2,2:962\n9358#2,4:964\n11365#2:968\n11700#2,3:969\n*S KotlinDebug\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions\n*L\n188#1:960,2\n195#1:962,2\n195#1:964,4\n208#1:968\n208#1:969,3\n*E\n"
    }
.end annotation


# static fields
.field public static final a:Ld/b$k$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "androidx.activity.result.contract.extra.PERMISSIONS"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Ld/b$k$a;

    const/4 v3, 0x0

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {v0, v1}, Ld/b$k$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    sput-object v0, Ld/b$k;->a:Ld/b$k$a;

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sM@~ K@ @@ ~bo ~@dbyc~~o@l~mvot@o.~S @~~4 si~u  @a~bf~@~lo~ i1~@~@t@@~@@ n~  @~~@ -@/i /r@f~o "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p2, [Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$k;->d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    check-cast p2, [Ljava/lang/String;

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Ld/b$k;->e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Ld/b$k;->f(ILandroid/content/Intent;)Ljava/util/Map;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "scomett"

    const-string v0, "ensotct"

    const/4 v2, 0x7

    const-string/jumbo v0, "ntteoco"

    const-string v0, "context"

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const-string p1, "bimpt"

    const-string/jumbo p1, "pinmt"

    const/4 v2, 0x3

    const-string/jumbo p1, "puntu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object p1, Ld/b$k;->a:Ld/b$k$a;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Ld/b$k$a;->a([Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p1
.end method

.method public e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "pnoectt"

    const-string v0, "ectnotx"

    const/4 v6, 0x6

    const-string v0, "cqnotxe"

    const-string v0, "context"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v0, "ubsnt"

    const-string v0, "bntiu"

    const/4 v6, 0x2

    const-string/jumbo v0, "utimn"

    const-string/jumbo v0, "input"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    array-length v0, p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v5, 0x3

    move v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance p1, Ld/a$a;

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-static {}, Lkotlin/collections/x0;->z()Ljava/util/Map;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p1, p2}, Ld/a$a;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    array-length v0, p2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    if-ge v3, v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    aget-object v4, p2, v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1, v4}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v4, v1

    move v4, v1

    const/4 v6, 0x6

    move v4, v1

    move v4, v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    move v4, v2

    move v4, v2

    const/4 v6, 0x2

    move v4, v2

    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v4, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    move v1, v2

    move v1, v2

    const/4 v6, 0x3

    move v1, v2

    move v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_3

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_1

    :cond_4
    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x7

    array-length p1, p2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1}, Lkotlin/collections/x0;->j(I)I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/16 v0, 0x10

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p1, v0}, Lkotlin/ranges/s;->u(II)I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v6, 0x5

    invoke-direct {v0, p1}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    array-length p1, p2

    :goto_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-ge v2, p1, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x3

    aget-object v1, p2, v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1, v3}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1}, Lkotlin/u0;->e()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Lkotlin/u0;->f()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v0, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    move v6, v5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_4

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance p1, Ld/a$a;

    const/4 v5, 0x6

    or-int/2addr v6, v5

    invoke-direct {p1, v0}, Ld/a$a;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_5

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 p1, 0x0

    :goto_5
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object p1
.end method

.method public f(ILandroid/content/Intent;)Ljava/util/Map;
    .locals 7
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v0, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eq p1, v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {}, Lkotlin/collections/x0;->z()Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez p2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lkotlin/collections/x0;->z()Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string p1, "dttroEtPcSiOuSRtNiuaoy.xnn.eltt.Sav.xa.rIsoirceMIrc"

    const-string p1, "ctItsiuitSxo.NdMSyvrPSiRaaa.Et.raOrcoux.ct.Ienetlnr"

    const/4 v6, 0x1

    const-string p1, "ctIcab.tRsenyNOoMr.irdIxvtr..Sc.eolaauSEatidPrtSxnt"

    const-string p1, "androidx.activity.result.contract.extra.PERMISSIONS"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v0, "t.N..SuO.lsSriaoSI_xdTnriRrSTEcMpUtdeLA.xtGNvRtEoncRcrteuyitPaaa"

    const-string/jumbo v0, "tnN.ruAptaRtPNcLnTEaxEa.alstceGiS.SdrMor.rytSUioSdecT.RxI_viR_tO"

    const/4 v6, 0x0

    const-string/jumbo v0, "oiNRrNSpT.aeuRcIatnRaSsSyvAMcrio.x.tGidx.nEIr_StUdP_tatrOLE.eltc"

    const-string v0, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    const/4 v6, 0x4

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz p2, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez p1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    array-length v1, p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    array-length v1, p2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    const/4 v6, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ge v3, v1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    aget v4, p2, v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v4, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x3

    goto :goto_1

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    move v4, v2

    move v4, v2

    const/4 v6, 0x5

    move v4, v2

    move v4, v2

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v0, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {p1}, Lkotlin/collections/l;->Ta([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-static {p1, v0}, Lkotlin/collections/u;->f6(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1}, Lkotlin/collections/x0;->B0(Ljava/lang/Iterable;)Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object p1

    :cond_5
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {}, Lkotlin/collections/x0;->z()Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-object p1
.end method
