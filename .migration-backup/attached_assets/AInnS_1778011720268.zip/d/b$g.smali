.class public Ld/b$g;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "[",
        "Ljava/lang/String;",
        "Ljava/util/List<",
        "Landroid/net/Uri;",
        ">;>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~~n@ -o s@~~b @b@~mdo~@~@@/@i4~S o~@@@@~~ii@~ b ~ f ac~@  ~ 1u~o@.ryv~~l~   /~tKf @t@M@~ o@ o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p2, [Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Ld/b$g;->d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    check-cast p2, [Ljava/lang/String;

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Ld/b$g;->e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Ld/b$g;->f(ILandroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x5

    return-object p1
.end method

.method public d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "snxmcot"

    const-string/jumbo v0, "onsxtct"

    const/4 v2, 0x6

    const-string/jumbo v0, "tnxcooe"

    const-string v0, "context"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string p1, "btpmu"

    const-string/jumbo p1, "tipmu"

    const/4 v2, 0x4

    const-string/jumbo p1, "nuitu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "dNn.odUpoE_eiNioMn.aEtncOarniOttDPC"

    const-string v0, "OtdnoniNtUao.iEncioEMDeOrCn._Nad.Pt"

    const/4 v2, 0x7

    const-string v0, "anOC.NEnqEUo.einoticiMatTOrDdNtd.nP"

    const-string v0, "android.intent.action.OPEN_DOCUMENT"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const-string v0, "aas.YMirS.InMntx.oe_idrEbdntPEt"

    const-string/jumbo v0, "iaEeTbIrnr.oit_PdEn.axMMtSYdt.n"

    const/4 v2, 0x1

    const-string v0, ".TSmMeitar.I_dEeiYEdn.xPrMnotat"

    const-string v0, "android.intent.extra.MIME_TYPES"

    const/4 v2, 0x0

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    const-string p2, "iEtMonWeLnrdaoALtnut.rI..TPUaLOexLi"

    const-string/jumbo p2, "tEietLuanP.nrItWdLeUi_.OMLanAToxLr."

    const/4 v2, 0x7

    const-string p2, "android.intent.extra.ALLOW_MULTIPLE"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string p2, "**/"

    const-string p2, "*/*"

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo p2, "n (n/b/N Ot.Anptt*y_2pE2) OT0IIe/. eC tI/ 6/e(e u T/ *t n"

    const-string/jumbo p2, "n n(T tp.s0TI6/e/ t2 Enn/)It .*CpetO  /_IOe(  /2/ueyANt *"

    const/4 v2, 0x4

    const-string p2, "Ine.(nu   y0*6ePT/ /nu t/tO n /_e*2(IA/N/. ttT  psC2IOt)e"

    const-string p2, "Intent(Intent.ACTION_OPE\u2026          .setType(\"*/*\")"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method

.method public final e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x1

    const-string/jumbo v0, "pqtoxet"

    const-string/jumbo v0, "nqextto"

    const-string v0, "context"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo p1, "stuqi"

    const-string/jumbo p1, "upsit"

    const/4 v2, 0x2

    const-string/jumbo p1, "itsnu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Ljava/util/List;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, -0x1

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    const/4 v2, 0x2

    const/4 p2, 0x0

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p2, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p1, Ld/b$d;->a:Ld/b$d$a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Ld/b$d$a;->a(Landroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_2

    :cond_2
    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object p1

    :goto_2
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1
.end method
