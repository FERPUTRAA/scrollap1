.class public final synthetic Ld/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@@~  n@l@ s/~a@ @.@b~-@ioc~~o ~~i@@~ otbo  @~S@~ v ~~@ rf~ K~~@ ~y4 m1@~ ~t@@f/~l @ob@iu Mdo~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {}, Landroid/provider/MediaStore;->getPickImagesMaxLimit()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method
