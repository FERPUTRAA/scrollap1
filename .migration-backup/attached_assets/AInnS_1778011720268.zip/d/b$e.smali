.class public Ld/b$e;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "[",
        "Ljava/lang/String;",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$OpenDocument\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$OpenDocument\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "oms/u~s@~t  adr ~~ 1  cMtf~4~l@y i  @~@bi o@f@@i@@ @ o ~o@/@@o~.v~~~@l@on ~~Kb@@S ~~~~@@~b~  -~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    check-cast p2, [Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Ld/b$e;->d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p2, [Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-virtual {p0, p1, p2}, Ld/b$e;->e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Ld/b$e;->f(ILandroid/content/Intent;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public d(Landroid/content/Context;[Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "stomexn"

    const-string/jumbo v0, "txsonce"

    const/4 v2, 0x3

    const-string v0, "ecotoxt"

    const-string v0, "context"

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string p1, "bntpi"

    const-string/jumbo p1, "input"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "OMEmETaU.raOnPddiN.onntticoN_i.eCDt"

    const/4 v2, 0x4

    const-string v0, "ONDOtnudn_.UaEn.MiTondc.erCEttoNiai"

    const-string v0, "android.intent.action.OPEN_DOCUMENT"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "nSidEnTpIi..toaee.xEnoradYPMtMr"

    const-string v0, "PinroIe.SntrET.enEiaxYtdM.otadM"

    const/4 v2, 0x1

    const-string v0, "PISx_eErqETo.idYirnaa.nt.MtdMen"

    const-string v0, "android.intent.extra.MIME_TYPES"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string p2, "*/*"

    const/4 v2, 0x4

    const-string p2, "*/*"

    const-string p2, "*/*"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo p2, "y.sI//6 T Oe/nnO/2 t en/eIs.b/n2t(*t 0t ApeC* E()P tT _ N"

    const-string p2, " OI_ebe .net/tys(/tO( )n.n22 ItITA/TPE06n/ e/C   N p **/t"

    const/4 v2, 0x7

    const-string/jumbo p2, "y Amt //)2t. O/(IIN/Oens p tTtn eInn t /6uTE_(C. *2 0/*ee"

    const-string p2, "Intent(Intent.ACTION_OPE\u2026          .setType(\"*/*\")"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1
.end method

.method public final e(Landroid/content/Context;[Ljava/lang/String;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "ntxteou"

    const/4 v2, 0x5

    const-string/jumbo v0, "ncetoto"

    const-string v0, "context"

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo p1, "uiptn"

    const/4 v2, 0x4

    const-string p1, "bptnu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x7

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Landroid/net/Uri;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v1, 0x4

    move v2, v1

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz p2, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method
