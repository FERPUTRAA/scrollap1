.class public Ld/b$d;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x12
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld/b$d$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Ljava/lang/String;",
        "Ljava/util/List<",
        "Landroid/net/Uri;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final a:Ld/b$d$a;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ld/b$d$a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ld/b$d$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    sput-object v0, Ld/b$d;->a:Ld/b$d$a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~~@@ @o t~y~ Ss@lo~i~ -@@@@~b1ib@@ @@~ o ~d@ @ ~a ~@/u~/v  ~M bic@4 fl oom~~~ ~fn@ t.~@@K~o~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$d;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Ld/b$d;->e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Ld/b$d;->f(ILandroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo v0, "sncmetx"

    const-string/jumbo v0, "ttsnxec"

    const-string v0, "context"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo p1, "tpumn"

    const/4 v2, 0x2

    const-string/jumbo p1, "puito"

    const-string/jumbo p1, "input"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "_nCoobT.TtTENntt.nciEre.iaddNaGin"

    const-string v0, "aeNio.cTNr.iTGdnoEnati.ToCdnnttE_"

    const/4 v2, 0x4

    const-string/jumbo v0, "oei._GuEtdni.dnN.TTNoECcinrnOtaTt"

    const-string v0, "android.intent.action.GET_CONTENT"

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "dEPtaoLpeirnBcNrgbiAEt...oynOead"

    const-string/jumbo v0, "oBet.bnAO.drrEEPLeioydnnicatN.ag"

    const-string/jumbo v0, "oiaeALnrqidtnEondBer..taOtgEcPyN"

    const-string v0, "android.intent.category.OPENABLE"

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo p2, "rWsiteiPMeOLtTdErAtLxo.ULn._.adLanI"

    const-string p2, "android.intent.extra.ALLOW_MULTIPLE"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p2, "L2ImL60OWO,neeRn.u/CetL)E_ItAuTtTUM_GNIAL2nAr(ITTu tn_t"

    const-string/jumbo p2, "uLeOtOu6W.2AtA_/MeCTnLnGIrLN ITne)2,Tntt_TIEtIuAREL0U_("

    const/4 v2, 0x3

    const-string p2, "I,L_oee_(EtInOWn2t.EL_TGTALTNTt 2nItLu)MUA/tu6OIR0nrCAP"

    const-string p2, "Intent(Intent.ACTION_GET\u2026TRA_ALLOW_MULTIPLE, true)"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1
.end method

.method public final e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const-string/jumbo v0, "tpncxbt"

    const-string/jumbo v0, "ptenxtc"

    const/4 v2, 0x7

    const-string v0, "cttxonu"

    const-string v0, "context"

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    move v2, v1

    const-string/jumbo p1, "qnppi"

    const-string/jumbo p1, "nupqi"

    const/4 v2, 0x3

    const-string/jumbo p1, "ptiqu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Ljava/util/List;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p2, 0x0

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz p2, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object p1, Ld/b$d;->a:Ld/b$d$a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Ld/b$d$a;->a(Landroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_2

    const/4 v2, 0x5

    goto :goto_2

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object p1

    :goto_2
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p1
.end method
