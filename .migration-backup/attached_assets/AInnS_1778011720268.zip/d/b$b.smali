.class public Ld/b$b;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Ljava/lang/String;",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$CreateDocument\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$CreateDocument\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3
    .annotation runtime Lkotlin/k;
        message = "Using a wildcard mime type with CreateDocument is not recommended as it breaks the automatic handling of file extensions. Instead, specify the mime type by using the constructor that takes an concrete mime type (e.g.., CreateDocument(\"image/png\"))."
        replaceWith = .subannotation Lkotlin/b1;
            expression = "CreateDocument(\"todo/todo\")"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string v0, "*/*"

    const-string v0, "**/"

    const/4 v2, 0x2

    const-string v0, "*/*"

    const-string v0, "*/*"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ld/b$b;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "mimeType"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Ld/b$b;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tvs~on@l ~~fKi4@ ~@  ~l@  i/o~~o @-~f~t od@S~./@~@@ ~  a~ ~@1ro@b~@~s @ ~yubc @@@@o i ~M~@@b~~~m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Ld/b$b;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x4

    check-cast p2, Ljava/lang/String;

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$b;->e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Ld/b$b;->f(ILandroid/content/Intent;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "ncxmest"

    const-string v0, "ecsxtnt"

    const-string/jumbo v0, "nexcoto"

    const-string v0, "context"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const-string p1, "bmpnt"

    const-string/jumbo p1, "ipnmt"

    const/4 v2, 0x6

    const-string/jumbo p1, "uutnp"

    const-string/jumbo p1, "input"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "iACeoEn.od.toT_cEDU.nriMNtTtCREOaindn"

    const/4 v2, 0x0

    const-string v0, "Ado.OUNpnTr.tiMTaCtniocRtni.ECeE_ndaD"

    const-string v0, "android.intent.action.CREATE_DOCUMENT"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, p0, Ld/b$b;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const-string v0, ".irxddiEqanabtneTo.IrtTten"

    const-string v0, "Extdib.TIe.ietntardnaronT."

    const/4 v2, 0x4

    const-string/jumbo v0, "onsEeitatdrnLit.n.IrT.xeaT"

    const-string v0, "android.intent.extra.TITLE"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string p2, "TT_muTn.nteARp)nE,iTXtnIntIAt_t.EuItCeeR/N Ot2IC(L06Eu2"

    const-string p2, "EuI,TCu_InueeRn2/EAtONtIIti.e( tntT2.tTC)n_t60XAERpnLTn"

    const/4 v2, 0x7

    const-string p2, "R6etotuXIE/ILIRnTpEAC,._O)n.teu nCnt_nTntTAtnt(NiIE22Te"

    const-string p2, "Intent(Intent.ACTION_CRE\u2026ntent.EXTRA_TITLE, input)"

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1
.end method

.method public final e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "xnettbo"

    const-string/jumbo v0, "pntotxe"

    const-string v0, "context"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo p1, "nutqp"

    const-string/jumbo p1, "tpuqn"

    const/4 v2, 0x0

    const-string/jumbo p1, "tippu"

    const-string/jumbo p1, "input"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Landroid/net/Uri;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x0

    move v2, p1

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p2, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method
