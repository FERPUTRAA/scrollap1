.class public Ld/b$f;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Landroid/net/Uri;",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    check-cast p2, Landroid/net/Uri;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Ld/b$f;->d(Landroid/content/Context;Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p2, Landroid/net/Uri;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Ld/b$f;->e(Landroid/content/Context;Landroid/net/Uri;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Ld/b$f;->f(ILandroid/content/Intent;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public d(Landroid/content/Context;Landroid/net/Uri;)Landroid/content/Intent;
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v0, "ocsstnt"

    const-string/jumbo v0, "tcsteon"

    const/4 v3, 0x7

    const-string/jumbo v0, "xntmtoc"

    const-string v0, "context"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const-string v0, "_EU_oonetEo.nnaa.diCtcriONMiTnDN.TORtmEP"

    const-string v0, "UNomDP..rancin_TtnEMdaEieoRNnOt_Cd.EOtiT"

    const/4 v3, 0x4

    const-string v0, "TOcEEbatnniPe_otorR.iOdCnNEDMna.T_Et.iUd"

    const-string v0, "android.intent.action.OPEN_DOCUMENT_TREE"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/16 v1, 0x1a

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, "_TLoIIuo.dvrRnrUIe.xpdoeaINAr.iadt"

    const-string/jumbo v0, "xooroUp_rearid..NtnvIdI.dRTIALeIar"

    const/4 v3, 0x7

    const-string/jumbo v0, "rrIv_LTp.dt.oaiIenaIrpiNRxe.ordUId"

    const-string v0, "android.provider.extra.INITIAL_URI"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1
.end method

.method public final e(Landroid/content/Context;Landroid/net/Uri;)Ld/a$a;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/net/Uri;",
            ")",
            "Ld/a$a<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string/jumbo p2, "tqcxneb"

    const-string/jumbo p2, "tcenobx"

    const-string p2, "ctsotex"

    const-string p2, "context"

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Landroid/net/Uri;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    move-object p2, v0

    move-object p2, v0

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p2, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x0

    return-object v0
.end method
