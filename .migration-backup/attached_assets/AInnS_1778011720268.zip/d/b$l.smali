.class public final Ld/b$l;
.super Ld/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "l"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Ljava/lang/String;",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestPermission\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,959:1\n12774#2,2:960\n*S KotlinDebug\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestPermission\n*L\n228#1:960,2\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestPermission\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,959:1\n12774#2,2:960\n*S KotlinDebug\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$RequestPermission\n*L\n228#1:960,2\n*E\n"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@@@~/@~@o ii ~ v~ /t@ol~i@@oS@~ ~oy~t @b ~@  bu~~K M ~d@~-~@.oa@m~@1 ~~4c@l @ b~s@ n~~ @ offr"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Ld/b$l;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Ld/b$l;->e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Ld/b$l;->f(ILandroid/content/Intent;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "ctomest"

    const-string/jumbo v0, "tosnetc"

    const/4 v2, 0x4

    const-string v0, "cttooxe"

    const-string v0, "context"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string p1, "buimp"

    const-string/jumbo p1, "uipmt"

    const/4 v2, 0x6

    const-string/jumbo p1, "iutpn"

    const-string/jumbo p1, "input"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    sget-object p1, Ld/b$k;->a:Ld/b$k$a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Ld/b$k$a;->a([Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1
.end method

.method public e(Landroid/content/Context;Ljava/lang/String;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ld/a$a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "pceooxn"

    const-string v0, "excootn"

    const/4 v2, 0x3

    const-string/jumbo v0, "oqecxnt"

    const-string v0, "context"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "bntiu"

    const/4 v2, 0x6

    const-string/jumbo v0, "nistu"

    const-string/jumbo v0, "input"

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1, p2}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 p1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p1, Ld/a$a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1, p2}, Ld/a$a;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x3

    move v2, v1

    goto :goto_1

    :cond_1
    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1
.end method

.method public f(ILandroid/content/Intent;)Ljava/lang/Boolean;
    .locals 6
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v0, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq p1, v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto/16 :goto_3

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string p1, "ec_maLtNroRSaxcTo.UdRnauxEPiutO.Ndr.vs.tSlSIr_naGti.SyrtiIAteEcR"

    const-string p1, ".rElStuyt.Ad.aRt_cuSTPN.nna.iicRocaTeSIrS_OiLRrtIUaroexxvNtdstGE"

    const/4 v5, 0x0

    const-string p1, "SRnLoGTaT_tr.edartStNcatoc.cUIs...xnoOPRAMyuESeldtIvaiiN_iErrxRS"

    const-string p1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getIntArrayExtra(Ljava/lang/String;)[I

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 p2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    array-length v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    move v1, p2

    move v1, p2

    const/4 v5, 0x0

    move v1, p2

    move v1, p2

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ge v1, v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    aget v3, p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v3, v2

    move v3, v2

    const/4 v5, 0x1

    move v3, v2

    move v3, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    move v3, p2

    move v3, p2

    const/4 v5, 0x5

    move v3, p2

    move v3, p2

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    if-eqz v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    move p1, v2

    move p1, v2

    const/4 v5, 0x4

    move p1, v2

    move p1, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    move p1, p2

    move p1, p2

    const/4 v5, 0x6

    move p1, p2

    move p1, p2

    :goto_2
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne p1, v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    move p2, v2

    move p2, v2

    const/4 v5, 0x4

    move p2, v2

    move p2, v2

    :cond_4
    const/4 v4, 0x2

    move v5, v4

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    return-object p1

    :cond_5
    :goto_3
    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x0

    return-object p1
.end method
