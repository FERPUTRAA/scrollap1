.class public final Ld/b$k$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b$k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ld/b$k$a;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a([Ljava/lang/String;)Landroid/content/Intent;
    .locals 4
    .param p1    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b s /f-@@~ r 4 @ yo@f1/~o~S~ @@@o@~~~~@m b~oMn@~o ~  ~.@i  ~@K@b~@it@ld~us~@i ~~c@~@ @~~~lt@ao v"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string/jumbo v0, "psimn"

    const-string/jumbo v0, "tnsip"

    const/4 v3, 0x5

    const-string/jumbo v0, "ntpuo"

    const-string/jumbo v0, "input"

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "SaMoabEdUTocSIRE.i.dctaxtrROuiivn..clatsN.tSEryretPnSnctQomi"

    const-string v1, "cMtmUritE.da_Rtatn.sIratNe.SErn.xctidluSOoovonQTEcRPiSa.iySc"

    const/4 v3, 0x6

    const-string/jumbo v1, "ts.RxruEoN.cOT_Uid.tiP.InSntytEQaoadtccESrSicav.SMRolItnuare"

    const-string v1, "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v1, "MaxSnyipr.rrd.oR.dtPot.aStcaaer.NulcOxittSIotsEcein"

    const-string v1, ".rSsoSoya..tr.xxMtdndieriScRaPt.uoIlttarictnNeOcaEv"

    const-string/jumbo v1, "iaItSi.iqRoSvtlrrnrdeEae.O.nMoxrx.dSa.utItstyNPcact"

    const-string v1, "androidx.activity.result.contract.extra.PERMISSIONS"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v0, "TNsui,CIMtnREN2nESuUX_tT 2tIQE6bep)SA/ERPAPO_0I(RE_OSSI"

    const-string v0, "_CI/XbEuES2T6)nI2SNENT,pPuREAAOiSREOIttQ_UM0R_PS(It enn"

    const-string v0, "__EmR6uQESU2XSNnnpTIi NRSRA(ESu2IEATCT/OEO)PIIM_etntt,0"

    const-string v0, "Intent(ACTION_REQUEST_PE\u2026EXTRA_PERMISSIONS, input)"

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    return-object p1
.end method
