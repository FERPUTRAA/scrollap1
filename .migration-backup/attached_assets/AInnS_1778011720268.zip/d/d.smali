.class public final synthetic Ld/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " -s~ b@~~o~~ml@ ~~  @@~~~@u i @s4@/1 otKy@of@./ ~@ ~bf@~c @lt@i@n r~@do@@~ob~@~~a@ ~ vMi~@~  o~S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Landroid/os/ext/SdkExtensions;->getExtensionVersion(I)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method
