.class public Ld/b$j;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "j"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld/b$j$a;,
        Ld/b$j$b;,
        Ld/b$j$c;,
        Ld/b$j$d;,
        Ld/b$j$e;,
        Ld/b$j$f;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Landroidx/activity/result/k;",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nActivityResultContracts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ActivityResultContracts.kt\nandroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,959:1\n1#2:960\n*E\n"
    }
.end annotation


# static fields
.field public static final a:Ld/b$j$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "androidx.activity.result.contract.action.PICK_IMAGES"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "androidx.activity.result.contract.extra.PICK_IMAGES_MAX"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "com.google.android.gms.provider.action.PICK_IMAGES"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "com.google.android.gms.provider.extra.PICK_IMAGES_MAX"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ld/b$j$a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ld/b$j$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static final e(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ld/b$j$a;->c(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static final g(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ld/b$j$a;->d(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static final h(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ld/b$j$a;->f(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p0
.end method

.method public static final i()Z
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClassVerificationFailure",
            "NewApi"
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    .annotation runtime Lkotlin/k;
        message = "This method is deprecated in favor of isPhotoPickerAvailable(context) to support the picker provided by updatable system apps"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "isPhotoPickerAvailable(context)"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ld/b$j$a;->g()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public static final j(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClassVerificationFailure",
            "NewApi"
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ld/b$j$a;->h(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method

.method public static final k(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ld/b$j$a;->i(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p0
.end method

.method public static final l()Z
    .locals 3
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClassVerificationFailure",
            "NewApi"
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0}, Ld/b$j$a;->j()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    check-cast p2, Landroidx/activity/result/k;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$j;->d(Landroid/content/Context;Landroidx/activity/result/k;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p2, Landroidx/activity/result/k;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Ld/b$j;->f(Landroid/content/Context;Landroidx/activity/result/k;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$j;->m(ILandroid/content/Intent;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public d(Landroid/content/Context;Landroidx/activity/result/k;)Landroid/content/Intent;
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroidx/activity/result/k;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v0, "sxscetn"

    const-string/jumbo v0, "tnsxcte"

    const/4 v4, 0x4

    const-string/jumbo v0, "toxmecn"

    const-string v0, "context"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v0, "npmuo"

    const-string/jumbo v0, "npumi"

    const/4 v4, 0x1

    const-string v0, "bpitn"

    const-string/jumbo v0, "input"

    const/4 v4, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ld/b$j$a;->j()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo v1, "r.Iiinupoo.IGSPnCred_craKaEvtood.di"

    const-string v1, "ICpvorSed..iGaMa_nKoirI.oocdPnErtid"

    const/4 v4, 0x6

    const-string/jumbo v1, "v.irnoPpecM._EiaGndrrpA.aKtooddISIC"

    const-string v1, "android.provider.action.PICK_IMAGES"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p2}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ld/b$j$a;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v2, "duwlrau qb.le isl Ruaveq"

    const-string/jumbo v2, "uraiqbl aueunl Rl dswev."

    const/4 v4, 0x6

    const-string v2, "a.sruu lwsl aeviRel ndqu"

    const-string v2, "Required value was null."

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ld/b$j$a;->d(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    iget-object p1, p1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x2

    const/4 v3, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v2, ".numravittenii..tK.I_coaEcnGcrrx.IostoytStdAPialCMca"

    const-string v2, "an.nrtul.Mi_otectdvaccocCnItiAitatari.sS.EIxPGuy.rKo"

    const/4 v4, 0x0

    const-string/jumbo v2, "ntuaoEdoI.KianGPCa_yrtivsMtil.c.SA.xccIronot.atcritd"

    const-string v2, "androidx.activity.result.contract.action.PICK_IMAGES"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    :goto_0
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto/16 :goto_1

    :cond_1
    const/4 v4, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    throw p1

    :cond_2
    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ld/b$j$a;->f(Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_4

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v0, p1}, Ld/b$j$a;->c(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object p1, p1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const-string v2, ".oovCb.r.inpriPlKogmcegocnI.Ei_SrgsMotAae.GddIpmao"

    const-string/jumbo v2, "roiK.mnpoM..mgcreP.cIaespdSoooavnG.gliigd_EItroCAd"

    const/4 v4, 0x5

    const-string v2, "com.google.android.gms.provider.action.PICK_IMAGES"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    iget-object v2, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    throw p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v1, "O_aE.UuniactiDoqtinto.TdNr.neCOEdMP"

    const-string v1, "CrON.acOqndodaU.TtE.NDnioetP_EtiMni"

    const/4 v4, 0x7

    const-string v1, "ENDteonpina_ta.idnUo.OT.nPCdcrMNOtE"

    const-string v1, "android.intent.action.OPEN_DOCUMENT"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez p2, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string p2, "**/"

    const-string p2, "**/"

    const/4 v4, 0x2

    const-string p2, "*/*"

    const-string p2, "*/*"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p2, "image/*"

    const/4 v4, 0x3

    const-string/jumbo v0, "iqo/se*"

    const-string v0, "*/seovi"

    const/4 v4, 0x2

    const-string/jumbo v0, "video/*"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    filled-new-array {p2, v0}, [Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v0, "tesmo.re.xIPS.MMddYa_tarTtinEnE"

    const-string v0, ".E.mSatd.oae_rInierdiYTtEtMxPMn"

    const/4 v4, 0x7

    const-string/jumbo v0, "nnomPn.tE_YiEMd.TrIettMSriade.a"

    const-string v0, "android.intent.extra.MIME_TYPES"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    :cond_5
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1
.end method

.method public final f(Landroid/content/Context;Landroidx/activity/result/k;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroidx/activity/result/k;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/activity/result/k;",
            ")",
            "Ld/a$a<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "context"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const-string/jumbo p1, "tuipo"

    const-string/jumbo p1, "uipto"

    const/4 v2, 0x4

    const-string p1, "bpiun"

    const-string/jumbo p1, "input"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method public final m(ILandroid/content/Intent;)Landroid/net/Uri;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 p1, 0x1

    or-int/2addr v2, p1

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 p1, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p2, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-nez p1, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object p1, Ld/b$d;->a:Ld/b$d$a;

    invoke-virtual {p1, p2}, Ld/b$d$a;->a(Landroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lkotlin/collections/u;->D2(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p1, Landroid/net/Uri;

    :cond_2
    move-object v0, p1

    move-object v0, p1

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method
