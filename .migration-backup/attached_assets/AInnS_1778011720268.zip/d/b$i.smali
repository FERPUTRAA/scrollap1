.class public Ld/b$i;
.super Ld/a;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld/b$i$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Landroidx/activity/result/k;",
        "Ljava/util/List<",
        "Landroid/net/Uri;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final b:Ld/b$i$a;
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field private final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Ld/b$i$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ld/b$i$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Ld/b$i;->b:Ld/b$i$a;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {p0, v2, v0, v1}, Ld/b$i;-><init>(IILkotlin/jvm/internal/w;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method public constructor <init>(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput p1, p0, Ld/b$i;->a:I

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x1

    xor-int/2addr v2, v0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-le p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo v0, "tms ibxu hthsreaignst a me1 hsM"

    const-string/jumbo v0, "xtsgi1 mm htnsasirubeM  thha e "

    const/4 v2, 0x4

    const-string v0, "hsam 1grMbuhxt e itehmesmi nt  "

    const-string v0, "Max items must be higher than 1"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p1
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    sget-object p1, Ld/b$i;->b:Ld/b$i$a;

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Ld/b$i$a;->a()I

    move-result p1

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Ld/b$i;-><init>(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@@yo  @@ ~i@~KS~o -@~/~/b@@ ~  Ms .o@@~~~ f @1btm@~~ ioca@~ ~iv ~@@d~@rb ful no~@~4@~  t@~~l~oo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p2, Landroidx/activity/result/k;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ld/b$i;->d(Landroid/content/Context;Landroidx/activity/result/k;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-object p1
.end method

.method public bridge synthetic b(Landroid/content/Context;Ljava/lang/Object;)Ld/a$a;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p2, Landroidx/activity/result/k;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Ld/b$i;->e(Landroid/content/Context;Landroidx/activity/result/k;)Ld/a$a;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Ld/b$i;->f(ILandroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public d(Landroid/content/Context;Landroidx/activity/result/k;)Landroid/content/Intent;
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroidx/activity/result/k;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi",
            "ClassVerificationFailure"
        }
    .end annotation

    .annotation build Landroidx/annotation/i;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v0, "cxmetbt"

    const-string/jumbo v0, "xctmten"

    const/4 v6, 0x6

    const-string v0, "cnxttou"

    const-string v0, "context"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v0, "tipop"

    const-string/jumbo v0, "nitpo"

    const/4 v6, 0x6

    const-string/jumbo v0, "npiqu"

    const-string/jumbo v0, "input"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object v0, Ld/b$j;->a:Ld/b$j$a;

    const/4 v6, 0x3

    invoke-virtual {v0}, Ld/b$j$a;->j()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance p1, Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v1, "orsrdvnoIcnMaPbA_ed.i.riE.CpGISoiaK"

    const-string/jumbo v1, "rrnv.bointP_rpKodCiAaiGeEaIo.MSIc.d"

    const/4 v6, 0x5

    const-string/jumbo v1, "novmrriM.edoKo.iCdGn_pEArPadatIIS.c"

    const-string v1, "android.provider.action.PICK_IMAGES"

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, p2}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget p2, p0, Ld/b$i;->a:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Ld/c;->a()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-gt p2, v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo p2, "xParorI_.EMM.CaKedddtXnIi_AorS.puvAeoi"

    const-string/jumbo p2, "od.rEPuAMtpoii.eSraIAxrr.ea_dvMKd_XCIn"

    const/4 v6, 0x7

    const-string/jumbo p2, "p.A_MbEraCISrXMd.rneoxaivKA._PdotdGIei"

    const-string p2, "android.provider.extra.PICK_IMAGES_MAX"

    const/4 v6, 0x6

    const/4 v5, 0x0

    iget v0, p0, Ld/b$i;->a:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto/16 :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string p2, "  si)ruxmoMaPdoctsiMelug  ebmk sesaaLtqege e.aemMesIlSx(iia tpustmt"

    const-string/jumbo p2, "mstsSadpgs es mMe sm(goeitati)ucxLm kMaaiPseeMiter atI  bqxue.illeo"

    const/4 v6, 0x3

    const-string/jumbo p2, "teauieSpsltram qexadermaig s.M iebu(coLstte es keI giotmPsaM ixMml)"

    const-string p2, "Max items must be less or equals MediaStore.getPickImagesMaxLimit()"

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    throw p1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Ld/b$j$a;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v3, "ew ullevqdi.quan rleaq s"

    const-string/jumbo v3, "s nai.ueq lveullq adRwer"

    const/4 v6, 0x5

    const-string v3, "ersdsll. qluvew nuiuaa R"

    const-string v3, "Required value was null."

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v4, "I_omgecoAd.rPg..e.vidlISrMogio.san.p_mredsrMmtEXGxAoa"

    const-string/jumbo v4, "xgsKM..dEA.advrIorPsXG_c.neldie.o_ie.omrmSporoagtgIMA"

    const-string v4, "GI_corlrpPtiAvmexogdrr_gMs.iAEooae.d.MgSoC.KIane.mod."

    const-string v4, "com.google.android.gms.provider.extra.PICK_IMAGES_MAX"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Ld/b$j$a;->d(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x5

    const-string/jumbo v2, "xo.mSn_Iyvaa.atccid..Ai.GitrEoKnlricItocttdsutPCerMn"

    const/4 v6, 0x4

    const-string v2, "ccnStbtaMiIcG.Kxo_viiuda.adrr.cIECtt.yon.titAarleons"

    const-string v2, "androidx.activity.result.contract.action.PICK_IMAGES"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p1

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget p1, p0, Ld/b$i;->a:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-object p1, v1

    move-object p1, v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    throw p1

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Ld/b$j$a;->f(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v1, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ld/b$j$a;->c(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p1, :cond_5

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object p1, p1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance p2, Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v0, "ecgg.iu.mEAvM.alGpioootrddnsIo.rPcdCoaom.grI_oeiSK"

    const-string/jumbo v0, "oIeKoSgGirAedc..I.MsPvaompdoomcrdi.Eg_.aion.ltCgor"

    const/4 v6, 0x2

    const-string v0, "iCov.dapidM.d.tsgcAa.opI.groIgeloo_mmcPinGr.SoKnrE"

    const-string v0, "com.google.android.gms.provider.action.PICK_IMAGES"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    iget-object v0, p1, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p2, v0, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget p1, p0, Ld/b$i;->a:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p2, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-object p1, p2

    move-object p1, p2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto/16 :goto_1

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x7

    const/4 v5, 0x5

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    throw p1

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance p1, Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v1, "tndOtbUorenii.EToctOdNnnC.EM_NiDaP."

    const/4 v6, 0x0

    const-string/jumbo v1, "ne.UEaEaqntT.dr_PiO.CioNMnDoitdcnNt"

    const-string v1, "android.intent.action.OPEN_DOCUMENT"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p2}, Landroidx/activity/result/k;->a()Ld/b$j$f;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, p2}, Ld/b$j$a;->e(Ld/b$j$f;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string p2, "LWsLtr.Tnti.Lu_xAMaUOddP.rtenaoeEin"

    const-string/jumbo p2, "tOrrA_uedL.LLoUdieinW.nEx.tnIaPMatT"

    const/4 v6, 0x0

    const-string p2, "Ltxm.rtLLdEInaeLA_MTUn.PaOior.tWedi"

    const-string p2, "android.intent.extra.ALLOW_MULTIPLE"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1, p2, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-nez p2, :cond_7

    const-string p2, "*/*"

    const-string p2, "**/"

    const/4 v6, 0x3

    const-string p2, "**/"

    const-string p2, "*/*"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string p2, "a/imoep"

    const-string/jumbo p2, "pgamei/"

    const/4 v6, 0x6

    const-string p2, "i*g/eba"

    const-string/jumbo p2, "image/*"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v0, "e*v/iqu"

    const-string v0, "/qiev*o"

    const/4 v6, 0x1

    const-string/jumbo v0, "video/*"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    filled-new-array {p2, v0}, [Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v0, "rtnniExp.oMdTtIa._dSYteE.srePMn"

    const-string v0, "YMsneitrirx.Mnt._EEdde.TatSnPIo"

    const/4 v6, 0x4

    const-string v0, "enrda..aqPMttniYeMiE.oSTtndxI_E"

    const-string v0, "android.intent.extra.MIME_TYPES"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    :cond_7
    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    return-object p1
.end method

.method public final e(Landroid/content/Context;Landroidx/activity/result/k;)Ld/a$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroidx/activity/result/k;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroidx/activity/result/k;",
            ")",
            "Ld/a$a<",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "ttscemn"

    const-string/jumbo v0, "xecmntt"

    const/4 v2, 0x7

    const-string v0, "ectmoxt"

    const-string v0, "context"

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo p1, "tpuio"

    const/4 v2, 0x1

    const-string/jumbo p1, "uitno"

    const-string/jumbo p1, "input"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public final f(ILandroid/content/Intent;)Ljava/util/List;
    .locals 3
    .param p2    # Landroid/content/Intent;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p2, 0x0

    :goto_1
    const/4 v1, 0x1

    move v2, v1

    if-eqz p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x2

    sget-object p1, Ld/b$d;->a:Ld/b$d$a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Ld/b$d$a;->a(Landroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz p1, :cond_2

    const/4 v2, 0x2

    goto :goto_2

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object p1

    :goto_2
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1
.end method
