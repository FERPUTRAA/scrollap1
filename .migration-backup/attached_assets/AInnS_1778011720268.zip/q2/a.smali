.class public Lq2/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "MTCommonPrivatesApi"

.field public static final b:I = 0x1b3

.field public static final c:Ljava/lang/String; = "4.3.5"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "iys~ola-@iK@c ~o@ ~m1  tb @~~@@~ ~~/@@fn@ @@ t~l  @v@@~S~b@@f~~~~~~oo  ~u@~ rb M@ @io4@ sd~/~ ~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p0, p1}, Lz2/c;->a(Landroid/content/Context;Ljava/lang/String;)Lz2/a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p0, p1, p2}, Lz2/c;->b(Landroid/content/Context;Ljava/lang/String;I)Lz2/a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static c(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    const-string/jumbo p0, "votmiPsCMsmrAmoTnap"

    const-string/jumbo p0, "mpsoAtairnMevsoTPCm"

    const/4 v3, 0x1

    const-string p0, "MPesootnAiipmvmrCaT"

    const-string p0, "MTCommonPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo p1, "tyceibcit /animwxne n mtt/htot"

    const-string/jumbo p1, "txtme imytp w/cotnatnctihi ne/"

    const/4 v3, 0x5

    const-string/jumbo p1, "w t/nhue tpynit/c t atmeicxino"

    const-string p1, "can\'t init with empty context"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x0

    and-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Ly2/b;->i:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-nez p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    sget-boolean p1, Ly2/b;->j:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x4

    move v3, v2

    sput-boolean p1, Ly2/b;->j:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x7

    invoke-static {p1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object p1, Lo2/b;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/16 v0, 0x3e8

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    return-void
.end method

.method public static d(Landroid/content/Context;Lc3/b;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "oTiovPspaAptMniCrmm"

    const-string v0, "TvsCopMomiPnAartimo"

    const/4 v3, 0x5

    const-string/jumbo v0, "ionmeAosqCPrMptvmaT"

    const-string v0, "MTCommonPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    const-string/jumbo p0, "xospn rmsot/beyttwva c n tc/theree"

    const-string/jumbo p0, "wcextbe mp / tnveanscb/yrtoeht tro"

    const/4 v3, 0x6

    const-string/jumbo p0, "rttmn xe/tp/yernceawthmisote cov b"

    const-string p0, "can\'t observer with empty context"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p0, " c aobtruenrpr onne/srotsscaievoh/"

    const-string p0, "anroarupv srihs sbrtnenc/t/ c ooee"

    const/4 v3, 0x5

    const-string/jumbo p0, "s asnb/ohnrretpese oenca/rcitbo rv"

    const-string p0, "can\'t observer in another process"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v0

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p0, p1}, Lc3/a;->d(Landroid/content/Context;Lc3/b;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;J)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string/jumbo v0, "oAmPiaupvomsTetirpC"

    const-string/jumbo v0, "veotmPppmCoirasinTA"

    const-string v0, "MTCommonPrivatesApi"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez p0, :cond_0

    const/4 v8, 0x7

    const-string/jumbo p0, "snn ptgpqeoe lshyatecxDmotdpet ai/tytcMesw e"

    const-string/jumbo p0, "xttMi aeqstcn eoaeDw dytncmyo/ts le/tgeepshp"

    const/4 v8, 0x7

    const-string/jumbo p0, "tetctytsqDMtch xpisot/w ee alenmyaeag spoend"

    const-string p0, "can\'t postMessageDelayed with empty context"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    if-eqz v1, :cond_1

    const/4 v7, 0x4

    move v8, v7

    const-string p0, "dtsne/coty ialp/ss etetag mha MeywasnmeeD"

    const/4 v8, 0x4

    const-string/jumbo p0, "mostMe/paeeptnysty aeiawnD cemdte/a  hgls"

    const-string p0, "can\'t postMessageDelayed with empty name"

    const/4 v7, 0x2

    or-int/2addr v8, v7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    return-void

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-nez v1, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-nez v1, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const-string p0, "can\'t postMessageDelayed in another process"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    return-void

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-wide v5, p3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual/range {v1 .. v6}, Lz2/c;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;J)V

    const/4 v7, 0x5

    move v8, v7

    return-void
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1}, Lz2/c;->e(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1, p2}, Lz2/c;->f(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "tPmmTemmsrvCiaMnopo"

    const-string/jumbo v0, "pPrmisAmavTemoCMton"

    const/4 v3, 0x3

    const-string v0, "MTCommonPrivatesApi"

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p0, "i teostxp aoawh/tnende/scy ctt Msemgn"

    const-string p0, "can\'t sendMessage with empty context"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo p0, "w/   bensaaei ea/mMtetsspoecngdhnm"

    const-string p0, "ensdo stamcepi ee s gae/nMtwmn/ath"

    const/4 v3, 0x6

    const-string/jumbo p0, "yc isMut //enngas dnmasmhteeewp et"

    const-string p0, "can\'t sendMessage with empty name"

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p0, "en  h npeoertsaMeon srdecacns/iaptbss"

    const-string p0, "anronb n Msegte p/ eaneorscethcsissda"

    const/4 v3, 0x4

    const-string/jumbo p0, "ssit eapqshsnsergee nntcrcn a//Med oo"

    const-string p0, "can\'t sendMessage in another process"

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-void

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p0, p1, p2, p3}, Lz2/c;->g(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public static i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V
    .locals 9

    const/4 v8, 0x1

    const-string v0, "AMsvoauotPeimrmnTpi"

    const-string v0, "TpomMAutersiinvmaPo"

    const-string/jumbo v0, "oMemimiPmvoCrTnpasA"

    const-string v0, "MTCommonPrivatesApi"

    if-nez p0, :cond_0

    const-string p0, "Mtaeo  thd /tc/sxylnetysatwDeeinaoppmndece s"

    const-string p0, "/tdtyawp shmtyxeesatMD indn oc/acenes tlepee"

    const-string/jumbo p0, "oMesxbenpat tsenwyte cmgi/dhe/escly te adnDa"

    const-string p0, "can\'t sendMessageDelayed with empty context"

    const/4 v8, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v8, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x4

    if-eqz v1, :cond_1

    const/4 v8, 0x1

    const-string p0, " taeywneqsgsdMt maplinncya/D/eeahmedee s "

    const-string p0, "ed dttuhnygeec/e eawM pmmislys sneatnaeaD"

    const-string p0, "can\'t sendMessageDelayed with empty name"

    const/4 v8, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    return-void

    :cond_1
    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x2

    if-nez v1, :cond_2

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x0

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x1

    if-nez v1, :cond_2

    const/4 v8, 0x5

    const-string p0, "ace ysdpasen/nne eosrcssdrhps/aog MaliDe nte"

    const-string/jumbo p0, "oesnseae/onn  splDsnd yeas ceircaMehre/dtsag"

    const-string/jumbo p0, "riae rhcqaongd  lspnseosnytM eedeset/sacD/en"

    const-string p0, "can\'t sendMessageDelayed in another process"

    const/4 v8, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    return-void

    :cond_2
    invoke-static {}, Lz2/c;->c()Lz2/c;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x0

    move v4, p2

    move v4, p2

    move v4, p2

    move v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-wide v6, p4

    const/4 v8, 0x0

    invoke-virtual/range {v1 .. v7}, Lz2/c;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V

    const/4 v8, 0x1

    return-void
.end method

.method public static j(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo p0, "omsiersTMmtmpCAavPn"

    const-string/jumbo p0, "vMrmePiniAmTpaotmCs"

    const-string p0, "TaemCPiniMrmoptAvso"

    const-string p0, "MTCommonPrivatesApi"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p1, " enroMe xasossste cPatdinMcnihtTg petoento/m/soaec"

    const-string/jumbo p1, "nTgcospaecy xhdo s aotst/s/MeannesotieMmtrPcn teei"

    const/4 v2, 0x5

    const-string p1, "i axcbs meynncMeTett/saoaep gtnrtdPosciMs/owes nht"

    const-string p1, "can\'t sendMessageToMainProcess with empty context"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lr2/a;->b()Lr2/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1, p2}, Lr2/a;->i(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static k(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const-string p0, "ernPvMuCbaiToptmAoi"

    const-string/jumbo p0, "nisirbetTaoAoMpvmCP"

    const/4 v2, 0x4

    const-string/jumbo p0, "pCrnPTspoaAmMtevimo"

    const-string p0, "MTCommonPrivatesApi"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string p1, "aneade cqepoPhoMsetsmsecRgxewottt nrisceynott ems/ /"

    const-string p1, "can\'t sendMessageToRemoteProcess with empty context"

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lr2/a;->b()Lr2/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1, p2}, Lr2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v1, 0x0

    or-int/2addr v2, v1

    return-void
.end method
