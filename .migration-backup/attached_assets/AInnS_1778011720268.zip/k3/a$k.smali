.class public interface abstract Lk3/a$k;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "k"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "day"

.field public static final b:Ljava/lang/String; = "begin_hour"

.field public static final c:Ljava/lang/String; = "begin_minute"

.field public static final d:Ljava/lang/String; = "end_hour"

.field public static final e:Ljava/lang/String; = "end_minute"
