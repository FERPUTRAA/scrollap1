.class public interface abstract Lk3/a$p;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "p"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "XIAOMI_APPID"

.field public static final b:Ljava/lang/String; = "XIAOMI_APPKEY"

.field public static final c:Ljava/lang/String; = "XIAOMI_GLOBAL_APPID"

.field public static final d:Ljava/lang/String; = "XIAOMI_GLOBAL_APPKEY"

.field public static final e:Ljava/lang/String; = "MEIZU_APPID"

.field public static final f:Ljava/lang/String; = "MEIZU_APPKEY"

.field public static final g:Ljava/lang/String; = "OPPO_APPID"

.field public static final h:Ljava/lang/String; = "OPPO_APPKEY"

.field public static final i:Ljava/lang/String; = "OPPO_APPSECRET"
