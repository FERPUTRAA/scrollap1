.class public interface abstract Lk3/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "id"

.field public static final b:Ljava/lang/String; = "count"

.field public static final c:Ljava/lang/String; = "interval"

.field public static final d:Ljava/lang/String; = "longitude"

.field public static final e:Ljava/lang/String; = "latitude"
