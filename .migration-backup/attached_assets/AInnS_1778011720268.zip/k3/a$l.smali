.class public interface abstract Lk3/a$l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "l"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "sequence"

.field public static final b:Ljava/lang/String; = "alias"

.field public static final c:Ljava/lang/String; = "tag"

.field public static final d:Ljava/lang/String; = "mobileNumber"
