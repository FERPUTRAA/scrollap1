.class public interface abstract Lk3/a$i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "i"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "notification_layout"

.field public static final b:Ljava/lang/String; = "id"

.field public static final c:Ljava/lang/String; = "layout_id"

.field public static final d:Ljava/lang/String; = "icon_view_id"

.field public static final e:Ljava/lang/String; = "icon_resource_id"

.field public static final f:Ljava/lang/String; = "title_view_id"

.field public static final g:Ljava/lang/String; = "content_view_id"

.field public static final h:Ljava/lang/String; = "time_view_id"
