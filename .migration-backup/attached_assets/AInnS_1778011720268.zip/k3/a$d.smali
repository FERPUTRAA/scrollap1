.class public interface abstract Lk3/a$d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "xiaomi"

.field public static final b:Ljava/lang/String; = "blackshark"

.field public static final c:Ljava/lang/String; = "huawei"

.field public static final d:Ljava/lang/String; = "honor"

.field public static final e:Ljava/lang/String; = "meizu"

.field public static final f:Ljava/lang/String; = "oppo"

.field public static final g:Ljava/lang/String; = "realme"

.field public static final h:Ljava/lang/String; = "oneplus"

.field public static final i:Ljava/lang/String; = "vivo"
