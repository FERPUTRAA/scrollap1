.class public interface abstract Lk3/a$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lk3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "e"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "message"

.field public static final b:Ljava/lang/String; = "message_json"

.field public static final c:Ljava/lang/String; = "message_limit"

.field public static final d:Ljava/lang/String; = "notification_id"

.field public static final e:Ljava/lang/String; = "msg_status"

.field public static final f:Ljava/lang/String; = "third_msg_status"

.field public static final g:I = 0x3fa

.field public static final h:I = 0x3e8

.field public static final i:I = 0x404

.field public static final j:I = 0x40e

.field public static final k:I = 0x42c

.field public static final l:I = 0x42d
