.class public Ld3/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method private static a([BLjava/lang/String;Ljava/lang/String;I)[B
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o sco@u@it@l /@Sro.@@~lb~ ~o~~f@@fv ~@ ~m~~@os  @1botiia@ ~-@  ~/d ~~~4~@y~~@~@~@~M @K@  @  b~~n"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, v0}, Ld3/a;->g(Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "EAS"

    const-string v1, "ASE"

    const/4 v3, 0x0

    const-string v1, "EAS"

    const-string v1, "AES"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, p1, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object p1, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Ld3/a;->l([B)Ljavax/crypto/spec/IvParameterSpec;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const-string p2, "/SsiP/CSgKE7BCAndCPd"

    const/4 v3, 0x2

    const-string p2, "SKPmCaCE7BdPngCd//Si"

    const-string p2, "AES/CBC/PKCS7Padding"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p2}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2, p3, v0, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p2, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p0
.end method

.method private static b([BLjava/lang/String;I)[B
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1, v0}, Ld3/a;->g(Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "ASE"

    const-string v1, "SEA"

    const/4 v3, 0x4

    const-string v1, "ESA"

    const-string v1, "AES"

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0, p1, v1}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p1, "dS5EoEmgiPSK/naP/ACC"

    const-string p1, "CCPmi/aKA5ddS/EEnSPg"

    const/4 v3, 0x5

    const-string p1, "gPiECb/ASdKP/da5CEBS"

    const-string p1, "AES/ECB/PKCS5Padding"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public static c([BLjava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Ld3/a;->b([BLjava/lang/String;I)[B

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public static d([BLjava/lang/String;Ljava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, v0}, Ld3/a;->a([BLjava/lang/String;Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static e([BLjava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Ld3/a;->b([BLjava/lang/String;I)[B

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static f([BLjava/lang/String;Ljava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, p1, p2, v0}, Ld3/a;->a([BLjava/lang/String;Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method private static g(Ljava/lang/String;Ljava/lang/String;)[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/UnsupportedEncodingException;
        }
    .end annotation

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-array v0, v0, [B

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    div-int/lit8 v1, v1, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    div-int/lit8 v3, v3, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    array-length p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v2, v0, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    array-length p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    array-length v1, p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0, v2, v0, p1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    return-object v0
.end method

.method public static h()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/security/SecureRandom;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/Random;->nextInt()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const v1, 0xffffff

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method public static i(J)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-wide/16 v0, 0xa

    const-wide/16 v0, 0xa

    const/4 v5, 0x0

    const-wide/16 v0, 0xa

    const-wide/16 v0, 0xa

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    rem-long v0, p0, v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    long-to-int v0, v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    packed-switch v0, :pswitch_data_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const/4 v5, 0x2

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    mul-long/2addr v0, p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, 0x4a

    const-wide/16 v2, 0x4a

    const/4 v5, 0x6

    const-wide/16 v2, 0x4a

    const-wide/16 v2, 0x4a

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    rem-long/2addr p0, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto/16 :goto_0

    :pswitch_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide/16 v0, 0x25

    const-wide/16 v0, 0x25

    const/4 v5, 0x0

    const-wide/16 v0, 0x25

    const-wide/16 v0, 0x25

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    mul-long/2addr v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-wide/16 v2, 0x5b

    const-wide/16 v2, 0x5b

    const/4 v5, 0x0

    const-wide/16 v2, 0x5b

    const-wide/16 v2, 0x5b

    const/4 v5, 0x7

    const/4 v4, 0x4

    rem-long/2addr p0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto/16 :goto_0

    :pswitch_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-wide/16 v0, 0x1d

    const-wide/16 v0, 0x1d

    const/4 v5, 0x7

    const-wide/16 v0, 0x1d

    const-wide/16 v0, 0x1d

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const-wide/16 v2, 0x29

    const-wide/16 v2, 0x29

    const/4 v5, 0x7

    const-wide/16 v2, 0x29

    const-wide/16 v2, 0x29

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    rem-long/2addr p0, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    goto/16 :goto_0

    :pswitch_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x1f

    const-wide/16 v0, 0x1f

    const/4 v5, 0x7

    const-wide/16 v0, 0x1f

    const-wide/16 v0, 0x1f

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    mul-long/2addr v0, p0

    const/4 v4, 0x2

    move v5, v4

    const-wide/16 v2, 0x27

    const/4 v5, 0x0

    const-wide/16 v2, 0x27

    const-wide/16 v2, 0x27

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    rem-long/2addr p0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto/16 :goto_0

    :pswitch_3
    const/4 v5, 0x4

    const/4 v4, 0x2

    const-wide/16 v0, 0x7

    const-wide/16 v0, 0x7

    const/4 v5, 0x1

    const-wide/16 v0, 0x7

    const-wide/16 v0, 0x7

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    mul-long/2addr v0, p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x44

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    rem-long/2addr p0, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto/16 :goto_0

    :pswitch_4
    const-wide/16 v0, 0x11

    const-wide/16 v0, 0x11

    const/4 v5, 0x1

    const-wide/16 v0, 0x11

    const-wide/16 v0, 0x11

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    mul-long/2addr v0, p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x31

    const-wide/16 v2, 0x31

    const/4 v5, 0x4

    const-wide/16 v2, 0x31

    const-wide/16 v2, 0x31

    rem-long/2addr p0, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :pswitch_5
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-wide/16 v0, 0xd

    const/4 v5, 0x5

    const-wide/16 v0, 0xd

    const-wide/16 v0, 0xd

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const-wide/16 v2, 0x60

    const-wide/16 v2, 0x60

    const/4 v5, 0x7

    const-wide/16 v2, 0x60

    const-wide/16 v2, 0x60

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    rem-long/2addr p0, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :pswitch_6
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-wide/16 v0, 0x3

    const-wide/16 v0, 0x3

    const/4 v5, 0x6

    const-wide/16 v0, 0x3

    const/4 v5, 0x2

    mul-long/2addr v0, p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-wide/16 v2, 0x49

    const-wide/16 v2, 0x49

    const/4 v5, 0x7

    const-wide/16 v2, 0x49

    const-wide/16 v2, 0x49

    const/4 v4, 0x1

    move v5, v4

    rem-long/2addr p0, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :pswitch_7
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-wide/16 v0, 0x17

    const-wide/16 v0, 0x17

    const/4 v5, 0x5

    const-wide/16 v0, 0x17

    const-wide/16 v0, 0x17

    const/4 v5, 0x4

    mul-long/2addr v0, p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x2

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    rem-long/2addr p0, v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :pswitch_8
    const/4 v5, 0x2

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v5, 0x3

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    mul-long/2addr v0, p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x58

    const-wide/16 v2, 0x58

    const/4 v5, 0x7

    const-wide/16 v2, 0x58

    const-wide/16 v2, 0x58

    const/4 v5, 0x4

    rem-long/2addr p0, v2

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-long/2addr v0, p0

    const/4 v5, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p1, "JCKP"

    const-string p1, "PKJC"

    const/4 v5, 0x7

    const-string p1, "JPCK"

    const-string p1, "JCKP"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p0}, Ld3/o;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static j(Ljava/lang/String;C)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, "8uFoT"

    const-string v0, "8FT-o"

    const-string v0, "UTF-8"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    move v4, v3

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v4, 0x5

    array-length v2, p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ge v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    aget-byte v2, p0, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    xor-int/2addr v2, p1

    const/4 v3, 0x2

    const/4 v3, 0x7

    int-to-byte v2, v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-byte v2, p0, v1

    const/4 v3, 0x1

    move v4, v3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    array-length v1, p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p1, p0, v0, v1}, Ljava/lang/String;-><init>([BII)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    return-object p1
.end method

.method public static k(J)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v0, 0xa

    const/4 v5, 0x0

    const-wide/16 v0, 0xa

    const-wide/16 v0, 0xa

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    rem-long v0, p0, v0

    const/4 v5, 0x0

    long-to-int v0, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    packed-switch v0, :pswitch_data_0

    const/4 v4, 0x0

    move v5, v4

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const/4 v5, 0x6

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    mul-long/2addr v0, p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-wide/16 v2, 0x4a

    const-wide/16 v2, 0x4a

    const/4 v5, 0x5

    const-wide/16 v2, 0x4a

    const-wide/16 v2, 0x4a

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    rem-long/2addr p0, v2

    const/4 v5, 0x4

    goto/16 :goto_0

    :pswitch_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v0, 0x25

    const-wide/16 v0, 0x25

    const/4 v5, 0x5

    const-wide/16 v0, 0x25

    const/4 v5, 0x1

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-wide/16 v2, 0x5b

    const-wide/16 v2, 0x5b

    const/4 v5, 0x7

    const-wide/16 v2, 0x5b

    const-wide/16 v2, 0x5b

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    rem-long/2addr p0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto/16 :goto_0

    :pswitch_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-wide/16 v0, 0x1d

    const-wide/16 v0, 0x1d

    const/4 v5, 0x2

    const-wide/16 v0, 0x1d

    const-wide/16 v0, 0x1d

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    mul-long/2addr v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-wide/16 v2, 0x29

    const-wide/16 v2, 0x29

    const/4 v5, 0x1

    const-wide/16 v2, 0x29

    const-wide/16 v2, 0x29

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    rem-long/2addr p0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto/16 :goto_0

    :pswitch_2
    const/4 v4, 0x4

    move v5, v4

    const-wide/16 v0, 0x1f

    const-wide/16 v0, 0x1f

    const-wide/16 v0, 0x1f

    const-wide/16 v0, 0x1f

    const/4 v5, 0x0

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const-wide/16 v2, 0x27

    const-wide/16 v2, 0x27

    const/4 v5, 0x7

    const-wide/16 v2, 0x27

    const-wide/16 v2, 0x27

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    rem-long/2addr p0, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto/16 :goto_0

    :pswitch_3
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-wide/16 v0, 0x7

    const-wide/16 v0, 0x7

    const/4 v5, 0x1

    const-wide/16 v0, 0x7

    const-wide/16 v0, 0x7

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    mul-long/2addr v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-wide/16 v2, 0x44

    const-wide/16 v2, 0x44

    const/4 v5, 0x5

    const-wide/16 v2, 0x44

    const-wide/16 v2, 0x44

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    rem-long/2addr p0, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto/16 :goto_0

    :pswitch_4
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-wide/16 v0, 0x11

    const-wide/16 v0, 0x11

    const/4 v5, 0x4

    const-wide/16 v0, 0x11

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x31

    const-wide/16 v2, 0x31

    const/4 v5, 0x3

    const-wide/16 v2, 0x31

    const-wide/16 v2, 0x31

    const/4 v5, 0x7

    const/4 v4, 0x1

    rem-long/2addr p0, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto/16 :goto_0

    :pswitch_5
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-wide/16 v0, 0xd

    const-wide/16 v0, 0xd

    const/4 v5, 0x6

    const-wide/16 v0, 0xd

    const-wide/16 v0, 0xd

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x60

    const-wide/16 v2, 0x60

    const/4 v5, 0x6

    const-wide/16 v2, 0x60

    const-wide/16 v2, 0x60

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    rem-long/2addr p0, v2

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :pswitch_6
    const/4 v5, 0x4

    const-wide/16 v0, 0x3

    const-wide/16 v0, 0x3

    const/4 v5, 0x6

    const-wide/16 v0, 0x3

    const-wide/16 v0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-wide/16 v2, 0x49

    const-wide/16 v2, 0x49

    const/4 v5, 0x6

    const-wide/16 v2, 0x49

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    rem-long/2addr p0, v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :pswitch_7
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-wide/16 v0, 0x17

    const-wide/16 v0, 0x17

    const/4 v5, 0x3

    const-wide/16 v0, 0x17

    const-wide/16 v0, 0x17

    const/4 v4, 0x4

    move v5, v4

    mul-long/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x2

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    rem-long/2addr p0, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :pswitch_8
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    mul-long/2addr v0, p0

    const/4 v4, 0x7

    and-int/2addr v5, v4

    const-wide/16 v2, 0x58

    const-wide/16 v2, 0x58

    const/4 v5, 0x0

    const-wide/16 v2, 0x58

    const-wide/16 v2, 0x58

    const/4 v5, 0x5

    rem-long/2addr p0, v2

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    add-long/2addr v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    move v5, v4

    const-string p1, "JCPK"

    const-string p1, "KPJC"

    const/4 v5, 0x5

    const-string p1, "JCKP"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Ld3/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static l([B)Ljavax/crypto/spec/IvParameterSpec;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-array v1, v0, [Ljava/lang/Class;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-class v2, [B

    const-class v2, [B

    const/4 v5, 0x4

    const-class v2, [B

    const-class v2, [B

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p0, v0, v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-class p0, Ljavax/crypto/spec/IvParameterSpec;

    const-class p0, Ljavax/crypto/spec/IvParameterSpec;

    const/4 v5, 0x3

    const-class p0, Ljavax/crypto/spec/IvParameterSpec;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0, v0, v1}, Ld3/l;->c(Ljava/lang/Class;[Ljava/lang/Object;[Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    check-cast p0, Ljavax/crypto/spec/IvParameterSpec;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object p0
.end method
