.class public Ld3/f;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "FileUtils"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Ljava/io/File;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "oMst @o/@v ~1~~@  @ @@sy~~b@@~~ .~@ oK~~ ~ ~oc~m@~@ @4f /@i@~aS@~ol@-n  ~ bi@ @uri@~bt@o~~  ~dlf"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    :cond_0
    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/io/File;->createNewFile()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "fl mreihHtastnalPc otFei::iaemlc-"

    const-string v1, " ishacl eitai-llceomfrHnPte:eFa:t"

    const/4 v3, 0x1

    const-string v1, "atefoeatHl:Fcl co hreiitta:n-lePm"

    const-string v1, "action:createHtmlFile - filePath:"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, " omc:btent"

    const-string v1, "cntm :t,eo"

    const/4 v3, 0x1

    const-string/jumbo v1, "tc n,tu:ne"

    const-string v1, ", content:"

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "tFillsepo"

    const-string v1, "FtlioseUl"

    const-string v1, "eitisUFlq"

    const-string v1, "FileUtils"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, p1}, Ld3/f;->k(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return p0
.end method

.method public static c(Ljava/lang/String;[B)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    array-length v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-lez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p1}, Ld3/f;->l(Ljava/lang/String;[B)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method public static d(Ljava/lang/String;I)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v0, "listbileF"

    const-string v0, "eilFUbtli"

    const/4 v6, 0x5

    const-string/jumbo v0, "letmiUslF"

    const-string v0, "FileUtils"

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v1, Ljava/io/File;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v1, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez p0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result p0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz p0, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x4

    array-length v1, p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const-string/jumbo v2, "t ncoleehhliase.Fu"

    const-string v2, "hahtl u.cneleescFi"

    const/4 v6, 0x2

    const-string/jumbo v2, "ths lbgaeelh.ecFin"

    const-string v2, "cacheFiles.length "

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    array-length v2, p0

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-gt v1, p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-void

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    new-instance v1, Ld3/f$b;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v1}, Ld3/f$b;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    sub-int/2addr v2, p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-ge v1, v2, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v2, Ljava/io/File;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-eqz v3, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v4, "eDiFelu ptehealc "

    const-string v4, "hcec FapDleeietl "

    const/4 v6, 0x1

    const-string v4, " i atllpeeFDeecce"

    const-string v4, "Delete cacheFile "

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v2}, Ld3/f;->e(Ljava/io/File;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :catchall_0
    :cond_6
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method public static e(Ljava/io/File;)Z
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    return v0

    :cond_0
    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {p0}, Ljava/io/File;->isFile()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    move-result p0

    const/4 v7, 0x4

    return p0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v1, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    array-length v2, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    move v3, v0

    move v3, v0

    const/4 v7, 0x7

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    if-ge v3, v2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x6

    aget-object v4, v1, v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    new-instance v5, Ljava/io/File;

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v5, p0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v5}, Ljava/io/File;->isDirectory()Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v5}, Ld3/f;->e(Ljava/io/File;)Z

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_1

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    return p0

    :catch_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo p0, "lqFsUliiq"

    const-string/jumbo p0, "ieFsiUllq"

    const/4 v7, 0x6

    const-string p0, "FileUtils"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo v1, "iostle Derrsder "

    const-string v1, " esrdoDl rietrer"

    const-string/jumbo v1, "r  meeeorrDltrde"

    const-string v1, "Delete dir error"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    return v0
.end method

.method private static f(Landroid/content/Context;Ljava/lang/String;ILjava/io/File;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-nez p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1}, Ld3/f;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p3

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    if-nez p3, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p3}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eqz p0, :cond_2

    const/4 v1, 0x4

    invoke-virtual {p3}, Ljava/io/File;->isDirectory()Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p0, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p3}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p0, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    array-length p1, p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-le p1, p2, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    new-instance p1, Ld3/f$a;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p1}, Ld3/f$a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0, p1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    array-length p1, p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    aget-object p0, p0, p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0}, Ld3/f;->e(Ljava/io/File;)Z

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const-string v0, ""

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {p0, p1}, Ld3/f;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo p0, "teUloFlim"

    const-string p0, "UilmtiFel"

    const/4 v3, 0x1

    const-string/jumbo p0, "slleibUtF"

    const-string p0, "FileUtils"

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const-string p1, "ce/ln uno/a b u"

    const-string/jumbo p1, "lnaloecn / / bu"

    const/4 v3, 0x4

    const-string p1, "etnulc/pnl b/  "

    const-string p1, " can\'t be null"

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/io/File;->isFile()Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/io/File;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "//g: blf inac tet"

    const/4 v2, 0x0

    const-string/jumbo v0, "lt g iceqfet/:n a"

    const-string v0, "can\'t get file :"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo p1, "iisuesFUl"

    const-string p1, "UisltFuei"

    const/4 v2, 0x3

    const-string p1, "FlsmiUiel"

    const-string p1, "FileUtils"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static i(Ljava/lang/String;)Z
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v1

    :cond_0
    :try_start_0
    const/4 v3, 0x3

    move v4, v3

    new-instance v0, Ljava/io/File;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "illUoseeFt:i"

    const-string v2, "FileUtils e:"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const-string v0, "iFUipbsll"

    const-string/jumbo v0, "lislieFpU"

    const/4 v4, 0x0

    const-string/jumbo v0, "liUileusF"

    const-string v0, "FileUtils"

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return v1
.end method

.method public static j(Ljava/io/File;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    if-eqz p0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v3, 0x2

    new-instance v1, Ljava/io/ObjectInputStream;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v2, Ljava/io/FileInputStream;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v2, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :catchall_1
    move-exception p0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw p0

    :cond_1
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method public static k(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "Fqp8U"

    const-string v0, "-F8qU"

    const/4 v2, 0x2

    const-string v0, "-T8qF"

    const-string v0, "UTF-8"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0, p1}, Ld3/f;->l(Ljava/lang/String;[B)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0

    :goto_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "gtsxyetotenpss:e Be"

    const-string v0, "essetytoipBnet :exg"

    const/4 v2, 0x5

    const-string/jumbo v0, "topmi ecBsentet:yge"

    const-string v0, "getBytes exception:"

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo p1, "stiloielm"

    const-string/jumbo p1, "isFmieltl"

    const/4 v2, 0x6

    const-string p1, "FelUiblis"

    const-string p1, "FileUtils"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0
.end method

.method private static l(Ljava/lang/String;[B)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    return v1

    :cond_0
    const/4 v6, 0x2

    if-nez p1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-array p1, v1, [B

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v2, Ljava/io/File;

    const/4 v6, 0x7

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v2}, Ld3/f;->a(Ljava/io/File;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v3, Ljava/io/FileOutputStream;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v3, p1}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v3}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x4

    const/4 p0, 0x1

    const/4 v6, 0x1

    move v5, p0

    move v5, p0

    const/4 v6, 0x4

    return p0

    :catchall_0
    move-exception p0

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_1

    :catch_0
    move-exception p1

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_0

    :catch_1
    move-exception p1

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "oUiteFusi"

    const-string/jumbo v2, "seUioiFlt"

    const/4 v6, 0x6

    const-string v2, "Uslltiepi"

    const-string v2, "FileUtils"

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v4, "xtsvle cqeobn:ea te pii"

    const-string/jumbo v4, "sei:vbtapetol icneeox  "

    const/4 v6, 0x5

    const-string v4, "avsflsoetecpxieit:o e  "

    const-string/jumbo v4, "save to file exception:"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " path = "

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x0

    invoke-static {v0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    return v1

    :catchall_1
    move-exception p0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    throw p0
.end method

.method public static m(Ljava/io/File;Ljava/lang/Object;)Z
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v1, "ilumiFUle"

    const-string v1, "FsliliueU"

    const/4 v6, 0x4

    const-string/jumbo v1, "ltleosiiF"

    const-string v1, "FileUtils"

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/io/File;->isDirectory()Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto/16 :goto_1

    :cond_0
    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p0}, Ld3/f;->a(Ljava/io/File;)V

    const/4 v6, 0x6

    new-instance v2, Ljava/io/ObjectOutputStream;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v3, Ljava/io/FileOutputStream;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v3, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v2, v3}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 p0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    return p0

    :catchall_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v2, 0x0

    :goto_0
    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v4, "eonflboetp :ep ita cvse"

    const-string/jumbo v4, "v aoeolpnteep e istfic:"

    const/4 v6, 0x4

    const-string/jumbo v4, "save to file exception:"

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string p1, "=atqp u "

    const-string/jumbo p1, "q at p=h"

    const/4 v6, 0x2

    const-string p1, " t=p h p"

    const-string p1, " path = "

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    return v0

    :catchall_2
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p0

    :cond_1
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo p0, "ysorota qltunuo  leeosh lidfelrdr bi c"

    const-string p0, "  syunosbleefoocri ailtrrn d dulle hot"

    const/4 v6, 0x3

    const-string/jumbo p0, "ltso l hrno  stnduobi dlfureac  rileey"

    const-string p0, "file should not be null or a directory"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v0
.end method
