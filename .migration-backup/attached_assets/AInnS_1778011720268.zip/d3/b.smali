.class public Ld3/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ld3/b$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/Object;

.field private static b:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/ThreadLocal<",
            "Ljava/text/SimpleDateFormat;",
            ">;>;"
        }
    .end annotation
.end field

.field private static volatile c:Ld3/b$a;

.field public static d:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Ld3/b;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    sput-object v0, Ld3/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "ydsmyyMmMyHs_"

    const-string v0, "HysMydmyym_Md"

    const/4 v2, 0x7

    const-string v0, "dmymMHHy_Myym"

    const-string/jumbo v0, "yyyyMMdd_HHmm"

    const/4 v1, 0x0

    const/4 v1, 0x2

    sput-object v0, Ld3/b;->d:Ljava/lang/String;

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/text/SimpleDateFormat;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "cfatodio@  ~o  lb~ @@4b~@~-@or~  M@1@~l@~~@S@~ ~@@   @y.i~o i~~~sv  t~/~m @~fou K~~@@b@~@n~@/o~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    sget-object v0, Ld3/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    check-cast v0, Ljava/lang/ThreadLocal;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v1, Ld3/b;->a:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-enter v1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    sget-object v0, Ld3/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast v0, Ljava/lang/ThreadLocal;

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Ld3/b$a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Ld3/b$a;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    sput-object v0, Ld3/b;->c:Ld3/b$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v0, Ld3/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object v2, Ld3/b;->c:Ld3/b$a;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    sput-object v0, Ld3/b;->c:Ld3/b$a;

    const/4 v4, 0x1

    sget-object v0, Ld3/b;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast p0, Ljava/lang/ThreadLocal;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    throw p0

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast p0, Ljava/text/SimpleDateFormat;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p0
.end method

.method public static b()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "ydHsMbmmmsHyyy"

    const-string/jumbo v0, "ysHmysMddyymmH"

    const/4 v3, 0x6

    const-string/jumbo v0, "yyyMysuMdsmHHm"

    const-string/jumbo v0, "yyyyMMddHHmmss"

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    invoke-static {v0}, Ld3/b;->a(Ljava/lang/String;)Ljava/text/SimpleDateFormat;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public static c()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Ld3/b;->d:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Ld3/b;->a(Ljava/lang/String;)Ljava/text/SimpleDateFormat;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public static d()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    const-string v0, ":Hd:ys-pmMysmd-Hyoy"

    const-string/jumbo v0, "y_ymodHHysd-:Msmy:-"

    const/4 v3, 0x7

    const-string/jumbo v0, "sH_dy-:mqM:-dyHMsym"

    const-string/jumbo v0, "yyyy-MM-dd_HH:mm:ss"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0}, Ld3/b;->a(Ljava/lang/String;)Ljava/text/SimpleDateFormat;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public static e(Ljava/util/Date;I)Z
    .locals 6

    const/4 v5, 0x1

    if-nez p0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 p0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    return p0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {p0}, Ljava/util/Date;->getTime()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v5, 0x3

    neg-int p0, p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 p1, 0x6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, p1, p0}, Ljava/util/Calendar;->roll(II)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->after(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    return p0
.end method

.method public static f(Ljava/lang/String;)Ljava/util/Date;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Ld3/b;->d:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Ld3/b;->a(Ljava/lang/String;)Ljava/text/SimpleDateFormat;

    move-result-object v0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0

    :catchall_0
    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x7

    move v1, p0

    move v1, p0

    const/4 v2, 0x7

    return-object p0
.end method
