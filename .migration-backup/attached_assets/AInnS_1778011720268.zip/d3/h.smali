.class public Ld3/h;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static a([B)[B
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "vbsl  o~K@~@y o~~@t-~i @ o~~/~@@@.o ~~~@@abt@f~~@ @S~@~~cs@n id M4  @~@f @ b~r1@~mil uo@ @ ~ o~/"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v1, 0x6

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-array v2, v1, [B

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    fill-array-data v2, :array_0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    array-length v3, p0

    const/4 v7, 0x3

    and-int/2addr v8, v7

    new-array v3, v3, [B

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    move v4, v0

    move v4, v0

    const/4 v8, 0x2

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    array-length v5, p0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ge v4, v5, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    aget-byte v5, p0, v4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    array-length v6, p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    add-int/2addr v6, v4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    rem-int/2addr v6, v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    aget-byte v6, v2, v6

    const/4 v8, 0x6

    const/4 v7, 0x5

    xor-int/2addr v5, v6

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    int-to-byte v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    aput-byte v5, v3, v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object v3

    :catchall_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-array p0, v0, [B

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    return-object p0

    nop

    :array_0
    .array-data 1
        0x20t
        0x19t
        0x8t
        0x16t
        0x11t
        0x30t
    .end array-data
.end method

.method public static b([B)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    new-instance v0, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0}, Ld3/h;->a([B)[B

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static c(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v0, "xxx"

    const-string/jumbo v0, "xxx"

    const/4 v4, 0x5

    const-string/jumbo v0, "xxx"

    const-string/jumbo v0, "xxx"

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Ld3/h;->a([B)[B

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v2, "rdams="

    const-string v2, "a=sdgr"

    const/4 v4, 0x6

    const-string v2, "=gdaou"

    const-string v2, "guard="

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p0}, Ld3/h;->a([B)[B

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v2, "remeeb=r"

    const-string/jumbo v2, "rr=meeev"

    const/4 v4, 0x7

    const-string/jumbo v2, "rveersu="

    const-string/jumbo v2, "reverse="

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v2, Ljava/lang/String;

    const/4 v4, 0x0

    invoke-direct {v2, p0}, Ljava/lang/String;-><init>([B)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const-string v2, "e:"

    const/4 v4, 0x0

    const-string v2, ":e"

    const-string v2, "e:"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method
