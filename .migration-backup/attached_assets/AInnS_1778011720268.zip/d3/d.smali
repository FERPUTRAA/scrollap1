.class public final synthetic Ld3/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/time/ZoneId;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/@s~@~~ @ @@c@ ~~y@@f1b@ ~tri @o miS/~~@@~.l~@ 4@v  ~na~o o@~~ ~~ bbfol@Kuio@~@ ~  o ~~~@s~M@-t "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method
