.class public Ld3/g;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "GZipUtil"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Ljava/io/Closeable;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "cssy.~b~nM@a~~@t~ fb@~~~r@lS~ @K   ~@@ ~o~@@@/ 1 ~ @io~~t  @i@/o f v 4o boi~~ld~o@@@@@u ~@~~m@~-"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v1, "eQ mdolcluiilseea ts"

    const-string/jumbo v1, "udslecti ilQoy esael"

    const/4 v3, 0x5

    const-string/jumbo v1, "syfioeo l lQlecdeuai"

    const-string v1, "closeQuietly failed "

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "iGZmtlUi"

    const/4 v3, 0x3

    const-string v0, "GZipUtil"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public static b([B)[B
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz p0, :cond_2

    const/4 v7, 0x1

    array-length v0, p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance p0, Ljava/util/zip/GZIPInputStream;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p0, v1}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v2, 0x100

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-array v2, v2, [B

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-ltz v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, v2, v4, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-object v2

    :catchall_0
    move-exception v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo v3, "oUltGbiZ"

    const-string/jumbo v3, "pZiGotUl"

    const/4 v7, 0x5

    const-string/jumbo v3, "tZiGiluU"

    const-string v3, "GZipUtil"

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v5, "eaifpd punzb "

    const-string v5, " f lzbuinedap"

    const/4 v7, 0x3

    const-string/jumbo v5, "liifzea qunp "

    const-string/jumbo v5, "unzip failed "

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    and-int/2addr v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v3, v2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x0

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 p0, 0x0

    and-int/2addr v7, p0

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-object p0

    :catchall_1
    move-exception v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x7

    invoke-static {p0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    throw v2

    :cond_2
    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object p0
.end method

.method public static c([B)[B
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    array-length v0, p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x7

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x2

    new-instance v1, Ljava/util/zip/GZIPOutputStream;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v1, v0}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1, p0}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "iuslGZpU"

    const-string/jumbo v2, "iiUpZGul"

    const/4 v6, 0x4

    const-string/jumbo v2, "ilZmUpti"

    const-string v2, "GZipUtil"

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v4, " ae olfidip"

    const-string/jumbo v4, "zip failed "

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    const/4 p0, 0x6

    const/4 p0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    return-object p0

    :catchall_1
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Ld3/g;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    throw p0

    :cond_1
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object p0
.end method
