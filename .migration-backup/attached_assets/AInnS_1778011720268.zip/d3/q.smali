.class public Ld3/q;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "Utils"

.field private static final b:Ljava/lang/Object;

.field private static c:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/ThreadLocal<",
            "Ljava/text/SimpleDateFormat;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Ld3/q;->b:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    sput-object v0, Ld3/q;->c:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Ljava/io/Closeable;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static b(Landroid/content/Context;I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    int-to-float p1, p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p1, p0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    float-to-int p0, p0

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return p0
.end method

.method public static c(DDDD)D
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide v0, 0x3f81df46a2529d39L    # 0.008726646259971648

    const-wide v0, 0x3f81df46a2529d39L    # 0.008726646259971648

    const/4 v5, 0x4

    const-wide v0, 0x3f81df46a2529d39L    # 0.008726646259971648

    const-wide v0, 0x3f81df46a2529d39L    # 0.008726646259971648

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    mul-double/2addr p2, v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    mul-double/2addr p6, v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    sub-double v2, p2, p6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    sub-double/2addr p0, p4

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    mul-double/2addr p0, v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide p4

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    const/4 v5, 0x1

    invoke-static {p4, p5, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide p4

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    mul-double/2addr p2, v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p2, p3}, Ljava/lang/Math;->cos(D)D

    move-result-wide p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    mul-double/2addr p6, v0

    const/4 v4, 0x6

    or-int/2addr v5, v4

    invoke-static {p6, p7}, Ljava/lang/Math;->cos(D)D

    move-result-wide p6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    mul-double/2addr p2, p6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0, p1}, Ljava/lang/Math;->sin(D)D

    move-result-wide p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p0, p1, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    mul-double/2addr p2, p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-double/2addr p4, p2

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-static {p4, p5}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0, p1}, Ljava/lang/Math;->asin(D)D

    move-result-wide p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const-wide p2, 0x416854a640000000L    # 1.2756274E7

    const-wide p2, 0x416854a640000000L    # 1.2756274E7

    const/4 v5, 0x4

    const-wide p2, 0x416854a640000000L    # 1.2756274E7

    const-wide p2, 0x416854a640000000L    # 1.2756274E7

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    mul-double/2addr p0, p2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-wide p2, 0x40c3880000000000L    # 10000.0

    const-wide p2, 0x40c3880000000000L    # 10000.0

    const/4 v5, 0x0

    const-wide p2, 0x40c3880000000000L    # 10000.0

    const-wide p2, 0x40c3880000000000L    # 10000.0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    mul-double/2addr p0, p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p0, p1}, Ljava/lang/Math;->round(D)J

    move-result-wide p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-wide/16 p2, 0x2710

    const-wide/16 p2, 0x2710

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    div-long/2addr p0, p2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    long-to-double p0, p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-wide p0
.end method

.method public static d(Lorg/json/JSONArray;)Ljava/util/ArrayList;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz p0, :cond_2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x7

    goto :goto_1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-ge v1, v2, :cond_2

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object v0
.end method

.method public static e(Ljava/util/Collection;Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lez p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    add-int/lit8 p0, p0, -0x1

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public static f(Landroid/content/Context;)Landroid/util/DisplayMetrics;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Landroid/util/DisplayMetrics;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "idsonw"

    const-string/jumbo v1, "wosdni"

    const/4 v3, 0x4

    const-string/jumbo v1, "niomdw"

    const-string/jumbo v1, "window"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast p0, Landroid/view/WindowManager;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    move v3, v2

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method

.method public static g(Ljava/io/InputStream;)[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/16 v1, 0x400

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-array v1, v1, [B

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v3, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eq v2, v3, :cond_0

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x7

    move v4, v3

    move v4, v3

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    throw p0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance p0, Ljava/io/IOException;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v0, "liStonsuan mIelm pt"

    const-string/jumbo v0, "ltnm Iienl mptsurSa"

    const/4 v5, 0x7

    const-string/jumbo v0, "tuS ebnmsnulripl tI"

    const-string v0, "InputStream is null"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p0
.end method

.method public static h(Ljava/io/InputStream;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/io/InputStream;->available()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-array v0, v0, [B

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p0, Ljava/io/IOException;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo v0, "u IuStuarlnipsemnot"

    const-string/jumbo v0, "iuatolS tmnIlunsrep"

    const/4 v2, 0x1

    const-string/jumbo v0, "nuamiuep lltsn Irpt"

    const-string v0, "InputStream is null"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    throw p0
.end method

.method public static i(Landroid/content/Context;Landroid/view/View;ZIIII)Landroid/view/ViewGroup$LayoutParams;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    instance-of v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    new-instance v1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1, v0}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p2, :cond_1

    const/4 v3, 0x3

    invoke-static {p0, p3}, Ld3/q;->b(Landroid/content/Context;I)I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {p0, p5}, Ld3/q;->b(Landroid/content/Context;I)I

    move-result p5

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, p4}, Ld3/q;->b(Landroid/content/Context;I)I

    move-result p4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p6}, Ld3/q;->b(Landroid/content/Context;I)I

    move-result p6

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, p3, p4, p5, p6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p2, "][igabsrrread.wil eeMtfni  eV"

    const/4 v3, 0x7

    const-string/jumbo p2, "rl.Mgn rqawtsVfrie ]ed i:[eia"

    const-string p2, "[setViewMargin] failed. err: "

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p1, "iUslu"

    const-string/jumbo p1, "tulUi"

    const-string p1, "Usimt"

    const-string p1, "Utils"

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0
.end method
