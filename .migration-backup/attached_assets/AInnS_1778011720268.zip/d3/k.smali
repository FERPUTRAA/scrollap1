.class public Ld3/k;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o sn~  a~@@1 rfd @l@y@~~@fK-@~oi@ @oMic/o@st~otl  @~ ~@iS @bo ~~@~~@~ ~~@u@v@@@~~m~  4~b /~~ b ."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0x21

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1, p2, v0}, Ld3/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, p1, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0
.end method

.method public static b(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/16 v1, 0x21

    const/4 v9, 0x7

    const/4 v8, 0x6

    if-lt v0, v1, :cond_0

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v7, 0x2

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static/range {v2 .. v7}, Ld3/i;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-object p0

    :cond_0
    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-object p0
.end method
