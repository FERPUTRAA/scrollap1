.class public final synthetic Ld3/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/time/ZoneId;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~ m~o ~@@@ @o~~a@ @ysf~4 @.@  dcr1~o~K@vl u  ~ ~-o@S @/@i ~t@Mb~ ~@ ~@@~bi~o@@ot ib~@~~ln~~f/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method
