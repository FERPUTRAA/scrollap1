.class public final Ld3/f$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld3/f;->d(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Ljava/io/File;Ljava/io/File;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2}, Ljava/io/File;->lastModified()J

    move-result-wide p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    sub-long/2addr v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-wide/16 p1, 0x0

    const/4 v3, 0x6

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    cmp-long p1, v0, p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-gez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-lez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x0

    return p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p1, Ljava/io/File;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p2, Ljava/io/File;

    invoke-virtual {p0, p1, p2}, Ld3/f$b;->a(Ljava/io/File;Ljava/io/File;)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    return p1
.end method
