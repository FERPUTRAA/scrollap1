.class public Ld3/o;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "0123456789ABCDEF"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~~@o~/ f~@ b@t u  @c@~SM@ @ ~~f4@n@i.@l~b@ Ka @li~~oosv@ o~m @~~@~r~t~@@~~@ o/d 1@~  @ o~- bi"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v1, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v1}, Landroid/util/Base64;->decode([BI)[B

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :catchall_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0

    :catchall_0
    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, "/w@mu/0fsa05#-9/]/+^u4//e-"

    const-string v0, "4^su/wf90//@#/-+e5/u$0a/]-"

    const-string v0, "f//eo$9a]/-/5u4u+0^-/0@/w["

    const-string v0, "[^\\w#$@\\-\u4e00-\u9fa5]+"

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Ld3/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/16 v0, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x18

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v0, "5DM"

    const-string v0, "5MD"

    const/4 v6, 0x1

    const-string v0, "MD5"

    const-string v0, "MD5"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    array-length v1, p0

    const/4 v5, 0x7

    move v6, v5

    new-array v1, v1, [B

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    move v3, v2

    move v3, v2

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    array-length v4, p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ge v3, v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    aget-char v4, p0, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    int-to-byte v4, v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    aput-byte v4, v1, v3

    const/4 v5, 0x6

    const/4 v6, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ge v2, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-byte v1, p0, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/16 v3, 0x10

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ge v1, v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v3, "0"

    const-string v3, "0"

    const/4 v6, 0x7

    const-string v3, "0"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x2

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object p0

    :catchall_0
    const/4 v6, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p0
.end method

.method public static f([B)Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v0, "5MD"

    const-string v0, "5MD"

    const/4 v6, 0x6

    const-string v0, "5MD"

    const-string v0, "MD5"

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    array-length v1, p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge v2, v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    aget-byte v3, p0, v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/16 v4, 0x10

    const/4 v6, 0x6

    if-ge v3, v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object p0

    :catchall_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x1

    return-object p0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x5

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Ld3/o;->h([B)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static h([B)Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v0, "SAH1"

    const-string v0, "SHA1"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v1, p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ge v2, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    aget-byte v3, p0, v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/16 v4, 0x10

    const/4 v6, 0x6

    const/4 v5, 0x6

    if-ge v3, v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x0

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p0

    :catchall_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x0

    const-string p0, ""

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object p0
.end method

.method public static i(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v0, "D5M"

    const-string v0, "DM5"

    const/4 v6, 0x0

    const-string v0, "MD5"

    const-string v0, "MD5"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object v1, Lx2/a;->b:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    array-length v1, p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-ge v2, v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    aget-byte v3, p0, v2

    const/4 v5, 0x7

    move v6, v5

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/16 v4, 0x10

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ge v3, v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p0

    :catchall_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object p0
.end method

.method public static j(Ljava/nio/ByteBuffer;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x6

    const-string v0, ""

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array v1, v1, [B

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    sget-object v2, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0, v1, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public static k(Ljava/lang/String;)[B
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-array p0, v0, [B

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0

    :catchall_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static l([B)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-nez p0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-object p0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    array-length v1, p0

    const/4 v7, 0x2

    mul-int/lit8 v1, v1, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    array-length v1, p0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-ge v2, v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget-byte v3, p0, v2

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    shr-int/lit8 v4, v3, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    and-int/lit8 v4, v4, 0xf

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v5, "E7360bBmC98D15A2"

    const-string v5, "0DFm7598BA1326CE"

    const/4 v7, 0x3

    const-string v5, "9B36A1uC8D540E2F"

    const-string v5, "0123456789ABCDEF"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v5, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    and-int/lit8 v3, v3, 0xf

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-object p0
.end method

.method public static m(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    const/4 v0, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "DM5"

    const-string v1, "5DM"

    const/4 v3, 0x6

    const-string v1, "M5D"

    const-string v1, "MD5"

    const/4 v3, 0x7

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0}, Ld3/o;->l([B)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :catchall_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method
