.class public Ld3/p;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "SystemUtil"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "b.s @~-@@~ ~iof~~a/f@ @~@~oslS~@ @o  /@~c~~u~v~o@ K4r@~1@  ~~~@ibni @l @@ M~t~ t@d y~ @~oo~m b @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x3

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v1, "tcsmonereutct_yr"

    const-string v1, "cosre_eocunryttt"

    const/4 v7, 0x7

    const-string v1, "_tetornyetoucdrc"

    const-string v1, "country_detector"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-nez p0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object v0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v2, "uetrybtmCoect"

    const-string v2, "ceumtryCntteo"

    const/4 v7, 0x7

    const-string/jumbo v2, "tdyneuuCcetto"

    const-string v2, "detectCountry"

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x4

    shl-int/2addr v6, v3

    :try_start_1
    const/4 v7, 0x2

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-nez p0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v2, "rtoysICptnouo"

    const-string v2, "CyIoouseonrtt"

    const-string v2, "getCountryIso"

    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const-string v4, "eebgrouSq"

    const-string v4, "crgeebSuo"

    const/4 v7, 0x7

    const-string/jumbo v4, "rSseectou"

    const-string v4, "getSource"

    :try_start_3
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-array v5, v3, [Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast p0, Ljava/lang/Integer;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz p0, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x1

    if-ne p0, v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v0

    :cond_3
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    return-object v1

    :catchall_0
    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v6, 0x3

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v1, ".pSmooreaPdn.strereuystoidi"

    const-string v1, ".poioaurnsd.ediorrtteePyssS"

    const/4 v6, 0x3

    const-string/jumbo v1, "rdsooiaeport.desSsePom.yrti"

    const-string v1, "android.os.SystemProperties"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v1, "tge"

    const-string v1, "get"

    const/4 v6, 0x3

    const-string/jumbo v1, "tge"

    const-string v1, "get"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x2

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-object p1, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 p1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    aput-object p2, v3, p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-array p2, v2, [Ljava/lang/Class;

    const/4 v6, 0x0

    aput-object v0, p2, v4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    aput-object v0, p2, p1

    const/4 v6, 0x1

    invoke-static {p0, v1, v3, p2}, Ld3/l;->d(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;[Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast p0, Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object p0

    :catchall_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-object p0
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const-string v1, "cnoctbiteiyv"

    const-string/jumbo v1, "toycviepnitc"

    const/4 v3, 0x4

    const-string v1, "enitoiuccynt"

    const-string v1, "connectivity"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast p0, Landroid/net/ConnectivityManager;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x1

    :catchall_0
    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0
.end method

.method public static d(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    const/4 v3, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "et/sqpapsmp/"

    const-string v1, "/y/ptapmqses"

    const/4 v3, 0x7

    const-string/jumbo v1, "s//mptpsqeya"

    const-string v1, "/system/app/"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    return p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const-string v1, "a/sapst/dp"

    const-string v1, "ats/p//dap"

    const/4 v3, 0x3

    const-string v1, "/apmatdp//"

    const-string v1, "/data/app/"

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0
.end method
