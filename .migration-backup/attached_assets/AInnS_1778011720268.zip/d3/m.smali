.class public Ld3/m;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String;

.field private static final b:Ljava/lang/String;

.field private static final c:Ljava/lang/String; = "RsaUitl"


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/16 v0, 0x80

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-array v0, v0, [B

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    fill-array-data v0, :array_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Ld3/h;->b([B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Ld3/m;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/16 v0, 0x15

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-array v0, v0, [B

    const/4 v2, 0x4

    fill-array-data v0, :array_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0}, Ld3/h;->b([B)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    sput-object v0, Ld3/m;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void

    nop

    :array_0
    .array-data 1
        0x45t
        0x50t
        0x66t
        0x47t
        0x64t
        0x48t
        0x51t
        0x5ct
        0x5at
        0x5ft
        0x7at
        0x50t
        0x60t
        0x60t
        0x72t
        0x7et
        0x61t
        0x48t
        0x4dt
        0x54t
        0x53t
        0x61t
        0x61t
        0x5dt
        0x5bt
        0x61t
        0x50t
        0x47t
        0x73t
        0x58t
        0x42t
        0x54t
        0x50t
        0x7ct
        0x10t
        0x6bt
        0x62t
        0x61t
        0x67t
        0x0t
        0x4dt
        0x5ft
        0x7bt
        0x59t
        0x28t
        0x63t
        0x70t
        0x40t
        0x5at
        0x2ft
        0x59t
        0x5at
        0x14t
        0x5ft
        0x5et
        0x2ft
        0x4bt
        0x7dt
        0x74t
        0x78t
        0x39t
        0x52t
        0x29t
        0x41t
        0x44t
        0x7dt
        0x59t
        0x5dt
        0x67t
        0x46t
        0x4ft
        0x77t
        0x3at
        0x54t
        0x5ct
        0x68t
        0x4et
        0x5at
        0x65t
        0x64t
        0x65t
        0x0t
        0x6ct
        0x43t
        0x6dt
        0x63t
        0x55t
        0x4t
        0x18t
        0x43t
        0x6ft
        0x7dt
        0x50t
        0x4at
        0x46t
        0x4ft
        0x71t
        0x64t
        0x53t
        0x61t
        0x4et
        0x41t
        0x7bt
        0x72t
        0x7at
        0x5ct
        0x4ct
        0x7bt
        0x38t
        0x54t
        0x7at
        0x72t
        0x41t
        0x56t
        0x47t
        0x20t
        0x76t
        0x7bt
        0x6dt
        0x5at
        0x49t
        0x61t
        0x54t
        0x71t
        0x61t
        0x48t
        0x35t
        0x2bt
    .end array-data

    :array_1
    .array-data 1
        0x44t
        0x42t
        0x71t
        0xft
        0x57t
        0x67t
        0x78t
        0x74t
        0x1ft
        0x70t
        0x52t
        0x4bt
        0x45t
        0x20t
        0x60t
        0x41t
        0x7dt
        0x6ct
        0x7ft
        0x7ft
        0x57t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s~o~@blu i~ @b~   @~4  v1S.i@@@@~ r ~ai -~@~y@s~/@~  ~lM@oodtc~~ ~t@b~@o@K@@~f@   ~~fomn/ ~~~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    const-string/jumbo v0, "sRsmUal"

    const-string/jumbo v0, "slstRUa"

    const/4 v6, 0x2

    const-string/jumbo v0, "sRlUoat"

    const-string v0, "RsaUitl"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v2

    :cond_0
    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {}, Ld3/m;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    move v6, v5

    const-string v4, "RaycebeeKs dmPub"

    const-string v4, " ePmesyaeocbKdRu"

    const/4 v6, 0x1

    const-string/jumbo v4, "ybKPdcuoedueseR "

    const-string v4, "decodeRsaPubKey "

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v3, "_ASE ROpo"

    const-string v3, "AS _oEROD"

    const/4 v6, 0x7

    const-string v3, " EARDS_Mq"

    const-string v3, "RSA_MODE "

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    sget-object v3, Ld3/m;->b:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {}, Ld3/m;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p0, v1, v3}, Ld3/m;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v3, "dbsR e"

    const-string v3, "dRea b"

    const/4 v6, 0x4

    const-string v3, "d smeR"

    const-string v3, "deRsa "

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object v2
.end method

.method private static b()Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v0, Ld3/m;->a:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    move v4, v3

    const-string/jumbo v2, "uasPocebo deeuKy"

    const-string v2, "dayKeeueoPc dsbu"

    const/4 v4, 0x6

    const-string/jumbo v2, "oRPaub seKcebded"

    const-string v2, "decodeRsaPubKey "

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "RpiUatu"

    const-string/jumbo v1, "psUtiRa"

    const-string v1, "RsaUitl"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v0
.end method

.method private static c(Ljava/lang/String;)Ljava/security/interfaces/RSAPublicKey;
    .locals 4

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x0

    move v2, v0

    move v2, v0

    :try_start_0
    const/4 v3, 0x3

    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, "RAS"

    const-string v0, "SAR"

    const/4 v3, 0x4

    const-string v0, "SAR"

    const-string v0, "RSA"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Ljava/security/spec/X509EncodedKeySpec;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast p0, Ljava/security/interfaces/RSAPublicKey;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v1, "KlsRyqoperaA a=e "

    const-string v1, "ee=s Ko qraASRyal"

    const/4 v3, 0x0

    const-string v1, "R=eSasy qa KerloA"

    const-string/jumbo v1, "rsa loadRSAKey e="

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "tssalUs"

    const-string/jumbo v0, "lUsstai"

    const/4 v3, 0x1

    const-string v0, "RiUmtal"

    const-string v0, "RsaUitl"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method private static declared-synchronized d(Ljava/lang/String;Ljava/security/interfaces/RSAPublicKey;Ljava/lang/String;)[B
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const-class v0, Ld3/m;

    const-class v0, Ld3/m;

    const/4 v3, 0x2

    const-class v0, Ld3/m;

    const-class v0, Ld3/m;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-enter v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x2

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p2}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, v1, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p2, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, v1}, Landroid/util/Base64;->decode([BI)[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p0
.end method

.method private static e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p1}, Ld3/m;->c(Ljava/lang/String;)Ljava/security/interfaces/RSAPublicKey;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Ld3/m;->d(Ljava/lang/String;Ljava/security/interfaces/RSAPublicKey;Ljava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 p2, 0x0

    const/4 p2, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p2}, Landroid/util/Base64;->encode([BI)[B

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    const-string/jumbo p2, "m8U-o"

    const-string p2, "8-TmU"

    const/4 v1, 0x3

    const-string p2, "b8-FU"

    const-string p2, "UTF-8"

    const/4 v1, 0x6

    invoke-direct {p1, p0, p2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    return-object p1
.end method
