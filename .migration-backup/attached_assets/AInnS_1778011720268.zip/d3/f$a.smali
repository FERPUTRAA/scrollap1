.class public final Ld3/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld3/f;->f(Landroid/content/Context;Ljava/lang/String;ILjava/io/File;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Ljava/io/File;Ljava/io/File;)I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@sn    mfob@ ~o~@S~it@d@. ~~~o~i  @- ~~lo@@ 1 @~/uo M~~cf~@~aKrob@~~@@~i~@y~ @b/~@@4~@t ~l v s@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/io/File;->lastModified()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    if-lez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/io/File;->lastModified()J

    move-result-wide p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    cmp-long p1, v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-gez p1, :cond_1

    const/4 v5, 0x5

    const/4 p1, 0x1

    const/4 v5, 0x3

    shr-int/2addr v4, p1

    const/4 v5, 0x5

    return p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Ljava/io/File;

    const/4 v1, 0x5

    const/4 v0, 0x4

    check-cast p2, Ljava/io/File;

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Ld3/f$a;->a(Ljava/io/File;Ljava/io/File;)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method
