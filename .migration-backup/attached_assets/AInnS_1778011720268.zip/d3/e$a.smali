.class public final Ld3/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ld3/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v0, "upc"

    const-string/jumbo v0, "upc"

    const/4 v5, 0x7

    const-string/jumbo v0, "puc"

    const-string v0, "cpu"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v0, 0x3

    :goto_0
    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ge v0, v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/16 v3, 0x30

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-lt v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x39

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-le v2, v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x7

    move v5, v4

    return p1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v1
.end method
