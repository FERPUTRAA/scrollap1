.class public Ld3/e;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "DeviceUtil"

.field private static b:Ljava/lang/String; = ""

.field private static c:Ljava/lang/String; = ""

.field private static final d:Ljava/io/FileFilter;


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, Ld3/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ld3/e$a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object v0, Ld3/e;->d:Ljava/io/FileFilter;

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    or-int/2addr v1, v0

    return-void
.end method

.method private static a([BI)I
    .locals 7

    :goto_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@os~io @~t~@ @~K id@cs~ @@@~ @@flro ~@@ ~by~vo ~~ 4~1@@Mi~~@/nm ~~@  o@~@fo~@@/~ tuS~.~  l  -~ab"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    const/4 v0, -0x1

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    array-length v1, p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-ge p1, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x0

    aget-byte v1, p0, p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/16 v2, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eq v1, v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/16 v2, 0x30

    const/4 v6, 0x6

    if-lt v1, v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/16 v3, 0x39

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-gt v1, v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v1, p1, 0x1

    :goto_1
    const/4 v5, 0x0

    move v6, v5

    array-length v4, p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-ge v1, v4, :cond_0

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    aget-byte v4, p0, v1

    const/4 v5, 0x6

    move v6, v5

    if-lt v4, v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-gt v4, v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    sub-int/2addr v1, p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v2, p0, v3, p1, v1}, Ljava/lang/String;-><init>([BIII)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    return p0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x1

    move v6, v5

    goto :goto_0

    :catchall_0
    :cond_2
    const/4 v6, 0x7

    return v0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "dndmdiisor"

    const-string v0, "dosiin_rdd"

    const/4 v2, 0x0

    const-string v0, "ainro_idod"

    const-string v0, "android_id"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public static c()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v4, 0x2

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method public static d()I
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    move v1, v0

    move v1, v0

    const/4 v8, 0x3

    move v1, v0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, -0x1

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Ld3/e;->f()I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-ge v1, v3, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v4, "eme/pbsseuvud/cy/ps/csyti/c"

    const-string v4, "ds/meiu/y/tm/s/eypvcccpuess"

    const/4 v8, 0x7

    const-string v4, "/umiysuyecp/d//sss/svuccete"

    const-string v4, "/sys/devices/system/cpu/cpu"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v4, "fqq_fr/ppfooeremac/xi_upn"

    const-string v4, "fuafomuq_npqfcrxoie/erp_/"

    const/4 v8, 0x1

    const-string v4, "_rofc_/uqqxuec/friapfpenm"

    const-string v4, "/cpufreq/cpuinfo_max_freq"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x7

    new-instance v4, Ljava/io/File;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v4, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v3, :cond_0

    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x2

    move v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/16 v1, 0x80

    const/4 v8, 0x0

    new-array v1, v1, [B

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v3, Ljava/io/FileInputStream;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v3, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v3, v1}, Ljava/io/FileInputStream;->read([B)I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ne v2, v4, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x3

    return v2

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x6

    move v4, v0

    move v4, v0

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    aget-byte v5, v1, v4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/16 v6, 0x30

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-lt v5, v6, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/16 v6, 0x39

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-gt v5, v6, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x6

    move v8, v7

    goto :goto_1

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v5, Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-direct {v5, v1, v0, v4}, Ljava/lang/String;-><init>([BII)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    return v0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v0, Ljava/io/FileInputStream;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string v1, "/oscuniob/rpf"

    const-string v1, "c/popbfu/rnio"

    const/4 v8, 0x2

    const-string/jumbo v1, "picmo/ucpnfro"

    const-string v1, "/proc/cpuinfo"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v1, " pcMoHu"

    const-string v1, "MHcpz u"

    const-string v1, "cupMHbz"

    const-string v1, "cpu MHz"

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v0}, Ld3/e;->w(Ljava/lang/String;Ljava/io/FileInputStream;)I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    mul-int/lit16 v1, v1, 0x3e8

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    return v1

    :catchall_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    return v2
.end method

.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const-string/jumbo v0, "puoen"

    const-string/jumbo v0, "pnpoe"

    const/4 v2, 0x0

    const-string/jumbo v0, "phone"

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Landroid/telephony/TelephonyManager;

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getNetworkOperatorName()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0

    :catchall_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static f()I
    .locals 5

    const/4 v4, 0x1

    const/4 v0, -0x1

    const/4 v4, 0x0

    move v3, v0

    move v3, v0

    :try_start_0
    const/4 v4, 0x2

    new-instance v1, Ljava/io/File;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "/p/eiycpvsd/sstsueqm/sce"

    const-string/jumbo v2, "t/sipeyvq/dess/sucec/s/m"

    const/4 v4, 0x6

    const-string v2, "/esvismtqs/puy/ds/cyscee"

    const-string v2, "/sys/devices/system/cpu/"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v2, Ld3/e;->d:Ljava/io/FileFilter;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    array-length v2, v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length v0, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_2
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0
.end method

.method public static g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    sget-object v0, Ld3/e;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    sget-object v0, Ld3/e;->c:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Ld3/e;->v()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Ld3/e;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public static h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Ld3/e;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Ld3/e;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Ld3/e;->v()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Ld3/e;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static i(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget-object p0, p0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/util/Locale;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public static j()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v4, 0x0

    const/4 v3, 0x0

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method public static k()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public static l()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget-object v1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v0
.end method

.method public static m(Landroid/content/Context;)J
    .locals 6

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v0, "systvcti"

    const-string/jumbo v0, "ivsttcya"

    const/4 v5, 0x5

    const-string/jumbo v0, "viymcita"

    const-string v0, "activity"

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v4, 0x5

    move v5, v4

    const/4 v0, 0x0

    move v5, v0

    const/4 v4, 0x3

    move v5, v4

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v0, Landroid/app/ActivityManager$MemoryInfo;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v0}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-wide v0, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-wide/16 v2, 0x400

    const-wide/16 v2, 0x400

    const/4 v5, 0x5

    const-wide/16 v2, 0x400

    const-wide/16 v2, 0x400

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    div-long/2addr v0, v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-wide v0

    :catchall_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-wide v0
.end method

.method public static n(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v0, "00*"

    const-string v0, "00*"

    const/4 v4, 0x1

    const-string v0, "*00"

    const-string v0, "0*0"

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez p0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    iget v1, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, "*"

    const-string v1, "*"

    const/4 v4, 0x6

    const-string v1, "*"

    const-string v1, "*"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0
.end method

.method public static o(Landroid/content/Context;)J
    .locals 7

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Environment;->getDataDirectory()Ljava/io/File;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    new-instance v0, Landroid/os/StatFs;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v0, p0}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/os/StatFs;->getBlockSize()I

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    int-to-long v1, p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/os/StatFs;->getBlockCount()I

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    int-to-long v3, p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    mul-long/2addr v3, v1

    const/4 v6, 0x7

    const-wide/16 v0, 0x400

    const-wide/16 v0, 0x400

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    div-long/2addr v3, v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-wide v3

    :catchall_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-wide v0
.end method

.method public static p(Landroid/content/Context;)D
    .locals 8

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    int-to-float v0, v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v1, p0, Landroid/util/DisplayMetrics;->xdpi:F

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    div-float/2addr v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    float-to-double v0, v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v6, 0x1

    move v7, v6

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget v4, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v7, 0x2

    int-to-float v4, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget p0, p0, Landroid/util/DisplayMetrics;->ydpi:F

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    div-float/2addr v4, p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    float-to-double v4, v4

    const/4 v7, 0x1

    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    add-double/2addr v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    return-wide v0

    :catchall_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-wide v0
.end method

.method public static q()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static r()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    xor-int/2addr v4, v2

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0
.end method

.method public static s()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public static t()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/TimeZone;->getRawOffset()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const v1, 0x36ee80

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    div-int/2addr v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    int-to-long v0, v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    cmp-long v2, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v3, "-"

    const-string v3, "-"

    const/4 v6, 0x3

    const-string v3, "-"

    const-string v3, "-"

    const/4 v6, 0x5

    if-lez v2, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v4, "+"

    const-string v4, "+"

    const/4 v6, 0x1

    const-string v4, "+"

    const-string v4, "+"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-gez v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    shl-int/2addr v6, v5

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v1, "--"

    const-string v1, "--"

    const/4 v6, 0x5

    const-string v1, "--"

    const-string v1, "--"

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-object v0
.end method

.method public static u()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Ld3/c;->a()Ljava/time/ZoneId;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {v0}, Ld3/d;->a(Ljava/time/ZoneId;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method private static v()V
    .locals 8

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    new-instance v0, Ljava/io/File;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v1, "nciuof/oop/pr"

    const-string v1, "c/umppfoonr/i"

    const/4 v7, 0x6

    const-string v1, "/proc/cpuinfo"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v1, Ljava/io/FileReader;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v1, v0}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    :cond_1
    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    if-eqz v1, :cond_4

    const/4 v6, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "rosPsbcer"

    const-string v2, "cPesorsro"

    const/4 v7, 0x6

    const-string v2, "eooPrcuss"

    const-string v2, "Processor"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const-string v3, ":"

    const-string v3, ":"

    const/4 v7, 0x4

    const-string v3, ":"

    const-string v3, ":"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v2, :cond_3

    :try_start_1
    const/4 v7, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    move v7, v6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-ltz v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    add-int/lit8 v5, v5, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-ge v4, v5, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    sput-object v2, Ld3/e;->b:Ljava/lang/String;

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v2, "bearHwap"

    const-string/jumbo v2, "reHarbaw"

    const/4 v7, 0x7

    const-string/jumbo v2, "qawarrdH"

    const-string v2, "Hardware"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    sput-object v1, Ld3/e;->c:Ljava/lang/String;

    const/4 v7, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void
.end method

.method private static w(Ljava/lang/String;Ljava/io/FileInputStream;)I
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/16 v0, 0x400

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v1, -0x1

    :try_start_0
    const/4 v8, 0x7

    new-array v0, v0, [B

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Ljava/io/FileInputStream;->read([B)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ge v2, p1, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    aget-byte v3, v0, v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/16 v4, 0xa

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eq v3, v4, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_2

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-ne v3, v4, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v2, v2, 0x1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-ge v3, p1, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    sub-int v4, v3, v2

    const/4 v7, 0x3

    shl-int/2addr v8, v7

    aget-byte v5, v0, v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v8, 0x7

    const/4 v7, 0x4

    if-eq v5, v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_2

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    add-int/lit8 v5, v5, -0x1

    const/4 v8, 0x4

    if-ne v4, v5, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v0, v3}, Ld3/e;->a([BI)I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    return p0

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    return v1
.end method
