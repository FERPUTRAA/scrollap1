.class public Ld3/n;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "SM4"

.field private static final b:I = 0x20

.field private static final c:I = 0x10

.field private static d:[B

.field private static e:[I


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/16 v0, 0x100

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-array v0, v0, [B

    const/4 v2, 0x0

    const/4 v1, 0x0

    fill-array-data v0, :array_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput-object v0, Ld3/n;->d:[B

    const/4 v1, 0x6

    move v2, v1

    const/16 v0, 0x20

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-array v0, v0, [I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    fill-array-data v0, :array_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Ld3/n;->e:[I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void

    :array_0
    .array-data 1
        -0x2at
        -0x70t
        -0x17t
        -0x2t
        -0x34t
        -0x1ft
        0x3dt
        -0x49t
        0x16t
        -0x4at
        0x14t
        -0x3et
        0x28t
        -0x5t
        0x2ct
        0x5t
        0x2bt
        0x67t
        -0x66t
        0x76t
        0x2at
        -0x42t
        0x4t
        -0x3dt
        -0x56t
        0x44t
        0x13t
        0x26t
        0x49t
        -0x7at
        0x6t
        -0x67t
        -0x64t
        0x42t
        0x50t
        -0xct
        -0x6ft
        -0x11t
        -0x68t
        0x7at
        0x33t
        0x54t
        0xbt
        0x43t
        -0x13t
        -0x31t
        -0x54t
        0x62t
        -0x1ct
        -0x4dt
        0x1ct
        -0x57t
        -0x37t
        0x8t
        -0x18t
        -0x6bt
        -0x80t
        -0x21t
        -0x6ct
        -0x6t
        0x75t
        -0x71t
        0x3ft
        -0x5at
        0x47t
        0x7t
        -0x59t
        -0x4t
        -0xdt
        0x73t
        0x17t
        -0x46t
        -0x7dt
        0x59t
        0x3ct
        0x19t
        -0x1at
        -0x7bt
        0x4ft
        -0x58t
        0x68t
        0x6bt
        -0x7ft
        -0x4et
        0x71t
        0x64t
        -0x26t
        -0x75t
        -0x8t
        -0x15t
        0xft
        0x4bt
        0x70t
        0x56t
        -0x63t
        0x35t
        0x1et
        0x24t
        0xet
        0x5et
        0x63t
        0x58t
        -0x2ft
        -0x5et
        0x25t
        0x22t
        0x7ct
        0x3bt
        0x1t
        0x21t
        0x78t
        -0x79t
        -0x2ct
        0x0t
        0x46t
        0x57t
        -0x61t
        -0x2dt
        0x27t
        0x52t
        0x4ct
        0x36t
        0x2t
        -0x19t
        -0x60t
        -0x3ct
        -0x38t
        -0x62t
        -0x16t
        -0x41t
        -0x76t
        -0x2et
        0x40t
        -0x39t
        0x38t
        -0x4bt
        -0x5dt
        -0x9t
        -0xet
        -0x32t
        -0x7t
        0x61t
        0x15t
        -0x5ft
        -0x20t
        -0x52t
        0x5dt
        -0x5ct
        -0x65t
        0x34t
        0x1at
        0x55t
        -0x53t
        -0x6dt
        0x32t
        0x30t
        -0xbt
        -0x74t
        -0x4ft
        -0x1dt
        0x1dt
        -0xat
        -0x1et
        0x2et
        -0x7et
        0x66t
        -0x36t
        0x60t
        -0x40t
        0x29t
        0x23t
        -0x55t
        0xdt
        0x53t
        0x4et
        0x6ft
        -0x2bt
        -0x25t
        0x37t
        0x45t
        -0x22t
        -0x3t
        -0x72t
        0x2ft
        0x3t
        -0x1t
        0x6at
        0x72t
        0x6dt
        0x6ct
        0x5bt
        0x51t
        -0x73t
        0x1bt
        -0x51t
        -0x6et
        -0x45t
        -0x23t
        -0x44t
        0x7ft
        0x11t
        -0x27t
        0x5ct
        0x41t
        0x1ft
        0x10t
        0x5at
        -0x28t
        0xat
        -0x3ft
        0x31t
        -0x78t
        -0x5bt
        -0x33t
        0x7bt
        -0x43t
        0x2dt
        0x74t
        -0x30t
        0x12t
        -0x48t
        -0x1bt
        -0x4ct
        -0x50t
        -0x77t
        0x69t
        -0x69t
        0x4at
        0xct
        -0x6at
        0x77t
        0x7et
        0x65t
        -0x47t
        -0xft
        0x9t
        -0x3bt
        0x6et
        -0x3at
        -0x7ct
        0x18t
        -0x10t
        0x7dt
        -0x14t
        0x3at
        -0x24t
        0x4dt
        0x20t
        0x79t
        -0x12t
        0x5ft
        0x3et
        -0x29t
        -0x35t
        0x39t
        0x48t
    .end array-data

    :array_1
    .array-data 4
        0x70e15
        0x1c232a31
        0x383f464d
        0x545b6269
        0x70777e85    # 3.06383E29f
        -0x736c655f    # -2.2742E-31f
        -0x57504943
        -0x3b342d27
        -0x1f18110b
        -0x3fcf5ef
        0x181f262d
        0x343b4249
        0x50575e65
        0x6c737a81
        -0x77706963
        -0x5b544d47
        -0x3f38312b
        -0x231c150f
        -0x700f9f3
        0x141b2229
        0x30373e45
        0x4c535a61    # 5.5404932E7f
        0x686f767d
        -0x7b746d67
        -0x5f58514b
        -0x433c352f
        -0x27201913
        -0xb04fdf7
        0x10171e25
        0x2c333a41
        0x484f565d
        0x646b7279
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method private static a(I)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ss1bfu/~o@ ~ @~4t@ @@~~M@ S@~~ @ @~   o~ib~do~y-@of~l@l i@ oin/m~@@rav@~~@b~@ ~ .to  ~ @@~K~~~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    sget-object v0, Ld3/n;->d:[B

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    ushr-int/lit8 v1, p0, 0x18

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    and-int/lit16 v1, v1, 0xff

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    aget-byte v1, v0, v1

    const/4 v4, 0x2

    and-int/lit16 v1, v1, 0xff

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    shl-int/lit8 v1, v1, 0x18

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    ushr-int/lit8 v2, p0, 0x10

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit16 v2, v2, 0xff

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    aget-byte v2, v0, v2

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    and-int/lit16 v2, v2, 0xff

    const/4 v4, 0x7

    shl-int/lit8 v2, v2, 0x10

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    or-int/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    ushr-int/lit8 v2, p0, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit16 v2, v2, 0xff

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    aget-byte v2, v0, v2

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit16 v2, v2, 0xff

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    shl-int/lit8 v2, v2, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    or-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit16 p0, p0, 0xff

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    aget-byte p0, v0, p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    and-int/lit16 p0, p0, 0xff

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    or-int/2addr p0, v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p0
.end method

.method private static b(I)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, v0}, Ld3/n;->e(II)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    xor-int/2addr v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/16 v1, 0xa

    const/4 v3, 0x5

    invoke-static {p0, v1}, Ld3/n;->e(II)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    xor-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x12

    const/4 v2, 0x1

    move v3, v2

    invoke-static {p0, v1}, Ld3/n;->e(II)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    xor-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 v1, 0x18

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p0, v1}, Ld3/n;->e(II)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    xor-int/2addr p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p0
.end method

.method private static c(I)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v0, 0xd

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0, v0}, Ld3/n;->e(II)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    xor-int/2addr v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v1, 0x17

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v1}, Ld3/n;->e(II)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    xor-int/2addr p0, v0

    const/4 v3, 0x2

    return p0
.end method

.method private static d([B)[I
    .locals 8

    const/4 v7, 0x1

    const/4 v0, 0x6

    const/4 v7, 0x3

    const/4 v0, 0x4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-array v1, v0, [I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ge v2, v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    mul-int/lit8 v3, v2, 0x4

    aget-byte v4, p0, v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    and-int/lit16 v4, v4, 0xff

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    shl-int/lit8 v4, v4, 0x18

    const/4 v7, 0x4

    const/4 v6, 0x3

    add-int/lit8 v5, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    aget-byte v5, p0, v5

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    and-int/lit16 v5, v5, 0xff

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    shl-int/lit8 v5, v5, 0x10

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    or-int/2addr v4, v5

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/lit8 v5, v3, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    aget-byte v5, p0, v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    and-int/lit16 v5, v5, 0xff

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    shl-int/lit8 v5, v5, 0x8

    const/4 v7, 0x2

    or-int/2addr v4, v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    aget-byte v3, p0, v3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    and-int/lit16 v3, v3, 0xff

    const/4 v7, 0x1

    const/4 v6, 0x7

    or-int/2addr v3, v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput v3, v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-object v1
.end method

.method private static e(II)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    shl-int v0, p0, p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    rsub-int/lit8 p1, p1, 0x20

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    ushr-int/2addr p0, p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    or-int/2addr p0, v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p0
.end method

.method private static f([B[B)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    array-length v1, p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    aget-byte v1, p0, v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    aget-byte v2, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    xor-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    int-to-byte v1, v1

    const/4 v4, 0x1

    aput-byte v1, p0, v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    return-void
.end method

.method public static g([B[B[B)[B
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz p0, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    array-length v0, p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto/16 :goto_2

    :cond_0
    const/4 v9, 0x3

    if-eqz p1, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    array-length v0, p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/16 v1, 0x10

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ne v0, v1, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz p2, :cond_1

    const/4 v9, 0x2

    array-length v0, p2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eq v0, v1, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 p2, 0x0

    move v9, p2

    :cond_1
    const/4 v8, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    const/4 v0, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p1, v0}, Ld3/n;->p([BZ)[I

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-array v0, v1, [B

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    new-array v2, v1, [B

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    array-length v3, p0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-array v3, v3, [B

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    move v5, v4

    move v5, v4

    const/4 v9, 0x7

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    add-int/lit8 v6, v5, 0x10

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    array-length v7, p0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-gt v6, v7, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p0, v5, v0, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v0, v2, p1}, Ld3/n;->o([B[B[I)V

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    if-eqz p2, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v2, p2}, Ld3/n;->f([B[B)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto :goto_1

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-array p2, v1, [B

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p0, v5, p2, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {v2, v4, v3, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    move v5, v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    goto :goto_0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v3}, Ld3/n;->n([B)[B

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    return-object p0

    :cond_4
    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo p1, "l 6mtlsehk/s/dygeb1h   neo"

    const-string/jumbo p1, "oess1eg eldylkn  / hh6/stb"

    const/4 v9, 0x0

    const-string/jumbo p1, "so/hob6ktne u yled  e1/hgl"

    const-string/jumbo p1, "key\'s length should be 16"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    throw p0

    :cond_5
    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    return-object p0
.end method

.method public static h([BLjava/lang/String;)[B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x4

    invoke-static {p1}, Ld3/n;->l(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v2, 0x10

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "b-tfu"

    const-string v1, "-fumt"

    const/4 v4, 0x1

    const-string v1, "fut-u"

    const-string/jumbo v1, "utf-8"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p0, v0, p1}, Ld3/n;->g([B[B[B)[B

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p0
.end method

.method public static i([BLjava/lang/String;Ljava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Ld3/n;->l(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "t8po-"

    const-string/jumbo v0, "t-f8o"

    const/4 v2, 0x3

    const-string/jumbo v0, "t-uqf"

    const-string/jumbo v0, "utf-8"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1, p2}, Ld3/n;->g([B[B[B)[B

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method public static j([B[B[B)[B
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz p0, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    array-length v0, p0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    goto/16 :goto_2

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz p1, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x2

    array-length v0, p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/16 v1, 0x10

    const/4 v8, 0x3

    if-ne v0, v1, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz p2, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    array-length v0, p2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eq v0, v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 p2, 0x0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p0}, Ld3/n;->m([B)[B

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x7

    invoke-static {p1, v0}, Ld3/n;->p([BZ)[I

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-array v2, v1, [B

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    array-length v3, p0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-array v3, v3, [B

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    move v4, v0

    move v4, v0

    const/4 v8, 0x7

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v7, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    add-int/lit8 v5, v4, 0x10

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    array-length v6, p0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-gt v5, v6, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p0, v4, v2, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v8, 0x2

    if-eqz p2, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v2, p2}, Ld3/n;->f([B[B)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto :goto_1

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-array p2, v1, [B

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v2, p2, p1}, Ld3/n;->o([B[B[I)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    array-length v6, p2

    const/4 v7, 0x6

    move v8, v7

    invoke-static {p2, v0, v3, v4, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    move v4, v5

    const/4 v8, 0x4

    move v4, v5

    move v4, v5

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    goto :goto_0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x6

    return-object v3

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string p1, "eeshos1nk/s hdt6lg/l by eu"

    const-string p1, "/1sk/bsb heugedne th lyl6o"

    const/4 v8, 0x5

    const-string p1, "eshme6lsl  /g eu1nkbty d/o"

    const-string/jumbo p1, "key\'s length should be 16"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    throw p0

    :cond_5
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x4

    return-object p0
.end method

.method public static k([BLjava/lang/String;Ljava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Ld3/n;->l(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const-string v0, "-8fto"

    const-string/jumbo v0, "utf-8"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Ld3/n;->j([B[B[B)[B

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static l(Ljava/lang/String;)[B
    .locals 7

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    div-int/lit8 v0, v0, 0x2

    const/4 v6, 0x0

    new-array v1, v0, [B

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ge v2, v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    mul-int/lit8 v3, v2, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x3

    aget-char v4, p0, v3

    const/4 v5, 0x6

    or-int/2addr v6, v5

    invoke-static {v4}, Ld3/n;->q(C)I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    shl-int/lit8 v4, v4, 0x4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    aget-char v3, p0, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v3}, Ld3/n;->q(C)I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    or-int/2addr v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    int-to-byte v3, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    aput-byte v3, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object v1
.end method

.method private static m([B)[B
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    array-length v0, p0

    const/4 v5, 0x0

    move v6, v5

    rem-int/lit8 v0, v0, 0x10

    const/4 v6, 0x2

    const/4 v5, 0x6

    rsub-int/lit8 v0, v0, 0x10

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    array-length v1, p0

    const/4 v5, 0x6

    move v6, v5

    add-int/2addr v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p0, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ge v2, v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    array-length v3, p0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    add-int/2addr v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    int-to-byte v4, v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-byte v4, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    return-object v1
.end method

.method private static n([B)[B
    .locals 5

    const/4 v4, 0x0

    array-length v0, p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    aget-byte v0, p0, v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    array-length v1, p0

    const/4 v3, 0x5

    move v4, v3

    sub-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-array v0, v1, [B

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x6

    return-object v0
.end method

.method public static o([B[B[I)V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x1

    invoke-static {p0}, Ld3/n;->d([B)[I

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v0, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    move v1, v0

    const/4 v10, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/16 v2, 0x20

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v3, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ge v1, v2, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    aget v2, p0, v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v4, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    aget v5, p0, v4

    const/4 v10, 0x4

    const/4 v6, 0x2

    const/4 v10, 0x6

    move v9, v6

    move v9, v6

    const/4 v10, 0x5

    aget v7, p0, v6

    const/4 v10, 0x6

    const/4 v9, 0x3

    xor-int/2addr v5, v7

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    aget v7, p0, v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    xor-int/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x5

    aget v7, p2, v1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    xor-int/2addr v5, v7

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {v5}, Ld3/n;->a(I)I

    move-result v5

    const/4 v9, 0x3

    move v10, v9

    invoke-static {v5}, Ld3/n;->b(I)I

    move-result v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    xor-int/2addr v2, v5

    const/4 v10, 0x6

    const/4 v9, 0x2

    aput v2, p0, v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    aget v5, p0, v4

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    aget v7, p0, v6

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    aget v8, p0, v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    xor-int/2addr v7, v8

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    xor-int/2addr v2, v7

    const/4 v10, 0x0

    const/4 v9, 0x0

    add-int/lit8 v7, v1, 0x1

    const/4 v10, 0x3

    aget v7, p2, v7

    const/4 v10, 0x6

    const/4 v9, 0x5

    xor-int/2addr v2, v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v2}, Ld3/n;->a(I)I

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {v2}, Ld3/n;->b(I)I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    xor-int/2addr v2, v5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    aput v2, p0, v4

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    aget v5, p0, v6

    const/4 v9, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    aget v7, p0, v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    aget v8, p0, v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    xor-int/2addr v7, v8

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    xor-int/2addr v2, v7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    add-int/lit8 v7, v1, 0x2

    const/4 v10, 0x2

    aget v7, p2, v7

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    xor-int/2addr v2, v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v2}, Ld3/n;->a(I)I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v2}, Ld3/n;->b(I)I

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    xor-int/2addr v2, v5

    const/4 v10, 0x4

    const/4 v9, 0x6

    aput v2, p0, v6

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    aget v5, p0, v3

    const/4 v10, 0x2

    aget v6, p0, v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    aget v4, p0, v4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    xor-int/2addr v4, v6

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    xor-int/2addr v2, v4

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 v4, v1, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    aget v4, p2, v4

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    xor-int/2addr v2, v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {v2}, Ld3/n;->a(I)I

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v2}, Ld3/n;->b(I)I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    xor-int/2addr v2, v5

    const/4 v9, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    aput v2, p0, v3

    const/4 v9, 0x3

    shr-int/2addr v10, v9

    add-int/lit8 v1, v1, 0x4

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto/16 :goto_0

    :cond_0
    :goto_1
    const/4 v9, 0x6

    move v10, v9

    const/16 p2, 0x10

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-ge v0, p2, :cond_1

    const/4 v9, 0x2

    move v10, v9

    div-int/lit8 p2, v0, 0x4

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    rsub-int/lit8 p2, p2, 0x3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    aget p2, p0, p2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    ushr-int/lit8 v1, p2, 0x18

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    and-int/lit16 v1, v1, 0xff

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    int-to-byte v1, v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    aput-byte v1, p1, v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    add-int/lit8 v1, v0, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x5

    ushr-int/lit8 v2, p2, 0x10

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    and-int/lit16 v2, v2, 0xff

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    int-to-byte v2, v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    aput-byte v2, p1, v1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    add-int/lit8 v1, v0, 0x2

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    ushr-int/lit8 v2, p2, 0x8

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    and-int/lit16 v2, v2, 0xff

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    int-to-byte v2, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    aput-byte v2, p1, v1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-int/lit8 v1, v0, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    and-int/lit16 p2, p2, 0xff

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    int-to-byte p2, p2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    aput-byte p2, p1, v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    add-int/lit8 v0, v0, 0x4

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x6

    return-void
.end method

.method public static p([BZ)[I
    .locals 13

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {p0}, Ld3/n;->d([B)[I

    move-result-object p0

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/4 v0, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x1

    aget v1, p0, v0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    const v2, -0x5c4e453a

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    xor-int/2addr v1, v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    aput v1, p0, v0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v1, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    aget v2, p0, v1

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    const v3, 0x56aa3350

    const/4 v12, 0x4

    const/4 v11, 0x4

    xor-int/2addr v2, v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    aput v2, p0, v1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v2, 0x2

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    aget v3, p0, v2

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    const v4, 0x677d9197

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    xor-int/2addr v3, v4

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    aput v3, p0, v2

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    const/4 v3, 0x3

    const/4 v11, 0x7

    move v12, v11

    aget v4, p0, v3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    const v5, -0x4d8fdd24

    const/4 v12, 0x6

    xor-int/2addr v4, v5

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    aput v4, p0, v3

    const/4 v11, 0x6

    or-int/2addr v12, v11

    const/16 v4, 0x20

    const/4 v12, 0x0

    new-array v5, v4, [I

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x6

    move v6, v0

    move v6, v0

    const/4 v12, 0x5

    move v6, v0

    move v6, v0

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-ge v6, v4, :cond_0

    const/4 v12, 0x2

    aget v7, p0, v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    aget v8, p0, v1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    aget v9, p0, v2

    const/4 v11, 0x3

    const/4 v12, 0x1

    xor-int/2addr v8, v9

    const/4 v12, 0x1

    const/4 v11, 0x5

    aget v9, p0, v3

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    xor-int/2addr v8, v9

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    sget-object v9, Ld3/n;->e:[I

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    aget v9, v9, v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    xor-int/2addr v8, v9

    const/4 v12, 0x2

    invoke-static {v8}, Ld3/n;->a(I)I

    move-result v8

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {v8}, Ld3/n;->c(I)I

    move-result v8

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    xor-int/2addr v7, v8

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    aput v7, p0, v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    aput v7, v5, v6

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    add-int/lit8 v7, v6, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    aget v8, p0, v1

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    aget v9, p0, v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    aget v10, p0, v3

    const/4 v12, 0x0

    xor-int/2addr v9, v10

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    aget v10, p0, v0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    xor-int/2addr v9, v10

    const/4 v11, 0x5

    xor-int/2addr v12, v11

    sget-object v10, Ld3/n;->e:[I

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    aget v10, v10, v7

    const/4 v12, 0x6

    const/4 v11, 0x0

    xor-int/2addr v9, v10

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v9}, Ld3/n;->a(I)I

    move-result v9

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-static {v9}, Ld3/n;->c(I)I

    move-result v9

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    xor-int/2addr v8, v9

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    aput v8, p0, v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    aput v8, v5, v7

    const/4 v11, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    add-int/lit8 v7, v6, 0x2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x5

    aget v8, p0, v2

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    aget v9, p0, v3

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    aget v10, p0, v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    xor-int/2addr v9, v10

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    aget v10, p0, v1

    const/4 v12, 0x0

    xor-int/2addr v9, v10

    const/4 v11, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    sget-object v10, Ld3/n;->e:[I

    const/4 v11, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    aget v10, v10, v7

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    xor-int/2addr v9, v10

    invoke-static {v9}, Ld3/n;->a(I)I

    move-result v9

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v9}, Ld3/n;->c(I)I

    move-result v9

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    xor-int/2addr v8, v9

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    aput v8, p0, v2

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    aput v8, v5, v7

    const/4 v11, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    add-int/lit8 v7, v6, 0x3

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    aget v8, p0, v3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    aget v9, p0, v0

    const/4 v11, 0x1

    and-int/2addr v12, v11

    aget v10, p0, v1

    const/4 v12, 0x1

    xor-int/2addr v9, v10

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    aget v10, p0, v2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    xor-int/2addr v9, v10

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    sget-object v10, Ld3/n;->e:[I

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    aget v10, v10, v7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    xor-int/2addr v9, v10

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static {v9}, Ld3/n;->a(I)I

    move-result v9

    const/4 v12, 0x4

    const/4 v11, 0x2

    invoke-static {v9}, Ld3/n;->c(I)I

    move-result v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    xor-int/2addr v8, v9

    const/4 v11, 0x7

    move v12, v11

    aput v8, p0, v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x6

    aput v8, v5, v7

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    add-int/lit8 v6, v6, 0x4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v12, 0x0

    if-eqz p1, :cond_1

    :goto_1
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    const/16 p0, 0x10

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-ge v0, p0, :cond_1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    aget p0, v5, v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    rsub-int/lit8 p1, v0, 0x1f

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    aget v1, v5, p1

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    aput v1, v5, v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    aput p0, v5, p1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x3

    goto :goto_1

    :cond_1
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-object v5
.end method

.method private static q(C)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const-string v0, "b814fbc3760d59a2"

    const-string v0, "80b3d2uc576149fa"

    const/4 v2, 0x4

    const-string v0, "0123456789abcdef"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->indexOf(I)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    int-to-byte p0, p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p0
.end method

.method public static r([B)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    array-length v0, p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-lt v0, v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    array-length v1, p0

    const/4 v6, 0x5

    const/4 v2, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ge v2, v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    aget-byte v3, p0, v2

    const/4 v6, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v4, 0x10

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ge v3, v4, :cond_0

    const/4 v6, 0x6

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x0

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object p0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const-string v0, " Abpleu oteroarhnettu turbymln smsp iyy "

    const-string v0, " rhnyttpyiom soueyellstmaA rut nrb pb te"

    const/4 v6, 0x3

    const-string/jumbo v0, "loroetepua phybrtt nmi lA es  st nmuryyb"

    const-string/jumbo v0, "this byteArray must not be null or empty"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    throw p0
.end method
