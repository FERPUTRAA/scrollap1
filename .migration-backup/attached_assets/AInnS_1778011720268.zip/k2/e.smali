.class public final Lk2/e;
.super Ljava/lang/Object;


# direct methods
.method public static final synthetic a(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)Lkotlin/properties/f;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(TV;",
            "Ljava/lang/String;",
            "Lcom/tencent/mmkv/MMKV;",
            ")",
            "Lkotlin/properties/f<",
            "Ljava/lang/Object;",
            "TV;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " vs~Kf ~@io/@tu.b~@@/bb ~@-@~~io~i r 4 M@@ @om~d~o~  n~oc~~1 @@@  yl ~@ ~ t~  @@@@foS~~s~~l@a@~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    const-string/jumbo v0, "vk"

    const-string/jumbo v0, "kv"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Lk2/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    const-string v2, "V"

    const/4 v4, 0x0

    const-string v2, "V"

    const-string v2, "V"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v4, 0x3

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, p0, v1, p1, p2}, Lk2/a;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0
.end method

.method public static synthetic b(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;ILjava/lang/Object;)Lkotlin/properties/f;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    and-int/lit8 p4, p3, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p4, :cond_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    and-int/lit8 p4, p3, 0x2

    if-eqz p4, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 p4, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    and-int/2addr p3, p4

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-eqz p3, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/mmkv/MMKV;->defaultMMKV()Lcom/tencent/mmkv/MMKV;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string p1, " a(mlK a=lu l.MluMsVh n0MdedM,=K nf) tV="

    const-string/jumbo p1, "nlsMuM Ml fn=KVddu=,lh a0eMl(K a eVt.) ="

    const/4 v2, 0x2

    const-string p1, "MMKV.defaultMMKV() == null, handle == 0 "

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    throw p0

    :cond_3
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo p3, "kv"

    const-string/jumbo p3, "vk"

    const/4 v2, 0x7

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "kv"

    const/4 v2, 0x6

    invoke-static {p2, p3}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p3, Lk2/a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const-string v0, "V"

    const/4 v2, 0x0

    const-string v0, "V"

    const-string v0, "V"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-class p4, Ljava/lang/Object;

    const-class p4, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p3, p0, p4, p1, p2}, Lk2/a;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p3
.end method

.method public static final synthetic c(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)Lkotlin/properties/f;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(TV;",
            "Ljava/lang/String;",
            "Lcom/tencent/mmkv/MMKV;",
            ")",
            "Lkotlin/properties/f<",
            "Ljava/lang/Object;",
            "TV;>;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v0, "vk"

    const-string/jumbo v0, "kv"

    const/4 v4, 0x1

    const-string/jumbo v0, "kv"

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Lk2/d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, "V"

    const-string v2, "V"

    const/4 v4, 0x1

    const-string v2, "V"

    const-string v2, "V"

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v4, 0x1

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, p0, v1, p1, p2}, Lk2/d;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method public static synthetic d(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;ILjava/lang/Object;)Lkotlin/properties/f;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    and-int/lit8 p4, p3, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p4, :cond_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    and-int/lit8 p4, p3, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    if-eqz p4, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_1
    const/4 v2, 0x0

    const/4 p4, 0x4

    const/4 v2, 0x0

    move v1, p4

    move v1, p4

    const/4 v2, 0x0

    and-int/2addr p3, p4

    const/4 v2, 0x0

    if-eqz p3, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/mmkv/MMKV;->defaultMMKV()Lcom/tencent/mmkv/MMKV;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p2, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const-string/jumbo p1, "utn(ofVla e,u nMmVK0l le.==aK)d=lh =MM  "

    const-string p1, "= em,0 ulnKeV(nda lhl=lu.  MKMtf=MdV )=a"

    const/4 v2, 0x0

    const-string p1, " dMflb=ell l==,0 hMe.u()aMVnn K K daVtM="

    const-string p1, "MMKV.defaultMMKV() == null, handle == 0 "

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p0

    :cond_3
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "kv"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p2, p3}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance p3, Lk2/d;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "V"

    const-string v0, "V"

    const/4 v2, 0x4

    const-string v0, "V"

    const-string v0, "V"

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-class p4, Ljava/lang/Object;

    const-class p4, Ljava/lang/Object;

    const/4 v2, 0x6

    const-class p4, Ljava/lang/Object;

    const-class p4, Ljava/lang/Object;

    const/4 v2, 0x1

    invoke-direct {p3, p0, p4, p1, p2}, Lk2/d;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p3
.end method

.method public static final synthetic e(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)Lkotlin/properties/e;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(TV;",
            "Ljava/lang/String;",
            "Lcom/tencent/mmkv/MMKV;",
            ")",
            "Lkotlin/properties/e<",
            "Ljava/lang/Object;",
            "Landroidx/lifecycle/t0<",
            "TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v0, "vk"

    const-string/jumbo v0, "vk"

    const-string/jumbo v0, "vk"

    const-string/jumbo v0, "kv"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    new-instance v0, Lk2/i;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x4

    const/4 v4, 0x5

    const-string v2, "V"

    const-string v2, "V"

    const/4 v4, 0x5

    const-string v2, "V"

    const-string v2, "V"

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v4, 0x7

    invoke-direct {v0, p0, v1, p1, p2}, Lk2/i;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    return-object v0
.end method

.method public static synthetic f(Ljava/lang/Object;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;ILjava/lang/Object;)Lkotlin/properties/e;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    and-int/lit8 p4, p3, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p4, :cond_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    and-int/lit8 p4, p3, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz p4, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p4, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    and-int/2addr p3, p4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p3, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/mmkv/MMKV;->defaultMMKV()Lcom/tencent/mmkv/MMKV;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const-string p1, "fn= MMueKVh M, )Mnluta(alK   e=dul0.doV="

    const-string p1, "Meu.o fn=K V0a=dle)   ,danVMl=Muht(KM =l"

    const/4 v2, 0x3

    const-string p1, "aKll=M paleKl Vd, =ut  =(0VfMM.un=hedM)n"

    const-string p1, "MMKV.defaultMMKV() == null, handle == 0 "

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    throw p0

    :cond_3
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "kv"

    const/4 v2, 0x2

    const-string/jumbo p3, "vk"

    const-string/jumbo p3, "kv"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p2, p3}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance p3, Lk2/i;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "V"

    const-string v0, "V"

    const/4 v2, 0x2

    const-string v0, "V"

    const-string v0, "V"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-class p4, Ljava/lang/Object;

    const-class p4, Ljava/lang/Object;

    const/4 v2, 0x0

    const-class p4, Ljava/lang/Object;

    const-class p4, Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p3, p0, p4, p1, p2}, Lk2/i;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p3
.end method
