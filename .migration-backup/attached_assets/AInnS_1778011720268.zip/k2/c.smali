.class public final synthetic Lk2/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:Lk2/d;

.field public final synthetic c:Lkotlin/reflect/o;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lk2/d;Lkotlin/reflect/o;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    or-int/2addr v1, v0

    iput-object p1, p0, Lk2/c;->a:Ljava/lang/Object;

    const/4 v1, 0x4

    iput-object p2, p0, Lk2/c;->b:Lk2/d;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lk2/c;->c:Lkotlin/reflect/o;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p4, p0, Lk2/c;->d:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~oso   v ~Kb~ ~  i @@ tbfi@t~~oo~1 @@@~.mS~@~~b @s@lM/f~~@d-@i~ c@~n@~~@y@a~ @@@ lr@ ~@  ~4ou/~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lk2/c;->a:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lk2/c;->b:Lk2/d;

    const/4 v5, 0x3

    iget-object v2, p0, Lk2/c;->c:Lkotlin/reflect/o;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v3, p0, Lk2/c;->d:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1, v2, v3}, Lk2/d;->b(Ljava/lang/Object;Lk2/d;Lkotlin/reflect/o;Ljava/lang/Object;)V

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    return-void
.end method
