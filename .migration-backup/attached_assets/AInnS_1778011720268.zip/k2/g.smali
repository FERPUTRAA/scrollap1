.class public final synthetic Lk2/g;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lk2/i;

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lk2/i;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lk2/g;->a:Lk2/i;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lk2/g;->b:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "f~s l@~/K@@S~o sna@@@~@    o ~yi t~@ b~  ~~~o~41 @@@ ~~ M~@ br@~m d~.vu@~f-~ t@@~~@cil@o~o/iob@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lk2/g;->a:Lk2/i;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Lk2/g;->b:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lk2/i;->s(Lk2/i;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
