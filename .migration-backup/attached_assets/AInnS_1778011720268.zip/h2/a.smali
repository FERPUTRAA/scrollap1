.class public final Lh2/a;
.super Ljava/util/ArrayList;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/ArrayList<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final type:Lkotlin/reflect/s;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/reflect/s;)V
    .locals 3
    .param p1    # Lkotlin/reflect/s;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "pety"

    const-string/jumbo v0, "tyep"

    const/4 v2, 0x0

    const-string/jumbo v0, "ytpe"

    const-string/jumbo v0, "type"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lh2/a;->type:Lkotlin/reflect/s;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Lkotlin/reflect/s;Ljava/util/Collection;)V
    .locals 3
    .param p1    # Lkotlin/reflect/s;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/util/Collection;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/reflect/s;",
            "Ljava/util/Collection<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "ptye"

    const-string/jumbo v0, "type"

    const/4 v2, 0x1

    const-string/jumbo v0, "teyp"

    const-string/jumbo v0, "type"

    const/4 v1, 0x1

    move v2, v1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "c"

    const-string v0, "c"

    const/4 v2, 0x6

    const-string v0, "c"

    const-string v0, "c"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, p2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Lh2/a;->type:Lkotlin/reflect/s;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public bridge a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~@@oK ~a4obc~ou~~~~@ifdt.~ yl~@~@~ ntb r@~ S @/ ~@ @~~@1~@o@lmi s ~~o@Mv~ i-o@/~@  @ ~bf @ @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-super {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public final b()Lkotlin/reflect/s;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object v0, p0, Lh2/a;->type:Lkotlin/reflect/s;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge d(I)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public final bridge remove(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TT;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lh2/a;->d(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public final bridge size()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lh2/a;->a()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method
