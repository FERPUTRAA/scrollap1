.class public final Lh2/b;
.super Ljava/lang/Object;


# direct methods
.method public static final synthetic a(Ljava/util/List;)Lh2/a;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "+TT;>;)",
            "Lh2/a<",
            "TT;>;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s~a ~u~ @ ~. ~ioo~@ lt@~K@4ob@  @@f@s@@l ~yt~~ @c~@~v@ fn~b~/ iom  b~@~-@dS~ @~ @~ri~/ o~@o1@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    const-string v0, "hs<m>i"

    const-string/jumbo v0, "ihs>s<"

    const/4 v5, 0x5

    const-string v0, "<tisoh"

    const-string v0, "<this>"

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance v0, Lh2/a;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v1, Lkotlin/reflect/u;->c:Lkotlin/reflect/u$a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v3, "T"

    const-string v3, "T"

    const/4 v5, 0x5

    const-string v3, "T"

    const-string v3, "T"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Lkotlin/reflect/u$a;->e(Lkotlin/reflect/s;)Lkotlin/reflect/u;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-class v2, Lh2/a;

    const-class v2, Lh2/a;

    const/4 v5, 0x5

    const-class v2, Lh2/a;

    const-class v2, Lh2/a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v2, v1}, Lkotlin/jvm/internal/l1;->B(Ljava/lang/Class;Lkotlin/reflect/u;)Lkotlin/reflect/s;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v0, v1, p0}, Lh2/a;-><init>(Lkotlin/reflect/s;Ljava/util/Collection;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object v0
.end method

.method public static final b(Lkotlin/reflect/s;Ljava/lang/Object;)Z
    .locals 4
    .param p0    # Lkotlin/reflect/s;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "istmhb"

    const-string v0, "ht>msi"

    const/4 v3, 0x6

    const-string/jumbo v0, "u<>tsh"

    const-string v0, "<this>"

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    move v3, v2

    const-string/jumbo v0, "ohptr"

    const-string/jumbo v0, "torho"

    const-string/jumbo v0, "rotqh"

    const-string/jumbo v0, "other"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p0}, Lkotlin/reflect/s;->z()Lkotlin/reflect/g;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    check-cast v0, Lkotlin/reflect/d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Lh8/a;->g(Lkotlin/reflect/d;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v1, p1, Lh2/a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {p0}, Lkotlin/reflect/s;->T()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast p1, Lh2/a;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Lh2/a;->b()Lkotlin/reflect/s;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p1}, Lkotlin/reflect/s;->T()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string p1, "K s.ylnca  nsutnblstcs-loonl.ub itrnC kl>enploectna< eotea ft"

    const-string p1, "eK-  bay iottltt <asnCcnlu>llk.etns p o.fcseultnna *rebclnoon"

    const/4 v3, 0x1

    const-string/jumbo p1, "netm>yratolKn fc cssstCnkt.ilpalt eaoueolllo  .ncn*nn<-eub l "

    const-string/jumbo p1, "null cannot be cast to non-null type kotlin.reflect.KClass<*>"

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method

.method public static final c(Lkotlin/reflect/s;Ljava/lang/Object;)Z
    .locals 4
    .param p0    # Lkotlin/reflect/s;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "u<>soi"

    const-string/jumbo v0, "ut<is>"

    const/4 v3, 0x5

    const-string v0, "hst>ib"

    const-string v0, "<this>"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "turoh"

    const-string/jumbo v0, "other"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p0}, Lkotlin/reflect/s;->z()Lkotlin/reflect/g;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Lkotlin/reflect/d;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Lh8/a;->g(Lkotlin/reflect/d;)Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, p1, Lh2/a;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-interface {p0}, Lkotlin/reflect/s;->T()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast p1, Lh2/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Lh2/a;->b()Lkotlin/reflect/s;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p1}, Lkotlin/reflect/s;->T()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return p0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo p1, "y>oia-tplu.nCllfottan o  up Koktan s<tlnlneeternsb* sncell.cc"

    const-string p1, " fl.l<kpbcslrnsaeiotot-seteCcatp.nalt  e no>ynlul nclKnt ou*n"

    const/4 v3, 0x7

    const-string/jumbo p1, "oaor<lKtqnnlatnn-yc  ulo .eeatl>lcoenluk tCt*sctl .pnns befsi"

    const-string/jumbo p1, "null cannot be cast to non-null type kotlin.reflect.KClass<*>"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    throw p0
.end method
