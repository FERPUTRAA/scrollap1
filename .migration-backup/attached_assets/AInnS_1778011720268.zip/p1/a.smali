.class public Lp1/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lq1/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lr1/e;)V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lq1/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lq1/a;-><init>(I)V

    const/4 v2, 0x7

    and-int/2addr v3, v2

    iput-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p1, v0, Lq1/a;->Q:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p2, v0, Lq1/a;->a:Lr1/e;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public A(I)Lp1/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4~s ~~ ~v@ybo~@S  ~-M@@~ r   ~ @b~~.@/~@li~~/~ @ 1~si~om~c~nolo~ tu~@f@f ~ab @@o@od@ t@ @@@ K@i~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    iput p1, v0, Lq1/a;->U:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public B(Ljava/lang/String;)Lp1/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, v0, Lq1/a;->R:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public C(I)Lp1/a;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, v0, Lq1/a;->d0:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public D(I)Lp1/a;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x4

    iput p1, v0, Lq1/a;->c0:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public E(III)Lp1/a;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, v0, Lq1/a;->m:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p2, v0, Lq1/a;->n:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p3, v0, Lq1/a;->o:I

    const/4 v2, 0x4

    return-object p0
.end method

.method public F(I)Lp1/a;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, v0, Lq1/a;->Y:I

    const/4 v2, 0x0

    return-object p0
.end method

.method public G(I)Lp1/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p1, v0, Lq1/a;->W:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public H(I)Lp1/a;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p1, v0, Lq1/a;->a0:I

    const/4 v2, 0x5

    return-object p0
.end method

.method public I(Ljava/lang/String;)Lp1/a;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, v0, Lq1/a;->T:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public J(Landroid/graphics/Typeface;)Lp1/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    iput-object p1, v0, Lq1/a;->k0:Landroid/graphics/Typeface;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public a(Landroid/view/View$OnClickListener;)Lp1/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, v0, Lq1/a;->c:Landroid/view/View$OnClickListener;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public b()Lcom/bigkoo/pickerview/view/b;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/bigkoo/pickerview/view/b<",
            "TT;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/bigkoo/pickerview/view/b;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lp1/a;->a:Lq1/a;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lcom/bigkoo/pickerview/view/b;-><init>(Lq1/a;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method

.method public c(Z)Lp1/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, v0, Lq1/a;->n0:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public d(Z)Lp1/a;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean p1, v0, Lq1/a;->j0:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public e(Z)Lp1/a;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean p1, v0, Lq1/a;->h0:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public f(Z)Lp1/a;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput-boolean p1, v0, Lq1/a;->s:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public g(I)Lp1/a;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p1, v0, Lq1/a;->f0:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public h(I)Lp1/a;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, v0, Lq1/a;->X:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public i(I)Lp1/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    iput p1, v0, Lq1/a;->V:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public j(Ljava/lang/String;)Lp1/a;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    iput-object p1, v0, Lq1/a;->S:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public k(I)Lp1/a;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, v0, Lq1/a;->b0:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public l(ZZZ)Lp1/a;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x0

    iput-boolean p1, v0, Lq1/a;->p:Z

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean p2, v0, Lq1/a;->q:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p3, v0, Lq1/a;->r:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public m(Landroid/view/ViewGroup;)Lp1/a;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, v0, Lq1/a;->O:Landroid/view/ViewGroup;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public n(I)Lp1/a;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput p1, v0, Lq1/a;->e0:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public o(Lcom/contrarywind/view/WheelView$c;)Lp1/a;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v1, 0x1

    move v2, v1

    iput-object p1, v0, Lq1/a;->l0:Lcom/contrarywind/view/WheelView$c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public p(I)Lp1/a;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput p1, v0, Lq1/a;->m0:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lp1/a;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, v0, Lq1/a;->g:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p2, v0, Lq1/a;->h:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p3, v0, Lq1/a;->i:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public r(ILr1/a;)Lp1/a;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput p1, v0, Lq1/a;->N:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p2, v0, Lq1/a;->f:Lr1/a;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public s(F)Lp1/a;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    iput p1, v0, Lq1/a;->g0:F

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public t(Lr1/d;)Lp1/a;
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p1, v0, Lq1/a;->e:Lr1/d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public u(Z)Lp1/a;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean p1, v0, Lq1/a;->i0:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public v(I)Lp1/a;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v1, 0x7

    move v2, v1

    iput p1, v0, Lq1/a;->f0:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public w(I)Lp1/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x6

    iput p1, v0, Lq1/a;->j:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public x(II)Lp1/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, v0, Lq1/a;->j:I

    const/4 v2, 0x1

    iput p2, v0, Lq1/a;->k:I

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public y(III)Lp1/a;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput p1, v0, Lq1/a;->j:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p2, v0, Lq1/a;->k:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p3, v0, Lq1/a;->l:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method public z(I)Lp1/a;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lp1/a;->a:Lq1/a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, v0, Lq1/a;->Z:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method
