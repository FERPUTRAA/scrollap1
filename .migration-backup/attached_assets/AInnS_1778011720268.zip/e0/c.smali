.class public final Le0/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInitializerViewModelFactory.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactoryBuilder\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,115:1\n37#2,2:116\n*S KotlinDebug\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactoryBuilder\n*L\n54#1:116,2\n*E\n"
.end annotation

.annotation runtime Le0/f;
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nInitializerViewModelFactory.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactoryBuilder\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,115:1\n37#2,2:116\n*S KotlinDebug\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactoryBuilder\n*L\n54#1:116,2\n*E\n"
    }
.end annotation


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Le0/g<",
            "*>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Le0/c;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final a(Lkotlin/reflect/d;Li8/l;)V
    .locals 4
    .param p1    # Lkotlin/reflect/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroidx/lifecycle/m1;",
            ">(",
            "Lkotlin/reflect/d<",
            "TT;>;",
            "Li8/l<",
            "-",
            "Le0/a;",
            "+TT;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " dsb~ @ ~@4  @u~t/ @~~m~.~o ~ @@1b@~ @i~oo ~b a ~@io @f@il@o@rl~Ky@~nS~f   @os~@c@~v@~@@/~ ~M~t-"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "zzaml"

    const-string/jumbo v0, "zaslz"

    const/4 v3, 0x6

    const-string v0, "cazzo"

    const-string v0, "clazz"

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "iramniletiz"

    const/4 v3, 0x1

    const-string/jumbo v0, "zieltbairin"

    const-string/jumbo v0, "initializer"

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x3

    iget-object v0, p0, Le0/c;->a:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v1, Le0/g;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1}, Lh8/a;->e(Lkotlin/reflect/d;)Ljava/lang/Class;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, p1, p2}, Le0/g;-><init>(Ljava/lang/Class;Li8/l;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public final b()Landroidx/lifecycle/p1$b;
    .locals 5
    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Le0/b;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Le0/c;->a:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array v2, v2, [Le0/g;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast v1, [Le0/g;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    array-length v2, v1

    const/4 v3, 0x5

    move v4, v3

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v1, [Le0/g;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Le0/b;-><init>([Le0/g;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v0
.end method
