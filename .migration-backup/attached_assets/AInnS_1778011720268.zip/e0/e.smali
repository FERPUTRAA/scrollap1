.class public final Le0/e;
.super Le0/a;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x0

    and-int/2addr v3, v2

    const/4 v1, 0x1

    xor-int/2addr v3, v1

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, v0, v1, v0}, Le0/e;-><init>(Le0/a;ILkotlin/jvm/internal/w;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Le0/a;)V
    .locals 3
    .param p1    # Le0/a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo v0, "nssrExttaiisl"

    const-string/jumbo v0, "ltstnaaEriixs"

    const/4 v2, 0x6

    const-string/jumbo v0, "ixEmatlsarini"

    const-string/jumbo v0, "initialExtras"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Le0/a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Le0/a;->b()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Le0/a;->b()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public synthetic constructor <init>(Le0/a;ILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x4

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    sget-object p1, Le0/a$a;->b:Le0/a$a;

    :cond_0
    const/4 v1, 0x7

    invoke-direct {p0, p1}, Le0/e;-><init>(Le0/a;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Le0/a$b;)Ljava/lang/Object;
    .locals 3
    .param p1    # Le0/a$b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Le0/a$b<",
            "TT;>;)TT;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "kye"

    const-string v0, "eyk"

    const/4 v2, 0x3

    const-string/jumbo v0, "kye"

    const-string/jumbo v0, "key"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Le0/a;->b()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p1
.end method

.method public final c(Le0/a$b;Ljava/lang/Object;)V
    .locals 3
    .param p1    # Le0/a$b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Le0/a$b<",
            "TT;>;TT;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "yke"

    const-string v0, "eyk"

    const/4 v2, 0x0

    const-string/jumbo v0, "yek"

    const-string/jumbo v0, "key"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Le0/a;->b()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
