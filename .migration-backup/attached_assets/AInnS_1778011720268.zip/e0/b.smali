.class public final Le0/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/lifecycle/p1$b;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInitializerViewModelFactory.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactory\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,115:1\n13579#2,2:116\n*S KotlinDebug\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactory\n*L\n105#1:116,2\n*E\n"
.end annotation

.annotation build Lkotlin/jvm/internal/r1;
    value = {
        "SMAP\nInitializerViewModelFactory.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactory\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,115:1\n13579#2,2:116\n*S KotlinDebug\n*F\n+ 1 InitializerViewModelFactory.kt\nandroidx/lifecycle/viewmodel/InitializerViewModelFactory\n*L\n105#1:116,2\n*E\n"
    }
.end annotation


# instance fields
.field private final b:[Le0/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Le0/g<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public varargs constructor <init>([Le0/g;)V
    .locals 3
    .param p1    # [Le0/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Le0/g<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "nislstzisaei"

    const-string/jumbo v0, "izsasnlieitr"

    const/4 v2, 0x2

    const-string/jumbo v0, "irimasielnti"

    const-string/jumbo v0, "initializers"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    iput-object p1, p0, Le0/b;->b:[Le0/g;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Class;Le0/a;)Landroidx/lifecycle/m1;
    .locals 9
    .param p1    # Ljava/lang/Class;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Le0/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroidx/lifecycle/m1;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Le0/a;",
            ")TT;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v0, "odCsosmlam"

    const-string v0, "doammslCsl"

    const/4 v8, 0x6

    const-string/jumbo v0, "mdlosbCael"

    const-string/jumbo v0, "modelClass"

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v0, "uatrso"

    const-string v0, "arstoe"

    const/4 v8, 0x2

    const-string/jumbo v0, "sprxte"

    const-string v0, "extras"

    const/4 v8, 0x1

    const/4 v7, 0x2

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v0, p0, Le0/b;->b:[Le0/g;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    array-length v1, v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v3, 0x0

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-ge v3, v1, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x4

    aget-object v5, v0, v3

    const/4 v8, 0x3

    invoke-virtual {v5}, Le0/g;->a()Ljava/lang/Class;

    move-result-object v6

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v6, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v6, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v5}, Le0/g;->b()Li8/l;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v4, p2}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    instance-of v5, v4, Landroidx/lifecycle/m1;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v5, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast v4, Landroidx/lifecycle/m1;

    const/4 v8, 0x5

    goto :goto_1

    :cond_0
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_1
    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x1

    if-eqz v4, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-object v4

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x0

    move v8, v7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const-string/jumbo v1, "rbo    iqt nirsaileloangveiszs fiNe"

    const-string v1, "eza ibseitsgosiirnlNt r i v eanfo l"

    const-string v1, "No initializer set for given class "

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    throw p2
.end method

.method public synthetic create(Ljava/lang/Class;)Landroidx/lifecycle/m1;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroidx/lifecycle/q1;->a(Landroidx/lifecycle/p1$b;Ljava/lang/Class;)Landroidx/lifecycle/m1;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method
