.class public final Li1/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Li1/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static a(Li1/a;IIII)V
    .locals 2
    .param p0    # Li1/a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os@~o~M@~@ @@ @~~@ .~ @ rvmsy/@l@ioc  @~@u~n ~@@@~  a@  dKb@fi~f~b~ ~@~o1S~~ @ @o~~btt/~-4ol  i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    const-string/jumbo p1, "shti"

    const-string p1, "htsi"

    const-string/jumbo p1, "iths"

    const-string/jumbo p1, "this"

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static b(Li1/a;Z)V
    .locals 2
    .param p0    # Li1/a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    const-string/jumbo p1, "isht"

    const-string/jumbo p1, "isth"

    const/4 v1, 0x2

    const-string/jumbo p1, "sthi"

    const-string/jumbo p1, "this"

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method
