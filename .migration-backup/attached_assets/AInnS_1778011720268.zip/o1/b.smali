.class public Lo1/b;
.super Ljava/lang/Object;

# interfaces
.implements La2/a;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lo1/b;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lo1/b;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public getItem(I)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "lis /bf@o~@ a@~~~ o@@@sbu-r ~ym@v@~~b4~ ~ i  .  @@@~~~ @n~ ~ltM@@@S@ot~ ~@~@@ ofc~oi~  Kd~o~~@1/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    if-ltz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lo1/b;->getItemsCount()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-ge p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lo1/b;->a:I

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    add-int/2addr v0, p1

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method public getItemsCount()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lo1/b;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, p0, Lo1/b;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    sub-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method public indexOf(Ljava/lang/Object;)I
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/Integer;

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lo1/b;->a:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v2, 0x3

    sub-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    return p1

    :catch_0
    const/4 v2, 0x1

    const/4 p1, -0x4

    const/4 v2, 0x1

    const/4 p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method
