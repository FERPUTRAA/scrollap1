.class public Lq0/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lq0/b$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:[Lq0/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lq0/b$a<",
            "TV;>;"
        }
    .end annotation
.end field

.field private final b:I


# direct methods
.method public constructor <init>(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    add-int/lit8 v0, p1, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput v0, p0, Lq0/b;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-array p1, p1, [Lq0/b$a;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/Class;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~~s~ ~@@@d@ ~yis~@n l~.@~r~~o@ 1o~   l o ~c~ f@@t~@@@@/~b  u~b~@@@o~@ @o~f ~o~/ib4 t@v Mmi@a -K~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x5

    iget-object v1, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    array-length v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ge v0, v2, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    aget-object v1, v1, v0

    const/4 v6, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_2

    :cond_0
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v3, v1, Lq0/b$a;->b:Ljava/lang/reflect/Type;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    instance-of v4, v3, Ljava/lang/Class;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v4, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x3

    check-cast v3, Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v4, :cond_1

    const/4 v6, 0x2

    return-object v3

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, v2, Lq0/b$a;->d:Lq0/b$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 p1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method

.method public final b(Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            ")TV;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lq0/b;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    aget-object v0, v1, v0

    :goto_0
    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, v0, Lq0/b$a;->b:Ljava/lang/reflect/Type;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne p1, v1, :cond_0

    const/4 v3, 0x2

    iget-object p1, v0, Lq0/b$a;->c:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x0

    iget-object v0, v0, Lq0/b$a;->d:Lq0/b$a;

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1
.end method

.method public c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            "TV;)Z"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lq0/b;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    and-int/2addr v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    aget-object v2, v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    iget-object v3, v2, Lq0/b$a;->b:Ljava/lang/reflect/Type;

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ne p1, v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-object p2, v2, Lq0/b$a;->c:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    return p1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, v2, Lq0/b$a;->d:Lq0/b$a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    new-instance v2, Lq0/b$a;

    const/4 v5, 0x0

    iget-object v3, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    aget-object v3, v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2, p1, p2, v0, v3}, Lq0/b$a;-><init>(Ljava/lang/reflect/Type;Ljava/lang/Object;ILq0/b$a;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object p1, p0, Lq0/b;->a:[Lq0/b$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput-object v2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return p1
.end method
