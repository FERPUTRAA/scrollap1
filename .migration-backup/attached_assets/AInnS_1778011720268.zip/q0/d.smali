.class public Lq0/d;
.super Ljava/lang/Object;


# static fields
.field public static a:Z = false

.field private static b:Z = true

.field private static volatile c:Ljava/lang/Class;

.field private static volatile d:Z

.field private static volatile e:Z

.field private static volatile f:Ljava/lang/reflect/Constructor;

.field private static volatile g:Ljava/lang/reflect/Method;

.field private static volatile h:Ljava/lang/reflect/Method;

.field private static volatile i:Ljava/lang/reflect/Method;

.field private static volatile j:Z

.field private static volatile k:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class;",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile l:Z

.field private static final m:Ljava/util/concurrent/ConcurrentMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "*>;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/high16 v1, 0x3f400000    # 0.75f

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/4 v2, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/16 v3, 0x24

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v0, v3, v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>(IFI)V

    const/4 v10, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    sput-object v0, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v1, "btye"

    const-string v1, "etyb"

    const/4 v11, 0x2

    const-string v1, "etby"

    const-string v1, "byte"

    const/4 v11, 0x0

    sget-object v2, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string/jumbo v1, "tssso"

    const-string/jumbo v1, "tssho"

    const/4 v11, 0x6

    const-string/jumbo v1, "shomr"

    const-string/jumbo v1, "short"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object v2, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x3

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string/jumbo v1, "nit"

    const/4 v11, 0x4

    const-string/jumbo v1, "itn"

    const-string/jumbo v1, "int"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string/jumbo v1, "olng"

    const-string v1, "glon"

    const/4 v11, 0x0

    const-string/jumbo v1, "long"

    const/4 v11, 0x3

    const/4 v10, 0x1

    sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-string v1, "amtoo"

    const-string/jumbo v1, "otfma"

    const/4 v11, 0x0

    const-string v1, "blfta"

    const-string v1, "float"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    sget-object v2, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x2

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string/jumbo v1, "udloub"

    const-string v1, "doluob"

    const/4 v11, 0x5

    const-string v1, "epdlbo"

    const-string v1, "double"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    sget-object v2, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string v1, "aqoblno"

    const-string v1, "aeoolbn"

    const/4 v11, 0x1

    const-string/jumbo v1, "obslaoe"

    const-string v1, "boolean"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-string/jumbo v1, "rcha"

    const-string/jumbo v1, "rcha"

    const/4 v11, 0x1

    const-string v1, "cahr"

    const-string v1, "char"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    sget-object v2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v1, "tyume"

    const-string v1, "butey"

    const/4 v11, 0x4

    const-string/jumbo v1, "t[ybo"

    const-string v1, "[byte"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-class v2, [B

    const-class v2, [B

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    move v11, v10

    const-string/jumbo v1, "p[ortb"

    const-string v1, "[ptroh"

    const/4 v11, 0x0

    const-string/jumbo v1, "u[rost"

    const-string v1, "[short"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-class v3, [S

    const-class v3, [S

    const/4 v11, 0x2

    const-class v3, [S

    const-class v3, [S

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v1, "[int"

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-class v4, [I

    const-class v4, [I

    const/4 v11, 0x4

    const-class v4, [I

    const/4 v11, 0x2

    invoke-interface {v0, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const-string/jumbo v1, "qopgn"

    const-string/jumbo v1, "o[gqn"

    const/4 v11, 0x3

    const-string/jumbo v1, "n[gqo"

    const-string v1, "[long"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-class v5, [J

    const-class v5, [J

    const/4 v11, 0x0

    const-class v5, [J

    const-class v5, [J

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-interface {v0, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string v1, "fsslta"

    const-string/jumbo v1, "lastf["

    const/4 v11, 0x7

    const-string v1, "af[mtl"

    const-string v1, "[float"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-class v6, [F

    const-class v6, [F

    const/4 v11, 0x5

    const-class v6, [F

    const-class v6, [F

    const/4 v10, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v0, v1, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v1, "budeool"

    const-string/jumbo v1, "loumdbe"

    const/4 v11, 0x0

    const-string v1, "[luedbo"

    const-string v1, "[double"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-class v7, [D

    const-class v7, [D

    const-class v7, [D

    const-class v7, [D

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {v0, v1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string/jumbo v1, "oob[naue"

    const-string/jumbo v1, "o[beolan"

    const/4 v11, 0x7

    const-string/jumbo v1, "oalb[nop"

    const-string v1, "[boolean"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const-class v8, [Z

    const/4 v11, 0x2

    const-class v8, [Z

    const-class v8, [Z

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-interface {v0, v1, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const-string v1, "cbhqa"

    const-string v1, "bhc[a"

    const/4 v11, 0x1

    const-string/jumbo v1, "ras[h"

    const-string v1, "[char"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-class v9, [C

    const-class v9, [C

    const/4 v11, 0x2

    const-class v9, [C

    const-class v9, [C

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {v0, v1, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v1, "[B"

    const-string v1, "[B"

    const/4 v11, 0x6

    const-string v1, "[B"

    const-string v1, "[B"

    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v1, "S["

    const-string v1, "S["

    const/4 v11, 0x4

    const-string v1, "[S"

    const-string v1, "[S"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v1, "I["

    const-string v1, "I["

    const/4 v11, 0x1

    const-string v1, "[I"

    const-string v1, "[I"

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {v0, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v1, "[J"

    const-string v1, "J["

    const/4 v11, 0x7

    const-string v1, "[J"

    const-string v1, "[J"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-interface {v0, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string v1, "F["

    const-string v1, "F["

    const/4 v11, 0x7

    const-string v1, "F["

    const-string v1, "[F"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-interface {v0, v1, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string v1, "D["

    const-string v1, "[D"

    const/4 v11, 0x6

    const-string v1, "D["

    const-string v1, "[D"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-interface {v0, v1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string v1, "C["

    const-string v1, "[C"

    const/4 v11, 0x7

    const-string v1, "[C"

    const-string v1, "[C"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-interface {v0, v1, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v1, "[Z"

    const-string v1, "Z["

    const/4 v11, 0x6

    const-string v1, "[Z"

    const-string v1, "[Z"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v0, v1, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v1, "Hjvm.uMu.tlishaap"

    const-string/jumbo v1, "uaH.jiuapshltv.Ma"

    const/4 v11, 0x7

    const-string/jumbo v1, "java.util.HashMap"

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-class v2, Ljava/util/HashMap;

    const-class v2, Ljava/util/HashMap;

    const/4 v11, 0x3

    const-class v2, Ljava/util/HashMap;

    const-class v2, Ljava/util/HashMap;

    const/4 v10, 0x0

    and-int/2addr v11, v10

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v1, "vtT.oelMaei.apjau"

    const-string/jumbo v1, "v.aeMaiplajTeut.r"

    const/4 v11, 0x5

    const-string/jumbo v1, "java.util.TreeMap"

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-class v2, Ljava/util/TreeMap;

    const-class v2, Ljava/util/TreeMap;

    const/4 v11, 0x7

    const-class v2, Ljava/util/TreeMap;

    const-class v2, Ljava/util/TreeMap;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string/jumbo v1, "jlaDabvu.t.qit"

    const-string/jumbo v1, "teuta.alqDji.v"

    const/4 v11, 0x7

    const-string/jumbo v1, "vajauaute.t.Dl"

    const-string/jumbo v1, "java.util.Date"

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-class v2, Ljava/util/Date;

    const-class v2, Ljava/util/Date;

    const/4 v11, 0x0

    const-class v2, Ljava/util/Date;

    const-class v2, Ljava/util/Date;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x5

    shr-int/2addr v11, v10

    const-string/jumbo v1, "toNscmOpaO..a.iSbetbajosblfasjn"

    const-string/jumbo v1, "nasitNajlaJeojO.c.absfbsSOtm.bo"

    const/4 v11, 0x3

    const-string v1, "bOalSj.iqbmacNosj.fnbaJa.toOtse"

    const-string v1, "com.alibaba.fastjson.JSONObject"

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-class v2, Lcom/alibaba/fastjson/e;

    const-class v2, Lcom/alibaba/fastjson/e;

    const/4 v11, 0x4

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string v1, "caspcrr.emsHaoMen.uuovcturtah.irnlnajt"

    const-string v1, "cvMmstnu.eocn.rjahul.nHorataeitnucprar"

    const/4 v11, 0x1

    const-string/jumbo v1, "nHcmajlraMecsonv.hcpnritreaturCua.tn.o"

    const-string/jumbo v1, "java.util.concurrent.ConcurrentHashMap"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x5

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const-class v2, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v1, "Speeoetlooi.tjtv.txmFaDaam"

    const-string/jumbo v1, "xiatoevjrmoma.ttFpe.DatSel"

    const/4 v11, 0x5

    const-string/jumbo v1, "lxmrebajamttata.ietDvFpoS."

    const-string/jumbo v1, "java.text.SimpleDateFormat"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v11, 0x1

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string v1, ".lncbauravtgaeEakjtTcelaSme"

    const-string v1, "Tcrteb.ktaaja.naevglcEeSaml"

    const/4 v11, 0x2

    const-string v1, "aketcltpgE.cnmeanj.aaSrveTl"

    const-string/jumbo v1, "java.lang.StackTraceElement"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-class v2, Ljava/lang/StackTraceElement;

    const-class v2, Ljava/lang/StackTraceElement;

    const/4 v11, 0x2

    const-class v2, Ljava/lang/StackTraceElement;

    const-class v2, Ljava/lang/StackTraceElement;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const-string/jumbo v1, "ngunEauaciao.levRtjepmnti."

    const/4 v11, 0x3

    const-string/jumbo v1, "pcg.aRxiqvionutnaeetmEljn."

    const-string/jumbo v1, "java.lang.RuntimeException"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-class v2, Ljava/lang/RuntimeException;

    const-class v2, Ljava/lang/RuntimeException;

    const/4 v11, 0x3

    const-class v2, Ljava/lang/RuntimeException;

    const-class v2, Ljava/lang/RuntimeException;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static A(Ljava/lang/String;)J
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "vKsoo r~@~n~   f/~.@  s @~y~/@@ ~~b-@~ ~Mo f~l  @i1 ~ai~Sd~ @@4cu@t@~~o~l b@~ @@@i~@~ @@o~bt@mo@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    if-nez p0, :cond_0

    const/4 v5, 0x2

    xor-int/2addr v6, v5

    const-wide/16 v0, 0x0

    const/4 v6, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-wide v0

    :cond_0
    const/4 v6, 0x2

    const-wide v0, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v0, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v0, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ge v2, v3, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/16 v4, 0x5f

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eq v3, v4, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v4, 0x2d

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-ne v3, v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/16 v4, 0x41

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-lt v3, v4, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/16 v4, 0x5a

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-gt v3, v4, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-int/lit8 v3, v3, 0x20

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    int-to-char v3, v3

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    int-to-long v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    xor-long/2addr v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const-wide v3, 0x100000001b3L

    const-wide v3, 0x100000001b3L

    const-wide v3, 0x100000001b3L

    const-wide v3, 0x100000001b3L

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    mul-long/2addr v0, v3

    :cond_3
    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-wide v0
.end method

.method public static B([Ljava/lang/reflect/Type;[Ljava/lang/reflect/TypeVariable;[Ljava/lang/reflect/Type;)Z
    .locals 9

    const/4 v8, 0x0

    const/4 v0, 0x6

    const/4 v8, 0x3

    const/4 v0, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz p2, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    array-length v1, p1

    const/4 v8, 0x6

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    goto/16 :goto_3

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v1, v0

    move v1, v0

    const/4 v8, 0x6

    move v1, v0

    move v1, v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    array-length v3, p0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-ge v1, v3, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x1

    aget-object v3, p0, v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    instance-of v4, v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v5, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v4, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v3}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v4, p1, p2}, Lq0/d;->B([Ljava/lang/reflect/Type;[Ljava/lang/reflect/TypeVariable;[Ljava/lang/reflect/Type;)Z

    move-result v6

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-eqz v6, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v2, Lq0/c;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v3}, Ljava/lang/reflect/ParameterizedType;->getOwnerType()Ljava/lang/reflect/Type;

    move-result-object v6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v3}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {v2, v4, v6, v3}, Lq0/c;-><init>([Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v2, p0, v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    move v2, v5

    move v2, v5

    const/4 v8, 0x6

    move v2, v5

    move v2, v5

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_2

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    instance-of v4, v3, Ljava/lang/reflect/TypeVariable;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v4, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    move v4, v0

    move v4, v0

    const/4 v8, 0x1

    move v4, v0

    move v4, v0

    :goto_1
    const/4 v7, 0x6

    move v8, v7

    array-length v6, p1

    const/4 v8, 0x2

    if-ge v4, v6, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    aget-object v6, p1, v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v6, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    aget-object v2, p2, v4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    aput-object v2, p0, v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    move v2, v5

    move v2, v5

    const/4 v8, 0x5

    move v2, v5

    move v2, v5

    :cond_2
    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    return v2

    :cond_5
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    return v0
.end method

.method public static C(Ljava/lang/reflect/Type;)Ljava/lang/Class;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-class v1, Ljava/lang/Class;

    const-class v1, Ljava/lang/Class;

    const/4 v4, 0x2

    const-class v1, Ljava/lang/Class;

    const-class v1, Ljava/lang/Class;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast p0, Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-static {p0}, Lq0/d;->C(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p0

    :cond_1
    const/4 v4, 0x0

    instance-of v0, p0, Ljava/lang/reflect/TypeVariable;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x4

    check-cast p0, Ljava/lang/reflect/TypeVariable;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/lang/reflect/TypeVariable;->getBounds()[Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v4, 0x4

    aget-object p0, p0, v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast p0, Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    instance-of v0, p0, Ljava/lang/reflect/WildcardType;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast p0, Ljava/lang/reflect/WildcardType;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/lang/reflect/WildcardType;->getUpperBounds()[Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    array-length v0, p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    move v4, v3

    if-ne v0, v2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x1

    aget-object p0, p0, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Lq0/d;->C(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    return-object p0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-class p0, Ljava/lang/Object;

    const-class p0, Ljava/lang/Object;

    const/4 v4, 0x6

    const-class p0, Ljava/lang/Object;

    const-class p0, Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p0
.end method

.method public static D(Ljava/lang/String;)Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v2, 0x2

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p0, Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static E(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .locals 6

    const/4 v5, 0x7

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    aget-object p0, p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    instance-of v1, p0, Ljava/lang/reflect/WildcardType;

    const/4 v4, 0x4

    move v5, v4

    if-eqz v1, :cond_2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v1, Ljava/lang/reflect/WildcardType;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/lang/reflect/WildcardType;->getUpperBounds()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    array-length v2, v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ne v2, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    aget-object p0, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v5, 0x7

    instance-of v0, p0, Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast p0, Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, "ajamp"

    const-string v1, "aapj."

    const/4 v5, 0x2

    const-string v1, "aav.o"

    const-string/jumbo v1, "java."

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0}, Lq0/d;->E(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 p0, 0x0

    :cond_2
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez p0, :cond_3

    const/4 v5, 0x1

    const-class p0, Ljava/lang/Object;

    const-class p0, Ljava/lang/Object;

    const/4 v5, 0x1

    const-class p0, Ljava/lang/Object;

    const-class p0, Ljava/lang/Object;

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p0
.end method

.method public static F(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;)Ljava/lang/reflect/Field;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/reflect/Field;",
            ")",
            "Ljava/lang/reflect/Field;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1, p2, v0}, Lq0/d;->G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/reflect/Field;",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "*>;[",
            "Ljava/lang/reflect/Field;",
            ">;)",
            "Ljava/lang/reflect/Field;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p0, p1, p2, p3}, Lq0/d;->H(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v1, "_"

    const-string v1, "_"

    const/4 v4, 0x0

    const-string v1, "_"

    const-string v1, "_"

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p0, v0, p2, p3}, Lq0/d;->H(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "m_"

    const-string/jumbo v1, "m_"

    const/4 v4, 0x3

    const-string v1, "_m"

    const-string/jumbo v1, "m_"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0, v0, p2, p3}, Lq0/d;->H(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "m"

    const-string/jumbo v1, "m"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0, p1, p2, p3}, Lq0/d;->H(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method private static H(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/reflect/Field;",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "*>;[",
            "Ljava/lang/reflect/Field;",
            ">;)",
            "Ljava/lang/reflect/Field;"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    array-length v0, p2

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    const/4 v8, 0x5

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ge v2, v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    aget-object v3, p2, v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v5, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-object v3

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x2

    shr-int/2addr v8, v6

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    if-le v5, v6, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/16 v6, 0x61

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-lt v5, v6, :cond_1

    const/4 v8, 0x5

    const/16 v6, 0x7a

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-gt v5, v6, :cond_1

    const/4 v7, 0x0

    shr-int/2addr v8, v7

    const/4 v5, 0x1

    or-int/2addr v8, v5

    const/4 v7, 0x5

    shl-int/2addr v8, v7

    invoke-virtual {p1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/16 v6, 0x41

    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-lt v5, v6, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v6, 0x5a

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-gt v5, v6, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v4, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-object v3

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 p2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz p0, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v8, 0x2

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-ne p0, v0, :cond_3

    const/4 v8, 0x5

    goto :goto_1

    :cond_3
    const/4 v8, 0x0

    if-eqz p3, :cond_4

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-interface {p3, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x4

    check-cast p2, [Ljava/lang/reflect/Field;

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x0

    if-nez p2, :cond_5

    const/4 v8, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz p3, :cond_5

    invoke-interface {p3, p0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p0, p1, p2, p3}, Lq0/d;->G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-object p0

    :cond_6
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    return-object p2
.end method

.method public static I(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    instance-of v0, p0, Ljava/lang/Class;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p0, Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0}, Lq0/d;->I(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public static J(Ljava/lang/Class;)[Ljava/lang/String;
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x6

    sget-object v0, Lq0/d;->f:Ljava/lang/reflect/Constructor;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v1, 0x1

    const/4 v9, 0x2

    const/4 v2, 0x5

    const/4 v9, 0x5

    const/4 v2, 0x0

    const/4 v9, 0x7

    if-nez v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    sget-boolean v0, Lq0/d;->e:Z

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-nez v0, :cond_0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v0, "flpaabt.Kn.qernIrlknjlCll.mciiteevmtss"

    const-string v0, ".pmli.lCqaeriameecltnInrvl.jtfsltKosnk"

    const/4 v9, 0x7

    const-string v0, "fKrk.Cuprnaaljlicnm.ltitneeeolts.slmIv"

    const-string/jumbo v0, "kotlin.reflect.jvm.internal.KClassImpl"

    const/4 v9, 0x4

    const/4 v8, 0x5

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-array v3, v1, [Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const-class v4, Ljava/lang/Class;

    const-class v4, Ljava/lang/Class;

    const/4 v9, 0x3

    const-class v4, Ljava/lang/Class;

    const-class v4, Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    aput-object v4, v3, v2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    sput-object v3, Lq0/d;->f:Ljava/lang/reflect/Constructor;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const-string/jumbo v3, "tsutrtgpscsrone"

    const-string/jumbo v3, "orstnegsuroctst"

    const-string/jumbo v3, "tusttronqCgcesr"

    const-string v3, "getConstructors"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    sput-object v0, Lq0/d;->g:Ljava/lang/reflect/Method;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-class v0, Lkotlin/reflect/i;

    const/4 v9, 0x5

    const-class v0, Lkotlin/reflect/i;

    const-class v0, Lkotlin/reflect/i;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-string v3, "ersrePtatmmag"

    const-string v3, "eatmraetePgmr"

    const/4 v9, 0x2

    const-string/jumbo v3, "rarmetPesmeag"

    const-string v3, "getParameters"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    sput-object v0, Lq0/d;->h:Ljava/lang/reflect/Method;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const-class v0, Lkotlin/reflect/n;

    const-class v0, Lkotlin/reflect/n;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v3, "eomtoaN"

    const-string v3, "eNgaotm"

    const-string v3, "getName"

    const/4 v9, 0x1

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    sput-object v0, Lq0/d;->i:Ljava/lang/reflect/Method;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x5

    goto :goto_0

    :catchall_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    sput-boolean v1, Lq0/d;->e:Z

    :cond_0
    :goto_0
    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    sget-object v0, Lq0/d;->f:Ljava/lang/reflect/Constructor;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v3, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-nez v0, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    return-object v3

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget-boolean v0, Lq0/d;->j:Z

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v0, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    return-object v3

    :cond_2
    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget-object v0, Lq0/d;->f:Ljava/lang/reflect/Constructor;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v9, 0x6

    aput-object p0, v4, v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    sget-object v0, Lq0/d;->g:Ljava/lang/reflect/Method;

    const/4 v9, 0x3

    const/4 v8, 0x5

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v0, p0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    check-cast p0, Ljava/lang/Iterable;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v4, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    sget-object v5, Lq0/d;->h:Ljava/lang/reflect/Method;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    new-array v6, v2, [Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v5, v4, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    check-cast v5, Ljava/util/List;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v0, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez v5, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x0

    goto :goto_2

    :cond_3
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    const/4 v9, 0x5

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x2

    sget-object p0, Lq0/d;->h:Ljava/lang/reflect/Method;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-array v4, v2, [Ljava/lang/Object;

    const/4 v9, 0x2

    invoke-virtual {p0, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    check-cast p0, Ljava/util/List;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    :goto_3
    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x4

    if-ge v4, v5, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    sget-object v6, Lq0/d;->i:Ljava/lang/reflect/Method;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-array v7, v2, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {v6, v5, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    check-cast v5, Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x4

    aput-object v5, v0, v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto :goto_3

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-object v0

    :catchall_1
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    sput-boolean v1, Lq0/d;->j:Z

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-object v3
.end method

.method public static K(Ljava/lang/Class;Ljava/lang/reflect/Method;)Lp0/b;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/reflect/Method;",
            ")",
            "Lp0/b;"
        }
    .end annotation

    invoke-virtual {p0}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_0
    const-class v4, Lp0/b;

    const-class v4, Lp0/b;

    const-class v4, Lp0/b;

    const-class v4, Lp0/b;

    const/4 v5, 0x1

    if-ge v3, v1, :cond_7

    aget-object v6, v0, v3

    invoke-virtual {v6}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v7, v6

    move v8, v2

    move v8, v2

    move v8, v2

    move v8, v2

    :goto_1
    if-ge v8, v7, :cond_6

    aget-object v9, v6, v8

    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual/range {p1 .. p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_0

    goto :goto_4

    :cond_0
    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v10

    invoke-virtual/range {p1 .. p1}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    array-length v12, v10

    array-length v13, v11

    if-eq v12, v13, :cond_1

    goto :goto_4

    :cond_1
    move v12, v2

    move v12, v2

    move v12, v2

    move v12, v2

    :goto_2
    array-length v13, v10

    if-ge v12, v13, :cond_3

    aget-object v13, v10, v12

    aget-object v14, v11, v12

    invoke-virtual {v13, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_2

    move v10, v2

    move v10, v2

    move v10, v2

    goto :goto_3

    :cond_2
    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_3
    move v10, v5

    move v10, v5

    move v10, v5

    move v10, v5

    :goto_3
    if-nez v10, :cond_4

    goto :goto_4

    :cond_4
    invoke-virtual {v9, v4}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v9

    check-cast v9, Lp0/b;

    if-eqz v9, :cond_5

    return-object v9

    :cond_5
    :goto_4
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_7
    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    :cond_8
    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v3

    invoke-static {v3}, Ljava/lang/reflect/Modifier;->isAbstract(I)Z

    move-result v3

    if-eqz v3, :cond_f

    invoke-virtual/range {p1 .. p1}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v0

    array-length v6, v0

    move v7, v2

    move v7, v2

    move v7, v2

    move v7, v2

    :goto_5
    if-ge v7, v6, :cond_f

    aget-object v8, v0, v7

    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v9

    array-length v10, v9

    array-length v11, v3

    if-eq v10, v11, :cond_9

    goto :goto_8

    :cond_9
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual/range {p1 .. p1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_a

    goto :goto_8

    :cond_a
    move v10, v2

    move v10, v2

    move v10, v2

    move v10, v2

    :goto_6
    array-length v11, v3

    if-ge v10, v11, :cond_c

    aget-object v11, v9, v10

    aget-object v12, v3, v10

    invoke-virtual {v11, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_b

    move v9, v2

    move v9, v2

    move v9, v2

    move v9, v2

    goto :goto_7

    :cond_b
    add-int/lit8 v10, v10, 0x1

    goto :goto_6

    :cond_c
    move v9, v5

    move v9, v5

    move v9, v5

    move v9, v5

    :goto_7
    if-nez v9, :cond_d

    goto :goto_8

    :cond_d
    invoke-virtual {v8, v4}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v8

    check-cast v8, Lp0/b;

    if-eqz v8, :cond_e

    return-object v8

    :cond_e
    :goto_8
    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_f
    return-object v1
.end method

.method public static L(Ljava/lang/reflect/Type;)Z
    .locals 5

    const/4 v4, 0x3

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    instance-of v0, p0, Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p0, Ljava/lang/Class;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v4, 0x5

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v4, 0x2

    if-eq p0, v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Lq0/d;->L(Ljava/lang/reflect/Type;)Z

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    const/4 v4, 0x2

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v2
.end method

.method private static M(Ljava/lang/Class;Lp0/c;Ljava/lang/String;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Lp0/c;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {p1}, Lp0/c;->ignores()[Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {p1}, Lp0/c;->ignores()[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    array-length v2, p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v3, v0

    move v3, v0

    const/4 v6, 0x5

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ge v3, v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    aget-object v4, p1, v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    return v1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-class p1, Ljava/lang/Object;

    const-class p1, Ljava/lang/Object;

    const/4 v6, 0x2

    const-class p1, Ljava/lang/Object;

    const-class p1, Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eq p0, p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x6

    if-eqz p0, :cond_2

    const/4 v6, 0x0

    const-class p1, Lp0/c;

    const-class p1, Lp0/c;

    const/4 v6, 0x7

    const-class p1, Lp0/c;

    const-class p1, Lp0/c;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    check-cast p1, Lp0/c;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0, p1, p2}, Lq0/d;->M(Ljava/lang/Class;Lp0/c;Ljava/lang/String;)Z

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz p0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    :cond_2
    const/4 v6, 0x5

    return v0
.end method

.method public static N(Ljava/lang/Class;)Z
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lq0/d;->c:Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-boolean v0, Lq0/d;->d:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const-class v0, Lkotlin/i0;

    const-class v0, Lkotlin/i0;

    const/4 v2, 0x1

    const-class v0, Lkotlin/i0;

    const-class v0, Lkotlin/i0;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    sput-object v0, Lq0/d;->c:Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :catchall_0
    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x2

    sput-boolean v0, Lq0/d;->d:Z

    :cond_0
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lq0/d;->c:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lq0/d;->c:Ljava/lang/Class;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/Class;->isAnnotationPresent(Ljava/lang/Class;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p0
.end method

.method private static O(Ljava/lang/Class;Ljava/lang/String;)Z
    .locals 10

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v0, "bmyEsbt"

    const-string/jumbo v0, "ystEmbi"

    const/4 v9, 0x0

    const-string/jumbo v0, "stmyipu"

    const-string/jumbo v0, "isEmpty"

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v1, "ItEdusepvncegul"

    const-string v1, "dgvleEuicestnIu"

    const/4 v9, 0x1

    const-string v1, "dncEulneqgiIsev"

    const-string v1, "getEndInclusive"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    sget-object v2, Lq0/d;->k:Ljava/util/Map;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v3, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    sget-boolean v2, Lq0/d;->l:Z

    const/4 v9, 0x5

    const/4 v8, 0x2

    if-nez v2, :cond_0

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-instance v2, Ljava/util/HashMap;

    const/4 v8, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    const/4 v9, 0x6

    const-string/jumbo v5, "sns.nlgato.kper"

    const-string v5, "cotarg.pk.lnesn"

    const/4 v9, 0x4

    const-string v5, ".inmetsknalgcor"

    const-string/jumbo v5, "kotlin.ranges.c"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v9, 0x5

    new-array v7, v6, [Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    aput-object v1, v7, v4

    const/4 v9, 0x4

    aput-object v0, v7, v3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v5, "n.aige.kqsltlor"

    const/4 v9, 0x1

    const-string/jumbo v5, "o.lnotraligs.ek"

    const-string/jumbo v5, "kotlin.ranges.l"

    const/4 v8, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-array v7, v6, [Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    aput-object v1, v7, v4

    const/4 v8, 0x4

    and-int/2addr v9, v8

    aput-object v0, v7, v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v5, "sgl.sb.aiokentr"

    const-string/jumbo v5, "loseg.a.rktiosn"

    const/4 v9, 0x5

    const-string v5, "einr..uktaognol"

    const-string/jumbo v5, "kotlin.ranges.o"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    new-array v7, v6, [Ljava/lang/String;

    const/4 v8, 0x4

    move v9, v8

    aput-object v1, v7, v4

    const/4 v9, 0x3

    aput-object v0, v7, v3

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const-string v5, ".solrknpeiagtem"

    const-string v5, "aosme.gklenr.it"

    const-string v5, "et.rkogsqnnail."

    const-string/jumbo v5, "kotlin.ranges.e"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-array v7, v6, [Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x6

    aput-object v1, v7, v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    aput-object v0, v7, v3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x7

    const-string v5, "etsinrgnlad.o.k"

    const-string/jumbo v5, "kotlin.ranges.d"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-array v6, v6, [Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    aput-object v1, v6, v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    aput-object v0, v6, v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {v2, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    sput-object v2, Lq0/d;->k:Ljava/util/Map;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_0

    :catchall_0
    const/4 v9, 0x1

    sput-boolean v3, Lq0/d;->l:Z

    :cond_0
    :goto_0
    const/4 v8, 0x7

    const/4 v9, 0x0

    sget-object v0, Lq0/d;->k:Ljava/util/Map;

    const/4 v9, 0x1

    const/4 v8, 0x2

    if-nez v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    return v4

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    sget-object v0, Lq0/d;->k:Ljava/util/Map;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x7

    const/4 v8, 0x0

    check-cast p0, [Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez p0, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    return v4

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p0, p1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-ltz p0, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_1

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x6

    return v3
.end method

.method public static P(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/ClassLoader;",
            ")",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lq0/d;->Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/ClassLoader;",
            "Z)",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v0, 0x5

    const/4 v8, 0x3

    const/4 v0, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz p0, :cond_a

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto/16 :goto_2

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/16 v2, 0x100

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-ge v1, v2, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object v1, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v8, 0x1

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    check-cast v2, Ljava/lang/Class;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-object v2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/16 v5, 0x5b

    const/4 v8, 0x1

    const/4 v6, 0x1

    const/4 v8, 0x3

    shr-int/2addr v7, v6

    const/4 v8, 0x7

    if-ne v4, v5, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {p0, p1, v3}, Lq0/d;->Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x4

    if-nez p0, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-object v0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p0, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-object p0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v0, "L"

    const-string v0, "L"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v0, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v0, ";"

    const-string v0, ";"

    const/4 v8, 0x1

    const-string v0, ";"

    const-string v0, ";"

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v0, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    sub-int/2addr p2, v6

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0, v6, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p0, p1, v3}, Lq0/d;->Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-object p0

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz p1, :cond_6

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz p2, :cond_5

    const/4 v7, 0x0

    move v8, v7

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-object v2

    :catch_0
    :cond_6
    :try_start_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->getContextClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v0, :cond_8

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eq v0, p1, :cond_8

    const/4 v8, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz p2, :cond_7

    :try_start_2
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    sget-object p2, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-interface {p2, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto :goto_0

    :catch_1
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_1

    :cond_7
    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object p1

    :catch_2
    :cond_8
    :goto_1
    :try_start_3
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    sget-object p1, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-interface {p1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    return-object v2

    :cond_9
    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v0, "o cmgoaenoa sNots.m "

    const-string v0, " n co sosaloe.moatgN"

    const/4 v8, 0x6

    const-string v0, " Ncaooml so.asoeg tn"

    const-string v0, "className too long. "

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {p1, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    throw p1

    :cond_a
    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object v0
.end method

.method public static R(Ljava/lang/String;)D
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/16 v1, 0xa

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-le v0, v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    return-wide v0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    move-wide v4, v2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    move v2, v1

    move v2, v1

    const/4 v10, 0x5

    move v2, v1

    move v2, v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    move v3, v2

    move v3, v2

    const/4 v10, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x4

    if-ge v1, v0, :cond_5

    const/4 v9, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/16 v7, 0x2d

    const/4 v10, 0x2

    const/4 v8, 0x5

    const/4 v8, 0x1

    move v10, v8

    if-ne v6, v7, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-nez v1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    move v2, v8

    move v2, v8

    const/4 v10, 0x0

    move v2, v8

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto :goto_1

    :cond_1
    const/4 v10, 0x2

    const/16 v7, 0x2e

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-ne v6, v7, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v3, :cond_2

    const/4 v10, 0x5

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    return-wide v0

    :cond_2
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    sub-int v3, v0, v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    sub-int/2addr v3, v8

    const/4 v10, 0x4

    goto :goto_1

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/16 v7, 0x30

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-lt v6, v7, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/16 v7, 0x39

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-gt v6, v7, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    add-int/lit8 v6, v6, -0x30

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-wide/16 v7, 0xa

    const-wide/16 v7, 0xa

    const/4 v10, 0x5

    const-wide/16 v7, 0xa

    const-wide/16 v7, 0xa

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    mul-long/2addr v4, v7

    const/4 v10, 0x2

    int-to-long v6, v6

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-long/2addr v4, v6

    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_0

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    return-wide v0

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eqz v2, :cond_6

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    neg-long v4, v4

    :cond_6
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    packed-switch v3, :pswitch_data_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-wide v0

    :pswitch_0
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    long-to-double v0, v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-wide v2, 0x41cdcd6500000000L    # 1.0E9

    const-wide v2, 0x41cdcd6500000000L    # 1.0E9

    const/4 v10, 0x7

    const-wide v2, 0x41cdcd6500000000L    # 1.0E9

    const-wide v2, 0x41cdcd6500000000L    # 1.0E9

    :goto_2
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    div-double/2addr v0, v2

    const/4 v10, 0x3

    return-wide v0

    :pswitch_1
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    long-to-double v0, v4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-wide v2, 0x4197d78400000000L    # 1.0E8

    const-wide v2, 0x4197d78400000000L    # 1.0E8

    const/4 v10, 0x6

    const-wide v2, 0x4197d78400000000L    # 1.0E8

    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto :goto_2

    :pswitch_2
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    long-to-double v0, v4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const-wide v2, 0x416312d000000000L    # 1.0E7

    const-wide v2, 0x416312d000000000L    # 1.0E7

    const/4 v10, 0x4

    const-wide v2, 0x416312d000000000L    # 1.0E7

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_2

    :pswitch_3
    const/4 v9, 0x6

    move v10, v9

    long-to-double v0, v4

    const/4 v10, 0x7

    const-wide v2, 0x412e848000000000L    # 1000000.0

    const-wide v2, 0x412e848000000000L    # 1000000.0

    const/4 v10, 0x3

    const-wide v2, 0x412e848000000000L    # 1000000.0

    const-wide v2, 0x412e848000000000L    # 1000000.0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto :goto_2

    :pswitch_4
    const/4 v10, 0x3

    const/4 v9, 0x5

    long-to-double v0, v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-wide v2, 0x40f86a0000000000L    # 100000.0

    const-wide v2, 0x40f86a0000000000L    # 100000.0

    const/4 v10, 0x2

    const-wide v2, 0x40f86a0000000000L    # 100000.0

    const-wide v2, 0x40f86a0000000000L    # 100000.0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_2

    :pswitch_5
    const/4 v10, 0x5

    const/4 v9, 0x7

    long-to-double v0, v4

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-wide v2, 0x40c3880000000000L    # 10000.0

    const-wide v2, 0x40c3880000000000L    # 10000.0

    const/4 v10, 0x1

    const-wide v2, 0x40c3880000000000L    # 10000.0

    const-wide v2, 0x40c3880000000000L    # 10000.0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto/16 :goto_2

    :pswitch_6
    const/4 v10, 0x0

    long-to-double v0, v4

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x2

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto/16 :goto_2

    :pswitch_7
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    long-to-double v0, v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const/4 v10, 0x2

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const/4 v10, 0x4

    goto/16 :goto_2

    :pswitch_8
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    long-to-double v0, v4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v10, 0x3

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v10, 0x6

    const/4 v9, 0x6

    goto/16 :goto_2

    :pswitch_9
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    long-to-double v0, v4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    return-wide v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static S(Ljava/lang/String;)F
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/16 v1, 0xa

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-lt v0, v1, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x7

    return p0

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v1, 0x0

    const/4 v10, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    move-wide v4, v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    move v2, v1

    move v2, v1

    const/4 v10, 0x1

    move v2, v1

    move v2, v1

    const/4 v9, 0x3

    move v10, v9

    move v3, v2

    move v3, v2

    const/4 v10, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v9, 0x5

    move v10, v9

    if-ge v1, v0, :cond_5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/16 v7, 0x2d

    const/4 v9, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v8, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-ne v6, v7, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-nez v1, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    move v2, v8

    move v2, v8

    const/4 v10, 0x2

    move v2, v8

    move v2, v8

    const/4 v9, 0x0

    move v10, v9

    goto :goto_1

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/16 v7, 0x2e

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ne v6, v7, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz v3, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x0

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    return p0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    sub-int v3, v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x2

    sub-int/2addr v3, v8

    const/4 v10, 0x3

    goto :goto_1

    :cond_3
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/16 v7, 0x30

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-lt v6, v7, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/16 v7, 0x39

    const/4 v10, 0x7

    const/4 v9, 0x0

    if-gt v6, v7, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    add-int/lit8 v6, v6, -0x30

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-wide/16 v7, 0xa

    const/4 v10, 0x4

    const-wide/16 v7, 0xa

    const-wide/16 v7, 0xa

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    mul-long/2addr v4, v7

    int-to-long v6, v6

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    add-long/2addr v4, v6

    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_0

    :cond_4
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x5

    return p0

    :cond_5
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz v2, :cond_6

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    neg-long v4, v4

    :cond_6
    const/4 v10, 0x6

    packed-switch v3, :pswitch_data_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    return p0

    :pswitch_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    long-to-float p0, v4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    const v0, 0x4e6e6b28    # 1.0E9f

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    div-float/2addr p0, v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    return p0

    :pswitch_1
    const/4 v10, 0x4

    long-to-float p0, v4

    const/4 v9, 0x6

    move v10, v9

    const v0, 0x4cbebc20    # 1.0E8f

    const/4 v9, 0x0

    move v10, v9

    goto :goto_2

    :pswitch_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    long-to-float p0, v4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    const v0, 0x4b189680    # 1.0E7f

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_2

    :pswitch_3
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    long-to-float p0, v4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    const v0, 0x49742400    # 1000000.0f

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto :goto_2

    :pswitch_4
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    long-to-float p0, v4

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    const v0, 0x47c35000    # 100000.0f

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_2

    :pswitch_5
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    long-to-float p0, v4

    const/4 v10, 0x1

    const v0, 0x461c4000    # 10000.0f

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto :goto_2

    :pswitch_6
    long-to-float p0, v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/high16 v0, 0x447a0000    # 1000.0f

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto :goto_2

    :pswitch_7
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    long-to-float p0, v4

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/high16 v0, 0x42c80000    # 100.0f

    const/4 v10, 0x7

    goto :goto_2

    :pswitch_8
    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    long-to-float p0, v4

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/high16 v0, 0x41200000    # 10.0f

    const/4 v9, 0x3

    move v10, v9

    goto :goto_2

    :pswitch_9
    const/4 v10, 0x1

    const/4 v9, 0x5

    long-to-float p0, v4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    return p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/reflect/Member;",
            "I)Z"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz p1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-boolean v1, Lq0/d;->b:Z

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const/4 v4, 0x1

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne p0, v2, :cond_2

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/lang/reflect/Member;->getModifiers()I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    and-int/2addr p0, v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    if-eqz p0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    and-int/lit8 p0, p2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast p1, Ljava/lang/reflect/AccessibleObject;

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/security/AccessControlException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return v1

    :catch_0
    const/4 v3, 0x1

    move v4, v3

    sput-boolean v0, Lq0/d;->b:Z

    :cond_3
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/Class;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    sget-object v0, Lq0/d;->m:Ljava/util/concurrent/ConcurrentMap;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static final b(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0, p1, p2, v0}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static final c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            "I)TT;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x4

    if-nez p0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz p1, :cond_23

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ne p1, v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    instance-of v1, p0, Ljava/util/Map;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v5, 0x3

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne p1, v0, :cond_2

    const/4 v5, 0x7

    return-object p0

    :cond_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v0, Ljava/util/Map;

    const/4 v4, 0x0

    or-int/2addr v5, v4

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v5, 0x6

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v4, 0x6

    move v5, v4

    if-ne p1, v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, "b@ebp"

    const-string v1, "bype@"

    const/4 v5, 0x2

    const-string/jumbo v1, "yupe@"

    const-string v1, "@type"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object p0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, p1, p2, p3}, Lq0/d;->s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p0

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->isArray()Z

    move-result p3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p3, :cond_7

    const/4 v4, 0x0

    and-int/2addr v5, v4

    instance-of p3, p0, Ljava/util/Collection;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p3, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast p0, Ljava/util/Collection;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p3

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p3, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object p3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {v0, v3, p2}, Lq0/d;->b(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p3, v2, v0}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/2addr v2, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object p3

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-class p3, [B

    const-class p3, [B

    const-class p3, [B

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p1, p3, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p0}, Lq0/d;->j(Ljava/lang/Object;)[B

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p3, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-object p0

    :cond_8
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object p3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x4

    if-eq p1, p3, :cond_22

    const/4 v5, 0x0

    const/4 v4, 0x0

    const-class p3, Ljava/lang/Boolean;

    const-class p3, Ljava/lang/Boolean;

    const-class p3, Ljava/lang/Boolean;

    const-class p3, Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-ne p1, p3, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto/16 :goto_9

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object p3, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq p1, p3, :cond_21

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-class p3, Ljava/lang/Byte;

    const-class p3, Ljava/lang/Byte;

    const/4 v5, 0x0

    const-class p3, Ljava/lang/Byte;

    const-class p3, Ljava/lang/Byte;

    const/4 v5, 0x5

    if-ne p1, p3, :cond_a

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto/16 :goto_8

    :cond_a
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object p3, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq p1, p3, :cond_b

    const/4 v5, 0x1

    const/4 v4, 0x3

    const-class p3, Ljava/lang/Character;

    const-class p3, Ljava/lang/Character;

    const/4 v5, 0x3

    const-class p3, Ljava/lang/Character;

    const-class p3, Ljava/lang/Character;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne p1, p3, :cond_c

    :cond_b
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    instance-of p3, p0, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz p3, :cond_c

    move-object p3, p0

    move-object p3, p0

    move-object p3, p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast p3, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne v3, v1, :cond_c

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p3, v2}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-object p0

    :cond_c
    const/4 v5, 0x0

    sget-object p3, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eq p1, p3, :cond_20

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-class p3, Ljava/lang/Short;

    const-class p3, Ljava/lang/Short;

    const/4 v5, 0x4

    const-class p3, Ljava/lang/Short;

    const-class p3, Ljava/lang/Short;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ne p1, p3, :cond_d

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto/16 :goto_7

    :cond_d
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget-object p3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    if-eq p1, p3, :cond_1f

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-class p3, Ljava/lang/Integer;

    const-class p3, Ljava/lang/Integer;

    const/4 v5, 0x3

    const-class p3, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p1, p3, :cond_e

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto/16 :goto_6

    :cond_e
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object p3, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x4

    if-eq p1, p3, :cond_1e

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-class p3, Ljava/lang/Long;

    const-class p3, Ljava/lang/Long;

    const/4 v5, 0x0

    const-class p3, Ljava/lang/Long;

    const-class p3, Ljava/lang/Long;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ne p1, p3, :cond_f

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto/16 :goto_5

    :cond_f
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object p3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq p1, p3, :cond_1d

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-class p3, Ljava/lang/Float;

    const-class p3, Ljava/lang/Float;

    const/4 v5, 0x1

    const-class p3, Ljava/lang/Float;

    const-class p3, Ljava/lang/Float;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne p1, p3, :cond_10

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto/16 :goto_4

    :cond_10
    const/4 v5, 0x0

    const/4 v4, 0x4

    sget-object p3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq p1, p3, :cond_1c

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-class p3, Ljava/lang/Double;

    const-class p3, Ljava/lang/Double;

    const-class p3, Ljava/lang/Double;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ne p1, p3, :cond_11

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto/16 :goto_3

    :cond_11
    const/4 v5, 0x7

    const/4 v4, 0x1

    const-class p3, Ljava/lang/String;

    const-class p3, Ljava/lang/String;

    const/4 v5, 0x2

    const-class p3, Ljava/lang/String;

    const-class p3, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ne p1, p3, :cond_12

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p0}, Lq0/d;->v(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p0

    :cond_12
    const/4 v5, 0x6

    const/4 v4, 0x3

    const-class p3, Ljava/math/BigDecimal;

    const-class p3, Ljava/math/BigDecimal;

    const/4 v5, 0x2

    const-class p3, Ljava/math/BigDecimal;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne p1, p3, :cond_13

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p0}, Lq0/d;->f(Ljava/lang/Object;)Ljava/math/BigDecimal;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object p0

    :cond_13
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-class p3, Ljava/math/BigInteger;

    const-class p3, Ljava/math/BigInteger;

    const/4 v5, 0x1

    const-class p3, Ljava/math/BigInteger;

    const-class p3, Ljava/math/BigInteger;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ne p1, p3, :cond_14

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p0}, Lq0/d;->g(Ljava/lang/Object;)Ljava/math/BigInteger;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object p0

    :cond_14
    const/4 v5, 0x1

    const/4 v4, 0x0

    const-class p3, Ljava/util/Date;

    const/4 v5, 0x6

    const-class p3, Ljava/util/Date;

    const-class p3, Ljava/util/Date;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p1, p3, :cond_15

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0}, Lq0/d;->l(Ljava/lang/Object;)Ljava/util/Date;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object p0

    :cond_15
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->isEnum()Z

    move-result p3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p3, :cond_16

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p0, p1, p2}, Lq0/d;->n(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object p0

    :cond_16
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-class p2, Ljava/util/Calendar;

    const-class p2, Ljava/util/Calendar;

    const/4 v5, 0x7

    const-class p2, Ljava/util/Calendar;

    const-class p2, Ljava/util/Calendar;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v1, " c:n ttpaun  co to"

    const-string v1, " :tcnsu o c tatn o"

    const/4 v5, 0x6

    const-string/jumbo v1, "s:tta n qtnco a c "

    const-string v1, "can not cast to : "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz p3, :cond_18

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p0}, Lq0/d;->l(Ljava/lang/Object;)Ljava/util/Date;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ne p1, p2, :cond_17

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object p1, Lcom/alibaba/fastjson/a;->a:Ljava/util/TimeZone;

    const/4 v5, 0x0

    sget-object p2, Lcom/alibaba/fastjson/a;->b:Ljava/util/Locale;

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {p1, p2}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;Ljava/util/Locale;)Ljava/util/Calendar;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_1

    :cond_17
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast p2, Ljava/util/Calendar;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, p0}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    return-object p1

    :catch_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v4, 0x6

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p2, p1, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw p2

    :cond_18
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    instance-of p2, p0, Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p2, :cond_1b

    const/4 v4, 0x2

    move v5, v4

    check-cast p0, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz p2, :cond_1a

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo p2, "llnu"

    const/4 v5, 0x5

    const-string/jumbo p2, "unll"

    const-string/jumbo p2, "null"

    const/4 v5, 0x4

    invoke-virtual {p2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p2, :cond_19

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_2

    :cond_19
    const/4 v4, 0x6

    const/4 v5, 0x1

    const-class p2, Ljava/util/Currency;

    const/4 v5, 0x4

    const-class p2, Ljava/util/Currency;

    const-class p2, Ljava/util/Currency;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne p1, p2, :cond_1b

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p0}, Ljava/util/Currency;->getInstance(Ljava/lang/String;)Ljava/util/Currency;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object p0

    :cond_1a
    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object v0

    :cond_1b
    const/4 v5, 0x2

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw p0

    :cond_1c
    :goto_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p0}, Lq0/d;->m(Ljava/lang/Object;)Ljava/lang/Double;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object p0

    :cond_1d
    :goto_4
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p0}, Lq0/d;->o(Ljava/lang/Object;)Ljava/lang/Float;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p0

    :cond_1e
    :goto_5
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0}, Lq0/d;->t(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    return-object p0

    :cond_1f
    :goto_6
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p0}, Lq0/d;->p(Ljava/lang/Object;)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p0

    :cond_20
    :goto_7
    const/4 v5, 0x5

    invoke-static {p0}, Lq0/d;->u(Ljava/lang/Object;)Ljava/lang/Short;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object p0

    :cond_21
    :goto_8
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p0}, Lq0/d;->i(Ljava/lang/Object;)Ljava/lang/Byte;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p0

    :cond_22
    :goto_9
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p0}, Lq0/d;->h(Ljava/lang/Object;)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p0

    :cond_23
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string p1, " ns llasipzzu"

    const-string/jumbo p1, "llusaz p lzin"

    const-string p1, " ilmlzz acnus"

    const-string p1, "clazz is null"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw p0
.end method

.method public static final d(Ljava/lang/Object;Ljava/lang/reflect/ParameterizedType;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/ParameterizedType;",
            "Lcom/alibaba/fastjson/parser/m;",
            ")TT;"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez p0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-object p0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-class v1, Lcom/alibaba/fastjson/e;

    const-class v1, Lcom/alibaba/fastjson/e;

    const/4 v9, 0x2

    const-class v1, Lcom/alibaba/fastjson/e;

    const-class v1, Lcom/alibaba/fastjson/e;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-class v2, Ljava/util/ArrayList;

    const-class v2, Ljava/util/ArrayList;

    const/4 v9, 0x2

    const-class v2, Ljava/util/ArrayList;

    const-class v2, Ljava/util/ArrayList;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v9, 0x0

    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v9, 0x3

    const/4 v4, 0x0

    const/4 v9, 0x0

    shr-int/2addr v8, v4

    const/4 v9, 0x6

    if-eq v0, v3, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-ne v0, v2, :cond_5

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    aget-object v5, v5, v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    instance-of v6, p0, Ljava/util/List;

    const/4 v9, 0x0

    const/4 v8, 0x7

    if-eqz v6, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast p0, Ljava/util/List;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    move v2, v4

    move v2, v4

    const/4 v9, 0x5

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-ge v2, p1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    instance-of v6, v5, Ljava/lang/Class;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-eqz v6, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v3, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x2

    if-ne v6, v1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast v3, Lcom/alibaba/fastjson/e;

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    check-cast v6, Ljava/lang/Class;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v3, v6, p2, v4}, Lcom/alibaba/fastjson/e;->Q0(Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_1

    :cond_2
    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    check-cast v6, Ljava/lang/Class;

    const/4 v9, 0x1

    invoke-static {v3, v6, p2, v4}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto :goto_1

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v3, v5, p2}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v3

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-object v0

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-class v5, Ljava/util/TreeSet;

    const-class v5, Ljava/util/TreeSet;

    const/4 v9, 0x0

    const-class v5, Ljava/util/TreeSet;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-class v6, Ljava/util/HashSet;

    const-class v6, Ljava/util/HashSet;

    const/4 v9, 0x2

    const-class v6, Ljava/util/HashSet;

    const-class v6, Ljava/util/HashSet;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-class v7, Ljava/util/Set;

    const/4 v9, 0x3

    const-class v7, Ljava/util/Set;

    const-class v7, Ljava/util/Set;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eq v0, v7, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eq v0, v6, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eq v0, v5, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x1

    if-eq v0, v3, :cond_6

    const/4 v9, 0x4

    if-ne v0, v2, :cond_d

    :cond_6
    const/4 v8, 0x5

    const/4 v8, 0x7

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    aget-object v2, v2, v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    instance-of v3, p0, Ljava/lang/Iterable;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v3, :cond_d

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-eq v0, v7, :cond_9

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ne v0, v6, :cond_7

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_2

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-ne v0, v5, :cond_8

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    new-instance p1, Ljava/util/TreeSet;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p1}, Ljava/util/TreeSet;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto :goto_3

    :cond_8
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_3

    :cond_9
    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    new-instance p1, Ljava/util/HashSet;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    :goto_3
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    check-cast p0, Ljava/lang/Iterable;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_4
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v0, :cond_c

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    instance-of v3, v2, Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x4

    if-eqz v3, :cond_b

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v0, :cond_a

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-ne v3, v1, :cond_a

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    check-cast v0, Lcom/alibaba/fastjson/e;

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    check-cast v3, Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0, v3, p2, v4}, Lcom/alibaba/fastjson/e;->Q0(Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_5

    :cond_a
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    check-cast v3, Ljava/lang/Class;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v0, v3, p2, v4}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_5

    :cond_b
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v0, v2, p2}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v0

    :goto_5
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {p1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_4

    :cond_c
    const/4 v8, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    return-object p1

    :cond_d
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-class v1, Ljava/util/Map;

    const-class v1, Ljava/util/Map;

    const/4 v9, 0x1

    const-class v1, Ljava/util/Map;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eq v0, v1, :cond_e

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-class v1, Ljava/util/HashMap;

    const-class v1, Ljava/util/HashMap;

    const-class v1, Ljava/util/HashMap;

    const-class v1, Ljava/util/HashMap;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ne v0, v1, :cond_10

    :cond_e
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    aget-object v1, v1, v4

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    aget-object v3, v3, v2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    instance-of v5, p0, Ljava/util/Map;

    const/4 v8, 0x4

    move v9, v8

    if-eqz v5, :cond_10

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-instance p1, Ljava/util/HashMap;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast p0, Ljava/util/Map;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_6
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v0, :cond_f

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v8, 0x0

    move v9, v8

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v2, v1, p2}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v0, v3, p2}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {p1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_6

    :cond_f
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-object p1

    :cond_10
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    instance-of v1, p0, Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v1, :cond_12

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v3, :cond_11

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v3, "ulnl"

    const-string/jumbo v3, "llun"

    const/4 v9, 0x5

    const-string/jumbo v3, "nllu"

    const-string/jumbo v3, "null"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v1, :cond_12

    :cond_11
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 p0, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-object p0

    :cond_12
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    array-length v1, v1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ne v1, v2, :cond_13

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    aget-object v1, v1, v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    instance-of v1, v1, Ljava/lang/reflect/WildcardType;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v1, :cond_13

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p0, v0, p2}, Lq0/d;->e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    return-object p0

    :cond_13
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v0, "   aotn:coc snaoq "

    const-string/jumbo v0, "oa   tn q sconact:"

    const/4 v9, 0x7

    const-string v0, "can not cast to : "

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    throw p0
.end method

.method public static final e(Ljava/lang/Object;Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/Type;",
            "Lcom/alibaba/fastjson/parser/m;",
            ")TT;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, p1, Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p1, Ljava/lang/Class;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0, p1, p2, v0}, Lq0/d;->c(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of v1, p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0, p1, p2}, Lq0/d;->d(Ljava/lang/Object;Ljava/lang/reflect/ParameterizedType;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0

    :cond_2
    const/4 v3, 0x6

    instance-of p2, p0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p2, :cond_4

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast p2, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "luln"

    const-string/jumbo v1, "unll"

    const/4 v3, 0x4

    const-string/jumbo v1, "null"

    const-string/jumbo v1, "null"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p2, :cond_4

    :cond_3
    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of p2, p1, Ljava/lang/reflect/TypeVariable;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p2, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0

    :cond_5
    const/4 v2, 0x3

    move v3, v2

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "ccot bs :a ntastno"

    const-string/jumbo v0, "n stnsa tc: cooat "

    const/4 v3, 0x6

    const-string/jumbo v0, "ncas tuao c  :ontt"

    const-string v0, "can not cast to : "

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p0
.end method

.method public static final f(Ljava/lang/Object;)Ljava/math/BigDecimal;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, p0, Ljava/math/BigDecimal;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    check-cast p0, Ljava/math/BigDecimal;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0

    :cond_1
    const/4 v2, 0x5

    move v3, v2

    instance-of v1, p0, Ljava/math/BigInteger;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/math/BigDecimal;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast p0, Ljava/math/BigInteger;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v1, "luln"

    const-string/jumbo v1, "lnlu"

    const/4 v3, 0x5

    const-string/jumbo v1, "nllu"

    const-string/jumbo v1, "null"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x6

    new-instance v0, Ljava/math/BigDecimal;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public static final g(Ljava/lang/Object;)Ljava/math/BigInteger;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x0

    move v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    instance-of v1, p0, Ljava/math/BigInteger;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast p0, Ljava/math/BigInteger;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0

    :cond_1
    const/4 v3, 0x7

    instance-of v1, p0, Ljava/lang/Float;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x2

    instance-of v1, p0, Ljava/lang/Double;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_1

    :cond_2
    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "unll"

    const-string/jumbo v1, "nlul"

    const/4 v3, 0x5

    const-string/jumbo v1, "lnul"

    const-string/jumbo v1, "null"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/math/BigInteger;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_5
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    check-cast p0, Ljava/lang/Number;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0
.end method

.method public static final h(Ljava/lang/Object;)Ljava/lang/Boolean;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v5, 0x6

    return-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    instance-of v1, p0, Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast p0, Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    instance-of v1, p0, Ljava/math/BigDecimal;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    and-int/2addr v5, v3

    if-eqz v1, :cond_3

    const/4 v5, 0x5

    check-cast p0, Ljava/math/BigDecimal;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/math/BigDecimal;->intValueExact()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-ne p0, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    move v2, v3

    move v2, v3

    const/4 v5, 0x6

    move v2, v3

    move v2, v3

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p0

    :cond_3
    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    check-cast p0, Ljava/lang/Number;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ne p0, v3, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    move v2, v3

    move v2, v3

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p0

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    instance-of v1, p0, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v1, :cond_b

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v2, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "nllu"

    const-string/jumbo v2, "null"

    const/4 v5, 0x0

    const-string/jumbo v2, "ulnl"

    const-string/jumbo v2, "null"

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v2, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_1

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string/jumbo v0, "utre"

    const-string/jumbo v0, "tuer"

    const/4 v5, 0x2

    const-string/jumbo v0, "treu"

    const-string/jumbo v0, "true"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v0, :cond_9

    const/4 v5, 0x0

    const-string v0, "1"

    const-string v0, "1"

    const/4 v5, 0x2

    const-string v0, "1"

    const-string v0, "1"

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_7
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v0, "seplf"

    const-string v0, "eflms"

    const/4 v5, 0x0

    const-string v0, "fseqa"

    const-string v0, "false"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v0, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x6

    const-string v0, "0"

    const-string v0, "0"

    const-string v0, "0"

    const-string v0, "0"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_b

    :cond_8
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object p0

    :cond_9
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0

    :cond_a
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v0

    :cond_b
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v2, "tns  vlinacuceotots tn a o:  "

    const-string v2, " ataotn sluov : n ecoctait  n"

    const/4 v5, 0x4

    const-string v2, " aima ocnlnv,t eot n: cst a u"

    const-string v2, "can not cast to int, value : "

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    throw v0
.end method

.method public static final i(Ljava/lang/Object;)Ljava/lang/Byte;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p0, Ljava/lang/Number;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Number;->byteValue()B

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    instance-of v1, p0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v1, "null"

    const-string/jumbo v1, "llnu"

    const/4 v4, 0x3

    const-string/jumbo v1, "null"

    const-string/jumbo v1, "null"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Byte;->parseByte(Ljava/lang/String;)B

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p0

    :cond_3
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "t,uc beal:sttc a o b v ayn nto"

    const/4 v4, 0x7

    const-string v2, "cao ol  ctt,u tsayae te:vonb  "

    const-string v2, "can not cast to byte, value : "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    throw v0
.end method

.method public static final j(Ljava/lang/Object;)[B
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    instance-of v0, p0, [B

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p0, [B

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    instance-of v0, p0, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-static {p0, v1, v0}, Lcom/alibaba/fastjson/parser/e;->i(Ljava/lang/String;II)[B

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v2, "auv nbn a tcnt suliteo:t ,o c"

    const-string v2, "c ntltuvane i   o, tcnsotau: "

    const/4 v4, 0x5

    const-string v2, "can not cast to int, value : "

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw v0
.end method

.method public static final k(Ljava/lang/Object;)Ljava/lang/Character;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    instance-of v1, p0, Ljava/lang/Character;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    move v5, v4

    check-cast p0, Ljava/lang/Character;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    instance-of v1, p0, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v2, ",cel cutoo  snnbta  ttpeu: yaa"

    const-string v2, " aaucespabyottn :o lcn, e  tt "

    const/4 v5, 0x1

    const-string v2, "ce :vosp en ,aclt tu yttn ob a"

    const-string v2, "can not cast to byte, value : "

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_4

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v3, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object v0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne v0, v3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 p0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p0

    :cond_3
    const/4 v5, 0x3

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    throw v0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw v0
.end method

.method public static final l(Ljava/lang/Object;)Ljava/util/Date;
    .locals 7

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez p0, :cond_0

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    return-object v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    instance-of v1, p0, Ljava/util/Calendar;

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast p0, Ljava/util/Calendar;

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    instance-of v1, p0, Ljava/util/Date;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    move v6, v5

    check-cast p0, Ljava/util/Date;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-object p0

    :cond_2
    const/4 v6, 0x4

    instance-of v1, p0, Ljava/math/BigDecimal;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v2, "tt en   qcc tavlqoean:,u saoDa"

    const-string/jumbo v2, "nu ta:n qeo taol  eva,c statcD"

    const/4 v6, 0x3

    const-string v2, " ussenoD    atn:l,vct aaeactto"

    const-string v2, "can not cast to Date, value : "

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v1, :cond_4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    check-cast v0, Ljava/math/BigDecimal;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v0}, Ljava/math/BigDecimal;->scale()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/16 v3, -0x64

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-lt v1, v3, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/16 v3, 0x64

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-gt v1, v3, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/math/BigDecimal;->longValue()J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto/16 :goto_2

    :cond_3
    invoke-virtual {v0}, Ljava/math/BigDecimal;->longValueExact()J

    move-result-wide v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto/16 :goto_2

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    check-cast v0, Ljava/lang/Number;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto/16 :goto_2

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    instance-of v1, p0, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v1, :cond_d

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v6, 0x5

    const/16 v3, 0x2d

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v4, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eq v3, v4, :cond_a

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object v0, Lcom/alibaba/fastjson/a;->e:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x4

    move v6, v5

    if-ne p0, v0, :cond_6

    const/4 v6, 0x2

    sget-object p0, Lcom/alibaba/fastjson/a;->e:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/16 v0, 0xa

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ne p0, v0, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string p0, "-yymsM-dyd"

    const-string p0, "d-sMdyy-yy"

    const/4 v6, 0x5

    const-string p0, "-dMMo-yydy"

    const-string/jumbo p0, "yyyy-MM-dd"

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_7
    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/16 v0, 0x13

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ne p0, v0, :cond_8

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string p0, "H:Hm -ddymsMmsM:-yy"

    const/4 v6, 0x6

    const-string/jumbo p0, "m:dyybsmHs-dMMH-: y"

    const-string/jumbo p0, "yyyy-MM-dd HH:mm:ss"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_8
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/16 v0, 0x1d

    const/4 v6, 0x5

    const/4 v5, 0x7

    if-ne p0, v0, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 p0, 0x1a

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/16 v0, 0x3a

    const/4 v6, 0x0

    const/4 v5, 0x7

    if-ne p0, v0, :cond_9

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    const/16 p0, 0x1c

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/16 v0, 0x30

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-ne p0, v0, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string p0, "dsHmdyuMX/SmyyX/HSy:X//Mo-ST:."

    const-string p0, ":sHXomyS/y.dT/-XyHSM:m-X//yMSd"

    const/4 v6, 0x6

    const-string p0, "SHdyTyMpX.d-HSMm//Sy/:-:sXX/sy"

    const-string/jumbo p0, "yyyy-MM-dd\'T\'HH:mm:ss.SSSXXX"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_9
    const/4 v6, 0x7

    const-string/jumbo p0, "mdH:- M.qHyyysmSbsMSSdy"

    const-string/jumbo p0, "syHM-bMHySsmdy .S:Sd:ym"

    const/4 v6, 0x6

    const-string/jumbo p0, "mHsH-MyMys-md:d:S.sSyS "

    const-string/jumbo p0, "yyyy-MM-dd HH:mm:ss.SSS"

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v6, 0x5

    const/4 v5, 0x3

    sget-object v3, Lcom/alibaba/fastjson/a;->b:Ljava/util/Locale;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v0, p0, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget-object p0, Lcom/alibaba/fastjson/a;->a:Ljava/util/TimeZone;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p0
    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object p0

    :catch_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {p0, v0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    throw p0

    :cond_a
    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v3, :cond_c

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v3, "lnul"

    const-string/jumbo v3, "null"

    const/4 v6, 0x1

    const-string/jumbo v3, "null"

    const-string/jumbo v3, "null"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v3, :cond_b

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_1

    :cond_b
    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_2

    :cond_c
    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v0

    :cond_d
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v6, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    cmp-long v3, v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ltz v3, :cond_e

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance p0, Ljava/util/Date;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {p0, v0, v1}, Ljava/util/Date;-><init>(J)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p0

    :cond_e
    const/4 v6, 0x2

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    throw v0
.end method

.method public static final m(Ljava/lang/Object;)Ljava/lang/Double;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast p0, Ljava/lang/Number;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_1
    const/4 v4, 0x0

    instance-of v1, p0, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v1, "luln"

    const-string/jumbo v1, "llun"

    const/4 v4, 0x4

    const-string/jumbo v1, "lnlu"

    const-string/jumbo v1, "null"

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v1, "LLUN"

    const/4 v4, 0x7

    const-string v1, "UNLL"

    const-string v1, "NULL"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    return-object p0

    :cond_3
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "oubmsol:ta   vcnl,c a utaee otd "

    const-string v2, "c  st uu ,:olu cbnt loovaead ate"

    const/4 v4, 0x7

    const-string v2, ",acno cote   eolont :dvsb a ltuu"

    const-string v2, "can not cast to double, value : "

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw v0
.end method

.method public static final n(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            ")TT;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p2, "n o  bnt:caaop tsc"

    const-string p2, "aca:  cpnostotn  t"

    const/4 v3, 0x6

    const-string p2, " t cn:u tat ncosao"

    const-string p2, "can not cast to : "

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    instance-of v0, p0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast p0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    instance-of v0, p0, Ljava/lang/Integer;

    const/4 v2, 0x7

    move v3, v2

    if-nez v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    instance-of v0, p0, Ljava/lang/Long;

    const/4 v3, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_3

    :cond_2
    check-cast p0, Ljava/lang/Number;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    array-length v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ge p0, v1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x2

    aget-object p0, v0, p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    return-object p0

    :cond_3
    const/4 v3, 0x2

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v2, 0x7

    move v3, v2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0

    :catch_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v2, 0x2

    move v3, v2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0, p1, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw v0
.end method

.method public static final o(Ljava/lang/Object;)Ljava/lang/Float;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    check-cast p0, Ljava/lang/Number;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    instance-of v1, p0, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "nllu"

    const-string/jumbo v1, "lunl"

    const/4 v4, 0x1

    const-string/jumbo v1, "luln"

    const-string/jumbo v1, "null"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    return-object p0

    :cond_3
    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x4

    const/4 v3, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, " o alt,cqa oafuo c vanslt t:en "

    const/4 v4, 0x0

    const-string v2, " flnv:lp n  cet, austoao a tcat"

    const-string v2, "can not cast to float, value : "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw v0
.end method

.method public static final p(Ljava/lang/Object;)Ljava/lang/Integer;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    instance-of v1, p0, Ljava/lang/Integer;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    check-cast p0, Ljava/lang/Integer;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    instance-of v1, p0, Ljava/math/BigDecimal;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    check-cast p0, Ljava/math/BigDecimal;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/math/BigDecimal;->scale()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/16 v1, -0x64

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-lt v0, v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v1, 0x64

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-gt v0, v1, :cond_2

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/math/BigDecimal;->intValue()I

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/math/BigDecimal;->intValueExact()I

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x4

    check-cast p0, Ljava/lang/Number;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_4
    const/4 v4, 0x0

    instance-of v1, p0, Ljava/lang/String;

    const/4 v3, 0x4

    move v4, v3

    if-eqz v1, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v1, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v1, "null"

    const/4 v4, 0x7

    const-string/jumbo v1, "null"

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_6
    :goto_0
    const/4 v4, 0x6

    return-object v0

    :cond_7
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const-string v2, "ce al,otq oa a   suvtc nn:itt"

    const-string v2, "can not cast to int, value : "

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    throw v0
.end method

.method public static final q(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1, v0}, Lq0/d;->b(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static final r(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, v0}, Lq0/d;->s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/alibaba/fastjson/parser/m;",
            "I)TT;"
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-class v0, Ljava/lang/StackTraceElement;

    const-class v0, Ljava/lang/StackTraceElement;

    const/4 v5, 0x4

    const-class v0, Ljava/lang/StackTraceElement;

    const-class v0, Ljava/lang/StackTraceElement;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne p1, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo p1, "lNsassaes"

    const-string p1, "aassNlsme"

    const/4 v5, 0x7

    const-string/jumbo p1, "lscmaNema"

    const-string p1, "className"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v4, 0x2

    move v5, v4

    const-string p2, "aNmooetdme"

    const-string p2, "htNmeodeam"

    const/4 v5, 0x0

    const-string/jumbo p2, "meeNhbdamo"

    const-string/jumbo p2, "methodName"

    const/4 v5, 0x0

    invoke-interface {p0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast p2, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo p3, "iNeeafum"

    const-string p3, "fileName"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {p0, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast p3, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo v0, "ieonmbeplr"

    const-string/jumbo v0, "rieuoebmnl"

    const/4 v5, 0x2

    const-string/jumbo v0, "menbelirqN"

    const-string/jumbo v0, "lineNumber"

    const/4 v5, 0x5

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast p0, Ljava/lang/Number;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x0

    move v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    instance-of v0, p0, Ljava/math/BigDecimal;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast p0, Ljava/math/BigDecimal;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/math/BigDecimal;->intValueExact()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p0, Ljava/lang/StackTraceElement;

    const/4 v5, 0x7

    invoke-direct {p0, p1, p2, p3, v1}, Ljava/lang/StackTraceElement;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v0, "etspb"

    const-string v0, "beytp"

    const/4 v5, 0x5

    const-string/jumbo v0, "p@ymt"

    const-string v0, "@type"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    instance-of v2, v0, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    move v5, v4

    if-eqz v2, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez p2, :cond_3

    const/4 v5, 0x6

    sget-object p2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p2, v0, v3, p3}, Lcom/alibaba/fastjson/parser/m;->a(Ljava/lang/String;Ljava/lang/Class;I)Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v0, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0, v2, p2, p3}, Lq0/d;->s(Ljava/util/Map;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object p0

    :cond_4
    const/4 v4, 0x7

    move v5, v4

    new-instance p0, Ljava/lang/ClassNotFoundException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    move v5, v4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string p2, " not found"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Ljava/lang/ClassNotFoundException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    throw p0

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->isInterface()Z

    move-result p3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p3, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    instance-of p3, p0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p3, :cond_6

    const/4 v5, 0x3

    check-cast p0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_1

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p3, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p3, p0}, Lcom/alibaba/fastjson/e;-><init>(Ljava/util/Map;)V

    move-object p0, p3

    move-object p0, p3

    move-object p0, p3

    move-object p0, p3

    :goto_1
    const/4 v5, 0x0

    if-nez p2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/alibaba/fastjson/parser/m;->f()Lcom/alibaba/fastjson/parser/m;

    move-result-object p2

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p2

    const/4 v5, 0x6

    if-eqz p2, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0, p1}, Lcom/alibaba/fastjson/a;->w(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-object p0

    :cond_8
    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Thread;->getContextClassLoader()Ljava/lang/ClassLoader;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 p3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-array p3, p3, [Ljava/lang/Class;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    aput-object p1, p3, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p2, p3, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0

    :cond_9
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-class p3, Ljava/lang/String;

    const-class p3, Ljava/lang/String;

    const/4 v5, 0x2

    const-class p3, Ljava/lang/String;

    const-class p3, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ne p1, p3, :cond_a

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    instance-of p3, p0, Lcom/alibaba/fastjson/e;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz p3, :cond_a

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object p0

    :cond_a
    const/4 v5, 0x2

    if-nez p2, :cond_b

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object p2, Lcom/alibaba/fastjson/parser/m;->g:Lcom/alibaba/fastjson/parser/m;

    :cond_b
    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    instance-of p3, p1, Lcom/alibaba/fastjson/parser/g;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p3, :cond_c

    move-object v3, p1

    move-object v3, p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    check-cast v3, Lcom/alibaba/fastjson/parser/g;

    :cond_c
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v3, :cond_d

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {v3, p0, p2}, Lcom/alibaba/fastjson/parser/g;->c(Ljava/util/Map;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object p0

    :cond_d
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string p1, " ungorvDlranneceiBieaao steeztaj"

    const-string p1, "esBr lutaaDnioeeijcr gantvan eez"

    const/4 v5, 0x5

    const-string p1, "etiajba rnecol DnevseBezgi nrata"

    const-string p1, "can not get javaBeanDeserializer"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    move v5, v4

    throw p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1, p2, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    throw p1
.end method

.method public static final t(Ljava/lang/Object;)Ljava/lang/Long;
    .locals 6

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    instance-of v1, p0, Ljava/math/BigDecimal;

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    check-cast p0, Ljava/math/BigDecimal;

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/math/BigDecimal;->scale()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v1, -0x64

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-lt v0, v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/16 v1, 0x64

    const/4 v4, 0x4

    move v5, v4

    if-gt v0, v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/math/BigDecimal;->longValue()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/math/BigDecimal;->longValueExact()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object p0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_3

    const/4 v5, 0x3

    check-cast p0, Ljava/lang/Number;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object p0

    :cond_3
    const/4 v5, 0x2

    instance-of v1, p0, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "lnlu"

    const-string/jumbo v2, "null"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v2, :cond_4

    const/4 v5, 0x7

    goto :goto_0

    :cond_4
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object p0

    :catch_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v2, v1}, Lcom/alibaba/fastjson/parser/e;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Lcom/alibaba/fastjson/parser/e;->M(Z)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, v2, Lcom/alibaba/fastjson/parser/e;->o:Ljava/util/Calendar;

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v5, 0x4

    if-eqz v0, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object p0

    :cond_6
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object v0

    :cond_7
    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    move v5, v4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, "can not cast to long, value : "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw v0
.end method

.method public static final u(Ljava/lang/Object;)Ljava/lang/Short;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    instance-of v1, p0, Ljava/lang/Number;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast p0, Ljava/lang/Number;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Number;->shortValue()S

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p0

    :cond_1
    const/4 v4, 0x1

    instance-of v1, p0, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "null"

    const-string/jumbo v1, "lunl"

    const/4 v4, 0x2

    const-string/jumbo v1, "unll"

    const-string/jumbo v1, "null"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Short;->parseShort(Ljava/lang/String;)S

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p0

    :cond_3
    :goto_0
    const/4 v3, 0x1

    move v4, v3

    return-object v0

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, " ,sn   porentto: utltavaac o cs"

    const/4 v4, 0x0

    const-string/jumbo v2, "o vocuut rs ae:o tt ,ahannst  l"

    const-string v2, "can not cast to short, value : "

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    or-int/2addr v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    throw v0
.end method

.method public static final v(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-nez p0, :cond_0

    const/4 v1, 0x1

    const/4 p0, 0x0

    const/4 v1, 0x6

    move v0, p0

    move v0, p0

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public static w(Ljava/lang/reflect/GenericArrayType;)Ljava/lang/reflect/Type;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "["

    const-string v1, "["

    const/4 v4, 0x0

    const-string v1, "["

    const-string v1, "["

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    instance-of v2, v0, Ljava/lang/reflect/GenericArrayType;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v0, Ljava/lang/reflect/GenericArrayType;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    instance-of v2, v0, Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v2, :cond_8

    const/4 v4, 0x6

    check-cast v0, Ljava/lang/Class;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v2, :cond_8

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ne v0, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v1, "Z"

    const-string v1, "Z"

    const/4 v4, 0x5

    const-string v1, "Z"

    const-string v1, "Z"

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto/16 :goto_1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    sget-object v2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne v0, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, "C"

    const-string v1, "C"

    const/4 v4, 0x0

    const-string v1, "C"

    const-string v1, "C"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v2, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ne v0, v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    const-string v1, "B"

    const-string v1, "B"

    const/4 v4, 0x7

    const-string v1, "B"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object v2, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-ne v0, v2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "S"

    const-string v1, "S"

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto/16 :goto_1

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x2

    if-ne v0, v2, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v1, "I"

    const-string v1, "I"

    const/4 v4, 0x3

    const-string v1, "I"

    const-string v1, "I"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto/16 :goto_1

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-ne v0, v2, :cond_6

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "J"

    const-string v1, "J"

    const/4 v4, 0x1

    const-string v1, "J"

    const-string v1, "J"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_1

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v2, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v0, v2, :cond_7

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "F"

    const/4 v4, 0x4

    const-string v1, "F"

    const-string v1, "F"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_1

    :cond_7
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v2, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-ne v0, v2, :cond_8

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "D"

    const-string v1, "D"

    const/4 v4, 0x3

    const-string v1, "D"

    const-string v1, "D"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_8
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p0
.end method

.method public static x(Ljava/lang/Class;IZLp0/c;Ljava/util/Map;ZZZLcom/alibaba/fastjson/j;)Ljava/util/List;
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;IZ",
            "Lp0/c;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;ZZZ",
            "Lcom/alibaba/fastjson/j;",
            ")",
            "Ljava/util/List<",
            "Lq0/a;",
            ">;"
        }
    .end annotation

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move/from16 v12, p1

    move/from16 v12, p1

    move/from16 v12, p1

    move/from16 v12, p1

    move-object/from16 v13, p3

    move-object/from16 v13, p3

    move-object/from16 v13, p3

    move-object/from16 v13, p3

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v15, p8

    move-object/from16 v15, p8

    move-object/from16 v15, p8

    move-object/from16 v15, p8

    new-instance v10, Ljava/util/LinkedHashMap;

    invoke-direct {v10}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v8

    const-class v7, Ljava/lang/Object;

    const-class v7, Ljava/lang/Object;

    const-class v7, Ljava/lang/Object;

    const-class v6, Lp0/b;

    const-class v6, Lp0/b;

    const-class v6, Lp0/b;

    const/16 v16, 0x0

    if-nez p2, :cond_37

    invoke-static/range {p0 .. p0}, Lq0/d;->N(Ljava/lang/Class;)Z

    move-result v17

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    :goto_0
    if-eqz v1, :cond_5

    if-eq v1, v7, :cond_5

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x0

    :goto_1
    if-ge v4, v3, :cond_4

    aget-object v5, v2, v4

    move-object/from16 p2, v2

    move-object/from16 p2, v2

    move-object/from16 p2, v2

    move-object/from16 p2, v2

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getModifiers()I

    move-result v2

    and-int/lit8 v20, v2, 0x8

    if-nez v20, :cond_2

    and-int/lit8 v20, v2, 0x2

    if-nez v20, :cond_2

    move/from16 v20, v3

    move/from16 v20, v3

    move/from16 v20, v3

    move/from16 v20, v3

    and-int/lit16 v3, v2, 0x100

    if-nez v3, :cond_3

    and-int/lit8 v2, v2, 0x4

    if-eqz v2, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v2

    sget-object v3, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v2

    array-length v2, v2

    if-nez v2, :cond_3

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v2

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    const-class v3, Ljava/lang/ClassLoader;

    if-eq v2, v3, :cond_3

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v2

    if-ne v2, v7, :cond_1

    goto :goto_2

    :cond_1
    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_2
    move/from16 v20, v3

    move/from16 v20, v3

    move/from16 v20, v3

    move/from16 v20, v3

    :cond_3
    :goto_2
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move/from16 v3, v20

    move/from16 v3, v20

    goto :goto_1

    :cond_4
    invoke-virtual {v1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v1

    goto :goto_0

    :cond_5
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v20

    move-object/from16 v0, v16

    move-object/from16 v0, v16

    move-object/from16 v0, v16

    move-object/from16 v0, v16

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_3
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_37

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    move-object v5, v4

    check-cast v5, Ljava/lang/reflect/Method;

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v4

    move-object/from16 p2, v1

    move-object/from16 p2, v1

    move-object/from16 p2, v1

    move-object/from16 p2, v1

    const-string/jumbo v1, "tesgsaaplqte"

    const-string/jumbo v1, "tgatsealqesC"

    const-string v1, "getMetaClass"

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    const-string v2, "asal.vMyqleoCa.sogrst"

    const-string v2, ".esrsloaaMglosyav.Cgt"

    const-string/jumbo v2, "ylsMose.atsrlC.vagagn"

    const-string v2, "groovy.lang.MetaClass"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    goto :goto_5

    :cond_6
    move-object/from16 v21, v2

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    :cond_7
    if-eqz p6, :cond_8

    invoke-virtual {v5, v6}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v1

    check-cast v1, Lp0/b;

    goto :goto_4

    :cond_8
    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    :goto_4
    if-nez v1, :cond_9

    if-eqz p6, :cond_9

    invoke-static {v11, v5}, Lq0/d;->K(Ljava/lang/Class;Ljava/lang/reflect/Method;)Lp0/b;

    move-result-object v1

    :cond_9
    if-eqz v17, :cond_a

    invoke-static {v11, v4}, Lq0/d;->O(Ljava/lang/Class;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_a

    :goto_5
    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v2, v21

    move-object/from16 v2, v21

    move-object/from16 v2, v21

    move-object/from16 v2, v21

    goto :goto_3

    :cond_a
    const-string v2, "get"

    const-string/jumbo v2, "teg"

    const-string v2, "egt"

    const-string v2, "get"

    move-object/from16 v22, v10

    move-object/from16 v22, v10

    move-object/from16 v22, v10

    move-object/from16 v22, v10

    if-nez v1, :cond_14

    if-eqz v17, :cond_14

    if-nez v0, :cond_e

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Class;->getDeclaredConstructors()[Ljava/lang/reflect/Constructor;

    move-result-object v0

    array-length v10, v0

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    const/4 v3, 0x1

    if-ne v10, v3, :cond_d

    const/4 v10, 0x0

    aget-object v18, v0, v10

    invoke-virtual/range {v18 .. v18}, Ljava/lang/reflect/Constructor;->getParameterAnnotations()[[Ljava/lang/annotation/Annotation;

    move-result-object v18

    invoke-static/range {p0 .. p0}, Lq0/d;->J(Ljava/lang/Class;)[Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_c

    array-length v10, v3

    new-array v10, v10, [Ljava/lang/String;

    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v26, v0

    array-length v0, v3

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    const/4 v6, 0x0

    invoke-static {v3, v6, v10, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static {v10}, Ljava/util/Arrays;->sort([Ljava/lang/Object;)V

    array-length v0, v3

    new-array v0, v0, [S

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    :goto_6
    array-length v1, v3

    if-ge v6, v1, :cond_b

    aget-object v1, v3, v6

    invoke-static {v10, v1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v1

    aput-short v6, v0, v1

    add-int/lit8 v6, v6, 0x1

    int-to-short v6, v6

    goto :goto_6

    :cond_b
    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v0, v26

    move-object/from16 v0, v26

    move-object/from16 v0, v26

    move-object/from16 v0, v26

    goto :goto_7

    :cond_c
    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    goto :goto_7

    :cond_d
    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v26, v0

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    goto :goto_7

    :cond_e
    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    :goto_7
    if-eqz v1, :cond_12

    if-eqz v21, :cond_12

    invoke-virtual {v4, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_12

    const/4 v6, 0x3

    invoke-virtual {v4, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lq0/d;->y(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v10

    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    if-gez v10, :cond_10

    const/4 v0, 0x0

    :goto_8
    array-length v7, v1

    if-ge v0, v7, :cond_10

    aget-object v7, v1, v0

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_f

    move v10, v0

    move v10, v0

    move v10, v0

    move v10, v0

    goto :goto_9

    :cond_f
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_10
    :goto_9
    if-ltz v10, :cond_13

    aget-short v0, v21, v10

    aget-object v0, v3, v0

    if-eqz v0, :cond_13

    array-length v6, v0

    const/4 v7, 0x0

    :goto_a
    if-ge v7, v6, :cond_13

    aget-object v10, v0, v7

    move-object/from16 v24, v0

    move-object/from16 v24, v0

    move-object/from16 v24, v0

    move-object/from16 v24, v0

    instance-of v0, v10, Lp0/b;

    if-eqz v0, :cond_11

    check-cast v10, Lp0/b;

    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v29, v10

    move-object/from16 v29, v10

    move-object/from16 v29, v10

    move-object/from16 v29, v10

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    goto/16 :goto_b

    :cond_11
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v0, v24

    move-object/from16 v0, v24

    move-object/from16 v0, v24

    move-object/from16 v0, v24

    goto :goto_a

    :cond_12
    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 p2, v0

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    :cond_13
    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v24, v1

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    move-object/from16 v21, p2

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    goto :goto_b

    :cond_14
    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v28, v1

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v27, v6

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v18, v7

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v26, v21

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v29, v28

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v28, v24

    move-object/from16 v28, v24

    move-object/from16 v28, v24

    move-object/from16 v28, v24

    move-object/from16 v24, p2

    move-object/from16 v24, p2

    move-object/from16 v24, p2

    move-object/from16 v24, p2

    :goto_b
    if-eqz v29, :cond_18

    invoke-interface/range {v29 .. v29}, Lp0/b;->serialize()Z

    move-result v0

    if-nez v0, :cond_15

    :goto_c
    move-object v15, v8

    move-object v15, v8

    move-object v15, v8

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    const/16 v19, 0x0

    const/16 v25, 0x1

    goto/16 :goto_1d

    :cond_15
    invoke-interface/range {v29 .. v29}, Lp0/b;->ordinal()I

    move-result v6

    invoke-interface/range {v29 .. v29}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v0

    invoke-static {v0}, Lcom/alibaba/fastjson/serializer/a0;->a([Lcom/alibaba/fastjson/serializer/a0;)I

    move-result v7

    invoke-interface/range {v29 .. v29}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :cond_17

    invoke-interface/range {v29 .. v29}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    if-eqz v14, :cond_16

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_16

    goto :goto_c

    :cond_16
    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    invoke-static {v11, v5, v12}, Lq0/d;->T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z

    new-instance v4, Lq0/a;

    const/4 v3, 0x0

    const/16 v23, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x1

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object v2, v5

    move-object v2, v5

    const/4 v5, 0x1

    move-object/from16 v32, v4

    move-object/from16 v32, v4

    move-object/from16 v32, v4

    move-object/from16 v32, v4

    const/16 v19, 0x0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move/from16 v25, v5

    move/from16 v25, v5

    move/from16 v25, v5

    move-object/from16 v5, v23

    move-object/from16 v5, v23

    move-object/from16 v5, v23

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v9, v30

    move-object/from16 v9, v30

    move-object/from16 v9, v30

    move-object/from16 v9, v30

    move-object v15, v10

    move-object v15, v10

    move-object v15, v10

    move-object v15, v10

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move/from16 v10, v31

    move/from16 v10, v31

    move/from16 v10, v31

    invoke-direct/range {v0 .. v10}, Lq0/a;-><init>(Ljava/lang/String;Ljava/lang/reflect/Method;Ljava/lang/reflect/Field;Ljava/lang/Class;Ljava/lang/reflect/Type;IILp0/b;Lp0/b;Z)V

    move-object/from16 v0, v32

    move-object/from16 v0, v32

    move-object/from16 v0, v32

    invoke-interface {v12, v15, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_13

    :cond_17
    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    const/16 v19, 0x0

    const/16 v25, 0x1

    goto :goto_d

    :cond_18
    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v35, v8

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v36, v9

    move-object/from16 v34, v18

    move-object/from16 v34, v18

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v12, v22

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    move-object/from16 v33, v27

    const/16 v19, 0x0

    const/16 v25, 0x1

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_d
    invoke-virtual {v4, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/16 v15, 0x66

    const/16 v10, 0x5f

    if-eqz v0, :cond_27

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x4

    if-lt v0, v1, :cond_26

    const-string v0, "alemgmtC"

    const-string v0, "aetmglsC"

    const-string v0, "getClass"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_19

    :goto_e
    goto/16 :goto_13

    :cond_19
    const/4 v9, 0x3

    invoke-virtual {v4, v9}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v0}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v2

    if-eqz v2, :cond_1b

    sget-boolean v0, Lq0/d;->a:Z

    if-eqz v0, :cond_1a

    invoke-virtual {v4, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq0/d;->y(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_1a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v9}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_1b
    if-ne v0, v10, :cond_1c

    invoke-virtual {v4, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_1c
    if-ne v0, v15, :cond_1d

    invoke-virtual {v4, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_1d
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x5

    if-lt v0, v2, :cond_26

    invoke-virtual {v4, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v0}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v0

    if-eqz v0, :cond_26

    invoke-virtual {v4, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq0/d;->y(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_f
    invoke-static {v11, v13, v0}, Lq0/d;->M(Ljava/lang/Class;Lp0/c;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1e

    goto :goto_e

    :cond_1e
    move-object/from16 v3, v35

    move-object/from16 v3, v35

    move-object/from16 v3, v35

    move-object/from16 v8, v36

    move-object/from16 v8, v36

    move-object/from16 v8, v36

    move-object/from16 v8, v36

    invoke-static {v11, v0, v3, v8}, Lq0/d;->G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v2

    move-object/from16 v1, v33

    move-object/from16 v1, v33

    if-eqz v2, :cond_23

    if-eqz p6, :cond_1f

    invoke-virtual {v2, v1}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v18

    check-cast v18, Lp0/b;

    goto :goto_10

    :cond_1f
    move-object/from16 v18, v16

    move-object/from16 v18, v16

    move-object/from16 v18, v16

    move-object/from16 v18, v16

    :goto_10
    if-eqz v18, :cond_22

    invoke-interface/range {v18 .. v18}, Lp0/b;->serialize()Z

    move-result v6

    if-nez v6, :cond_20

    goto/16 :goto_12

    :cond_20
    invoke-interface/range {v18 .. v18}, Lp0/b;->ordinal()I

    move-result v6

    invoke-interface/range {v18 .. v18}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v7

    invoke-static {v7}, Lcom/alibaba/fastjson/serializer/a0;->a([Lcom/alibaba/fastjson/serializer/a0;)I

    move-result v7

    invoke-interface/range {v18 .. v18}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->length()I

    move-result v22

    if-eqz v22, :cond_22

    invoke-interface/range {v18 .. v18}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    if-eqz v14, :cond_21

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_21

    goto :goto_12

    :cond_21
    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v7, p8

    move-object/from16 v7, p8

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v6, v25

    move/from16 v6, v25

    goto :goto_11

    :cond_22
    move/from16 v22, v7

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v23, v18

    move-object/from16 v7, p8

    move-object/from16 v7, p8

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    goto :goto_11

    :cond_23
    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move-object/from16 v23, v16

    move-object/from16 v23, v16

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move-object/from16 v7, p8

    :goto_11
    if-eqz v7, :cond_24

    if-nez v6, :cond_24

    invoke-virtual {v7, v0}, Lcom/alibaba/fastjson/j;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_24
    if-eqz v14, :cond_25

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_25

    :goto_12
    move-object v15, v3

    move-object v15, v3

    move-object v15, v3

    move-object v15, v3

    move-object/from16 v36, v8

    move-object/from16 v36, v8

    move-object/from16 v36, v8

    move-object/from16 v36, v8

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    goto/16 :goto_1d

    :cond_25
    move/from16 v6, p1

    move/from16 v6, p1

    move/from16 v6, p1

    move/from16 v6, p1

    move-object/from16 v43, v12

    move-object/from16 v43, v12

    move-object/from16 v43, v12

    move-object v12, v0

    move-object v12, v0

    move-object v12, v0

    move-object v12, v0

    move-object/from16 v0, v43

    move-object/from16 v0, v43

    move-object/from16 v0, v43

    move-object/from16 v0, v43

    invoke-static {v11, v5, v6}, Lq0/d;->T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z

    new-instance v15, Lq0/a;

    const/16 v27, 0x0

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move-object v0, v15

    move-object v0, v15

    move-object/from16 v37, v1

    move-object/from16 v37, v1

    move-object/from16 v37, v1

    move-object/from16 v37, v1

    move-object v1, v12

    move-object v1, v12

    move-object v1, v12

    move-object v1, v12

    move-object/from16 v30, v2

    move-object/from16 v30, v2

    move-object/from16 v30, v2

    move-object/from16 v30, v2

    move-object v2, v5

    move-object v2, v5

    move-object v2, v5

    move-object v2, v5

    move-object/from16 v38, v3

    move-object/from16 v38, v3

    move-object/from16 v38, v3

    move-object/from16 v38, v3

    move-object/from16 v3, v30

    move-object/from16 v3, v30

    move-object/from16 v3, v30

    move-object/from16 v3, v30

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object/from16 v5, v27

    move-object/from16 v5, v27

    move-object/from16 v5, v27

    move-object/from16 v5, v27

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v7, v22

    move/from16 v7, v22

    move/from16 v7, v22

    move/from16 v7, v22

    move-object/from16 v40, v8

    move-object/from16 v40, v8

    move-object/from16 v40, v8

    move-object/from16 v40, v8

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move/from16 v27, v9

    move/from16 v27, v9

    move/from16 v27, v9

    move/from16 v27, v9

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move/from16 v13, v27

    move/from16 v13, v27

    move/from16 v13, v27

    move/from16 v13, v27

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    invoke-direct/range {v0 .. v10}, Lq0/a;-><init>(Ljava/lang/String;Ljava/lang/reflect/Method;Ljava/lang/reflect/Field;Ljava/lang/Class;Ljava/lang/reflect/Type;IILp0/b;Lp0/b;Z)V

    invoke-interface {v14, v12, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_14

    :cond_26
    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    :goto_13
    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    move-object/from16 v12, v33

    move-object/from16 v12, v33

    move-object/from16 v12, v33

    move-object/from16 v12, v33

    move-object/from16 v15, v35

    move-object/from16 v15, v35

    move-object/from16 v15, v35

    move-object/from16 v15, v35

    goto/16 :goto_1d

    :cond_27
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object/from16 v39, v5

    move-object v14, v12

    move-object v14, v12

    move-object v14, v12

    move-object/from16 v37, v33

    move-object/from16 v37, v33

    move-object/from16 v38, v35

    move-object/from16 v38, v35

    move-object/from16 v40, v36

    move-object/from16 v40, v36

    const/4 v13, 0x3

    :goto_14
    const-string/jumbo v0, "si"

    const-string/jumbo v0, "si"

    const-string/jumbo v0, "si"

    const-string/jumbo v0, "is"

    invoke-virtual {v11, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_28

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v0

    if-ge v0, v13, :cond_29

    :cond_28
    :goto_15
    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object/from16 v12, v37

    move-object/from16 v12, v37

    move-object/from16 v15, v38

    move-object/from16 v15, v38

    move-object/from16 v15, v38

    move-object/from16 v36, v40

    move-object/from16 v36, v40

    move-object/from16 v36, v40

    move-object/from16 v36, v40

    :goto_16
    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    goto/16 :goto_1d

    :cond_29
    const/4 v0, 0x2

    invoke-virtual {v11, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v2

    if-eqz v2, :cond_2b

    sget-boolean v1, Lq0/d;->a:Z

    if-eqz v1, :cond_2a

    invoke-virtual {v11, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq0/d;->y(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_17

    :cond_2a
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_17

    :cond_2b
    const/16 v2, 0x5f

    if-ne v1, v2, :cond_2c

    invoke-virtual {v11, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_17
    move-object/from16 v12, p3

    move-object/from16 v12, p3

    move-object/from16 v12, p3

    move-object/from16 v12, p3

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    goto :goto_18

    :cond_2c
    const/16 v2, 0x66

    if-ne v1, v2, :cond_28

    invoke-virtual {v11, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_17

    :goto_18
    invoke-static {v11, v12, v0}, Lq0/d;->M(Ljava/lang/Class;Lp0/c;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2d

    goto :goto_15

    :cond_2d
    move-object/from16 v15, v38

    move-object/from16 v15, v38

    move-object/from16 v15, v38

    move-object/from16 v15, v38

    move-object/from16 v13, v40

    move-object/from16 v13, v40

    move-object/from16 v13, v40

    move-object/from16 v13, v40

    invoke-static {v11, v0, v15, v13}, Lq0/d;->G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v2

    if-nez v2, :cond_2e

    invoke-static {v11, v1, v15, v13}, Lq0/d;->G(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/reflect/Field;Ljava/util/Map;)Ljava/lang/reflect/Field;

    move-result-object v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    goto :goto_19

    :cond_2e
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_19
    if-eqz v3, :cond_34

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    if-eqz p6, :cond_2f

    invoke-virtual {v3, v10}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v1

    check-cast v1, Lp0/b;

    goto :goto_1a

    :cond_2f
    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    :goto_1a
    if-eqz v1, :cond_33

    invoke-interface {v1}, Lp0/b;->serialize()Z

    move-result v2

    if-nez v2, :cond_30

    move-object v12, v10

    move-object v12, v10

    move-object v12, v10

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    goto/16 :goto_16

    :cond_30
    invoke-interface {v1}, Lp0/b;->ordinal()I

    move-result v2

    invoke-interface {v1}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v4

    invoke-static {v4}, Lcom/alibaba/fastjson/serializer/a0;->a([Lcom/alibaba/fastjson/serializer/a0;)I

    move-result v4

    invoke-interface {v1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    if-eqz v5, :cond_31

    invoke-interface {v1}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    if-eqz v14, :cond_32

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_32

    goto :goto_1c

    :cond_31
    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    :cond_32
    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move v6, v2

    move v6, v2

    move v6, v2

    move v6, v2

    move v7, v4

    move v7, v4

    move v7, v4

    goto :goto_1b

    :cond_33
    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    goto :goto_1b

    :cond_34
    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    move-object/from16 v10, v37

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v14, p4

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v18, v16

    move-object/from16 v18, v16

    move-object/from16 v18, v16

    move-object/from16 v18, v16

    :goto_1b
    if-eqz v8, :cond_35

    invoke-virtual {v8, v0}, Lcom/alibaba/fastjson/j;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_35
    if-eqz v14, :cond_36

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_36

    :goto_1c
    move-object v12, v10

    move-object v12, v10

    move-object v12, v10

    move-object v12, v10

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    goto :goto_1d

    :cond_36
    move/from16 v4, p1

    move/from16 v4, p1

    move/from16 v4, p1

    move/from16 v4, p1

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    invoke-static {v11, v3, v4}, Lq0/d;->T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z

    move-object/from16 v2, v39

    move-object/from16 v2, v39

    move-object/from16 v2, v39

    move-object/from16 v2, v39

    invoke-static {v11, v2, v4}, Lq0/d;->T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z

    new-instance v1, Lq0/a;

    const/16 v22, 0x0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object/from16 v36, v13

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move v12, v4

    move v12, v4

    move v12, v4

    move v12, v4

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object v11, v5

    move-object v11, v5

    move-object v11, v5

    move-object/from16 v5, v22

    move-object/from16 v5, v22

    move-object/from16 v5, v22

    move-object/from16 v5, v22

    move-object/from16 v8, v29

    move-object/from16 v8, v29

    move-object/from16 v41, v9

    move-object/from16 v41, v9

    move-object/from16 v41, v9

    move-object/from16 v41, v9

    move-object/from16 v9, v18

    move-object/from16 v9, v18

    move-object/from16 v9, v18

    move-object/from16 v9, v18

    move-object v12, v10

    move-object v12, v10

    move-object v12, v10

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    invoke-direct/range {v0 .. v10}, Lq0/a;-><init>(Ljava/lang/String;Ljava/lang/reflect/Method;Ljava/lang/reflect/Field;Ljava/lang/Class;Ljava/lang/reflect/Type;IILp0/b;Lp0/b;Z)V

    move-object/from16 v10, v41

    move-object/from16 v10, v41

    move-object/from16 v10, v41

    invoke-interface {v10, v11, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1d
    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v13, p3

    move-object/from16 v13, p3

    move-object v6, v12

    move-object v6, v12

    move-object v6, v12

    move-object v6, v12

    move-object v8, v15

    move-object v8, v15

    move-object v8, v15

    move-object v8, v15

    move-object/from16 v0, v21

    move-object/from16 v0, v21

    move-object/from16 v0, v21

    move-object/from16 v0, v21

    move-object/from16 v1, v24

    move-object/from16 v1, v24

    move-object/from16 v1, v24

    move-object/from16 v2, v26

    move-object/from16 v2, v26

    move-object/from16 v2, v26

    move-object/from16 v2, v26

    move-object/from16 v3, v28

    move-object/from16 v3, v28

    move-object/from16 v3, v28

    move-object/from16 v3, v28

    move-object/from16 v7, v34

    move-object/from16 v7, v34

    move-object/from16 v7, v34

    move-object/from16 v7, v34

    move-object/from16 v9, v36

    move-object/from16 v9, v36

    move-object/from16 v9, v36

    move/from16 v12, p1

    move/from16 v12, p1

    move/from16 v12, p1

    move/from16 v12, p1

    move-object/from16 v15, p8

    move-object/from16 v15, p8

    move-object/from16 v15, p8

    goto/16 :goto_3

    :cond_37
    move-object v12, v6

    move-object v12, v6

    move-object v12, v6

    move-object v12, v6

    move-object/from16 v34, v7

    move-object/from16 v34, v7

    move-object/from16 v34, v7

    move-object/from16 v34, v7

    move-object v15, v8

    move-object v15, v8

    move-object v15, v8

    move-object v15, v8

    const/16 v19, 0x0

    const/16 v25, 0x1

    new-instance v0, Ljava/util/ArrayList;

    array-length v1, v15

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    array-length v1, v15

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    :goto_1e
    if-ge v4, v1, :cond_3b

    aget-object v2, v15, v4

    invoke-virtual {v2}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v3

    and-int/lit8 v3, v3, 0x8

    if-eqz v3, :cond_38

    goto :goto_1f

    :cond_38
    invoke-virtual {v2}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v5, "t0$soh"

    const-string v5, "$h0tos"

    const-string/jumbo v5, "this$0"

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_39

    goto :goto_1f

    :cond_39
    invoke-virtual {v2}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v3

    and-int/lit8 v3, v3, 0x1

    if-eqz v3, :cond_3a

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3a
    :goto_1f
    add-int/lit8 v4, v4, 0x1

    goto :goto_1e

    :cond_3b
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v1

    :goto_20
    if-eqz v1, :cond_3f

    move-object/from16 v2, v34

    move-object/from16 v2, v34

    move-object/from16 v2, v34

    if-eq v1, v2, :cond_3f

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v3

    array-length v4, v3

    move/from16 v5, v19

    move/from16 v5, v19

    move/from16 v5, v19

    move/from16 v5, v19

    :goto_21
    if-ge v5, v4, :cond_3e

    aget-object v6, v3, v5

    invoke-virtual {v6}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v7

    and-int/lit8 v7, v7, 0x8

    if-eqz v7, :cond_3c

    goto :goto_22

    :cond_3c
    invoke-virtual {v6}, Ljava/lang/reflect/Field;->getModifiers()I

    move-result v7

    and-int/lit8 v7, v7, 0x1

    if-eqz v7, :cond_3d

    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3d
    :goto_22
    add-int/lit8 v5, v5, 0x1

    goto :goto_21

    :cond_3e
    invoke-virtual {v1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v1

    move-object/from16 v34, v2

    move-object/from16 v34, v2

    goto :goto_20

    :cond_3f
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_23
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_47

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    check-cast v3, Ljava/lang/reflect/Field;

    if-eqz p6, :cond_40

    invoke-virtual {v3, v12}, Ljava/lang/reflect/Field;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v0

    check-cast v0, Lp0/b;

    move-object v9, v0

    move-object v9, v0

    goto :goto_24

    :cond_40
    move-object/from16 v9, v16

    move-object/from16 v9, v16

    move-object/from16 v9, v16

    move-object/from16 v9, v16

    :goto_24
    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v9, :cond_43

    invoke-interface {v9}, Lp0/b;->serialize()Z

    move-result v1

    if-nez v1, :cond_41

    goto :goto_23

    :cond_41
    invoke-interface {v9}, Lp0/b;->ordinal()I

    move-result v1

    invoke-interface {v9}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v2

    invoke-static {v2}, Lcom/alibaba/fastjson/serializer/a0;->a([Lcom/alibaba/fastjson/serializer/a0;)I

    move-result v2

    invoke-interface {v9}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-eqz v4, :cond_42

    invoke-interface {v9}, Lp0/b;->name()Ljava/lang/String;

    move-result-object v0

    :cond_42
    move v6, v1

    move v6, v1

    move v6, v1

    move v6, v1

    move v7, v2

    move v7, v2

    move v7, v2

    move v7, v2

    goto :goto_25

    :cond_43
    move/from16 v6, v19

    move/from16 v6, v19

    move/from16 v6, v19

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_25
    if-eqz v14, :cond_44

    invoke-interface {v14, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_44

    goto :goto_23

    :cond_44
    move-object/from16 v13, p8

    move-object/from16 v13, p8

    if-eqz v13, :cond_45

    invoke-virtual {v13, v0}, Lcom/alibaba/fastjson/j;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_45
    move-object v15, v0

    move-object v15, v0

    move-object v15, v0

    move-object v15, v0

    invoke-interface {v10, v15}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_46

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    invoke-static {v12, v3, v8}, Lq0/d;->T(Ljava/lang/Class;Ljava/lang/reflect/Member;I)Z

    new-instance v5, Lq0/a;

    const/4 v2, 0x0

    const/16 v18, 0x0

    const/16 v20, 0x0

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    move-object/from16 v42, v5

    move-object/from16 v42, v5

    move-object/from16 v42, v5

    move-object/from16 v42, v5

    move-object/from16 v5, v18

    move-object/from16 v5, v18

    move-object/from16 v5, v18

    move-object/from16 v5, v18

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object v11, v10

    move-object v11, v10

    move-object v11, v10

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    invoke-direct/range {v0 .. v10}, Lq0/a;-><init>(Ljava/lang/String;Ljava/lang/reflect/Method;Ljava/lang/reflect/Field;Ljava/lang/Class;Ljava/lang/reflect/Type;IILp0/b;Lp0/b;Z)V

    move-object/from16 v0, v42

    move-object/from16 v0, v42

    move-object/from16 v0, v42

    move-object/from16 v0, v42

    invoke-interface {v11, v15, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_26

    :cond_46
    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object/from16 p2, v11

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    move-object/from16 v12, p0

    move-object v11, v10

    move-object v11, v10

    move-object v11, v10

    :goto_26
    move-object v10, v11

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    move-object/from16 v11, p2

    move-object/from16 v11, p2

    move-object/from16 v11, p2

    move-object/from16 v11, p2

    goto/16 :goto_23

    :cond_47
    move-object v11, v10

    move-object v11, v10

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p3, :cond_4a

    invoke-interface/range {p3 .. p3}, Lp0/c;->orders()[Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_4b

    array-length v2, v1

    invoke-interface {v11}, Ljava/util/Map;->size()I

    move-result v3

    if-ne v2, v3, :cond_4b

    array-length v2, v1

    move/from16 v4, v19

    move/from16 v4, v19

    :goto_27
    if-ge v4, v2, :cond_49

    aget-object v3, v1, v4

    invoke-interface {v11, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_48

    move/from16 v5, v19

    move/from16 v5, v19

    move/from16 v5, v19

    goto :goto_28

    :cond_48
    add-int/lit8 v4, v4, 0x1

    goto :goto_27

    :cond_49
    move/from16 v5, v25

    move/from16 v5, v25

    move/from16 v5, v25

    move/from16 v5, v25

    :goto_28
    move v4, v5

    move v4, v5

    goto :goto_29

    :cond_4a
    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    move-object/from16 v1, v16

    :cond_4b
    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    :goto_29
    if-eqz v4, :cond_4c

    array-length v2, v1

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    move/from16 v4, v19

    :goto_2a
    if-ge v4, v2, :cond_4e

    aget-object v3, v1, v4

    invoke-interface {v11, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lq0/a;

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_2a

    :cond_4c
    invoke-interface {v11}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lq0/a;

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2b

    :cond_4d
    if-eqz p5, :cond_4e

    invoke-static {v0}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    :cond_4e
    return-object v0
.end method

.method public static y(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x6

    and-int/2addr v4, v3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-le v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    aget-char v0, p0, v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Character;->toLowerCase(C)C

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-char v0, p0, v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([C)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p0
.end method

.method public static z(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne p0, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne p0, v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne p0, v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ne p0, v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-ne p0, v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 p0, 0x0

    or-int/2addr v3, p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne p0, v0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne p0, v0, :cond_6

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne p0, v0, :cond_7

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 p0, 0x30

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0

    :cond_7
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0
.end method
