.class public Lq0/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/ParameterizedType;


# instance fields
.field private final a:[Ljava/lang/reflect/Type;

.field private final b:Ljava/lang/reflect/Type;

.field private final c:Ljava/lang/reflect/Type;


# direct methods
.method public constructor <init>([Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    iput-object p1, p0, Lq0/c;->a:[Ljava/lang/reflect/Type;

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p2, p0, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p3, p0, Lq0/c;->c:Ljava/lang/reflect/Type;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "/@s~@~ ~ ~ yK@@@o@n~@~~~@b ~@.o @~~  ~@/~@~Mi oob@@Sl@t~lsi ~ d~ @@~rumabfv c~i  ~41  @f- ~o@t@o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne p0, p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eq v2, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_2

    :cond_1
    const/4 v5, 0x5

    check-cast p1, Lq0/c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, p0, Lq0/c;->a:[Ljava/lang/reflect/Type;

    const/4 v5, 0x7

    const/4 v4, 0x7

    iget-object v3, p1, Lq0/c;->a:[Ljava/lang/reflect/Type;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v2, v3}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    return v1

    :cond_2
    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v2, p0, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p1, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-nez v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v2, p1, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v2, :cond_4

    :goto_0
    const/4 v4, 0x3

    const/4 v5, 0x5

    return v1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v2, p0, Lq0/c;->c:Ljava/lang/reflect/Type;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object p1, p1, Lq0/c;->c:Ljava/lang/reflect/Type;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez p1, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_1

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x6

    move v0, v1

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v4, 0x3

    const/4 v5, 0x5

    return v0

    :cond_7
    :goto_2
    const/4 v5, 0x2

    return v1
.end method

.method public getActualTypeArguments()[Ljava/lang/reflect/Type;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lq0/c;->a:[Ljava/lang/reflect/Type;

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-object v0
.end method

.method public getOwnerType()Ljava/lang/reflect/Type;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v2, 0x2

    return-object v0
.end method

.method public getRawType()Ljava/lang/reflect/Type;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lq0/c;->c:Ljava/lang/reflect/Type;

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-object v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lq0/c;->a:[Ljava/lang/reflect/Type;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    move v0, v1

    move v0, v1

    const/4 v4, 0x2

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v2, p0, Lq0/c;->b:Ljava/lang/reflect/Type;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    move v2, v1

    move v2, v1

    const/4 v4, 0x0

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/2addr v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lq0/c;->c:Ljava/lang/reflect/Type;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0
.end method
