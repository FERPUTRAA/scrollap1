.class public final Lm0/a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lm0/a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nProcessLock.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ProcessLock.kt\nandroidx/sqlite/util/ProcessLock\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,104:1\n1#2:105\n*E\n"
.end annotation


# static fields
.field public static final e:Lm0/a$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final f:Ljava/lang/String; = "SupportSQLiteLock"
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final g:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/concurrent/locks/Lock;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field private final a:Z

.field private final b:Ljava/io/File;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final c:Ljava/util/concurrent/locks/Lock;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private d:Ljava/nio/channels/FileChannel;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lm0/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lm0/a$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    sput-object v0, Lm0/a;->e:Lm0/a$a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v0, Lm0/a;->g:Ljava/util/Map;

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/File;Z)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/io/File;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "anem"

    const-string v0, "aemn"

    const/4 v3, 0x4

    const-string/jumbo v0, "mnea"

    const-string/jumbo v0, "name"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean p3, p0, Lm0/a;->a:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p3, Ljava/io/File;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "ckl."

    const-string/jumbo v1, "lck."

    const-string/jumbo v1, "l.ck"

    const-string v1, ".lck"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {p3, p2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 p3, 0x0

    move v3, p3

    :goto_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p3, p0, Lm0/a;->b:Ljava/io/File;

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object p2, Lm0/a;->e:Lm0/a$a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p2, p1}, Lm0/a$a;->a(Lm0/a$a;Ljava/lang/String;)Ljava/util/concurrent/locks/Lock;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object p1, p0, Lm0/a;->c:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method

.method public static final synthetic a()Ljava/util/Map;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "vos d@yrtu@ ~  o -.fi  @~nosf ~a~l~ot1  @i@b@ ~@@@~@@@ @b@/~ bl4~@ ~M@/~ m ~@c@o@K~ ~~~~Soi@~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lm0/a;->g:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static synthetic c(Lm0/a;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v0, 0x4

    const/4 v0, 0x2

    iget-boolean p1, p0, Lm0/a;->a:Z

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lm0/a;->b(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final b(Z)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lm0/a;->c:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p1, p0, Lm0/a;->b:Ljava/io/File;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance p1, Ljava/io/FileOutputStream;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lm0/a;->b:Ljava/io/File;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/nio/channels/FileChannel;->lock()Ljava/nio/channels/FileLock;

    const/4 v3, 0x4

    iput-object p1, p0, Lm0/a;->d:Ljava/nio/channels/FileChannel;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    new-instance p1, Ljava/io/IOException;

    const/4 v3, 0x1

    const-string/jumbo v0, "o tmcroNdrswa rsoipdc. iydelvek"

    const-string/jumbo v0, "o svwl oryordNcast keired.pdioc"

    const/4 v3, 0x5

    const-string v0, "No lock directory was provided."

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lm0/a;->d:Ljava/nio/channels/FileChannel;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v0, "tmriotpQuSkSLocLp"

    const-string/jumbo v0, "urLmcktpotSiQSLop"

    const/4 v3, 0x3

    const-string v0, "LQLuobokpSiepttcS"

    const-string v0, "SupportSQLiteLock"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "o l biu okfalr.lntaeUcbeg"

    const-string v1, "Unable to grab file lock."

    const/4 v3, 0x2

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public final d()V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lm0/a;->d:Ljava/nio/channels/FileChannel;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lm0/a;->c:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
