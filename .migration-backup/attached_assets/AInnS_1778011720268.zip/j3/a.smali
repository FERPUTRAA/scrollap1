.class public Lj3/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lj3/a$a;
    }
.end annotation

.annotation build Lp2/a;
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "MTPushPrivatesApi"
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static b:I = 0x1b3
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static c:Ljava/lang/String; = "4.3.5"
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final d:B = 0x0t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final e:B = 0x1t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final f:B = 0x2t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final g:B = 0x3t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final h:B = 0x4t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final i:B = 0x5t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final j:B = 0x7t
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final k:B = 0x8t
    .annotation build Lp2/a;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static A(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s  ~K~~bS@y@ @b@ - ~ol@~ ~s~~lM ~@u~1/@@ @ i~n~~~ocro/oi@~@~d~ ~i@f o~@ 4vm@@@t@   ~~@@at~.fbo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    const-string/jumbo p0, "psamersTsuPvhAMPi"

    const-string p0, "iAsvsurePhiMTsPpa"

    const/4 v3, 0x1

    const-string/jumbo p0, "suaeoMrvtpAsPiTPi"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const-string p1, "ciaiibcttele amoBNe//kl foi ntnenp t uosnstcee h e,ttaxgdbcc"

    const-string p1, ",tnmt k ioaou ialnlceBdat gNibtcesnehcl/ece eciptn et xost/f"

    const/4 v3, 0x3

    const-string p1, "etk t/uneaotiue,N o iasle  tcleicnBeinltc btndep/cgtofcasa x"

    const-string/jumbo p1, "setNotificationBadge context can\'t be null, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "iodntaepotaoibni_f"

    const-string/jumbo v1, "iib_ofttndaioenago"

    const/4 v3, 0x5

    const-string v1, "acfgi_naqboeiontid"

    const-string/jumbo v1, "notification_badge"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 p1, 0xf2d

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public static B(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "ptsMhiveusrTiAsPa"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p0, "est eboutltn utioactCaxiolhnnfpceNbnicacnicl to e e ,/tt ks/"

    const/4 v3, 0x1

    const-string p0, "anumso aNt,abetC  lcnekento nplt c/cfot heixiictleutsec/otni"

    const-string/jumbo p0, "setNotificationCount context can\'t be null, please check it"

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-gez p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string p0, "aliNon soan lnues0toCl t/tmctuctsi,ctce k   cahao oihtp/nuefant"

    const-string p0, "ailteCu N tcpha nmkn  t,tntsouhiotoe/t li /slcatai n0asefcoucnc"

    const/4 v3, 0x3

    const-string p0, "ctnatbstocfsn oe ,lpcahel0aikl  ia saCtNo intto tmncih/tcuun e/"

    const-string/jumbo p0, "setNotificationCount count can\'t small than 0, please check it"

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v2, 0x4

    move v3, v2

    if-nez p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string p0, "a,ethauau0ttenccn now/qe c tsaohitpsituc oo pieetilcfi N/u  lkn"

    const-string/jumbo p0, "kno ntap  uqaeNchit/etseo e0iacclsoCp ,wnthat iceofu ii ntt/clu"

    const/4 v3, 0x2

    const-string p0, "/tqs tnpscwueekc  t ttceihnucinenNao eooo fptl,ttia  aChli/a0uc"

    const-string/jumbo p0, "setNotificationCount count can\'t equal with 0, please check it"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_3

    const/4 v3, 0x6

    return-void

    :cond_3
    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    const-string/jumbo v1, "onofctqnqiatonici_"

    const-string v1, "ctnanoooq_ifnictit"

    const/4 v3, 0x5

    const-string v1, "_fstainnoiocictont"

    const-string/jumbo v1, "notification_count"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/16 p1, 0xf2f

    const/4 v3, 0x4

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method public static C(Landroid/content/Context;ILcom/engagelab/privates/push/api/NotificationLayout;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "tisihsAeausTvPpMP"

    const/4 v3, 0x2

    const-string/jumbo v0, "sphmPisiMuaTtAevP"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p0, "eieeolo N/ltnatu,n ao yoetsft/ikntt tahcmee xLcbcnlcpsuai i o"

    const-string p0, "ecLmeeohla usciilisy/tiot, ef tnc cnt/o  anxltnute kapattoNeb"

    const/4 v3, 0x2

    const-string/jumbo p0, "setNotificationLayout context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p2, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const-string p0, "acobo yaaeaocl/e ho,ffo istciuty/pttulntn cnitoiuk tLnLcteen iatiileNaos"

    const/4 v3, 0x2

    const-string p0, "ane,cbaaiu t iaocipao ttc neNncityoelhtltfLi/koenlatoiu eioufsLycs n btt"

    const-string/jumbo p0, "setNotificationLayout notificationLayout can\'t be null, please check it"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "di"

    const-string v1, "di"

    const/4 v3, 0x4

    const-string/jumbo v1, "id"

    const-string/jumbo v1, "id"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x0

    const-string/jumbo p1, "ioctfbuaoiuantn_yli"

    const-string/jumbo p1, "oinatboayf_tiiltcun"

    const/4 v3, 0x0

    const-string/jumbo p1, "ioincotpaultia_onyt"

    const-string/jumbo p1, "notification_layout"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 p1, 0xf31

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public static varargs D(Landroid/content/Context;II[I)V
    .locals 5
    .annotation build Lp2/a;
    .end annotation

    const/4 v4, 0x7

    const-string v0, "PiMetTipqhuvraAPs"

    const-string/jumbo v0, "iaTPstuehvsAMrpPi"

    const/4 v4, 0x2

    const-string v0, "aisvPeuMprssiPTtA"

    const-string v0, "MTPushPrivatesApi"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string p0, " temosieeoatau l/oeip/lais tle o kiwnniht  xbchfc,nTttecetScNpc"

    const-string p0, "/senc hpnee uln kf oiTcawoNtocast/apnltbteieS oei,xht tleii cct"

    const/4 v4, 0x6

    const-string/jumbo p0, "n aooikte nSeiT/f,otoc scaheteen lhbimotNlwxsul/ ciptt caicet e"

    const-string/jumbo p0, "setNotificationShowTime context can\'t be null, please check it"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-ltz p1, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/16 v1, 0x17

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-le p1, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ltz p2, :cond_7

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-le p2, v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-le p1, p2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const-string p0, "SH oebni itoNreulnnimi/qhosaTrtw,cteokehsh f ndrb aHgouceipatnt  atieee accl"

    const-string p0, " nterc dqgengem wo,nTchuaiiir frsHbpNksal Stetti  noeic/teatoh nahoceeuHaloi"

    const/4 v4, 0x1

    const-string/jumbo p0, "setNotificationShowTime beginHour can\'t large than endHour, please check it"

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne p1, p2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string p0, "Shto eukeuonipHiaeec aa utciuntdoifecire elosw wH /gt/ aoi,ttnlsbehhrTsNmq i"

    const-string p0, "aasNthetikhgHi im sStseHwouo cilpenu/an wci/o hdractce,urTnetlfiee be ooqit "

    const/4 v4, 0x3

    const-string p0, "T dHigepoistcaaofletmtti ee/hN  t,onHnraik/ Srcce  onehihuesuocnbwawtl iueqi"

    const-string/jumbo p0, "setNotificationShowTime beginHour can\'t equal with endHour, please check it"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    array-length v1, p3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x7

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-le v1, v2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string p0, "em etmeTqnk0chathica ewnbSttoyi.spf,osi c ektne~eDwi ge leesesl7wNumttaih"

    const-string/jumbo p0, "thwmecsse ikop. ikSnboeotef ei y7e m0isasln~ugiN,eeTtntDwehcehtclw aettam"

    const/4 v4, 0x0

    const-string/jumbo p0, "s.scShltpo,mne iei~ tNefsikDbmwnTko lcn7ees0wategtoa e iteyeahweuictets  "

    const-string/jumbo p0, "setNotificationShowTime weekDays.length must between 0~7, please check it"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_6

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    return-void

    :cond_6
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "noomg_ehui"

    const-string v1, "_rneouohgi"

    const/4 v4, 0x3

    const-string v1, "_birognhou"

    const-string v1, "begin_hour"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p1, "u_obnbeh"

    const-string/jumbo p1, "no_dhbeu"

    const-string p1, "droeu_uh"

    const-string p1, "end_hour"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string p1, "ady"

    const-string p1, "ady"

    const/4 v4, 0x6

    const-string/jumbo p1, "yad"

    const-string p1, "day"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p3}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 p1, 0xf35

    const/4 v4, 0x1

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void

    :cond_7
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p0, "0nw2koupc l,uwtseaosat3r inett  deinNbepihTmh~Hei ief tteecSu oces"

    const-string/jumbo p0, "nf3ewoulteumid b  Nreec,sii~eoict2kp uee HnSsmteo saw hn0htaettciT"

    const/4 v4, 0x2

    const-string/jumbo p0, "tam2Ntkiqhn3mbnS,w iu isde  tlesne aH~oheowT ocetteiofuecr0sipete "

    const-string/jumbo p0, "setNotificationShowTime endHour must between 0~23, please check it"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :cond_8
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string p0, "e sshi~eaci h0Nef,oecuktlmeowbeii2icneuroHaeTb o eStm s tginppt nwt3"

    const-string/jumbo p0, "tt ouispwh mSte e0N b2en enpttbenmcaeaoiiuegrsH~ oTc,e3filikio ewcth"

    const/4 v4, 0x3

    const-string/jumbo p0, "weimonnit0  elethio b2euHfr,SseNniaihe~tsaots Tokccct3em imwg eutpb "

    const-string/jumbo p0, "setNotificationShowTime beginHour must between 0~23, please check it"

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    return-void
.end method

.method public static E(Landroid/content/Context;IIII)V
    .locals 5
    .annotation build Lp2/a;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, "PuAsoiiTstqPverMa"

    const-string/jumbo v0, "itareThvqPssuPMAi"

    const/4 v4, 0x0

    const-string/jumbo v0, "iisMvbTaAtrePuhsp"

    const-string v0, "MTPushPrivatesApi"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo p0, "tcisa uesuxee /clfcec/eltnce nonieliahnoantT  it tNcbSi,mli ekptto"

    const-string/jumbo p0, "setNotificationSilenceTime context can\'t be null, please check it"

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ltz p1, :cond_9

    const/4 v3, 0x0

    move v4, v3

    const/16 v1, 0x17

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-le p1, v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto/16 :goto_3

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    if-ltz p2, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/16 v2, 0x3b

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-le p2, v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto/16 :goto_2

    :cond_2
    if-ltz p3, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-le p3, v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto/16 :goto_1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ltz p4, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-le p4, v2, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x3

    const-string/jumbo v1, "nriousephb"

    const-string/jumbo v1, "nbseihurgo"

    const/4 v4, 0x4

    const-string/jumbo v1, "rnoiue_bqg"

    const-string v1, "begin_hour"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string p1, "enstnmgmu_ii"

    const-string p1, "gutmi_niebnm"

    const/4 v4, 0x7

    const-string/jumbo p1, "nuimne_bmegi"

    const-string p1, "begin_minute"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p1, "d_roohoe"

    const-string p1, "_hreodno"

    const/4 v4, 0x1

    const-string p1, "end_hour"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p1, p3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string p1, "eedmtbbi_u"

    const-string/jumbo p1, "n_ueebmidt"

    const/4 v4, 0x4

    const-string/jumbo p1, "miudt_unen"

    const-string p1, "end_minute"

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1, p4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/16 p1, 0xf33

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x2

    return-void

    :cond_6
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string p0, "ait9mwdps,btitun  eT u0soceNfn5aSeel~tnsenece  eteiectciilhi Me kopuntm"

    const-string p0, "Mueeltu tasd0 Snneci,icili Netosbcnesot95ie mntteaw~pTe femteue hinkce "

    const/4 v4, 0x7

    const-string/jumbo p0, "see~e iuqt iSmtki enailocpiMi50cai sene unencemdNbtt,Tf telot ns9ecweht"

    const-string/jumbo p0, "setNotificationSilenceTime endMinute must between 0~59, please check it"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :cond_7
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo p0, "oesernsSfeTcH,intlk3nNmuicei e~siiubttoetd ow  heip 2p  etme0accslnet"

    const-string/jumbo p0, "oa nfiwptnk e tlitud~b,se0ecsmce or2eNthiptneiTecuHnleoiie e3tSm s ec"

    const/4 v4, 0x1

    const-string p0, "e0cm sefuesetnta itkmen ipN2llrui oideoc3eiemob~,hTieStncew ttHensca "

    const-string/jumbo p0, "setNotificationSilenceTime endHour must between 0~23, please check it"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    return-void

    :cond_8
    :goto_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string p0, "i05eoeneMntt~nSwlt a9iigct,tms oeeuNcusihbke iemp cntcsiq  e Teeafieoblit"

    const-string p0, "Nineehe q0stt tiecisbiptwMcaoelumae9imT  c~bit5lene fgtne iecnsSuee,oti k"

    const/4 v4, 0x5

    const-string/jumbo p0, "ueTiabeobiueg tics pniiemn,tmtenMNoceftbcne  Set h9ln~te5s etiwi las0cike"

    const-string/jumbo p0, "setNotificationSilenceTime beginMinute must between 0~59, please check it"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_9
    :goto_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo p0, "u sSs usntTeuemiwbot2rek 0in meoclltiHo ceeiefeeeb t,ccNn a~nigieth3pia"

    const-string/jumbo p0, "setNotificationSilenceTime beginHour must between 0~23, please check it"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public static F(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p0, "stsivpTMuaAsrhePi"

    const-string p0, "aisevAhpTispPPrtM"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p1, " tcastucqeneinpcli,oewoNackt/h ahlcxbio  nnl tt tef/ ieo"

    const-string/jumbo p1, "showNotification context can\'t be null, please check it"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "seemsga"

    const-string/jumbo v1, "sessgae"

    const-string/jumbo v1, "message"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p1, "g_imeolmmtesi"

    const-string/jumbo p1, "sietomelmgai_"

    const/4 v3, 0x4

    const-string/jumbo p1, "tma_ogssieeim"

    const-string/jumbo p1, "message_limit"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p1, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 p1, 0xf37

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public static G(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "vepbobAroCsPanTMtim"

    const-string v0, "MArpnbTetvsaCmioPom"

    const/4 v3, 0x4

    const-string v0, "MpTsnmuimoroCatAive"

    const-string v0, "MTCommonPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo p0, "na aintpfcOop eweSetctete ncfnulfh/ ox t, ctec kr/elnhuGlecsi"

    const-string/jumbo p0, "turnOffGeofenceSwitch context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p0, "lccOe  rqoclsn oechnosiemwa   eebdsiefufnanuridftlpuhG"

    const-string p0, "OuesdcubGfcnfaf h rnrociohlnnpelc lse omde eittseawiu "

    const/4 v3, 0x5

    const-string/jumbo p0, "mis iltucfle dfue n erp ewhohboencdsOcr SlafesstcnanGi"

    const-string/jumbo p0, "turnOffGeofenceSwitch should be called in main process"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/16 v0, 0xed5

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public static H(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string p0, "TaemsspMuviirPptP"

    const-string/jumbo p0, "irepaTspPMihvPust"

    const/4 v3, 0x6

    const-string p0, "eputoMrPAviPssTah"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "cqt eb e,ec np/hPe o rbuuntlletnaa /flhfuOccsstnx i"

    const-string/jumbo v0, "necPuelhqpeoxfe a stutn  snchtlb/ic/tfertc , lunO a"

    const/4 v3, 0x4

    const-string v0, " etnr ueh,abesnf ke lctot P alOxl/nf uchcntsu/ciptu"

    const-string/jumbo v0, "turnOffPush context can\'t be null, please check it"

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v0, 0xf3a

    const/4 v3, 0x1

    const/4 v1, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public static I(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v0, "toAmrappmTMCvoPnsis"

    const-string v0, "anseMsmPtvAoTmoCrpi"

    const/4 v3, 0x7

    const-string/jumbo v0, "omontimpqrTAPiaCvsM"

    const-string v0, "MTCommonPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string p0, "e scennpc iowec ae  stiekth/lluntncn eaGxcbSrOf /ctohlm,ntee"

    const-string p0, "aiimSfneuec ahlrecwepl,xncteton   lseeu Otc  /eGnctnhko/ctbn"

    const/4 v3, 0x1

    const-string/jumbo p0, "kiemeG lnncnuetnweo pcu/btlnt/iaeceS hecc r, lf htntxsoOaect"

    const-string/jumbo p0, "turnOnGeofenceSwitch context can\'t be null, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string p0, "e o oectrbdio iunlh ln GmoeneesOauStcnshdoseacr cilfw"

    const-string p0, "GcOoorepwieli cche tena dfsrelbnsohdaisnut  Somlc neu"

    const/4 v3, 0x1

    const-string p0, "Srpfibleo enelreoaotd bcwcs cnmisG i dceennOhhalsntu "

    const-string/jumbo p0, "turnOnGeofenceSwitch should be called in main process"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v0, 0xed6

    const/4 v3, 0x2

    const/4 v1, 0x0

    or-int/2addr v2, v1

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public static J(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p0, "bPMresuiAsiautvPT"

    const-string p0, "PirPTbpivauesMstA"

    const-string/jumbo p0, "vTPMhrPpApsaisuie"

    const-string p0, "MTPushPrivatesApi"

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    const-string/jumbo v0, "tlann /cqsltbuelh o seu tpc xu ttre cuc,nOk/nPiena"

    const-string/jumbo v0, "lnc pcueus lt ten xbec//liO httuanPaou nsr tnk,ece"

    const/4 v3, 0x3

    const-string v0, "ehselpe se t,un lO nub/x/k ur cscthPceclt tinnanot"

    const-string/jumbo v0, "turnOnPush context can\'t be null, please check it"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/16 v0, 0xf3b

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    return-void
.end method

.method public static varargs K(Landroid/content/Context;I[Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, "ahsmuspArtipievPP"

    const-string v0, "ePisivhpsPaAtrTup"

    const/4 v3, 0x0

    const-string v0, "MavToiPiesphAtsPr"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const-string/jumbo p0, "pTlnxbteceneaeuluteb hci/talepc,ksdn  qtc at  /ag"

    const-string p0, "dp legciqb c eltnceee nuttn p t/aaalhextT/,sc auk"

    const/4 v3, 0x7

    const-string p0, "cedtagu/alk,epuxacT/ b as chit eupllneotn ec ntte"

    const-string/jumbo p0, "updateTag context can\'t be null, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string p0, "gkc/eehpu itbqunaeecatepe,d/tc T s0   pesaslcna"

    const-string p0, ",dspe 0eeae silgutteaakhu n/ccqT n  ptcc ba/see"

    const/4 v3, 0x0

    const-string p0, "c eetp eqs u lne/g/ptatea skeu nahcdcc,T e0qiba"

    const-string/jumbo p0, "updateTag sequence can\'t be 0, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x5

    if-nez p2, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo p0, "s sutab Tnee,tcl/ tg tg  kca/nl apipeaeuhcadm"

    const-string p0, " d/mTl hunetgc  lpenaabuetg aac sacl kt/,ptei"

    const-string p0, "/bimpaecl na ke g s,aculuhngtatea/eTdltepc   "

    const-string/jumbo p0, "updateTag tag can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    array-length v1, p2

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string p0, "esg,o aeoe tp tatuel// dbhma kgTinceeat  yccpp"

    const-string/jumbo p0, "pspaoet cy m/ghl teentaT,aiadcecbuek atg  pe/ "

    const/4 v3, 0x4

    const-string/jumbo p0, "uycmebt nha tepeTte,tp dec kp tg /acglaeba/si "

    const-string/jumbo p0, "updateTag tag can\'t be empty, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    return-void

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-void

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "eeubecus"

    const-string/jumbo v1, "uncsebee"

    const/4 v3, 0x1

    const-string/jumbo v1, "qenuecsp"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo p1, "tag"

    const-string p1, "gta"

    const/4 v3, 0x5

    const-string p1, "gat"

    const-string/jumbo p1, "tag"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 p1, 0xf93

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public static L(Landroid/content/Context;ILjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo v0, "prsiiPusquTeAvtaP"

    const-string/jumbo v0, "svtMpruasPPieAiuT"

    const/4 v3, 0x0

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string p0, " t,epdkphNei tlieelbou/bnnMaosb  l mcltnx aceeprloatuue c/"

    const/4 v3, 0x6

    const-string p0, " esectis amrbx  bcnectkltapollne/peeoalNdtcu b Mehuuinl,/ "

    const-string/jumbo p0, "uploadMobileNumber context can\'t be null, please check it"

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string p0, "eaembcNo/baubh,io c delyeboutMs p nr ealumpeqre/Nmit mkemll ipbc"

    const-string p0, "d cnb  bq,pl eoboluru/aeyeme ieehaeNpkbacictm/io r mMsNtllmebupe"

    const/4 v3, 0x4

    const-string p0, "/ip oe/eNclkambe  Myrsuhlebltmidenlboeoc,poui uNebc atbrtm mapee"

    const-string/jumbo p0, "uploadMobileNumber mobileNumber can\'t be empty, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void

    :cond_2
    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v1, "qeucebns"

    const-string v1, "cessneuq"

    const/4 v3, 0x7

    const-string/jumbo v1, "qsecunue"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo p1, "umilmbopbNme"

    const-string/jumbo p1, "ibmmolNeubrm"

    const/4 v3, 0x3

    const-string p1, "eNmiblmeqbou"

    const-string/jumbo p1, "mobileNumber"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 p1, 0xf8a

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x1

    return-void
.end method

.method public static M(Landroid/content/Context;BLjava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p0, "hosPvspuaPMAtisTi"

    const-string p0, "PePMoasTvusithpAi"

    const/4 v2, 0x2

    const-string p0, "aMsmiethPATpsrPui"

    const-string p0, "MTPushPrivatesApi"

    const/4 v2, 0x6

    const-string p1, " pseab   /nenlam nfccx/eouintee btTtoacotlkoPe,hnrct ll"

    const-string/jumbo p1, "t c/o m  b,isn l/npeetntxacoutok o TfonahaeclrtllekcePn"

    const-string/jumbo p1, "onPlatformToken context can\'t be null, please check it"

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->e(B)Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->h(Ljava/lang/String;)Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->g(Ljava/lang/String;)Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p2, Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo p3, "sagsubm"

    const-string/jumbo p3, "ssmageu"

    const/4 v2, 0x1

    const-string p3, "assegmu"

    const-string/jumbo p3, "message"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p2, p3, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 p1, 0xf8b

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static varargs a(Landroid/content/Context;I[Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "iiaTPAMputrehpPss"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x1

    const/4 v2, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p0, "klaot pnq nceah   deet,/xsccautip /dglecnle ab"

    const-string p0, "ealgl npaeab, / t dctc uonct/  pedlxekhiatsnce"

    const/4 v3, 0x5

    const-string/jumbo p0, "olsthcldint/aet sdpncbnaceet eagec ,l au / xk "

    const-string p0, "addTag context can\'t be null, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const-string p0, "ce/msenagsaat uetkcdpqch elb eTq,iad e c  n/"

    const-string/jumbo p0, "uctkd,ncqdqc a hitaeegn l  sa a es/ebep/eTec"

    const/4 v3, 0x6

    const-string/jumbo p0, "pu /oa heeecse ndqg/   eedn,lek Tastaabiccct"

    const-string p0, "addTag sequence can\'t be 0, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p2, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const-string p0, "ct acbed einbhsTda pucala lsng e/k,/ae lgt"

    const-string p0, "acs n e/th ap t nbikTldle agcdusagc, eae/l"

    const/4 v3, 0x2

    const-string p0, " n gcluudgaepdTecc bka  et ,aatel/i tlahsn"

    const-string p0, "addTag tag can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    array-length v1, p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p0, "g//iea pcce,skahcpd mmna adgteeeltt byp  T "

    const-string/jumbo p0, "nctmTk be at ageyldp/tedeca ,aeash   pgicm/"

    const/4 v3, 0x3

    const-string p0, "a edsbckqh agpaeg,a ny/ti tat  m cpceelTe/t"

    const-string p0, "addTag tag can\'t be empty, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_4

    const/4 v3, 0x6

    return-void

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "oescueqs"

    const-string v1, "cueeonsq"

    const/4 v3, 0x3

    const-string/jumbo v1, "qeemeusn"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const-string p1, "gat"

    const-string p1, "agt"

    const/4 v3, 0x6

    const-string p1, "gat"

    const-string/jumbo p1, "tag"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/16 p1, 0xf95

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public static b(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p0, "bipvoAihurastMsPe"

    const-string/jumbo p0, "ueiPsbPhMstivarpA"

    const/4 v3, 0x0

    const-string p0, "hpiTAbauevtPirsPM"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p1, "cellesue ntnas/a,ilcpl/ aAettk r healcb ctci u uxn"

    const-string/jumbo p1, "taaia ubt,c//lncpceAcnhk l io lt tcrl e eexlsansue"

    const/4 v3, 0x1

    const-string p1, "elseeobpu/ cet aaltlp eacc kthxitnncasnecr/,A  ll "

    const-string p1, "clearAlias context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v1, "qcneeupq"

    const-string/jumbo v1, "ucnqeeep"

    const/4 v3, 0x6

    const-string v1, "esseqenc"

    const-string/jumbo v1, "sequence"

    const/4 v2, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 p1, 0xf8d

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x5

    move v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const-string/jumbo p0, "uMtmiTvhpriAsPqaP"

    const-string/jumbo p0, "ihiMtArpqvasuPTPs"

    const/4 v3, 0x4

    const-string p0, "MTPushPrivatesApi"

    const-string v0, "etsoiesc,n txtencfNe  cbp /naccenotaloalir ukl/tichia lte"

    const/4 v3, 0x0

    const-string/jumbo v0, "tcpcoeuiot aceknis  tNenlriet/b,oaneccxait a ceof llnht/l"

    const-string v0, "clearNotification context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v0, 0xf36

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public static d(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string p0, "eusPibiTmMAhspvPt"

    const-string/jumbo p0, "iPvmsMpheAuPitrsT"

    const/4 v3, 0x6

    const-string/jumbo p0, "rhMtpvusueiPAPais"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string p1, ",rltlpipboto/nlanheeen aN ko xi e/seattcufe cictncc itlao"

    const-string p1, "cx/loh Ncecteici ounniie/on tok ctblafrnea, apalsc ttleet"

    const-string p1, "a ucn/ecqt  ltslafiieiNenh tkoloe c/rblnt ,ca catipneexco"

    const-string p1, "clearNotification context can\'t be null, please check it"

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "ftsboi_iy"

    const-string/jumbo v1, "y_itibfod"

    const/4 v3, 0x7

    const-string v1, "d_ymtfnio"

    const-string/jumbo v1, "notify_id"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 p1, 0xf36

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public static e(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "pMusoTvatehPiAPsi"

    const-string v0, "hsAtsuuPepaMiTvPi"

    const/4 v3, 0x4

    const-string v0, "MhpPvbiasertsPAui"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo p0, "ntinl/utoiexecc llppe/u ,aa hkitcsneen b c t"

    const-string p0, " cpunt,pbiacint  olienc xcnea etesh/ lt ek/l"

    const/4 v3, 0x0

    const-string/jumbo p0, "len etbpttt ce antnsinc pi /l, h/lkauoeecc i"

    const-string/jumbo p0, "init context can\'t be null, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 p0, 0x18c

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    sput p0, Lj3/a;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p0, "9..qq"

    const-string p0, ".9.q3"

    const/4 v3, 0x1

    const-string p0, ".3s69"

    const-string p0, "3.9.6"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object p0, Lj3/a;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "idsm fsrluVnsPOhocgoe"

    const-string/jumbo v1, "ocsdsigerl OPnhiVfsou"

    const/4 v3, 0x4

    const-string v1, "PfdOoiegsisuonolrV nh"

    const-string v1, "configOldPushVersion "

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v1, Lj3/a;->c:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p0, "eAsmiiPstvahPTupM"

    const/4 v3, 0x6

    const-string/jumbo p0, "iPieubMsPhavTAsrp"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p1, "cukaasusecnhclnpoa   hgbca/o,iLnl ePe /xlfuuceeeg  ttntgon"

    const-string p1, "aheuoehatn ksln,npaab nL ixceegcgc P/c noocsu ege/lfiutl t"

    const/4 v3, 0x2

    const-string p1, "gethk,/pl ung/xgcPntciuaccie tcaeloab alnt usfeps eneo nhL"

    const-string p1, "configPushLanguage context can\'t be null, please check it"

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v1, "uaeerbgssau_ltn_g"

    const/4 v3, 0x1

    const-string/jumbo v1, "set_user_language"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/16 p1, 0xed4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public static g(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "ushiepaPqrtiTvuAM"

    const-string v0, "TvePpiuarMPuitsAh"

    const-string v0, "MAsPtuivrspaPTise"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p0, "ct m dexctlele// cbpceAilesaotklnu  T,paaet he netll"

    const-string/jumbo p0, "l et l,pp tn eeATgkac/ab  easliuth/tlccxeecedltoe nl"

    const/4 v3, 0x1

    const-string p0, "dleooebtlentxt lln  ln,Tpe/euatcc  ace/hsliteeag k c"

    const-string p0, "deleteAllTag context can\'t be null, please check it"

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string p0, " cnaebslqlc,/k e c qatA/ebecel0uneltTd pteseehi ag"

    const-string/jumbo p0, "llea, ceq/lt nieqtsaleeTA /kcheeuscp 0 ge  tbdneac"

    const/4 v3, 0x6

    const-string p0, "ec hd u/e,0ac   tqaeseekecbtlselAl at/Tcl npiegeue"

    const-string p0, "deleteAllTag sequence can\'t be 0, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "suesencp"

    const-string v1, "eescunes"

    const/4 v3, 0x6

    const-string/jumbo v1, "qsucqeen"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 p1, 0xf91

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "MasmeAihPispPrutT"

    const-string/jumbo v0, "stamihPpsAMPTeuri"

    const/4 v3, 0x4

    const-string/jumbo v0, "iiMmThaAPsPestuvr"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string p0, "cutlonae c/eeeoolna tne f/eGehxcbstkcl ,plc oe  etiedt"

    const-string/jumbo p0, "lG/lope,n  o cicceteane et  tce/eehellksuo dttxaeebnfc"

    const/4 v3, 0x7

    const-string p0, ",clntbtl eehc seec utlneetGetnf eo cbkci/l aoex eden/a"

    const-string p0, "deleteGeofence context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p0, "/eIbdaudekeccncathG/ e pie eso enfnlcpcteboee  ,el gtmteey"

    const-string p0, "cfhe b ibtoeekltcapeteod g/ eIyndnlaGp eccece/,s eeme etne"

    const/4 v3, 0x5

    const-string p0, "ecpofttpeeme enhyt bceeen/elgeaapes fcIt  dccek,/lo n iGed"

    const-string p0, "deleteGeofence geofenceId can\'t be empty, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "di"

    const-string v1, "di"

    const/4 v3, 0x7

    const-string v1, "di"

    const-string/jumbo v1, "id"

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 p1, 0xf28

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public static varargs i(Landroid/content/Context;I[Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v0, "uirhPTAaqsMvPpeui"

    const-string v0, "hsavPruptTiAiPMeu"

    const/4 v3, 0x6

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const-string p0, "egsex ebs  acceTnthattn/tud,octepi e apl eknlc/ll"

    const-string/jumbo p0, "tt T n ppalieoectcne xg e/tdcuacehe,at ls /nklble"

    const/4 v3, 0x6

    const-string/jumbo p0, "tkhmu bx clco teatgsctca e teineedl npeleT/ anl,e"

    const-string p0, "deleteTag context can\'t be null, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo p0, "ueaao/ he0e/enetseccc  ebqenlltp tc  ekesgi,a T"

    const-string p0, "deleteTag sequence can\'t be 0, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x4

    if-nez p2, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string p0, " ctq/baluea ed/lgke tbehsl ain Tg,ec  pletenc"

    const-string p0, "ceene t/q kbTa/ph eteuita,lasgl t  cleel gcnd"

    const-string/jumbo p0, "t pc ,uebuee/tscige caalT lehenaat  tdlngk/e "

    const-string p0, "deleteTag tag can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v1, p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string p0, "detaaatpeTk,gimcbe/es nttl/ecalee s c yehgpp  "

    const-string p0, "epsea/netaphegcebi,akeT   / lys gt ettdec lamc"

    const/4 v3, 0x2

    const-string/jumbo p0, "tlteebspq  enl, ytcteca hg dtgpeTmecai a/eake "

    const-string p0, "deleteTag tag can\'t be empty, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_4
    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "uesmecqe"

    const-string v1, "ceumeeqs"

    const/4 v3, 0x7

    const-string v1, "esnmqeeu"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo p1, "tga"

    const/4 v3, 0x0

    const-string p1, "gat"

    const-string/jumbo p1, "tag"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 p1, 0xf94

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method public static j(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo p0, "oMTAotiPpsPhrauei"

    const-string/jumbo p0, "savMotTprihPeuPiA"

    const/4 v3, 0x0

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p1, " lke betuaoslnsccpebi/nl xtictthtnel bagaA  c ee"

    const-string p1, "ect cbicpeteoekAxt l  esll /ab uls anthgc/etiann"

    const/4 v3, 0x7

    const-string p1, "e c/gaucl, sehenlsoiauxccpiAtte entklnlt  e/ b t"

    const-string p1, "getAlias context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "enuqesep"

    const-string/jumbo v1, "usqneeue"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 p1, 0xf8e

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public static k(Landroid/content/Context;)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p0, "usMrAaPpqesvPpiti"

    const-string/jumbo p0, "iTsuParpetAsMviPp"

    const/4 v2, 0x5

    const-string/jumbo p0, "usshtaPTpPMeiirsA"

    const-string p0, "MTPushPrivatesApi"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "neemubntAlp pahcto iocaneeqciollttfi gsNtgos txn,pSe/oa/etii t  ckn"

    const-string v0, "egcnulesqae n/xcen fSkiooetittiittoppceh ci /oo pgtanntstbN,lcAa l "

    const/4 v2, 0x6

    const-string/jumbo v0, "xeiloei n aooigStc eelbpcinonpcogaTne l tksn,pitucoAttes act//thNt "

    const-string v0, "goToAppNotificationSettings context can\'t be null, please check it"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-static {p0}, Lo3/f;->z(Landroid/content/Context;)Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static l(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string v0, "MsTnPb4.isisvA3trit5..uiPhe "

    const-string v0, "4us3sipi n..hPttv5riMsA.eiPT"

    const/4 v3, 0x7

    const-string/jumbo v0, "iai.A uTnii.4sshvPrpet5P3.Mu"

    const-string v0, "MTPushPrivatesApi.init 4.3.5"

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "tempThipsvaAPMPiu"

    const-string/jumbo v1, "rsamAvMPeihtuipPT"

    const/4 v3, 0x7

    const-string/jumbo v1, "irveAPasqTsiuhPtp"

    const-string v1, "MTPushPrivatesApi"

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string p0, "ces,su xcaeknp ceahtn  c le b/ttniteilnilo/ "

    const-string p0, "cciuoobhee ta i ixklel atc/lcne tt/ nns,e pn"

    const/4 v3, 0x3

    const-string p0, "ehlmaun n pocn,scecetce ilt a  t/kttni /xelb"

    const-string/jumbo p0, "init context can\'t be null, please check it"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p0, " Ten bt tieephpneehafPrMsv nrlPhshtpsa sPicuioeicu a ctst osn nrerslium lchsptoeAo .iai"

    const/4 v3, 0x1

    const-string p0, "T.hrorotenp nrecoeseusaifiPmetstp ph cnn eoi  lhtol riiesnhM iaAvsaucPcalpis thtsPe us "

    const-string p0, "Please call the MTPushPrivatesApi.init function in the main process or the push process"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lq2/a;->c(Landroid/content/Context;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v1, Le3/a;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v1}, Le3/a;-><init>()V

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Li3/a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0}, Li3/a;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public static m(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, "PPiipbshMsAuTtuav"

    const-string/jumbo v0, "iatPisuAPTuvrsMph"

    const/4 v3, 0x0

    const-string/jumbo v0, "saitpeusuMPrvAPih"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string p0, "ageuk Tphpt ctl, lnalsn elepybicxceecoA  en utt/rla"

    const-string/jumbo p0, "xecuk/ pa n  tthnlr/aspeuaeec Allyel,lc ictbten oTg"

    const/4 v3, 0x1

    const-string/jumbo p0, "osullc xqqeee cli nu/ ,yeccTtln teeak/ahA lag bnttp"

    const-string/jumbo p0, "queryAllTag context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const-string/jumbo p0, "qlske0tca pe,e/ q nalyg eqanesireuct/lc sebTc  Ae"

    const-string p0, " ,0 Te tqqcecab cnlitlsesrqanu/ eey Acp gelek/eah"

    const/4 v3, 0x6

    const-string/jumbo p0, "ye mTqcc0 i eg unuceA qreshseealt,l eacpkanl/bet "

    const-string/jumbo p0, "queryAllTag sequence can\'t be 0, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "senqoesc"

    const-string/jumbo v1, "qeseesnc"

    const/4 v3, 0x7

    const-string v1, "enscubeq"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 p1, 0xf90

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public static n(Landroid/content/Context;ILjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "tPmeviuTusprsiAPh"

    const-string v0, "hapmisuArvPsPetiT"

    const/4 v3, 0x2

    const-string/jumbo v0, "irvsutapTipheAsPM"

    const-string v0, "MTPushPrivatesApi"

    const/4 v2, 0x2

    move v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo p0, "ubupetneqslaTraleq cahtc gcxtc  e t/l noe neyoki"

    const-string/jumbo p0, "tea o/Tca  sn llepiknau,y hctn  trcuetqeoelebxcg"

    const/4 v3, 0x5

    const-string/jumbo p0, "uase /cq sec b/lu,pr neeenlgxt hlaant  ttikyoecT"

    const-string/jumbo p0, "queryTag context can\'t be null, please check it"

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo p0, "liemc qr / uht enu,Te pn/ac cbtsceeygaaq0eesk "

    const-string p0, " / n becuaisceh0q rpct kq n, ycsaeetbe/ulagTee"

    const/4 v3, 0x4

    const-string/jumbo p0, "queryTag sequence can\'t be 0, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo p0, "kme/oegbttau Tt,ghtclsee au inqe/eprcc  a y p"

    const-string p0, ",agyteua rtt ugqcpsy eT ep/  me/aeltehc icbkn"

    const/4 v3, 0x1

    const-string/jumbo p0, "tcymlbetikbcpTet a,aaheqsu/ eecgp   reng t a/"

    const-string/jumbo p0, "queryTag tag can\'t be empty, please check it"

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, "cpqeeuue"

    const-string v1, "eeuqsecp"

    const/4 v3, 0x3

    const-string v1, "cqeenuep"

    const-string/jumbo v1, "sequence"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo p1, "tag"

    const-string p1, "gat"

    const-string/jumbo p1, "tag"

    const-string/jumbo p1, "tag"

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/16 p1, 0xf92

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public static o(Landroid/content/Context;Ljava/lang/String;BLjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v0, "iiAqMraPqPhtpsTuv"

    const-string/jumbo v0, "sAraPuiMqhtpiPvsT"

    const/4 v3, 0x3

    const-string/jumbo v0, "iussPhPvatTisepMr"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p0, "ktAm tlscntabinn ixea oetea/c hc/tlsr rlodtfitiouroeiccvN pr, nep"

    const-string/jumbo p0, "srscirovnthroNctiolt/u/Aia edrtaex,ep tn ktciobtllefc npc aei e n"

    const/4 v3, 0x4

    const-string/jumbo p0, "it,votlasc/ux NeieiotctpdA ecabllerka  iotcnr/orce nn htoep tifen"

    const-string/jumbo p0, "reportNotificationArrived context can\'t be null, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string p0, "aNg/ibeeatroeletcedineinpyba Asocdcsf ipror secI mte athtrimp m /,vt"

    const-string p0, "I gmeNe mspsay,eetbcrfiir ls /o nart tthcpdeAce eneitticooap/dremiav"

    const/4 v3, 0x5

    const-string p0, "earigpuseveleriem e//,fo s NmhcnntabtdtaiAoeeri s yi keoptcctprc aId"

    const-string/jumbo p0, "reportNotificationArrived messageId can\'t be empty, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Lcom/engagelab/privates/push/api/NotificationMessage;

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/NotificationMessage;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->a0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->d0(B)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/NotificationMessage;->f0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p2, Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p3, "pgmease"

    const-string/jumbo p3, "sageome"

    const/4 v3, 0x6

    const-string p3, "aqsesmg"

    const-string/jumbo p3, "message"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2, p3, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 p1, 0xf9e

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, p1, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public static p(Landroid/content/Context;Ljava/lang/String;BLjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "vAsiTPsuaMphPtrib"

    const-string v0, "hpArabviiPsMtePuT"

    const/4 v3, 0x2

    const-string v0, "hPvmPApiaeiurTssM"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo p0, "xteco tnc/NceeCiircllb ie inpuunik/hcaa k,tt serlt tfoolpncdtooee"

    const-string/jumbo p0, "ie eNiuoc  nreoeloectnabltnfantoiehei /pptrcl ctcsck,d/ xCilt kut"

    const/4 v3, 0x1

    const-string p0, "artpibikleoot teerelein i/clccCn iaax ophlb ntnNc,cofdtseeutt k/c"

    const-string/jumbo p0, "reportNotificationClicked context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v2, 0x5

    move v3, v2

    const-string/jumbo p0, "tylc auitpecfir ipeae,htsgcml dtN/ iiCotpecssenorIee dm bkkete aanc/"

    const-string/jumbo p0, "s icecapnebpg aoeetiim/ctp  atod,reee Nlhm dciCeI/yfcsttlrnkap ietsk"

    const/4 v3, 0x6

    const-string/jumbo p0, "reportNotificationClicked messageId can\'t be empty, please check it"

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Lcom/engagelab/privates/push/api/NotificationMessage;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/NotificationMessage;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->a0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->d0(B)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/NotificationMessage;->f0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p2, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p3, "pmqesag"

    const-string p3, "eqgseam"

    const/4 v3, 0x0

    const-string p3, "eqmessg"

    const-string/jumbo p3, "message"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p2, p3, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/16 p1, 0xf9d

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, p1, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public static q(Landroid/content/Context;Ljava/lang/String;BLjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "tAsiihupPrsMsaveP"

    const-string v0, "AestrPiuasPpsvMih"

    const/4 v3, 0x3

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p0, " oomatdstiepeoceeefbctem/a epniextNan Dlth/cn  rnu t,icliroetl tc"

    const-string/jumbo p0, "oeimlcnb aaitte nllar rt/eenfeei eootp hpcDi/ectnts ,ulxNcetoctd "

    const-string/jumbo p0, "tetNockcnid eitt,pxcpnrel/lte len oob flo i e /oscuinerathtcaaeDt"

    const-string/jumbo p0, "reportNotificationDeleted context can\'t be null, please check it"

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const-string p0, " peeob No/tae,prkeyDtIdgtiaeseestailcbcod is  haenfei/nt  mtopcmclrt"

    const-string p0, "he,ronsoiDdlestkitotceyetcpeaNi eeaa plrc optgaemeI/s tm c/enb dift "

    const/4 v3, 0x4

    const-string/jumbo p0, "tpieituebeis/ehno/patesN es aInlgrdctco rk leDcoae,cm  tdymtteaeefpi"

    const-string/jumbo p0, "reportNotificationDeleted messageId can\'t be empty, please check it"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/engagelab/privates/push/api/NotificationMessage;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/NotificationMessage;-><init>()V

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->a0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->d0(B)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/NotificationMessage;->f0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p2, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo p3, "pessbge"

    const-string p3, "eegmsbs"

    const/4 v3, 0x7

    const-string/jumbo p3, "sqsemag"

    const-string/jumbo p3, "message"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2, p3, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 p1, 0xf9c

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p1, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public static r(Landroid/content/Context;Ljava/lang/String;BLjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, "PusisviAPtarMpTse"

    const-string/jumbo v0, "rhiPapuMesPisAvTt"

    const/4 v3, 0x3

    const-string v0, "PMrmuTPivAstsepih"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p0, "/eeooicd,eeeaeothcpintntlr ufncknltlnitabc rNpces o o  iOtaex/tp"

    const-string/jumbo p0, "xcateoopNi dieeilfkcnOeps alon boe/lntt ertp,eet catincrnup/cht "

    const/4 v3, 0x6

    const-string/jumbo p0, "reportNotificationOpened context can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string p0, " f qebclcIee/tsenp/irt eto  aegemaepkadbehp,aridnittyimco NtOocpess"

    const-string p0, "bg/eO   qetptacei pe/r,ktnseneh dmdyIpriecpaefcectoaletssaNmi otion"

    const/4 v3, 0x7

    const-string p0, " sdioeusebiedoeifpIn/atge chi sceam/ ,cnN Opor eeptlttecmpy aatekrt"

    const-string/jumbo p0, "reportNotificationOpened messageId can\'t be empty, please check it"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x0

    new-instance v0, Lcom/engagelab/privates/push/api/NotificationMessage;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/NotificationMessage;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->a0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->d0(B)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/NotificationMessage;->f0(Ljava/lang/String;)Lcom/engagelab/privates/push/api/NotificationMessage;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p2, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo p3, "psgamse"

    const-string/jumbo p3, "sssgame"

    const/4 v3, 0x6

    const-string/jumbo p3, "mqasees"

    const-string/jumbo p3, "message"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p2, p3, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 p1, 0xf9b

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public static s(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p0, "assAMteuiPmPpiTrh"

    const-string p0, "ePvmiirhPpatsMAuT"

    const-string p0, "ehsmsPMiPavitrTAu"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x6

    const-string v0, "culfoibksoetaonetx ccta Niioiaa ethcn/et  Bs,n eetr/otl pngele"

    const-string v0, "Noeao x onat/ocf eagrBihleletetene/ibc,sttu psainnkttlicc ce  "

    const/4 v3, 0x6

    const-string v0, "  hntbxN cBeei lsccen ,oo//trpoetes e nttieaagiealdtnbacucilkf"

    const-string/jumbo v0, "resetNotificationBadge context can\'t be null, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v0, 0xf2c

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public static t(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo p0, "ibpvPhuTiussArtPe"

    const-string p0, "avtPsbiruieThsPpA"

    const/4 v3, 0x1

    const-string/jumbo p0, "tPpseAipuiMrvaPTs"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x7

    const-string/jumbo v0, "uthiep/aqincCelsutt sctc ink  ncNlnoocnxi,etouoe  af/tlrbtee t"

    const-string/jumbo v0, "ttolisuNntna nccuxC t,e/a/hel e ioto ksuei pcnef rbeottlecntic"

    const/4 v3, 0x7

    const-string/jumbo v0, "insxecNtou tslC,ec/aftcoiae eniclnoioeatetrtutn t sl /bp hk ce"

    const-string/jumbo v0, "resetNotificationCount context can\'t be null, please check it"

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v0, 0xf2e

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public static u(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string p0, "AeamMrhsiPpsupTvP"

    const-string p0, "haTAPsspMpvutePir"

    const/4 v3, 0x3

    const-string p0, "atPiohPprMTssvueA"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x5

    const-string/jumbo p1, "onau biLet  iieps lafaaocl cnbenotsn,kutetyceecrothNit/qle/ cxt"

    const-string p1, "ccoLoiluqteen,/eosatti p t/ hnxaactnNcirou cb ey nsfete eaklilt"

    const/4 v3, 0x1

    const-string p1, "haa ctuebtuoiespneiae n/tycl siLe uconcfkoc i,lrttoN ttt/ex anl"

    const-string/jumbo p1, "resetNotificationLayout context can\'t be null, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "di"

    const-string/jumbo v1, "id"

    const-string/jumbo v1, "id"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/16 p1, 0xf30

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public static v(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo p0, "sivPtpepMuTihsaAP"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v0, "xs/iueTlqnioar obnaltticsiensS heltthwNc ae mteo/ceiee  onk tcc,p"

    const-string/jumbo v0, "pxsiieci ei ettcbtlsuclr/a ho nf eomtoa soT,t nneNnchw/eSeelicakt"

    const-string/jumbo v0, "uwsbfnoern atini c tnh shect/eitekmet/etc leeN,Ttocoiclasx ailoS "

    const-string/jumbo v0, "resetNotificationShowTime context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v0, 0xf34

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public static w(Landroid/content/Context;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const-string p0, "TsvmiueMraPAPmsti"

    const-string p0, "estmPTpiPsiurAaMv"

    const/4 v3, 0x0

    const-string p0, "PMisoaPtivuATsrhe"

    const-string p0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "eueitbs lmi cn neSTnioeothle eNtcics ren tnaoktt,fc/te/lepabocla iic"

    const-string v0, " utooneittincTteciflNinta ni,cseaencccetlreleotoi  / eS ek sp/emlabh"

    const/4 v3, 0x6

    const-string v0, " nbti ueniScnisT meeefacorite,oeetetce kp/chocictliea/nstlltauxl  nN"

    const-string/jumbo v0, "resetNotificationSilenceTime context can\'t be null, please check it"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    move v3, v2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v0, 0xf32

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x7

    return-void
.end method

.method public static x(Landroid/content/Context;ILjava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "pAsuTarpsPhiibMPv"

    const-string v0, "APMuvbeapPTssirhi"

    const/4 v3, 0x7

    const-string/jumbo v0, "iPpuMAitqePhvssrT"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p0, "t stlsoxea lat seuk,eltbccne/nieci/ u tl Ashnea "

    const-string p0, "exek uuo hlsntbtseetcna,ie Atl s ntclcaia/ l /pe"

    const/4 v3, 0x5

    const-string/jumbo p0, "lslmtlelt,ce/aspetoi bkA / eacst uetcx c ahnenin"

    const-string/jumbo p0, "setAlias context can\'t be null, please check it"

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string p0, "ciltoe,l alasanuesp iceelln As/ kcbph ea/t i t"

    const-string/jumbo p0, "l  enaeplls,tn hauase/ aseccA ipiscl/ tktl ieb"

    const/4 v3, 0x0

    const-string p0, " taeebbtaae pAli,tnl/eaelcius csn ailc  / sslk"

    const-string/jumbo p0, "setAlias alias can\'t be null, please check it"

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, "cqunqeus"

    const-string/jumbo v1, "qeqcesnu"

    const/4 v3, 0x7

    const-string v1, "csuqneep"

    const-string/jumbo v1, "sequence"

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const-string/jumbo p1, "lasas"

    const/4 v3, 0x2

    const-string/jumbo p1, "slaqa"

    const-string p1, "alias"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 p1, 0xf8f

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public static y(Landroid/content/Context;I)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "PasTvAptimushPMrs"

    const-string v0, "PMimeATavrssthPpu"

    const/4 v3, 0x2

    const-string/jumbo v0, "ptvmAhisTMsiraPPe"

    const-string v0, "MTPushPrivatesApi"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string p0, "/aCloeet n Ghcn tscuintsbtkflc/eeeen noeu,oxc taeo  tlco"

    const-string p0, "ceteo,e Gnl notc e ekelnn/iaceceb atsfunsteClut xc/ ohto"

    const/4 v3, 0x6

    const-string/jumbo p0, "t cxcb,i tlckhfseeeCnloecleubn tpecuoeat at /etne n Gn/s"

    const-string/jumbo p0, "setGeofenceCount context can\'t be null, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lez p1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/16 v1, 0x64

    const/4 v3, 0x5

    if-lt p1, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v2, 0x3

    move v3, v2

    return-void

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "nutbc"

    const-string v1, "bcnto"

    const/4 v3, 0x1

    const-string/jumbo v1, "ocput"

    const-string v1, "count"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 p1, 0xf2b

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    return-void

    :cond_3
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p0, "w uesoi1qse p 0komo0te  teGuttbsC,0e cehcn a~ecuncetftlenu"

    const-string/jumbo p0, "kettntu0saenseslo0ehuc fcut, otbin 1~m0tee G eoeC  ecupnwc"

    const/4 v3, 0x0

    const-string p0, " Gse neut netlu Cf0t ts,ecmwt1uti0 cacn~eeeopoe s0beeksnho"

    const-string/jumbo p0, "setGeofenceCount count must between 0~100, please check it"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public static z(Landroid/content/Context;J)V
    .locals 5
    .annotation build Lp2/a;
    .end annotation

    const/4 v4, 0x6

    const-string v0, "PshmpMrApeTuPisai"

    const-string v0, "ATpaivPpMeisrsPuh"

    const/4 v4, 0x0

    const-string v0, "PiueoarstMhvsPiAT"

    const-string v0, "MTPushPrivatesApi"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const-string/jumbo p0, "teonlbneeaxee, enotnt/etcGaaIktscl cpqr uf th evbc/esc elnl"

    const-string p0, "eapntIutqver e oca xs//esencllG,hccea oenec klntflette  bnt"

    const/4 v4, 0x4

    const-string p0, "In ea ulefclcn ee,Gc/cteentnhkbtetaotro seve pinx/ lstl uec"

    const-string/jumbo p0, "setGeofenceInterval context can\'t be null, please check it"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-wide/32 v1, 0x2bf20

    const-wide/32 v1, 0x2bf20

    const/4 v4, 0x4

    const-wide/32 v1, 0x2bf20

    const-wide/32 v1, 0x2bf20

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    cmp-long v1, p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ltz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    const/4 v4, 0x5

    const-wide/32 v1, 0x5265c00

    const-wide/32 v1, 0x5265c00

    const/4 v4, 0x0

    const/4 v3, 0x5

    cmp-long v1, p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-lez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "lrvstnep"

    const-string/jumbo v1, "vastnler"

    const/4 v4, 0x4

    const-string/jumbo v1, "interval"

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1, p1, p2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 p1, 0xf2a

    const/4 v4, 0x3

    invoke-static {p0, p1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void

    :cond_3
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo p0, "m1Gtn0t qfl0u neeteacn1eet  0r0vc6  hnete ea 00 r*~ivse p**0  0s,skIeoec i0*  a3lm le 26 w46b*"

    const-string p0, " eem   *te01p* ne6is sh ltce G b o000rnI e*semak043urvl *,2i 0t10ecna vcate0 e  0e ft6~eln *6w"

    const-string p0, "evs 6 04elem0p u*f   i3*t 0 rIce *0610ec *ke*h6leno  sbsntn,t c G ~ta 2t0e0rlenae0 ie  10aetvw"

    const-string/jumbo p0, "setGeofenceInterval interval must between 3 * 60 * 1000 ~ 24 * 60 * 60 * 1000, please check it"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method
