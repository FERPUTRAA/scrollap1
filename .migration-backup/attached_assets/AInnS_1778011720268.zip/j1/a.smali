.class public interface abstract Lj1/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)V
.end method

.method public abstract b(I)V
.end method

.method public abstract c()I
.end method

.method public abstract d()V
.end method

.method public abstract e(I)V
.end method

.method public abstract f(I)V
.end method

.method public abstract g()V
.end method
