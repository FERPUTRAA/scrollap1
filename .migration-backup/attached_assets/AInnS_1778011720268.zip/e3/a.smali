.class public Le3/a;
.super Lc3/b;


# static fields
.field public static final a:Ljava/lang/String;

.field public static final b:Ljava/lang/String;

.field public static final c:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lx2/a;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "EOCR"

    const-string v1, "CEOR"

    const/4 v3, 0x6

    const-string v1, "EOCR"

    const-string v1, "CORE"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lx2/a;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "REssPR"

    const-string v1, "OEsRRP"

    const/4 v3, 0x3

    const-string v1, "RPOmER"

    const-string v1, "REPORT"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-object v0, Le3/a;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    invoke-static {}, Lx2/a;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "TCEComN"

    const-string v1, "CECmNNT"

    const/4 v3, 0x6

    const-string v1, "ENCCNbO"

    const-string v1, "CONNECT"

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    sput-object v0, Le3/a;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lc3/b;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@M y tu ~@vcb~o@@~u~fo4@~  ~@~b@~i .ll sm~oK~dr@on@ @-@o~    @~b~/@/t@ aS@i@~~~1~o~  @i~ ~~f @@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    const/16 v0, 0x7d1

    const/4 v6, 0x6

    if-eq p2, v0, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v0, 0x7d2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq p2, v0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/16 v0, 0x8b9

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eq p2, v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/16 v0, 0xbb1

    const/4 v5, 0x3

    if-eq p2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/16 v0, 0xbb2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-wide/16 v1, 0x2710

    const/4 v6, 0x1

    const-wide/16 v1, 0x2710

    const-wide/16 v1, 0x2710

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq p2, v0, :cond_0

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lh3/b;->c()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-long/2addr v3, v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    long-to-int v1, v3

    const/4 v5, 0x7

    and-int/2addr v6, v5

    invoke-static {p1, v0, v1}, Lq2/a;->b(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object v0, Le3/a;->c:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lh3/b;->c()J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    add-long/2addr v3, v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    long-to-int v1, v3

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lq2/a;->b(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    sget-object v0, Le3/a;->c:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lq2/a;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget-object v0, Le3/a;->b:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_3
    const/4 v6, 0x3

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p2, p1}, Lo2/i;->g(Landroid/content/Context;)V

    const/4 v6, 0x1

    goto :goto_0

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p2, p1}, Lo2/i;->d(Landroid/content/Context;)V

    :goto_0
    const/4 v6, 0x4

    return-void
.end method

.method public b()S
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    move v2, v1

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const-string v0, "eervor_pd_sk"

    const-string/jumbo v0, "krdeo_re_svc"

    const/4 v2, 0x0

    const-string v0, "c_rseo_dqkvr"

    const-string v0, "core_sdk_ver"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "35s.4"

    const-string v0, "b4.35"

    const/4 v2, 0x0

    const-string v0, "..4m3"

    const-string v0, "4.3.5"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public f()[Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v1, Le3/a;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v2, Le3/a;->c:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0
.end method

.method public g(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p3, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eq p2, p3, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/16 p3, 0xbae

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-eq p2, p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/16 p3, 0xbb0

    const/4 v1, 0x2

    const/4 v0, 0x5

    if-eq p2, p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p2, p1}, Lo2/i;->i(Landroid/content/Context;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/16 p2, 0xbb2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p3, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v1, 0x7

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x0

    invoke-virtual {p2, p1}, Lo2/i;->b(Landroid/content/Context;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public h(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 v0, 0x13

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p2, v0, :cond_9

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/16 v0, 0x19

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eq p2, v0, :cond_8

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/16 v0, 0x7cf

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p2, v0, :cond_7

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/16 v0, 0x8ae

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq p2, v0, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/16 v0, 0x835

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-eq p2, v0, :cond_5

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/16 v0, 0x836

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eq p2, v0, :cond_4

    const/4 v1, 0x3

    move v2, v1

    const/16 v0, 0x8b9

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p2, v0, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/16 v0, 0x8ba

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eq p2, v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 p3, 0xbb6

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p2, p3, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/16 p3, 0xbb7

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eq p2, p3, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/16 v0, 0xbb2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    packed-switch p2, :pswitch_data_0

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    packed-switch p2, :pswitch_data_1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto/16 :goto_0

    :pswitch_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2, p1}, Lo2/i;->m(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto/16 :goto_0

    :pswitch_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Lo2/i;->l(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto/16 :goto_0

    :pswitch_2
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Lo2/i;->h(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto/16 :goto_0

    :pswitch_3
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p2, p1}, Lo2/i;->j(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    goto/16 :goto_0

    :pswitch_4
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1, v0, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto/16 :goto_0

    :pswitch_5
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lo2/f;->a()Lo2/f;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Lo2/f;->c(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    goto/16 :goto_0

    :pswitch_6
    const/4 v2, 0x0

    invoke-static {}, Lo2/f;->a()Lo2/f;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2, p1}, Lo2/f;->b(Landroid/content/Context;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto/16 :goto_0

    :pswitch_7
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1, v0, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x2

    goto/16 :goto_0

    :cond_0
    :pswitch_8
    const/4 v2, 0x2

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Lo2/i;->i(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto/16 :goto_0

    :cond_1
    :pswitch_9
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {p2, p1}, Lo2/i;->k(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lo2/h;->a()Lo2/h;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, p1, p3}, Lo2/h;->b(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lo2/p;->c()Lo2/p;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p2, p1, p3}, Lo2/p;->f(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/d;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_5
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2, p1, p3}, Lo2/d;->f(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_6
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/i;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_7
    const/4 v2, 0x3

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Lo2/d;->d(Landroid/content/Context;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Lo2/d;->b(Landroid/content/Context;)V

    const/4 v2, 0x4

    goto :goto_0

    :cond_8
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p2, p1, p3}, Lo2/d;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_9
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p2, p1, p3}, Lo2/i;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :pswitch_data_0
    .packed-switch 0x7c9
        :pswitch_7
        :pswitch_6
        :pswitch_5
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xbae
        :pswitch_4
        :pswitch_9
        :pswitch_8
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public j(I)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0x13

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x19

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 v0, 0x8ae

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0x7ce

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v0, 0x7cf

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x7d1

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/16 v0, 0x7d2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    const/16 v0, 0x835

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/16 v0, 0x836

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x8b9

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 v0, 0x8ba

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 v0, 0xbb6

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0xbb7

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x0

    move v2, v1

    packed-switch p1, :pswitch_data_1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return p1

    :cond_0
    :pswitch_0
    const/4 v1, 0x1

    move v2, v1

    const/4 p1, 0x1

    shr-int/2addr v2, p1

    const/4 v1, 0x2

    move v2, v1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x7c9
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xbae
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
