.class public Li3/a;
.super Lc3/b;


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lx2/a;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v1, "PUHS"

    const-string v1, "HSPU"

    const/4 v3, 0x3

    const-string v1, "PHUS"

    const-string v1, "PUSH"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object v0, Li3/a;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lc3/b;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o s~n~tsu~@@~m @@ait ~ ~~~l1K@~dr@~@ @~oo @M  @of i~ @@@ Sy @f~l.b~@~~@4b@/@~@   ~bo -~~~ic /@ov"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/16 v0, 0xce7

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eq p2, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    packed-switch p2, :pswitch_data_0

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    packed-switch p2, :pswitch_data_1

    const/4 v2, 0x4

    packed-switch p2, :pswitch_data_2

    sget-object v0, Li3/a;->a:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto/16 :goto_0

    :pswitch_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/t;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lo2/w;->e()Lo2/w;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2, p3}, Lo2/w;->d(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v2, 0x0

    invoke-static {}, Lo2/c0;->e()Lo2/c0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2, p3}, Lo2/c0;->c(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    goto :goto_0

    :pswitch_3
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lo2/e0;->k()Lo2/e0;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2, p3}, Lo2/e0;->f(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_4
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lo2/d0;->e()Lo2/d0;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2, p3}, Lo2/d0;->c(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_5
    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p2, p1, p3}, Lo2/z;->m(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_6
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p2, p1, p3}, Lo2/z;->u(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    :pswitch_7
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3}, Lo2/x;->i(Landroid/content/Context;ILandroid/os/Bundle;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void

    :pswitch_data_0
    .packed-switch 0xbb9
        :pswitch_1
        :pswitch_7
        :pswitch_7
        :pswitch_7
        :pswitch_7
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xbc3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_2
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0xbcd
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch
.end method

.method public b()S
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, "_ssdrvk"

    const/4 v2, 0x5

    const-string v0, "ekrmsdv"

    const-string/jumbo v0, "sdk_ver"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lj3/a;->c:Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method public f()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Li3/a;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    return-object v0
.end method

.method public g(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x2

    packed-switch p2, :pswitch_data_0

    const/4 v0, 0x6

    or-int/2addr v1, v0

    goto :goto_0

    :pswitch_0
    const/4 v0, 0x4

    move v1, v0

    invoke-static {}, Lo2/c0;->e()Lo2/c0;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p2, p1, p3}, Lo2/c0;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    goto :goto_0

    :pswitch_1
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {}, Lo2/e0;->k()Lo2/e0;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p2, p1, p3}, Lo2/e0;->g(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    goto :goto_0

    :pswitch_2
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2, p1, p3}, Lo2/z;->o(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :pswitch_3
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lo2/d0;->e()Lo2/d0;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p2, p1, p3}, Lo2/d0;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1a
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public h(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 v0, 0xf8a

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eq p2, v0, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 v0, 0xf8b

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p2, v0, :cond_6

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x7

    move v3, v0

    move v3, v0

    const/4 v4, 0x5

    if-eq p2, v0, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/16 v1, 0x3b

    const/4 v4, 0x1

    if-eq p2, v1, :cond_4

    const/4 v3, 0x6

    move v4, v3

    const/16 v1, 0x7d1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eq p2, v1, :cond_3

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 v1, 0xbb5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq p2, v1, :cond_2

    const/4 v4, 0x6

    const/16 v1, 0xbb7

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p2, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/16 v1, 0xed4

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eq p2, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    packed-switch p2, :pswitch_data_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch p2, :pswitch_data_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    packed-switch p2, :pswitch_data_2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    packed-switch p2, :pswitch_data_3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    packed-switch p2, :pswitch_data_4

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto/16 :goto_0

    :pswitch_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lo2/c0;->e()Lo2/c0;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2, p1, p3}, Lo2/c0;->g(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto/16 :goto_0

    :pswitch_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lo2/e0;->k()Lo2/e0;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, p1, p3}, Lo2/e0;->n(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto/16 :goto_0

    :pswitch_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/z;->r(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto/16 :goto_0

    :pswitch_3
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Lo2/d0;->e()Lo2/d0;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p2, p1, p3}, Lo2/d0;->g(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto/16 :goto_0

    :pswitch_4
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 p2, 0xbb2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    move v4, v3

    goto/16 :goto_0

    :pswitch_5
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 p2, 0xbb1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_6
    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {}, Lo2/u;->b()Lo2/u;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, p1}, Lo2/u;->e(Landroid/content/Context;)V

    const/4 v3, 0x7

    move v4, v3

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p3, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/t;->g(Landroid/content/Context;I)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_7
    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lo2/u;->b()Lo2/u;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Lo2/u;->c(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_8
    const/4 v4, 0x7

    const/16 p2, 0xbb4

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 p2, 0xc1e

    const/4 v4, 0x2

    invoke-static {p1, p2, v2}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto/16 :goto_0

    :pswitch_9
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/16 p2, 0xbb3

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 p2, 0xc1f

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, p2, v2}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_a
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {}, Lo2/w;->e()Lo2/w;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, p1, p3}, Lo2/w;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_b
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/x;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto/16 :goto_0

    :pswitch_c
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2, p1, p3}, Lo2/x;->y(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto/16 :goto_0

    :pswitch_d
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/x;->u(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto/16 :goto_0

    :pswitch_e
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/t;->p(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_f
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Lo2/t;->s(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_10
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, p1, p3}, Lo2/t;->r(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto/16 :goto_0

    :pswitch_11
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Lo2/t;->t(Landroid/content/Context;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto/16 :goto_0

    :pswitch_12
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, p1, p3}, Lo2/t;->n(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    goto/16 :goto_0

    :pswitch_13
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2, p1, p3}, Lo2/t;->h(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_14
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p2, p1, p3}, Lo2/t;->k(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto/16 :goto_0

    :pswitch_15
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Lo2/t;->q(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto/16 :goto_0

    :pswitch_16
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x7

    invoke-virtual {p2, p1, p3}, Lo2/t;->i(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_17
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p2, p1}, Lo2/t;->o(Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_18
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Lo2/e0;->k()Lo2/e0;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1, p2, p3}, Lo2/e0;->m(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto/16 :goto_0

    :pswitch_19
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lo2/c0;->e()Lo2/c0;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p1, p2, p3}, Lo2/c0;->f(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto/16 :goto_0

    :pswitch_1a
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lo2/w;->e()Lo2/w;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p1, p2, p3}, Lo2/w;->f(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto/16 :goto_0

    :pswitch_1b
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, p1, v0}, Lo2/t;->g(Landroid/content/Context;I)V

    :pswitch_1c
    const/4 v4, 0x4

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p1, p2, p3}, Lo2/x;->t(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    if-eqz p3, :cond_8

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p2, "_aumuegt_aeessglr"

    const/4 v4, 0x6

    const-string/jumbo p2, "leeaoueang_usrt_g"

    const-string/jumbo p2, "set_user_language"

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p3, p2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1}, Lo2/q;->I(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p2, p3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x0

    if-nez p3, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lo2/q;->s(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Lo2/t;->m(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Lo2/z;->n(Landroid/content/Context;)V

    const/4 v4, 0x4

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Lo2/t;->m(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p3, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p2, p1, p3}, Lo2/t;->g(Landroid/content/Context;I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2, p1, p3}, Lo2/t;->g(Landroid/content/Context;I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Lo2/z;->f(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/16 p2, 0xf27

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p2, p1, p3}, Lo2/x;->x(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lo2/v;->a()Lo2/v;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p2, p1, p3}, Lo2/v;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lo2/z;->k()Lo2/z;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2, p1, p3}, Lo2/z;->w(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x1

    goto :goto_0

    :cond_7
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lo2/d0;->e()Lo2/d0;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p1, p2, p3}, Lo2/d0;->f(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_8
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void

    :pswitch_data_0
    .packed-switch 0x1a
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x7ca
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0xf2c
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch

    :pswitch_data_3
    .packed-switch 0xf8d
        :pswitch_19
        :pswitch_19
        :pswitch_19
        :pswitch_18
        :pswitch_18
        :pswitch_18
        :pswitch_18
        :pswitch_18
        :pswitch_18
    .end packed-switch

    :pswitch_data_4
    .packed-switch 0xf9b
        :pswitch_1c
        :pswitch_1c
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
    .end packed-switch
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public j(I)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/16 v0, 0xc1e

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/16 v0, 0xc1f

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/16 v0, 0xf8a

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/16 v0, 0xf8b

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/16 v0, 0x3b

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x7d1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0xbb7

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 v0, 0xce7

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    packed-switch p1, :pswitch_data_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    packed-switch p1, :pswitch_data_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    packed-switch p1, :pswitch_data_2

    const/4 v2, 0x2

    const/4 v1, 0x0

    packed-switch p1, :pswitch_data_3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    packed-switch p1, :pswitch_data_4

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    packed-switch p1, :pswitch_data_5

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    packed-switch p1, :pswitch_data_6

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    packed-switch p1, :pswitch_data_7

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    packed-switch p1, :pswitch_data_8

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1

    :cond_0
    :pswitch_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0xf28
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xf9a
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x1a
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_3
    .packed-switch 0x7ca
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_4
    .packed-switch 0xbb9
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_5
    .packed-switch 0xbc3
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_6
    .packed-switch 0xbcd
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_7
    .packed-switch 0xed4
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    :pswitch_data_8
    .packed-switch 0xf8d
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
