.class public final Ld2/b;
.super Landroid/os/Handler;


# static fields
.field public static final b:I = 0x3e8

.field public static final c:I = 0x7d0

.field public static final d:I = 0xbb8


# instance fields
.field private final a:Lcom/contrarywind/view/WheelView;


# direct methods
.method public constructor <init>(Lcom/contrarywind/view/WheelView;)V
    .locals 2

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Ld2/b;->a:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  sn@~~~@~~@~4@ou-~1S~/s~c@o @.vK@@ ~ orl~ amdi~ltf@@~fio@@~oti@@~~/  o~~b @b ~  ~ y @~@~ bM @ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/16 v0, 0x3e8

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p1, v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x7d0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eq p1, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0xbb8

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p0, Ld2/b;->a:Lcom/contrarywind/view/WheelView;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/contrarywind/view/WheelView;->onItemSelected()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Ld2/b;->a:Lcom/contrarywind/view/WheelView;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/contrarywind/view/WheelView$b;->b:Lcom/contrarywind/view/WheelView$b;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/contrarywind/view/WheelView;->smoothScroll(Lcom/contrarywind/view/WheelView$b;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object p1, p0, Ld2/b;->a:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method
