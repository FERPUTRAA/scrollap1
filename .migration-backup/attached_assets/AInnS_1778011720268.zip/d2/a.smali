.class public final Ld2/a;
.super Ljava/util/TimerTask;


# instance fields
.field private a:F

.field private final b:F

.field private final c:Lcom/contrarywind/view/WheelView;


# direct methods
.method public constructor <init>(Lcom/contrarywind/view/WheelView;F)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput p2, p0, Ld2/a;->b:F

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/high16 p1, 0x4f000000

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Ld2/a;->a:F

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 14

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v12, "  s @l~ -K~~~@bo @~~M@o4  @@1d l @@~~ @bo~~ .o@ @af~u~ ~~sS@@@ti@~o@ /bo@t~my/~i@~f~nc @~ ~r @iv"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x6

    iget v0, p0, Ld2/a;->a:F

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/high16 v1, 0x4f000000

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x6

    cmpl-float v0, v0, v1

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    const/4 v1, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    if-nez v0, :cond_2

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x4

    iget v0, p0, Ld2/a;->b:F

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    const/high16 v2, 0x44fa0000    # 2000.0f

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x3

    cmpl-float v0, v0, v2

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x4

    if-lez v0, :cond_1

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    iget v0, p0, Ld2/a;->b:F

    const/4 v13, 0x4

    cmpl-float v0, v0, v1

    const/4 v13, 0x3

    const/4 v12, 0x3

    if-lez v0, :cond_0

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x6

    goto :goto_0

    :cond_0
    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x1

    const/high16 v2, -0x3b060000    # -2000.0f

    :goto_0
    const/4 v13, 0x2

    const/4 v12, 0x0

    iput v2, p0, Ld2/a;->a:F

    const/4 v13, 0x2

    const/4 v12, 0x5

    goto :goto_1

    :cond_1
    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x2

    iget v0, p0, Ld2/a;->b:F

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x2

    iput v0, p0, Ld2/a;->a:F

    :cond_2
    :goto_1
    const/4 v13, 0x3

    const/4 v12, 0x6

    iget v0, p0, Ld2/a;->a:F

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x3

    cmpl-float v0, v0, v1

    const/4 v12, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x4

    const/high16 v2, 0x41a00000    # 20.0f

    const/4 v13, 0x7

    if-ltz v0, :cond_3

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x3

    iget v0, p0, Ld2/a;->a:F

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x2

    cmpg-float v0, v0, v2

    const/4 v13, 0x3

    const/4 v12, 0x5

    if-gtz v0, :cond_3

    const/4 v13, 0x2

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v12, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->cancelFuture()V

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x7

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    const/16 v1, 0x7d0

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    return-void

    :cond_3
    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget v0, p0, Ld2/a;->a:F

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x7

    const/high16 v3, 0x42c80000    # 100.0f

    const/4 v13, 0x5

    div-float/2addr v0, v3

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x2

    float-to-int v0, v0

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x6

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v4

    const/4 v13, 0x6

    const/4 v12, 0x3

    int-to-float v0, v0

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x6

    sub-float/2addr v4, v0

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v3, v4}, Lcom/contrarywind/view/WheelView;->setTotalScrollY(F)V

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x7

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v12, 0x2

    move v13, v12

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->isLoop()Z

    move-result v3

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x0

    if-nez v3, :cond_7

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x7

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getItemHeight()F

    move-result v3

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x1

    iget-object v4, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v4}, Lcom/contrarywind/view/WheelView;->getInitPosition()I

    move-result v4

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x4

    neg-int v4, v4

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x4

    int-to-float v4, v4

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x3

    mul-float/2addr v4, v3

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x5

    iget-object v5, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v5}, Lcom/contrarywind/view/WheelView;->getItemsCount()I

    move-result v5

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x2

    add-int/lit8 v5, v5, -0x1

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x2

    iget-object v6, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v12, 0x0

    shr-int/2addr v13, v12

    invoke-virtual {v6}, Lcom/contrarywind/view/WheelView;->getInitPosition()I

    move-result v6

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x4

    sub-int/2addr v5, v6

    const/4 v13, 0x1

    const/4 v12, 0x7

    int-to-float v5, v5

    const/4 v12, 0x3

    and-int/2addr v13, v12

    mul-float/2addr v5, v3

    const/4 v12, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    iget-object v6, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v6}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v6

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x3

    float-to-double v6, v6

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x1

    float-to-double v8, v3

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x5

    const-wide/high16 v10, 0x3fd0000000000000L    # 0.25

    const-wide/high16 v10, 0x3fd0000000000000L    # 0.25

    const/4 v13, 0x2

    const-wide/high16 v10, 0x3fd0000000000000L    # 0.25

    const-wide/high16 v10, 0x3fd0000000000000L    # 0.25

    const/4 v13, 0x0

    const/4 v12, 0x6

    mul-double/2addr v8, v10

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x1

    sub-double/2addr v6, v8

    const/4 v12, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    float-to-double v10, v4

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x0

    cmpg-double v3, v6, v10

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x7

    if-gez v3, :cond_4

    const/4 v12, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x6

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v3

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x6

    add-float v4, v3, v0

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    goto :goto_2

    :cond_4
    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v3

    const/4 v13, 0x4

    const/4 v12, 0x2

    float-to-double v6, v3

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    add-double/2addr v6, v8

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x5

    float-to-double v8, v5

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x7

    cmpl-double v3, v6, v8

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x5

    if-lez v3, :cond_5

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x2

    iget-object v3, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v3

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    add-float v5, v3, v0

    :cond_5
    :goto_2
    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x2

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x1

    const/4 v12, 0x7

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v0

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    cmpg-float v0, v0, v4

    const/4 v13, 0x2

    const/4 v12, 0x1

    if-gtz v0, :cond_6

    const/4 v12, 0x0

    move v13, v12

    const/high16 v0, 0x42200000    # 40.0f

    const/4 v12, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    iput v0, p0, Ld2/a;->a:F

    const/4 v13, 0x3

    const/4 v12, 0x6

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    float-to-int v3, v4

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    int-to-float v3, v3

    const/4 v12, 0x2

    and-int/2addr v13, v12

    invoke-virtual {v0, v3}, Lcom/contrarywind/view/WheelView;->setTotalScrollY(F)V

    const/4 v13, 0x4

    const/4 v12, 0x2

    goto :goto_3

    :cond_6
    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x6

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    cmpl-float v0, v0, v5

    const/4 v13, 0x5

    if-ltz v0, :cond_7

    const/4 v13, 0x7

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x3

    float-to-int v3, v5

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    int-to-float v3, v3

    const/4 v13, 0x7

    const/4 v12, 0x6

    invoke-virtual {v0, v3}, Lcom/contrarywind/view/WheelView;->setTotalScrollY(F)V

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x1

    const/high16 v0, -0x3de00000    # -40.0f

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x4

    iput v0, p0, Ld2/a;->a:F

    :cond_7
    :goto_3
    const/4 v12, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x4

    iget v0, p0, Ld2/a;->a:F

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x4

    cmpg-float v1, v0, v1

    const/4 v13, 0x4

    if-gez v1, :cond_8

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    add-float/2addr v0, v2

    const/4 v12, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x4

    iput v0, p0, Ld2/a;->a:F

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x6

    goto :goto_4

    :cond_8
    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    sub-float/2addr v0, v2

    const/4 v13, 0x0

    const/4 v12, 0x4

    iput v0, p0, Ld2/a;->a:F

    :goto_4
    const/4 v12, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x0

    iget-object v0, p0, Ld2/a;->c:Lcom/contrarywind/view/WheelView;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x1

    const/16 v1, 0x3e8

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    return-void
.end method
