.class public final Ld2/c;
.super Ljava/util/TimerTask;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private final d:Lcom/contrarywind/view/WheelView;


# direct methods
.method public constructor <init>(Lcom/contrarywind/view/WheelView;I)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x0

    iput p2, p0, Ld2/c;->c:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const p1, 0x7fffffff

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Ld2/c;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput p1, p0, Ld2/c;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~vs /lo@ ~r  @~@-M obc d~ l@~~@o~nu@ o~~bsS@ ~f/~@oi@ @. @4Kf~ ab~~~~@  @ @@~iio@t~~@@m~~1yt@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget v0, p0, Ld2/c;->a:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const v1, 0x7fffffff

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget v0, p0, Ld2/c;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput v0, p0, Ld2/c;->a:I

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v0, p0, Ld2/c;->a:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    int-to-float v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const v2, 0x3dcccccd    # 0.1f

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    mul-float/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    float-to-int v1, v1

    const/4 v6, 0x4

    iput v1, p0, Ld2/c;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x1

    move v6, v5

    if-nez v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-gez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput v1, p0, Ld2/c;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iput v2, p0, Ld2/c;->b:I

    :cond_2
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/16 v1, 0xbb8

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-gt v0, v2, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->cancelFuture()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v4, p0, Ld2/c;->b:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    int-to-float v4, v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-float/2addr v3, v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Lcom/contrarywind/view/WheelView;->setTotalScrollY(F)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->isLoop()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v0, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getItemHeight()F

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v3, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3}, Lcom/contrarywind/view/WheelView;->getInitPosition()I

    move-result v3

    const/4 v5, 0x6

    const/4 v6, 0x3

    neg-int v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    int-to-float v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    mul-float/2addr v3, v0

    const/4 v5, 0x3

    or-int/2addr v6, v5

    iget-object v4, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v4}, Lcom/contrarywind/view/WheelView;->getItemsCount()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    sub-int/2addr v4, v2

    const/4 v5, 0x1

    move v6, v5

    iget-object v2, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/contrarywind/view/WheelView;->getInitPosition()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    sub-int/2addr v4, v2

    const/4 v6, 0x3

    int-to-float v2, v4

    const/4 v5, 0x7

    move v6, v5

    mul-float/2addr v2, v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    cmpg-float v0, v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-lez v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    cmpl-float v0, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-ltz v0, :cond_5

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getTotalScrollY()F

    move-result v2

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    iget v3, p0, Ld2/c;->b:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    int-to-float v3, v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    sub-float/2addr v2, v3

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    invoke-virtual {v0, v2}, Lcom/contrarywind/view/WheelView;->setTotalScrollY(F)V

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->cancelFuture()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-void

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Ld2/c;->d:Lcom/contrarywind/view/WheelView;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/contrarywind/view/WheelView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/16 v1, 0x3e8

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v0, p0, Ld2/c;->a:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v1, p0, Ld2/c;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    sub-int/2addr v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput v0, p0, Ld2/c;->a:I

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void
.end method
