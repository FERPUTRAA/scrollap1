.class public final Ll3/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "com.engagelab.privates.push.platform.google"

.field public static final c:Ljava/lang/String; = "standard"

.field public static final d:Ljava/lang/String; = "23.1.1"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
