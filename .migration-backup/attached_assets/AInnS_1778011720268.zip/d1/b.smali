.class public Ld1/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Ld1/d;)Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "c@s~ ~ab@~@~~~@o~~@ ~ 4K@@fo~@y@ s@-mb@o d @~  ut@@ ~@b~~~@Mr@l v~So~ i1~ f /~  @~oot@./ iil@~ n"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    new-instance v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;

    const/4 v4, 0x0

    move v5, v4

    invoke-direct {v0}, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;-><init>()V

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 p0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, Ld1/d;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->os:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Ld1/d;->j:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->rpcVersion:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v1, "1"

    const-string v1, "1"

    const/4 v5, 0x1

    const-string v1, "1"

    const-string v1, "1"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->bizType:Ljava/lang/String;

    const/4 v5, 0x4

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->bizData:Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "pdams"

    const-string v2, "ddsap"

    const/4 v5, 0x4

    const-string/jumbo v2, "pddao"

    const-string v2, "apdid"

    const/4 v5, 0x1

    iget-object v3, p0, Ld1/d;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->bizData:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "padikbnmoe"

    const-string v2, "dkpmedaoin"

    const/4 v5, 0x5

    const-string v2, "apdidToken"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v3, p0, Ld1/d;->c:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->bizData:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v2, "umdioeTkn"

    const/4 v5, 0x2

    const-string/jumbo v2, "umidToken"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v3, p0, Ld1/d;->d:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->bizData:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "ycnKamubey"

    const-string v2, "eKynybmica"

    const/4 v5, 0x3

    const-string v2, "eymdcaypiK"

    const-string v2, "dynamicKey"

    const/4 v5, 0x6

    const/4 v4, 0x5

    iget-object v3, p0, Ld1/d;->e:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object p0, p0, Ld1/d;->f:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object p0, v0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportRequest;->deviceData:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object v0
.end method

.method public static b(Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;)Ld1/c;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v0, Ld1/c;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0}, Ld1/c;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez p0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 p0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-boolean v1, p0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;->success:Z

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-boolean v1, v0, Ld1/a;->a:Z

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;->resultCode:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object v1, v0, Ld1/a;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    iget-object p0, p0, Lcom/alipay/tscenter/biz/rpc/report/general/model/DataReportResult;->resultData:Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz p0, :cond_3

    const-string v1, "diaqd"

    const-string v1, "duida"

    const/4 v5, 0x2

    const-string v1, "dpsda"

    const-string v1, "apdid"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v1, v0, Ld1/c;->c:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "ikemaddTnp"

    const-string v1, "apdidToken"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput-object v1, v0, Ld1/c;->d:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "yncyomepid"

    const-string/jumbo v1, "ydamicypen"

    const/4 v5, 0x1

    const-string/jumbo v1, "yKnidbymca"

    const-string v1, "dynamicKey"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v1, v0, Ld1/c;->g:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v1, "laInmrtvqtei"

    const/4 v5, 0x6

    const-string/jumbo v1, "rveInautmilt"

    const-string/jumbo v1, "timeInterval"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v4, 0x1

    iput-object v1, v0, Ld1/c;->h:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v1, "lwrcebrpU"

    const-string/jumbo v1, "rcsewlbUr"

    const/4 v5, 0x7

    const-string/jumbo v1, "lwcbeUtrq"

    const-string/jumbo v1, "webrtcUrl"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-object v1, v0, Ld1/c;->i:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-object v1, v0, Ld1/c;->j:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v1, "cmsShmiwd"

    const-string v1, "dhSmcwrim"

    const/4 v5, 0x6

    const-string v1, "drmSwitch"

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v1}, Lz0/a;->g(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-lez v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-object v2, v0, Ld1/c;->e:Ljava/lang/String;

    :cond_1
    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v3, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-lt v2, v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-object v1, v0, Ld1/c;->f:Ljava/lang/String;

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "ee_mpsoadreg"

    const-string/jumbo v1, "spdgor_edeea"

    const/4 v5, 0x0

    const-string v1, "apse_degrade"

    const/4 v4, 0x1

    move v5, v4

    invoke-interface {p0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast p0, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-object p0, v0, Ld1/c;->k:Ljava/lang/String;

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v0
.end method
