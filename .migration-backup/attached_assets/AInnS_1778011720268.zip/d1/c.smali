.class public Ld1/c;
.super Ld1/a;


# static fields
.field public static final l:I = 0x1

.field public static final m:I = 0x2

.field public static final n:I = 0x3

.field public static final o:Ljava/lang/String; = "APPKEY_ERROR"

.field public static final p:Ljava/lang/String; = "SUCCESS"


# instance fields
.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Ld1/a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Ld1/c;->k:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ s~t c oK.b iS @o~~/lt@4r~~~@@~ub@~@ ai ~  -f@@o/  @f @m~~ l~ y~~@o b~nd@@@v@~@~@@o@i~ ~~s~1@M "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-boolean v0, p0, Ld1/a;->a:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Ld1/c;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v0, "RsYmPKREO_RP"

    const-string v0, "KRsPEEOYRRP_"

    const/4 v4, 0x2

    const-string v0, "_OPYoEREKPAR"

    const-string v0, "APPKEY_ERROR"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Ld1/a;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    return v1
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const-string v0, "1"

    const/4 v3, 0x2

    const-string v0, "1"

    const-string v0, "1"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Ld1/c;->e:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Ld1/c;->f:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "0"

    const-string v0, "0"

    const/4 v2, 0x4

    const-string v0, "0"

    const-string v0, "0"

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method
