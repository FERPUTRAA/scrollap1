.class public final Le2/c;
.super Ljava/lang/Object;

# interfaces
.implements Le2/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le2/c$a;
    }
.end annotation


# static fields
.field public static final b:Le2/c$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:F


# instance fields
.field private final a:F


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v0, Le2/c$a;

    const/4 v1, 0x0

    and-int/2addr v3, v1

    xor-int/2addr v2, v1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Le2/c$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v0, Le2/c;->b:Le2/c$a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/high16 v0, 0x3f000000    # 0.5f

    const/4 v2, 0x4

    move v3, v2

    sput v0, Le2/c;->c:F

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 5
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, v2, v0, v1}, Le2/c;-><init>(FILkotlin/jvm/internal/w;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method public constructor <init>(F)V
    .locals 2
    .annotation build Lh8/i;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Le2/c;->a:F

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public synthetic constructor <init>(FILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v1, 0x4

    sget p1, Le2/c;->c:F

    :cond_0
    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0, p1}, Le2/c;-><init>(F)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 9
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~csK sui~~@ / vo ~i ~@  o~@ t~-n@  ~b 4/~m@ @l1@S~f@ ~~o~@@o~o~bt o ~d~~@@f.@@bM@ ~@y~ ~@@a@@lir"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    const-string/jumbo v0, "iewv"

    const-string v0, "eviw"

    const/4 v8, 0x4

    const-string/jumbo v0, "wvie"

    const-string/jumbo v0, "view"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v0, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-array v1, v0, [F

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget v2, p0, Le2/c;->a:F

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    aput v2, v1, v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    aput v4, v1, v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v5, "lsXmca"

    const-string/jumbo v5, "lcsaXe"

    const/4 v8, 0x1

    const-string v5, "cXseoa"

    const-string/jumbo v5, "scaleX"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1, v5, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-array v5, v0, [F

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget v6, p0, Le2/c;->a:F

    const/4 v8, 0x6

    const/4 v7, 0x4

    aput v6, v5, v3

    const/4 v7, 0x4

    const/4 v7, 0x5

    aput v4, v5, v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const-string v4, "Yslcmb"

    const-string v4, "ecYmsl"

    const/4 v8, 0x5

    const-string/jumbo v4, "uaeslY"

    const-string/jumbo v4, "scaleY"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p1, v4, v5}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance v4, Landroid/animation/AnimatorSet;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {v4}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v8, 0x7

    new-array v0, v0, [Landroid/animation/Animator;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v1, v0, v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    aput-object p1, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4, v0}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v8, 0x5

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4, v0, v1}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v4}, Landroid/animation/AnimatorSet;->start()V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void
.end method
