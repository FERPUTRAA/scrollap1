.class public final Le2/f;
.super Ljava/lang/Object;

# interfaces
.implements Le2/b;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/ s /~f~~.f4i b ~~~~@i@~ @M S@o~@ily~r vc~ Ko~oo ~@@ ~@st @~@@~@@ou@~ ~@@ @ -@~@ ~ babdn ~o~1@tl"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const-string/jumbo v0, "ievw"

    const-string/jumbo v0, "iewv"

    const/4 v4, 0x3

    const-string/jumbo v0, "weiv"

    const-string/jumbo v0, "view"

    const/4 v3, 0x7

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array v0, v0, [F

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    int-to-float v1, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    aput v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    aput v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "ttslsoinanXr"

    const/4 v4, 0x1

    const-string v1, "Xnnmtiltasro"

    const-string/jumbo v1, "translationX"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1, v1, v0}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v4, 0x5

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method
