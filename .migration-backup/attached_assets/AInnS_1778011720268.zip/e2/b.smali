.class public interface abstract Le2/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/View;)V
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method
