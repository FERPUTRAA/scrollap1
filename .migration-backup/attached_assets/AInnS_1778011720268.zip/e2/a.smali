.class public final Le2/a;
.super Ljava/lang/Object;

# interfaces
.implements Le2/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Le2/a$a;
    }
.end annotation


# static fields
.field public static final b:Le2/a$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:F


# instance fields
.field private final a:F


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Le2/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {v0, v1}, Le2/a$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    sput-object v0, Le2/a;->b:Le2/a$a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 5
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0, v2, v0, v1}, Le2/a;-><init>(FILkotlin/jvm/internal/w;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method public constructor <init>(F)V
    .locals 2
    .annotation build Lh8/i;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Le2/a;->a:F

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public synthetic constructor <init>(FILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    sget p1, Le2/a;->c:F

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Le2/a;-><init>(F)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s l~~ @~~@ 1@@@v.  ~@r/~f@~~io~@   @~~-ub~cdn@o~@~K M~m@s~fol~  b @~by  ~@ @  i@@o~a~@St/4o@to"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "iwve"

    const-string/jumbo v0, "vwie"

    const/4 v4, 0x1

    const-string/jumbo v0, "veiw"

    const-string/jumbo v0, "view"

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-array v0, v0, [F

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, p0, Le2/a;->a:F

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    aput v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput v2, v0, v1

    const/4 v4, 0x7

    const-string v1, "ahamp"

    const-string/jumbo v1, "pasha"

    const/4 v4, 0x5

    const-string v1, "ahlao"

    const-string v1, "alpha"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, v1, v0}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v4, 0x4

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method
