.class public interface abstract Ll1/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)V
.end method
