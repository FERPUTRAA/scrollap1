.class public Ll1/a;
.super Ljava/lang/Object;

# interfaces
.implements Ll1/c;


# instance fields
.field private a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/ImageView;",
            ">;"
        }
    .end annotation
.end field

.field private b:[I

.field private c:Ll1/c;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;[I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Landroid/widget/ImageView;",
            ">;[I)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Ll1/a;->a:Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Ll1/a;->b:[I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ms@@ @i@@~~a@o@r bd f @l~l~~So ot~~~t b@v @@@f-K~~@ m@  ~i@i@~@o ~ 4~ yc~on@~1u@/~~~@so  b~ ~/."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Ll1/a;->c:Ll1/c;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2, p3}, Ll1/c;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public b(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Ll1/a;->c:Ll1/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Ll1/c;->b(Landroidx/recyclerview/widget/RecyclerView;I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public c(Ll1/c;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Ll1/a;->c:Ll1/c;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public onPageSelected(I)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x3

    move v6, v5

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v2, p0, Ll1/a;->a:Ljava/util/ArrayList;

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    if-ge v1, v2, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v2, p0, Ll1/a;->a:Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast v2, Landroid/widget/ImageView;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v3, p0, Ll1/a;->b:[I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x5

    aget v3, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v5, 0x3

    move v6, v5

    if-eq p1, v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Ll1/a;->a:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    check-cast v2, Landroid/widget/ImageView;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v3, p0, Ll1/a;->b:[I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    aget v3, v3, v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Ll1/a;->c:Ll1/c;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0, p1}, Ll1/c;->onPageSelected(I)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void
.end method
