.class public Lf3/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lp2/a;
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "MTCorePrivatesApi"

.field public static final b:I = 0x1b3
    .annotation build Lp2/a;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "4.3.5"
    .annotation build Lp2/a;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/ns@ d~@1@-i@s @or@t~ u ~oc @ b  ~@~@~~@i~ ab@~ @fK@ .o@~~~@ ~t~~~@f~~~m@b~MSv@@lil 4oy/  ~o~o@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const-string/jumbo v0, "seomrMiPAeTrstCav"

    const-string/jumbo v0, "resTasApvCtoPeMri"

    const/4 v3, 0x3

    const-string v0, "AtCporosPiTieeMva"

    const-string v0, "MTCorePrivatesApi"

    const/4 v2, 0x7

    and-int/2addr v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo p0, "leaAhbpeucltaclces ntncoCcmn /i o elhben tfpxekin  pa/nt"

    const-string/jumbo p0, "xecmot hn  h kacnitlcnelgAe sibte/a/latncpfplCe copnneu "

    const/4 v3, 0x6

    const-string p0, "gaao/futA xh Ce nicne h  /alpipnee,blluctcenkctne tnspco"

    const-string p0, "configAppChannel context can\'t be null, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p0, "eAa n Cpcppo ppahn  itk tblehnahcCeaptcn /lfpnoi,seaee/gcyln"

    const-string p0, "c e o ptCpppkethn gCie/ iela abAnhhtnypanasfnaeeonmlclc/ cp,"

    const/4 v3, 0x1

    const-string p0, "configAppChannel appChannel can\'t be empty, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "nlnca_cpqpghefia_n"

    const-string/jumbo v1, "n_lhibnecnafgpa_cp"

    const/4 v3, 0x6

    const-string v1, "hpsgapnfacincneol_"

    const-string v1, "config_app_channel"

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v1, 0x8ba

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0, v1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x2

    invoke-static {p1}, Ly2/b;->D(Ljava/lang/String;)V

    const/4 v3, 0x0

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v0, "tuAmPeaorCviispre"

    const-string/jumbo v0, "riavspuCoreePitMA"

    const/4 v3, 0x4

    const-string v0, "etCiosoPMiarveATp"

    const-string v0, "MTCorePrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p0, "xttheKepeikllcfaslnytg e,pcu n  ptcaA ncne/ o/oicb e"

    const/4 v3, 0x5

    const-string/jumbo p0, "t ecyb, lgbhopAucnfi k pna e Keetc easitlo/nlcetcnp/"

    const-string p0, "configAppKey context can\'t be null, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    move v3, v2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const-string/jumbo p0, "y/Kei ubfeepp/tpAp ieeca ty amcp,tnnqhc  sK okleagep"

    const-string p0, "blpec taqpcyiKp peks  iee/gcn  mftecoKhey ,papatneA/"

    const/4 v3, 0x4

    const-string p0, "configAppKey appKey can\'t be empty, please check it"

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x4

    const-string/jumbo v1, "nyoigsapf_eppc"

    const-string v1, "cpsfpa_inykeog"

    const/4 v3, 0x3

    const-string v1, "c_fgpaonqykei_"

    const-string v1, "config_app_key"

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v1, 0x8ba

    const/4 v3, 0x7

    invoke-static {p0, v1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Ly2/b;->E(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const-string v0, "PTsmtsMiverrpCAae"

    const-string v0, "APemsoMeritaTCprv"

    const/4 v3, 0x5

    const-string v0, "MTCorePrivatesApi"

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const-string p0, "cacmhlat,psfclonueee itm Spk og  lepeineetx/ cntNtia/nobc"

    const-string p0, "hekto  nenxi,ctspctbN pe/laccmeSoon/f lnceuaplti eeait g "

    const/4 v3, 0x7

    const-string/jumbo p0, "pneeoelbnccsoane otkhel t Suxf/imtpatnc tipl,eN ciacA e /"

    const-string p0, "configAppSiteName context can\'t be null, please check it"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p0, "ebpypbega,A mnnc t/sheeiS lpefpNptNak act eoebamaSc pi/ticete "

    const-string p0, "egAc beec pieisyppttS cmabftpeeehatpi iaN N/k St/nnl epeo,mcaa"

    const/4 v3, 0x1

    const-string p0, "  kecbum aticpceymsm,htpitaNe pia taNplpftee /SAc geeienpeSan/"

    const-string p0, "configAppSiteName appSiteName can\'t be empty, please check it"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "ug_mtfep_cn_iaappnse"

    const-string/jumbo v1, "mpnaoiuegna__fc_etps"

    const/4 v3, 0x2

    const-string/jumbo v1, "p_geomnaqnetis_i_fca"

    const-string v1, "config_app_site_name"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/16 v1, 0x8ba

    const/4 v3, 0x0

    invoke-static {p0, v1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Ly2/b;->F(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public static d(Landroid/content/Context;I)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Lh3/b;->r(I)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Lh3/b;->r(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public static e(Landroid/content/Context;Z)V
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Ly2/b;->I(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v1, "dgsmbc_dofngpiueo"

    const-string v1, "__coguopdmgibedfn"

    const/4 v3, 0x7

    const-string v1, "config_debug_mode"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x8ba

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, v1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Ly2/b;->I(Z)V

    const/4 v2, 0x7

    move v3, v2

    return-void
.end method

.method public static f(Landroid/content/Context;J)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lh3/b;->s(J)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lh3/b;->s(J)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static g(Landroid/content/Context;)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo p0, "teamCPpoqeiiTvrMA"

    const-string/jumbo p0, "rCMtpaTPqirieovAe"

    const/4 v2, 0x2

    const-string p0, "MCTsoiopevPitaerA"

    const-string p0, "MTCorePrivatesApi"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "  sce//x ,ni ealctpcsilo4behuf  tnnSl eccgntoMaet"

    const/4 v2, 0x2

    const-string v0, "configSM4 context can\'t be null, please check it"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0}, Ly2/b;->K(I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static h(Landroid/content/Context;Z)V
    .locals 3
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string p0, "eivMebpsCrAPTorti"

    const-string p0, "eAtmCPrerioMTsvpi"

    const/4 v2, 0x4

    const-string p0, "aPpeoruevrisCATMt"

    const-string p0, "MTCorePrivatesApi"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p1, "ete  kgp/ol/nf koeksnl thaAteicaa nientc bW,ceeBlpaccWxnoue"

    const-string/jumbo p1, "xcn o ta lsecgoecbelAdounncnciae klha, efWtpWBtkn akeei/et/"

    const-string p1, "//leAxccqeaepWknn loenhnbcence oifsa tikutg t BeaWae c,kl d"

    const-string p1, "configWakeAndBeWake context can\'t be null, please check it"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1}, Lh3/b;->D(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public static i(Landroid/content/Context;)I
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo p0, "vpstreieMrPbCsioA"

    const-string p0, "aeoevbiPApitMrsCr"

    const/4 v3, 0x7

    const-string/jumbo p0, "oMtmpePariATeCsrv"

    const-string p0, "MTCorePrivatesApi"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "elteoot g ikaetpcL/lc tebduliaC ogn,/xnho ence  tceu"

    const-string v1, "et ,teultkcchoil/ic bu n/eexCocaeln gegLnna to petd "

    const/4 v3, 0x7

    const-string v1, "eant,bpoilt/a/tenc oC  dticecsxn o eeunclbktlhgeg  L"

    const-string v1, "getLoginCode context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    invoke-static {p0}, Lh3/b;->f(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0}, Lo2/q;->u(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return p0

    :cond_2
    return v0
.end method

.method public static j(Landroid/content/Context;)Ljava/lang/String;
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string p0, "CiPaoMutrrspeTAvi"

    const-string/jumbo p0, "sPrvArapiieCTptMo"

    const/4 v3, 0x0

    const-string p0, "TvoeaAspCietpPrrM"

    const-string p0, "MTCorePrivatesApi"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, " qcxne  qePugl sotcd,o /tt/enapwnlec c eathakslebrt"

    const-string/jumbo v1, "t,sltPepqdnrkxtu/bac elgneo/etahc   scecew   lotsan"

    const/4 v3, 0x4

    const-string v1, "/ sudths xnsc lew apnlPblogercieecek/ ttn ac astote"

    const-string v1, "getPassword context can\'t be null, please check it"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0}, Lh3/b;->i(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-static {p0}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public static k(Landroid/content/Context;)I
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p0, "piMmsAPtTsriCaove"

    const-string p0, "CtssreTivAMPiapro"

    const/4 v3, 0x2

    const-string/jumbo p0, "risPorAvatpMeCoei"

    const-string p0, "MTCorePrivatesApi"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "Cdtxrbe, segk eR elaet e l s/o nntoceuatecitpbtglcehmni"

    const-string/jumbo v1, "ukoms/ecbi sh  cc ,gn dxaelltetteaoel nRtgCnieteprce te"

    const/4 v3, 0x5

    const-string v1, "eecnisueetbca h srtnxloeeltRi tdCtggkpa /nu ,ce oleec /"

    const-string v1, "getRegisterCode context can\'t be null, please check it"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x0

    invoke-static {p0}, Lh3/b;->k(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_2

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lo2/q;->y(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p0

    :cond_2
    const/4 v3, 0x7

    return v0
.end method

.method public static l(Landroid/content/Context;)Ljava/lang/String;
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p0, "PeMostTprrvpiaAeC"

    const-string/jumbo p0, "irpAoeaCTtorsMePv"

    const/4 v3, 0x4

    const-string p0, "CApaMPerqtiosrvei"

    const-string p0, "MTCorePrivatesApi"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "nksee Ir/ptshoe e  i bclclacgtx gncbunli/saeedet,ttotR in"

    const-string v1, "ctetnbetgti/rl onll Regc nedteoa sbc pkixs eIht,antu/ci e"

    const-string v1, "getRegistrationId context can\'t be null, please check it"

    const/4 v3, 0x5

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0}, Lh3/b;->l(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0}, Lo2/q;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    return-object p0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public static m(Landroid/content/Context;)I
    .locals 4
    .annotation build Lp2/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo p0, "vCtmeeprMairosAPi"

    const-string p0, "MTCorePrivatesApi"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "otesohcxleStue/gtneienlkue dbctec/Idt nc  apa,l  "

    const-string v1, " Saeiluxc blkec gotu/ed tehtnsctnp e d/,ea Itenlc"

    const-string v1, "eS dtbetelcncelbu/ho kp a, tIcag n secextn et/lid"

    const-string v1, "getSeedId context can\'t be null, please check it"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Lh3/b;->n(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    return p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->A(Landroid/content/Context;)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    return p0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v0
.end method

.method public static n(Landroid/content/Context;)J
    .locals 5
    .annotation build Lp2/a;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p0, "ppMiseuetvrPoirAT"

    const-string p0, "MeiAvCopriretTspP"

    const/4 v4, 0x6

    const-string p0, "PersptipeCMArvaTo"

    const-string p0, "MTCorePrivatesApi"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "sa/hcc iqxeeertvte brtlen  ,nnei/ceStTtlceolqua  gp k"

    const-string v2, "b/hke roqttel/ecteS lca nepineegei lvcx ctne,T ur sta"

    const/4 v4, 0x2

    const-string v2, "Teselkiuntnnciecc/exeet  es  vmttagcrlSb o,/rpahete l"

    const-string v2, "getServerTime context can\'t be null, please check it"

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-static {p0, v2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-wide v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v2}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p0}, Lh3/b;->o(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-wide v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v2}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p0}, Lo2/q;->B(Landroid/content/Context;)J

    move-result-wide v0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-wide v0
.end method

.method public static o(Landroid/content/Context;)J
    .locals 5
    .annotation build Lp2/a;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo p0, "viTmsotpeaMPAsier"

    const-string/jumbo p0, "rrsievapPtoiTseMA"

    const/4 v4, 0x6

    const-string/jumbo p0, "oMaropPsvtCAiieTe"

    const-string p0, "MTCorePrivatesApi"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v2, "erh ebg/c neetIm  postenxidt etuacnl lb,eU/actks "

    const-string v2, "ctem/peeascr ttsgxnaenlU , oItuecd/t  lnbeck eih "

    const/4 v4, 0x4

    const-string v2, "ctc tlucihbeleu xIegekar nd staUt neeo pt cel/sn,"

    const-string v2, "getUserId context can\'t be null, please check it"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0, v2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-wide v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v2}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v2, :cond_1

    const/4 v3, 0x4

    move v4, v3

    invoke-static {p0}, Lh3/b;->p(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-wide v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v2}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-wide v0
.end method

.method public static p(Landroid/content/Context;)Z
    .locals 6
    .annotation build Lp2/a;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x6

    const-string p0, "MCvATpeprtrseiPia"

    const-string p0, "eivsorrAatCMpeiTP"

    const/4 v5, 0x7

    const-string p0, "CMripiaeqsTerPvtA"

    const-string p0, "MTCorePrivatesApi"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v1, "bcsac ie/nCoentn l hnexnsttC eactke npueu,i nl eoloi/stcc"

    const-string/jumbo v1, "tt ncbcseannpelo/oln /,etiC csb eaitnunckloei uCtexnche  "

    const/4 v5, 0x0

    const-string/jumbo v1, "uocme nteintccnp nCnel/tnttculeoksa,e ilax sh/enC oe tbci"

    const-string/jumbo v1, "isConnectContinue context can\'t be null, please check it"

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-nez p0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p0, p0, Lc3/a;->b:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x4

    const-string v2, "aeunosv.PuicbtpspshTomlgaeur.hM.ga"

    const-string v2, "a.pcnguerMlaavip.euehhtgbsmPos.uTs"

    const/4 v5, 0x5

    const-string v2, "com.engagelab.privates.push.MTPush"

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v3

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "ecaesbbseegMmemlgasreM.pasngTti.e.aao.pg"

    const-string v2, "..saeeapmssMomean.ebel.cagartegMvsTegigp"

    const/4 v5, 0x0

    const-string v2, "elec.guesteMna.ve.aboMpgsasTsgseieamrmg."

    const-string v2, "com.engagelab.privates.message.MTMessage"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v3

    :cond_4
    const/4 v4, 0x5

    const/4 v5, 0x5

    return v0
.end method

.method public static q(I)V
    .locals 2
    .annotation build Lp2/a;
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    if-ltz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    sput p0, Lo2/p;->c:I

    :cond_0
    const/4 v1, 0x5

    return-void
.end method

.method public static r(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    sget-boolean v0, Ly2/b;->b:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "i_cfsqip_gsno"

    const-string/jumbo v1, "scofnil_qis_g"

    const/4 v3, 0x0

    const-string/jumbo v1, "sos_fscgqnil_"

    const-string v1, "config_is_ssl"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x8ba

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, v1, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1}, Ly2/b;->Q(Z)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public static s(Z)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lp2/c;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    sget-boolean v0, Ly2/b;->b:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0}, Ly2/b;->Q(Z)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public static t(Landroid/content/Context;Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lp2/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lf3/a;->h(Landroid/content/Context;Z)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static u(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "vrsTCtisoPAsereai"

    const-string v0, "PssAeipaerTtCviro"

    const/4 v3, 0x4

    const-string/jumbo v0, "seamPTtvrepiirMoA"

    const-string v0, "MTCorePrivatesApi"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo p0, "nicoo ls,n/eotfpegcCx legGel/ lnttu oecbee tcitoka sm ha"

    const-string/jumbo p0, "neomncsa  paellGs tictxlCeot eeknl/ei/to tncg,o bh eufgc"

    const/4 v3, 0x7

    const-string p0, "c, o bnohC testentc sltleGaen/c ickgunte  eloaipbxe/tolf"

    const-string/jumbo p0, "testConfigGoogle context can\'t be null, please check it"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Ly2/b;->C(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo p0, "ioCC dut nnrniodoaees vo eegs odhsoasonfeGrigvtylaith lguegbul,tcna eeeeg s n,erpinese  lnl  lot eb"

    const-string/jumbo p0, "ld tonv ohlsatehloeud e nniCoG,Cgailofeegingtyn rerg ctbtn eepa ree   e,vi ui se oebsosnaolss elgnd"

    const/4 v3, 0x6

    const-string/jumbo p0, "ue fo ipa egguCaego  yesesahlenrna lisnt,bddotrtlepne glsesi ninol cio ee httnovs Gneoeb gl v erdo,"

    const-string/jumbo p0, "testConfigGoogle, Can only be used in the debugging version, please do not call the release version"

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p0, "NC"

    const-string p0, "CN"

    const/4 v3, 0x5

    const-string p0, "CN"

    const-string p0, "CN"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0}, Ly2/b;->G(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p0, "SU"

    const-string p0, "US"

    const/4 v3, 0x6

    const-string p0, "SU"

    const-string p0, "US"

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {p0}, Ly2/b;->G(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
