.class public Lf3/b;
.super Ljava/lang/Object;


# annotations
.annotation build Lp2/b;
.end annotation


# instance fields
.field private a:[B

.field private b:I

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/16 v0, 0x20

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lf3/b;-><init>(I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-array p1, p1, [B

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lf3/b;->a:[B

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lf3/b;->b:I

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v1, 0x4

    xor-int/2addr v0, p1

    const/4 v1, 0x5

    iput p1, p0, Lf3/b;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method private a(JI)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "u sKo4cm /- ~@~i~@~ ~@~bt~~s~@l~~ ~.o @1~ @~@ yS@@~ ~@ ~@/@ol@@~@~ovo ~ta@if@ @riobn@df~   b ~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    return-void
.end method

.method private d(I)V
    .locals 5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    array-length v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v2, p0, Lf3/b;->b:I

    const/4 v4, 0x2

    sub-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-lt v1, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    array-length v1, v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    mul-int/lit8 v1, v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    add-int/2addr p1, v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ge v1, p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    move v1, p1

    move v1, p1

    const/4 v4, 0x7

    move v1, p1

    move v1, p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-array p1, v1, [B

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, v1, p1, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x1

    and-int/2addr v4, v3

    iput-object p1, p0, Lf3/b;->a:[B

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method


# virtual methods
.method public b()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget v0, p0, Lf3/b;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public c(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lf3/b;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-gt p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput p1, p0, Lf3/b;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string/jumbo v0, "nsama ajon m ofa s ttppundtc"

    const-string v0, "c sn atd tpt sjnmfadoo paanu"

    const/4 v2, 0x1

    const-string/jumbo v0, "ntnuo a  jpaopfdo  scenmadta"

    const-string v0, "cannot jump past end of data"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x0

    iget v0, p0, Lf3/b;->c:I

    const/4 v3, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput v0, p0, Lf3/b;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput v0, p0, Lf3/b;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v1, "eov ubisonepmsat "

    const-string/jumbo v1, "ut mtspesiooan ev"

    const/4 v3, 0x0

    const-string v1, " rin auoevtestoup"

    const-string/jumbo v1, "no previous state"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw v0
.end method

.method public f()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    iget v0, p0, Lf3/b;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lf3/b;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public g()[B
    .locals 6

    const/4 v5, 0x2

    iget v0, p0, Lf3/b;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-array v1, v0, [B

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Lf3/b;->a:[B

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x3

    shr-int/2addr v4, v3

    const/4 v5, 0x3

    invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x6

    move v5, v4

    return-object v1
.end method

.method public h([B)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    array-length v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, p1, v1, v0}, Lf3/b;->i([BII)V

    const/4 v2, 0x4

    move v3, v2

    return-void
.end method

.method public i([BII)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p3}, Lf3/b;->d(I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v2, 0x5

    move v3, v2

    iget v1, p0, Lf3/b;->b:I

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget p1, p0, Lf3/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/2addr p1, p3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput p1, p0, Lf3/b;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public j([B)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    array-length v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lf3/b;->l(I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    array-length v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1, v1, v0}, Lf3/b;->i([BII)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public k([B)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    array-length v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v1, 0xff

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-gt v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {p0, v0}, Lf3/b;->d(I)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v2, p0, Lf3/b;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-int/lit8 v3, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput v3, p0, Lf3/b;->b:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    array-length v3, p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    and-int/2addr v1, v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    int-to-byte v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    aput-byte v1, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v1, v0}, Lf3/b;->i([BII)V

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v0, "dneortgpuntcvo sIi iad"

    const-string v0, "gitdo nuIidtaesncnr ov"

    const/4 v5, 0x6

    const-string/jumbo v0, "tid vgdlqsnnrute cnoIa"

    const-string v0, "Invalid counted string"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    throw p1
.end method

.method public l(I)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    int-to-long v0, p1

    const/4 v4, 0x0

    move v5, v4

    const/16 v2, 0x10

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p0, v0, v1, v2}, Lf3/b;->a(JI)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x2

    move v5, v0

    const/4 v4, 0x5

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lf3/b;->d(I)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget v1, p0, Lf3/b;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    ushr-int/lit8 v3, p1, 0x8

    const/4 v5, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    int-to-byte v3, v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput-byte v3, v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/lit8 v1, v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v1, p0, Lf3/b;->b:I

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    and-int/lit16 p1, p1, 0xff

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    int-to-byte p1, p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    aput-byte p1, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method

.method public m(II)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    int-to-long v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/16 v2, 0x10

    const/4 v4, 0x6

    invoke-direct {p0, v0, v1, v2}, Lf3/b;->a(JI)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v0, p0, Lf3/b;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x2

    const/4 v4, 0x0

    const/4 v3, 0x0

    if-gt p2, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    add-int/lit8 v1, p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    ushr-int/lit8 v2, p1, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    and-int/lit16 v2, v2, 0xff

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-byte v2, v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    aput-byte v2, v0, p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    and-int/lit16 p1, p1, 0xff

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    int-to-byte p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput-byte p1, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo p2, "iesapwo adtnan b totnecd at r"

    const-string/jumbo p2, "tndaobwonept   ana citsrae td"

    const/4 v4, 0x4

    const-string p2, "aeemctnanpdttrwoaaino f  s  d"

    const-string p2, "cannot write past end of data"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw p1
.end method

.method public n(J)V
    .locals 9

    const/4 v7, 0x0

    move v8, v7

    const/16 v0, 0x20

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-direct {p0, p1, p2, v0}, Lf3/b;->a(JI)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v0, 0x4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0, v0}, Lf3/b;->d(I)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget v1, p0, Lf3/b;->b:I

    const/4 v8, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/16 v3, 0x18

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    ushr-long v3, p1, v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v8, 0x6

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    and-long/2addr v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    long-to-int v3, v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    int-to-byte v3, v3

    const/4 v7, 0x5

    const/4 v8, 0x3

    aput-byte v3, v0, v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    add-int/lit8 v1, v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/16 v3, 0x10

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    ushr-long v3, p1, v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    and-long/2addr v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    long-to-int v3, v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    int-to-byte v3, v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    aput-byte v3, v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    add-int/lit8 v2, v1, 0x1

    const/4 v7, 0x7

    move v8, v7

    const/16 v3, 0x8

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    ushr-long v3, p1, v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    and-long/2addr v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    long-to-int v3, v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    int-to-byte v3, v3

    const/4 v8, 0x2

    aput-byte v3, v0, v1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    add-int/lit8 v1, v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput v1, p0, Lf3/b;->b:I

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    and-long/2addr p1, v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    long-to-int p1, p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    int-to-byte p1, p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    aput-byte p1, v0, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-void
.end method

.method public o(JI)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/16 v0, 0x20

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p0, p1, p2, v0}, Lf3/b;->a(JI)V

    const/4 v7, 0x3

    iget v0, p0, Lf3/b;->b:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    add-int/lit8 v0, v0, -0x4

    const/4 v7, 0x6

    if-gt p3, v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    add-int/lit8 v1, p3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/16 v2, 0x18

    const/4 v7, 0x4

    ushr-long v2, p1, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const/4 v7, 0x0

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const/4 v7, 0x0

    and-long/2addr v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    long-to-int v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    int-to-byte v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    aput-byte v2, v0, p3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    add-int/lit8 p3, v1, 0x1

    const/4 v7, 0x4

    const/16 v2, 0x10

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    ushr-long v2, p1, v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    and-long/2addr v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    long-to-int v2, v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    int-to-byte v2, v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    aput-byte v2, v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/lit8 v1, p3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 v2, 0x8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    ushr-long v2, p1, v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    and-long/2addr v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    long-to-int v2, v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    int-to-byte v2, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    aput-byte v2, v0, p3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    and-long/2addr p1, v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    long-to-int p1, p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    int-to-byte p1, p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    aput-byte p1, v0, v1

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string p2, "eaanor tcteftani a wd do psun"

    const-string/jumbo p2, "ncfnttusdwan  tiaoaerd  aeo p"

    const/4 v7, 0x6

    const-string p2, " ctrwb nfadate enianota  spdt"

    const-string p2, "cannot write past end of data"

    const/4 v7, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    throw p1
.end method

.method public p(J)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/16 v0, 0x8

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {p0, v0}, Lf3/b;->d(I)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v1, p0, Lf3/b;->a:[B

    const/4 v9, 0x6

    const/4 v8, 0x0

    iget v2, p0, Lf3/b;->b:I

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-int/lit8 v3, v2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/16 v4, 0x38

    const/4 v9, 0x1

    const/4 v8, 0x2

    ushr-long v4, p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-wide/16 v6, 0xff

    const-wide/16 v6, 0xff

    const/4 v9, 0x7

    const-wide/16 v6, 0xff

    const-wide/16 v6, 0xff

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    and-long/2addr v4, v6

    const/4 v8, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    long-to-int v4, v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    int-to-byte v4, v4

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    aput-byte v4, v1, v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    add-int/lit8 v2, v3, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/16 v4, 0x30

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    ushr-long v4, p1, v4

    const/4 v9, 0x2

    and-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    long-to-int v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    int-to-byte v4, v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    aput-byte v4, v1, v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/lit8 v3, v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/16 v4, 0x28

    const/4 v9, 0x3

    const/4 v8, 0x6

    ushr-long v4, p1, v4

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    and-long/2addr v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x2

    long-to-int v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x0

    int-to-byte v4, v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    aput-byte v4, v1, v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    add-int/lit8 v2, v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/16 v4, 0x20

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    ushr-long v4, p1, v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    and-long/2addr v4, v6

    const/4 v9, 0x1

    long-to-int v4, v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    int-to-byte v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    aput-byte v4, v1, v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    add-int/lit8 v3, v2, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/16 v4, 0x18

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    ushr-long v4, p1, v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    and-long/2addr v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    long-to-int v4, v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    int-to-byte v4, v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    aput-byte v4, v1, v2

    const/4 v9, 0x0

    const/4 v8, 0x7

    add-int/lit8 v2, v3, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/16 v4, 0x10

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    ushr-long v4, p1, v4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    and-long/2addr v4, v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    long-to-int v4, v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    int-to-byte v4, v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    aput-byte v4, v1, v3

    const/4 v9, 0x7

    add-int/lit8 v3, v2, 0x1

    const/4 v8, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    ushr-long v4, p1, v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    and-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x0

    long-to-int v0, v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    int-to-byte v0, v0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    aput-byte v0, v1, v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    add-int/lit8 v0, v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    iput v0, p0, Lf3/b;->b:I

    const/4 v8, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    and-long/2addr p1, v6

    const/4 v9, 0x4

    long-to-int p1, p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    int-to-byte p1, p1

    const/4 v8, 0x2

    move v9, v8

    aput-byte p1, v1, v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-void
.end method

.method public q(JI)V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/16 v0, 0x40

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {p0, p1, p2, v0}, Lf3/b;->a(JI)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget v0, p0, Lf3/b;->b:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/16 v1, 0x8

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    sub-int/2addr v0, v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-gt p3, v0, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    add-int/lit8 v2, p3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/16 v3, 0x38

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    ushr-long v3, p1, v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v8, 0x6

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v8, 0x2

    const/4 v7, 0x7

    and-long/2addr v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    long-to-int v3, v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    int-to-byte v3, v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    aput-byte v3, v0, p3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    add-int/lit8 p3, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/16 v3, 0x30

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    ushr-long v3, p1, v3

    const/4 v7, 0x2

    move v8, v7

    and-long/2addr v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    long-to-int v3, v3

    const/4 v7, 0x3

    and-int/2addr v8, v7

    int-to-byte v3, v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-byte v3, v0, v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    add-int/lit8 v2, p3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/16 v3, 0x28

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    ushr-long v3, p1, v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    and-long/2addr v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    long-to-int v3, v3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    int-to-byte v3, v3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    aput-byte v3, v0, p3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    add-int/lit8 p3, v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/16 v3, 0x20

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    ushr-long v3, p1, v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    and-long/2addr v3, v5

    const/4 v8, 0x3

    long-to-int v3, v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    int-to-byte v3, v3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    aput-byte v3, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-int/lit8 v2, p3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/16 v3, 0x18

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    ushr-long v3, p1, v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    and-long/2addr v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    long-to-int v3, v3

    const/4 v8, 0x3

    const/4 v7, 0x7

    int-to-byte v3, v3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    aput-byte v3, v0, p3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    add-int/lit8 p3, v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/16 v3, 0x10

    const/4 v8, 0x1

    const/4 v7, 0x7

    ushr-long v3, p1, v3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    and-long/2addr v3, v5

    long-to-int v3, v3

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    int-to-byte v3, v3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    aput-byte v3, v0, v2

    const/4 v8, 0x4

    add-int/lit8 v2, p3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x0

    ushr-long v3, p1, v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    and-long/2addr v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    long-to-int v1, v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    int-to-byte v1, v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    aput-byte v1, v0, p3

    const/4 v8, 0x1

    and-long/2addr p1, v5

    const/4 v8, 0x2

    long-to-int p1, p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    int-to-byte p1, p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    aput-byte p1, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo p2, "pteaonuowcae at irdtna d tn f"

    const-string p2, "cannot write past end of data"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    throw p1
.end method

.method public r(I)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    int-to-long v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v2, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0, v0, v1, v2}, Lf3/b;->a(JI)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lf3/b;->d(I)V

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lf3/b;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v2, p0, Lf3/b;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    and-int/lit16 p1, p1, 0xff

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    int-to-byte p1, p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    aput-byte p1, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method

.method public s(II)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    int-to-long v0, p1

    const/4 v3, 0x7

    move v4, v3

    const/16 v2, 0x8

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0, v0, v1, v2}, Lf3/b;->a(JI)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v0, p0, Lf3/b;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-gt p2, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lf3/b;->a:[B

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    and-int/lit16 p1, p1, 0xff

    const/4 v4, 0x6

    int-to-byte p1, p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    aput-byte p1, v0, p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    move v4, v3

    const-string p2, "acnp nepotdo nstftaead  atpw "

    const-string/jumbo p2, "sonaea ppanno ietcdwtdf ta  t"

    const/4 v4, 0x1

    const-string p2, " orsiaaoqftp e twaannde cntd "

    const-string p2, "cannot write past end of data"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    throw p1
.end method
