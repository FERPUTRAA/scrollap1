.class public final Lg1/b;
.super Ljava/lang/Object;

# interfaces
.implements Lh1/b;


# instance fields
.field private final a:Landroid/content/Context;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "xnsttosC"

    const-string/jumbo v0, "xostnteC"

    const/4 v2, 0x2

    const-string/jumbo v0, "tonmtmex"

    const-string/jumbo v0, "mContext"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lg1/b;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private final d()Landroid/graphics/Point;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@o @l~ m t i~  ~o@bo-b~d@ @b~@~@to~~~@@/@  i~~ u forM K1i@@av ~@S~~@~@n ~~~o@os4@~y@f~ .~c/@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Landroid/graphics/Point;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lg1/b;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v2, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v2, v0, Landroid/graphics/Point;->x:I

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v1, v0, Landroid/graphics/Point;->y:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 6

    const/4 v5, 0x2

    iget-object v0, p0, Lg1/b;->a:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v1, "biemn"

    const-string v1, "einmm"

    const/4 v5, 0x6

    const-string v1, "eunmi"

    const-string v1, "dimen"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string/jumbo v2, "prdandi"

    const-string v2, "adrdoni"

    const/4 v5, 0x6

    const-string/jumbo v2, "iqnddor"

    const-string v2, "android"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, "hgsvha_tbibargionnaet"

    const-string v3, "gaitabnhirnbtoahgi_ev"

    const/4 v5, 0x3

    const-string/jumbo v3, "o_emharvtniaitgabg_hn"

    const-string/jumbo v3, "navigation_bar_height"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-lez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lg1/b;->a:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x3

    move v4, v0

    move v4, v0

    :goto_0
    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Lg1/b;->d()Landroid/graphics/Point;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, v0, Landroid/graphics/Point;->y:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lg1/b;->d()Landroid/graphics/Point;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget v0, v0, Landroid/graphics/Point;->x:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method
