.class public final Lg1/a;
.super Ljava/lang/Object;

# interfaces
.implements Lh1/a;


# instance fields
.field private final a:Landroid/content/res/TypedArray;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;[I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "nsscteo"

    const-string/jumbo v0, "xoscnet"

    const-string/jumbo v0, "tnomxec"

    const-string v0, "context"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "lReyotme"

    const-string v0, "Rtsmyeel"

    const/4 v2, 0x1

    const-string/jumbo v0, "ltsRebsy"

    const-string/jumbo v0, "styleRes"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string p2, "auclaoues.Re noStybstttyelsAteioiet(ttxt,rdt)ns"

    const-string/jumbo p2, "tn,ooeea.l isS)(ysicletdertesxbtAtRrtuttynstaot"

    const/4 v2, 0x6

    const-string p2, "context.obtainStyledAttributes(attrs, styleRes)"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lg1/a;->a:Landroid/content/res/TypedArray;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~l/p~@tb v@-@bi~~s~i~aMS~@o~ nobc~@ ~@ /@ ~ ~@l@o@@~~ @iu@mf@1~f o t~oKy~ @@@r~ ~  d ~4.o@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lg1/a;->a:Landroid/content/res/TypedArray;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public b(I)I
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lg1/a;->a:Landroid/content/res/TypedArray;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p1
.end method
