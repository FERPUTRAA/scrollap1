.class public interface abstract Lg3/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "config_app_key"

.field public static final b:Ljava/lang/String; = "config_app_channel"

.field public static final c:Ljava/lang/String; = "config_app_site_name"

.field public static final d:Ljava/lang/String; = "config_is_ssl"

.field public static final e:Ljava/lang/String; = "config_debug_mode"
