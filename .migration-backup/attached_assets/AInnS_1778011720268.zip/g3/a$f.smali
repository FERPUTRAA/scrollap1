.class public interface abstract Lg3/a$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lg3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "f"
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "code"

.field public static final b:Ljava/lang/String; = "user_id"

.field public static final c:Ljava/lang/String; = "registration_id"

.field public static final d:Ljava/lang/String; = "password"
