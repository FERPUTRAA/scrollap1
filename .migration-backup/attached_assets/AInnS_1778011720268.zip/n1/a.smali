.class public final Ln1/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "com.bigkoo.pickerview"

.field public static final c:Ljava/lang/String; = "com.bigkoo.pickerview"
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "release"

.field public static final e:Ljava/lang/String; = ""

.field public static final f:I = 0x22

.field public static final g:Ljava/lang/String; = "4.1.9"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method
