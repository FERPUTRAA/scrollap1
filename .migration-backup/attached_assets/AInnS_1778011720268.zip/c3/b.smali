.class public abstract Lc3/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public abstract a(Landroid/content/Context;ILandroid/os/Bundle;)V
.end method

.method public b()S
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "M~sv @@@ ~o@@l@/i  @a~o  ~~ ~~b  K~l~t@@m1o ~i r~ u.fn~~d@@o4c@i@ ~~~@  tb@ ~S~/@f~ @s@~~~@o-o@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public d()I
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public f()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x0

    move v1, v0

    move v1, v0

    const/4 v2, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public g(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public h(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public i()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    and-int/2addr v2, v1

    return v0
.end method

.method public abstract j(I)Z
.end method
