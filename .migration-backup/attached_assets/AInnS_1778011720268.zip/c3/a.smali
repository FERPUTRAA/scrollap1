.class public Lc3/a;
.super Ljava/lang/Object;


# static fields
.field private static final c:Ljava/lang/String; = "MTObservable"

.field public static final d:I = 0x65

.field private static volatile e:Lc3/a;


# instance fields
.field public a:Ljava/util/concurrent/ConcurrentLinkedQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentLinkedQueue<",
            "Lc3/b;",
            ">;"
        }
    .end annotation
.end field

.field public b:Ljava/util/concurrent/ConcurrentLinkedQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentLinkedQueue<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lc3/a;->b:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static b()Lc3/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ts l~c ff~  ~b~Kio~i~~ i 4 ~br~@@~o@ @@/d@1.@~~@M@ ~@~b@@u~ ~  /@@~  ~S@oo~la~ to~s @m~-vo@y@@n"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lc3/a;->e:Lc3/a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-class v0, Lc3/a;

    const-class v0, Lc3/a;

    const/4 v3, 0x5

    const-class v0, Lc3/a;

    const-class v0, Lc3/a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Lc3/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v1}, Lc3/a;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    sput-object v1, Lc3/a;->e:Lc3/a;

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lc3/a;->e:Lc3/a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    check-cast v1, Lc3/b;

    invoke-virtual {v1, p2}, Lc3/b;->j(I)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    invoke-virtual {v1, p1, p2, p3}, Lc3/b;->a(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public c(Landroid/content/Context;ILjava/lang/String;ILandroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    check-cast v1, Lc3/b;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Lc3/b;->f()[Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    const/4 v4, 0x0

    invoke-interface {v2, p3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1, p4}, Lc3/b;->j(I)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    if-nez p2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, p1, p4, p5}, Lc3/b;->h(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    move v4, v3

    if-ne p2, v2, :cond_0

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1, p1, p4, p5}, Lc3/b;->g(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public d(Landroid/content/Context;Lc3/b;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v1, p0, Lc3/a;->b:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v1, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    return-void

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string v2, " esmovrsb"

    const-string/jumbo v2, "resosvrb "

    const/4 v9, 0x7

    const-string v2, "e vooerrb"

    const-string/jumbo v2, "observer "

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v2, "MmsebbTOarel"

    const-string v2, "ebbmeTrOlsMa"

    const/4 v9, 0x2

    const-string v2, "MTObservable"

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v2, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v1, p0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v1, p2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v1, p0, Lc3/a;->b:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v9, 0x3

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v1, Landroid/os/Bundle;

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string/jumbo v2, "msoro_uabeene"

    const-string/jumbo v2, "seo_omaerbenr"

    const/4 v9, 0x0

    const-string/jumbo v2, "observer_name"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {p1}, Ly2/b;->B(Landroid/content/Context;)Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v0, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {}, Ly2/b;->q()Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {}, Ly2/b;->l()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v4, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string v5, "bsptt"

    const-string v5, "bttse"

    const/4 v9, 0x2

    const-string/jumbo v5, "state"

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-nez v3, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v1, v5, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v9, 0x1

    const-string/jumbo v0, "qcivytia"

    const-string v0, "aiyctiuv"

    const-string v0, "atsiviyt"

    const-string v0, "activity"

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/16 v0, 0x3ed

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p2, v0}, Lc3/b;->j(I)Z

    move-result v2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez v2, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/16 v2, 0x3ee

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {p2, v2}, Lc3/b;->j(I)Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v2, :cond_3

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p2, p1, v0, v4}, Lc3/b;->a(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-static {}, Ly2/b;->v()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {}, Ly2/b;->w()I

    move-result v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {}, Ly2/b;->t()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {}, Ly2/b;->u()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-nez v7, :cond_6

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {v1, v5, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v9, 0x4

    const-string/jumbo v5, "ytep"

    const-string v5, "etyp"

    const/4 v9, 0x7

    const-string/jumbo v5, "ypet"

    const-string/jumbo v5, "type"

    const/4 v9, 0x6

    invoke-virtual {v1, v5, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v2, "nema"

    const-string v2, "amen"

    const-string/jumbo v2, "nmae"

    const-string/jumbo v2, "name"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo v2, "orpmd"

    const-string v2, "dapor"

    const/4 v9, 0x5

    const-string/jumbo v2, "radio"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v1, v2, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/16 v2, 0x3eb

    const/4 v9, 0x3

    const/4 v8, 0x3

    invoke-virtual {p2, v2}, Lc3/b;->j(I)Z

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/16 v5, 0x3ec

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-nez v3, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {p2, v5}, Lc3/b;->j(I)Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v3, :cond_6

    :cond_4
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v0, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_0

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    move v2, v5

    move v2, v5

    const/4 v9, 0x3

    move v2, v5

    move v2, v5

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p2, p1, v2, v4}, Lc3/b;->a(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_6
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {}, Lr2/a;->b()Lr2/a;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/16 v0, 0x65

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    invoke-virtual {p2, p1, v0, v1}, Lr2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    return-void
.end method

.method public e(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x3

    const-string/jumbo v0, "qteto"

    const-string/jumbo v0, "tesqt"

    const/4 v8, 0x7

    const-string v0, "betst"

    const-string/jumbo v0, "state"

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v1, "vreambuoe_ser"

    const-string/jumbo v1, "sesbe_rrmoeav"

    const/4 v8, 0x0

    const-string v1, "b_aermvpsoern"

    const-string/jumbo v1, "observer_name"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v2, p0, Lc3/a;->b:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v8, 0x6

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    instance-of v2, v1, Lc3/b;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v2, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    check-cast v1, Lc3/b;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, p1, v1}, Lc3/a;->d(Landroid/content/Context;Lc3/b;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v3, "qatytmic"

    const-string/jumbo v3, "vtymicat"

    const/4 v8, 0x4

    const-string v3, "activity"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v4, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v2}, Ly2/b;->L(Z)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-static {v3}, Ly2/b;->H(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/16 v3, 0x7cb

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v1, v3}, Lc3/b;->j(I)Z

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/16 v6, 0x7ca

    const/4 v8, 0x7

    const/4 v7, 0x7

    if-nez v4, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v1, v6}, Lc3/b;->j(I)Z

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v4, :cond_3

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v2, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    move v3, v6

    move v3, v6

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1, p1, v3, v5}, Lc3/b;->a(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v3, "type"

    const-string/jumbo v3, "ypet"

    const/4 v8, 0x0

    const-string/jumbo v3, "type"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v4, "mean"

    const-string/jumbo v4, "nmea"

    const-string v4, "amen"

    const-string/jumbo v4, "name"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p2, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string/jumbo v6, "iosar"

    const-string v6, "aidro"

    const/4 v8, 0x7

    const-string v6, "daomr"

    const-string/jumbo v6, "radio"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p2, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-nez v6, :cond_6

    const/4 v7, 0x5

    and-int/2addr v8, v7

    invoke-static {v0}, Ly2/b;->O(Z)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v3}, Ly2/b;->P(I)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v4}, Ly2/b;->M(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p2}, Ly2/b;->N(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/16 p2, 0x7cd

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v1, p2}, Lc3/b;->j(I)Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/16 v3, 0x7cc

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez v0, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v3}, Lc3/b;->j(I)Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v0, :cond_6

    :cond_4
    const/4 v8, 0x2

    if-eqz v2, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_1

    :cond_5
    const/4 v8, 0x4

    move p2, v3

    move p2, v3

    const/4 v8, 0x0

    move p2, v3

    move p2, v3

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, p1, p2, v5}, Lc3/b;->a(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_2

    :catchall_0
    move-exception p1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string/jumbo v0, "rodroavfi  ebles"

    const-string/jumbo v0, "observer failed "

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo p2, "saObTbMlbvee"

    const-string p2, "MTObservable"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    return-void
.end method
