.class public Lio/openinstall/sdk/t;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/t$b;,
        Lio/openinstall/sdk/t$c;,
        Lio/openinstall/sdk/t$a;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)Lio/openinstall/sdk/t$a;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@dsoSm .~~s o~@ M ~l~ob@v   fKo@~i~  ~~ tl~~@arf~o 4@  @@@~@@~b~@~ n@y@~/u-1@tco@~@@i / b@@~ ~i~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-ne v0, v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-object v2

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v0, 0x0

    move v8, v0

    :try_start_0
    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const-string/jumbo v3, "n.smndroimdenvcdo.a"

    const-string v3, "giscnoddrdo.vnea.nm"

    const/4 v8, 0x5

    const-string v3, "cireoddgmvdin.o.onn"

    const-string v3, "com.android.vending"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, v3, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_0

    :catchall_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget-boolean v1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v1, "dtriubeod vinnocdnfn oamodmn."

    const-string v1, " oum ntiognnodfconavdme.ddnir"

    const-string/jumbo v1, "onnoidumtaeongdrddf  v.ciu.on"

    const-string v1, "com.android.vending not found"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-array v3, v0, [Ljava/lang/Object;

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    invoke-static {v1, v3}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v1, Lio/openinstall/sdk/t$b;

    const/4 v8, 0x7

    invoke-direct {v1, v2}, Lio/openinstall/sdk/t$b;-><init>(Lio/openinstall/sdk/u;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v3, Landroid/content/Intent;

    const/4 v8, 0x3

    const-string/jumbo v4, "n.cvimmp.io.d.srSgeeeoi.nrarATeidsdsltofoedao.TgRc."

    const-string/jumbo v4, "inf.oamistar.r.oSciTd.eoesvclno.Tgedms.Adgied.Regro"

    const/4 v8, 0x0

    const-string v4, ".givstdsq.eirnAradeSdi.os.emcnooe.Tieo.dfmcglRirag."

    const-string v4, "com.google.android.gms.ads.identifier.service.START"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const-string/jumbo v4, "odsm.cg.dgo.nogleobmra"

    const-string v4, ".eodgbrg.nsacdogmolo.m"

    const/4 v8, 0x7

    const-string/jumbo v4, "ilgmmne..domogoadgsr.o"

    const-string v4, "com.google.android.gms"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0, v3, v1, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v3, :cond_3

    :try_start_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v3, Lio/openinstall/sdk/t$c;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v1}, Lio/openinstall/sdk/t$b;->a()Landroid/os/IBinder;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {v3, v5}, Lio/openinstall/sdk/t$c;-><init>(Landroid/os/IBinder;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v5, Lio/openinstall/sdk/t$a;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3}, Lio/openinstall/sdk/t$c;->a()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Lio/openinstall/sdk/t$c;->a(Z)Z

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    invoke-direct {v5, v6, v3}, Lio/openinstall/sdk/t$a;-><init>(Ljava/lang/String;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object v5

    :catchall_1
    :try_start_2
    const/4 v8, 0x4

    const/4 v7, 0x5

    sget-boolean v3, Lio/openinstall/sdk/ec;->a:Z

    const/4 v8, 0x4

    if-eqz v3, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v3, "Avneoigued lIr gIsfdndACitnla itefoed"

    const-string/jumbo v3, "ivniIiu lntraee otICdAdtfdAn sggleefd"

    const/4 v8, 0x1

    const-string v3, "AdvertisingIdClient get AdInfo failed"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v3, v0}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    goto :goto_1

    :catchall_2
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    throw v0

    :cond_3
    const/4 v7, 0x1

    const/4 v8, 0x5

    sget-boolean p0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz p0, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string p0, "eedp bsiadrnntlicldidStIngv CveAeeirfb"

    const-string p0, " estvdtpCddfivreicn leeinebriidASaIgln"

    const/4 v8, 0x3

    const-string p0, "aindicu siAiI gevCbteenSldeidnidtfrlev"

    const-string p0, "AdvertisingIdClient bindService failed"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p0, v0}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_4
    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object v2
.end method
