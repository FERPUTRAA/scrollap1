.class public Lio/openinstall/sdk/j;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/dn;


# static fields
.field static final a:Ljava/lang/String; = ""

.field static final b:Ljava/lang/String; = "https://res.openinstall.com/%s.dnc"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~1s o/b@c@ f@~@@ib~Ku y/@  ~~l~@~.@ r@ @i~ -M~boot~o Ss@d@t~@~ ~a@~~@~ o~4@@~m@~i  o@f n ~~~lv  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    sget-object v0, Lio/openinstall/sdk/j;->b:Ljava/lang/String;

    const/4 v3, 0x4

    move v4, v3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput-object p1, v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p1
.end method
