.class Lio/openinstall/sdk/dt;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/concurrent/LinkedBlockingQueue;

.field final synthetic b:Lio/openinstall/sdk/ds;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/ds;Ljava/util/concurrent/LinkedBlockingQueue;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/dt;->b:Lio/openinstall/sdk/ds;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lio/openinstall/sdk/dt;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "o s~v@ 1b  @m .~/n K @iuf@o@ ~~/l~~taf ~@b~@o~  o@ i @-~~~@~~@ibSy@lr ~@@~~4@@ ~@~@dto@oM~ s~c@~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/dt;->b:Lio/openinstall/sdk/ds;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v0}, Lio/openinstall/sdk/ds;->a(Lio/openinstall/sdk/ds;)Lio/openinstall/sdk/bv;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/bv;->b(Z)Lio/openinstall/sdk/by;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lio/openinstall/sdk/dt;->b:Lio/openinstall/sdk/ds;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v2, v0}, Lio/openinstall/sdk/ds;->a(Lio/openinstall/sdk/ds;Lio/openinstall/sdk/by;)Lio/openinstall/sdk/by;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/dt;->b:Lio/openinstall/sdk/ds;

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v2}, Lio/openinstall/sdk/ds;->b(Lio/openinstall/sdk/ds;)Lio/openinstall/sdk/bv;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Lio/openinstall/sdk/bv;->a(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v2, p0, Lio/openinstall/sdk/dt;->b:Lio/openinstall/sdk/ds;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v2}, Lio/openinstall/sdk/ds;->c(Lio/openinstall/sdk/ds;)Lio/openinstall/sdk/bv;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Lio/openinstall/sdk/bv;->a()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/dt;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v1, Lio/openinstall/sdk/cv;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "gkfj"

    const-string v2, "fkjg"

    const-string/jumbo v2, "jgkf"

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v4, "Rpb"

    const-string v4, "Rbp"

    const/4 v6, 0x2

    const-string v4, "bRp"

    const-string/jumbo v4, "pbR"

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1, v4, v2, v3}, Lio/openinstall/sdk/cv;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Lio/openinstall/sdk/by;->c(I)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lio/openinstall/sdk/dt;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v6, 0x0

    new-instance v2, Lio/openinstall/sdk/cv;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v3, "cfwp"

    const-string v3, "fpwc"

    const/4 v6, 0x1

    const-string/jumbo v3, "pfwc"

    const-string/jumbo v3, "pwcf"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/by;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v4, "Hpb"

    const-string v4, "bHp"

    const/4 v6, 0x0

    const-string v4, "Hbp"

    const-string/jumbo v4, "pbH"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v2, v4, v3, v0}, Lio/openinstall/sdk/cv;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "avwi"

    const-string/jumbo v2, "wiav"

    const/4 v6, 0x7

    const-string v2, "aviw"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v3, "Tbp"

    const-string v3, "bTp"

    const/4 v6, 0x3

    const-string v3, "bTp"

    const-string/jumbo v3, "pbT"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/by;->c(I)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/dt;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v6, 0x0

    const/4 v5, 0x6

    new-instance v4, Lio/openinstall/sdk/cv;

    const/4 v5, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/by;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    invoke-direct {v4, v3, v2, v0}, Lio/openinstall/sdk/cv;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, v4}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/dt;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v1, Lio/openinstall/sdk/cv;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v1, v3, v2, v4}, Lio/openinstall/sdk/cv;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto/16 :goto_0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void
.end method
