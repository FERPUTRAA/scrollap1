.class public Lio/openinstall/sdk/bj;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/Object;

.field private final b:Landroid/app/Application;

.field private final c:Ljava/util/concurrent/LinkedBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/LinkedBlockingQueue<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lio/openinstall/sdk/bo;

.field private e:Landroid/app/Application$ActivityLifecycleCallbacks;

.field private f:Z


# direct methods
.method public constructor <init>(Lio/openinstall/sdk/av;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lio/openinstall/sdk/bj;->a:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lio/openinstall/sdk/bj;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    shl-int/2addr v3, v0

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    iput-boolean v0, p0, Lio/openinstall/sdk/bj;->f:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    check-cast v0, Landroid/app/Application;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lio/openinstall/sdk/bj;->b:Landroid/app/Application;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Landroid/os/HandlerThread;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "drssHtnsvaeln"

    const-string v1, "HssadnltrenvE"

    const/4 v3, 0x4

    const-string v1, "HenmEtenvaldr"

    const-string v1, "EventsHandler"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lio/openinstall/sdk/bk;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bk;-><init>(Lio/openinstall/sdk/bj;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v1, Lio/openinstall/sdk/bo;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, v0, p1}, Lio/openinstall/sdk/bo;-><init>(Landroid/os/Looper;Lio/openinstall/sdk/av;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v1, p0, Lio/openinstall/sdk/bj;->d:Lio/openinstall/sdk/bo;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic a(Lio/openinstall/sdk/bj;)Ljava/util/concurrent/LinkedBlockingQueue;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ @ oio@ @ i@tin/o ~~d~f~~.~bt-  y@@@M b  @~~~r@~~@~u~@~ @ vS @1 ~K o@ao@m@~~b@o~/l ~oc@~l@4f @s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lio/openinstall/sdk/bj;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic a(Lio/openinstall/sdk/bj;Z)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lio/openinstall/sdk/bj;->f:Z

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method private a(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v0, 0x2c

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-gez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/16 v0, 0x3b

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ltz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1

    :cond_1
    :goto_0
    const/4 v1, 0x7

    move v2, v1

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1
.end method

.method static synthetic b(Lio/openinstall/sdk/bj;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-boolean p0, p0, Lio/openinstall/sdk/bj;->f:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic c(Lio/openinstall/sdk/bj;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/openinstall/sdk/bj;->d()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic d(Lio/openinstall/sdk/bj;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/bj;->e()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private d()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->k()Lio/openinstall/sdk/bd;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/bd;->a()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->l()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->d()Landroid/app/Activity;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->m()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method static synthetic e(Lio/openinstall/sdk/bj;)Lio/openinstall/sdk/bo;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p0, p0, Lio/openinstall/sdk/bj;->d:Lio/openinstall/sdk/bo;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method private e()V
    .locals 6

    const/4 v5, 0x7

    new-instance v0, Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Lio/openinstall/sdk/bn;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bn;-><init>(Lio/openinstall/sdk/bj;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x7

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bj;->a:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/bj;->e:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v1, Lio/openinstall/sdk/bl;

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bl;-><init>(Lio/openinstall/sdk/bj;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v1, p0, Lio/openinstall/sdk/bj;->e:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v2, p0, Lio/openinstall/sdk/bj;->b:Landroid/app/Application;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v2, v1}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw v1
.end method

.method public a(J)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    cmp-long v0, p1, v0

    const/4 v3, 0x2

    if-ltz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lio/openinstall/sdk/be;->a(J)Lio/openinstall/sdk/be;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lio/openinstall/sdk/be;->a(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p2, p0, Lio/openinstall/sdk/bj;->d:Lio/openinstall/sdk/bo;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Lio/openinstall/sdk/bo;->a(Lio/openinstall/sdk/be;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public a(Ljava/lang/String;JLjava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bj;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-boolean p2, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    sget-object p2, Lio/openinstall/sdk/dz;->a:Lio/openinstall/sdk/dz;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Lio/openinstall/sdk/dz;->a()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 p3, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-array p3, p3, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object p1, p3, v1

    const/4 v4, 0x6

    invoke-static {p2, p3}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p4, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p4}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/16 v2, 0xa

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-le v0, v2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object p1, Lio/openinstall/sdk/dz;->b:Lio/openinstall/sdk/dz;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/dz;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1, p2}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_3
    const/4 v3, 0x5

    move v4, v3

    invoke-static {p1, p2, p3, p4}, Lio/openinstall/sdk/be;->a(Ljava/lang/String;JLjava/util/Map;)Lio/openinstall/sdk/be;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p2, p0, Lio/openinstall/sdk/bj;->d:Lio/openinstall/sdk/bo;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, p1}, Lio/openinstall/sdk/bo;->a(Lio/openinstall/sdk/be;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x0

    const/4 v2, 0x7

    new-instance v1, Lio/openinstall/sdk/bm;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bm;-><init>(Lio/openinstall/sdk/bj;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "le"

    const-string/jumbo v1, "le"

    const-string/jumbo v1, "le"

    const-string v1, "el"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public c()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lio/openinstall/sdk/be;->a()Lio/openinstall/sdk/be;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/be;->a(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/bj;->d:Lio/openinstall/sdk/bo;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/bo;->a(Lio/openinstall/sdk/be;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method
