.class public Lio/openinstall/sdk/f;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/ch;


# static fields
.field private static final a:[Ljava/lang/String;

.field private static b:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "otsmescan.olnps"

    const-string/jumbo v0, "tascpnels.mlono"

    const/4 v3, 0x7

    const-string v0, ".limnesnomocatp"

    const-string/jumbo v0, "openinstall.com"

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, "emdmola.loscepi"

    const-string/jumbo v1, "lp.milademonsec"

    const/4 v3, 0x3

    const-string v1, "dntepbcsoaml.le"

    const-string v1, "deepinstall.com"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object v0, Lio/openinstall/sdk/f;->a:[Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    sput v0, Lio/openinstall/sdk/f;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "t@o~  u4n@S si i@~b t~@@@K@@  fr@ ~M~~@~@~@m@@b~1~@@ldv.o/ iy~ oo@@ ~~o l ~~~b@ ~u~ ~fa c~@~-/o "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget v0, Lio/openinstall/sdk/f;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v1, Lio/openinstall/sdk/f;->a:[Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    array-length v1, v1

    const/4 v3, 0x5

    rem-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    sput v0, Lio/openinstall/sdk/f;->b:I

    const/4 v3, 0x1

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const-string v1, "-2pai"

    const-string v1, "a2-io"

    const/4 v4, 0x3

    const-string/jumbo v1, "p-2qa"

    const-string v1, "api2-"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const-string v1, "."

    const-string v1, "."

    const-string v1, "."

    const-string v1, "."

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Lio/openinstall/sdk/f;->a:[Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget v2, Lio/openinstall/sdk/f;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    aget-object v1, v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "ts-tab"

    const/4 v4, 0x6

    const-string v1, "-asst2"

    const-string/jumbo v1, "stat2-"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, "."

    const-string v1, "."

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v1, Lio/openinstall/sdk/f;->a:[Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget v2, Lio/openinstall/sdk/f;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    aget-object v1, v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0
.end method
