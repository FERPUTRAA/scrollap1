.class public Lio/openinstall/sdk/cp;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/cm;


# static fields
.field private static final f:[B


# instance fields
.field private final a:Z

.field private final b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;"
        }
    .end annotation
.end field

.field private e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/16 v0, 0x40

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-array v0, v0, [B

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    fill-array-data v0, :array_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lio/openinstall/sdk/cp;->f:[B

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    nop

    :array_0
    .array-data 1
        -0x4t
        0x6et
        0x4t
        -0x26t
        -0x5bt
        0x50t
        -0x35t
        0x6ft
        0x1et
        -0x1et
        -0x30t
        -0x45t
        -0x42t
        0x0t
        0x43t
        -0x3ft
        -0x30t
        -0x4ft
        0x53t
        -0x68t
        0x4bt
        0x3at
        -0x24t
        0x7ft
        -0x25t
        -0x52t
        -0x45t
        -0x16t
        -0xat
        0x46t
        0x13t
        0x53t
        0x70t
        0x2bt
        0x7ct
        -0x49t
        0x55t
        0x4ft
        -0x7bt
        -0x57t
        -0x13t
        -0x1at
        -0x42t
        0x65t
        -0x2at
        0x40t
        0x70t
        -0x3ct
        0x43t
        -0x19t
        -0xet
        -0x3ft
        -0x35t
        -0x3et
        0x15t
        -0x69t
        -0x80t
        -0x8t
        -0x3et
        -0x40t
        0x2ct
        -0x45t
        0x15t
        -0x17t
    .end array-data
.end method

.method public constructor <init>(ZLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-boolean p1, p0, Lio/openinstall/sdk/cp;->a:Z

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lio/openinstall/sdk/cp;->b:Ljava/lang/String;

    return-void
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~stb4 @.@~ /@~M cS @~~ @@o@~bna@@~o  fl~@~@ sodoi@f@~/K@ ~~ rmy~@~o~iv~~ @@@  l1 ~-~b~ uo  ~@@i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 p0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object v0, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    move v5, v4

    array-length v1, p0

    const/4 v4, 0x5

    and-int/2addr v5, v4

    if-ge v0, v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    aget-byte v1, p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    sget-object v2, Lio/openinstall/sdk/cp;->f:[B

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    array-length v3, v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    rem-int v3, v0, v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    aget-byte v2, v2, v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    xor-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    int-to-byte v1, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    aput-byte v1, p0, v0

    const/4 v5, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {}, Lio/openinstall/sdk/bt;->b()Lio/openinstall/sdk/bt$b;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/bt$b;->a()Lio/openinstall/sdk/bt$b;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/bt$b;->b([B)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p0
.end method

.method protected static c(Ljava/util/Map;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-nez p0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 p0, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-object p0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v1, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v8, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    check-cast v2, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v2, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-nez v1, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v3, :cond_3

    const/4 v8, 0x0

    goto :goto_0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    instance-of v3, v1, Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v4, "&"

    const-string v4, "&"

    const/4 v8, 0x2

    const-string v4, "&"

    const-string v4, "&"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v3, :cond_5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v1}, Lio/openinstall/sdk/cp;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v3, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    goto :goto_0

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto/16 :goto_0

    :cond_5
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    instance-of v3, v1, Ljava/util/List;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    check-cast v1, Ljava/util/List;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-eqz v3, :cond_1

    const/4 v7, 0x0

    or-int/2addr v8, v7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v3}, Lio/openinstall/sdk/cp;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v6, :cond_6

    const/4 v8, 0x0

    goto :goto_1

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_1

    :cond_7
    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-lez p0, :cond_8

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    add-int/lit8 p0, p0, -0x1

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->setLength(I)V

    :cond_8
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x2

    return-object p0
.end method


# virtual methods
.method public a()Lio/openinstall/sdk/cl;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lio/openinstall/sdk/cl;->b:Lio/openinstall/sdk/cl;

    const/4 v2, 0x7

    return-object v0
.end method

.method public a(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/cp;->d:Ljava/util/Map;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v2, "thst:p/s"

    const/4 v4, 0x1

    const-string v2, ":tpmh//s"

    const-string v2, "https://"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lio/openinstall/sdk/cp;->c:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "iampo"

    const-string v2, "/iamp"

    const/4 v4, 0x2

    const-string v2, "bp//a"

    const-string v2, "/api/"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "v25_"

    const-string v2, "25_v"

    const/4 v4, 0x6

    const-string v2, "_v52"

    const-string/jumbo v2, "v2_5"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v2, "da/doni/o"

    const/4 v4, 0x3

    const-string v2, "/d/rniudo"

    const-string v2, "/android/"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/cp;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v2, "/"

    const-string v2, "/"

    const/4 v4, 0x7

    const-string v2, "/"

    const-string v2, "/"

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    const/4 v4, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cp;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/cp;->c:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public b(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/cp;->e:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/cp;->d:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-lez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cp;->d:Ljava/util/Map;

    const/4 v1, 0x3

    move v2, v1

    invoke-static {v0}, Lio/openinstall/sdk/cp;->c(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public d()[B
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/cp;->e:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-lez v0, :cond_0

    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Lio/openinstall/sdk/cp;->e:Ljava/util/Map;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Lio/openinstall/sdk/cp;->c(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-lez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v1, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cp;->c:Ljava/lang/String;

    const/4 v2, 0x4

    return-object v0
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/openinstall/sdk/cp;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method
