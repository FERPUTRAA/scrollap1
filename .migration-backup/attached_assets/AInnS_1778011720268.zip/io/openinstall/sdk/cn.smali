.class public Lio/openinstall/sdk/cn;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/cm;


# static fields
.field private static final b:Ljava/lang/String;

.field private static final c:Ljava/lang/String;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "1AsuVVsZ2XlNdB"

    const-string v0, "V1sXdNV2culBAZ"

    const-string v0, "XBNm2lAVicVdZ1"

    const-string v0, "VXNlci1BZ2VudA"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lio/openinstall/sdk/cn;->b:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, "3mlRoRxGhb3TTEksBlu"

    const-string v0, "Rl3muBhkcTxsb3lTEGR"

    const/4 v2, 0x1

    const-string v0, "T3TukbGlhExRbBcbl3s"

    const-string v0, "T3Blbkluc3RhbGxTREs"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lio/openinstall/sdk/cn;->c:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/cn;->a:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Lio/openinstall/sdk/cl;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S @~f~u@K@@4b~ o~  ~  @@@@- ty~@~f~o  ostibiroo~ a~@~ @ lo/@@ ~lMu~~~n@ @cd b1~@@/~@~i~ @m@~v~. "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lio/openinstall/sdk/cl;->a:Lio/openinstall/sdk/cl;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/cn;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "t="

    const-string/jumbo v1, "t="

    const/4 v4, 0x5

    const-string v1, "=t"

    const-string/jumbo v1, "t="

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0
.end method

.method public d()[B
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    and-int/2addr v2, v1

    return-object v0
.end method

.method public e()Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object v1, Lio/openinstall/sdk/cn;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v2, Lio/openinstall/sdk/cn;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method
