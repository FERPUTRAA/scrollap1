.class public Lio/openinstall/sdk/g;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/cx;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/fm/openinstall/Configuration;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/fm/openinstall/Configuration;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/openinstall/sdk/cw;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~s 4~n~@ois@ ~@mf/l~~ @df@ @~o~~1@ ~ o a@@~@o @i@~uMob@~@ .Ki b@~ yc  @@S ~~ b/@t~t@v~-~l~~o  r"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x6

    new-instance v1, Lio/openinstall/sdk/o;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Lio/openinstall/sdk/o;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v1, Lio/openinstall/sdk/r;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget-object v3, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v1, v2, v3}, Lio/openinstall/sdk/r;-><init>(Landroid/content/Context;Lcom/fm/openinstall/Configuration;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v1}, Lio/openinstall/sdk/ea;->d(Landroid/content/Context;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/fm/openinstall/Configuration;->isAdEnabled()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v1, Lio/openinstall/sdk/l;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1}, Lio/openinstall/sdk/l;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    new-instance v1, Lio/openinstall/sdk/s;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Lio/openinstall/sdk/s;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v2, Lio/openinstall/sdk/p;

    const/4 v5, 0x7

    iget-object v3, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v2, v3, v1}, Lio/openinstall/sdk/p;-><init>(Lcom/fm/openinstall/Configuration;Lio/openinstall/sdk/s;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v2, Lio/openinstall/sdk/n;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v3, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v2, v3, v1}, Lio/openinstall/sdk/n;-><init>(Lcom/fm/openinstall/Configuration;Lio/openinstall/sdk/s;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v1, Lio/openinstall/sdk/m;

    const/4 v5, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v3, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3}, Lio/openinstall/sdk/m;-><init>(Landroid/content/Context;Lcom/fm/openinstall/Configuration;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v1, Lio/openinstall/sdk/q;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v2, p0, Lio/openinstall/sdk/g;->a:Landroid/content/Context;

    const/4 v4, 0x3

    move v5, v4

    iget-object v3, p0, Lio/openinstall/sdk/g;->b:Lcom/fm/openinstall/Configuration;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v1, v2, v3}, Lio/openinstall/sdk/q;-><init>(Landroid/content/Context;Lcom/fm/openinstall/Configuration;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object v0
.end method
