.class public Lio/openinstall/sdk/aw;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/Boolean;

.field private b:Ljava/lang/Boolean;

.field private c:Ljava/lang/Boolean;

.field private d:Ljava/lang/Boolean;

.field private e:J

.field private f:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/16 v0, 0xe10

    const-wide/16 v0, 0xe10

    const/4 v3, 0x1

    const-wide/16 v0, 0xe10

    const-wide/16 v0, 0xe10

    const/4 v3, 0x3

    const/4 v2, 0x0

    iput-wide v0, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v2, 0x3

    move v3, v2

    return-void
.end method

.method public static b(Ljava/lang/String;)Lio/openinstall/sdk/aw;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "i ss~o~ @~  @l~/@K @n@~~.o@~ @ ~4@doyf@tS-@o@r~~ @~b a~f/ ~v@@o~i  1~~~iu~@ ~@~o @bt@m ~cM @@l b"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    new-instance v0, Lio/openinstall/sdk/aw;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0}, Lio/openinstall/sdk/aw;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v0

    :cond_0
    :try_start_0
    const/4 v5, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string p0, "aEbmkssSldenptuwea"

    const-string/jumbo p0, "swsbkeEpaneatuStld"

    const/4 v5, 0x4

    const-string p0, "alEtoeubtawpdSkesn"

    const-string/jumbo p0, "wakeupStatsEnabled"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, p0, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/aw;->a(Ljava/lang/Boolean;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string p0, "bilEsbSavtenalade"

    const-string p0, "aliveStatsEnabled"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, p0, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/aw;->c(Ljava/lang/Boolean;)V

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string p0, "eslstgunmdeiebtStEar"

    const-string p0, "gramltsdintetaeEbseS"

    const/4 v5, 0x4

    const-string p0, "eSaEtrrpdialbseettgs"

    const-string/jumbo p0, "registerStatsEnabled"

    const/4 v5, 0x4

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    invoke-virtual {v1, p0, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/aw;->b(Ljava/lang/Boolean;)V

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo p0, "nnetSoedqaltabseE"

    const-string p0, "eaSdonetvEnatbels"

    const/4 v5, 0x5

    const-string p0, "Evsaettetnadsbeln"

    const-string p0, "eventStatsEnabled"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p0, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/aw;->c(Ljava/lang/Boolean;)V

    :cond_4
    const/4 v5, 0x5

    const-string p0, "btemrooPpdri"

    const-string/jumbo p0, "idrrPbropeto"

    const/4 v5, 0x7

    const-string/jumbo p0, "tpriodoerreP"

    const-string/jumbo p0, "reportPeriod"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v2, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Lio/openinstall/sdk/aw;->a(J)V

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x7

    const-string/jumbo p0, "uilaIbdst"

    const-string/jumbo p0, "ldsltiuIa"

    const/4 v5, 0x2

    const-string/jumbo p0, "ldntsluai"

    const-string/jumbo p0, "installId"

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v2, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/aw;->a(Ljava/lang/String;)V

    :catch_0
    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x7

    return-object v0
.end method

.method private d(Ljava/lang/Boolean;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v0, 0x2

    or-int/2addr v1, v0

    return p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method


# virtual methods
.method public a()Ljava/lang/Boolean;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public a(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-wide p1, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public a(Lio/openinstall/sdk/aw;)V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->a()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->e()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lio/openinstall/sdk/aw;->b:Ljava/lang/Boolean;

    const/4 v3, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->c()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->e()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->g()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-wide v0, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->h()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public a(Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v1, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v1, 0x5

    return-void
.end method

.method public b(Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lio/openinstall/sdk/aw;->d(Ljava/lang/Boolean;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public c()Ljava/lang/Boolean;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public c(Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lio/openinstall/sdk/aw;->d(Ljava/lang/Boolean;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public e()Ljava/lang/Boolean;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v1, 0x6

    move v2, v1

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v0, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-ne p0, p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    return v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz p1, :cond_d

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eq v2, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto/16 :goto_5

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    check-cast p1, Lio/openinstall/sdk/aw;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-wide v2, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-wide v4, p1, Lio/openinstall/sdk/aw;->e:J

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v7, 0x1

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    return v1

    :cond_2
    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v3, p1, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez v2, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v2, p1, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v7, 0x0

    if-eqz v2, :cond_4

    :goto_0
    const/4 v7, 0x1

    return v1

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/aw;->b:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v2, :cond_5

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v3, p1, Lio/openinstall/sdk/aw;->b:Ljava/lang/Boolean;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-nez v2, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_1

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p1, Lio/openinstall/sdk/aw;->b:Ljava/lang/Boolean;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v2, :cond_6

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    return v1

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v2, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v2, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x0

    iget-object v3, p1, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez v2, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto :goto_2

    :cond_7
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v2, p1, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v6, 0x4

    or-int/2addr v7, v6

    if-eqz v2, :cond_8

    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    return v1

    :cond_8
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v3, p1, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez v2, :cond_a

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_3

    :cond_9
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v2, p1, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_a

    :goto_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    return v1

    :cond_a
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v2, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p1, p1, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v2, :cond_b

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_4

    :cond_b
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez p1, :cond_c

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_4

    :cond_c
    const/4 v7, 0x0

    move v0, v1

    move v0, v1

    const/4 v7, 0x4

    move v0, v1

    move v0, v1

    :goto_4
    const/4 v7, 0x7

    const/4 v6, 0x7

    return v0

    :cond_d
    :goto_5
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    return v1
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lio/openinstall/sdk/aw;->d(Ljava/lang/Boolean;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public g()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-wide v0, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method

.method public h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public hashCode()I
    .locals 8

    const/4 v7, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v1, 0x0

    shl-int/2addr v7, v1

    const/4 v6, 0x5

    move v7, v6

    if-eqz v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->hashCode()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    move v0, v1

    move v0, v1

    const/4 v7, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    mul-int/lit8 v0, v0, 0x1f

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v2, p0, Lio/openinstall/sdk/aw;->b:Ljava/lang/Boolean;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Boolean;->hashCode()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    add-int/2addr v0, v2

    const/4 v7, 0x7

    mul-int/lit8 v0, v0, 0x1f

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v6, 0x6

    move v7, v6

    if-eqz v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/Boolean;->hashCode()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_2

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    add-int/2addr v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    mul-int/lit8 v0, v0, 0x1f

    const/4 v6, 0x6

    or-int/2addr v7, v6

    iget-object v2, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v2, :cond_3

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v2}, Ljava/lang/Boolean;->hashCode()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_3

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    :goto_3
    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    add-int/2addr v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    mul-int/lit8 v0, v0, 0x1f

    const/4 v7, 0x6

    const/4 v6, 0x2

    iget-wide v2, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/16 v4, 0x20

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    ushr-long v4, v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    xor-long/2addr v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    long-to-int v2, v2

    const/4 v7, 0x3

    add-int/2addr v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    mul-int/lit8 v0, v0, 0x1f

    const/4 v7, 0x4

    const/4 v6, 0x5

    iget-object v2, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v7, 0x1

    if-eqz v2, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v1

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/2addr v0, v1

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    return v0
.end method

.method public i()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "bkaalnapuptewdsEte"

    const/4 v5, 0x7

    const-string v1, "btksnaSplwpaaueedE"

    const-string/jumbo v1, "wakeupStatsEnabled"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/aw;->a:Ljava/lang/Boolean;

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v1, "nesqbiaSqtldrEegttea"

    const-string v1, "drgtsnaaqeibstteeElS"

    const/4 v5, 0x7

    const-string v1, "aessltnaeErtsrgbiedS"

    const-string/jumbo v1, "registerStatsEnabled"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v2, p0, Lio/openinstall/sdk/aw;->c:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v1, "eventStatsEnabled"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lio/openinstall/sdk/aw;->d:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "primoteredso"

    const-string/jumbo v1, "odsirpotrere"

    const/4 v5, 0x5

    const-string/jumbo v1, "retPoioopred"

    const-string/jumbo v1, "reportPeriod"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-wide v2, p0, Lio/openinstall/sdk/aw;->e:J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "liIalbdst"

    const-string/jumbo v1, "installId"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/aw;->f:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object v0
.end method
