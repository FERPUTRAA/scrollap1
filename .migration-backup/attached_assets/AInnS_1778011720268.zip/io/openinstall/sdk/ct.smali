.class Lio/openinstall/sdk/ct;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/cs;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/cs;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/ct;->a:Lio/openinstall/sdk/cs;

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s@f  1i ~@o~~o~~ ~@/  tfado~v o y~@~r t@m@in.~~ o@ ~s@@l@~~Kb~@ l~@~@c4b~@@@~/ o~ @u@ ~M ~ib@S"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ct;->a:Lio/openinstall/sdk/cs;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/cs;->n()Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lio/openinstall/sdk/ct;->a:Lio/openinstall/sdk/cs;

    const/4 v4, 0x1

    iget-object v2, v1, Lio/openinstall/sdk/cs;->b:Lio/openinstall/sdk/da;

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, v1, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1}, Lio/openinstall/sdk/av;->b()Landroid/os/Handler;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v2, Lio/openinstall/sdk/cu;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v2, p0, v0}, Lio/openinstall/sdk/cu;-><init>(Lio/openinstall/sdk/ct;Lio/openinstall/sdk/cy;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method
