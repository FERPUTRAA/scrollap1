.class public Lio/openinstall/sdk/bt$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/bt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field static final a:Lio/openinstall/sdk/bt$a;

.field static final b:Lio/openinstall/sdk/bt$a;

.field static final c:Lio/openinstall/sdk/bt$a;

.field private static final f:[I

.field private static final g:[I


# instance fields
.field private final d:Z

.field private final e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/16 v0, 0x100

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-array v1, v0, [I

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    sput-object v1, Lio/openinstall/sdk/bt$a;->f:[I

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v2, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([II)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {}, Lio/openinstall/sdk/bt$b;->b()[C

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    array-length v4, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ge v3, v4, :cond_0

    const/4 v7, 0x0

    sget-object v4, Lio/openinstall/sdk/bt$a;->f:[I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Lio/openinstall/sdk/bt$b;->b()[C

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    aget-char v5, v5, v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    aput v3, v4, v5

    const/4 v7, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v3, Lio/openinstall/sdk/bt$a;->f:[I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v4, 0x3d

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v5, -0x2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    aput v5, v3, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-array v0, v0, [I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    sput-object v0, Lio/openinstall/sdk/bt$a;->g:[I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    move v0, v1

    move v0, v1

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lio/openinstall/sdk/bt$b;->c()[C

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    array-length v2, v2

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ge v0, v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v2, Lio/openinstall/sdk/bt$a;->g:[I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {}, Lio/openinstall/sdk/bt$b;->c()[C

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-char v3, v3, v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    aput v0, v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    sget-object v0, Lio/openinstall/sdk/bt$a;->g:[I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    aput v5, v0, v4

    const/4 v7, 0x5

    new-instance v0, Lio/openinstall/sdk/bt$a;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v0, v1, v1}, Lio/openinstall/sdk/bt$a;-><init>(ZZ)V

    const/4 v7, 0x5

    sput-object v0, Lio/openinstall/sdk/bt$a;->a:Lio/openinstall/sdk/bt$a;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v0, Lio/openinstall/sdk/bt$a;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v2, 0x1

    const/4 v6, 0x6

    move v7, v6

    invoke-direct {v0, v2, v1}, Lio/openinstall/sdk/bt$a;-><init>(ZZ)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    sput-object v0, Lio/openinstall/sdk/bt$a;->b:Lio/openinstall/sdk/bt$a;

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v0, Lio/openinstall/sdk/bt$a;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/bt$a;-><init>(ZZ)V

    const/4 v7, 0x3

    sput-object v0, Lio/openinstall/sdk/bt$a;->c:Lio/openinstall/sdk/bt$a;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-void
.end method

.method private constructor <init>(ZZ)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-boolean p1, p0, Lio/openinstall/sdk/bt$a;->d:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p2, p0, Lio/openinstall/sdk/bt$a;->e:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private a([BII)I
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "b/s~ @oy~lv@ t@/fS@~~ ~o~ K m 4 @~f~Mb~@1~@@ ~~ r~ oo@~-it@b.~@l@  @@~o~@i~s  @n u~ @c~a@@~oi~ d"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    iget-boolean v0, p0, Lio/openinstall/sdk/bt$a;->d:Z

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x5

    sget-object v0, Lio/openinstall/sdk/bt$a;->g:[I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-object v0, Lio/openinstall/sdk/bt$a;->f:[I

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    sub-int v1, p3, p2

    const/4 v8, 0x6

    and-int/2addr v9, v8

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x4

    if-nez v1, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    return v2

    :cond_1
    const/4 v9, 0x5

    const/4 v3, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    const/4 v4, 0x2

    if-ge v1, v4, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-boolean p1, p0, Lio/openinstall/sdk/bt$a;->e:Z

    const/4 v9, 0x2

    if-eqz p1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    aget p1, v0, v2

    const/4 v8, 0x2

    if-ne p1, v3, :cond_2

    const/4 v9, 0x5

    return v2

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string p2, "eItmbdlys4 nbstobu]2 yl se[fh tbtya shes v6t  otaaeuep rs "

    const-string p2, "2psuyI4e av t ou sbotysstaty f] tterd e[en6ashle  bbl bhsa"

    const/4 v9, 0x3

    const-string p2, "btf6osl  4tl peIo hynareyoht  stbvtaaueeuds esa] t[be2 s b"

    const-string p2, "Input byte[] should at least have 2 bytes for base64 bytes"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    throw p1

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-boolean v5, p0, Lio/openinstall/sdk/bt$a;->e:Z

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/16 v6, 0x3d

    const/4 v8, 0x3

    and-int/2addr v9, v8

    const/4 v7, 0x1

    move v9, v7

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v5, :cond_7

    const/4 v8, 0x1

    shr-int/2addr v9, v8

    move v4, v2

    const/4 v9, 0x2

    move v4, v2

    move v4, v2

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ge p2, p3, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    add-int/lit8 v5, p2, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    aget-byte p2, p1, p2

    const/4 v9, 0x4

    const/4 v8, 0x6

    and-int/lit16 p2, p2, 0xff

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-ne p2, v6, :cond_4

    const/4 v9, 0x0

    sub-int/2addr p3, v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    add-int/2addr p3, v7

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    sub-int/2addr v1, p3

    const/4 v9, 0x7

    goto :goto_2

    :cond_4
    const/4 v8, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    aget p2, v0, p2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ne p2, v3, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    add-int/lit8 v4, v4, 0x1

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    move p2, v5

    move p2, v5

    const/4 v9, 0x0

    move p2, v5

    move p2, v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    goto :goto_1

    :cond_6
    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    sub-int/2addr v1, v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    goto :goto_3

    :cond_7
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    add-int/lit8 p2, p3, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    aget-byte p2, p1, p2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-ne p2, v6, :cond_9

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    sub-int/2addr p3, v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    aget-byte p1, p1, p3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-ne p1, v6, :cond_8

    move v2, v4

    const/4 v9, 0x4

    move v2, v4

    move v2, v4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_3

    :cond_8
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v2, v7

    move v2, v7

    move v2, v7

    move v2, v7

    :cond_9
    :goto_3
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez v2, :cond_a

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    and-int/lit8 p1, v1, 0x3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz p1, :cond_a

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    rsub-int/lit8 v2, p1, 0x4

    :cond_a
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/lit8 v1, v1, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    div-int/lit8 v1, v1, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    mul-int/lit8 v1, v1, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    sub-int/2addr v1, v2

    const/4 v9, 0x3

    return v1
.end method

.method private a([BII[B)I
    .locals 11

    const/4 v10, 0x4

    iget-boolean v0, p0, Lio/openinstall/sdk/bt$a;->d:Z

    const/4 v10, 0x6

    if-eqz v0, :cond_0

    const/4 v10, 0x2

    sget-object v0, Lio/openinstall/sdk/bt$a;->g:[I

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    sget-object v0, Lio/openinstall/sdk/bt$a;->f:[I

    :goto_0
    const/4 v10, 0x6

    const/16 v1, 0x12

    const/4 v10, 0x2

    const/4 v2, 0x0

    const/4 v10, 0x3

    move v4, v1

    move v4, v1

    move v4, v1

    move v4, v1

    const/4 v10, 0x3

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    const/4 v10, 0x1

    move v5, v3

    move v5, v3

    move v5, v3

    move v5, v3

    :goto_1
    const/4 v10, 0x5

    const/4 v6, 0x6

    const/4 v10, 0x4

    const/16 v7, 0x10

    const/4 v10, 0x5

    if-ge p2, p3, :cond_7

    const/4 v10, 0x6

    add-int/lit8 v8, p2, 0x1

    const/4 v10, 0x6

    aget-byte p2, p1, p2

    const/4 v10, 0x1

    and-int/lit16 p2, p2, 0xff

    const/4 v10, 0x7

    aget p2, v0, p2

    const/4 v10, 0x6

    if-gez p2, :cond_5

    const/4 v10, 0x3

    const/4 v9, -0x2

    const/4 v10, 0x3

    if-ne p2, v9, :cond_3

    const/4 v10, 0x3

    if-ne v4, v6, :cond_1

    const/4 v10, 0x3

    if-eq v8, p3, :cond_2

    const/4 v10, 0x4

    add-int/lit8 p2, v8, 0x1

    const/4 v10, 0x3

    aget-byte v2, p1, v8

    const/4 v10, 0x1

    const/16 v8, 0x3d

    const/4 v10, 0x2

    if-ne v2, v8, :cond_2

    const/4 v10, 0x0

    goto :goto_2

    :cond_1
    const/4 v10, 0x5

    move p2, v8

    move p2, v8

    :goto_2
    const/4 v10, 0x4

    if-eq v4, v1, :cond_2

    const/4 v10, 0x7

    goto/16 :goto_4

    :cond_2
    const/4 v10, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x3

    const-string p2, "eurusbnabnha-o ng  ttyt wrnem  ap nygiebriIy4"

    const-string p2, "b ym r nhngrpeiItb n 4eyoa yriwtg tnnueadsau-"

    const-string/jumbo p2, "tyaainut-dp rb egyureniI y b4nseg no tthrnu w"

    const-string p2, "Input byte array has wrong 4-byte ending unit"

    const/4 v10, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    throw p1

    :cond_3
    const/4 v10, 0x7

    iget-boolean p2, p0, Lio/openinstall/sdk/bt$a;->e:Z

    const/4 v10, 0x0

    if-eqz p2, :cond_4

    const/4 v10, 0x6

    goto :goto_3

    :cond_4
    const/4 v10, 0x7

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const-string/jumbo p4, "sc ellIp b4ect ar6ehaogaa"

    const-string p4, "aleloth4csr6  bcaaag ereI"

    const-string/jumbo p4, "lgI6h 4lqalcarbaete rc ae"

    const-string p4, "Illegal base64 character "

    const/4 v10, 0x0

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    add-int/lit8 v8, v8, -0x1

    const/4 v10, 0x1

    aget-byte p1, p1, v8

    const/4 v10, 0x3

    invoke-static {p1, v7}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    throw p2

    :cond_5
    const/4 v10, 0x5

    shl-int/2addr p2, v4

    const/4 v10, 0x1

    or-int/2addr p2, v3

    const/4 v10, 0x7

    add-int/lit8 v4, v4, -0x6

    const/4 v10, 0x7

    if-gez v4, :cond_6

    const/4 v10, 0x7

    add-int/lit8 v3, v5, 0x1

    const/4 v10, 0x5

    shr-int/lit8 v4, p2, 0x10

    const/4 v10, 0x0

    int-to-byte v4, v4

    const/4 v10, 0x3

    aput-byte v4, p4, v5

    const/4 v10, 0x5

    add-int/lit8 v4, v3, 0x1

    const/4 v10, 0x3

    shr-int/lit8 v5, p2, 0x8

    const/4 v10, 0x0

    int-to-byte v5, v5

    aput-byte v5, p4, v3

    const/4 v10, 0x4

    add-int/lit8 v5, v4, 0x1

    const/4 v10, 0x0

    int-to-byte p2, p2

    const/4 v10, 0x1

    aput-byte p2, p4, v4

    const/4 v10, 0x7

    move v4, v1

    move v4, v1

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    goto :goto_3

    :cond_6
    const/4 v10, 0x1

    move v3, p2

    move v3, p2

    move v3, p2

    :goto_3
    const/4 v10, 0x1

    move p2, v8

    move p2, v8

    move p2, v8

    move p2, v8

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_7
    :goto_4
    const/4 v10, 0x3

    if-ne v4, v6, :cond_8

    const/4 v10, 0x5

    add-int/lit8 v1, v5, 0x1

    const/4 v10, 0x3

    shr-int/lit8 v2, v3, 0x10

    const/4 v10, 0x5

    int-to-byte v2, v2

    const/4 v10, 0x7

    aput-byte v2, p4, v5

    move v5, v1

    move v5, v1

    move v5, v1

    move v5, v1

    const/4 v10, 0x5

    goto :goto_5

    :cond_8
    const/4 v10, 0x0

    if-nez v4, :cond_9

    const/4 v10, 0x7

    add-int/lit8 v1, v5, 0x1

    const/4 v10, 0x5

    shr-int/lit8 v2, v3, 0x10

    const/4 v10, 0x2

    int-to-byte v2, v2

    const/4 v10, 0x6

    aput-byte v2, p4, v5

    const/4 v10, 0x5

    add-int/lit8 v5, v1, 0x1

    const/4 v10, 0x4

    shr-int/lit8 v2, v3, 0x8

    const/4 v10, 0x6

    int-to-byte v2, v2

    const/4 v10, 0x7

    aput-byte v2, p4, v1

    const/4 v10, 0x0

    goto :goto_5

    :cond_9
    const/4 v10, 0x7

    const/16 p4, 0xc

    const/4 v10, 0x6

    if-eq v4, p4, :cond_d

    :goto_5
    const/4 v10, 0x0

    if-ge p2, p3, :cond_c

    const/4 v10, 0x0

    iget-boolean p4, p0, Lio/openinstall/sdk/bt$a;->e:Z

    const/4 v10, 0x7

    if-eqz p4, :cond_b

    const/4 v10, 0x1

    add-int/lit8 p4, p2, 0x1

    const/4 v10, 0x5

    aget-byte p2, p1, p2

    const/4 v10, 0x2

    aget p2, v0, p2

    const/4 v10, 0x2

    if-gez p2, :cond_a

    const/4 v10, 0x5

    move p2, p4

    move p2, p4

    move p2, p4

    move p2, p4

    goto :goto_5

    :cond_a
    const/4 v10, 0x0

    move p2, p4

    move p2, p4

    move p2, p4

    move p2, p4

    :cond_b
    const/4 v10, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const-string p4, "etsgrd uyeaeh a annt yy bsrrrin anbtetIbc pic "

    const-string p4, "ar esb re tttoereyni hdnur i yybI cacannabpgt "

    const-string p4, "ae mntIiepuh nacrboaerttytcsr eay gt by  nir n"

    const-string p4, "Input byte array has incorrect ending byte at "

    const/4 v10, 0x2

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x2

    throw p1

    :cond_c
    const/4 v10, 0x5

    return v5

    :cond_d
    const/4 v10, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x3

    const-string p2, " vovolti de oahgoLe sintui bt  nhaeuustdn"

    const-string p2, " haonoulgtndd Lbevt vuihta  ae nsoesiuit "

    const-string p2, " edolbtnoivs  e bdsnisth utaguavtL hena i"

    const-string p2, "Last unit does not have enough valid bits"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    throw p1
.end method


# virtual methods
.method public a(Ljava/lang/String;)[B
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lio/openinstall/sdk/bt$a;->a([B)[B

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1
.end method

.method public a([B)[B
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    array-length v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x7

    invoke-direct {p0, p1, v1, v0}, Lio/openinstall/sdk/bt$a;->a([BII)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    new-array v2, v0, [B

    const/4 v5, 0x5

    const/4 v4, 0x1

    array-length v3, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p0, p1, v1, v3, v2}, Lio/openinstall/sdk/bt$a;->a([BII[B)I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eq p1, v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2, p1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object v2
.end method
