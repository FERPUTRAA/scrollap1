.class public Lio/openinstall/sdk/db;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/concurrent/ThreadFactory;

.field private static final b:Ljava/util/concurrent/RejectedExecutionHandler;

.field private static final c:Ljava/util/concurrent/ThreadPoolExecutor;

.field private static final d:Ljava/util/concurrent/ThreadPoolExecutor;


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v9, Lio/openinstall/sdk/dc;

    invoke-direct {v9}, Lio/openinstall/sdk/dc;-><init>()V

    sput-object v9, Lio/openinstall/sdk/db;->a:Ljava/util/concurrent/ThreadFactory;

    new-instance v10, Lio/openinstall/sdk/de;

    invoke-direct {v10}, Lio/openinstall/sdk/de;-><init>()V

    sput-object v10, Lio/openinstall/sdk/db;->b:Ljava/util/concurrent/RejectedExecutionHandler;

    new-instance v11, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x5

    const/16 v2, 0xa

    const-wide/16 v3, 0xa

    const-wide/16 v3, 0xa

    const-wide/16 v3, 0xa

    const-wide/16 v3, 0xa

    sget-object v12, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    const/16 v13, 0x1e

    invoke-direct {v6, v13}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    move-object v0, v11

    move-object v0, v11

    move-object v0, v11

    move-object v0, v11

    move-object v5, v12

    move-object v5, v12

    move-object v5, v12

    move-object v7, v9

    move-object v7, v9

    move-object v7, v9

    move-object v7, v9

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    invoke-direct/range {v0 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    sput-object v11, Lio/openinstall/sdk/db;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v14, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x3

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v6, v13}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    invoke-direct/range {v0 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    sput-object v14, Lio/openinstall/sdk/db;->d:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v0, 0x1

    invoke-virtual {v11, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    invoke-virtual {v14, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    return-void
.end method

.method public static a()Ljava/util/concurrent/ThreadPoolExecutor;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~rs~@f@4 ~l~@ou~@ a @@@K~i@@@m  o~  ~tn~i~~~~s/@~bco@ @@~ d@f ~1v bS-.@yo io~~ tlM~ ~ b~@o~@ /@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lio/openinstall/sdk/db;->d:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method

.method public static b()Ljava/util/concurrent/ThreadPoolExecutor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lio/openinstall/sdk/db;->c:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method
