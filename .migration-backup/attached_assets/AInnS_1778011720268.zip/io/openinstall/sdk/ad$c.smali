.class abstract Lio/openinstall/sdk/ad$c;
.super Landroid/os/Binder;

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/ad;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "iesk.adIuca.snviroIccledCrhlooao.chD.AmlioO"

    const-string/jumbo v0, "losIhoIuoknevh.ACosm.rcicaalraocieBD..ldOid"

    const-string v0, "com.hihonor.cloudservice.oaid.IOAIDCallBack"

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method abstract a(IJZFDLjava/lang/String;)V
.end method

.method abstract a(ILandroid/os/Bundle;)V
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~ m~l~@Si ~b~ybv @@@ a~/4@@n~1@ f@@l~~@  t @M~.@i~@ /@K @o bu-~~ @o~~i~ @d~~o~ r@o~toc sf @~ @o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-object p0
.end method

.method protected onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 11
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string/jumbo v0, "oavloD.olC.souicl.AhnerdioomhacdIreOBIcackm"

    const-string v0, ".domaoiicImchirduBeAhalencksl.rCIlc.ovOaDoo"

    const-string v0, "com.hihonor.cloudservice.oaid.IOAIDCallBack"

    const/4 v1, 0x1

    if-ne p1, v1, :cond_1

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v3

    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide v4

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    if-eqz p1, :cond_0

    move v6, v1

    move v6, v1

    move v6, v1

    move v6, v1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    move v6, p1

    move v6, p1

    move v6, p1

    move v6, p1

    :goto_0
    invoke-virtual {p2}, Landroid/os/Parcel;->readFloat()F

    move-result v7

    invoke-virtual {p2}, Landroid/os/Parcel;->readDouble()D

    move-result-wide v8

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v10

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    invoke-virtual/range {v2 .. v10}, Lio/openinstall/sdk/ad$c;->a(IJZFDLjava/lang/String;)V

    :goto_1
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :cond_1
    const/4 v2, 0x2

    if-ne p1, v2, :cond_3

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p4

    if-eqz p4, :cond_2

    sget-object p4, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {p4, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/os/Bundle;

    goto :goto_2

    :cond_2
    const/4 p2, 0x0

    :goto_2
    invoke-virtual {p0, p1, p2}, Lio/openinstall/sdk/ad$c;->a(ILandroid/os/Bundle;)V

    goto :goto_1

    :cond_3
    const v2, 0x5f4e5446

    if-eq p1, v2, :cond_4

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :cond_4
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1
.end method
