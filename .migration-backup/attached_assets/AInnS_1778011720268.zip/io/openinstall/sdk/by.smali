.class public Lio/openinstall/sdk/by;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I

.field private d:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public static a(Landroid/content/ClipData;)Lio/openinstall/sdk/by;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v5, 0x2

    return-object v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    new-instance v1, Lio/openinstall/sdk/by;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v1}, Lio/openinstall/sdk/by;-><init>()V

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {p0}, Landroid/content/ClipData;->getItemCount()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-lez v2, :cond_2

    const/4 v4, 0x3

    move v5, v4

    const/4 v2, 0x0

    shr-int/2addr v5, v2

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0, v2}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz p0, :cond_2

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/ClipData$Item;->getHtmlText()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/ClipData$Item;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v4, 0x0

    move v5, v4

    if-nez v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/ClipData$Item;->getText()Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    move-object p0, v0

    move-object p0, v0

    move-object v0, v2

    move-object v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_1

    :cond_2
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget-object v2, Lio/openinstall/sdk/dx;->d:Ljava/lang/String;

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/by;->b(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lio/openinstall/sdk/by;->b(I)V

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Lio/openinstall/sdk/by;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/by;->a(Z)V

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p0, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v0, Lio/openinstall/sdk/dx;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1, p0}, Lio/openinstall/sdk/by;->a(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Lio/openinstall/sdk/by;->b(I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0}, Lio/openinstall/sdk/by;->d(Ljava/lang/String;)Z

    move-result p0

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Lio/openinstall/sdk/by;->a(Z)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_3

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0}, Lio/openinstall/sdk/dw;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_6

    const/4 v5, 0x7

    invoke-virtual {v1, p0}, Lio/openinstall/sdk/by;->a(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v3}, Lio/openinstall/sdk/by;->b(I)V

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-static {v2}, Lio/openinstall/sdk/by;->d(Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_2

    :cond_7
    :goto_3
    const/4 v5, 0x7

    return-object v1
.end method

.method public static c(Ljava/lang/String;)Lio/openinstall/sdk/by;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lio/openinstall/sdk/by;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0}, Lio/openinstall/sdk/by;-><init>()V

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v2, Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-direct {v2, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string p0, "essbtp"

    const-string/jumbo p0, "ptsbeT"

    const/4 v4, 0x1

    const-string/jumbo p0, "pbText"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/by;->a(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string p0, "Htpmlm"

    const-string/jumbo p0, "lpHmtm"

    const/4 v4, 0x7

    const-string/jumbo p0, "pbHtml"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/by;->b(Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string p0, "eTbpop"

    const-string/jumbo p0, "pbType"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2, p0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/by;->a(I)V

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :catch_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v1
.end method

.method private static d(Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    sget-object v0, Lio/openinstall/sdk/dx;->e:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v1, :cond_0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    add-int/2addr v1, v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v0, "-"

    const-string v0, "-"

    const/4 v6, 0x3

    const-string v0, "-"

    const-string v0, "-"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :catch_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    cmp-long p0, v3, v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-gez p0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v2, 0x1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v2
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/by;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/by;->a:Ljava/lang/String;

    const/4 v1, 0x0

    return-void
.end method

.method public a(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-boolean p1, p0, Lio/openinstall/sdk/by;->d:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/by;->b:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public b(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/by;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public c(I)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    and-int/2addr p1, v0

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 p1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method

.method public d()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "txTebb"

    const-string/jumbo v1, "tbexoT"

    const/4 v4, 0x3

    const-string/jumbo v1, "pbText"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lio/openinstall/sdk/by;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "utmHbl"

    const-string/jumbo v1, "pbHtml"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lio/openinstall/sdk/by;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "ypTbpb"

    const-string/jumbo v1, "yTpebb"

    const/4 v4, 0x6

    const-string v1, "epqyTb"

    const-string/jumbo v1, "pbType"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v2, p0, Lio/openinstall/sdk/by;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method
