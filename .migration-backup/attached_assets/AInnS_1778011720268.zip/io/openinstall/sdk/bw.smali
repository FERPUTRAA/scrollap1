.class Lio/openinstall/sdk/bw;
.super Lio/openinstall/sdk/ap;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/bv;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/bv;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/bw;->a:Lio/openinstall/sdk/bv;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/ap;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "t/s iyM~ @@co~@v@~iot~  @Kd-@b@~S ~~~~~i m@ @ ~@~~~@ f  o1l~uf~n~o@ .4 @/aboo@@s ~@@@@b@ ~ rl~~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/bw;->a:Lio/openinstall/sdk/bv;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1}, Lio/openinstall/sdk/bv;->a(Lio/openinstall/sdk/bv;)Ljava/lang/Runnable;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-wide/16 v2, 0x12c

    const-wide/16 v2, 0x12c

    const/4 v5, 0x4

    const-wide/16 v2, 0x12c

    const-wide/16 v2, 0x12c

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/bw;->a:Lio/openinstall/sdk/bv;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lio/openinstall/sdk/bv;->a(Lio/openinstall/sdk/bv;Ljava/lang/ref/WeakReference;)Ljava/lang/ref/WeakReference;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/bw;->a:Lio/openinstall/sdk/bv;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Lio/openinstall/sdk/bv;->b(Lio/openinstall/sdk/bv;)Ljava/lang/ref/WeakReference;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/bv;->a(Ljava/lang/ref/WeakReference;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method
