.class public Lio/openinstall/sdk/as;
.super Ljava/lang/Object;


# static fields
.field private static final a:Lio/openinstall/sdk/as;


# instance fields
.field private b:Z

.field private c:Landroid/content/Context;

.field private d:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/Boolean;

.field private h:Ljava/lang/Boolean;

.field private i:Z

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:Ljava/lang/Boolean;

.field private n:Landroid/content/ClipData;

.field private o:Lio/openinstall/sdk/bd;

.field private p:Z

.field private q:Z

.field private r:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    new-instance v0, Lio/openinstall/sdk/as;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Lio/openinstall/sdk/as;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lio/openinstall/sdk/as;->a:Lio/openinstall/sdk/as;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->b:Z

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->i:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->j:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->k:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->l:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->p:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->q:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/openinstall/sdk/as;->r:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public static a()Lio/openinstall/sdk/as;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o/s @ul~~~ o ~@iib@v  ~~~@~@~~ st@o b 4~K/fr@@S~ 1@  @ @@~ oo~M~@~@l oy@ti@ f~. n~@~@a~m @~-c~@d"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lio/openinstall/sdk/as;->a:Lio/openinstall/sdk/as;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/as;->d:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/as;->d:Ljava/lang/ref/WeakReference;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public a(Landroid/content/ClipData;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/as;->n:Landroid/content/ClipData;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public a(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/as;->c:Landroid/content/Context;

    const/4 v1, 0x6

    return-void
.end method

.method public a(Lio/openinstall/sdk/bd;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/as;->o:Lio/openinstall/sdk/bd;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public a(Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/as;->m:Ljava/lang/Boolean;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lio/openinstall/sdk/as;->e:Ljava/lang/String;

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    return-void
.end method

.method public a(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-boolean p1, p0, Lio/openinstall/sdk/as;->p:Z

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    return-void
.end method

.method public b(Ljava/lang/Boolean;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/as;->g:Ljava/lang/Boolean;

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/as;->f:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public b(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-boolean p1, p0, Lio/openinstall/sdk/as;->q:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-void
.end method

.method public b()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/as;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public c()Landroid/content/Context;
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, Lio/openinstall/sdk/as;->c:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public c(Z)V
    .locals 2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lio/openinstall/sdk/as;->r:Z

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method public d()Landroid/app/Activity;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/as;->d:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Landroid/app/Activity;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/as;->e:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/as;->f:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method public g()Ljava/lang/Boolean;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/as;->m:Ljava/lang/Boolean;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/as;->c:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lio/openinstall/sdk/ea;->b(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/as;->m:Ljava/lang/Boolean;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/as;->m:Ljava/lang/Boolean;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public h()Landroid/content/ClipData;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/as;->n:Landroid/content/ClipData;

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object v0
.end method

.method public i()Ljava/lang/Boolean;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/as;->g:Ljava/lang/Boolean;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public j()Ljava/lang/Boolean;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/as;->h:Ljava/lang/Boolean;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/as;->c:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-static {v0}, Lio/openinstall/sdk/ea;->c(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lio/openinstall/sdk/as;->h:Ljava/lang/Boolean;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/as;->h:Ljava/lang/Boolean;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public k()Lio/openinstall/sdk/bd;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/as;->o:Lio/openinstall/sdk/bd;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/openinstall/sdk/as;->p:Z

    const/4 v2, 0x4

    return v0
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/openinstall/sdk/as;->q:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public n()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/openinstall/sdk/as;->r:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method
