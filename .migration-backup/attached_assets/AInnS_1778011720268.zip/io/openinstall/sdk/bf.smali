.class public abstract Lio/openinstall/sdk/bf;
.super Lio/openinstall/sdk/ap;


# instance fields
.field private a:Ljava/lang/Runnable;

.field private final b:Landroid/os/Handler;

.field private volatile c:Z

.field private volatile d:Z


# direct methods
.method protected constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ap;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/bf;->a:Ljava/lang/Runnable;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/bf;->b:Landroid/os/Handler;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-boolean v0, p0, Lio/openinstall/sdk/bf;->c:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-boolean v0, p0, Lio/openinstall/sdk/bf;->d:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic a(Lio/openinstall/sdk/bf;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "-@sur~t@ vot  ~  nS@~@ s~a@@oi~~@ l@b ~.~~@ f~~~~i@~o@ y1 ~b@~ ~@~o  4l@~c@bM@~i @o @/~@@d~o /mf"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-boolean p0, p0, Lio/openinstall/sdk/bf;->c:Z

    const/4 v1, 0x7

    const/4 v0, 0x2

    return p0
.end method

.method static synthetic a(Lio/openinstall/sdk/bf;Z)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p1, p0, Lio/openinstall/sdk/bf;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic b(Lio/openinstall/sdk/bf;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-boolean p0, p0, Lio/openinstall/sdk/bf;->d:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-super {p0, p1}, Lio/openinstall/sdk/ap;->onActivityPaused(Landroid/app/Activity;)V

    const/4 v4, 0x0

    const/4 p1, 0x6

    const/4 v4, 0x5

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-boolean p1, p0, Lio/openinstall/sdk/bf;->d:Z

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/as;->a(Landroid/app/Activity;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/bf;->a:Ljava/lang/Runnable;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/bf;->b:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance p1, Lio/openinstall/sdk/bg;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p1, p0}, Lio/openinstall/sdk/bg;-><init>(Lio/openinstall/sdk/bf;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/bf;->a:Ljava/lang/Runnable;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bf;->b:Landroid/os/Handler;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-super {p0, p1}, Lio/openinstall/sdk/ap;->onActivityResumed(Landroid/app/Activity;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->k()Lio/openinstall/sdk/bd;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1}, Lio/openinstall/sdk/as;->n()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/bd;->a()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x0

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/as;->a(Landroid/app/Activity;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-boolean p1, p0, Lio/openinstall/sdk/bf;->c:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x1

    xor-int/2addr p1, v0

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/openinstall/sdk/bf;->c:Z

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    shr-int/2addr v2, v0

    iput-boolean v0, p0, Lio/openinstall/sdk/bf;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/bf;->a:Ljava/lang/Runnable;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/bf;->b:Landroid/os/Handler;

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/bf;->a:Ljava/lang/Runnable;

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/openinstall/sdk/bf;->a()V

    :cond_3
    const/4 v3, 0x6

    return-void
.end method
