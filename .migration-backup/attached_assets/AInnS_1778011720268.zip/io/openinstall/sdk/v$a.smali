.class Lio/openinstall/sdk/v$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    const-string/jumbo p1, "sIsetgelaRnlerrfet"

    const-string/jumbo p1, "lgsfteaeIrerternRl"

    const/4 v4, 0x6

    const-string p1, "etrmrenterallsIRgf"

    const-string p1, "getInstallReferrer"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v1, "RireoeierunSmnhlfIetstsFonladp"

    const-string v1, "entmpdethuoernfiFrRlsnsrleiISa"

    const/4 v4, 0x2

    const-string v1, "dhSeebliresraRnIpFltrfeineunts"

    const-string/jumbo v1, "onInstallReferrerSetupFinished"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    aget-object p2, p3, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast p2, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-boolean p3, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz p3, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v0, "HeeFoauSsieiurlSit:reaRetnrLef lnr eIsddcne=tetsoaonldne pt"

    const-string v0, "esnnoanSinoeFeRarodi= eLesIrc SreldtetHrteidtutfeel:lsnar p"

    const/4 v4, 0x4

    const-string/jumbo v0, "ttnoee pt tRduHairshoI eearSrlfdnirseensr:idSletcaenL=neFel"

    const-string v0, "StateListenerHandler : onInstallReferrerSetupFinished code="

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {p3, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x5

    if-nez p2, :cond_1

    const/4 v4, 0x1

    const-class p2, Lcom/android/installreferrer/api/InstallReferrerClient;

    const-class p2, Lcom/android/installreferrer/api/InstallReferrerClient;

    const/4 v4, 0x4

    const-class p2, Lcom/android/installreferrer/api/InstallReferrerClient;

    const-class p2, Lcom/android/installreferrer/api/InstallReferrerClient;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array p3, v1, [Ljava/lang/Class;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p2, p1, p3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lio/openinstall/sdk/v;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p3, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-class v0, Lcom/android/installreferrer/api/ReferrerDetails;

    const-class v0, Lcom/android/installreferrer/api/ReferrerDetails;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, p1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, p3, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    check-cast p1, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1}, Lio/openinstall/sdk/v;->a(Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-string/jumbo p1, "tnniendeqnooC"

    const-string p1, "endConnection"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-array p3, v1, [Ljava/lang/Class;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2, p1, p3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lio/openinstall/sdk/v;->b()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-array p3, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, p2, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo p1, "irsendrteear frsiRagbr leIlRIfClanteeenellsfrte"

    const-string p1, "  ICdbeergflrsrrreInersteineallnReaeleiafltltfR"

    const/4 v4, 0x4

    const-string p1, "dnnmelletfIertirfilerCslaeeftsRlgaeRrnl art rIe"

    const-string p1, "InstallReferrerClient getInstallReferrer failed"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lio/openinstall/sdk/v;->c()Ljava/util/concurrent/CountDownLatch;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p1, "eScroonoRlesitIcseiavunefrrederDnelt"

    const-string/jumbo p1, "raceesuetcnneneDdfviserIleRStonrirlo"

    const/4 v4, 0x4

    const-string/jumbo p1, "riSeebeDcreosltdeenneontnavIcliRscrf"

    const-string/jumbo p1, "onInstallReferrerServiceDisconnected"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x5

    if-eqz p1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz p1, :cond_4

    const/4 v4, 0x3

    const-string p1, "atLefeueercaeDRn enserlt:ladHSiesnertIrdicSnve  srntelorit"

    const-string p1, "StateListenerHandler : InstallReferrerService Disconnected"

    const/4 v4, 0x0

    const/4 v3, 0x5

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, p2}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    move v4, v3

    const-string p3, "hcSrodeptea:Hn: nau  terlie pdo smLhntte"

    const-string p3, "ctntrelpHrintaes :nhehadote em uS: Lo  d"

    const/4 v4, 0x0

    const-string p3, ":Letns eqmealrona tS  t Htuod:shd hnicee"

    const-string p3, "StateListenerHandler : no such method : "

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array p2, v1, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_4
    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    return-object p1
.end method
