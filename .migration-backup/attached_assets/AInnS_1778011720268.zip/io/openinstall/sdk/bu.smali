.class public final Lio/openinstall/sdk/bu;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/nio/charset/Charset;

.field public static final b:Ljava/nio/charset/Charset;

.field public static final c:Ljava/nio/charset/Charset;

.field public static final d:Ljava/nio/charset/Charset;

.field public static final e:Ljava/nio/charset/Charset;

.field public static final f:Ljava/nio/charset/Charset;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const-string v0, "IUsSC-IS"

    const-string v0, "US-ASCII"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lio/openinstall/sdk/bu;->a:Ljava/nio/charset/Charset;

    const-string v0, "S8-m-sI19O"

    const-string v0, "--s188I9SO"

    const-string v0, "-I98o1S58O"

    const-string v0, "ISO-8859-1"

    const/4 v1, 0x3

    const/4 v1, 0x2

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lio/openinstall/sdk/bu;->b:Ljava/nio/charset/Charset;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "bFUT8"

    const-string v0, "UTF-8"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object v0, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v2, 0x3

    const-string v0, "BT6U1-um"

    const-string v0, "-UEmTB16"

    const/4 v2, 0x1

    const-string v0, "E6F1T-Up"

    const-string v0, "UTF-16BE"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    sput-object v0, Lio/openinstall/sdk/bu;->d:Ljava/nio/charset/Charset;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const-string/jumbo v0, "qTF1ELU6"

    const-string v0, "UTF-16LE"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Lio/openinstall/sdk/bu;->e:Ljava/nio/charset/Charset;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    const-string v0, "6-sTUo"

    const-string v0, "61UTo-"

    const/4 v2, 0x3

    const-string v0, "16FmT-"

    const-string v0, "UTF-16"

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lio/openinstall/sdk/bu;->f:Ljava/nio/charset/Charset;

    const/4 v2, 0x4

    return-void
.end method
