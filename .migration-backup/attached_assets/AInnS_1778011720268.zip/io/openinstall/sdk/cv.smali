.class public Lio/openinstall/sdk/cv;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/cv;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lio/openinstall/sdk/cv;->b:Ljava/lang/String;

    const/4 v1, 0x3

    iput-object p3, p0, Lio/openinstall/sdk/cv;->c:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o s.bstb ~@y /@ ov@~ nS4 rmu@@- @ @~@~@o id @~l~@f~~~~~@i~Mb~i@ @l@t oo@1~K~/@~@~@ ~ oc~~ @a f ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cv;->a:Ljava/lang/String;

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cv;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/cv;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method
