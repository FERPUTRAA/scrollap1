.class public Lio/openinstall/sdk/dm;
.super Ljava/lang/Object;


# static fields
.field private static final a:[B


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/16 v0, 0x20

    const/4 v2, 0x0

    new-array v0, v0, [B

    const/4 v2, 0x6

    fill-array-data v0, :array_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    sput-object v0, Lio/openinstall/sdk/dm;->a:[B

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void

    nop

    :array_0
    .array-data 1
        -0x60t
        0x2dt
        -0x15t
        -0xft
        -0x5t
        0x7bt
        0x7ct
        -0x3ft
        -0x1dt
        -0x2dt
        -0x55t
        -0x1t
        -0x77t
        0x3et
        0x49t
        0x1ft
        0x25t
        -0x16t
        0x7at
        -0x4t
        0x39t
        0x4ft
        0x38t
        0x4dt
        0x39t
        -0x77t
        -0x4bt
        0x1et
        0x28t
        0x68t
        0x34t
        0xbt
    .end array-data
.end method

.method static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, ".~s~ @@ ~~~lyo@b~@/ cSn @b /i@@K o tv l@ ~@@ i @ @@o~~d@ b~fr  ~uM@ ~@iot~am~~~~1~~s@-o~ 4~@of~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo v1, "|s/m/"

    const-string/jumbo v1, "|/sn/"

    const/4 v6, 0x7

    const-string v1, "/n/|o"

    const-string v1, "\"|\n"

    const/4 v6, 0x4

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-static {}, Lio/openinstall/sdk/bt;->d()Lio/openinstall/sdk/bt$a;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, p0}, Lio/openinstall/sdk/bt$a;->a(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    array-length v2, p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ge v1, v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    aget-byte v2, p0, v1

    const/4 v5, 0x3

    move v6, v5

    sget-object v3, Lio/openinstall/sdk/dm;->a:[B

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    array-length v4, v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    rem-int v4, v1, v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    aget-byte v3, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    xor-int/2addr v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    int-to-byte v2, v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-byte v2, p0, v1

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v1, p0}, Ljava/lang/String;-><init>([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    return-object v1

    :catch_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object v0
.end method

.method static b(Ljava/lang/String;)Landroid/util/Pair;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-static {p0}, Lio/openinstall/sdk/dm;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    if-eqz p0, :cond_a

    const/4 v11, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v11, 0x3

    if-nez v1, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x6

    goto/16 :goto_6

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v2, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    move v3, v2

    move v3, v2

    const/4 v11, 0x0

    move v3, v2

    move v3, v2

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-ge v3, v1, :cond_9

    :goto_1
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/16 v4, 0xa

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/16 v5, 0x22

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/16 v6, 0x20

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-ge v3, v1, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eq v7, v6, :cond_1

    const/4 v11, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eq v7, v5, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-ne v7, v4, :cond_2

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto :goto_1

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-lt v3, v1, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    goto/16 :goto_5

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    move v7, v3

    const/4 v11, 0x6

    move v7, v3

    move v7, v3

    :goto_2
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-ge v7, v1, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p0, v7}, Ljava/lang/String;->charAt(I)C

    move-result v8

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/16 v9, 0x3d

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eq v8, v9, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    add-int/lit8 v7, v7, 0x1

    const/4 v10, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    goto :goto_2

    :cond_4
    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p0, v3, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-lt v7, v1, :cond_5

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto/16 :goto_5

    :cond_5
    const/4 v10, 0x0

    move v11, v10

    add-int/lit8 v8, v7, 0x1

    :goto_3
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-ge v7, v1, :cond_6

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {p0, v7}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eq v9, v6, :cond_6

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0, v7}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eq v9, v5, :cond_6

    const/4 v10, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0, v7}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-eq v9, v4, :cond_6

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto :goto_3

    :cond_6
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0, v8, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string v5, "aip"

    const-string/jumbo v5, "iap"

    const-string v5, "api"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v5, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-eqz v5, :cond_7

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    goto :goto_4

    :cond_7
    const/4 v11, 0x3

    const-string/jumbo v5, "tsta"

    const-string/jumbo v5, "ttsa"

    const/4 v11, 0x7

    const-string v5, "atts"

    const-string/jumbo v5, "stat"

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-virtual {v5, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v3, :cond_8

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :cond_8
    :goto_4
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    move v3, v7

    move v3, v7

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    goto/16 :goto_0

    :cond_9
    :goto_5
    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-static {v0, v2}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    return-object p0

    :cond_a
    :goto_6
    const/4 v10, 0x6

    invoke-static {v0, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    return-object p0
.end method
