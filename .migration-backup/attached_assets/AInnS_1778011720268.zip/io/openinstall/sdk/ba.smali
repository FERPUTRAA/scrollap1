.class Lio/openinstall/sdk/ba;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ba;->a:Landroid/app/Activity;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sK/ f/r~@~t ~@~v.~~o~~~@~o   @io@ @~ ~ @@b  4oc~s@ ~1o@ il~~a~@@tSu @b-m@~@~ @@lMon@y  @b i@d~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/ba;->a:Landroid/app/Activity;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Lio/openinstall/sdk/az;->a(Landroid/app/Activity;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
