.class public Lio/openinstall/sdk/cq;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Ljava/lang/String;)Lio/openinstall/sdk/cq;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~fs  o @o@tc@ b @@@@@~~~~~/@@ru  yi~~@  Sb~@~~f1~~@@@sd/M -ilb ~4 @~ @o ~a~tn~o ooKm@  ~l@v~.~~i"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    const-string/jumbo v0, "mgs"

    const-string/jumbo v0, "msg"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v1, "odyb"

    const/4 v7, 0x1

    const-string v1, "doyb"

    const-string v1, "body"

    const/4 v6, 0x6

    or-int/2addr v7, v6

    const-string v2, "gsomnf"

    const-string/jumbo v2, "insgof"

    const/4 v7, 0x4

    const-string/jumbo v2, "ofcgoi"

    const-string v2, "config"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v3, "eocd"

    const-string v3, "deco"

    const/4 v7, 0x3

    const-string v3, "doec"

    const-string v3, "code"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance v4, Lio/openinstall/sdk/cq;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {v4}, Lio/openinstall/sdk/cq;-><init>()V

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v5, Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v5, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v5, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz p0, :cond_0

    const/4 v7, 0x5

    invoke-virtual {v5, v3}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    if-nez p0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v5, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4, p0}, Lio/openinstall/sdk/cq;->a(I)V

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-nez p0, :cond_1

    const/4 v7, 0x0

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v4, p0}, Lio/openinstall/sdk/cq;->d(Ljava/lang/String;)V

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v5, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz p0, :cond_2

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    invoke-virtual {v5, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez p0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v5, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, p0}, Lio/openinstall/sdk/cq;->c(Ljava/lang/String;)V

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz p0, :cond_3

    const/4 v7, 0x6

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez p0, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4, p0}, Lio/openinstall/sdk/cq;->b(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v4
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget v0, p0, Lio/openinstall/sdk/cq;->a:I

    const/4 v2, 0x7

    return v0
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lio/openinstall/sdk/cq;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cq;->c:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/cq;->c:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/cq;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public c(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/cq;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/cq;->d:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/cq;->d:Ljava/lang/String;

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method
