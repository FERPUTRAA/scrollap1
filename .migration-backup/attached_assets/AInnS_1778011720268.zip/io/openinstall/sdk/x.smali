.class public Lio/openinstall/sdk/x;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field a:Z

.field private final b:Ljava/util/concurrent/ThreadPoolExecutor;

.field private final c:Ljava/util/concurrent/LinkedBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/LinkedBlockingQueue<",
            "Landroid/os/IBinder;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v2, 0x3

    const/4 v10, 0x2

    move v9, v2

    move v9, v2

    const/4 v10, 0x4

    const-wide/16 v3, 0x3c

    const-wide/16 v3, 0x3c

    const/4 v10, 0x2

    const-wide/16 v3, 0x3c

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/16 v0, 0xa

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v6, v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    new-instance v7, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {v7}, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;-><init>()V

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/RejectedExecutionHandler;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    iput-object v8, p0, Lio/openinstall/sdk/x;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v0, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    iput-boolean v0, p0, Lio/openinstall/sdk/x;->a:Z

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/x;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v10, 0x2

    return-void
.end method

.method static synthetic a(Lio/openinstall/sdk/x;)Ljava/util/concurrent/LinkedBlockingQueue;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s@ l  io@@~~4 @ c@bd~yi l so  ~@@  u@/~mft  ~~M@@t@b~o~@@ ~/fb~@@~o~S@.n~~r~o ia1 @~~K~@~vo@-~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lio/openinstall/sdk/x;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public a()Landroid/os/IBinder;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-boolean v0, p0, Lio/openinstall/sdk/x;->a:Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-boolean v0, p0, Lio/openinstall/sdk/x;->a:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/x;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-wide/16 v1, 0x5

    const-wide/16 v1, 0x5

    const/4 v5, 0x6

    const-wide/16 v1, 0x5

    const-wide/16 v1, 0x5

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/concurrent/LinkedBlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v0, Landroid/os/IBinder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    throw v0
.end method

.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lio/openinstall/sdk/x;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lio/openinstall/sdk/y;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p0, p2}, Lio/openinstall/sdk/y;-><init>(Lio/openinstall/sdk/x;Landroid/os/IBinder;)V

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
