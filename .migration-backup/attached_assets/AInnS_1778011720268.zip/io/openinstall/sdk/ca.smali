.class public Lio/openinstall/sdk/ca;
.super Ljava/lang/Object;


# instance fields
.field private final a:Z

.field private b:Landroid/content/ClipboardManager;

.field private final c:Ljava/util/concurrent/DelayQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/DelayQueue<",
            "Lio/openinstall/sdk/bz;",
            ">;"
        }
    .end annotation
.end field

.field private d:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private e:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/DelayQueue;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/DelayQueue;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/ca;->d:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x5

    iput v0, p0, Lio/openinstall/sdk/ca;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->j()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    iput-boolean v0, p0, Lio/openinstall/sdk/ca;->a:Z

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string v0, "bosisalrp"

    const-string/jumbo v0, "rbscpalio"

    const/4 v2, 0x1

    const-string/jumbo v0, "odlmcaibp"

    const-string v0, "clipboard"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p1, Landroid/content/ClipboardManager;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ca;->b:Landroid/content/ClipboardManager;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method private f()Landroid/content/ClipData;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~~~o~@~~d~@  sy@@ o@ @~/ o @@~l@@o ti b~.vo @i@1 nr@bi ~ M~ao@~l/S~~ c@ omf~b 4~fK@~~@~-u@@@t ~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lio/openinstall/sdk/ca;->b:Landroid/content/ClipboardManager;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/content/ClipboardManager;->getPrimaryClipDescription()Landroid/content/ClipDescription;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/ca;->g()Landroid/content/ClipData;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v2, "nai/tbmlpe"

    const-string v2, "eaim/xtlpn"

    const/4 v5, 0x7

    const-string/jumbo v2, "text/plain"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v3, "thtxleumt"

    const-string/jumbo v3, "text/html"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    or-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const-string v0, "cpouto"

    const-string v0, "cotmou"

    const/4 v5, 0x0

    const-string/jumbo v0, "tmqous"

    const-string v0, "custom"

    const/4 v4, 0x1

    move v5, v4

    const-string v1, "ctsdm/t bn/a"

    const-string/jumbo v1, "mdthcbant/ /"

    const/4 v5, 0x1

    const-string/jumbo v1, "td mnoaht/m/"

    const-string v1, "don\'t match"

    const/4 v4, 0x2

    move v5, v4

    invoke-static {v0, v1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v0

    :cond_1
    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Lio/openinstall/sdk/ca;->b:Landroid/content/ClipboardManager;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0}, Lio/openinstall/sdk/ca;->g()Landroid/content/ClipData;

    move-result-object v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object v0
.end method

.method private g()Landroid/content/ClipData;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/ca;->c()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lio/openinstall/sdk/ca;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lio/openinstall/sdk/ca;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    iput v0, p0, Lio/openinstall/sdk/ca;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v0, "sucoom"

    const-string/jumbo v0, "ucmtso"

    const/4 v3, 0x0

    const-string/jumbo v0, "scotmb"

    const-string v0, "custom"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "ocfs puup"

    const-string v1, "ascp fupo"

    const/4 v3, 0x4

    const-string v1, "cfspau po"

    const-string v1, "app focus"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-boolean v0, p0, Lio/openinstall/sdk/ca;->a:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {}, Lio/openinstall/sdk/bz;->a()Lio/openinstall/sdk/bz;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/concurrent/DelayQueue;->offer(Ljava/util/concurrent/Delayed;)Z

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public a(Ljava/lang/ref/WeakReference;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/ca;->d:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/ca;->a:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lio/openinstall/sdk/bz;->a()Lio/openinstall/sdk/bz;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/DelayQueue;->offer(Ljava/util/concurrent/Delayed;)Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {}, Lio/openinstall/sdk/bz;->b()Lio/openinstall/sdk/bz;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/DelayQueue;->offer(Ljava/util/concurrent/Delayed;)Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/ca;->d:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Landroid/app/Activity;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/app/Activity;->hasWindowFocus()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public d()Landroid/content/ClipData;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/ca;->b:Landroid/content/ClipboardManager;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lio/openinstall/sdk/ca;->f()Landroid/content/ClipData;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public e()Landroid/content/ClipData;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/ca;->b:Landroid/content/ClipboardManager;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x3

    shl-int/2addr v8, v7

    if-nez v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    return-object v1

    :cond_0
    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/ca;->a:Z

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    invoke-direct {p0}, Lio/openinstall/sdk/ca;->f()Landroid/content/ClipData;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v3, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    move v3, v2

    move v3, v2

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v0, :cond_5

    :try_start_0
    const/4 v7, 0x6

    move v8, v7

    iget-object v0, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v8, 0x7

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v0, v5, v6, v4}, Ljava/util/concurrent/DelayQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/Delayed;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    check-cast v0, Lio/openinstall/sdk/bz;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_1

    :catch_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {p0}, Lio/openinstall/sdk/ca;->f()Landroid/content/ClipData;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    add-int/2addr v3, v2

    const/4 v8, 0x1

    if-eqz v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/bz;->c()Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v8, 0x4

    if-nez v4, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x3

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v0, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget-object v0, Lio/openinstall/sdk/dz;->c:Lio/openinstall/sdk/dz;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/dz;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0, v1}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    goto :goto_2

    :cond_2
    const/4 v8, 0x7

    iget-boolean v0, p0, Lio/openinstall/sdk/ca;->a:Z

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-nez v0, :cond_4

    const/4 v7, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v0, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-lt v3, v0, :cond_4

    :cond_3
    :goto_2
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    const/4 v8, 0x7

    const/4 v7, 0x2

    goto :goto_3

    :cond_4
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_5
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/ca;->c:Ljava/util/concurrent/DelayQueue;

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/DelayQueue;->clear()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object v0
.end method
