.class public Lio/openinstall/sdk/k;
.super Ljava/lang/Object;


# static fields
.field private static a:Lio/openinstall/sdk/k;

.field private static final b:Ljava/lang/Object;


# instance fields
.field private c:Ljava/lang/StringBuilder;

.field private final d:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Lio/openinstall/sdk/k;->b:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>()V
    .locals 9

    const/4 v8, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    move v8, v7

    iput-object v0, p0, Lio/openinstall/sdk/k;->c:Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo v1, "mAss=dv="

    const-string v1, "=dsAv=mJ"

    const-string v1, "dmJveA=="

    const/4 v8, 0x3

    const/4 v7, 0x2

    const-string v2, "9Zgmcp2mZ2=G"

    const-string v2, "Z=2mGcZ2g9pZ"

    const/4 v8, 0x3

    const-string v2, "9gZpo2cZ=ZGs"

    const-string v2, "Z29sZGZpc2g="

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v3, "=NgXob3="

    const-string v3, "==X3o4gN"

    const/4 v8, 0x7

    const-string v3, "gN=4=Xu3"

    const-string v3, "X3g4Ng=="

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v4, "z=bcWYAp"

    const-string v4, "==cYWbzA"

    const/4 v8, 0x1

    const-string/jumbo v4, "qA=zYWc9"

    const-string v4, "YW9zcA=="

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string/jumbo v5, "wG=9rcuQ2ad2X=Zu"

    const-string v5, "Qwsdc=ur2R29ZXGa"

    const-string v5, "c2RrX2dwaG9uZQ=="

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v6, "Rl2mX35brcpo"

    const-string/jumbo v6, "l3Rb2X5pBocr"

    const/4 v8, 0x2

    const-string v6, "2X3oobrB5cR2"

    const-string v6, "c2RrX3Bob25l"

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/k;->d:[Ljava/lang/String;

    const/4 v8, 0x6

    return-void
.end method

.method public static a()Lio/openinstall/sdk/k;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "su @ b~ot@ b K~ ~~S  ~~  1@ @~y @~m@~~~io@@  @v@@@n~dl~@c~o@~i/M~o-~/o4bb@@~~tr~ @ @@i~ f.@al fo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lio/openinstall/sdk/k;->a:Lio/openinstall/sdk/k;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lio/openinstall/sdk/k;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x4

    move v3, v2

    sget-object v1, Lio/openinstall/sdk/k;->a:Lio/openinstall/sdk/k;

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x3

    new-instance v1, Lio/openinstall/sdk/k;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1}, Lio/openinstall/sdk/k;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-object v1, Lio/openinstall/sdk/k;->a:Lio/openinstall/sdk/k;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v0, Lio/openinstall/sdk/k;->a:Lio/openinstall/sdk/k;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method private a(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v1, "Sayorruenm.dsrtPotedesiqoi."

    const-string v1, "eoepidtrqimPSd.rtyoaseso.nr"

    const-string v1, "dnodrrpps.SyaPteoeor.imtesi"

    const-string v1, "android.os.SystemProperties"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v2, "gte"

    const-string v2, "etg"

    const/4 v8, 0x0

    const-string/jumbo v2, "teg"

    const-string v2, "get"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-array v4, v3, [Ljava/lang/Class;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v6, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    aput-object v5, v4, v6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    aput-object p1, v2, v6

    const/4 v7, 0x3

    move v8, v7

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz p1, :cond_0

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_0

    :catch_0
    :cond_0
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_1
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    return-object v0
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p2}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    xor-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p1
.end method

.method private a([Ljava/lang/String;)Z
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x6

    move v1, v0

    const/4 v9, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/k;->d:[Ljava/lang/String;

    const/4 v9, 0x7

    array-length v3, v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-ge v1, v3, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    aget-object v3, v2, v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v3}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    aput-object v3, v2, v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    array-length v1, p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    move v2, v0

    move v2, v0

    const/4 v9, 0x1

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-ge v2, v1, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    aget-object v3, p1, v2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v3}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {p0, v3}, Lio/openinstall/sdk/k;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v3, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v4, p0, Lio/openinstall/sdk/k;->d:[Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    array-length v5, v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    move v6, v0

    move v6, v0

    const/4 v9, 0x0

    move v6, v0

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ge v6, v5, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    aget-object v7, v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v3, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v7, :cond_1

    const/4 v9, 0x2

    const/4 p1, 0x0

    const/4 v9, 0x4

    const/4 p1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x6

    return p1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    add-int/lit8 v6, v6, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    goto :goto_2

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_1

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    return v0
.end method

.method private b([Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    array-length v0, p1

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    move v2, v1

    move v2, v1

    const/4 v6, 0x0

    move v2, v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ge v2, v0, :cond_1

    const/4 v6, 0x2

    aget-object v3, p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v3}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v4, Ljava/io/File;

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-direct {v4, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 p1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    return p1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    return v1
.end method

.method private c([Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    array-length v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    move v2, v1

    move v2, v1

    const/4 v6, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-ge v2, v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    aget-object v3, p1, v2

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v3}, Lio/openinstall/sdk/dw;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v4, Ljava/io/File;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v4, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    return v1

    :cond_0
    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 p1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    return p1
.end method


# virtual methods
.method public a(Landroid/content/Context;)Z
    .locals 21

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    iget-object v2, v0, Lio/openinstall/sdk/k;->c:Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->setLength(I)V

    const-string v2, "Z9mcuh=cqGYcQd8hGvmms0uc"

    const-string v2, "hcscdxm80GmmG9cuQ=YZhuvc"

    const-string v2, "YGsxmucmhcZcmGmdv=cu8h9Q"

    const-string v2, "cm8uYm9hcmQucGxhdGZvcm0="

    const-string/jumbo v4, "macmGZhummH8yd=F"

    const-string/jumbo v4, "yc=mmdZmHhuc8aFG"

    const-string v4, "UcaHoGmhdm8cZ=Fy"

    const-string v4, "cm8uaGFyZHdhcmU="

    const-string v5, "dumVxb9mh8GyQmpboucn"

    const-string/jumbo v5, "uxYbouV9G8phdmmQyncm"

    const-string/jumbo v5, "mp9hbuuZ8YmQdyGunxcm"

    const-string v5, "cm8uYnVpbGQuZmxhdm9y"

    filled-new-array {v5, v2, v4}, [Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lio/openinstall/sdk/k;->a([Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_0
    const-string v4, "CGd2YGWpoZ5ZSky=Xp9Fbbl5Yc5iJVdH9dvk"

    const-string/jumbo v4, "vGClZb2Wk=k5FoVdgYbpX9d5Z5YicyJH9GdS"

    const-string/jumbo v4, "kG5F5dVZqi2CJbypkoWdXYv9YdSlcmHZ5=9G"

    const-string v4, "YW5kcm9pZC5oYXJkd2FyZS5ibHVldG9vdGg="

    invoke-direct {v0, v1, v4}, Lio/openinstall/sdk/k;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    add-int/lit8 v2, v2, 0x5

    :cond_1
    const-string/jumbo v4, "jJYmZXuWcx5=k5CkW1Sghm25cc9yF2EYomdpuZZY"

    const-string/jumbo v4, "mYsyYFZmCYE95JuScgxkocc2dXkmW=2p5ZZjhl15"

    const-string v4, "YW5kcm9pZC5oYXJkd2FyZS5jYW1lcmEuZmxhc2g="

    invoke-direct {v0, v1, v4}, Lio/openinstall/sdk/k;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    add-int/lit8 v2, v2, 0x5

    :cond_2
    const-string v4, "52DmeS3v9bFtpZ3RvlcmNcmgmdcX"

    const-string v4, "RmccSX9pect2N3mZgd5mFls3vDvb"

    const-string/jumbo v4, "vNL3o3c2DXSgclvtmbZ9mmsd5FRc"

    const-string v4, "L3N5c3RlbS9mcmFtZXdvcmsveDg2"

    const-string/jumbo v5, "v30q3bmgXz5XSDmdNcvbRYmLZ9cclets"

    const-string v5, "5dZDzevtqR3m0cN9bls3YXcvLmFmcSgX"

    const-string v5, "L3N5c3RlbS9mcmFtZXdvcmsveDg2XzY0"

    const-string v6, "XN3sbluR5gjbvwi3YJ32ixl9sYa3Lb4=5NlcGI=i"

    const-string/jumbo v6, "s=s23w5g3RcjNXllI4WvlLb5ax9YiJ3i3YbN=bGi"

    const-string v6, "YGx3Y4ipjRwJ=5NXSbWv3b3agc=NlLl3i529Ilbs"

    const-string v6, "L3N5c3RlbS9saWIvbGliY2xjb3JlX3g4Ni5iYw=="

    const-string v7, "JmegmNI3qGbNj3m9cvaLRDWb2laJjfVs25cLNsW9"

    const-string/jumbo v7, "v9lm2bC5GgcDaNsIJJWNm3NVmLjWfsL23a9ecbjR"

    const-string v7, "Nmsc3leLfJCja2Nma9I3RgJsvG2sbDNbVW5c9WjL"

    const-string v7, "L3N5c3RlbS9saWI2NC9saWJjbGNvcmVfeDg2LmJj"

    const-string v8, "993mWAbib=N4mBSvcRLaL34b53ly"

    const-string v8, "L3N5c3RlbS9iaW4vbm94LXByb3A="

    const-string/jumbo v9, "wHwcoLoma53JZQ3v9vS1ia4WCRWbcNle"

    const-string v9, "eL9Jo0cHa4aWCW3vNm5vSiwZc3R1Qlbw"

    const-string v9, "39e3SbHRlcaCJQwm09bZW5ciwv4WLaN1"

    const-string v9, "L3N5c3RlbS9iaW4vZHJvaWQ0eC1wcm9w"

    const-string/jumbo v10, "vN93w5u9WlLSb1W4iR3TbRcHmcdS"

    const-string/jumbo v10, "iWT95bd9RSvmc3RNS1L4ab3WlwHc"

    const-string v10, "RRwcScapm9i493NbWWl1wLS3d5Hv"

    const-string v10, "L3N5c3RlbS9iaW4vdHRWTS1wcm9w"

    const-string v11, "caWX4mN9qu=yLW59LvjblR2J3aciSXB3b0b3"

    const-string v11, "3LJWa0ub=3ylS4Lc9iBRbaXljmcWv92XN35b"

    const-string v11, "WXsbBLbNajS9c9lAb3ciJ3Xl2y0mvaW5L=R3"

    const-string v11, "L3N5c3RlbS9iaW4vbWljcm92aXJ0LXByb3A="

    const-string v12, "LX=mbabAyb5ZtdNWSVL34N3pcBl9Vv3m"

    const-string v12, "=XctybapSV4LAm39i53LBldZ3bvbNNWV"

    const-string v12, "bvLyolXNcARL9Zd5a4NmVVB=b33tSb3i"

    const-string v12, "L3N5c3RlbS9iaW4vbmVtdVZNLXByb3A="

    const-string v13, "ScWT5bNm959Ycl9WkWw3vLR1w34aimSb"

    const-string v13, "L3N5c3RlbS9iaW4vYW5kcm9WTS1wcm9w"

    const-string/jumbo v14, "v5dSe9ub93Wcm2iYN1WVaLNqZ4b41uL3GvivmRll"

    const-string/jumbo v14, "uVNLW1vXqSll4mc9Y9Rbi1G2i34Nv5aeZbvmdW3L"

    const-string v14, "4S42Xa3pbW2YWmZ3iV1udRb1i9c5lLmvNvelLvNG"

    const-string v14, "L3N5c3RlbS9iaW4vZ2VueW1vdGlvbi12Ym94LXNm"

    const-string v15, "S1oZvcldqRdlNbNG3shRN35a5y5CWnpLLbbM"

    const-string v15, "Sbshl5WdboC3GL91lL5RnR5ZbdyMaNNN3vpc"

    const-string v15, "5Csl9NRy5ZdNGp313blamnMhdSWLbNbcLRo5"

    const-string v15, "L3N5c3RlbS9ldGMvaW5pdC5hbmRyb1ZNLnNo"

    const-string v16, "5t3mlV1mLbWvaX2SbNMldS35dRGjb9zd"

    const-string v16, "1dcmdbzv359V5LSjRa3lNbGMmt2SlbWd"

    const-string v16, "L3N5c3RlbS9ldGMvbXVtdS1jb25maWdz"

    const-string v17, "4NWboRF0hAg352vhHoL2Nha=2QbVclv53943=SLg"

    const-string v17, "g=gVoAhW9Q2R=hLvSH0va335h4Flc2NL2b4Nbc53"

    const-string v17, "gNlhAb34aV=c=LS53F3v2RbbL0vhch5QSH42Ng92"

    const-string v17, "L3N5c3RlbS9hcHAvS2V5Q2hhaW4vb2F0L3g4Ng=="

    const-string v18, "V33lg4ucb8Na22lN9NAvbLhHA=0vLF232bRhhcSW5SQ="

    const-string v18, "S2bv0b9F=33QlaVHchgN4cL223A4v5l=bSLNNh2Rh8WA"

    const-string v18, "=hvW0lvpN2gLQbFcaSH4292hNAScV5582AN4h333Lb=R"

    const-string v18, "L3N5c3RlbS9hcHAvS2V5Q2hhaW4vb2F0L3g4Nl82NA=="

    const-string v19, "gtZ=uvsNqb9L0RgcF4cc3=Fbd23LmXmS5lvm"

    const-string v19, "cb3cS=uXdv02=m5bmFFcLsZN9LgvRt34gl3m"

    const-string v19, "L3N5c3RlbS9mcmFtZXdvcmsvb2F0L3g4Ng=="

    const-string v20, "clsv43cAm=cRtFZml3SLp9g3FXvN05Nbsb2dmLN8"

    const-string/jumbo v20, "vlbRL5ZpctX3v38NASd0LmsFcN2m=g93b4N=cFlm"

    const-string v20, "L3N5c3RlbS9mcmFtZXdvcmsvb2F0L3g4Nl82NA=="

    filled-new-array/range {v4 .. v20}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lio/openinstall/sdk/k;->b([Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    add-int/lit8 v2, v2, 0xa

    :cond_3
    const-string v1, "ZhamSN4bVya3c5ZNW3blQcLqWwtZX5WQR=dWVjbd2lwl5vXGkM9H"

    const-string/jumbo v1, "tvw5XlXQqGZ4VlZtRd2lWjHabh=QkadbNSWWM3Ncywbc5L5WVZ39"

    const-string v1, "4GWMoawh5GQdlWvc9VLbbcbZSkX55Wldlwa2Zjy=R3NNHZXVtWQt"

    const-string v1, "L3N5c3RlbS9ldGMvZXhjbHVkZWQtaW5wdXQtZGV2aWNlcy54bWw="

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lio/openinstall/sdk/k;->b([Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    if-ge v1, v4, :cond_4

    add-int/lit8 v2, v2, 0x5

    goto :goto_1

    :cond_4
    add-int/lit8 v2, v2, 0x3

    :cond_5
    :goto_1
    const-string/jumbo v1, "mcdRXbbmJLvlssYSZm35c9tN3cFv"

    const-string/jumbo v1, "tNs3Y3vlmdSX9ZLmbcFc5sJtvRcm"

    const-string v1, "cLmdXcuR3mXFvtNbStl9Zs5cvYJm"

    const-string v1, "L3N5c3RlbS9mcmFtZXdvcmsvYXJt"

    const-string/jumbo v4, "tXN5tmvpJ9XFsNSmccZYvjclm3mb3LQ="

    const-string v4, "XQZmXvstmc5RlmSc9LFY3N3jNmbJt=cv"

    const-string v4, "NcvstmXRqFJYLXc3Z3Sm59dcQbN=jvmt"

    const-string v4, "L3N5c3RlbS9mcmFtZXdvcmsvYXJtNjQ="

    filled-new-array {v1, v4}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lio/openinstall/sdk/k;->c([Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    add-int/lit8 v2, v2, 0x7

    :cond_6
    const/16 v1, 0xa

    if-lt v2, v1, :cond_7

    const/4 v3, 0x1

    :cond_7
    return v3
.end method
