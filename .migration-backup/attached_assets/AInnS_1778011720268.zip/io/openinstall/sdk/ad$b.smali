.class Lio/openinstall/sdk/ad$b;
.super Lio/openinstall/sdk/ad$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/ad;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lio/openinstall/sdk/ad;

.field private b:Ljava/util/concurrent/BlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/BlockingQueue<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/openinstall/sdk/ad;Ljava/util/concurrent/BlockingQueue;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/BlockingQueue<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/ad$b;->a:Lio/openinstall/sdk/ad;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/ad$c;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lio/openinstall/sdk/ad$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method a(IJZFDLjava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method a(ILandroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    const-string p1, "dssfai_a_l"

    const-string/jumbo p1, "l_safid_ga"

    const/4 v1, 0x3

    const-string/jumbo p1, "oa_id_flag"

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x1

    const-string p1, ""

    const-string p1, ""

    :goto_0
    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p2, p0, Lio/openinstall/sdk/ad$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p2, p1}, Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
