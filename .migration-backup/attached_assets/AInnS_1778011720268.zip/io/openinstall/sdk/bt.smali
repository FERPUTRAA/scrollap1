.class public Lio/openinstall/sdk/bt;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/bt$b;,
        Lio/openinstall/sdk/bt$a;
    }
.end annotation


# direct methods
.method public static a()Lio/openinstall/sdk/bt$b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " csb  ~@Ko  @@@~o~~~M@ ~io~l~@~@~.@f@s4@~b otf~@ ~@ ~@oity~~ nl~m@  ~u/  o~@1@ /-~a@ @rvi @~@db~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lio/openinstall/sdk/bt$b;->a:Lio/openinstall/sdk/bt$b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object v0
.end method

.method public static b()Lio/openinstall/sdk/bt$b;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    sget-object v0, Lio/openinstall/sdk/bt$b;->b:Lio/openinstall/sdk/bt$b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static c()Lio/openinstall/sdk/bt$a;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lio/openinstall/sdk/bt$a;->a:Lio/openinstall/sdk/bt$a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static d()Lio/openinstall/sdk/bt$a;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lio/openinstall/sdk/bt$a;->b:Lio/openinstall/sdk/bt$a;

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
