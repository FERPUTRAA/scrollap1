.class final Lio/openinstall/sdk/t$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation


# instance fields
.field a:Z

.field private final b:Ljava/util/concurrent/LinkedBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/LinkedBlockingQueue<",
            "Landroid/os/IBinder;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/openinstall/sdk/t$b;->a:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lio/openinstall/sdk/t$b;->b:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lio/openinstall/sdk/u;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/t$b;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Landroid/os/IBinder;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ s-~.to@/@    iubv~ @~o~@~ /@~~@S ~~ro~sn b~~@c4lb@f@o~ ~~ afMi~@ ~~ d@~~i1@m@  ~  @@oK~@y@olt@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-boolean v0, p0, Lio/openinstall/sdk/t$b;->a:Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x2

    iput-boolean v0, p0, Lio/openinstall/sdk/t$b;->a:Z

    const/4 v5, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/t$b;->b:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-wide/16 v1, 0x3

    const-wide/16 v1, 0x3

    const/4 v5, 0x0

    const-wide/16 v1, 0x3

    const-wide/16 v1, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/util/concurrent/LinkedBlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast v0, Landroid/os/IBinder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw v0
.end method

.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/t$b;->b:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Ljava/util/concurrent/LinkedBlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method
