.class public Lio/openinstall/sdk/cf;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/cf$a;
    }
.end annotation


# instance fields
.field private final a:J

.field private final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/openinstall/sdk/ce<",
            "Ljava/lang/Integer;",
            "Lio/openinstall/sdk/cf$a;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(J)V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-wide p1, p0, Lio/openinstall/sdk/cf;->a:J

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method private a(I)[B
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/ds@f@@~~~v@@~~~@~~t~@om@ r~@~M~~toa@- . ~i~@s@n~l/  o@~c  yoi@@ ~4  l~1b@fi  @@~ S  bo~ @ ~oKu@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v1, Lio/openinstall/sdk/ce;

    const/4 v4, 0x0

    const/4 v3, 0x0

    iget-object v2, v1, Lio/openinstall/sdk/ce;->a:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v2, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne v2, p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p1, v1, Lio/openinstall/sdk/ce;->b:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p1, Lio/openinstall/sdk/cf$a;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Lio/openinstall/sdk/cf$a;->a()[B

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p1
.end method

.method private b(I)V
    .locals 4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v1, Lio/openinstall/sdk/ce;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, v1, Lio/openinstall/sdk/ce;->a:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v1, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public a()J
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-wide v0, p0, Lio/openinstall/sdk/cf;->a:J

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cf;->c()J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-long/2addr v0, v2

    const/4 v5, 0x5

    return-wide v0
.end method

.method public a(I[B)V
    .locals 7

    const/4 v5, 0x3

    const/4 v6, 0x3

    array-length v0, p2

    const/4 v6, 0x1

    add-int/lit8 v0, v0, 0x8

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/lit8 v0, v0, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x5

    new-array v1, v0, [B

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    sget-object v3, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int/lit8 v0, v0, -0x8

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    int-to-long v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2, v3, v4}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v2, p2}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance p2, Lio/openinstall/sdk/ce;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v2, Lio/openinstall/sdk/cf$a;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v2, v1}, Lio/openinstall/sdk/cf$a;-><init>([B)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p2, v0, v2}, Lio/openinstall/sdk/ce;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/List;->listIterator()Ljava/util/ListIterator;

    move-result-object v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/ListIterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    check-cast v1, Lio/openinstall/sdk/ce;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, v1, Lio/openinstall/sdk/ce;->a:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v1, Ljava/lang/Integer;

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ne v1, p1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v0, p2}, Ljava/util/ListIterator;->set(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void

    :cond_1
    const/4 v5, 0x2

    move v6, v5

    iget-object p1, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void
.end method

.method public a([B)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const v0, 0x3ae21354

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lio/openinstall/sdk/cf;->b(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, v0, p1}, Lio/openinstall/sdk/cf;->a(I[B)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public b()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-wide v0, p0, Lio/openinstall/sdk/cf;->a:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method

.method public c()J
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-wide/16 v1, 0x20

    const-wide/16 v1, 0x20

    const/4 v6, 0x1

    const-wide/16 v1, 0x20

    const-wide/16 v1, 0x20

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast v3, Lio/openinstall/sdk/ce;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v3, v3, Lio/openinstall/sdk/ce;->b:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v3, Lio/openinstall/sdk/cf$a;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v3, v3, Lio/openinstall/sdk/cf$a;->a:[B

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    array-length v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    int-to-long v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    add-long/2addr v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-wide v1
.end method

.method public synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/cf;->f()Lio/openinstall/sdk/cf;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public d()[B
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const v0, 0x3ae21354

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lio/openinstall/sdk/cf;->a(I)[B

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()[Ljava/nio/ByteBuffer;
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-int/lit8 v0, v0, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-array v0, v0, [Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/cf;->c()J

    move-result-wide v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v3, 0x8

    const-wide/16 v3, 0x8

    const/4 v8, 0x0

    const-wide/16 v3, 0x8

    const-wide/16 v3, 0x8

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    sub-long/2addr v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v3, 0x8

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v3, v1, v2}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    check-cast v3, Ljava/nio/ByteBuffer;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    aput-object v3, v0, v4

    const/4 v7, 0x0

    move v8, v7

    iget-object v3, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v8, 0x1

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v4, 0x5

    const/4 v4, 0x1

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v5, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    check-cast v5, Lio/openinstall/sdk/ce;

    const/4 v8, 0x0

    add-int/lit8 v6, v4, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v5, v5, Lio/openinstall/sdk/ce;->b:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast v5, Lio/openinstall/sdk/cf$a;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v5, v5, Lio/openinstall/sdk/cf$a;->a:[B

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v5}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    aput-object v5, v0, v4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    move v4, v6

    move v4, v6

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/16 v3, 0x18

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    sget-object v5, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v3, v5}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, v1, v2}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-wide v2, 0x20676953204b5041L

    const-wide v2, 0x20676953204b5041L

    const/4 v8, 0x2

    const-wide v2, 0x20676953204b5041L

    const-wide v2, 0x20676953204b5041L

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1, v2, v3}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-wide v2, 0x3234206b636f6c42L    # 7.465385175170059E-67

    const-wide v2, 0x3234206b636f6c42L    # 7.465385175170059E-67

    const/4 v8, 0x7

    const-wide v2, 0x3234206b636f6c42L    # 7.465385175170059E-67

    const-wide v2, 0x3234206b636f6c42L    # 7.465385175170059E-67

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v1, v2, v3}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    check-cast v1, Ljava/nio/ByteBuffer;

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    aput-object v1, v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object v0
.end method

.method public f()Lio/openinstall/sdk/cf;
    .locals 8

    const/4 v6, 0x5

    move v7, v6

    new-instance v0, Lio/openinstall/sdk/cf;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-wide v1, p0, Lio/openinstall/sdk/cf;->a:J

    const/4 v6, 0x7

    move v7, v6

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cf;-><init>(J)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v1, p0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    check-cast v2, Lio/openinstall/sdk/ce;

    const/4 v6, 0x4

    or-int/2addr v7, v6

    iget-object v3, v0, Lio/openinstall/sdk/cf;->b:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v4, Lio/openinstall/sdk/ce;

    const/4 v7, 0x4

    const/4 v6, 0x3

    iget-object v5, v2, Lio/openinstall/sdk/ce;->a:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x0

    iget-object v2, v2, Lio/openinstall/sdk/ce;->b:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v4, v5, v2}, Lio/openinstall/sdk/ce;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    return-object v0
.end method
