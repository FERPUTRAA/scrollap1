.class public final enum Lio/openinstall/sdk/dz;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lio/openinstall/sdk/dz;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lio/openinstall/sdk/dz;

.field public static final enum b:Lio/openinstall/sdk/dz;

.field public static final enum c:Lio/openinstall/sdk/dz;

.field public static final enum d:Lio/openinstall/sdk/dz;

.field private static final synthetic g:[Lio/openinstall/sdk/dz;


# instance fields
.field private final e:Ljava/lang/String;

.field private final f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v0, Lio/openinstall/sdk/dz;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v1, "6us/ 4u67s3u655/0uudbb6/u85u42u3f4f4///5/b9///66u02//u5u64042/b572461u0%/f/7e/1c00755su8uu757895du0"

    const-string v1, "73sc4bb/42655//6ud//50482e/766u2500/69512/0u580u/77s//97bu6/u55/7u6/ubu6f9/4u85%/fuf04u 3duu01u5u44"

    const/4 v6, 0x7

    const-string v1, "48um 9/71/477/63uu044514cuu2u/2u8u5/bs77u656/uf0uf//639/00u00u57b4//5259/bu6ed%/5754058u6d//56f6b2/"

    const-string/jumbo v1, "\u4f20\u5165\u7684\u6548\u679c\u70b9\u540d\u79f0\u5305\u542b\u4e0d\u652f\u6301\u7684\u5b57\u7b26 %s"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v2, "vndcos ne rnandosahrutecetoti i% rsdtop pmeprmcu aveas hee"

    const-string v2, "eermnco hre snpupuanstd e isTmn eecco%vt ditprvr eatsaahdo"

    const-string v2, "eth  bdpci tahvsmo n asrn% s aipnournrpnescuveeoetcTdteard"

    const-string v2, "The provided event name contains unsupported characters %s"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v3, "dtano_veeinivlamn_"

    const/4 v6, 0x2

    const-string/jumbo v3, "nvdavnunl_emte_iie"

    const-string v3, "event_name_invalid"

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x7

    shl-int/2addr v5, v4

    const/4 v6, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lio/openinstall/sdk/dz;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    move v6, v5

    sput-object v0, Lio/openinstall/sdk/dz;->a:Lio/openinstall/sdk/dz;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v0, Lio/openinstall/sdk/dz;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v1, "7/du465p4760//05cu4cb//8927/5uu55uu854528f8uu/9/757u4uu6026uc/86u2/b9/fu361/6693/5/0"

    const-string v1, "466/6b/7u8u5c/09c/69c8//udu/u65u3249f/a378506u4/5u82u915640/57u//u502f578u7/u5/4b62u"

    const/4 v6, 0x2

    const-string v1, "/auf/327q982746978c/u6/55d/0456u6c0386/9//56u1/548cu25/00/548654/u76uuu/2u50u7fbuuu9"

    const-string/jumbo v1, "\u4f20\u5165\u7684\u6548\u679c\u70b9\u9644\u52a0\u53c2\u6570\u8d85\u8fc7\u9650\u5236"

    const/4 v6, 0x1

    const-string/jumbo v2, "o st tidu rhsaeTipa lvrddro geeoaea "

    const-string v2, " gTte ueo dixealrdaisdeo tao  apvrhr"

    const/4 v6, 0x7

    const-string v2, " drm oix gtdae edoretplasviho a Tear"

    const-string v2, "The provided extra data is too large"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const-string v3, "gtreotrleveapxanr_"

    const-string v3, "evtgarxpel_teranre"

    const/4 v6, 0x6

    const-string/jumbo v3, "reelabvgtatr_x_ere"

    const-string v3, "event_extra_larger"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v0, v3, v4, v1, v2}, Lio/openinstall/sdk/dz;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    sput-object v0, Lio/openinstall/sdk/dz;->b:Lio/openinstall/sdk/dz;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v0, Lio/openinstall/sdk/dz;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v1, "34u/7uuq/4705679u921/75731eu22u6337/8ue/b/7d/u8/u3uub5e7u863c8n0533u0feu4u/23/8//9u/24u5//e4fu16920u0/1i6//62u1/56uc9455/e2ue0ea5uuu/678u4u66ibce0u5u//7f777/c/tuf49///cbcufu304e0855508e6//efu7pu//u4/85885c5i/40/f80cfe90e0u17/uuf0ua/71f80//34"

    const-string v1, "/a/5uu54q7e5/c7/u702u0/fuu/77//76c72u/44/87f42//i9f4u/53u5u//13/82u6e4i65/08ed0e//786u46//tub/f3a8f/66/3ne/cu5/ef908/4euc/2uuu/e29059ef/78637u0u9i5uu5pf57107u/ub08u5403/6uuuuu30f57832/1u0e6b/0cc98ue4/61/09408uu18/eu0/5fu43uu5u81e3e5c3c1b7/72"

    const-string v1, "/6c2//up3e74/9/uu3f/7eu/u/4/5uu15fucf312u/5ubu//ubu1u//41i8386/uu949/b3u7e7tu084085/0e20e86ff7e177853/91//766515/55bu0iu7fecuu7///0c650uu4a/5ie50074/4/f0eduuf9e9/e6/0u4uc0af0p528586//20/38f8uc57ue6335u93/2c787uuu/304/uu487225nu//u/064/e6e7u8"

    const-string/jumbo v1, "\u7591\u4f3c\u5e94\u7528\u5904\u4e8e\u540e\u53f0\u4e0d\u53ef\u89c1\u72b6\u6001\u4e0b\u8c03\u7528init\uff0c\u5e76\u4e14\u63a5\u7740\u8c03\u7528\u5176\u5b83api\uff0c\u6570\u636e\u5927\u6982\u7387\u4e22\u5931\uff0c\u8bf7\u68c0\u67e5\u4ee3\u7801"

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    const-string v2, "a toseptqcac ai t t h mfwln aikiud he gttbnCiha efgyieaohtnals isintltorcadhp elra "

    const-string v2, "hrsgp ncne  l bs haalietfeoi pdduamgCh t   fit tkls a itaci tyhlatrataotiionhncaewe"

    const-string v2, "etsngtairCa orfidhdocl lhtkiwta isatt ieafcpc tlaabnelshp   unm igtiat nha leo y  e"

    const-string v2, "Calling start while the application is in the background may fail to fetch the data"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo v3, "iibmnamotkrgu_n"

    const-string/jumbo v3, "outmiirgdnb_akn"

    const/4 v6, 0x3

    const-string/jumbo v3, "init_background"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v0, v3, v4, v1, v2}, Lio/openinstall/sdk/dz;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    sput-object v0, Lio/openinstall/sdk/dz;->c:Lio/openinstall/sdk/dz;

    const/4 v6, 0x0

    const/4 v5, 0x1

    new-instance v0, Lio/openinstall/sdk/dz;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const-string v1, "d60uo8s72u3ub/ 3o//55"

    const-string/jumbo v1, "s3duo/83 u56750//2u3b"

    const/4 v6, 0x0

    const-string v1, "/%/ ubbd/5s23367380u5"

    const-string/jumbo v1, "\u83b7\u53d6\u5230 %s"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v2, "G%ahatud : neegi tsb"

    const-string/jumbo v2, "taGntb  e%dste:iahg "

    const/4 v6, 0x1

    const-string v2, "Getting the data: %s"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string/jumbo v3, "taitnu_paegt"

    const-string v3, "g_atdtutneia"

    const/4 v6, 0x3

    const-string v3, "atgneti_qdat"

    const-string v3, "getting_data"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v0, v3, v4, v1, v2}, Lio/openinstall/sdk/dz;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    sput-object v0, Lio/openinstall/sdk/dz;->d:Lio/openinstall/sdk/dz;

    const/4 v5, 0x6

    move v6, v5

    invoke-static {}, Lio/openinstall/sdk/dz;->b()[Lio/openinstall/sdk/dz;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object v0, Lio/openinstall/sdk/dz;->g:[Lio/openinstall/sdk/dz;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x5

    or-int/2addr v1, v0

    iput-object p3, p0, Lio/openinstall/sdk/dz;->e:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p4, p0, Lio/openinstall/sdk/dz;->f:Ljava/lang/String;

    const/4 v1, 0x2

    return-void
.end method

.method private static synthetic b()[Lio/openinstall/sdk/dz;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s@@/~~t M~i@ u@~@~~~o~@fs@ a cl-i4~ S ~b@~ m oo.bn~ @r@d f1@~i~/@@K @@b~~@ ~@ ovl  y  ~~o~@@~o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-array v0, v0, [Lio/openinstall/sdk/dz;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v2, Lio/openinstall/sdk/dz;->a:Lio/openinstall/sdk/dz;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Lio/openinstall/sdk/dz;->b:Lio/openinstall/sdk/dz;

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x2

    or-int/2addr v3, v1

    const/4 v4, 0x5

    sget-object v2, Lio/openinstall/sdk/dz;->c:Lio/openinstall/sdk/dz;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x2

    move v4, v3

    sget-object v2, Lio/openinstall/sdk/dz;->d:Lio/openinstall/sdk/dz;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/openinstall/sdk/dz;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-class v0, Lio/openinstall/sdk/dz;

    const-class v0, Lio/openinstall/sdk/dz;

    const/4 v2, 0x2

    const-class v0, Lio/openinstall/sdk/dz;

    const-class v0, Lio/openinstall/sdk/dz;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Lio/openinstall/sdk/dz;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lio/openinstall/sdk/dz;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lio/openinstall/sdk/dz;->g:[Lio/openinstall/sdk/dz;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lio/openinstall/sdk/dz;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast v0, [Lio/openinstall/sdk/dz;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->b()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/dz;->f:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/dz;->e:Ljava/lang/String;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method
