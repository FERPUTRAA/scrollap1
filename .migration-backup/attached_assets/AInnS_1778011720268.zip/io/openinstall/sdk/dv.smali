.class Lio/openinstall/sdk/dv;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/concurrent/LinkedBlockingQueue;

.field final synthetic b:Lio/openinstall/sdk/cw;

.field final synthetic c:Lio/openinstall/sdk/ds;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/ds;Ljava/util/concurrent/LinkedBlockingQueue;Lio/openinstall/sdk/cw;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/dv;->c:Lio/openinstall/sdk/ds;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p2, p0, Lio/openinstall/sdk/dv;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p3, p0, Lio/openinstall/sdk/dv;->b:Lio/openinstall/sdk/cw;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@-s ~~~@S~~iu~a@o~@/ K@ @ voi@ @~~~yM @@  r@bo~@t4~ifo@1t .s  @c/o~b @~d~ ~fl~ ~~~lbo@@@ @~  @~n"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/openinstall/sdk/dv;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Lio/openinstall/sdk/dv;->b:Lio/openinstall/sdk/cw;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1}, Lio/openinstall/sdk/cw;->e()Lio/openinstall/sdk/cv;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method
