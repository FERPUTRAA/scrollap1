.class public Lio/openinstall/sdk/ay;
.super Ljava/lang/Object;


# static fields
.field private static k:Lio/openinstall/sdk/ay;

.field private static final l:Ljava/lang/Object;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lio/openinstall/sdk/at;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/Integer;

.field private final f:Ljava/lang/String;

.field private final g:Ljava/lang/String;

.field private final h:Ljava/lang/String;

.field private final i:Ljava/lang/String;

.field private final j:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;

.field private o:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    sput-object v0, Lio/openinstall/sdk/ay;->l:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Lio/openinstall/sdk/at;)V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "HardwareIds"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/ay;->a:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object p2, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/ay;->c:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object p2, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p2, p0, Lio/openinstall/sdk/ay;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p2, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget p2, p1, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    iget-object v0, p1, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v3, 0x5

    goto :goto_0

    :catch_0
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :catch_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object p2, p0, Lio/openinstall/sdk/ay;->e:Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lio/openinstall/sdk/ay;->f:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object p1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/ay;->g:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p1, Landroid/os/Build;->ID:Ljava/lang/String;

    const/4 v3, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/ay;->h:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object p1, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ay;->i:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object p1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ay;->j:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;Lio/openinstall/sdk/at;)Lio/openinstall/sdk/ay;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "M~s~ ~vl  ~@i1@r@t @S @~ t@i@i- l .~4~@@~ @/n@bo~a~@o~~~ @y c~  ~o~@~ob/m@@ f~ @buo@s@ ~Kf@ d~~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lio/openinstall/sdk/ay;->l:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v1, Lio/openinstall/sdk/ay;->k:Lio/openinstall/sdk/ay;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lio/openinstall/sdk/ay;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1}, Lio/openinstall/sdk/ay;-><init>(Landroid/content/Context;Lio/openinstall/sdk/at;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object v1, Lio/openinstall/sdk/ay;->k:Lio/openinstall/sdk/ay;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p0, Lio/openinstall/sdk/ay;->k:Lio/openinstall/sdk/ay;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw p0
.end method

.method private a(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lio/openinstall/sdk/dx;->m:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 p1, 0x4

    const/4 p1, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method

.method private b(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x2

    sget-object v0, Lio/openinstall/sdk/dx;->i:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lio/openinstall/sdk/dx;->m:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "HardwareIds"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ay;->m:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0}, Lio/openinstall/sdk/at;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    :try_start_0
    const/4 v4, 0x7

    iget-object v1, p0, Lio/openinstall/sdk/ay;->a:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v2, "dismodd_ri"

    const-string/jumbo v2, "odsid_iadr"

    const-string v2, "android_id"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v1, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lio/openinstall/sdk/ay;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v3, 0x4

    move v4, v3

    sget-object v1, Lio/openinstall/sdk/dx;->m:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/at;->d(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/at;->d(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/ay;->m:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/ay;->m:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "HardwareIds"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->n:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/at;->g()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/16 v2, 0x1a

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ge v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object v0, Landroid/os/Build;->SERIAL:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lcom/alipay/security/mobile/module/b/b;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    :catchall_0
    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lio/openinstall/sdk/ay;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_3

    const/4 v4, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v1, Lio/openinstall/sdk/dx;->m:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/at;->e(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_1

    :cond_3
    const/4 v3, 0x7

    move v4, v3

    iget-object v1, p0, Lio/openinstall/sdk/ay;->b:Lio/openinstall/sdk/at;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/at;->e(Ljava/lang/String;)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lio/openinstall/sdk/ay;->n:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->n:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/ay;->o:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x0

    return-object v0

    :cond_0
    :try_start_0
    const/4 v9, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->a:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lio/openinstall/sdk/ay;->a:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/16 v2, 0x40

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    aget-object v0, v0, v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v2, "ASH1"

    const-string v2, "SH1A"

    const/4 v9, 0x3

    const-string v2, "AHS1"

    const-string v2, "SHA1"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v2}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v2, v0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    array-length v3, v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    move v4, v1

    move v4, v1

    const/4 v9, 0x2

    move v4, v1

    move v4, v1

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v8, 0x0

    and-int/2addr v9, v8

    if-ge v4, v3, :cond_2

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    aget-byte v6, v0, v4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    and-int/lit16 v6, v6, 0xff

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v6}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-ne v7, v5, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v5, "0"

    const-string v5, "0"

    const/4 v9, 0x3

    const-string v5, "0"

    const-string v5, "0"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string v5, ":"

    const-string v5, ":"

    const/4 v9, 0x6

    const-string v5, ":"

    const-string v5, ":"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    sub-int/2addr v2, v5

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/ay;->o:Ljava/lang/String;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    :catchall_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->o:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-object v0
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ay;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ay;->d:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public f()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/ay;->e:Ljava/lang/Integer;

    const/4 v2, 0x0

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/ay;->f:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/ay;->g:Ljava/lang/String;

    const/4 v2, 0x3

    return-object v0
.end method

.method public i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/ay;->h:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public j()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/ay;->i:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public k()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ay;->j:Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method public l()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/ay;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x3

    xor-int/2addr v5, v1

    :try_start_0
    const/4 v6, 0x5

    new-instance v2, Ljava/io/RandomAccessFile;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v3, "r"

    const-string/jumbo v3, "r"

    const-string/jumbo v3, "r"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v2, v0, v3}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0}, Lio/openinstall/sdk/cc;->a(Ljava/nio/channels/FileChannel;)Lio/openinstall/sdk/cb;

    move-result-object v2
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    :try_start_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v3

    :cond_1
    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2}, Lio/openinstall/sdk/cb;->c()[B

    move-result-object v2
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v0, :cond_2

    :try_start_4
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    :catch_1
    :cond_2
    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object v3

    :cond_3
    const/16 v3, 0xa

    :try_start_5
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2, v3}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget-object v4, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v3, v2, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_4

    :try_start_6
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    :cond_4
    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_1

    :catchall_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :catchall_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    :goto_0
    :try_start_7
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_5

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_1

    :catch_3
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :catch_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :catch_5
    :cond_5
    :goto_1
    const/4 v6, 0x1

    return-object v1
.end method

.method public m()Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :try_start_0
    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_3

    :cond_0
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v2, Ljava/net/NetworkInterface;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->isLoopback()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v3, :cond_0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->isUp()Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v4, "mmmyo"

    const-string/jumbo v4, "mmumy"

    const/4 v6, 0x7

    const-string v4, "bumyd"

    const-string v4, "dummy"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    move-result-object v2

    :cond_2
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v3, :cond_0

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v3, Ljava/net/InetAddress;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    instance-of v4, v3, Ljava/net/Inet4Address;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v4, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/net/SocketException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_1

    :catch_0
    :catchall_0
    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object v0
.end method
