.class public Lio/openinstall/sdk/ea;
.super Ljava/lang/Object;


# direct methods
.method private static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~sod@mS@b~r~t o @ ~~1~~ @~  s~ Mc@ y~  //oi~@ b~@@@Ki  @o-v  ln~@f@b~uo4~~f@~~i@@ ~ @~~alt@o@.@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/16 v2, 0x80

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    const/4 v4, 0x0

    if-eqz p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :catch_0
    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v0
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "emsmnscPAYl.n._Pilaoopt"

    const-string/jumbo v0, "losnantYc.p.E_oPiePsAlm"

    const/4 v2, 0x2

    const-string v0, "com.openinstall.APP_KEY"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lio/openinstall/sdk/ea;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :catch_0
    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "nsomD.EiPampNcnLoAltBBEle."

    const-string v0, "aEc_oBimnlE.NDplPBsoe.tonA"

    const-string v0, "com.openinstall.PB_ENABLED"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lio/openinstall/sdk/ea;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p0

    :catch_0
    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p0
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "oNnBSblGso._c.npltoPmAaeL"

    const-string v0, "GBpmotealAc..LNosolnn_SPi"

    const/4 v2, 0x5

    const-string v0, "A.pa.oucnlINsmlonPGe_itLS"

    const-string v0, "com.openinstall.PB_SIGNAL"

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lio/openinstall/sdk/ea;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p0

    :catch_0
    :cond_0
    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v2, 0x1

    move v1, p0

    move v1, p0

    const/4 v2, 0x5

    return p0
.end method

.method public static d(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "toelAanpml.AoTDspi_.CKRc"

    const-string v0, "com.openinstall.AD_TRACK"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lio/openinstall/sdk/ea;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p0

    :catch_0
    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p0
.end method
