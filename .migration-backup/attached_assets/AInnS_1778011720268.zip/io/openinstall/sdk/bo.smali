.class public Lio/openinstall/sdk/bo;
.super Landroid/os/Handler;


# instance fields
.field protected a:Lio/openinstall/sdk/aq;

.field protected b:Lio/openinstall/sdk/aw;

.field protected c:Lio/openinstall/sdk/ck;

.field protected d:Lio/openinstall/sdk/at;

.field private final e:Lio/openinstall/sdk/bi;

.field private f:J

.field private g:I


# direct methods
.method public constructor <init>(Landroid/os/Looper;Lio/openinstall/sdk/av;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p1, p0, Lio/openinstall/sdk/bo;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2}, Lio/openinstall/sdk/av;->e()Lio/openinstall/sdk/aq;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/bo;->a:Lio/openinstall/sdk/aq;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2}, Lio/openinstall/sdk/av;->f()Lio/openinstall/sdk/aw;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2}, Lio/openinstall/sdk/av;->c()Lio/openinstall/sdk/ck;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/bo;->c:Lio/openinstall/sdk/ck;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p2}, Lio/openinstall/sdk/av;->d()Lio/openinstall/sdk/at;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/bo;->d:Lio/openinstall/sdk/at;

    const/4 v2, 0x5

    const/4 v1, 0x7

    new-instance p1, Lio/openinstall/sdk/bi;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->b()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, p2, v0}, Lio/openinstall/sdk/bi;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/bo;->d:Lio/openinstall/sdk/at;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/at;->d()J

    move-result-wide p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-wide p1, p0, Lio/openinstall/sdk/bo;->f:J

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method private a(Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "4 s@ a~~~ o@il @~on@ ~~ @@ ~So~y-u@@@~ c@~.@~/if~~ ~ @mt db@@1 ~io   M~~ov~ob@~@ r~s@@~l/~@@f tK"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bo;->b(Z)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->f()V

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private b()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method private b(Lio/openinstall/sdk/be;)Z
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->b()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v2, "fSemnsaidslt absenatlese v"

    const-string/jumbo v2, "iesbdS esattetsanlfaen vsl"

    const/4 v5, 0x6

    const-string v2, "eaftontbsaE at levSssnield"

    const-string v2, "eventStatsEnabled is false"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne v0, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/aw;->f()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    if-eqz p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v2, p1}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v3

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->b()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v0, v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/aw;->f()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v5, 0x1

    invoke-static {v2, p1}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v3

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->b()I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p1, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->d()Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez p1, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    if-eqz p1, :cond_4

    const/4 v5, 0x7

    const-string/jumbo p1, "stemaanere aSidiftbleEltssrsg"

    const/4 v5, 0x1

    const-string p1, "besdabnes itigteslfasrteSaEl "

    const-string/jumbo p1, "registerStatsEnabled is false"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p1, v0}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_4
    const/4 v5, 0x6

    return v3

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v1
.end method

.method private b(Z)Z
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->a:Lio/openinstall/sdk/aq;

    const/4 v9, 0x2

    const/4 v8, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->c()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez p1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object p1, p0, Lio/openinstall/sdk/bo;->a:Lio/openinstall/sdk/aq;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p1}, Lio/openinstall/sdk/aq;->a()V

    :cond_0
    const/4 v8, 0x5

    const/4 v9, 0x4

    return v1

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz p1, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object p1, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->f()Z

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x1

    if-nez p1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object p1, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->d()Z

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-nez p1, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    invoke-virtual {p1}, Lio/openinstall/sdk/bi;->d()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    return v1

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/bi;->a()Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz p1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    return v1

    :cond_3
    iget-object p1, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {p1}, Lio/openinstall/sdk/bi;->b()Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v0, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz p1, :cond_4

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    return v0

    :cond_4
    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object p1, p0, Lio/openinstall/sdk/bo;->b:Lio/openinstall/sdk/aw;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->g()J

    move-result-wide v4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v9, 0x6

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    mul-long/2addr v4, v6

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-wide v6, p0, Lio/openinstall/sdk/bo;->f:J

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    sub-long/2addr v2, v6

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    cmp-long p1, v4, v2

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-gez p1, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    move v1, v0

    move v1, v0

    const/4 v9, 0x4

    move v1, v0

    move v1, v0

    :cond_5
    const/4 v8, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    return v1
.end method

.method private c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method private c(Lio/openinstall/sdk/be;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bo;->b(Lio/openinstall/sdk/be;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    invoke-direct {p0, p1}, Lio/openinstall/sdk/bo;->a(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/bi;->a(Lio/openinstall/sdk/be;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->c()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0
.end method

.method private d()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lio/openinstall/sdk/bo;->g:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private e()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v0, p0, Lio/openinstall/sdk/bo;->g:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ge v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v0, p0, Lio/openinstall/sdk/bo;->g:I

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private f()V
    .locals 5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/bo;->a:Lio/openinstall/sdk/aq;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->b()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->a:Lio/openinstall/sdk/aq;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->a()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v4, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/bi;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lio/openinstall/sdk/bo;->c:Lio/openinstall/sdk/ck;

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/ck;->b(Ljava/lang/String;)Lio/openinstall/sdk/cr;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    iput-wide v1, p0, Lio/openinstall/sdk/bo;->f:J

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lio/openinstall/sdk/cr;->a()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/cr;->e()Lio/openinstall/sdk/cq;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/cq;->a()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "otEsncusvcts tuses"

    const-string/jumbo v0, "teuEosscses cttsnv"

    const/4 v4, 0x7

    const-string/jumbo v0, "sscsteupEatvtcesns"

    const-string/jumbo v0, "statEvents success"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->d()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->e:Lio/openinstall/sdk/bi;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/bi;->c()V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bo;->d:Lio/openinstall/sdk/at;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-wide v1, p0, Lio/openinstall/sdk/bo;->f:J

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lio/openinstall/sdk/at;->a(J)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-boolean v1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/cr;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput-object v0, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v0, "taE: sesq bl nsfvt%i"

    const-string/jumbo v0, "sv ftbanE i :set%sla"

    const/4 v4, 0x5

    const-string/jumbo v0, "statEvents fail : %s"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->e()V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/16 v1, 0x17

    const/4 v3, 0x6

    iput v1, v0, Landroid/os/Message;->what:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-virtual {p0, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public a(Lio/openinstall/sdk/be;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x15

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v1, v0, Landroid/os/Message;->what:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x6

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/16 v1, 0x15

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast p1, Lio/openinstall/sdk/be;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bo;->c(Lio/openinstall/sdk/be;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 p1, 0x17

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v0, p1, :cond_1

    const/4 v3, 0x4

    iget p1, p0, Lio/openinstall/sdk/bo;->g:I

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/16 v0, 0xa

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ge p1, v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bo;->b(Z)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lio/openinstall/sdk/bo;->f()V

    :cond_1
    :goto_0
    const/4 v2, 0x1

    move v3, v2

    return-void
.end method
