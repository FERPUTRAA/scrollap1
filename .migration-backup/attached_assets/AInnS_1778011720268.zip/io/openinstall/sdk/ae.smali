.class public Lio/openinstall/sdk/ae;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ae$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ossu@M~@n~t  db ~@~a / @  1~ i.K@~ o~@oy~@ b~@Si~ ~r@~m@@~@@f @@l  ~~~o li-4~oo~~@~tv@@/@b~@cf~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/16 v1, 0x18

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-lt v0, v1, :cond_0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v1, "a_pmsopi"

    const-string v1, "aos_ipps"

    const/4 v5, 0x7

    const-string v1, "dpoio_pa"

    const-string/jumbo v1, "pps_oaid"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1}, Landroid/provider/Settings$Global;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v2

    :catchall_0
    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "..V.IbmmEdERdSieNoou_eoInODiccPEveCS"

    const-string v1, "_SCmPII.ncvESViENR.eEododuemi.OeDocs"

    const/4 v5, 0x7

    const-string v1, "_PoeSDuEceNiRomvVpoSe.Cc.s.inOEIudEd"

    const-string v1, "com.uodis.opendevice.OPENIDS_SERVICE"

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v1, "eumw.idpoiwhao."

    const-string/jumbo v1, "ohuhoie.w.wimda"

    const/4 v5, 0x5

    const-string v1, "chadwi.eq.hiowm"

    const-string v1, "com.huawei.hwid"

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v1, Lio/openinstall/sdk/x;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v1}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1, v0, v1, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v0, Lio/openinstall/sdk/ae$a;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v0, v3}, Lio/openinstall/sdk/ae$a;-><init>(Landroid/os/IBinder;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/ae$a;->a()Ljava/lang/String;

    move-result-object v2
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catch_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :catchall_1
    move-exception v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    throw v0

    :cond_1
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v2
.end method
