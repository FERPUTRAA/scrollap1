.class public Lio/openinstall/sdk/cg;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# static fields
.field private static final i:[B


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:J

.field public f:J

.field public g:[B

.field public h:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-array v0, v0, [B

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lio/openinstall/sdk/cg;->i:[B

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lio/openinstall/sdk/cg;->i:[B

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@o@/Kra@-nlS~@ fc v~~  i@t~o~@~@b Mdu@t~fib~ ~ ~@@   o@~.i @@4~o~~~~~@@ l~  so@@/~@ ~1y mo@~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    array-length v0, v0

    const/4 v2, 0x6

    add-int/lit8 v0, v0, 0x16

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public a(J)Ljava/nio/ByteBuffer;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/cg;->a()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const v1, 0x6054b50

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v1, p0, Lio/openinstall/sdk/cg;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    int-to-short v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lio/openinstall/sdk/cg;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    int-to-short v1, v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v4, 0x5

    iget v1, p0, Lio/openinstall/sdk/cg;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    int-to-short v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v1, p0, Lio/openinstall/sdk/cg;->d:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    int-to-short v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x2

    iget-wide v1, p0, Lio/openinstall/sdk/cg;->e:J

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    long-to-int v1, v1

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    long-to-int p1, p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    array-length p1, p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    int-to-short p1, p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object p1, p0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    const/4 v4, 0x7

    return-object v0
.end method

.method public a([B)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    array-length v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_1

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object p1, Lio/openinstall/sdk/cg;->i:[B

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public b()Lio/openinstall/sdk/cg;
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lio/openinstall/sdk/cg;
    :try_end_0
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v1, Ljava/lang/Error;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, v0}, Ljava/lang/Error;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw v1
.end method

.method public synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cg;->b()Lio/openinstall/sdk/cg;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method
