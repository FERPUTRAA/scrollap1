.class public Lio/openinstall/sdk/ao;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/br;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s@o@  oi~1o@oSa@ynu~@ f~~ @@~/@d~ ~@o~i/blM~@@t~~ s. o@~-@v~ ~rc@~~~Km~~ @~    4@lb f t@~@@ ~i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method
