.class Lio/openinstall/sdk/d;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/da;


# instance fields
.field final synthetic a:Lu3/f;

.field final synthetic b:Lio/openinstall/sdk/a;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/a;Lu3/f;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/d;->b:Lio/openinstall/sdk/a;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p2, p0, Lio/openinstall/sdk/d;->a:Lu3/f;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cy;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sMam b ~K@~@o@~o~f~t @t/s~-@o i~~~v@4~  y/@  @ir~~@o b~ ~~ @S1cuoo@ d ~@@f@i@.~l ~@@~~lb  n~@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/d;->a:Lu3/f;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-static {p1}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0, v1, p1}, Lu3/f;->a(Ljava/lang/Object;Lv3/b;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method
