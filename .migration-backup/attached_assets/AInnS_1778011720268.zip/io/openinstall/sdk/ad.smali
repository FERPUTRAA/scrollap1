.class public Lio/openinstall/sdk/ad;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ad$a;,
        Lio/openinstall/sdk/ad$b;,
        Lio/openinstall/sdk/ad$c;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    const-string/jumbo v0, "nrsdmhooo.isi."

    const-string v0, ".osicmroh.noid"

    const/4 v5, 0x3

    const-string v0, "i.omn.rohohcmi"

    const-string v0, "com.hihonor.id"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v3, "vdeiohchd.Ia.SoimrO.oircmneo"

    const-string/jumbo v3, "mSvmrrheo.iodiceci.a.IndnOoh"

    const/4 v5, 0x5

    const-string/jumbo v3, "vHmrnbhiridShdOocince.aoe.o."

    const-string v3, "com.hihonor.id.HnOaIdService"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, v2, v1}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    xor-int/lit8 p0, p0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    return p0

    :catch_0
    const/4 v5, 0x7

    return v1
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x5

    move v6, v0

    move v6, v0

    :try_start_0
    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v2, "doai"

    const-string/jumbo v2, "oaid"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v1, v2}, Landroid/provider/Settings$Global;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-object v0

    :catch_0
    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v2, "hSvnodumceiIo.r.onh.OcradHei"

    const-string/jumbo v2, "rhrOo.cIiinm.hcodoeSv.ndiaeH"

    const/4 v7, 0x1

    const-string v2, ".dreIi.pnhhnoaeo.coSivHcrOdm"

    const-string v2, "com.hihonor.id.HnOaIdService"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v2, "irdoi.ncqohbmh"

    const-string v2, ".i.ombohcrndih"

    const/4 v7, 0x2

    const-string v2, ".msi.nordhioch"

    const-string v2, "com.hihonor.id"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v2, Lio/openinstall/sdk/x;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v2}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v1, :cond_1

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v1, Lio/openinstall/sdk/ad$a;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v1, v3}, Lio/openinstall/sdk/ad$a;-><init>(Landroid/os/IBinder;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v3, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v7, 0x1

    invoke-direct {v3}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    new-instance v4, Lio/openinstall/sdk/ad$b;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v4, p0, v3}, Lio/openinstall/sdk/ad$b;-><init>(Lio/openinstall/sdk/ad;Ljava/util/concurrent/BlockingQueue;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Lio/openinstall/sdk/ad$a;->a(Lio/openinstall/sdk/ad$c;)V

    const/4 v7, 0x7

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    const-wide/16 v4, 0x3

    const-wide/16 v4, 0x3

    const-wide/16 v4, 0x3

    const-wide/16 v4, 0x3

    invoke-interface {v3, v4, v5, v1}, Ljava/util/concurrent/BlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x0

    check-cast v1, Ljava/lang/String;
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    throw v0

    :catch_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_1
    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-object v0
.end method
