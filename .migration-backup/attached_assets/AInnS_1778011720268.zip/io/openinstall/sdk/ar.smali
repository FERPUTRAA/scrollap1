.class public final Lio/openinstall/sdk/ar;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lio/openinstall/sdk/ar;

.field public static final b:Lio/openinstall/sdk/ar;

.field public static final c:Lio/openinstall/sdk/ar;

.field public static final d:Lio/openinstall/sdk/ar;

.field public static final e:Lio/openinstall/sdk/ar;

.field public static final f:Lio/openinstall/sdk/ar;


# instance fields
.field private final g:I

.field private final h:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "s9sdu/5ubau/u532715c26//"

    const-string/jumbo v2, "u1sucu/59276//bu2ad53/51"

    const/4 v4, 0x5

    const-string v2, "/u5ma/6/bd2935u1cuu/6715"

    const-string/jumbo v2, "\u672a\u521d\u59cb\u5316"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    sput-object v0, Lio/openinstall/sdk/ar;->a:Lio/openinstall/sdk/ar;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v2, "u7c5ou6ud///u61b8362/1355u259m"

    const-string v2, "25um9/555871uu/6bc626/u1b3d/3u"

    const/4 v4, 0x4

    const-string v2, "7/u53b2u62b/6/861ucd/55u9/1ub5"

    const-string/jumbo v2, "\u6b63\u5728\u521d\u59cb\u5316"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    sput-object v0, Lio/openinstall/sdk/ar;->b:Lio/openinstall/sdk/ar;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "db2u6/u5/u1ud529u1u/3/5135/9oc"

    const-string v2, "595uo9251dc/1u63/125d/3u/u5bu/"

    const/4 v4, 0x7

    const-string v2, "6uubd15p531u5u//2du13825/5/c/9"

    const-string/jumbo v2, "\u521d\u59cb\u5316\u5931\u8d25"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    sput-object v0, Lio/openinstall/sdk/ar;->c:Lio/openinstall/sdk/ar;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, "65u/u51bq2//c3b1622u9ud/1/f5u9"

    const-string v2, "21u15b255/f9u5u6/c2u6/db9u//31"

    const/4 v4, 0x0

    const-string/jumbo v2, "uus2/5/91/u/5d6163uu1bc/202f95"

    const-string/jumbo v2, "\u521d\u59cb\u5316\u6210\u529f"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v3, 0x2

    move v4, v3

    sput-object v0, Lio/openinstall/sdk/ar;->d:Lio/openinstall/sdk/ar;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x5

    const/4 v1, -0x2

    const/4 v4, 0x0

    move v3, v1

    move v3, v1

    const/4 v4, 0x1

    const-string/jumbo v2, "u5fm91/u5cuedb96/2b315uu195//8"

    const-string/jumbo v2, "\u521d\u59cb\u5316\u9519\u8bef"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v0, Lio/openinstall/sdk/ar;->e:Lio/openinstall/sdk/ar;

    const/4 v4, 0x3

    new-instance v0, Lio/openinstall/sdk/ar;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, -0x3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v2, "/b6do/1u15/u9/uu26u85b8839c/52ubu17a"

    const-string v2, "d29u8/ub76bu/u/59/1a2c86u3/5bu1618u5"

    const/4 v4, 0x5

    const-string/jumbo v2, "\u521d\u59cb\u5316\u88ab\u7981\u6b62"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/ar;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    sput-object v0, Lio/openinstall/sdk/ar;->f:Lio/openinstall/sdk/ar;

    const/4 v4, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method constructor <init>(ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lio/openinstall/sdk/ar;->g:I

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lio/openinstall/sdk/ar;->h:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static a(I)Lio/openinstall/sdk/ar;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~ o b.f~m~i@n4 ~1r @y@@~lf@~cM os@S@@ K@~o~ob@@a @  ~~u o~ -@t ~~~ ~o~@ ~ td v~~/~i@/@l@b~@~ b@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, -0x3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eq p0, v0, :cond_4

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, -0x2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq p0, v0, :cond_3

    const/4 v2, 0x6

    const/4 v0, -0x7

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p0, v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p0, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object p0, Lio/openinstall/sdk/ar;->a:Lio/openinstall/sdk/ar;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object p0, Lio/openinstall/sdk/ar;->b:Lio/openinstall/sdk/ar;

    const/4 v2, 0x0

    const/4 v1, 0x3

    goto :goto_0

    :cond_1
    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object p0, Lio/openinstall/sdk/ar;->d:Lio/openinstall/sdk/ar;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object p0, Lio/openinstall/sdk/ar;->c:Lio/openinstall/sdk/ar;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object p0, Lio/openinstall/sdk/ar;->e:Lio/openinstall/sdk/ar;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object p0, Lio/openinstall/sdk/ar;->f:Lio/openinstall/sdk/ar;

    :goto_0
    const/4 v2, 0x7

    return-object p0
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lio/openinstall/sdk/ar;->g:I

    const/4 v2, 0x5

    return v0
.end method
