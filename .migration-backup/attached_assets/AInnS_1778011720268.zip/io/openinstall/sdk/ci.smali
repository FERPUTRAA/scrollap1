.class public abstract Lio/openinstall/sdk/ci;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/au;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lio/openinstall/sdk/au<",
        "Ljava/util/Map<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;>;"
    }
.end annotation


# instance fields
.field protected final a:Lio/openinstall/sdk/ay;

.field protected final b:Lio/openinstall/sdk/as;


# direct methods
.method protected constructor <init>(Lio/openinstall/sdk/ay;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/ci;->b:Lio/openinstall/sdk/as;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected abstract a()Ljava/util/Map;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public synthetic a_()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s- ob~@@ l.y@@@fS~o~ b~/@~c   o~~~@ 4K  l  ~@~M@r~@~~imtib~v@@@ n /@@d~ui~f~ o~@t~osa @ ~1@~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/ci;->c()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Lio/openinstall/sdk/ay;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "wjap"

    const-string v2, "apwj"

    const/4 v4, 0x0

    const-string v2, "awpj"

    const-string/jumbo v2, "jpaw"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    or-int/2addr v4, v3

    iget-object v1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v4, 0x2

    invoke-virtual {v1}, Lio/openinstall/sdk/ay;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v2, "opof"

    const-string/jumbo v2, "opfo"

    const/4 v4, 0x0

    const-string v2, "foop"

    const-string/jumbo v2, "opof"

    const/4 v4, 0x7

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v1}, Lio/openinstall/sdk/ay;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string/jumbo v2, "jkfe"

    const-string/jumbo v2, "kfej"

    const/4 v4, 0x5

    const-string v2, "fjek"

    const-string/jumbo v2, "kjfe"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1}, Lio/openinstall/sdk/ay;->f()Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "wfeh"

    const-string v2, "efwh"

    const/4 v4, 0x6

    const-string v2, "hwef"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lio/openinstall/sdk/ci;->a:Lio/openinstall/sdk/ay;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Lio/openinstall/sdk/ay;->g()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, "asvn"

    const-string/jumbo v2, "nsva"

    const/4 v4, 0x4

    const-string/jumbo v2, "nsva"

    const-string/jumbo v2, "vsna"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/ci;->a()Ljava/util/Map;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0
.end method
