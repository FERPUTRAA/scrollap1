.class public Lio/openinstall/sdk/ah;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@aso1@  o~~~~@ ~ oti@~/ib d@ @@fMl@@~. bSy on @@o~~~@ i~@/~@~  b4c@t~ru@ @@~ ~o l~~~m@Kf @-v~ ~s"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const-string/jumbo v0, "iiomnicna./dutei/tnetidn.tst:e/cnyyt"

    const-string/jumbo v0, "t/s/nnytt/niiyndtoeadiute:tccnni.ie."

    const/4 v5, 0x7

    const-string/jumbo v0, "ty.ion/dnece.:oni/tntaudittctnnbieyi"

    const-string v0, "content://cn.nubia.identity/identity"

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Landroid/content/ContentResolver;->acquireContentProviderClient(Landroid/net/Uri;)Landroid/content/ContentProviderClient;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, "gmtOAbI"

    const-string v1, "ItAmgDO"

    const/4 v5, 0x3

    const-string v1, "eDtgIOu"

    const-string v1, "getOAID"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1, v1, v0, v0}, Landroid/content/ContentProviderClient;->call(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/16 v3, 0x18

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/ContentProviderClient;->release()Z

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :cond_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string p1, "doce"

    const-string p1, "eocd"

    const/4 v5, 0x2

    const-string p1, "dceo"

    const-string p1, "code"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1, p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez p1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo p1, "id"

    const-string p1, "di"

    const/4 v5, 0x5

    const-string p1, "di"

    const-string/jumbo p1, "id"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v0, ""

    const/4 v5, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v0
.end method
