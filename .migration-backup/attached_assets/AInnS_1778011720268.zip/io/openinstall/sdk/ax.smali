.class public Lio/openinstall/sdk/ax;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ax$a;,
        Lio/openinstall/sdk/ax$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/ax;->a:Ljava/util/concurrent/Executor;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;Lio/openinstall/sdk/ax$b;)Ljava/util/concurrent/Future;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lio/openinstall/sdk/ax$b;",
            ")",
            "Ljava/util/concurrent/Future<",
            "Landroid/content/SharedPreferences;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o1s/   @yK~o~cf@M~~@  mn @@@@@~u~@@@b ~~sl o.oi a~@4~o~  S~~~@tvfr@~   ~~   ~b@bd@/~-l~@~@@iit@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Lio/openinstall/sdk/ax$a;

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2, p3}, Lio/openinstall/sdk/ax$a;-><init>(Landroid/content/Context;Ljava/lang/String;Lio/openinstall/sdk/ax$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p1, Ljava/util/concurrent/FutureTask;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p2, p0, Lio/openinstall/sdk/ax;->a:Ljava/util/concurrent/Executor;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {p2, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method
