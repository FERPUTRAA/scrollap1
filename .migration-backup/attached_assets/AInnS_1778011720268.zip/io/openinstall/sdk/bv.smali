.class public Lio/openinstall/sdk/bv;
.super Ljava/lang/Object;


# static fields
.field private static a:Lio/openinstall/sdk/bv;


# instance fields
.field private final b:Z

.field private c:Lio/openinstall/sdk/ca;

.field private d:Z

.field private e:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private f:Landroid/app/Application;

.field private g:Landroid/app/Application$ActivityLifecycleCallbacks;

.field private final h:Ljava/lang/Runnable;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/openinstall/sdk/bv;->d:Z

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v1, v0

    move v1, v0

    const/4 v2, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/bv;->e:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lio/openinstall/sdk/bx;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lio/openinstall/sdk/bx;-><init>(Lio/openinstall/sdk/bv;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lio/openinstall/sdk/bv;->h:Ljava/lang/Runnable;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->g()Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    new-instance v0, Lio/openinstall/sdk/ca;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Lio/openinstall/sdk/ca;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p1, Landroid/app/Application;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/bv;->f:Landroid/app/Application;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p1, Lio/openinstall/sdk/bw;

    const/4 v2, 0x0

    invoke-direct {p1, p0}, Lio/openinstall/sdk/bw;-><init>(Lio/openinstall/sdk/bv;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/bv;->g:Landroid/app/Application$ActivityLifecycleCallbacks;

    iget-object v0, p0, Lio/openinstall/sdk/bv;->f:Landroid/app/Application;

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {v0, p1}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-boolean p1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v2, 0x4

    const-string/jumbo v0, "rnsobacB=E liplfae ddeal"

    const/4 v2, 0x3

    const-string v0, "Bps lEddsf elaaei=clarbn"

    const-string v0, "clipBoardEnabled = false"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v2, 0x6

    return-void
.end method

.method public static a(Landroid/content/Context;)Lio/openinstall/sdk/bv;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~@mbMf@@  oSd~i@@@o~@~o~ct @~.o i1@-l~~~@~v/i@la r@~o/ @byt~ s~@~b  u ~ ~~@ ~n~  @~f~@ o@ m K@4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lio/openinstall/sdk/bv;->a:Lio/openinstall/sdk/bv;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const-class v0, Lio/openinstall/sdk/bv;

    const-class v0, Lio/openinstall/sdk/bv;

    const/4 v3, 0x0

    const-class v0, Lio/openinstall/sdk/bv;

    const-class v0, Lio/openinstall/sdk/bv;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v1, Lio/openinstall/sdk/bv;->a:Lio/openinstall/sdk/bv;

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lio/openinstall/sdk/bv;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bv;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object v1, Lio/openinstall/sdk/bv;->a:Lio/openinstall/sdk/bv;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object p0, Lio/openinstall/sdk/bv;->a:Lio/openinstall/sdk/bv;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0
.end method

.method static synthetic a(Lio/openinstall/sdk/bv;)Ljava/lang/Runnable;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p0, p0, Lio/openinstall/sdk/bv;->h:Ljava/lang/Runnable;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic a(Lio/openinstall/sdk/bv;Ljava/lang/ref/WeakReference;)Ljava/lang/ref/WeakReference;
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/bv;->e:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic b(Lio/openinstall/sdk/bv;)Ljava/lang/ref/WeakReference;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p0, p0, Lio/openinstall/sdk/bv;->e:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p1, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo p1, "ms roael%s"

    const-string p1, "elrms%e as"

    const/4 v3, 0x3

    const-string/jumbo p1, "s%eerblae "

    const-string p1, "%s release"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p1, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/ca;->b()V

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method public a(Ljava/lang/ref/WeakReference;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/ca;->a(Ljava/lang/ref/WeakReference;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public a(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-boolean p1, p0, Lio/openinstall/sdk/bv;->d:Z

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public a()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public b()Lio/openinstall/sdk/by;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/bv;->b(Z)Lio/openinstall/sdk/by;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public b(Z)Lio/openinstall/sdk/by;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/ca;->e()Landroid/content/ClipData;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p1, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/ca;->d()Landroid/content/ClipData;

    move-result-object p1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Lio/openinstall/sdk/by;->a(Landroid/content/ClipData;)Lio/openinstall/sdk/by;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz p1, :cond_2

    const/4 v5, 0x6

    sget-boolean v2, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    move v5, v4

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/by;->c()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    aput-object v3, v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v0, " aptd%u sdiyoat"

    const-string/jumbo v0, "tdasoat %i pyed"

    const/4 v5, 0x2

    const-string/jumbo v0, "sd eat pp %dtia"

    const-string v0, "data type is %d"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v2}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/bv;->f:Landroid/app/Application;

    const/4 v4, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/bv;->g:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v1, p0, Lio/openinstall/sdk/bv;->g:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v5, 0x6

    goto :goto_1

    :cond_2
    const/4 v5, 0x6

    sget-boolean v1, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, " alitud qlsn"

    const-string v1, "data is null"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_3
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    return-object p1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v1
.end method

.method public b(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->b:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/bv;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    aput-object p1, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo p1, "sssascbe%"

    const-string p1, "%ssesbcac"

    const/4 v3, 0x4

    const-string p1, "es%mass c"

    const-string p1, "%s access"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lio/openinstall/sdk/bv;->c:Lio/openinstall/sdk/ca;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/ca;->a()V

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method
