.class public Lio/openinstall/sdk/at;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "Landroid/content/SharedPreferences;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Future;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "Landroid/content/SharedPreferences;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    iput-object v0, p0, Lio/openinstall/sdk/at;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method private a(Ljava/lang/String;I)V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@sib@@~@o@@@of ~r@~ ~ .@@o @t ~ ~o~1~~~~~au-bo~4~b ~o@K@@@c l~@/ M~vti ~ d f~@   i  ls@~@nS@m/~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method private a(Ljava/lang/String;J)V
    .locals 3

    :try_start_0
    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method private a(Ljava/lang/String;Z)V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x4

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method private b(Ljava/lang/String;I)I
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1

    :catch_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p2
.end method

.method private b(Ljava/lang/String;J)J
    .locals 3

    :try_start_0
    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2, p3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-wide p1

    :catch_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-wide p2
.end method

.method private b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1

    :catch_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object p2
.end method

.method private b(Ljava/lang/String;Z)Z
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p2
.end method


# virtual methods
.method public a(Ljava/lang/String;)Lio/openinstall/sdk/ar;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lio/openinstall/sdk/ar;->a:Lio/openinstall/sdk/ar;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/ar;->a()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Lio/openinstall/sdk/ar;->a(I)Lio/openinstall/sdk/ar;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1
.end method

.method public a()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v0, "tdtmi_si_ana"

    const-string/jumbo v0, "tns_adiatMi_"

    const/4 v3, 0x0

    const-string v0, "_aiioF_tntMa"

    const-string v0, "FM_init_data"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method

.method public a(J)V
    .locals 3

    const/4 v2, 0x2

    const-string v0, "_et_tbilmFma"

    const-string v0, "aFemlm_tMit_"

    const/4 v2, 0x3

    const-string/jumbo v0, "tai_smuMt_Fl"

    const-string v0, "FM_last_time"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1, p2}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;J)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public a(Lio/openinstall/sdk/aw;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "FMdioatp_faong"

    const-string/jumbo v0, "n_FdoiMf_gaota"

    const/4 v2, 0x7

    const-string v0, "MnFo_fgiqdatac"

    const-string v0, "FM_config_data"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/aw;->i()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public a(Lio/openinstall/sdk/by;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const-string v0, "__stbpMadF"

    const-string v0, "Mbda_bpt_F"

    const/4 v2, 0x6

    const-string v0, "_pbmtaadM_"

    const-string v0, "FM_pb_data"

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/by;->d()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public a(Ljava/lang/String;Lio/openinstall/sdk/ar;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p2}, Lio/openinstall/sdk/ar;->a()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public a(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "et_FodmMhyfu_aci"

    const-string v0, "ctiMymuFaeh_fd_c"

    const/4 v2, 0x6

    const-string v0, "_iecmbFa_tyMnhdc"

    const-string v0, "FM_dynamic_fetch"

    const/4 v1, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 4

    const-string/jumbo v0, "iMp_tmuinsF"

    const-string/jumbo v0, "iitFsnMpm_g"

    const/4 v3, 0x6

    const-string/jumbo v0, "mM_itFnpg_s"

    const-string v0, "FM_init_msg"

    const/4 v3, 0x7

    const-string v1, ""

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public b(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "aFi_titdq_Mn"

    const-string v0, "FM_init_data"

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public b(Z)V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    const-string/jumbo v0, "oqs_eusshwd_hn_FoidM"

    const-string v0, "h_odwudsq_elosFni_Mh"

    const/4 v2, 0x0

    const-string/jumbo v0, "leMmuoi_ssFh_dn_dxow"

    const-string v0, "FM_should_show_index"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Z)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public c()Lio/openinstall/sdk/aw;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "nf_Mos_todcgai"

    const-string v0, "Fnsd_aMc_tigfo"

    const/4 v3, 0x2

    const-string v0, "adftFb_aigonMc"

    const-string v0, "FM_config_data"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lio/openinstall/sdk/aw;->b(Ljava/lang/String;)Lio/openinstall/sdk/aw;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public c(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "MmsmF_uigni"

    const-string v0, "FiMms__nimg"

    const/4 v2, 0x6

    const-string v0, "gFtM_iipns_"

    const-string v0, "FM_init_msg"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    return-void
.end method

.method public c(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "uFsofeb_qrerd_Moi"

    const-string v0, "de_roqusbiefo_MFr"

    const/4 v2, 0x4

    const-string v0, "_MssbeFi_urdofqre"

    const-string v0, "FM_request_forbid"

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public d()J
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v0, "a_embtmltFs_"

    const-string/jumbo v0, "ti_albsFetm_"

    const-string/jumbo v0, "liteos_F_Mmt"

    const-string v0, "FM_last_time"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, v0, v1, v2}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-wide v0
.end method

.method public d(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "Fdiiab_rMndu_"

    const-string v0, "ddFairu__Mdin"

    const/4 v2, 0x7

    const-string v0, "Mdoin_ua_rFid"

    const-string v0, "FM_android_id"

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public e()Lio/openinstall/sdk/by;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v0, "Mdt__pbpaa"

    const/4 v3, 0x2

    const-string/jumbo v0, "pM_baadpF_"

    const-string v0, "FM_pb_data"

    const/4 v2, 0x5

    move v3, v2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const-string v1, ""

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Lio/openinstall/sdk/by;->c(Ljava/lang/String;)Lio/openinstall/sdk/by;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method public e(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const-string/jumbo v0, "nbmiarM_qFeesrul"

    const-string v0, "_lbneseMqrmaFrui"

    const/4 v2, 0x5

    const-string v0, "e_ssMleia_rbFnum"

    const-string v0, "FM_serial_number"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/at;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public f()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "iormMs_addd_F"

    const-string v0, "dMsFnid_ad_ro"

    const/4 v3, 0x4

    const-string/jumbo v0, "id_ooFndiaMr_"

    const-string v0, "FM_android_id"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const-string v0, "abrmlb_Mseemri_F"

    const-string v0, "basmuemMrF__lrei"

    const/4 v3, 0x3

    const-string/jumbo v0, "srluMmubrenF__ie"

    const-string v0, "FM_serial_number"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public h()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "_tfncFapyhMm_ieo"

    const-string/jumbo v0, "yen_omitc_MfFahc"

    const/4 v3, 0x4

    const-string v0, "FM_cyi_tqdfamcen"

    const-string v0, "FM_dynamic_fetch"

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method public i()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "wdssFuMo_dishx_on_be"

    const-string/jumbo v0, "uwiehboxnl_sdoM_sdF_"

    const/4 v3, 0x0

    const-string v0, "FM_should_show_index"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method public j()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "_MqmtbeursfiFruoe"

    const-string v0, "eb_s_turufFieorMq"

    const/4 v3, 0x5

    const-string/jumbo v0, "rMsFobiu_ofdqter_"

    const-string v0, "FM_request_forbid"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Lio/openinstall/sdk/at;->b(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method public k()V
    .locals 3

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/at;->a:Ljava/util/concurrent/Future;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method
