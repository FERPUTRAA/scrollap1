.class public Lio/openinstall/sdk/am;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/am$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@@sn~ ~oM~ ~~@a~i@@  i@~uo@ @-o @@     o b~y@~t@~~sbfl ~@~o~r~t~@~m @~@o~c~. f/ilvd@~~S b@@1 K/4"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const-string v1, "cscmiemeseK.lamdsrd.vSivirsae.cMm"

    const-string/jumbo v1, "vssacmioceKemdcsreemsi..vrdMlS.ia"

    const/4 v7, 0x7

    const-string/jumbo v1, "sei.orMs.ielae.odSvc.eacmvricsmKm"

    const-string v1, "com.mdid.msa.service.MsaKlService"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v2, "midmabd.scm."

    const-string v2, "com.mdid.msa"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "cm.naaus.c.tovosraienismc.teum.b"

    const-string v1, "..smoravmainnccc.oeitt..asuetsmb"

    const/4 v7, 0x3

    const-string/jumbo v1, "r.savimpctosr.tabtiee.ucmca.nsn."

    const-string v1, "com.bun.msa.action.start.service"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v3, "e..kanmbqgaunor.acomsmp.m"

    const-string v3, "gnpcomumab.r.s.kmoepana.m"

    const/4 v7, 0x0

    const-string v3, "cksoanp.saramg.meap.mbnm."

    const-string v3, "com.bun.msa.param.pkgname"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v1, ".ermc.mbat.aaibrmpnsnmuuos"

    const-string/jumbo v1, "mtoarbs.pmaainrmus.n.e.buc"

    const/4 v7, 0x0

    const-string/jumbo v1, "mnmuo.a.upanib.esatcmro.rn"

    const-string v1, "com.bun.msa.param.runinset"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :try_start_0
    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v7, 0x0

    new-instance v0, Lio/openinstall/sdk/x;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {v0}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance v1, Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo v5, "somaubdcdicseerI.cva.emsrmMviei.."

    const-string v5, "essiMauicrsIm.moeeS.i.dvvcdar.cme"

    const/4 v7, 0x1

    const-string/jumbo v5, "sid.aouemr.mmvveMcIcdcsS.rsieie.d"

    const-string v5, "com.mdid.msa.service.MsaIdService"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v5}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v2, "ctu.oadpprivce.cionesm.non..iatbs"

    const-string v2, "..aebbsptiomciouentvcs.cnn..idora"

    const/4 v7, 0x7

    const-string v2, "bt.uc.cvqo..aoeaiiodntmsbns.irecm"

    const-string v2, "com.bun.msa.action.bindto.service"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p1, v1, v0, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    new-instance v1, Lio/openinstall/sdk/am$a;

    const/4 v7, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v1, v2}, Lio/openinstall/sdk/am$a;-><init>(Landroid/os/IBinder;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Lio/openinstall/sdk/am$a;->a()Ljava/lang/String;

    move-result-object v1
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    throw v1

    :catch_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v1
.end method
