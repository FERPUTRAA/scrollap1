.class public abstract Lio/openinstall/sdk/cs;
.super Ljava/lang/Object;


# instance fields
.field protected final a:Lio/openinstall/sdk/av;

.field protected final b:Lio/openinstall/sdk/da;


# direct methods
.method public constructor <init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lio/openinstall/sdk/cs;->b:Lio/openinstall/sdk/da;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ts ~ oc~@f@ /~~o@oib~Kd @@uo~  1~~ i-~nv@t.@aMfs  @o@~l~ y@~i~@ @~ ~@/ 4~mr@ @ lb@S@@o~~@ b~ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method protected b()Lio/openinstall/sdk/aq;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->e()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method protected c()Lio/openinstall/sdk/at;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->d()Lio/openinstall/sdk/at;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method protected d()Lio/openinstall/sdk/aw;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->f()Lio/openinstall/sdk/aw;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method protected e()Lio/openinstall/sdk/ck;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->c()Lio/openinstall/sdk/ck;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method protected f()Lio/openinstall/sdk/ay;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->g()Lio/openinstall/sdk/ay;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method protected g()Lio/openinstall/sdk/bq;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->i()Lio/openinstall/sdk/bq;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method protected h()Lio/openinstall/sdk/bv;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->h()Lio/openinstall/sdk/bv;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method protected i()Ljava/util/concurrent/ThreadPoolExecutor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {}, Lio/openinstall/sdk/db;->a()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method protected j()Ljava/util/concurrent/ThreadPoolExecutor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {}, Lio/openinstall/sdk/db;->b()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method protected abstract k()Ljava/lang/String;
.end method

.method public l()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->m()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->j()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v1, Lio/openinstall/sdk/ct;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lio/openinstall/sdk/ct;-><init>(Lio/openinstall/sdk/cs;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method protected m()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method protected abstract n()Lio/openinstall/sdk/cy;
.end method
