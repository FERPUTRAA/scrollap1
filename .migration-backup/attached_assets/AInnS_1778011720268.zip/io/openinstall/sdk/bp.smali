.class public Lio/openinstall/sdk/bp;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/io/File;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " .sdv  ~~l@@o f@~ @i~n@@~~ fm@u1 @~oi@@MS //@~  o i ~~@ @c~y@~~bo-Kltr@~bs~to4@~~ @~o~~ a@@ b ~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/io/File;->createNewFile()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v3, 0x6

    return-void
.end method

.method public static a(Ljava/io/File;Ljava/lang/String;Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1, v0, p2}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;Ljava/lang/String;ZZ)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Ljava/io/File;Ljava/lang/String;ZZ)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v1, Ljava/io/FileWriter;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v1, p0, p3}, Ljava/io/FileWriter;-><init>(Ljava/io/File;Z)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/io/BufferedWriter;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v1}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    const/4 v3, 0x5

    if-eqz p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/io/BufferedWriter;->newLine()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/io/BufferedWriter;->flush()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/io/BufferedWriter;->close()V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/io/Writer;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_3

    :catchall_0
    move-exception p1

    move-object v0, p0

    move-object v0, p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :catch_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_2

    :catchall_1
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_1

    :catchall_2
    move-exception p1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    :try_start_4
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedWriter;->close()V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/io/Writer;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    :catch_1
    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw p1

    :catch_2
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :catch_3
    :goto_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    :try_start_5
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/io/BufferedWriter;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :catch_4
    :cond_4
    :goto_3
    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public static b(Ljava/io/File;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v2, Ljava/io/FileReader;

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, p0}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p0, Ljava/io/BufferedReader;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_0
    :try_start_2
    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    :try_start_3
    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/io/Reader;->close()V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_5

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_2

    :catchall_1
    move-exception v0

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_2
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    goto :goto_3

    :catch_0
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :catch_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_4

    :catchall_2
    move-exception v0

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_3
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    :try_start_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/io/Reader;->close()V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    :catch_2
    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    throw v0

    :catch_3
    move-object p0, v1

    move-object p0, v1

    :goto_4
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_3

    :try_start_5
    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/io/Reader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz p0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_1

    :catch_4
    :cond_4
    :goto_5
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object p0
.end method
