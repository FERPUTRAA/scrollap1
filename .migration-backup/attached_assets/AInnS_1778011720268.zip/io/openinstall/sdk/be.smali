.class public Lio/openinstall/sdk/be;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field private a:Z

.field private final b:I

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/Long;

.field private final e:Ljava/lang/Long;

.field private final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v1, p1

    move v1, p1

    const/4 v7, 0x6

    move v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct/range {v0 .. v5}, Lio/openinstall/sdk/be;-><init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;)V

    const/4 v6, 0x4

    or-int/2addr v7, v6

    return-void
.end method

.method private constructor <init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/openinstall/sdk/be;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p1, p0, Lio/openinstall/sdk/be;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/be;->c:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p3, p0, Lio/openinstall/sdk/be;->d:Ljava/lang/Long;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p4, p0, Lio/openinstall/sdk/be;->e:Ljava/lang/Long;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p5, p0, Lio/openinstall/sdk/be;->f:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public static a()Lio/openinstall/sdk/be;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "t s@@~~ m~/ @s4@o@a o~b@@~@@~ncl~i ~o~@@i~b@o  @1.~~~ @ itbrM@~@~   ~~~@~S  ~v~~l /odyfo f-K u@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    new-instance v0, Lio/openinstall/sdk/be;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v6, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v4, "egrm$tsis"

    const-string/jumbo v4, "isstgrer$"

    const/4 v6, 0x3

    const-string/jumbo v4, "teeroi$rg"

    const-string v4, "$register"

    const/4 v6, 0x3

    invoke-direct {v0, v3, v4, v1, v2}, Lio/openinstall/sdk/be;-><init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object v0
.end method

.method public static a(J)Lio/openinstall/sdk/be;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Lio/openinstall/sdk/be;

    const/4 v4, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, p1, v2, v1, p0}, Lio/openinstall/sdk/be;-><init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0
.end method

.method public static a(Ljava/lang/String;JLjava/util/Map;)Lio/openinstall/sdk/be;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "J",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lio/openinstall/sdk/be;"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v6, Lio/openinstall/sdk/be;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v1, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct/range {v0 .. v5}, Lio/openinstall/sdk/be;-><init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/Map;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object v6
.end method


# virtual methods
.method public a(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    iput-boolean p1, p0, Lio/openinstall/sdk/be;->a:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lio/openinstall/sdk/be;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public c()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/be;->a:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/be;->c:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public e()Ljava/lang/Long;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/be;->d:Ljava/lang/Long;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public f()Ljava/lang/Long;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/be;->e:Ljava/lang/Long;

    const/4 v2, 0x4

    return-object v0
.end method

.method public g()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/be;->f:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
