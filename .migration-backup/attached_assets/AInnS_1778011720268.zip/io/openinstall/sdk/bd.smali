.class public Lio/openinstall/sdk/bd;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Lio/openinstall/sdk/cr;)Lio/openinstall/sdk/bd;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ts  fo@@~~~ @bo  @@ @y@~b da1~@~@~~v@~~l@ @M l~t@s4~~@i r/~~f m~-~ ~bSounK.o/ c~ i@o @i~o~@@@  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->a()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->e()Lio/openinstall/sdk/cq;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lio/openinstall/sdk/cq;->c()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0

    :cond_1
    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p0, "ausmst"

    const-string/jumbo p0, "utsast"

    const/4 v4, 0x6

    const-string/jumbo p0, "tssuot"

    const-string/jumbo p0, "status"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0}, Lio/openinstall/sdk/bd;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p0}, Lio/openinstall/sdk/bd;->a(Ljava/lang/String;)Lio/openinstall/sdk/bd;

    move-result-object p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p0

    :catch_0
    :cond_4
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0
.end method

.method private static a(Ljava/lang/String;)Lio/openinstall/sdk/bd;
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x4

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p0, Lio/openinstall/sdk/bd;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/bd;-><init>()V

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    const-string v2, "ca"

    const/4 v5, 0x6

    const-string v2, "ac"

    const-string v2, "ac"

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    const/4 v3, 0x1

    move v5, v3

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    iput v2, p0, Lio/openinstall/sdk/bd;->a:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v2, "sac"

    const-string v2, "cas"

    const/4 v5, 0x2

    const-string/jumbo v2, "sca"

    const-string v2, "cas"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput v2, p0, Lio/openinstall/sdk/bd;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v2, "ls"

    const-string/jumbo v2, "sl"

    const/4 v5, 0x3

    const-string/jumbo v2, "ls"

    const-string/jumbo v2, "ls"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput v2, p0, Lio/openinstall/sdk/bd;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v2, "it"

    const-string/jumbo v2, "ti"

    const-string/jumbo v2, "ti"

    const-string/jumbo v2, "ti"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-object v2, p0, Lio/openinstall/sdk/bd;->d:Ljava/lang/String;

    const/4 v5, 0x1

    const-string/jumbo v2, "ms"

    const-string/jumbo v2, "sm"

    const/4 v5, 0x0

    const-string/jumbo v2, "sm"

    const-string/jumbo v2, "ms"

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v2, p0, Lio/openinstall/sdk/bd;->e:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v2, "co"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v2, p0, Lio/openinstall/sdk/bd;->f:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v2, "uj"

    const-string/jumbo v2, "uj"

    const/4 v5, 0x6

    const-string/jumbo v2, "ju"

    const-string/jumbo v2, "ju"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/bd;->g:Ljava/lang/String;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :catch_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 p0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0
.end method

.method private static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x4

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v2, 0x13

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-le v1, v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/String;

    const/4 v5, 0x1

    const-string v2, "bF-UT"

    const-string v2, "UTF-8"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v1, p0, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object p0, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v3, "usu2:6u356u6e646/u56m/e/4a7//58u7Ba /u0602de"

    const-string/jumbo v3, "u70m264ude6458u:6u6/u0a73/632665Bu5s///ae/ e"

    const/4 v5, 0x3

    const-string v3, "/u426 ap/070s/566eu/u6u73e/5e/u66562u844a3:B"

    const-string/jumbo v3, "\u622a\u53d6\u540e\u7684Base64\u6570\u636e: "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object v1

    :catch_0
    :cond_1
    const/4 v4, 0x2

    move v5, v4

    return-object v0
.end method


# virtual methods
.method public a()Z
    .locals 4

    const/4 v3, 0x0

    iget v0, p0, Lio/openinstall/sdk/bd;->a:I

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v0
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v0, p0, Lio/openinstall/sdk/bd;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x1

    move v3, v2

    return v1
.end method

.method public c()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v0, p0, Lio/openinstall/sdk/bd;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v1
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/bd;->d:Ljava/lang/String;

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bd;->e:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bd;->f:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bd;->g:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method
