.class Lio/openinstall/sdk/cu;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/cy;

.field final synthetic b:Lio/openinstall/sdk/ct;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/ct;Lio/openinstall/sdk/cy;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/cu;->b:Lio/openinstall/sdk/ct;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p2, p0, Lio/openinstall/sdk/cu;->a:Lio/openinstall/sdk/cy;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l@s@co ~@ @~iu@@ ~~@K1b  ~~@o@/a fr/oy~sb~d~@~ ~~ - ~.t@~ i@@o~ov@~~~@ b on@f Sm @@4@~ Mi@~t ~l~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/openinstall/sdk/cu;->b:Lio/openinstall/sdk/ct;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, v0, Lio/openinstall/sdk/ct;->a:Lio/openinstall/sdk/cs;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, v0, Lio/openinstall/sdk/cs;->b:Lio/openinstall/sdk/da;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/cu;->a:Lio/openinstall/sdk/cy;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lio/openinstall/sdk/da;->a(Lio/openinstall/sdk/cy;)V

    const/4 v3, 0x0

    return-void
.end method
