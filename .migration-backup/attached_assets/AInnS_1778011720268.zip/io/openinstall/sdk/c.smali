.class Lio/openinstall/sdk/c;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/da;


# instance fields
.field final synthetic a:Lu3/b;

.field final synthetic b:Lio/openinstall/sdk/a;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/a;Lu3/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/c;->b:Lio/openinstall/sdk/a;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lio/openinstall/sdk/c;->a:Lu3/b;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cy;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "y@sobM~oni~~lld~r-~~@~@o@~ f b@4~@i~o~ bic @@  @.K/@ @@ m t~   u ~@~~vso@~@@@@a~ /~f  ~1tS@~ ~o~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v0, :cond_2

    const/4 v6, 0x0

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    aput-object v4, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v4, "ecImed:ldosc ncss et%alssu"

    const-string v4, ":cssn %usdedssIloa celtces"

    const/4 v6, 0x3

    const-string v4, "eIlsou sdsncdtc% cse: eoas"

    const-string v4, "decodeInstall success : %s"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v4, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    :try_start_0
    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/c;->b:Lio/openinstall/sdk/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, p1}, Lio/openinstall/sdk/a;->a(Lio/openinstall/sdk/a;Ljava/lang/String;)Lv3/a;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/c;->a:Lu3/b;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0, p1, v1}, Lu3/b;->a(Lv3/a;Lv3/b;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    aput-object p1, v0, v2

    const/4 v6, 0x6

    const-string/jumbo p1, "sol%sbea: c eotn remdrIr"

    const-string/jumbo p1, "r%smed:aectoo rlne Ir ls"

    const/4 v6, 0x3

    const-string/jumbo p1, "lrdrocusnede:  rIa %toes"

    const-string p1, "decodeInstall error : %s"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v0}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/c;->a:Lu3/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz p1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x4

    sget-object v0, Lio/openinstall/sdk/cy$a;->d:Lio/openinstall/sdk/cy$a;

    const/4 v6, 0x4

    invoke-static {v0}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p1, v1, v0}, Lu3/b;->a(Lv3/a;Lv3/b;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    aput-object v3, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v2, " csIoe%p eonilfats a:dd"

    const-string v2, " sl:o eo ldeId%tfanscai"

    const-string/jumbo v2, "iol sclIqetfsnld aa d:e"

    const-string v2, "decodeInstall fail : %s"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v2, v0}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/c;->a:Lu3/b;

    if-eqz v0, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v0, v1, p1}, Lu3/b;->a(Lv3/a;Lv3/b;)V

    :cond_4
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method
