.class Lio/openinstall/sdk/di;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/concurrent/LinkedBlockingQueue;

.field final synthetic b:Lio/openinstall/sdk/dh;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/dh;Ljava/util/concurrent/LinkedBlockingQueue;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/openinstall/sdk/di;->b:Lio/openinstall/sdk/dh;

    const/4 v1, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/di;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@tss@@@ro oKm1l  @v ~~ i ~@-@~~@@~oo ~ ab@d ~~bc t~ 4~ @@/yu ~Mffo /.~@@~ ~ i@@l~~~@@~i o~@~Sb~n"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/di;->b:Lio/openinstall/sdk/dh;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Lio/openinstall/sdk/dh;->a(Lio/openinstall/sdk/dh;)Lio/openinstall/sdk/bv;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/bv;->b(Z)Lio/openinstall/sdk/by;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Lio/openinstall/sdk/by;->c(I)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/di;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "cfpw"

    const-string/jumbo v2, "pfwc"

    const/4 v4, 0x5

    const-string/jumbo v2, "pfcw"

    const-string/jumbo v2, "pwcf"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/by;->b()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v2, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v2, "wiav"

    const-string/jumbo v2, "iwva"

    const/4 v4, 0x3

    const-string v2, "aivw"

    const-string v2, "aviw"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/by;->c(I)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/di;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/by;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/di;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v2, v1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    :goto_1
    const/4 v3, 0x0

    const/4 v3, 0x3

    return-void
.end method
