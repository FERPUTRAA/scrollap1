.class public Lio/openinstall/sdk/dy;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " cs  ~f~ /o @ m~@ir   Koa~~~~@~bS@~@ ~s4~o @@@ d@@~@bt-@u io  lib @@f~~@~/@~~@~to~lM@o@ ~vy@~~1."

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 v1, 0xa

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v2, "Nmambseeriru"

    const-string v2, "Nrsmaeilrebu"

    const/4 v6, 0x1

    const-string/jumbo v2, "lbNromarsuei"

    const-string/jumbo v2, "serialNumber"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ge v0, v1, :cond_2

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v2}, Lio/openinstall/sdk/dy;->e(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-void

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ge v1, v0, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Character;->isDigit(C)Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v4, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v3}, Ljava/lang/Character;->isLetter(C)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez v3, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-static {v2}, Lio/openinstall/sdk/dy;->e(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void
.end method

.method public static b(Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x1

    move v6, v5

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-void

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v1, 0x10

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v2, "domaibddr_"

    const-string v2, "dirmad_ido"

    const/4 v6, 0x2

    const-string/jumbo v2, "nridoduai_"

    const-string v2, "android_id"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq v0, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/16 v1, 0x20

    const/4 v6, 0x0

    if-eq v0, v1, :cond_2

    const/4 v5, 0x7

    move v6, v5

    invoke-static {v2}, Lio/openinstall/sdk/dy;->e(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    if-ge v1, v0, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v3}, Ljava/lang/Character;->isDigit(C)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Character;->isLetter(C)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-nez v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v2}, Lio/openinstall/sdk/dy;->e(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :cond_4
    const/4 v6, 0x6

    return-void
.end method

.method public static c(Ljava/lang/String;)V
    .locals 7

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x1

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/16 v1, 0xc

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v2, "daio"

    const-string v2, "doia"

    const/4 v6, 0x5

    const-string/jumbo v2, "ioad"

    const-string/jumbo v2, "oaid"

    const/4 v6, 0x0

    const/4 v5, 0x4

    if-eq v0, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/16 v1, 0x20

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v0, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/16 v1, 0x24

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eq v0, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/16 v1, 0x40

    const/4 v6, 0x1

    const/4 v5, 0x7

    if-eq v0, v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v2}, Lio/openinstall/sdk/dy;->f(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ge v1, v0, :cond_4

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v3}, Ljava/lang/Character;->isDigit(C)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Character;->isLetter(C)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v4, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/16 v4, 0x2d

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eq v3, v4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v2}, Lio/openinstall/sdk/dy;->f(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-void

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method

.method public static d(Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x3

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    const/16 v1, 0x20

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string v2, "gdai"

    const/4 v6, 0x1

    const-string v2, "daig"

    const-string v2, "gaid"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v0, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/16 v1, 0x24

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v0, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v2}, Lio/openinstall/sdk/dy;->f(Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ge v1, v0, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v3}, Ljava/lang/Character;->isDigit(C)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v4, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Character;->isLetter(C)Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    if-nez v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/16 v4, 0x2d

    const/4 v6, 0x1

    const/4 v5, 0x0

    if-eq v3, v4, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-static {v2}, Lio/openinstall/sdk/dy;->f(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method

.method private static e(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    aput-object p0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo p0, "u6u9e /p/61/0b5euue//4d7uu3 cu/687uu5/ofe/c11ua026u1//0s85f///8/7u692uu0157bf%f7cucu/40u5u6ubf/u/6/66f098585f081e45f/835///ucf4ueeb60867"

    const-string p0, "0f/bo6c6031/f68uuue0//f/708 76ue//e/501865071e5e45uu1f76fus1eu7uu825fu/7b28/6108uu/c5/uu/6/u9u/38fuf5ccu9b49uf/e d%ub45a//40c6///86/265u"

    const/4 v3, 0x6

    const-string p0, "6768///eq519f160/b/47564/u5/u5ufuuf1u3u2cc/e/79b79e/5313aduu7/ub8/f046e/ue0u/0u58/// 6012u//866fu/ecuf2u88cb08fc7u6u65u8uu5/4/sfe%51 00f"

    const-string/jumbo p0, "\u4f20\u5165\u9519\u8bef\u7684 %s \u5c06\u5bfc\u81f4\u7edf\u8ba1\u6570\u636e\u5f02\u5e38\uff0c\u8bf7\u68c0\u67e5\u96c6\u6210\u4ee3\u7801"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method private static f(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    aput-object p0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string p0, "5us4u39f048/0uu76 /798uu1bf/u/98c/9u5c69u5f5216u6c3/64u/7239fub5u28 ub/04/e0168uf4/%a550uu///0//8//b6/c/5u3f/uu4dc1/1sf581e5e547f1ueued6"

    const-string p0, "3768/b ecf81f//efcuu8bu/1f76151995/0/6/ab92/8 u9u870//uu44///3u156454e/6u/u4u1%fu476e0ucub8usuc350/fe759f/0cfu5825//4uu1u659/du2/56ud530"

    const/4 v3, 0x3

    const-string p0, "36emu6/6fu u094b1fc/454bf/5f/u28//0uu2uuf12115cua//e68467d1/ufc//15u54u0s8/u9/7fu8/8u34f69u37/0//5u095eu9587u654/ 1dec/355c70/u/6eb8uu%9"

    const-string/jumbo p0, "\u4f20\u5165\u9519\u8bef\u7684 %s \u5c06\u5bfc\u81f4\u5e7f\u544a\u5339\u914d\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u96c6\u6210\u4ee3\u7801"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
