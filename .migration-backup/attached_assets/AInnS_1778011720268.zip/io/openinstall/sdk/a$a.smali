.class Lio/openinstall/sdk/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static a:Lio/openinstall/sdk/a;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lio/openinstall/sdk/a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lio/openinstall/sdk/a;-><init>(Lio/openinstall/sdk/b;)V

    const/4 v3, 0x7

    sput-object v0, Lio/openinstall/sdk/a$a;->a:Lio/openinstall/sdk/a;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
