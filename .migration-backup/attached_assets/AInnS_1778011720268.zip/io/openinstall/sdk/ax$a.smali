.class Lio/openinstall/sdk/ax$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/ax;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Landroid/content/SharedPreferences;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Ljava/lang/String;

.field private final c:Lio/openinstall/sdk/ax$b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Lio/openinstall/sdk/ax$b;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/ax$a;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lio/openinstall/sdk/ax$a;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p3, p0, Lio/openinstall/sdk/ax$a;->c:Lio/openinstall/sdk/ax$b;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Landroid/content/SharedPreferences;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "l s ~@~@~y~~/K ~ co@@f~ o@u  @-t@@i/a~~.@ do~mr@b14S@@~ ~fM @o~~ ibv~~ ~~@~@ ~on @@s~ i@  t@lob@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ax$a;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lio/openinstall/sdk/ax$a;->b:Ljava/lang/String;

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/ax$a;->c:Lio/openinstall/sdk/ax$b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v1, v0}, Lio/openinstall/sdk/ax$b;->a(Landroid/content/SharedPreferences;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/ax$a;->a()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method
