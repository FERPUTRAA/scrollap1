.class public interface abstract Lio/openinstall/sdk/da;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lio/openinstall/sdk/cy;)V
.end method
