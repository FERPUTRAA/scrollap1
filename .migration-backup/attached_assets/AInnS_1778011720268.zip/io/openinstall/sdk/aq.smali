.class public Lio/openinstall/sdk/aq;
.super Ljava/lang/Object;


# instance fields
.field private volatile a:Lio/openinstall/sdk/ar;

.field private final b:Ljava/util/concurrent/CountDownLatch;

.field private final c:Ljava/util/concurrent/LinkedBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/LinkedBlockingQueue<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/aq;->b:Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lio/openinstall/sdk/aq;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lio/openinstall/sdk/aq;->d:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public a(J)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@fso~~~.a@ist1@r@ l@@  ~~b @n M4K~@~~-@di   ~ @@f@  yvc@ibo~~@  u@o@/~b~ ~~/ ~o@@~@t o~ o~m~~~Sl"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/aq;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p2, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method public a()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v1, Lio/openinstall/sdk/ar;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x7

    const/4 v2, 0x5

    sget-object v1, Lio/openinstall/sdk/ar;->b:Lio/openinstall/sdk/ar;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v0, v1, :cond_1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/aq;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lio/openinstall/sdk/aq;->d:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public declared-synchronized a(Lio/openinstall/sdk/ar;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    monitor-exit p0

    throw p1
.end method

.method public a(Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v1, Lio/openinstall/sdk/ar;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object v1, Lio/openinstall/sdk/ar;->b:Lio/openinstall/sdk/ar;

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-ne v0, v1, :cond_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/aq;->c:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/aq;->d:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aq;->b:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x1

    move v3, v2

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, p2, p3, v1}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-boolean p2, Lio/openinstall/sdk/ec;->a:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    aput-object p1, p2, p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p1, "nidmieutw %taeitnsaIt rr"

    const-string p1, "%s awaitInit interrupted"

    const/4 v3, 0x3

    invoke-static {p1, p2}, Lio/openinstall/sdk/ec;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x5

    sget-object v1, Lio/openinstall/sdk/ar;->d:Lio/openinstall/sdk/ar;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method public c()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v1, Lio/openinstall/sdk/ar;->e:Lio/openinstall/sdk/ar;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v2, 0x3

    move v3, v2

    sget-object v1, Lio/openinstall/sdk/ar;->d:Lio/openinstall/sdk/ar;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Lio/openinstall/sdk/ar;->f:Lio/openinstall/sdk/ar;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v0
.end method

.method public declared-synchronized d()Lio/openinstall/sdk/ar;
    .locals 3

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/aq;->a:Lio/openinstall/sdk/ar;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    throw v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/aq;->b:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v2, 0x3

    return-void
.end method
