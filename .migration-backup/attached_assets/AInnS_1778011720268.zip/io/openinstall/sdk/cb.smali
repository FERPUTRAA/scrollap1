.class public Lio/openinstall/sdk/cb;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field private final a:Lio/openinstall/sdk/cg;

.field private final b:Lio/openinstall/sdk/cf;


# direct methods
.method public constructor <init>(Lio/openinstall/sdk/cf;Lio/openinstall/sdk/cg;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/cb;->a:Lio/openinstall/sdk/cg;

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lio/openinstall/sdk/cb;->b:Lio/openinstall/sdk/cf;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Lio/openinstall/sdk/cg;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/cb;-><init>(Lio/openinstall/sdk/cf;Lio/openinstall/sdk/cg;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Lio/openinstall/sdk/cg;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s  lt@ ncb u~-o~@~~S@of m~~1 ~ @@b~lK@o~~~@b @ @ r~s /~~Mo4i @~~ @t@@i@a@/~~~v~@~.iooyd@  @ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cb;->a:Lio/openinstall/sdk/cg;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public a([B)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cb;->b:Lio/openinstall/sdk/cf;

    const/4 v2, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cf;->a([B)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cb;->a:Lio/openinstall/sdk/cg;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cg;->a([B)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public b()Lio/openinstall/sdk/cf;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/cb;->b:Lio/openinstall/sdk/cf;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()[B
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/cb;->b:Lio/openinstall/sdk/cf;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/cf;->d()[B

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cb;->a:Lio/openinstall/sdk/cg;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, v0, Lio/openinstall/sdk/cg;->g:[B

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/cb;->d()Lio/openinstall/sdk/cb;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public d()Lio/openinstall/sdk/cb;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Lio/openinstall/sdk/cb;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/cb;->b:Lio/openinstall/sdk/cf;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Lio/openinstall/sdk/cf;->f()Lio/openinstall/sdk/cf;

    move-result-object v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lio/openinstall/sdk/cb;->a:Lio/openinstall/sdk/cg;

    const/4 v4, 0x3

    invoke-virtual {v2}, Lio/openinstall/sdk/cg;->b()Lio/openinstall/sdk/cg;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cb;-><init>(Lio/openinstall/sdk/cf;Lio/openinstall/sdk/cg;)V

    const/4 v3, 0x3

    and-int/2addr v4, v3

    return-object v0
.end method
