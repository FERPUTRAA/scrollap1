.class public interface abstract Lio/openinstall/sdk/cx;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lio/openinstall/sdk/cw;",
            ">;"
        }
    .end annotation
.end method
