.class public final enum Lio/openinstall/sdk/cl;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lio/openinstall/sdk/cl;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lio/openinstall/sdk/cl;

.field public static final enum b:Lio/openinstall/sdk/cl;

.field private static final synthetic c:[Lio/openinstall/sdk/cl;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lio/openinstall/sdk/cl;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "EGT"

    const-string v1, "TEG"

    const/4 v4, 0x4

    const-string v1, "EGT"

    const-string v1, "GET"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cl;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    sput-object v0, Lio/openinstall/sdk/cl;->a:Lio/openinstall/sdk/cl;

    const/4 v4, 0x7

    const/4 v3, 0x3

    new-instance v0, Lio/openinstall/sdk/cl;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const-string v1, "PTOS"

    const-string v1, "TSPO"

    const-string v1, "SPOT"

    const-string v1, "POST"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v2, 0x1

    move v4, v2

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cl;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    sput-object v0, Lio/openinstall/sdk/cl;->b:Lio/openinstall/sdk/cl;

    const/4 v4, 0x4

    invoke-static {}, Lio/openinstall/sdk/cl;->a()[Lio/openinstall/sdk/cl;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    sput-object v0, Lio/openinstall/sdk/cl;->c:[Lio/openinstall/sdk/cl;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private static synthetic a()[Lio/openinstall/sdk/cl;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/tsfo  ~@~ ~@ m   ~@~ ~~@y~@ @o@l 4cK@~Si~ ~~b@ u i ~@@ r ~no@fs~b~Mo@-~~ @/ila.db@~@t~@~1@vo~o@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array v0, v0, [Lio/openinstall/sdk/cl;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v2, Lio/openinstall/sdk/cl;->a:Lio/openinstall/sdk/cl;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    sget-object v2, Lio/openinstall/sdk/cl;->b:Lio/openinstall/sdk/cl;

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lio/openinstall/sdk/cl;
    .locals 3

    const/4 v2, 0x5

    const-class v0, Lio/openinstall/sdk/cl;

    const-class v0, Lio/openinstall/sdk/cl;

    const/4 v2, 0x3

    const-class v0, Lio/openinstall/sdk/cl;

    const-class v0, Lio/openinstall/sdk/cl;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lio/openinstall/sdk/cl;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lio/openinstall/sdk/cl;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lio/openinstall/sdk/cl;->c:[Lio/openinstall/sdk/cl;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lio/openinstall/sdk/cl;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast v0, [Lio/openinstall/sdk/cl;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method
