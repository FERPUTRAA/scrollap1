.class public Lio/openinstall/sdk/cd;
.super Ljava/lang/Object;


# direct methods
.method public static a(BBBB)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~1s.ba@@v@ @@~o @@ lK@i@ ~ ~~~r~tM@@@- @lnbyis@~  /@~b@u~fm@@ oS 4  i d~~/o ~ ~@c~o ~~~~ot f~@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    and-int/lit16 p0, p0, 0xff

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    shl-int/lit8 p0, p0, 0x18

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    and-int/lit16 p1, p1, 0xff

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    shl-int/lit8 p1, p1, 0x10

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/2addr p0, p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    and-int/lit16 p1, p2, 0xff

    const/4 v1, 0x2

    shl-int/lit8 p1, p1, 0x8

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    or-int/2addr p0, p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    and-int/lit16 p1, p3, 0xff

    const/4 v1, 0x2

    const/4 v0, 0x4

    or-int/2addr p0, p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p0
.end method

.method public static a([BILjava/nio/ByteOrder;)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v3, 0x3

    if-ne p2, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 p2, p1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    aget-byte p2, p0, p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/lit8 v0, p1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    aget-byte v0, p0, v0

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-int/lit8 v1, p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    aget-byte v1, p0, v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    aget-byte p0, p0, p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p2, v0, v1, p0}, Lio/openinstall/sdk/cd;->a(BBBB)I

    move-result p0

    const/4 v3, 0x2

    return p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    aget-byte p2, p0, p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    aget-byte v0, p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    add-int/lit8 v1, p1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    aget-byte v1, p0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/lit8 p1, p1, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    aget-byte p0, p0, p1

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0
.end method

.method public static a(BBBBBBBB)J
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0, p1, p2, p3}, Lio/openinstall/sdk/cd;->a(BBBB)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    int-to-long p0, p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v2, 0x0

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    and-long/2addr p0, p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/16 v0, 0x20

    const/4 v2, 0x6

    shl-long/2addr p0, v0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p4, p5, p6, p7}, Lio/openinstall/sdk/cd;->a(BBBB)I

    move-result p4

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    int-to-long p4, p4

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    and-long/2addr p2, p4

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    or-long/2addr p0, p2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-wide p0
.end method

.method public static a(BB)S
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    shl-int/lit8 p0, p0, 0x8

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    and-int/lit16 p1, p1, 0xff

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    or-int/2addr p0, p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    int-to-short p0, p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method public static b([BILjava/nio/ByteOrder;)S
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    if-ne p2, v0, :cond_0

    const/4 v2, 0x3

    add-int/lit8 p2, p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    aget-byte p2, p0, p2

    const/4 v2, 0x3

    aget-byte p0, p0, p1

    :goto_0
    const/4 v1, 0x5

    move v2, v1

    invoke-static {p2, p0}, Lio/openinstall/sdk/cd;->a(BB)S

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    aget-byte p2, p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    aget-byte p0, p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0
.end method

.method public static c([BILjava/nio/ByteOrder;)J
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-ne p2, v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    add-int/lit8 p2, p1, 0x7

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    aget-byte v0, p0, p2

    const/4 v9, 0x6

    const/4 v8, 0x1

    add-int/lit8 p2, p1, 0x6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    aget-byte v1, p0, p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    add-int/lit8 p2, p1, 0x5

    const/4 v9, 0x4

    const/4 v8, 0x6

    aget-byte v2, p0, p2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    add-int/lit8 p2, p1, 0x4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    aget-byte v3, p0, p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    add-int/lit8 p2, p1, 0x3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    aget-byte v4, p0, p2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    add-int/lit8 p2, p1, 0x2

    const/4 v8, 0x7

    move v9, v8

    aget-byte v5, p0, p2

    const/4 v9, 0x5

    add-int/lit8 p2, p1, 0x1

    const/4 v9, 0x0

    aget-byte v6, p0, p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    aget-byte v7, p0, p1

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static/range {v0 .. v7}, Lio/openinstall/sdk/cd;->a(BBBBBBBB)J

    move-result-wide p0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-wide p0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    aget-byte v0, p0, p1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    add-int/lit8 p2, p1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    aget-byte v1, p0, p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    add-int/lit8 p2, p1, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x7

    aget-byte v2, p0, p2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    add-int/lit8 p2, p1, 0x3

    const/4 v9, 0x4

    aget-byte v3, p0, p2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    add-int/lit8 p2, p1, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    aget-byte v4, p0, p2

    const/4 v9, 0x7

    const/4 v8, 0x1

    add-int/lit8 p2, p1, 0x5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    aget-byte v5, p0, p2

    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    add-int/lit8 p2, p1, 0x6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    aget-byte v6, p0, p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    add-int/lit8 p1, p1, 0x7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    aget-byte v7, p0, p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto :goto_0
.end method
