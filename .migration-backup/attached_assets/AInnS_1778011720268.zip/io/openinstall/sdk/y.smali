.class Lio/openinstall/sdk/y;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Landroid/os/IBinder;

.field final synthetic b:Lio/openinstall/sdk/x;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/x;Landroid/os/IBinder;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/y;->b:Lio/openinstall/sdk/x;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lio/openinstall/sdk/y;->a:Landroid/os/IBinder;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Mst/@ ~~~~ @  ~~1o@bycon i@/ b@K~ @al~~t ~r@ o~f~@ ~@b~4f-oo l S@ @ m~. @v@u@@~@~i@~~d@@s io ~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/y;->b:Lio/openinstall/sdk/x;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lio/openinstall/sdk/x;->a(Lio/openinstall/sdk/x;)Ljava/util/concurrent/LinkedBlockingQueue;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lio/openinstall/sdk/y;->a:Landroid/os/IBinder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
