.class Lio/openinstall/sdk/du;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Ljava/util/concurrent/LinkedBlockingQueue;

.field final synthetic b:Lio/openinstall/sdk/ds;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/ds;Ljava/util/concurrent/LinkedBlockingQueue;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/du;->b:Lio/openinstall/sdk/ds;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p2, p0, Lio/openinstall/sdk/du;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@o -r@~ci /t@Su@   m ~ @f@M~@@ @~oo~~vo@@~  ~od~~~K~@ of~/  si@a@~n~~y1b@@~  l@4tb @i ~lb~~@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/du;->b:Lio/openinstall/sdk/ds;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lio/openinstall/sdk/ds;->d(Lio/openinstall/sdk/ds;)Lio/openinstall/sdk/ay;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/ay;->l()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Lio/openinstall/sdk/cv;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string v2, "Ia"

    const-string v2, "Ia"

    const/4 v5, 0x4

    const-string v2, "aI"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v3, "hise"

    const-string v3, "heis"

    const/4 v5, 0x0

    const-string v3, "hies"

    const-string/jumbo v3, "ihse"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v1, v2, v3, v0}, Lio/openinstall/sdk/cv;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/du;->a:Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    return-void
.end method
