.class public Lio/openinstall/sdk/ab;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ab$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s@rt loy~ ~~~~ t~~m   ~@@ ~@@of@ b~@bu@ ~4~~o@ ~@f@@ @1~K@~ bS. ~oiM ocli ~v@n@~@o@d@/si~/@- a"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v1, "sc.ma.E.DC_soma.osntuDcIsSiaSC"

    const-string v1, "SIstEC_S..nCmacoDscas.uAiaosD."

    const/4 v5, 0x6

    const-string/jumbo v1, "n_IDoatSaScCsos.A.mcDs.oEuami."

    const-string v1, "com.asus.msa.action.ACCESS_DID"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Landroid/content/ComponentName;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "uSmeIbnsra..calmpta.sysDpDumo"

    const-string v2, "com.asus.msa.SupplementaryDID"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v3, "rpcptmuleyrDelcIaiumsmmD.n.vSyIp.nearatu.umpDsoSseeeS"

    const-string/jumbo v3, "rSumDvr.reie.asIeyImlSDtcya.pDStplpnapmoemeanuecsm.us"

    const/4 v5, 0x4

    const-string/jumbo v3, "paapnl.preputS.DnDltepDreSmISmr.esImeivayaDyeumc.cuss"

    const-string v3, "com.asus.msa.SupplementaryDID.SupplementaryDIDService"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Lio/openinstall/sdk/x;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v0, Lio/openinstall/sdk/ab$a;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0, v2}, Lio/openinstall/sdk/ab$a;-><init>(Landroid/os/IBinder;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Lio/openinstall/sdk/ab$a;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw v0

    :catch_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v4, 0x7

    move v5, v4

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v0
.end method
