.class public Lio/openinstall/sdk/cj;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method private a(Ljava/io/InputStream;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "ans/~~~  1o@~d@-Mv~@ bi~@bl~l@@  @  /o~@t @f~ o  @@f ~4s @S ~y~@Kti~  ~rioo~@~ .~@c@@~b@u~@m~@~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Ljava/io/InputStreamReader;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v2, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v4, 0x5

    invoke-direct {v1, p1, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "n/"

    const-string/jumbo v1, "n/"

    const-string v1, "/n"

    const-string v1, "\n"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p1
.end method

.method private a(Ljava/net/HttpURLConnection;[B)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Ljava/io/BufferedOutputStream;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->flush()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cm;I)Lio/openinstall/sdk/cr;
    .locals 8

    const/4 v7, 0x0

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const-string v0, "?"

    const-string v0, "?"

    const/4 v7, 0x1

    const-string v0, "?"

    const-string v0, "?"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/16 v1, 0x3e8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ge p2, v1, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    move p2, v1

    move p2, v1

    const/4 v7, 0x3

    move p2, v1

    :cond_1
    const/4 v7, 0x2

    const/16 v1, 0x2710

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-le p2, v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    move p2, v1

    move p2, v1

    const/4 v7, 0x1

    move p2, v1

    move p2, v1

    :cond_2
    invoke-interface {p1}, Lio/openinstall/sdk/cm;->a()Lio/openinstall/sdk/cl;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    sget-object v2, Lio/openinstall/sdk/cl;->b:Lio/openinstall/sdk/cl;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ne v1, v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->d()[B

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    if-eqz v1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v1, v4

    move v1, v4

    const/4 v7, 0x6

    move v1, v4

    move v1, v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v1, v3

    move v1, v3

    const/4 v7, 0x2

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v5, Ljava/net/URL;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v5, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v5}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    const/4 v7, 0x5

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x3

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->a()Lio/openinstall/sdk/cl;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v4}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, p2}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, p2}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v1, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v4}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->d()[B

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    array-length p2, p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, p2}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    :cond_4
    const/4 v6, 0x3

    move v7, v6

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->e()Ljava/util/Map;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz p2, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->e()Ljava/util/Map;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v2, :cond_5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    invoke-virtual {v0, v3, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string p2, "ecsmnotCno"

    const-string/jumbo p2, "oisncCeotn"

    const/4 v7, 0x3

    const-string/jumbo p2, "nntconCeoo"

    const-string p2, "Connection"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v2, "bomce"

    const-string/jumbo v2, "olcme"

    const/4 v7, 0x7

    const-string v2, "close"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, p2, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/net/URLConnection;->connect()V

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v1, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {p1}, Lio/openinstall/sdk/cm;->d()[B

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {p0, v0, p1}, Lio/openinstall/sdk/cj;->a(Ljava/net/HttpURLConnection;[B)V

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 p2, 0xc8

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-ne p1, p2, :cond_7

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {p0, p1}, Lio/openinstall/sdk/cj;->a(Ljava/io/InputStream;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p2, Lio/openinstall/sdk/cr;

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-direct {p2, p1}, Lio/openinstall/sdk/cr;-><init>(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-object p2

    :cond_7
    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p1, Lio/openinstall/sdk/cr;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-direct {p1, p2, v1}, Lio/openinstall/sdk/cr;-><init>(ILjava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-object p1

    :catchall_0
    move-exception p1

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_3

    :catch_0
    move-exception p1

    move-object v2, v0

    move-object v2, v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_2

    :catchall_1
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x6

    goto :goto_3

    :catch_1
    move-exception p1

    :goto_2
    :try_start_3
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance p2, Lio/openinstall/sdk/cr;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p2, p1}, Lio/openinstall/sdk/cr;-><init>(Ljava/lang/Exception;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v2, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_8
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-object p2

    :goto_3
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v2, :cond_9

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_9
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    throw p1
.end method
