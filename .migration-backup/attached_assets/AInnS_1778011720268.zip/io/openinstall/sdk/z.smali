.class public interface abstract Lio/openinstall/sdk/z;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/content/Context;)Ljava/lang/String;
.end method
