.class final Lio/openinstall/sdk/ad$a;
.super Landroid/os/Binder;

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/ad;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/os/IBinder;


# direct methods
.method public constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    iput-object p1, p0, Lio/openinstall/sdk/ad$a;->a:Landroid/os/IBinder;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/ad$c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " Ms@~@a t @@o~1co   s~@m  ~f @ibnl.~K@io~~@@o ~~oSu/bt@@ ~f@ 4r~~l~@~@~/   @@b~~@-~y @v~id~~~o@ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v2, "eeom.rolmh.daeci.ivo.DocSIsurhvroiIiccsOed"

    const-string/jumbo v2, "resOciDo.ri.eviIcmodnclheorvsaue.oI.idchSo"

    const/4 v5, 0x3

    const-string/jumbo v2, "meoOoiroSrv.evoadoAh.c.cciheIiocDeis.lIrnd"

    const-string v2, "com.hihonor.cloudservice.oaid.IOAIDService"

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/ad$a;->a:Landroid/os/IBinder;

    const/4 v5, 0x2

    const/4 v2, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {p1, v2, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    throw p1
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/ad$a;->a:Landroid/os/IBinder;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method
