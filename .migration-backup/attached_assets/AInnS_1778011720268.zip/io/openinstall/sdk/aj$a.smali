.class final Lio/openinstall/sdk/aj$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/aj;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/os/IBinder;


# direct methods
.method public constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/aj$a;->a:Landroid/os/IBinder;

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@fs~ls~o  y  ~~@o~~~@~@l ~a@iiSt/@@b@ ~. ~1n@o~@/o c4b  vM~mou~ib@~~ ~~ @ @df@-@@t  @@~or @K~ ~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v2, "eegmo.rsiecucsvSdiidnoImcieicsvde.e.cn.vIvsereaDdrmd"

    const-string/jumbo v2, "nDsiIeecdvmceidaivire.cnudss..eirecrmsedvovogI.ceSdi"

    const/4 v6, 0x5

    const-string v2, "com.samsung.android.deviceidservice.IDeviceIdService"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/aj$a;->a:Landroid/os/IBinder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x4

    move v5, v4

    move v5, v4

    const/4 v6, 0x6

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    return-object v2

    :catchall_0
    move-exception v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    throw v2
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/aj$a;->a:Landroid/os/IBinder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method
