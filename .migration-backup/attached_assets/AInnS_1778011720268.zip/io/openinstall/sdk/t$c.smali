.class final Lio/openinstall/sdk/t$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private b:Landroid/os/IBinder;


# direct methods
.method public constructor <init>(Landroid/os/IBinder;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "dnsn.ssreaieesrd.eo.iIgigiooadil.rv.gtagerteSitmdeiAIci.ldsnondcnvmf"

    const-string/jumbo v0, "itsrgnecd.gred.d.odmeioasliArndi.soInm.glrrtiefde.evcSInioevanaitisg"

    const/4 v2, 0x6

    const-string v0, "erimicdodni.nalsIndreiele.adgerv.g.AmtIterongao.nfrsiemcSsidi.gd.tov"

    const-string v0, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/t$c;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/t$c;->b:Landroid/os/IBinder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v2, "tIedostvgangdge.vca.inriideetiSmmacoo.d.ennidIlosrdogmr.lfn.ei.rrisi"

    const-string v2, "eiemeodargecaddg.s.entmi...iirIlvdA.ngldtrvidioinratfcgeIo.smSornins"

    const-string/jumbo v2, "itiilbiAenSrreeiadnlgaIieogamiddo.nnvcgorid.tsgs.of.nm.ree.cedIstvrd"

    const-string v2, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/t$c;->b:Landroid/os/IBinder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-object v2

    :catchall_0
    move-exception v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    throw v2
.end method

.method public a(Z)Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "ev.ecau.eIAidd.ningon..eeiosnegmrgmgns.vtriIoortidlstS.rdaoelafdicid"

    const-string v2, ".n.iooegddngogini.Seven.fd.tasoidAdaiIinore.sdveamcriItegislrr.cmetl"

    const/4 v6, 0x1

    const-string v2, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService"

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const/4 v6, 0x6

    move p1, v2

    move p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    move p1, v3

    move p1, v3

    const/4 v6, 0x4

    move p1, v3

    move p1, v3

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/t$c;->b:Landroid/os/IBinder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p1, v4, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_1

    const/4 v5, 0x1

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    move v2, v3

    move v2, v3

    const/4 v6, 0x0

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x3

    return v2

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    move v6, v5

    throw p1
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/t$c;->b:Landroid/os/IBinder;

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method
