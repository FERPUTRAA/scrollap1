.class public Lio/openinstall/sdk/bi;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/io/File;

.field private final b:Ljava/io/File;

.field private c:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, v1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Ljava/io/File;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo p2, "t."

    const-string p2, ".t"

    const/4 v4, 0x1

    const-string/jumbo p2, "t."

    const-string p2, ".t"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v1, p1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x4

    iput-object v1, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lio/openinstall/sdk/bi;->a(Ljava/io/File;)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0, v1}, Lio/openinstall/sdk/bi;->a(Ljava/io/File;)I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/2addr p1, p2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput p1, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method private a(Ljava/io/File;)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {p1}, Lio/openinstall/sdk/bp;->b(Ljava/io/File;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, ";"

    const-string v2, ";"

    const-string v2, ";"

    const-string v2, ";"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eq v0, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v1
.end method

.method private a(Ljava/lang/String;I)I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    const/4 v5, 0x7

    move v1, v0

    move v1, v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v2, ";"

    const-string v2, ";"

    const/4 v5, 0x6

    const-string v2, ";"

    const-string v2, ";"

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v3, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eq v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v0, v2, 0x1

    const/4 v4, 0x7

    move v5, v4

    if-lt v1, p2, :cond_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v0
.end method

.method private a(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p1, v1}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;Ljava/lang/String;Z)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p1, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/io/File;->length()J

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private b(Lio/openinstall/sdk/be;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    or-int/2addr v6, v5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v2, ","

    const-string v2, ","

    const/4 v6, 0x1

    const-string v2, ","

    const-string v2, ","

    const/4 v6, 0x1

    if-nez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->e()Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->e()Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v6, 0x4

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->f()Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v1, :cond_2

    const/4 v6, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->f()Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-lez v1, :cond_4

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/be;->g()Ljava/util/Map;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v3, :cond_3

    const/4 v6, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v3, Ljava/util/Map$Entry;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast v4, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p1}, Lio/openinstall/sdk/dw;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-lez p1, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string p1, ";"

    const-string p1, ";"

    const/4 v6, 0x4

    const-string p1, ";"

    const-string p1, ";"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget-object v0, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    array-length v0, v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/be;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bi;->b(Lio/openinstall/sdk/be;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/openinstall/sdk/bi;->a(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget p1, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public a()Z
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v2, 0x1

    if-gtz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/16 v1, 0x64

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return v0
.end method

.method public c()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p0, v0}, Lio/openinstall/sdk/bi;->a(Ljava/io/File;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v1, v2, v3}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;Ljava/lang/String;Z)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v1, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    sub-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput v1, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lio/openinstall/sdk/bi;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public e()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p0, v0}, Lio/openinstall/sdk/bi;->a(Ljava/io/File;)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v6, 0x4

    invoke-static {v1}, Lio/openinstall/sdk/bp;->b(Ljava/io/File;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/16 v2, 0x32

    const/4 v5, 0x6

    const/4 v5, 0x7

    if-le v0, v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object v1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    rsub-int/lit8 v0, v0, 0x64

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v2, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2}, Lio/openinstall/sdk/bp;->b(Ljava/io/File;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, v2, v0}, Lio/openinstall/sdk/bi;->a(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v4, p0, Lio/openinstall/sdk/bi;->b:Ljava/io/File;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v4, v3, v1}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;Ljava/lang/String;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v4, p0, Lio/openinstall/sdk/bi;->a:Ljava/io/File;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v4, v0, v1}, Lio/openinstall/sdk/bp;->a(Ljava/io/File;Ljava/lang/String;Z)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object v3
.end method
