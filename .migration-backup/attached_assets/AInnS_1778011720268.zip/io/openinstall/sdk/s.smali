.class public Lio/openinstall/sdk/s;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/s;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private a(Ljava/lang/String;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "s~s~nv@1 oi~ a~u om  M ~/~ i@f@~~~tob~@.@ @~ib  K b @@t~@@@@-@~l~S y/l4@@~cd ~ f~ @@o@~~@o~r@~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_1

    sget-object v0, Lio/openinstall/sdk/dx;->j:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lio/openinstall/sdk/dx;->k:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x5

    or-int/2addr v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method private b(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lio/openinstall/sdk/dx;->l:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x2

    const/4 p1, 0x1

    move v2, p1

    :goto_1
    const/4 v1, 0x0

    move v2, v1

    return p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 12

    const/4 v11, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/s;->b:Ljava/lang/String;

    const/4 v10, 0x2

    shr-int/2addr v11, v10

    if-eqz v0, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    return-object v0

    :cond_0
    const/4 v11, 0x0

    const/4 v0, 0x5

    const/4 v11, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/s;->a:Landroid/content/Context;

    const/4 v11, 0x3

    sget-object v2, Lio/openinstall/sdk/dx;->f:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    check-cast v1, Landroid/net/wifi/WifiManager;

    const/4 v11, 0x5

    if-eqz v1, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v1, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getMacAddress()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    :catchall_0
    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {p0, v0}, Lio/openinstall/sdk/s;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-nez v1, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/s;->b:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    return-object v0

    :cond_2
    :try_start_1
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v1, Ljava/io/BufferedReader;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    new-instance v2, Ljava/io/FileReader;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v3, Ljava/io/File;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    sget-object v4, Lio/openinstall/sdk/dx;->h:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-direct {v2, v3}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catch_1
    :catchall_1
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {p0, v0}, Lio/openinstall/sdk/s;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-nez v1, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/s;->b:Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-object v0

    :cond_3
    :try_start_2
    const/4 v11, 0x3

    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v1}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_4
    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    if-eqz v2, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    check-cast v2, Ljava/net/NetworkInterface;

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    sget-object v3, Lio/openinstall/sdk/dx;->g:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v3, :cond_4

    const/4 v10, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getHardwareAddress()[B

    move-result-object v2

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-eqz v2, :cond_4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    array-length v4, v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v5, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    move v6, v5

    move v6, v5

    const/4 v11, 0x1

    move v6, v5

    move v6, v5

    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-ge v6, v4, :cond_5

    const/4 v11, 0x7

    aget-byte v8, v2, v6

    const/4 v10, 0x3

    xor-int/2addr v11, v10

    const-string v9, "2%sm:"

    const-string v9, ":2s0%"

    const/4 v11, 0x0

    const-string v9, "0:X2o"

    const-string v9, "%02X:"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v8}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v8

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    aput-object v8, v7, v5

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v9, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    goto :goto_1

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-lez v2, :cond_6

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    sub-int/2addr v2, v7

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    :cond_6
    const/4 v11, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto/16 :goto_0

    :catchall_2
    :cond_7
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {p0, v0}, Lio/openinstall/sdk/s;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x2

    if-nez v1, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_2

    :cond_8
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x3

    const-string v0, ""

    const-string v0, ""

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    iput-object v0, p0, Lio/openinstall/sdk/s;->b:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/s;->b:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "HardwareIds"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/s;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/s;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lio/openinstall/sdk/eb;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/s;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v1, "bomne"

    const-string v1, "ehomn"

    const/4 v4, 0x6

    const-string v1, "huope"

    const-string/jumbo v1, "phone"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    check-cast v0, Landroid/telephony/TelephonyManager;

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/16 v2, 0x1a

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-lt v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Lio/openinstall/sdk/a0;->a(Landroid/telephony/TelephonyManager;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getDeviceId()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    :catchall_0
    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p0, v0}, Lio/openinstall/sdk/s;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v0, ""

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object v0, p0, Lio/openinstall/sdk/s;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/s;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-object v0
.end method
