.class Lio/openinstall/sdk/b;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/da;


# instance fields
.field final synthetic a:Lu3/e;

.field final synthetic b:Landroid/net/Uri;

.field final synthetic c:Lio/openinstall/sdk/a;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/a;Lu3/e;Landroid/net/Uri;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/b;->c:Lio/openinstall/sdk/a;

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/b;->a:Lu3/e;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p3, p0, Lio/openinstall/sdk/b;->b:Landroid/net/Uri;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cy;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@sS @~~@ ~~~4lo@ a~ ~~~i  t@~ ~~o~@o1mrd@ ~sf@~lb .@~ @@ @f~~/i boivo- MKc @tyn@~@/@  ou~ @b@@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    aput-object p1, v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v4, "sesmskde:duW sac%U cocsp "

    const-string/jumbo v4, "oesa k:dssUce%ss udccpe W"

    const/4 v6, 0x1

    const-string/jumbo v4, "kpc o:de%acdcs WUuesseoes"

    const-string v4, "decodeWakeUp success : %s"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v4, v0}, Lio/openinstall/sdk/ec;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_0
    :try_start_0
    const/4 v6, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/b;->c:Lio/openinstall/sdk/a;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, p1}, Lio/openinstall/sdk/a;->a(Lio/openinstall/sdk/a;Ljava/lang/String;)Lv3/a;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/b;->a:Lu3/e;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v0, p1, v1}, Lu3/e;->onWakeUpFinish(Lv3/a;Lv3/b;)V

    :cond_1
    const/4 v6, 0x7

    invoke-virtual {p1}, Lv3/a;->c()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez p1, :cond_5

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lio/openinstall/sdk/b;->c:Lio/openinstall/sdk/a;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/b;->b:Landroid/net/Uri;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/a;->a(Landroid/net/Uri;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v5, 0x4

    and-int/2addr v6, v5

    if-eqz v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput-object p1, v0, v2

    const/4 v5, 0x1

    move v6, v5

    const-string/jumbo p1, "oepr b:okUrd%ace rdsWem"

    const-string p1, "Uorm apdr :dreeeWk% cso"

    const/4 v6, 0x0

    const-string/jumbo p1, "rdWaeeuokcd%rrpUs  eo e"

    const-string p1, "decodeWakeUp error : %s"

    invoke-static {p1, v0}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object p1, p0, Lio/openinstall/sdk/b;->a:Lu3/e;

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz p1, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v0, Lio/openinstall/sdk/cy$a;->d:Lio/openinstall/sdk/cy$a;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {p1, v1, v0}, Lu3/e;->onWakeUpFinish(Lv3/a;Lv3/b;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-boolean v0, Lio/openinstall/sdk/ec;->a:Z

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_4

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v6, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    aput-object v3, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v2, "oolUsk pep eaf di%Wdec"

    const-string v2, "eafeo%ids cUda oklWpe "

    const/4 v6, 0x0

    const-string v2, "cUp dfl:qe aide% seaok"

    const-string v2, "decodeWakeUp fail : %s"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v2, v0}, Lio/openinstall/sdk/ec;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_4
    const/4 v6, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/b;->a:Lu3/e;

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0, v1, p1}, Lu3/e;->onWakeUpFinish(Lv3/a;Lv3/b;)V

    :cond_5
    :goto_0
    const/4 v5, 0x0

    move v6, v5

    return-void
.end method
