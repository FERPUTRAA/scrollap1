.class public Lio/openinstall/sdk/bz;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Delayed;


# instance fields
.field private final a:J

.field private final b:Z


# direct methods
.method private constructor <init>(JZ)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-long/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-wide v0, p0, Lio/openinstall/sdk/bz;->a:J

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-boolean p3, p0, Lio/openinstall/sdk/bz;->b:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public static a()Lio/openinstall/sdk/bz;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    new-instance v0, Lio/openinstall/sdk/bz;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2, v3}, Lio/openinstall/sdk/bz;-><init>(JZ)V

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    return-object v0
.end method

.method public static b()Lio/openinstall/sdk/bz;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lio/openinstall/sdk/bz;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-wide/16 v1, 0x320

    const-wide/16 v1, 0x320

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    or-int/2addr v5, v4

    invoke-direct {v0, v1, v2, v3}, Lio/openinstall/sdk/bz;-><init>(JZ)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object v0
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/bz;)I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-wide v0, p0, Lio/openinstall/sdk/bz;->a:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-wide v2, p1, Lio/openinstall/sdk/bz;->a:J

    const/4 v4, 0x7

    and-int/2addr v5, v4

    cmp-long p1, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-gez p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 p1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    return p1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-lez p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 p1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    return p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    return p1
.end method

.method public a(Ljava/util/concurrent/Delayed;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Lio/openinstall/sdk/bz;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lio/openinstall/sdk/bz;->a(Lio/openinstall/sdk/bz;)I

    move-result p1

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/openinstall/sdk/bz;->b:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public synthetic compareTo(Ljava/lang/Object;)I
    .locals 2

    check-cast p1, Ljava/util/concurrent/Delayed;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lio/openinstall/sdk/bz;->a(Ljava/util/concurrent/Delayed;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1
.end method

.method public getDelay(Ljava/util/concurrent/TimeUnit;)J
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-wide v0, p0, Lio/openinstall/sdk/bz;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1, v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-wide v0
.end method
