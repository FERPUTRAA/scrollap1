.class public Lio/openinstall/sdk/bh;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/bh;->a:Ljava/lang/String;

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sb~m s@@. ~t~~~o o l~Sbono/ 4@b@@~~d f@ty~i ~K@a @~l@ ~@f@~M~/~vi~  @or@@@@u~i@1 o ~~ @  ~@~-c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/bh;->a:Ljava/lang/String;

    const/4 v2, 0x0

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/bh;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/bh;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method
