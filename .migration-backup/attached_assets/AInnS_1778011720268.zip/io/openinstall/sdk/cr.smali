.class public Lio/openinstall/sdk/cr;
.super Ljava/lang/Object;


# instance fields
.field private final a:Z

.field private b:I

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Lio/openinstall/sdk/cq;


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/openinstall/sdk/cr;->a:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lio/openinstall/sdk/cr;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p2, p0, Lio/openinstall/sdk/cr;->c:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/Exception;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    or-int/2addr v1, v0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/openinstall/sdk/cr;->a:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lio/openinstall/sdk/cr;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/cr;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/openinstall/sdk/cr;->a:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/cr;->d:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1}, Lio/openinstall/sdk/cq;->a(Ljava/lang/String;)Lio/openinstall/sdk/cq;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/cr;->e:Lio/openinstall/sdk/cq;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c@sotKbM@ @ru ~m~ay ~o/ -  @~~~@ o~  @d~~vil o ~s@~ ~l~@o @@ @@@@.@@ft~b@4@ ifS ~~ i~/n1@~@~o~b~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/openinstall/sdk/cr;->a:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lio/openinstall/sdk/cr;->b:I

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/cr;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/cr;->d:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public e()Lio/openinstall/sdk/cq;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/cr;->e:Lio/openinstall/sdk/cq;

    const/4 v2, 0x3

    return-object v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/openinstall/sdk/cr;->a:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method
