.class public Lio/openinstall/sdk/do;
.super Lio/openinstall/sdk/cs;


# static fields
.field private static final c:[Ljava/lang/String;


# instance fields
.field private final d:Lio/openinstall/sdk/dn;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x2

    const-string/jumbo v0, "s4s..2."

    const-string v0, "48s..2."

    const/4 v8, 0x2

    const-string v0, "24.m..1"

    const-string v0, "1.2.4.8"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v1, "535m.52.2"

    const/4 v8, 0x2

    const-string v1, "235.o.5.5"

    const-string v1, "223.5.5.5"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v2, ".8.88b8"

    const-string v2, ".8.8o88"

    const/4 v8, 0x7

    const-string v2, "...888u"

    const-string v2, "8.8.8.8"

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v3, "b.6.071p6.78"

    const-string v3, "7768.b.01.67"

    const/4 v8, 0x7

    const-string v3, ".67.7061q6.7"

    const-string v3, "180.76.76.76"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v4, ".9s9222u1.19"

    const-string v4, "212..9u99192"

    const/4 v8, 0x1

    const-string v4, "922m1.1.9929"

    const-string v4, "119.29.29.29"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v5, "0262o28...72p2"

    const-string v5, "22..672p2.8022"

    const/4 v8, 0x1

    const-string v5, "222.2b..268702"

    const-string v5, "208.67.222.222"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string v6, "1.141qu14..1141"

    const-string v6, "441111..q44.111"

    const/4 v8, 0x6

    const-string v6, "14141.1p41411.."

    const-string v6, "114.114.114.114"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    sput-object v0, Lio/openinstall/sdk/do;->c:[Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void
.end method

.method public constructor <init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/dn;)V
    .locals 3
    .param p2    # Lio/openinstall/sdk/dn;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lio/openinstall/sdk/cs;-><init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/do;->d:Lio/openinstall/sdk/dn;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method private a(Ljava/lang/String;)Landroid/util/Pair;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~Su~@o q@rcld~ @~@ K  n@y@b@ @~~/mf~@~@~b  il~ o s@~ .~ooo@t4b @@~ ~o~~@v -M1~ @f~@@@~i @at/~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    const-string v0, "////"

    const-string v0, "////"

    const/4 v2, 0x0

    const-string v0, "////"

    const-string v0, "\"\""

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->c()Lio/openinstall/sdk/at;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/at;->a(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1, p1}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lio/openinstall/sdk/dm;->b(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method private o()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/do;->d:Lio/openinstall/sdk/dn;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v1

    :cond_0
    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Lio/openinstall/sdk/dn;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->c()Lio/openinstall/sdk/at;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v2}, Lio/openinstall/sdk/at;->h()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Lio/openinstall/sdk/av;->c()Lio/openinstall/sdk/ck;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/ck;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method protected k()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "ycssaim"

    const-string/jumbo v0, "yascimd"

    const/4 v2, 0x1

    const-string/jumbo v0, "maymdci"

    const-string v0, "dynamic"

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method protected m()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-super {p0}, Lio/openinstall/sdk/cs;->m()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->c()Lio/openinstall/sdk/ck;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/ck;->a()V

    const/4 v2, 0x3

    return-void
.end method

.method protected n()Lio/openinstall/sdk/cy;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/do;->o()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lio/openinstall/sdk/do;->a(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lio/openinstall/sdk/cs;->a:Lio/openinstall/sdk/av;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Lio/openinstall/sdk/av;->c()Lio/openinstall/sdk/ck;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    iget-object v2, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v1, v2, v0}, Lio/openinstall/sdk/ck;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lio/openinstall/sdk/cy;->a()Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    return-object v0
.end method
