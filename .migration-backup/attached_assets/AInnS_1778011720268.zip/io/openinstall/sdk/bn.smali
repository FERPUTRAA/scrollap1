.class Lio/openinstall/sdk/bn;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/bj;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/bj;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/bn;->a:Lio/openinstall/sdk/bj;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o1sd~ r~@@@@l~b ~~bo  tubo/~.~ @o  ~ic~@~M@~Kao@@S ~i~ ~~@~@t@@~n@f ~l@@ vo@m /~y  ~~@f @4- si@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lio/openinstall/sdk/az;->a()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method
