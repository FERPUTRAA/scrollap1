.class public Lio/openinstall/sdk/bq;
.super Ljava/lang/Object;


# static fields
.field private static b:Lio/openinstall/sdk/bq;

.field private static final c:Ljava/lang/Object;


# instance fields
.field private final a:Lio/openinstall/sdk/br;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Lio/openinstall/sdk/bq;->c:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Lio/openinstall/sdk/bs;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-interface {p1}, Lio/openinstall/sdk/au;->a_()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    check-cast p1, Lio/openinstall/sdk/br;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/bq;->a:Lio/openinstall/sdk/br;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Lio/openinstall/sdk/bs;)Lio/openinstall/sdk/bq;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "i~s@~~/~ K @y o .@ ~@s~d@a~ v @1~ ~lf u ~@@ b @M@~@@o@c@b~f~on/~t~ l~ ~~ m  4b~@-i@or@t~~@ooi@S~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lio/openinstall/sdk/bq;->c:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    move v3, v2

    sget-object v1, Lio/openinstall/sdk/bq;->b:Lio/openinstall/sdk/bq;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lio/openinstall/sdk/bq;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lio/openinstall/sdk/bq;-><init>(Lio/openinstall/sdk/bs;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v1, Lio/openinstall/sdk/bq;->b:Lio/openinstall/sdk/bq;

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object p0, Lio/openinstall/sdk/bq;->b:Lio/openinstall/sdk/bq;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw p0
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/bq;->a:Lio/openinstall/sdk/br;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/openinstall/sdk/br;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/bq;->a:Lio/openinstall/sdk/br;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Lio/openinstall/sdk/br;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lio/openinstall/sdk/bq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lio/openinstall/sdk/bq;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x7

    return-void
.end method
