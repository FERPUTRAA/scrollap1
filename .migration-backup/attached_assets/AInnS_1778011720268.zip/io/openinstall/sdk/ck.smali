.class public Lio/openinstall/sdk/ck;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lio/openinstall/sdk/ck;


# instance fields
.field private final b:Lio/openinstall/sdk/cj;

.field private final c:Lio/openinstall/sdk/av;

.field private d:Lio/openinstall/sdk/ci;

.field private e:Lio/openinstall/sdk/ch;

.field private f:Ljava/util/concurrent/CountDownLatch;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/cj;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/ck;->f:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v2, 0x3

    iput-object p2, p0, Lio/openinstall/sdk/ck;->b:Lio/openinstall/sdk/cj;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Lio/openinstall/sdk/av;)Lio/openinstall/sdk/ck;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o~s @ f~ ~~rb~o@ @~@ K@@@f  o@uv/y @~oi @ c~tm ~So@n~@~t~~  sli1~o@@ @~b ~M~4/~b@a~@~.l~- @ d@~i"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    sget-object v0, Lio/openinstall/sdk/ck;->a:Lio/openinstall/sdk/ck;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-class v0, Lio/openinstall/sdk/ck;

    const/4 v4, 0x3

    const-class v0, Lio/openinstall/sdk/ck;

    const-class v0, Lio/openinstall/sdk/ck;

    const/4 v4, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v1, Lio/openinstall/sdk/ck;->a:Lio/openinstall/sdk/ck;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v1, Lio/openinstall/sdk/ck;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v2, Lio/openinstall/sdk/cj;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v2}, Lio/openinstall/sdk/cj;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1, p0, v2}, Lio/openinstall/sdk/ck;-><init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/cj;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    sput-object v1, Lio/openinstall/sdk/ck;->a:Lio/openinstall/sdk/ck;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    throw p0

    :cond_1
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object p0, Lio/openinstall/sdk/ck;->a:Lio/openinstall/sdk/ck;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0
.end method

.method private a(Lio/openinstall/sdk/cr;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->a()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->e()Lio/openinstall/sdk/cq;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Lio/openinstall/sdk/cq;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Lio/openinstall/sdk/aw;->b(Ljava/lang/String;)Lio/openinstall/sdk/aw;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v3, 0x0

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->f()Lio/openinstall/sdk/aw;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/aw;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/aw;->a(Lio/openinstall/sdk/aw;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p1, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Lio/openinstall/sdk/av;->d()Lio/openinstall/sdk/at;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/at;->a(Lio/openinstall/sdk/aw;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lio/openinstall/sdk/aw;->h()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/av;->i()Lio/openinstall/sdk/bq;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/aw;->h()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v1, v0}, Lio/openinstall/sdk/bq;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private declared-synchronized b()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ck;->i:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/ck;->d:Lio/openinstall/sdk/ci;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/ci;->c()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/ck;->i:Ljava/util/Map;

    :cond_0
    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/ck;->i:Ljava/util/Map;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    throw v0
.end method

.method private b(Lio/openinstall/sdk/cp;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ck;->f:Ljava/util/concurrent/CountDownLatch;

    const/4 v4, 0x4

    move v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/ck;->f:Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-wide/16 v2, 0x3

    const-wide/16 v2, 0x3

    const/4 v5, 0x3

    const-wide/16 v2, 0x3

    const-wide/16 v2, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v2, v3, v1}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v5, 0x4

    invoke-virtual {p1}, Lio/openinstall/sdk/cp;->g()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/ck;->g:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ck;->h:Ljava/lang/String;

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/cp;->f()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p1}, Lio/openinstall/sdk/cp;->f()Ljava/lang/String;

    move-result-object v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_5

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cp;->g()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v5, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ck;->e:Lio/openinstall/sdk/ch;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0}, Lio/openinstall/sdk/ch;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_1

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/ck;->e:Lio/openinstall/sdk/ch;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v0}, Lio/openinstall/sdk/ch;->c()Ljava/lang/String;

    move-result-object v0

    :cond_5
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/cp;->b(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method private b(Lio/openinstall/sdk/cr;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->a()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->e()Lio/openinstall/sdk/cq;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cq;->a()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0xf

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne p1, v1, :cond_1

    :cond_0
    const/4 v3, 0x5

    iget-object p1, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Lio/openinstall/sdk/av;->d()Lio/openinstall/sdk/at;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/at;->c(Z)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private c()Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/ck;->b()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Lio/openinstall/sdk/av;->f()Lio/openinstall/sdk/aw;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v6, 0x1

    invoke-virtual {v2}, Lio/openinstall/sdk/av;->i()Lio/openinstall/sdk/bq;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v1}, Lio/openinstall/sdk/aw;->h()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Lio/openinstall/sdk/bq;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Lio/openinstall/sdk/aw;->h()Ljava/lang/String;

    move-result-object v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v2, "3fef"

    const-string v2, "f3ef"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "szqms"

    const-string/jumbo v2, "szsqv"

    const/4 v6, 0x1

    const-string/jumbo v2, "vzqmo"

    const-string/jumbo v2, "qmvzs"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ck;->c:Lio/openinstall/sdk/av;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0}, Lio/openinstall/sdk/av;->d()Lio/openinstall/sdk/at;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lio/openinstall/sdk/at;->j()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p1, Lio/openinstall/sdk/cr;

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Exception;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string v1, "e qndbfidotbesurr"

    const-string/jumbo v1, "request forbidden"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p1, v0}, Lio/openinstall/sdk/cr;-><init>(Ljava/lang/Exception;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lio/openinstall/sdk/ck;->c()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lio/openinstall/sdk/cp;->a(Ljava/util/Map;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lio/openinstall/sdk/ck;->b(Lio/openinstall/sdk/cp;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/ck;->b:Lio/openinstall/sdk/cj;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/16 v1, 0x1388

    const/4 v3, 0x3

    invoke-virtual {v0, p1, v1}, Lio/openinstall/sdk/cj;->a(Lio/openinstall/sdk/cm;I)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cr;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lio/openinstall/sdk/ck;->b(Lio/openinstall/sdk/cr;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->f()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/ck;->e:Lio/openinstall/sdk/ch;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0}, Lio/openinstall/sdk/ch;->a()V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p1
.end method

.method public a(Ljava/util/Map;)Lio/openinstall/sdk/cr;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Lio/openinstall/sdk/cr;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lio/openinstall/sdk/cp;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v2, "iu/tm"

    const-string v2, "/timi"

    const/4 v4, 0x4

    const-string v2, "/init"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cp;-><init>(ZLjava/lang/String;)V

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cp;->b(Ljava/util/Map;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    return-object p1
.end method

.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lio/openinstall/sdk/cn;

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, p1}, Lio/openinstall/sdk/cn;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    iget-object p1, p0, Lio/openinstall/sdk/ck;->b:Lio/openinstall/sdk/cj;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/16 v1, 0xbb8

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Lio/openinstall/sdk/cj;->a(Lio/openinstall/sdk/cm;I)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Lio/openinstall/sdk/cr;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1
.end method

.method public a()V
    .locals 4

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object v0, p0, Lio/openinstall/sdk/ck;->f:Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public a(Lio/openinstall/sdk/ch;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    iput-object p1, p0, Lio/openinstall/sdk/ck;->e:Lio/openinstall/sdk/ch;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public a(Lio/openinstall/sdk/ci;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/ck;->d:Lio/openinstall/sdk/ci;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v0, "."

    const-string v0, "."

    const-string v0, "."

    const-string v0, "."

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v1, "2oppa"

    const-string v1, "2apio"

    const/4 v6, 0x0

    const-string v1, "api2."

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x3

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v4, "2ipqa"

    const-string v4, "bapi2"

    const-string/jumbo v4, "iasp-"

    const-string v4, "api2-"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/ck;->g:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz p2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo p1, "ut2mts"

    const-string/jumbo p1, "u2satt"

    const/4 v6, 0x4

    const-string/jumbo p1, "tat.o2"

    const-string/jumbo p1, "stat2."

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1}, Lio/openinstall/sdk/as;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v3, "pa-s2b"

    const-string/jumbo v3, "sp2t-a"

    const/4 v6, 0x0

    const-string/jumbo v3, "utas2t"

    const-string/jumbo v3, "stat2-"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p2, p1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/ck;->h:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    move v6, v5

    iput-object p2, p0, Lio/openinstall/sdk/ck;->h:Ljava/lang/String;

    :goto_0
    const/4 v6, 0x6

    iget-object p1, p0, Lio/openinstall/sdk/ck;->f:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    :cond_2
    const/4 v6, 0x7

    return-void
.end method

.method public b(Ljava/lang/String;)Lio/openinstall/sdk/cr;
    .locals 5

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Lio/openinstall/sdk/co;

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x4

    shr-int/2addr v3, v1

    const/4 v4, 0x0

    const-string v2, "/sqsantp/esvt"

    const-string v2, "/sanvtesqtts/"

    const/4 v4, 0x6

    const-string/jumbo v2, "te/vns/tqstsa"

    const-string v2, "/stats/events"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/co;-><init>(ZLjava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/co;->a(Ljava/lang/String;)V

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p1
.end method

.method public b(Ljava/util/Map;)Lio/openinstall/sdk/cr;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Lio/openinstall/sdk/cr;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v0, Lio/openinstall/sdk/cp;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v2, "e-spcrodew/uka-eul"

    const-string v2, "/decode-wakeup-url"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cp;-><init>(ZLjava/lang/String;)V

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cp;->b(Ljava/util/Map;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p1
.end method

.method public c(Ljava/util/Map;)Lio/openinstall/sdk/cr;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Lio/openinstall/sdk/cr;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    new-instance v0, Lio/openinstall/sdk/cp;

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x3

    const/4 v3, 0x0

    const-string/jumbo v2, "s//msptuetksa"

    const-string v2, "atswkus/et/sp"

    const/4 v4, 0x3

    const-string/jumbo v2, "kusaoetp/a/sw"

    const-string v2, "/stats/wakeup"

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cp;-><init>(ZLjava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cp;->b(Ljava/util/Map;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p1
.end method

.method public d(Ljava/util/Map;)Lio/openinstall/sdk/cr;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Lio/openinstall/sdk/cr;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Lio/openinstall/sdk/cp;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    move v4, v3

    const-string/jumbo v2, "phoeebr/arst/"

    const-string v2, "/share/report"

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cp;-><init>(ZLjava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cp;->b(Ljava/util/Map;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object p1
.end method

.method public e(Ljava/util/Map;)Lio/openinstall/sdk/cr;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "*>;)",
            "Lio/openinstall/sdk/cr;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v0, Lio/openinstall/sdk/cp;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x1

    and-int/2addr v5, v1

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v2, "atutssu"

    const-string v2, "/status"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0, v1, v2}, Lio/openinstall/sdk/cp;-><init>(ZLjava/lang/String;)V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v1, "lZQbZeXpu6Rmln3H"

    const-string v1, "Xb3mZQeRlZucnHl6"

    const/4 v5, 0x5

    const-string v1, "RQhc6HlbqeuZlX3Z"

    const-string v1, "c3RhZXZlbnQueHl6"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v3, "TosU8"

    const-string v3, "8TFUo"

    const/4 v5, 0x7

    const-string v3, "8F-mU"

    const-string v3, "UTF-8"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Lio/openinstall/sdk/cp;->b(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lio/openinstall/sdk/cp;->b(Ljava/util/Map;)V

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/cp;)Lio/openinstall/sdk/cr;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object p1
.end method
