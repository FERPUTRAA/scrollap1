.class public Lio/openinstall/sdk/aa;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Lio/openinstall/sdk/z;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "aesiuh"

    const-string/jumbo v1, "uhseia"

    const/4 v4, 0x7

    const-string/jumbo v1, "waumeh"

    const-string v1, "huawei"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v1, :cond_1a

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "iaymot"

    const-string/jumbo v1, "iyimta"

    const/4 v4, 0x5

    const-string/jumbo v1, "tiynib"

    const-string/jumbo v1, "tianyi"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto/16 :goto_5

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "ouoon"

    const-string/jumbo v1, "nohoo"

    const/4 v4, 0x4

    const-string v1, "hnpoo"

    const-string v1, "honor"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p0}, Lio/openinstall/sdk/ad;->b(Landroid/content/Context;)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p0, Lio/openinstall/sdk/ad;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ad;-><init>()V

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance p0, Lio/openinstall/sdk/ae;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/ae;-><init>()V

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0

    :cond_2
    const/4 v4, 0x1

    const-string/jumbo v1, "xiqmia"

    const-string/jumbo v1, "iaixmb"

    const/4 v4, 0x5

    const-string/jumbo v1, "iosxma"

    const-string/jumbo v1, "xiaomi"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v1, :cond_19

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v1, "urmme"

    const-string v1, "eudrm"

    const/4 v4, 0x5

    const-string/jumbo v1, "redmi"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v1, :cond_19

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "rlsbopckaa"

    const-string v1, "halkrcspba"

    const/4 v4, 0x7

    const-string/jumbo v1, "kchsabrakl"

    const-string v1, "blackshark"

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    if-nez v1, :cond_19

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v1, "euiuq"

    const-string/jumbo v1, "umeqi"

    const/4 v4, 0x5

    const-string/jumbo v1, "impte"

    const-string/jumbo v1, "meitu"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto/16 :goto_4

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "vvoi"

    const-string/jumbo v1, "vivo"

    const/4 v4, 0x3

    const-string/jumbo v1, "vvio"

    const-string/jumbo v1, "vivo"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance p0, Lio/openinstall/sdk/ak;

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/ak;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object p0

    :cond_4
    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "ppoo"

    const-string/jumbo v1, "oopp"

    const/4 v4, 0x0

    const-string/jumbo v1, "popo"

    const-string/jumbo v1, "oppo"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v1, :cond_18

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "leqars"

    const-string/jumbo v1, "masrel"

    const/4 v4, 0x0

    const-string/jumbo v1, "mrseea"

    const-string/jumbo v1, "realme"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v1, :cond_18

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "lmomepu"

    const-string/jumbo v1, "osemplu"

    const-string/jumbo v1, "oneplus"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_5

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    goto/16 :goto_3

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v1, "noleoo"

    const-string/jumbo v1, "oenool"

    const/4 v4, 0x2

    const-string/jumbo v1, "onvoeb"

    const-string/jumbo v1, "lenovo"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v1, :cond_17

    const/4 v4, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "mltaorub"

    const-string/jumbo v1, "ltarmboo"

    const/4 v4, 0x3

    const-string/jumbo v1, "lrmootap"

    const-string/jumbo v1, "motorola"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v1, :cond_17

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "kuz"

    const/4 v4, 0x5

    const-string/jumbo v1, "kuz"

    const-string/jumbo v1, "zuk"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_17

    const/4 v4, 0x7

    const/4 v3, 0x2

    const-string/jumbo v1, "qomouotl"

    const-string v1, "almooout"

    const/4 v4, 0x0

    const-string/jumbo v1, "losamoro"

    const-string/jumbo v1, "motolora"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto/16 :goto_2

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "pmsuang"

    const/4 v4, 0x3

    const-string/jumbo v1, "samsung"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p0, Lio/openinstall/sdk/aj;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/aj;-><init>()V

    return-object p0

    :cond_7
    const/4 v4, 0x6

    const-string/jumbo v1, "zummi"

    const-string/jumbo v1, "meizu"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v1, :cond_16

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v1, "mblu"

    const-string/jumbo v1, "mlub"

    const/4 v4, 0x4

    const-string v1, "blum"

    const-string/jumbo v1, "mblu"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_8

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto/16 :goto_1

    :cond_8
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "nqubo"

    const-string v1, "biuqn"

    const/4 v4, 0x6

    const-string/jumbo v1, "nubia"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_9

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance p0, Lio/openinstall/sdk/ah;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ah;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p0

    :cond_9
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v1, "etz"

    const-string v1, "etz"

    const/4 v4, 0x4

    const-string/jumbo v1, "zte"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_a

    const/4 v4, 0x1

    const/4 v3, 0x2

    new-instance p0, Lio/openinstall/sdk/am;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/am;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p0

    :cond_a
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "sasu"

    const-string/jumbo v1, "ssua"

    const/4 v4, 0x7

    const-string/jumbo v1, "susa"

    const-string v1, "asus"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_b

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance p0, Lio/openinstall/sdk/ab;

    const/4 v3, 0x2

    move v4, v3

    invoke-direct {p0}, Lio/openinstall/sdk/ab;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p0

    :cond_b
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "ocdasbleevuodppt..cimoidrcp"

    const-string v0, "com.coolpad.deviceidsupport"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, v0}, Lio/openinstall/sdk/aa;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_c

    const/4 v4, 0x2

    const/4 v3, 0x0

    new-instance p0, Lio/openinstall/sdk/ac;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Lio/openinstall/sdk/ac;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :cond_c
    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "eell.oubfrlmsiebrude."

    const-string v0, "e.sdbebmaoferrllui.el"

    const/4 v4, 0x3

    const-string/jumbo v0, "riml.abpleberulefed.."

    const-string/jumbo v0, "ro.build.freeme.label"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_d

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v2, "feemmsor"

    const/4 v4, 0x0

    const-string/jumbo v2, "qeefmrse"

    const-string v2, "freemeos"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_d

    const/4 v4, 0x7

    new-instance p0, Lio/openinstall/sdk/am;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/am;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :cond_d
    const/4 v4, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "ocosotsuprrd.ui"

    const/4 v4, 0x4

    const-string/jumbo v0, "ro.ssui.product"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v2, "nnsobwn"

    const-string/jumbo v2, "nwknobn"

    const/4 v4, 0x1

    const-string/jumbo v2, "unwmnkn"

    const-string/jumbo v2, "unknown"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v2}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_e

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v0, :cond_e

    const/4 v3, 0x6

    move v4, v3

    new-instance p0, Lio/openinstall/sdk/am;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0}, Lio/openinstall/sdk/am;-><init>()V

    const/4 v4, 0x0

    return-object p0

    :cond_e
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v0, "oibloeuune..vou.isimr"

    const-string v0, "dv.eoeuno.iriuu.sbilm"

    const/4 v4, 0x3

    const-string v0, "elr..boounbsruim.ivde"

    const-string/jumbo v0, "ro.build.version.emui"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_15

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v0, "iacrnou.l_dlh.ppbfurwsmoivst"

    const-string/jumbo v0, "neob_lsplcisuvrphw.orf.mtdia"

    const/4 v4, 0x1

    const-string v0, "fpertdwpbissmcor.nhil_.lu.oa"

    const-string v0, "hw_sc.build.platform.version"

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v0, :cond_f

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto/16 :goto_0

    :cond_f
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v0, "mnar.ql.qsecvir.guooid"

    const-string/jumbo v0, "icaeobrgq.dri.vul.omns"

    const/4 v4, 0x4

    const-string v0, ".ss.cumiao.vibrdgrlino"

    const-string/jumbo v0, "ro.build.version.magic"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_11

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0}, Lio/openinstall/sdk/ad;->b(Landroid/content/Context;)Z

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p0, :cond_10

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance p0, Lio/openinstall/sdk/ad;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/ad;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    return-object p0

    :cond_10
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p0, Lio/openinstall/sdk/ae;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ae;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p0

    :cond_11
    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string/jumbo v0, "mirmn.orsuieo.niu.m.ais"

    const-string v0, "eis...noa.mrirniuimeuos"

    const/4 v4, 0x0

    const-string v0, "a.euoseiroorvnin.m.mui."

    const-string/jumbo v0, "ro.miui.ui.version.name"

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_12

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p0, Lio/openinstall/sdk/al;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0}, Lio/openinstall/sdk/al;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p0

    :cond_12
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v0, "vovrebimrvnoo.s.o."

    const-string/jumbo v0, "vnvm.v.rioie.orsoo"

    const/4 v4, 0x7

    const-string v0, "eovs.iu.rriv.ovnos"

    const-string/jumbo v0, "ro.vivo.os.version"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_13

    const/4 v4, 0x0

    new-instance p0, Lio/openinstall/sdk/ak;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/ak;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p0

    :cond_13
    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, ".iopr.oponpourio.drsebvl"

    const-string/jumbo v0, "rrdrouo.pblooveon.i.iosp"

    const/4 v4, 0x4

    const-string/jumbo v0, "ro.build.version.opporom"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lio/openinstall/sdk/aa;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_14

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v0, Lio/openinstall/sdk/ai;

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lio/openinstall/sdk/ai;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x3

    return-object v0

    :cond_14
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p0, Lio/openinstall/sdk/w;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lio/openinstall/sdk/w;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p0

    :cond_15
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance p0, Lio/openinstall/sdk/ae;

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ae;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    return-object p0

    :cond_16
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p0, Lio/openinstall/sdk/ag;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Lio/openinstall/sdk/ag;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :cond_17
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance p0, Lio/openinstall/sdk/af;

    const/4 v4, 0x3

    invoke-direct {p0}, Lio/openinstall/sdk/af;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    return-object p0

    :cond_18
    :goto_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Lio/openinstall/sdk/ai;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, p0}, Lio/openinstall/sdk/ai;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0

    :cond_19
    :goto_4
    const/4 v3, 0x0

    move v4, v3

    new-instance p0, Lio/openinstall/sdk/al;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0}, Lio/openinstall/sdk/al;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p0

    :cond_1a
    :goto_5
    const/4 v4, 0x3

    const/4 v3, 0x4

    new-instance p0, Lio/openinstall/sdk/ae;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/ae;-><init>()V

    const/4 v3, 0x6

    and-int/2addr v4, v3

    return-object p0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v1, "ordeta.iqesPrimobystnSro.ds"

    const-string v1, "domonbyasidsrot.pi.rPeretSs"

    const/4 v8, 0x4

    const-string v1, "dssoe.rPsSoettendsromi.yrip"

    const-string v1, "android.os.SystemProperties"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string v2, "gte"

    const-string v2, "get"

    const/4 v8, 0x4

    const-string v2, "etg"

    const-string v2, "get"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v3, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    aput-object v0, v4, v5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v6, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v0, v4, v6

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object p0, v2, v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    aput-object p1, v2, v6

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-object p0
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :catch_0
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0
.end method
