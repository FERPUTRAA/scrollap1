.class public Lio/openinstall/sdk/i;
.super Lio/openinstall/sdk/av;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/openinstall/sdk/av;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected a()Lio/openinstall/sdk/bs;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "-@s~iK~M  ~r~~/o@@f@~@od ~ ~ ~~@ ~@~~~v/@~ ~obm~niS1@b@~@@ut   st@~@o @ @~b oa4 ~i@ofl@l@cy@~  ."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Lio/openinstall/sdk/an;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Lio/openinstall/sdk/an;-><init>()V

    const/4 v1, 0x6

    and-int/2addr v2, v1

    return-object v0
.end method
