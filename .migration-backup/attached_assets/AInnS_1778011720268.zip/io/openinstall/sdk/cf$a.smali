.class Lio/openinstall/sdk/cf$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/openinstall/sdk/cf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field a:[B


# direct methods
.method public constructor <init>([B)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lio/openinstall/sdk/cf$a;->a:[B

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()[B
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  s@i@ /l~~o ~@i~c~ @@~fi~ @t4@@/v~~S@ t@los@of@@~@~~~@@@@@~ar.~-~ M1nb~m~bo   d@bo   ~ ~ ~uy~Ko"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/cf$a;->a:[B

    const/4 v6, 0x1

    array-length v1, v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/16 v2, 0xc

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    sub-int/2addr v1, v2

    const/4 v5, 0x1

    and-int/2addr v6, v5

    new-array v3, v1, [B

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v2, v3, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x4

    return-object v3
.end method
