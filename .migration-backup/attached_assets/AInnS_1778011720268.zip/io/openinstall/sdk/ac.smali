.class public Lio/openinstall/sdk/ac;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ac$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~s@o/d@~@~o~o b ~i i/K~l~ @~. r @yl1M~@ ~@@~   ~@@fb@~S@s~c@~@m t a~~@t@n~- @o~ u@ @ ~4 bofv~io"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v1, Landroid/content/ComponentName;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "secmceo.svuoitiladodp.rpcdo"

    const-string/jumbo v2, "pdsedpieatodsi.cvorpul.ococ"

    const/4 v5, 0x0

    const-string/jumbo v2, "pirsoiccvmtlodapdocpoedu..o"

    const-string v2, "com.coolpad.deviceidsupport"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v3, "c.dmvecvcDvoppee.mreasicoriepS.ddIdliiuoteo"

    const/4 v5, 0x7

    const-string v3, "i.deabpcoeevoiDidvop.redpeicvcmltSdeIorc.cu"

    const-string v3, "com.coolpad.deviceidsupport.DeviceIdService"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v1, Lio/openinstall/sdk/x;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v1}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Lio/openinstall/sdk/ac$a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0, v2}, Lio/openinstall/sdk/ac$a;-><init>(Landroid/os/IBinder;)V

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Lio/openinstall/sdk/ac$a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    throw v0

    :catch_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v0
.end method
