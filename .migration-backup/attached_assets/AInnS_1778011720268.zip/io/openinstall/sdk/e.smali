.class Lio/openinstall/sdk/e;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/da;


# instance fields
.field final synthetic a:Lu3/f;

.field final synthetic b:Lio/openinstall/sdk/a;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/a;Lu3/f;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/e;->b:Lio/openinstall/sdk/a;

    const/4 v1, 0x0

    iput-object p2, p0, Lio/openinstall/sdk/e;->a:Lu3/f;

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a(Lio/openinstall/sdk/cy;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "K~sr~@ /ofo@-l~~n~i@si~/o@  d  ~toM1@v@~u mbc~ib@t@@4~~@ @@~.@fl@~@~@S ~ b~@o~@    ~~ @~ a @y~ ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/e;->a:Lu3/f;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    move v4, v3

    new-instance v1, Ljava/io/File;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lio/openinstall/sdk/cy;->c()Lio/openinstall/sdk/cy$a;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lv3/b;->a(Lio/openinstall/sdk/cy$a;)Lv3/b;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v0, v1, p1}, Lu3/f;->a(Ljava/lang/Object;Lv3/b;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method
