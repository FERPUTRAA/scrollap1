.class public Lio/openinstall/sdk/ec;
.super Ljava/lang/Object;


# static fields
.field public static a:Z = true


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static varargs a(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s~o@@ @ @~~~1@lt @ .Kobu~ @v~~@-f~ol@~md @~~@~ b@~M @~ia~ ytcb @n~@/~i~f S@@~~ ~o4r @ @ so/@ o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    const-string/jumbo p1, "slOmlpannse"

    const-string/jumbo p1, "pOstnesnlal"

    const-string/jumbo p1, "lIpsonteOan"

    const-string p1, "OpenInstall"

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static varargs b(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    invoke-static {p0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    const-string/jumbo p1, "tneIlbOsmna"

    const-string p1, "epnmItnlaOs"

    const/4 v1, 0x4

    const-string/jumbo p1, "slaIpOutenl"

    const-string p1, "OpenInstall"

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public static varargs c(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    const-string/jumbo p1, "tnInOepploa"

    const-string/jumbo p1, "lOntoeIlpna"

    const/4 v1, 0x2

    const-string/jumbo p1, "psIeOnltqna"

    const-string p1, "OpenInstall"

    const/4 v1, 0x0

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
