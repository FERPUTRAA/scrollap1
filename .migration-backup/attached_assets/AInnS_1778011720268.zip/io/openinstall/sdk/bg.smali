.class Lio/openinstall/sdk/bg;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/bf;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/bf;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    iput-object p1, p0, Lio/openinstall/sdk/bg;->a:Lio/openinstall/sdk/bf;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "iisad  ~@o t~@~~ /K@ S@~~ @   4f~@sy ot@b@ou@- M~~i f~@@~@ o~l @mol~~ ~o~nrb~@@@@~ ~~~ ~c1v/.@b@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/bg;->a:Lio/openinstall/sdk/bf;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lio/openinstall/sdk/bf;->a(Lio/openinstall/sdk/bf;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bg;->a:Lio/openinstall/sdk/bf;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lio/openinstall/sdk/bf;->b(Lio/openinstall/sdk/bf;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/bg;->a:Lio/openinstall/sdk/bf;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lio/openinstall/sdk/bf;->a(Lio/openinstall/sdk/bf;Z)Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/bg;->a:Lio/openinstall/sdk/bf;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/bf;->b()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method
