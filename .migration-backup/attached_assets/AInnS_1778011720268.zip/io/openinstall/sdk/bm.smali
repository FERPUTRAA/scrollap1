.class Lio/openinstall/sdk/bm;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/bj;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/bj;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@Ms@~i@ oo~ @~~1@~@ n  ~~i/i@~@4l@K~v~~ u@@@o/as~@-~ o  @rff@~ b~ ~l b@~@@ ~m   dcS~t @.~oo@~tb~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const/16 v0, 0x64

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v1, 0x0

    :goto_0
    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    iget-object v2, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v2}, Lio/openinstall/sdk/bj;->a(Lio/openinstall/sdk/bj;)Ljava/util/concurrent/LinkedBlockingQueue;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    int-to-long v3, v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2, v3, v4, v5}, Ljava/util/concurrent/LinkedBlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v2, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v2}, Lio/openinstall/sdk/bj;->b(Lio/openinstall/sdk/bj;)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v2, :cond_0

    const/4 v7, 0x0

    iget-object v2, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v2}, Lio/openinstall/sdk/bj;->c(Lio/openinstall/sdk/bj;)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v2, 0x23

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ge v1, v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-lez v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Lio/openinstall/sdk/as;->b(Z)V

    const/4 v6, 0x2

    move v7, v6

    iget-object v2, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v2}, Lio/openinstall/sdk/bj;->d(Lio/openinstall/sdk/bj;)V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2}, Lio/openinstall/sdk/as;->l()Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v3}, Lio/openinstall/sdk/bj;->a(Lio/openinstall/sdk/bj;Z)Z

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v2, p0, Lio/openinstall/sdk/bm;->a:Lio/openinstall/sdk/bj;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v2}, Lio/openinstall/sdk/bj;->e(Lio/openinstall/sdk/bj;)Lio/openinstall/sdk/bo;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2}, Lio/openinstall/sdk/bo;->a()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    mul-int/lit8 v0, v0, 0xa

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/16 v2, 0x2710

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x7

    goto/16 :goto_0
.end method
