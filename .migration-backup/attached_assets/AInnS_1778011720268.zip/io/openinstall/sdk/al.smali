.class public Lio/openinstall/sdk/al;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    :try_start_0
    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@@sM @ nv@~1@  ~i~ub ~~~~K/@@-i~ @ ~t@ @ crodf~/ o ~bl~ @@y~Sof~~@i~@  @ ~ oao~4om~@~@.@~t@@ lbs"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    const-string v0, ".pdmdan.rprIsPiveiIlodoimo.iddrc.l"

    const-string v0, ".psiddod.omdorIivrirldinIpelaPm..c"

    const/4 v8, 0x2

    const-string v0, "d.dIopmleailpmPn.rodvdrom.diociIr."

    const-string v0, "com.android.id.impl.IdProviderImpl"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo v2, "mteIObg"

    const-string v2, "AIgmtOe"

    const/4 v8, 0x0

    const-string v2, "IegDOtu"

    const-string v2, "getOAID"

    const/4 v8, 0x0

    const/4 v3, 0x3

    const/4 v8, 0x6

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x5

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    aput-object v5, v4, v6

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v7, 0x4

    or-int/2addr v8, v7

    aput-object p1, v2, v6

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x2

    move v8, v7

    if-eqz p1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object p1

    :catch_0
    :cond_0
    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 p1, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object p1
.end method
