.class public Lio/openinstall/sdk/ak;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "@-sc~~fb@m@od.1@@~~by~@@~M   @@si~~@ouo4~f @  rl~@~ o  @ /o~~~~~ i~@@~aSl~o@  ~i   @@@tKvb t~n~@"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string v1, "eftmecndroetvsvncm.r/IIPnv:/m..idIvI/iiOAodDdtisoe/"

    const-string/jumbo v1, "vOsrD:csndto.idivcPI/eteod/m/AeIrI.i.inmvfordeI/vnt"

    const/4 v10, 0x2

    const-string v1, "/:iooodtnriomnv/ceAIsiDIe..tmIPv/vOfcoreid/rdtI.dvn"

    const-string v1, "content://com.vivo.vms.IdProvider/IdentifierId/OAID"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v4, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v6, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v7, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz p1, :cond_3

    :try_start_1
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    const/4 v10, 0x5

    const/4 v9, 0x7

    const-string v1, "aelmu"

    const/4 v10, 0x0

    const-string v1, "bvelu"

    const-string/jumbo v1, "value"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-gez v1, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-interface {p1}, Landroid/database/Cursor;->isClosed()Z

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez v1, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-object v0

    :cond_1
    :try_start_2
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-interface {p1, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-interface {p1}, Landroid/database/Cursor;->isClosed()Z

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x0

    if-nez v1, :cond_2

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto :goto_0

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-eqz p1, :cond_5

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p1}, Landroid/database/Cursor;->isClosed()Z

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    if-nez v1, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_1

    :catchall_1
    move-exception p1

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eqz p1, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-interface {p1}, Landroid/database/Cursor;->isClosed()Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez v1, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    throw v0

    :catch_0
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :catch_1
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-eqz p1, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {p1}, Landroid/database/Cursor;->isClosed()Z

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-nez v1, :cond_5

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_5
    const/4 v9, 0x6

    return-object v0
.end method
