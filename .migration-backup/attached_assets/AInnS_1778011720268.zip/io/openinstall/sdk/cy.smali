.class public Lio/openinstall/sdk/cy;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/cy$a;
    }
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field private b:Lio/openinstall/sdk/cy$a;


# direct methods
.method private constructor <init>(Lio/openinstall/sdk/cy$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/cy;->b:Lio/openinstall/sdk/cy$a;

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lio/openinstall/sdk/cy$a;Lio/openinstall/sdk/cz;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lio/openinstall/sdk/cy;-><init>(Lio/openinstall/sdk/cy$a;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lio/openinstall/sdk/cy;->a:Ljava/lang/String;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-void
.end method

.method public static a()Lio/openinstall/sdk/cy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s s@o~u@~@f M1~~~~ y~t~  b@@/-t@am ~S  ~. ~ Ko4 @l@o o~@~/fn@o @@bb d~o~~ @@@c@i@rv i ~~~~~@@l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-static {v0}, Lio/openinstall/sdk/cy;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public static a(Lio/openinstall/sdk/cr;)Lio/openinstall/sdk/cy;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->a()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->e()Lio/openinstall/sdk/cq;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cq;->a()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cq;->c()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0}, Lio/openinstall/sdk/cy;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lio/openinstall/sdk/cy$a;->e:Lio/openinstall/sdk/cy$a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/cq;->b()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->b()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lio/openinstall/sdk/cy$a;->d:Lio/openinstall/sdk/cy$a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->c()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lio/openinstall/sdk/cy$a;->c:Lio/openinstall/sdk/cy$a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/openinstall/sdk/cr;->c()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static a(Ljava/lang/String;)Lio/openinstall/sdk/cy;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lio/openinstall/sdk/cy;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lio/openinstall/sdk/cy;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/cy;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public c()Lio/openinstall/sdk/cy$a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/openinstall/sdk/cy;->b:Lio/openinstall/sdk/cy$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method
