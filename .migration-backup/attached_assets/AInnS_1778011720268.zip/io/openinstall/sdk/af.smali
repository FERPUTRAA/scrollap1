.class public Lio/openinstall/sdk/af;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/af$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "-~s~Sv ~M@~ ~@~i~~ ~4~o@c@b @@@@b@~@/K@~~~  @ai .tyum o 1~~~  l@f/nor bo@  ~@t@  f ~@di@~@~lsoo~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    const-string v1, "eevmsdieiedsivmzcru.cc."

    const-string/jumbo v1, "zssiedmuciriv.e.evieccd"

    const/4 v4, 0x7

    const-string/jumbo v1, "izodoiccsievvu.ecrdeime"

    const-string v1, "com.zui.deviceidservice"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v2, "ievmebecicdivSeir.mecdr.cdueDceo.viiiez"

    const-string v2, "ecvmueeiddcceedriiiieSDesirecmvvci.zo.."

    const/4 v4, 0x0

    const-string v2, "dicmieuvvicvuc.rceeSsedcii.Dzeerd.ioiee"

    const-string v2, "com.zui.deviceidservice.DeviceidService"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    new-instance v1, Lio/openinstall/sdk/x;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Lio/openinstall/sdk/af$a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v2}, Lio/openinstall/sdk/af$a;-><init>(Landroid/os/IBinder;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/af$a;->a()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    throw v0

    :catch_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method
