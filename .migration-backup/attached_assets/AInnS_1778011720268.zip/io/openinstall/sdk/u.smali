.class synthetic Lio/openinstall/sdk/u;
.super Ljava/lang/Object;
