.class public Lio/openinstall/sdk/eb;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "v~s@ mof/i.u@~@~f~4o~~n@~~b@r@@  ~b~d~s o  oS~y@~~M@@    @o i@@~~@tl~@~ / @@loc1it-Kb~a@@ ~ ~  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string/jumbo v0, "soTmiEAosd.p_aie.TPn_iRDOmsSArnNErE"

    const-string v0, ".msENOaodTDri_nAAE.rePSTHsns_EiipoR"

    const/4 v2, 0x4

    const-string v0, "android.permission.READ_PHONE_STATE"

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lio/openinstall/sdk/eb;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v0

    :cond_0
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, p1, v1, v2}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    move v4, v3

    return v0
.end method
