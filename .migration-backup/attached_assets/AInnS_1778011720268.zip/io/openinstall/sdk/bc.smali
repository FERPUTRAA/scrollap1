.class Lio/openinstall/sdk/bc;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Lio/openinstall/sdk/bd;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Landroid/app/Dialog;


# direct methods
.method constructor <init>(Lio/openinstall/sdk/bd;Landroid/content/Context;Landroid/app/Dialog;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lio/openinstall/sdk/bc;->a:Lio/openinstall/sdk/bd;

    const/4 v1, 0x2

    iput-object p2, p0, Lio/openinstall/sdk/bc;->b:Landroid/content/Context;

    const/4 v0, 0x1

    move v1, v0

    iput-object p3, p0, Lio/openinstall/sdk/bc;->c:Landroid/app/Dialog;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~sc@~@f~   n/ ~yoS@~ @~4ib~ob~.@~  ~o@i~o ~oru1~-~@~~@@ o@@ ~vd@bKa@@ f tMt@~/ @@ il~s ~~l@~m@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "iEam.rsanItnet.dcidoV.Woin"

    const-string/jumbo v0, "irscn.a.ddeiVta.EotoItnnWi"

    const/4 v3, 0x0

    const-string v0, "ciWootiIVEdontnn.t.ir.aane"

    const-string v0, "android.intent.action.VIEW"

    const/4 v2, 0x0

    move v3, v2

    iget-object v1, p0, Lio/openinstall/sdk/bc;->a:Lio/openinstall/sdk/bd;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1}, Lio/openinstall/sdk/bd;->g()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/high16 v0, 0x10000000

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/bc;->b:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lio/openinstall/sdk/bc;->c:Landroid/app/Dialog;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method
