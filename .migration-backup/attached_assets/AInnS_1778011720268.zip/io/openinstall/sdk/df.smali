.class public abstract Lio/openinstall/sdk/df;
.super Lio/openinstall/sdk/cs;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/openinstall/sdk/cs;",
        "Ljava/util/concurrent/Callable<",
        "Lio/openinstall/sdk/cy;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lio/openinstall/sdk/cs;-><init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~isy@~@~~o o~mufv @@~~a~o  b~ n ~d~ l@~ .tor i @bK@~o@ct ~ f@@-~4 @@~ ~/~@ @o1i@bM@Sl~~@ @@~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/df;->p()Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method protected n()Lio/openinstall/sdk/cy;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->i()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/util/concurrent/AbstractExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/df;->r()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    int-to-long v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v0, v1, v2, v3}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    check-cast v1, Lio/openinstall/sdk/cy;
    :try_end_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v1, Lio/openinstall/sdk/cy$a;->c:Lio/openinstall/sdk/cy$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :catch_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-interface {v0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object v0, Lio/openinstall/sdk/cy$a;->f:Lio/openinstall/sdk/cy$a;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/cy$a;->a()Lio/openinstall/sdk/cy;

    move-result-object v1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object v1
.end method

.method protected o()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->h()Lio/openinstall/sdk/bv;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->k()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/bv;->a(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public p()Lio/openinstall/sdk/cy;
    .locals 6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lio/openinstall/sdk/df;->o()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->k()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Lio/openinstall/sdk/df;->r()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    int-to-long v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lio/openinstall/sdk/aq;->a(Ljava/lang/String;J)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->c()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v0, Lio/openinstall/sdk/cy$a;->f:Lio/openinstall/sdk/cy$a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/cy$a;->a()Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->b()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->c()Lio/openinstall/sdk/at;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/openinstall/sdk/at;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    sget-object v1, Lio/openinstall/sdk/cy$a;->b:Lio/openinstall/sdk/cy$a;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Lio/openinstall/sdk/df;->q()Lio/openinstall/sdk/cy;

    move-result-object v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object v0
.end method

.method protected abstract q()Lio/openinstall/sdk/cy;
.end method

.method protected abstract r()I
.end method
