.class public Lio/openinstall/sdk/ai;
.super Ljava/lang/Object;

# interfaces
.implements Lio/openinstall/sdk/z;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/openinstall/sdk/ai$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p1, p0, Lio/openinstall/sdk/ai;->a:Landroid/content/Context;

    const/4 v0, 0x0

    and-int/2addr v1, v0

    return-void
.end method

.method private a()Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/NoSuchAlgorithmException;,
            Landroid/content/pm/PackageManager$NameNotFoundException;
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " @s ~l@~o ~1~@~~@MS4/o~~.nyft@to~ ~ @db ~@c   @ o~r~~~ @K@~~i@ a @ ~@~i@i @s~b-/ov~mu@@l b@~f@ o"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/ai;->b:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v0, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/ai;->a:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v1, p0, Lio/openinstall/sdk/ai;->a:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v2, 0x40

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x0

    aget-object v0, v0, v1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v2, "ASH1"

    const-string v2, "HSA1"

    const/4 v8, 0x0

    const-string v2, "SAH1"

    const-string v2, "SHA1"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v2}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v2, v0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    array-length v3, v0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-ge v1, v3, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    aget-byte v4, v0, v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    and-int/lit16 v4, v4, 0xff

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    or-int/lit16 v4, v4, 0x100

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v5, 0x3

    and-int/2addr v8, v5

    const/4 v7, 0x1

    move v8, v7

    const/4 v6, 0x1

    move v8, v6

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v4, v6, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    iput-object v0, p0, Lio/openinstall/sdk/ai;->b:Ljava/lang/String;

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lio/openinstall/sdk/ai;->b:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/Context;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v1, "DOam.IEE.CnNPtdeyh_EaeoomtiSo.isnp_IcpV."

    const-string v1, "OistyIcSEoEtIm..Cae_inPpnVoha_NED.dpoec."

    const/4 v6, 0x2

    const-string/jumbo v1, "tyVionIodnCER.SpaEec_.Iia_.NthoDoEO.cPpe"

    const-string v1, "action.com.heytap.openid.OPEN_ID_SERVICE"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    new-instance v1, Landroid/content/ComponentName;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "ndpaob.i.eymhtmeo"

    const-string/jumbo v2, "yocmtnhei.apode.m"

    const/4 v6, 0x0

    const-string/jumbo v2, "meoyc.udppntih.eo"

    const-string v2, "com.heytap.openid"

    const/4 v6, 0x1

    const-string v3, "IiieyfdpSmtopcor.dinenvaetpyeec.h"

    const-string/jumbo v3, "tSmio..iI.pyaenpehvcrdyefeocedtin"

    const/4 v6, 0x1

    const-string/jumbo v3, "ynheinadqoItfSoe.emiptd.epvcie.cy"

    const-string v3, "com.heytap.openid.IdentifyService"

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Lio/openinstall/sdk/x;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v1}, Lio/openinstall/sdk/x;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Lio/openinstall/sdk/ai$a;

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Lio/openinstall/sdk/x;->a()Landroid/os/IBinder;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v0, v2}, Lio/openinstall/sdk/ai$a;-><init>(Landroid/os/IBinder;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p0}, Lio/openinstall/sdk/ai;->a()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v4, "DIOU"

    const-string v4, "IUDO"

    const-string v4, "OUID"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, v2, v3, v4}, Lio/openinstall/sdk/ai$a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    throw v0

    :catch_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    return-object v0
.end method
