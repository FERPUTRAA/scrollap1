.class public abstract Lio/openinstall/sdk/av;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lio/openinstall/sdk/ck;

.field private final c:Lio/openinstall/sdk/at;

.field private final d:Lio/openinstall/sdk/aq;

.field private final e:Lio/openinstall/sdk/aw;

.field private final f:Landroid/os/Handler;

.field private final g:Lio/openinstall/sdk/bs;


# direct methods
.method protected constructor <init>()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v0, Landroid/os/Handler;

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-object v0, p0, Lio/openinstall/sdk/av;->f:Landroid/os/Handler;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/openinstall/sdk/as;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object v0, p0, Lio/openinstall/sdk/av;->a:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v1, Lio/openinstall/sdk/aq;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v1}, Lio/openinstall/sdk/aq;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object v1, p0, Lio/openinstall/sdk/av;->d:Lio/openinstall/sdk/aq;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance v1, Lio/openinstall/sdk/aw;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v1}, Lio/openinstall/sdk/aw;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object v1, p0, Lio/openinstall/sdk/av;->e:Lio/openinstall/sdk/aw;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v1, Lio/openinstall/sdk/ax;

    const/4 v4, 0x1

    move v5, v4

    invoke-direct {v1}, Lio/openinstall/sdk/ax;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v2, "FosfcgiM_"

    const-string v2, "FM_config"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v0, v2, v3}, Lio/openinstall/sdk/ax;->a(Landroid/content/Context;Ljava/lang/String;Lio/openinstall/sdk/ax$b;)Ljava/util/concurrent/Future;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v1, Lio/openinstall/sdk/at;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v1, v0}, Lio/openinstall/sdk/at;-><init>(Ljava/util/concurrent/Future;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v1, p0, Lio/openinstall/sdk/av;->c:Lio/openinstall/sdk/at;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Lio/openinstall/sdk/ck;->a(Lio/openinstall/sdk/av;)Lio/openinstall/sdk/ck;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    iput-object v0, p0, Lio/openinstall/sdk/av;->b:Lio/openinstall/sdk/ck;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lio/openinstall/sdk/av;->a()Lio/openinstall/sdk/bs;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v0, p0, Lio/openinstall/sdk/av;->g:Lio/openinstall/sdk/bs;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lio/openinstall/sdk/as;->a()Lio/openinstall/sdk/as;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Lio/openinstall/sdk/at;->i()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lio/openinstall/sdk/as;->c(Z)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method


# virtual methods
.method protected abstract a()Lio/openinstall/sdk/bs;
.end method

.method public b()Landroid/os/Handler;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@~m @i ~@r~Kld~@on@st@@a/ot M @4~f@~~ib@o@@~i~ ~/ @b-o~ @~u~  @o@v ~l@   @ @. ~1~om cf~Sb@y~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/av;->f:Landroid/os/Handler;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public c()Lio/openinstall/sdk/ck;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/av;->b:Lio/openinstall/sdk/ck;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public d()Lio/openinstall/sdk/at;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/openinstall/sdk/av;->c:Lio/openinstall/sdk/at;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public e()Lio/openinstall/sdk/aq;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/openinstall/sdk/av;->d:Lio/openinstall/sdk/aq;

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method public f()Lio/openinstall/sdk/aw;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/openinstall/sdk/av;->e:Lio/openinstall/sdk/aw;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public g()Lio/openinstall/sdk/ay;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lio/openinstall/sdk/av;->a:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lio/openinstall/sdk/av;->c:Lio/openinstall/sdk/at;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {v0, v1}, Lio/openinstall/sdk/ay;->a(Landroid/content/Context;Lio/openinstall/sdk/at;)Lio/openinstall/sdk/ay;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public h()Lio/openinstall/sdk/bv;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lio/openinstall/sdk/av;->a:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Lio/openinstall/sdk/bv;->a(Landroid/content/Context;)Lio/openinstall/sdk/bv;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method

.method public i()Lio/openinstall/sdk/bq;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/openinstall/sdk/av;->g:Lio/openinstall/sdk/bs;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lio/openinstall/sdk/bq;->a(Lio/openinstall/sdk/bs;)Lio/openinstall/sdk/bq;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method
