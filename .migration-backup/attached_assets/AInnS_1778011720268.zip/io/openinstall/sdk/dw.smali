.class public Lio/openinstall/sdk/dw;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "l@s~   @@im~o~ v~@  S~4~i@@s@o@-~  /fo  Kd@~~@bo~~l~obcai~~~.oub@fnytM@ @@/ @~1 ~ @~@r~   @t~~@~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {}, Lio/openinstall/sdk/bt;->c()Lio/openinstall/sdk/bt$a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/bt$a;->a(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v3, 0x3

    move v4, v3

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v2, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    return-object v1

    :catch_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p0
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lio/openinstall/sdk/bt;->d()Lio/openinstall/sdk/bt$a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p0}, Lio/openinstall/sdk/bt$a;->a(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x1

    sget-object v2, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v1

    :catch_0
    return-object p0
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lio/openinstall/sdk/bt;->a()Lio/openinstall/sdk/bt$b;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v1, Lio/openinstall/sdk/bu;->c:Ljava/nio/charset/Charset;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Lio/openinstall/sdk/bt$b;->a([B)[B

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v2, Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v2, v0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v2

    :catch_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0
.end method
