.class public abstract Lio/openinstall/sdk/dj;
.super Lio/openinstall/sdk/cs;


# direct methods
.method public constructor <init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lio/openinstall/sdk/cs;-><init>(Lio/openinstall/sdk/av;Lio/openinstall/sdk/da;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected n()Lio/openinstall/sdk/cy;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s ~~@b@ut@@~ o .@o~4 rS~@ @/i~@~@~~t@~~   f vb@M~d@am~@l1oi lf@/ ~ @@sib@~y-~ ~oc~K@  n o~ @~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->a()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->c()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lio/openinstall/sdk/cy$a;->f:Lio/openinstall/sdk/cy$a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lio/openinstall/sdk/cy$a;->a()Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->b()Lio/openinstall/sdk/aq;

    move-result-object v0

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-virtual {v0}, Lio/openinstall/sdk/aq;->b()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/cs;->c()Lio/openinstall/sdk/at;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lio/openinstall/sdk/at;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v1, Lio/openinstall/sdk/cy$a;->b:Lio/openinstall/sdk/cy$a;

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/openinstall/sdk/dj;->o()Lio/openinstall/sdk/cy;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lio/openinstall/sdk/cy$a;->c:Lio/openinstall/sdk/cy$a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Lio/openinstall/sdk/cy$a;->a(Ljava/lang/String;)Lio/openinstall/sdk/cy;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method

.method protected abstract o()Lio/openinstall/sdk/cy;
.end method
