.class Lio/reactivex/e0$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/e0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field final a:Ljava/lang/Runnable;

.field final b:Lio/reactivex/e0$c;

.field volatile c:Z


# direct methods
.method constructor <init>(Ljava/lang/Runnable;Lio/reactivex/e0$c;)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/e0$b;->a:Ljava/lang/Runnable;

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/e0$b;->b:Lio/reactivex/e0$c;

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @sot   ~@u @~ndo @o@~@@@m~Kcr~ /@s~~~ b /@~ibl 1@@~-ob@ ~@ ~ ~~@~~y4~o MS@@ifl.~o a~@~t~~f iv @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/e0$b;->c:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    or-int/2addr v2, v1

    iput-boolean v0, p0, Lio/reactivex/e0$b;->c:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/e0$b;->b:Lio/reactivex/e0$c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public run()V
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/e0$b;->c:Z

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    if-nez v0, :cond_0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/e0$b;->a:Ljava/lang/Runnable;

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/e0$b;->b:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v1}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw v0

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
