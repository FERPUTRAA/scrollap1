.class final Lio/reactivex/e0$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/e0$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "a"
.end annotation


# instance fields
.field final a:Ljava/lang/Runnable;

.field final b:Lio/reactivex/internal/disposables/k;

.field final c:J

.field d:J

.field e:J

.field f:J

.field final synthetic g:Lio/reactivex/e0$c;


# direct methods
.method constructor <init>(Lio/reactivex/e0$c;JLjava/lang/Runnable;JLio/reactivex/internal/disposables/k;J)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/e0$c$a;->g:Lio/reactivex/e0$c;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/e0$c$a;->a:Ljava/lang/Runnable;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p7, p0, Lio/reactivex/e0$c$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-wide p8, p0, Lio/reactivex/e0$c$a;->c:J

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-wide p5, p0, Lio/reactivex/e0$c$a;->e:J

    const/4 v1, 0x1

    iput-wide p2, p0, Lio/reactivex/e0$c$a;->f:J

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 14

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v12, "ots~~~ ~o~ ~f~/~~.on m@s~@ @ vo@~ M~ tiub~~r  S~ 1io~-l@@ @@ico~a@y@@ ~/lb @@@db~f@4@ @@ ~@~@ K~"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x0

    iget-object v0, p0, Lio/reactivex/e0$c$a;->a:Ljava/lang/Runnable;

    const/4 v13, 0x5

    const/4 v12, 0x3

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-object v0, p0, Lio/reactivex/e0$c$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v13, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v0

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x3

    if-nez v0, :cond_2

    const/4 v13, 0x1

    iget-object v0, p0, Lio/reactivex/e0$c$a;->g:Lio/reactivex/e0$c;

    const/4 v13, 0x0

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v0, v1}, Lio/reactivex/e0$c;->b(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x7

    sget-wide v4, Lio/reactivex/e0;->a:J

    const/4 v13, 0x7

    add-long v6, v2, v4

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x0

    iget-wide v8, p0, Lio/reactivex/e0$c$a;->e:J

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x4

    cmp-long v0, v6, v8

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x6

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v13, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x7

    if-ltz v0, :cond_1

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-wide v10, p0, Lio/reactivex/e0$c$a;->c:J

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    add-long/2addr v8, v10

    const/4 v13, 0x4

    const/4 v12, 0x4

    add-long/2addr v8, v4

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x5

    cmp-long v0, v2, v8

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    if-ltz v0, :cond_0

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_0

    :cond_0
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    iget-wide v4, p0, Lio/reactivex/e0$c$a;->f:J

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x4

    iget-wide v8, p0, Lio/reactivex/e0$c$a;->d:J

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x2

    add-long/2addr v8, v6

    const/4 v13, 0x6

    iput-wide v8, p0, Lio/reactivex/e0$c$a;->d:J

    const/4 v12, 0x3

    and-int/2addr v13, v12

    mul-long/2addr v8, v10

    const/4 v13, 0x4

    const/4 v12, 0x2

    add-long/2addr v4, v8

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-wide v4, p0, Lio/reactivex/e0$c$a;->c:J

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x4

    add-long v8, v2, v4

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x6

    iget-wide v10, p0, Lio/reactivex/e0$c$a;->d:J

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    add-long/2addr v10, v6

    const/4 v12, 0x1

    const/4 v13, 0x2

    iput-wide v10, p0, Lio/reactivex/e0$c$a;->d:J

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    mul-long/2addr v4, v10

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x5

    sub-long v4, v8, v4

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x0

    iput-wide v4, p0, Lio/reactivex/e0$c$a;->f:J

    move-wide v4, v8

    :goto_1
    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x6

    iput-wide v2, p0, Lio/reactivex/e0$c$a;->e:J

    const/4 v13, 0x7

    sub-long/2addr v4, v2

    const/4 v12, 0x0

    move v13, v12

    iget-object v0, p0, Lio/reactivex/e0$c$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v13, 0x6

    const/4 v12, 0x1

    iget-object v2, p0, Lio/reactivex/e0$c$a;->g:Lio/reactivex/e0$c;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-virtual {v2, p0, v4, v5, v1}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object v1

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/internal/disposables/k;->b(Lio/reactivex/disposables/c;)Z

    :cond_2
    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x2

    return-void
.end method
