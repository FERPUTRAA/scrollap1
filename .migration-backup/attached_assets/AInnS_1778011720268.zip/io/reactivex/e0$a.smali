.class Lio/reactivex/e0$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Runnable;

.field final synthetic b:Lio/reactivex/e0$c;

.field final synthetic c:Lio/reactivex/e0;


# direct methods
.method constructor <init>(Lio/reactivex/e0;Ljava/lang/Runnable;Lio/reactivex/e0$c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/e0$a;->c:Lio/reactivex/e0;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/e0$a;->a:Ljava/lang/Runnable;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/e0$a;->b:Lio/reactivex/e0$c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ys@b~vt iuS~~ ~o /~r@~ m~~o ~otc ~nlM~-@o@@ @i f@~~~@sf a~ @i@ @l~ .o 1~@o  @b~~/@~~@K@b@@d@4 ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/e0$a;->a:Ljava/lang/Runnable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/e0$a;->b:Lio/reactivex/e0$c;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/e0$a;->b:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v1}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    throw v0
.end method
