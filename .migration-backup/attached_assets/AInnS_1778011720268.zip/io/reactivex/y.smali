.class public interface abstract Lio/reactivex/y;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/j;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lio/reactivex/j<",
        "TT;>;"
    }
.end annotation


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b(Lio/reactivex/disposables/c;)V
.end method

.method public abstract c(Lt7/f;)V
.end method

.method public abstract serialize()Lio/reactivex/y;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/y<",
            "TT;>;"
        }
    .end annotation
.end method
