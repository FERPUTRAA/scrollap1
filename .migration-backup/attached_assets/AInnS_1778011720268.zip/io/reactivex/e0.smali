.class public abstract Lio/reactivex/e0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/e0$b;,
        Lio/reactivex/e0$c;
    }
.end annotation


# static fields
.field static final a:J


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "ttsd-clnerxre2ecuisaros.dlr.h"

    const-string v1, "edscr2adhr.tecusr-rnti.lexelo"

    const-string v1, "fnemdrtrreie.cxaltsru2.locedh"

    const-string/jumbo v1, "rx2.scheduler.drift-tolerance"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x4

    const-wide/16 v2, 0xf

    const-wide/16 v2, 0xf

    const/4 v5, 0x0

    invoke-static {v1, v2, v3}, Ljava/lang/Long;->getLong(Ljava/lang/String;J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    sput-wide v0, Lio/reactivex/e0;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static b()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "li~~o@@ s~rv@-y @~~K~1~t@~do~@ ooo@ct~nm@~@~ bul@.~    ~ i~@a~/@ f/ ~b~@b@4MoS~@ @  @ @ if ~@o@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-wide v0, Lio/reactivex/e0;->a:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method


# virtual methods
.method public abstract c()Lio/reactivex/e0$c;
.end method

.method public d(Ljava/util/concurrent/TimeUnit;)J
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method public f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v2, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v0, v1, v2}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object p1
.end method

.method public g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->Y(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Lio/reactivex/e0$a;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-direct {v1, p0, p1, v0}, Lio/reactivex/e0$a;-><init>(Lio/reactivex/e0;Ljava/lang/Runnable;Lio/reactivex/e0$c;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p2, p3, p4}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public h(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;
    .locals 9

    const/4 v8, 0x4

    invoke-virtual {p0}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v0

    const/4 v8, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->Y(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    move-result-object p1

    const/4 v8, 0x2

    new-instance v7, Lio/reactivex/e0$b;

    const/4 v8, 0x7

    invoke-direct {v7, p1, v0}, Lio/reactivex/e0$b;-><init>(Ljava/lang/Runnable;Lio/reactivex/e0$c;)V

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-wide v2, p2

    move-wide v4, p4

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x4

    invoke-virtual/range {v0 .. v6}, Lio/reactivex/e0$c;->f(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v8, 0x6

    sget-object p2, Lio/reactivex/internal/disposables/e;->a:Lio/reactivex/internal/disposables/e;

    const/4 v8, 0x6

    if-ne p1, p2, :cond_0

    const/4 v8, 0x4

    return-object p1

    :cond_0
    const/4 v8, 0x7

    return-object v7
.end method

.method public i()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public j()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public k(Lt7/o;)Lio/reactivex/e0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Lio/reactivex/e0;",
            ":",
            "Lio/reactivex/disposables/c;",
            ">(",
            "Lt7/o<",
            "Lio/reactivex/k<",
            "Lio/reactivex/k<",
            "Lio/reactivex/c;",
            ">;>;",
            "Lio/reactivex/c;",
            ">;)TS;"
        }
    .end annotation

    .annotation build Ls7/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lio/reactivex/internal/schedulers/l;

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-direct {v0, p1, p0}, Lio/reactivex/internal/schedulers/l;-><init>(Lt7/o;Lio/reactivex/e0;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method
