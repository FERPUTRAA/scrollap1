.class public final Lio/reactivex/android/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "io.reactivex.android"

.field public static final c:Ljava/lang/String; = "release"

.field public static final d:Ljava/lang/String; = ""

.field public static final e:I = -0x1

.field public static final f:Ljava/lang/String; = ""


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method
