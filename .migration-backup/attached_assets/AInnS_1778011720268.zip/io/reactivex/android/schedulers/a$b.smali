.class final Lio/reactivex/android/schedulers/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/android/schedulers/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation


# static fields
.field static final a:Lio/reactivex/e0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Lio/reactivex/android/schedulers/b;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Lio/reactivex/android/schedulers/b;-><init>(Landroid/os/Handler;)V

    const/4 v3, 0x5

    or-int/2addr v4, v3

    sput-object v0, Lio/reactivex/android/schedulers/a$b;->a:Lio/reactivex/e0;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method
