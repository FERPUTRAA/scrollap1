.class final Lio/reactivex/android/schedulers/b;
.super Lio/reactivex/e0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/android/schedulers/b$b;,
        Lio/reactivex/android/schedulers/b$a;
    }
.end annotation


# instance fields
.field private final b:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/os/Handler;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/e0;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/android/schedulers/b;->b:Landroid/os/Handler;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public c()Lio/reactivex/e0$c;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@so~m~  ~@f@~.~i~@s@ ~r4@@~-@u~@lK/~~i~~fltoiS  /ob~ d@@ac   ~~@@o@ @  @M~1t~~by on b@ v~@ @ @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Lio/reactivex/android/schedulers/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/android/schedulers/b;->b:Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, v1}, Lio/reactivex/android/schedulers/b$a;-><init>(Landroid/os/Handler;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method

.method public g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p4, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->Y(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Lio/reactivex/android/schedulers/b$b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/android/schedulers/b;->b:Landroid/os/Handler;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, v1, p1}, Lio/reactivex/android/schedulers/b$b;-><init>(Landroid/os/Handler;Ljava/lang/Runnable;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p1, p0, Lio/reactivex/android/schedulers/b;->b:Landroid/os/Handler;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p4, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1, v2, p2, p3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo p2, "ti=mn u= lul"

    const-string/jumbo p2, "nislu= u= lt"

    const/4 v4, 0x0

    const-string p2, "=tl=ouunl  i"

    const-string/jumbo p2, "unit == null"

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo p2, "nlrn=b  mul"

    const-string/jumbo p2, "un=mnrull  "

    const/4 v4, 0x5

    const-string/jumbo p2, "ln=u uu nr="

    const-string/jumbo p2, "run == null"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw p1
.end method
