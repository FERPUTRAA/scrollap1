.class public final Lio/reactivex/android/schedulers/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/android/schedulers/a$b;
    }
.end annotation


# static fields
.field private static final a:Lio/reactivex/e0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/android/schedulers/a$a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lio/reactivex/android/schedulers/a$a;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/android/plugins/a;->d(Ljava/util/concurrent/Callable;)Lio/reactivex/e0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    sput-object v0, Lio/reactivex/android/schedulers/a;->a:Lio/reactivex/e0;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "nosseNissa.tn"

    const-string/jumbo v1, "oasste Ns.nni"

    const/4 v3, 0x3

    const-string/jumbo v1, "ns.moscatein "

    const-string v1, "No instances."

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw v0
.end method

.method public static a(Landroid/os/Looper;)Lio/reactivex/e0;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@4 ov~@ ~ ~~onb~f@@l.fiS/ ~~ ~ @@/ @ @~t@t@o~r ca@  ~~@~  @ @oo  doiKb~@l1s~@i~ ~bum@~@~y~@-@M~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    new-instance v0, Lio/reactivex/android/schedulers/b;

    const/4 v3, 0x3

    new-instance v1, Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lio/reactivex/android/schedulers/b;-><init>(Landroid/os/Handler;)V

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "el=lmb=lrpu no"

    const-string v0, "=oumlrnple =lo"

    const/4 v3, 0x5

    const-string/jumbo v0, "lllp ru= ouneo"

    const-string/jumbo v0, "looper == null"

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p0
.end method

.method public static b()Lio/reactivex/e0;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lio/reactivex/android/schedulers/a;->a:Lio/reactivex/e0;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {v0}, Lio/reactivex/android/plugins/a;->e(Lio/reactivex/e0;)Lio/reactivex/e0;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method
