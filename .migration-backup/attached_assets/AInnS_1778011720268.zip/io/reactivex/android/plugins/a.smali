.class public final Lio/reactivex/android/plugins/a;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;",
            "Lio/reactivex/e0;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile b:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "Lio/reactivex/e0;",
            "Lio/reactivex/e0;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, ".estcnssinoa "

    const-string v1, " tsnnsi.easco"

    const/4 v3, 0x0

    const-string v1, "Ntomscns ia.e"

    const-string v1, "No instances."

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw v0
.end method

.method static a(Lt7/o;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lt7/o<",
            "TT;TR;>;TT;)TR;"
        }
    .end annotation

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "of~So~t~ ~yi~dt .~  o bK@io cb @@  oo@@M @1@l @@@~ m@i@~@sf~~ ~ovr~bln@~-@@~@ @4  ~a~ @u@~/~~/~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-interface {p0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0}, Lio/reactivex/exceptions/b;->a(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    throw p0
.end method

.method static b(Lt7/o;Ljava/util/concurrent/Callable;)Lio/reactivex/e0;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/o<",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;",
            "Lio/reactivex/e0;",
            ">;",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;)",
            "Lio/reactivex/e0;"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lio/reactivex/android/plugins/a;->a(Lt7/o;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    check-cast p0, Lio/reactivex/e0;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    const-string/jumbo p1, "lertebldd mCburaeunrhlaeSn llu e"

    const-string p1, "ebrmllhd nCStanrruaue udele elll"

    const/4 v1, 0x6

    const-string p1, "aeu beulneetluhllS ardu ldelncrr"

    const-string p1, "Scheduler Callable returned null"

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    throw p0
.end method

.method static c(Ljava/util/concurrent/Callable;)Lio/reactivex/e0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;)",
            "Lio/reactivex/e0;"
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p0, Lio/reactivex/e0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo v0, "rSe dtupCeua hdlaolelulrllbcnree"

    const-string/jumbo v0, "rreeotal b lldluCldr aclhuSneeeu"

    const/4 v2, 0x3

    const-string v0, "ee ruSthqlncll rCaluldenuabde re"

    const-string v0, "Scheduler Callable returned null"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    throw p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0}, Lio/reactivex/exceptions/b;->a(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p0
.end method

.method public static d(Ljava/util/concurrent/Callable;)Lio/reactivex/e0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;)",
            "Lio/reactivex/e0;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lio/reactivex/android/plugins/a;->a:Lt7/o;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0}, Lio/reactivex/android/plugins/a;->c(Ljava/util/concurrent/Callable;)Lio/reactivex/e0;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lio/reactivex/android/plugins/a;->b(Lt7/o;Ljava/util/concurrent/Callable;)Lio/reactivex/e0;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string v0, "==s lerbuucde nsh"

    const-string v0, "hn=clbders l=ue u"

    const/4 v2, 0x2

    const-string v0, "=uemsneclu rlhld="

    const-string/jumbo v0, "scheduler == null"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p0
.end method

.method public static e(Lio/reactivex/e0;)Lio/reactivex/e0;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/android/plugins/a;->b:Lt7/o;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lio/reactivex/android/plugins/a;->a(Lt7/o;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lio/reactivex/e0;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "hrluoedc els= =ul"

    const-string/jumbo v0, "ll=e= uuldeuchrs "

    const/4 v2, 0x7

    const-string v0, "drel blcu h=enusl"

    const-string/jumbo v0, "scheduler == null"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p0
.end method

.method public static f()V
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x0

    move v1, v0

    move v1, v0

    const/4 v2, 0x0

    invoke-static {v0}, Lio/reactivex/android/plugins/a;->g(Lt7/o;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/android/plugins/a;->h(Lt7/o;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public static g(Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/o<",
            "Ljava/util/concurrent/Callable<",
            "Lio/reactivex/e0;",
            ">;",
            "Lio/reactivex/e0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    sput-object p0, Lio/reactivex/android/plugins/a;->a:Lt7/o;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static h(Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/o<",
            "Lio/reactivex/e0;",
            "Lio/reactivex/e0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    sput-object p0, Lio/reactivex/android/plugins/a;->b:Lt7/o;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method
