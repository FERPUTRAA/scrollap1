.class public final Lio/reactivex/exceptions/b;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "c!ssenntos ai"

    const/4 v3, 0x6

    const-string v1, " nsseaNs!noic"

    const-string v1, "No instances!"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    throw v0
.end method

.method public static a(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ @mo~4~/~. o~o@@~ i ot /m~o~d  ~lrib@S -s~a lM~~n@    @K@@@~~~ v~@@uo~@~~f@fy~@tbc@@ @ b@1~i~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    throw p0
.end method

.method public static b(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    instance-of v0, p0, Ljava/lang/VirtualMachineError;

    const/4 v1, 0x5

    move v2, v1

    if-nez v0, :cond_2

    const/4 v2, 0x6

    instance-of v0, p0, Ljava/lang/ThreadDeath;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    instance-of v0, p0, Ljava/lang/LinkageError;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Ljava/lang/LinkageError;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p0, Ljava/lang/ThreadDeath;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p0

    :cond_2
    const/4 v2, 0x2

    check-cast p0, Ljava/lang/VirtualMachineError;

    const/4 v2, 0x7

    const/4 v1, 0x4

    throw p0
.end method
