.class public final Lio/reactivex/exceptions/a;
.super Ljava/lang/RuntimeException;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/exceptions/a$a;,
        Lio/reactivex/exceptions/a$d;,
        Lio/reactivex/exceptions/a$c;,
        Lio/reactivex/exceptions/a$b;
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x29ffcc6947b49592L


# instance fields
.field private cause:Ljava/lang/Throwable;

.field private final exceptions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field private final message:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    check-cast v2, Ljava/lang/Throwable;

    const/4 v4, 0x1

    const/4 v5, 0x2

    instance-of v3, v2, Lio/reactivex/exceptions/a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v2, Lio/reactivex/exceptions/a;

    const/4 v5, 0x4

    invoke-virtual {v2}, Lio/reactivex/exceptions/a;->b()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0, v2}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/NullPointerException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v3, "sss b!nlhlwlwaTuo e"

    const-string/jumbo v3, "oTs!wwhnsbleru  all"

    const/4 v5, 0x6

    const-string v3, "aswm  hwerlla!Tulno"

    const-string v3, "Throwable was null!"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const-string/jumbo v2, "nrumossell arro"

    const-string/jumbo v2, "s rmrwalronselu"

    const/4 v5, 0x1

    const-string/jumbo v2, "noerlburraw ssl"

    const-string v2, "errors was null"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez p1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-object p1, p0, Lio/reactivex/exceptions/a;->exceptions:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo p1, "t rcncue. eiooxrc ousp"

    const-string/jumbo p1, "pcdeoio ecu.rnsro cx t"

    const/4 v5, 0x5

    const-string p1, "eneococp.cxie r  tpurd"

    const-string p1, " exceptions occurred. "

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object p1, p0, Lio/reactivex/exceptions/a;->message:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    move v5, v4

    const-string/jumbo v0, "r trspyeqoeib m"

    const-string/jumbo v0, "s orpbrsty imee"

    const/4 v5, 0x2

    const-string/jumbo v0, "ieso ysp rtrres"

    const-string v0, "errors is empty"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    throw p1
.end method

.method public varargs constructor <init>([Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-array p1, p1, [Ljava/lang/NullPointerException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v1, "tw mlsuexpnsoecuinl"

    const-string v1, "eplustunolwiens  xc"

    const/4 v3, 0x1

    const-string/jumbo v1, "xineospaclel tsnow "

    const-string v1, "exceptions was null"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-object v0, p1, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/exceptions/a;-><init>(Ljava/lang/Iterable;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method private a(Ljava/lang/StringBuilder;Ljava/lang/Throwable;Ljava/lang/String;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " ~@~@bur@ tK~oi~~ c@o~@b@~~b~bl~~o@@ S.~s~ @@4o/yiv o~~@ @~t @ @~ l@@o ~ ~  @~fd@ /i1m~M n~ @f@-"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 p3, 0xa

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    array-length v1, v0

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x3

    move v5, v2

    move v5, v2

    :goto_0
    const/4 v6, 0x1

    if-ge v2, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    aget-object v3, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v4, "tta/ /u"

    const-string v4, "\t\tat "

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz p3, :cond_1

    const/4 v6, 0x7

    const-string p3, "atds/bypu  Cp"

    const-string p3, " dyCtb:ps/ au"

    const/4 v6, 0x4

    const-string p3, "ae:y tbuqCs/d"

    const-string p3, "\tCaused by: "

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string p3, ""

    const-string p3, ""

    const/4 v6, 0x1

    const-string p3, ""

    const-string p3, ""

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {p0, p1, p2, p3}, Lio/reactivex/exceptions/a;->a(Ljava/lang/StringBuilder;Ljava/lang/Throwable;Ljava/lang/String;)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-void
.end method

.method private c(Ljava/lang/Throwable;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ne v1, p1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne p1, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :cond_1
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method private d(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/exceptions/a;->cause:Ljava/lang/Throwable;

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-ne v1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_2

    :cond_0
    :goto_0
    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne p1, v0, :cond_1

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_1

    :cond_1
    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :cond_3
    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method

.method private e(Lio/reactivex/exceptions/a$b;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/16 v1, 0x80

    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/16 v1, 0xa

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    array-length v3, v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x5

    if-ge v4, v3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    aget-object v5, v2, v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo v6, "t/sqt"

    const-string/jumbo v6, "t/ qt"

    const/4 v8, 0x6

    const-string/jumbo v6, "t/tma"

    const-string v6, "\tat "

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v1, p0, Lio/reactivex/exceptions/a;->exceptions:Ljava/util/List;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    const/4 v8, 0x3

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v4, :cond_1

    const/4 v8, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    check-cast v4, Ljava/lang/Throwable;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v5, "xs docspEp ootom iCn"

    const-string/jumbo v5, "t smpsnox c CdpEoioe"

    const/4 v8, 0x0

    const-string v5, "eEsx bonootm i Cpecp"

    const-string v5, "  ComposedException "

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v5, "n/ :"

    const-string v5, ": /n"

    const/4 v8, 0x3

    const-string v5, "/:n "

    const-string v5, " :\n"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const-string v5, "/t"

    const-string v5, "/t"

    const-string v5, "/t"

    const-string v5, "\t"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {p0, v0, v4, v5}, Lio/reactivex/exceptions/a;->a(Ljava/lang/StringBuilder;Ljava/lang/Throwable;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    add-int/2addr v3, v2

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Lio/reactivex/exceptions/a$b;->a(Ljava/lang/Object;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method public b()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/exceptions/a;->exceptions:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/exceptions/a;->exceptions:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public declared-synchronized getCause()Ljava/lang/Throwable;
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v0, p0, Lio/reactivex/exceptions/a;->cause:Ljava/lang/Throwable;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-nez v0, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-instance v0, Lio/reactivex/exceptions/a$a;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v0}, Lio/reactivex/exceptions/a$a;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v1, Ljava/util/HashSet;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v2, p0, Lio/reactivex/exceptions/a;->exceptions:Ljava/util/List;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz v4, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    check-cast v4, Ljava/lang/Throwable;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v5, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p0, v4}, Lio/reactivex/exceptions/a;->c(Ljava/lang/Throwable;)Ljava/util/List;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v6, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    check-cast v6, Ljava/lang/Throwable;

    const/4 v9, 0x2

    invoke-interface {v1, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v7, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v4, Ljava/lang/RuntimeException;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v6, "uuiaonuaot.t.ir oash omcnv  cnDlfgpua r nci elpnpp i eocdpose ."

    const-string v6, "c vmtp o nlo hnaa erpueia riptgc..c donaisD ptucnosu pnli.eo of"

    const/4 v9, 0x2

    const-string v6, "anu.nispDcpdrtoaenl n . gneeoilvuoo s  t cpaoi . iucfaolprc htp"

    const-string v6, "Duplicate found in causal chain so cropping to prevent loop ..."

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v4, v6}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-interface {v1, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_1

    :cond_2
    :try_start_1
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v9, 0x3

    invoke-direct {p0, v3}, Lio/reactivex/exceptions/a;->d(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    iput-object v0, p0, Lio/reactivex/exceptions/a;->cause:Ljava/lang/Throwable;

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v0, p0, Lio/reactivex/exceptions/a;->cause:Ljava/lang/Throwable;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    monitor-exit p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    return-object v0

    :catchall_1
    move-exception v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    monitor-exit p0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    throw v0
.end method

.method public getMessage()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/exceptions/a;->message:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public printStackTrace()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Ljava/lang/System;->err:Ljava/io/PrintStream;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/exceptions/a;->printStackTrace(Ljava/io/PrintStream;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public printStackTrace(Ljava/io/PrintStream;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/exceptions/a$c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lio/reactivex/exceptions/a$c;-><init>(Ljava/io/PrintStream;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, v0}, Lio/reactivex/exceptions/a;->e(Lio/reactivex/exceptions/a$b;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public printStackTrace(Ljava/io/PrintWriter;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/exceptions/a$d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Lio/reactivex/exceptions/a$d;-><init>(Ljava/io/PrintWriter;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lio/reactivex/exceptions/a;->e(Lio/reactivex/exceptions/a$b;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method
