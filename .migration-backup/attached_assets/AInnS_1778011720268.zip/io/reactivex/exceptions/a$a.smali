.class final Lio/reactivex/exceptions/a$a;
.super Ljava/lang/RuntimeException;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/exceptions/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field static final a:Ljava/lang/String; = "Chain of Causes for CompositeException In Order Received =>"

.field private static final serialVersionUID:J = 0x35c7853e403cebd2L


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getMessage()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b s@ ~~i~ ~~b~t1@io@ o ~ad ~@t  @~s@~~fu ~~rb l@~ @v@c@ ~@@K-~@i/~yn@@  o@S~o  @M@@m4f~/~@~~l. o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string v0, "C em p icd Cms ihrueORI>rot f=riotenoEdxvCcanoepes nefsieao"

    const-string/jumbo v0, "oCsr C> RdeefEnInnstre of os eiOCh=ceiaaxi vripmoeeocp sdtu"

    const/4 v2, 0x2

    const-string v0, "enimo=R>vpee fotsit dpofaEioxs C n rnucdoosi Ihae crCe COer"

    const-string v0, "Chain of Causes for CompositeException In Order Received =>"

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    return-object v0
.end method
