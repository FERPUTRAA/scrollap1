.class public interface abstract Lio/reactivex/g;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lio/reactivex/e;)Lio/reactivex/e;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation
.end method
