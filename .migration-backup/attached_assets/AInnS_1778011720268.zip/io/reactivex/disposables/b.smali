.class public final Lio/reactivex/disposables/b;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/disposables/c;
.implements Lio/reactivex/internal/disposables/c;


# instance fields
.field a:Lio/reactivex/internal/util/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/util/r<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field volatile b:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "ses uris celorlun"

    const-string/jumbo v0, "resources is null"

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lio/reactivex/internal/util/r;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0}, Lio/reactivex/internal/util/r;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "p  muaelsenbomslD siisi"

    const-string v1, "eDsb lpsisio u ilaetnsm"

    const/4 v3, 0x4

    const-string/jumbo v1, "ilspoDeilbonmslt  si au"

    const-string v1, "Disposable item is null"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lio/reactivex/internal/util/r;->a(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public varargs constructor <init>([Lio/reactivex/disposables/c;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v0, " scmeb ilserrluuo"

    const-string/jumbo v0, "leemsuo s cnrriul"

    const/4 v5, 0x0

    const-string v0, " lueseuiossnurlcr"

    const-string/jumbo v0, "resources is null"

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v0, Lio/reactivex/internal/util/r;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    array-length v1, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Lio/reactivex/internal/util/r;-><init>(I)V

    const/4 v5, 0x3

    iput-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    array-length v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ge v1, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    aget-object v2, p1, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const-string v3, "e Dloiopb lnmstlsi apeu"

    const-string/jumbo v3, "s Diosu io mpelailenblt"

    const-string/jumbo v3, "itnmll eqasupDoel is sb"

    const-string v3, "Disposable item is null"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v2, v3}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v3, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v3, v2}, Lio/reactivex/internal/util/r;->a(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t~s~@~ b4~al @   m~@~    Kl@~n@~@~s@~oSv@ ~@@iio- @~f~~@i@~@~b~@b1M o/@rufo@ @.~c~ /   ~d~o@~oty"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public b(Lio/reactivex/disposables/c;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1
.end method

.method public c(Lio/reactivex/disposables/c;)Z
    .locals 3

    const-string/jumbo v0, "llbmsdni "

    const-string v0, " idl bnsl"

    const/4 v2, 0x3

    const-string/jumbo v0, "l  iodlsu"

    const-string v0, "d is null"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/internal/util/r;

    const/4 v2, 0x5

    invoke-direct {v0}, Lio/reactivex/internal/util/r;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/r;->a(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x6

    return p1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p1

    :cond_2
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    return p1
.end method

.method public d(Lio/reactivex/disposables/c;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "l msub niaeDts soullibi"

    const-string/jumbo v0, "laieebu sl tols nimuDis"

    const/4 v3, 0x6

    const-string/jumbo v0, "sse iaupDstln m lbleiio"

    const-string v0, "Disposable item is null"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v2, 0x3

    move v3, v2

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_1
    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/r;->e(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1

    :cond_3
    :goto_0
    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    return v1

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw p1
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x7

    and-int/2addr v3, v2

    iput-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v2, v1

    move v2, v1

    iput-object v1, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lio/reactivex/disposables/b;->h(Lio/reactivex/internal/util/r;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0
.end method

.method public varargs f([Lio/reactivex/disposables/c;)Z
    .locals 8

    const/4 v7, 0x6

    const-string/jumbo v0, "sdpl sipun"

    const-string/jumbo v0, "nl ussdpil"

    const/4 v7, 0x6

    const-string v0, "ds is null"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-nez v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x1

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v7, 0x2

    if-nez v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x0

    move v7, v6

    if-nez v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v0, Lio/reactivex/internal/util/r;

    const/4 v7, 0x0

    const/4 v6, 0x7

    array-length v3, p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/2addr v3, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v0, v3}, Lio/reactivex/internal/util/r;-><init>(I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    array-length v3, p1

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-ge v1, v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    aget-object v4, p1, v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo v5, "l  sqildq"

    const-string/jumbo v5, "usli  ldq"

    const/4 v7, 0x2

    const-string/jumbo v5, "iussn dll"

    const-string v5, "d is null"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v4, v5}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v4}, Lio/reactivex/internal/util/r;->a(Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    monitor-exit p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    return v2

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    monitor-exit p0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    throw p1

    :cond_3
    :goto_1
    const/4 v7, 0x5

    array-length v0, p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v2, v0, :cond_4

    const/4 v7, 0x1

    aget-object v3, p1, v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v3}, Lio/reactivex/disposables/c;->e()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_2

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    return v1
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lio/reactivex/disposables/b;->h(Lio/reactivex/internal/util/r;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    throw v0
.end method

.method h(Lio/reactivex/internal/util/r;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/util/r<",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez p1, :cond_0

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1}, Lio/reactivex/internal/util/r;->b()[Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    array-length v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    move v3, v1

    move v3, v1

    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ge v3, v0, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    aget-object v4, p1, v3

    const/4 v6, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    instance-of v5, v4, Lio/reactivex/disposables/c;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v5, :cond_2

    :try_start_0
    const/4 v7, 0x2

    check-cast v4, Lio/reactivex/disposables/c;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface {v4}, Lio/reactivex/disposables/c;->e()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_1

    :catchall_0
    move-exception v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v4}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    if-nez v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v2, Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v2, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne p1, v0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast p1, Ljava/lang/Throwable;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    throw p1

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance p1, Lio/reactivex/exceptions/a;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {p1, v2}, Lio/reactivex/exceptions/a;-><init>(Ljava/lang/Iterable;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    throw p1

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void
.end method

.method public i()I
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/disposables/b;->b:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/disposables/b;->a:Lio/reactivex/internal/util/r;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/util/r;->g()I

    move-result v1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v1

    :catchall_0
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw v0
.end method
