.class public interface abstract Lio/reactivex/disposables/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Z
.end method

.method public abstract e()V
.end method
