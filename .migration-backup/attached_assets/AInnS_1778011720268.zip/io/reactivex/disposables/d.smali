.class public final Lio/reactivex/disposables/d;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "sssastn nceNo"

    const-string v1, "cNstiaensons "

    const-string v1, " snmn!isetocN"

    const-string v1, "No instances!"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw v0
.end method

.method public static a()Lio/reactivex/disposables/c;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " b~lod/ ao~.~i  @~  ~~-ro@~@y s @@~~o@@~/@@itb4b@~u~@S~o~ @M i K~f  v~t@@@om n~c l~~@1 ~ @f@o~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/internal/disposables/e;->a:Lio/reactivex/internal/disposables/e;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public static b()Lio/reactivex/disposables/c;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lio/reactivex/internal/functions/a;->b:Ljava/lang/Runnable;

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/disposables/d;->f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public static c(Lt7/a;)Lio/reactivex/disposables/c;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string/jumbo v0, "sul nb ruin"

    const-string/jumbo v0, "run is null"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v1, 0x0

    move v2, v1

    new-instance v0, Lio/reactivex/disposables/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lio/reactivex/disposables/a;-><init>(Lt7/a;)V

    const/4 v2, 0x3

    return-object v0
.end method

.method public static d(Ljava/util/concurrent/Future;)Lio/reactivex/disposables/c;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "*>;)",
            "Lio/reactivex/disposables/c;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "ulumnfri lus t"

    const/4 v2, 0x2

    const-string v0, " ilufnusuerut "

    const-string v0, "future is null"

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {p0, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lio/reactivex/disposables/d;->e(Ljava/util/concurrent/Future;Z)Lio/reactivex/disposables/c;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public static e(Ljava/util/concurrent/Future;Z)Lio/reactivex/disposables/c;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "*>;Z)",
            "Lio/reactivex/disposables/c;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string v0, " ruloflnue isu"

    const/4 v2, 0x7

    const-string v0, "future is null"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/disposables/e;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lio/reactivex/disposables/e;-><init>(Ljava/util/concurrent/Future;Z)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public static f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "u br ilpnul"

    const-string/jumbo v0, "ulinlb  urn"

    const/4 v2, 0x1

    const-string/jumbo v0, "u nsrll qni"

    const-string/jumbo v0, "run is null"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lio/reactivex/disposables/g;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lio/reactivex/disposables/g;-><init>(Ljava/lang/Runnable;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public static g(Lja/d;)Lio/reactivex/disposables/c;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "snsulcssnp tuobiri i"

    const-string/jumbo v0, "tssnicuunpboiil  urs"

    const/4 v2, 0x1

    const-string/jumbo v0, "unbmntsc ls usirliop"

    const-string/jumbo v0, "subscription is null"

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/disposables/i;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-direct {v0, p0}, Lio/reactivex/disposables/i;-><init>(Lja/d;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method
