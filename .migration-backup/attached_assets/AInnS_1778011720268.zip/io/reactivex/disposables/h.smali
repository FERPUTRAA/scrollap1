.class public final Lio/reactivex/disposables/h;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/disposables/c;


# instance fields
.field final a:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sfi@@.@~f/~~~d@im~  a~~c1 K@~@b -li @oy @v s@~~~  @ @rM~~  b~~@@~ ~o@ou~t@l~o @~n~to@   @@4ob/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public b()Lio/reactivex/disposables/c;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {}, Lio/reactivex/disposables/d;->a()Lio/reactivex/disposables/c;

    move-result-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public c(Lio/reactivex/disposables/c;)Z
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->d(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p1
.end method

.method public d(Lio/reactivex/disposables/c;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->g(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return p1
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/disposables/h;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
