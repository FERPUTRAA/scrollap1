.class public final synthetic Ll0/d;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ll0/e;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Landroid/annotation/SuppressLint;
            value = {
                "ArrayReturn"
            }
        .end annotation

        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x7

    const-string v0, " ms@o@~-~~@@S~~u~K@~t  a~@@c@~ r b@o~vn ~1~  @o/i~@/@  @so b~@i ~@ b~foMt@@@@ f4~l~.~d @~ i~~yol"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    const-string/jumbo p0, "lqs"

    const-string/jumbo p0, "slq"

    const/4 v1, 0x1

    const-string/jumbo p0, "sql"

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    throw p0
.end method

.method public static b(Ll0/e;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 p0, 0x0

    move v1, p0

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return p0
.end method
