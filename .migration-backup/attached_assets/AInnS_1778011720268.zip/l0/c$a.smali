.class public final Ll0/c$a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation build Landroidx/annotation/w0;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final a:Ll0/c$a;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Ll0/c$a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Ll0/c$a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Ll0/c$a;->a:Ll0/c$a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static final a(Landroid/os/CancellationSignal;)V
    .locals 3
    .param p0    # Landroid/os/CancellationSignal;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x3

    const-string v1, " ~s~~~~-~@ oyfr s~~@ bu@K .n@ ol@~ b@ @iSf@ @olM~c ~ @4~@a/b1o@o~@m ~ /~it~~@~@~ @~i~t @@@d o @v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-string/jumbo v0, "lalmenSiotliacnnsg"

    const-string v0, "alsnlninSgacalitoe"

    const-string/jumbo v0, "liagotoallcciSnean"

    const-string v0, "cancellationSignal"

    const/4 v1, 0x5

    const/4 v1, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/os/CancellationSignal;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static final b()Landroid/os/CancellationSignal;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Landroid/os/CancellationSignal;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Landroid/os/CancellationSignal;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public static final c(Ljava/io/File;)Z
    .locals 3
    .param p0    # Ljava/io/File;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const-string/jumbo v0, "iefl"

    const-string/jumbo v0, "lefi"

    const/4 v2, 0x0

    const-string v0, "fiel"

    const-string v0, "file"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    invoke-static {p0}, Landroid/database/sqlite/SQLiteDatabase;->deleteDatabase(Ljava/io/File;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static final d(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 3
    .param p0    # Landroid/database/sqlite/SQLiteDatabase;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x6

    const-string v0, "emsaabbiaLsDte"

    const-string v0, "bsemeDaastiLQa"

    const/4 v2, 0x1

    const-string v0, "aQbtaeuLeDsast"

    const-string/jumbo v0, "sQLiteDatabase"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->disableWriteAheadLogging()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public static final e(Landroid/database/sqlite/SQLiteDatabase;)Z
    .locals 3
    .param p0    # Landroid/database/sqlite/SQLiteDatabase;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "tLieetapobaDQs"

    const-string v0, "QatboaiseDsLte"

    const-string/jumbo v0, "ttDQeibsqaaeaL"

    const-string/jumbo v0, "sQLiteDatabase"

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteDatabase;->isWriteAheadLoggingEnabled()Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0
.end method

.method public static final f(Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;)Landroid/database/Cursor;
    .locals 8
    .param p0    # Landroid/database/sqlite/SQLiteDatabase;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p4    # Landroid/os/CancellationSignal;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Landroid/database/sqlite/SQLiteDatabase$CursorFactory;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v0, "bisestDLQaaeas"

    const-string/jumbo v0, "sQLiteDatabase"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v0, "qsl"

    const-string/jumbo v0, "lsq"

    const/4 v7, 0x7

    const-string/jumbo v0, "lqs"

    const-string/jumbo v0, "sql"

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    move v7, v6

    const-string/jumbo v0, "lsrmtsceogbAn"

    const-string v0, "eAgiobrsntscl"

    const/4 v7, 0x2

    const-string/jumbo v0, "sgleoiteoAcns"

    const-string/jumbo v0, "selectionArgs"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v0, "aniaeblagcilonlcnS"

    const-string v0, "aloinauenciancgSll"

    const-string v0, "ccgnlouaaSelntniil"

    const-string v0, "cancellationSignal"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p4, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v0, "stcrFoypocrru"

    const/4 v7, 0x5

    const-string v0, "croycrapoFurs"

    const-string v0, "cursorFactory"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p5, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p5

    move-object v1, p5

    move-object v1, p5

    move-object v1, p5

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual/range {v0 .. v5}, Landroid/database/sqlite/SQLiteDatabase;->rawQueryWithFactory(Landroid/database/sqlite/SQLiteDatabase$CursorFactory;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string p1, "Sob Qunaq e iDayn20grQetsaLi.tu/    arw6eql)/2   ta  Wan"

    const-string p1, " e uy  rqseSonw t .Ltis a 2 t2ng/Db Qau ai6n aWe/a0rQ)la"

    const/4 v7, 0x2

    const-string p1, "ebsty. ou6Qwar0siWnasQ/ tt   ann)uli eD gaSa  L ie/  a2r"

    const-string/jumbo p1, "sQLiteDatabase.rawQueryW\u2026ationSignal\n            )"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-object p0
.end method

.method public static final g(Landroid/database/sqlite/SQLiteDatabase;Z)V
    .locals 3
    .param p0    # Landroid/database/sqlite/SQLiteDatabase;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "eLsmsaasQtatbD"

    const-string v0, "eDsassaQetaLtb"

    const/4 v2, 0x7

    const-string/jumbo v0, "iataosabQeLDet"

    const-string/jumbo v0, "sQLiteDatabase"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/database/sqlite/SQLiteDatabase;->setForeignKeyConstraintsEnabled(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static final h(Landroid/database/sqlite/SQLiteOpenHelper;Z)V
    .locals 3
    .param p0    # Landroid/database/sqlite/SQLiteOpenHelper;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const-string/jumbo v0, "stpmebieernHLepO"

    const-string/jumbo v0, "lHLmeeeerOpitnsp"

    const/4 v2, 0x0

    const-string v0, "OstpenuLepQHlree"

    const-string/jumbo v0, "sQLiteOpenHelper"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Landroid/database/sqlite/SQLiteOpenHelper;->setWriteAheadLoggingEnabled(Z)V

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method
