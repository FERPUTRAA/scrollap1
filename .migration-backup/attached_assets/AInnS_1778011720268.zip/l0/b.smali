.class public final Ll0/b;
.super Ljava/lang/Object;

# interfaces
.implements Ll0/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ll0/b$a;
    }
.end annotation


# static fields
.field public static final c:Ll0/b$a;
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:[Ljava/lang/Object;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ll0/b$a;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    shr-int/2addr v3, v1

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-direct {v0, v1}, Ll0/b$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    sput-object v0, Ll0/b;->c:Ll0/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "sesuq"

    const-string/jumbo v0, "yuseq"

    const/4 v2, 0x3

    const-string/jumbo v0, "uryme"

    const-string/jumbo v0, "query"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Ll0/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo v0, "qrumo"

    const-string/jumbo v0, "yqrmu"

    const/4 v2, 0x3

    const-string v0, "breyq"

    const-string/jumbo v0, "query"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Ll0/b;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p2, p0, Ll0/b;->b:[Ljava/lang/Object;

    const/4 v2, 0x4

    return-void
.end method

.method public static final d(Ll0/g;[Ljava/lang/Object;)V
    .locals 3
    .param p0    # Ll0/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Ll0/b;->c:Ll0/b$a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1}, Ll0/b$a;->b(Ll0/g;[Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Ll0/b;->b:[Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    array-length v0, v0

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public b()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object v0, p0, Ll0/b;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public c(Ll0/g;)V
    .locals 4
    .param p1    # Ll0/g;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x4

    const-string/jumbo v0, "ttaoesuem"

    const-string/jumbo v0, "tmnsoteae"

    const/4 v3, 0x5

    const-string v0, "eamnettps"

    const-string/jumbo v0, "statement"

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Ll0/b;->c:Ll0/b$a;

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Ll0/b;->b:[Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Ll0/b$a;->b(Ll0/g;[Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method
