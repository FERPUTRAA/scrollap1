.class public final Ll0/i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ll0/i$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSupportSQLiteQueryBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SupportSQLiteQueryBuilder.kt\nandroidx/sqlite/db/SupportSQLiteQueryBuilder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,186:1\n1#2:187\n*E\n"
.end annotation


# static fields
.field public static final j:Ll0/i$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final k:Ljava/util/regex/Pattern;


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field

.field private b:Z

.field private c:[Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private e:[Ljava/lang/Object;
    .annotation build Lia/e;
    .end annotation
.end field

.field private f:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private g:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private h:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private i:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    new-instance v0, Ll0/i$a;

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x7

    and-int/2addr v2, v1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ll0/i$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    sput-object v0, Ll0/i;->j:Ll0/i$a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "d/s+//*s+/**//)ds/,s//s/?*s/"

    const-string/jumbo v0, "s/s?/*//+//+ds**/s///)*//,sd"

    const/4 v3, 0x0

    const-string v0, "+/)ms/////sd/**+?(s//*/s//d,"

    const-string v0, "\\s*\\d+\\s*(,\\s*\\d+\\s*)?"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object v0, Ll0/i;->k:Ljava/util/regex/Pattern;

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Ll0/i;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Ll0/i;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method private final a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    if-eqz p3, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p3}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private final b(Ljava/lang/StringBuilder;[Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    array-length v0, p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v1, v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    aget-object v2, p2, v1

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-lez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, ", "

    const/4 v5, 0x4

    const-string v3, ", "

    const-string v3, ", "

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/16 p2, 0x20

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void
.end method

.method public static final c(Ljava/lang/String;)Ll0/i;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Ll0/i;->j:Ll0/i$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ll0/i$a;->a(Ljava/lang/String;)Ll0/i;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method


# virtual methods
.method public final d([Ljava/lang/String;)Ll0/i;
    .locals 2
    .param p1    # [Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    iput-object p1, p0, Ll0/i;->c:[Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public final e()Ll0/h;
    .locals 7
    .annotation build Lia/d;
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Ll0/i;->f:Ljava/lang/String;

    const/4 v5, 0x6

    move v6, v5

    const/4 v1, 0x0

    move v6, v1

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x5

    move v0, v2

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Ll0/i;->g:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    :goto_3
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_4

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_5

    :cond_5
    :goto_4
    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_5
    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v0, :cond_b

    const/4 v6, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/16 v3, 0x78

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "SELECT "

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    iget-boolean v3, p0, Ll0/i;->b:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v3, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v3, "CTNDoT Sm"

    const-string v3, "STCmN DIT"

    const/4 v6, 0x5

    const-string v3, "NSTCDb TI"

    const-string v3, "DISTINCT "

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v3, p0, Ll0/i;->c:[Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v3, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x2

    array-length v4, v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v4, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    move v4, v2

    move v4, v2

    const/4 v6, 0x4

    move v4, v2

    move v4, v2

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_6

    :cond_7
    const/4 v5, 0x6

    move v6, v5

    move v4, v1

    move v4, v1

    :goto_6
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v4, :cond_9

    :cond_8
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    move v1, v2

    move v1, v2

    :cond_9
    const/4 v6, 0x3

    if-nez v1, :cond_a

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v3}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {p0, v0, v3}, Ll0/i;->b(Ljava/lang/StringBuilder;[Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_7

    :cond_a
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v1, " *"

    const-string v1, " *"

    const/4 v6, 0x3

    const-string v1, "* "

    const-string v1, "* "

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_7
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v1, "FuMOR"

    const-string v1, "OMFRo"

    const/4 v6, 0x2

    const-string v1, "MFpO "

    const-string v1, "FROM "

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Ll0/i;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v1, " qRbHWE"

    const-string v1, "WREH b "

    const/4 v6, 0x1

    const-string v1, " EsWE H"

    const-string v1, " WHERE "

    const/4 v6, 0x7

    iget-object v2, p0, Ll0/i;->d:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p0, v0, v1, v2}, Ll0/i;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v1, "  um BUOGR"

    const-string v1, " G BRYuOU "

    const/4 v6, 0x2

    const-string v1, " UPOoYBRG "

    const-string v1, " GROUP BY "

    const/4 v6, 0x7

    iget-object v2, p0, Ll0/i;->f:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0, v0, v1, v2}, Ll0/i;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const-string v1, "H  GIVAp"

    const/4 v6, 0x5

    const-string v1, "AI  NbHG"

    const-string v1, " HAVING "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Ll0/i;->g:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {p0, v0, v1, v2}, Ll0/i;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v1, "RqRBDEu Y "

    const-string v1, "BD REYROq "

    const/4 v6, 0x7

    const-string v1, " RBR DYpOE"

    const-string v1, " ORDER BY "

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v2, p0, Ll0/i;->h:Ljava/lang/String;

    const/4 v6, 0x7

    invoke-direct {p0, v0, v1, v2}, Ll0/i;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const-string v1, " qLIIM "

    const-string v1, " MsILI "

    const/4 v6, 0x7

    const-string v1, " LIMIT "

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Ll0/i;->i:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {p0, v0, v1, v2}, Ll0/i;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string v1, "BatmynlA))/oeict2riucro6pt)t(S.radSi0.r2gteicdiinuguln("

    const/4 v6, 0x5

    const-string/jumbo v1, "lrsttbo/2unyi(taS2n(Bloin.6.teciAcrridut)c0guiid))pegSa"

    const-string v1, "StringBuilder(capacity).\u2026builderAction).toString()"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v1, Ll0/b;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Ll0/i;->e:[Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-direct {v1, v0, v2}, Ll0/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object v1

    :cond_b
    const/4 v6, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v1, "mo mwiugce gel tprpc usseNliedIVaBnnyrhaeyou  oaGera stu  AsH"

    const-string v1, "ehuuo rca ygmsaresoaV uolt i  enlHtGplBnes gIceida p AruNyswe"

    const/4 v6, 0x2

    const-string/jumbo v1, "peeHortVrgseBeaymo l Aoaets dgusc uacraGnNs ln  i ueipnIlwyuh"

    const-string v1, "HAVING clauses are only permitted when using a groupBy clause"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    throw v0
.end method

.method public final f()Ll0/i;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Ll0/i;->b:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public final g(Ljava/lang/String;)Ll0/i;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Ll0/i;->f:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public final h(Ljava/lang/String;)Ll0/i;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Ll0/i;->g:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public final i(Ljava/lang/String;)Ll0/i;
    .locals 6
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v0, "limit"

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v0, Ll0/i;->k:Ljava/util/regex/Pattern;

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x2

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    move v1, v3

    move v1, v3

    const/4 v5, 0x6

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v1, :cond_2

    const/4 v4, 0x4

    move v5, v4

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    move v2, v3

    move v2, v3

    const/4 v5, 0x4

    move v2, v3

    move v2, v3

    :cond_2
    :goto_1
    const/4 v4, 0x2

    move v5, v4

    if-eqz v2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object p1, p0, Ll0/i;->i:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    return-object p0

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, "cieaabMvTsdu IlLsb nI:"

    const-string/jumbo v1, "s TnMbvadc lIsLia:iIue"

    const/4 v5, 0x7

    const-string v1, " aLsusuaIdllIniMi cveT"

    const-string/jumbo v1, "invalid LIMIT clauses:"

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    throw v0
.end method

.method public final j(Ljava/lang/String;)Ll0/i;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Ll0/i;->h:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public final k(Ljava/lang/String;[Ljava/lang/Object;)Ll0/i;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x2

    iput-object p1, p0, Ll0/i;->d:Ljava/lang/String;

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Ll0/i;->e:[Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method
