.class public final Ll0/f$b$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/f$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ll0/f$b$b;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;)Ll0/f$b$a;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string/jumbo v0, "xnstcts"

    const-string/jumbo v0, "tcsxtne"

    const/4 v2, 0x5

    const-string/jumbo v0, "tonmetc"

    const-string v0, "context"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Ll0/f$b$a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Ll0/f$b$a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method
