.class public Ll0/f$b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/f$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/content/Context;
    .annotation build Lia/d;
    .end annotation
.end field

.field private b:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private c:Ll0/f$a;
    .annotation build Lia/e;
    .end annotation
.end field

.field private d:Z

.field private e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "cnstosx"

    const-string v0, "cosxetn"

    const-string/jumbo v0, "ttomnxe"

    const-string v0, "context"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Ll0/f$b$a;->a:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a(Z)Ll0/f$b$a;
    .locals 2
    .annotation build Lia/d;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l@i~o1to@/~@ M -@a@@~ i l @s@@ nbi~~oS@@b@y~~~ ~@~~uf~d @o~ /@mo~@ ~4.fK@@~~@b v@c ~t~~ o~ ro ~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iput-boolean p1, p0, Ll0/f$b$a;->e:Z

    const/4 v1, 0x6

    return-object p0
.end method

.method public b()Ll0/f$b;
    .locals 9
    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v3, p0, Ll0/f$b$a;->c:Ll0/f$a;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v3, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-boolean v0, p0, Ll0/f$b$a;->d:Z

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v0, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v0, p0, Ll0/f$b$a;->b:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v0, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    move v0, v2

    move v0, v2

    const/4 v8, 0x3

    move v0, v2

    move v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v0, :cond_2

    const/4 v7, 0x3

    goto :goto_2

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    move v1, v2

    move v1, v2

    const/4 v8, 0x7

    move v1, v2

    move v1, v2

    :cond_3
    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v6, Ll0/f$b;

    const/4 v8, 0x4

    iget-object v1, p0, Ll0/f$b$a;->a:Landroid/content/Context;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v2, p0, Ll0/f$b$a;->b:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x1

    iget-boolean v4, p0, Ll0/f$b$a;->d:Z

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-boolean v5, p0, Ll0/f$b$a;->e:Z

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v5}, Ll0/f$b;-><init>(Landroid/content/Context;Ljava/lang/String;Ll0/f$a;ZZ)V

    return-object v6

    :cond_4
    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const-string v1, "a dsybr Mscopnatelsueuafi i ug tkatndhooca tanblrb h ttmeousneotaenairs m .eat o- u t c"

    const-string v1, "hssmao -ktnhteea aarm  uuoadanctba eotiuM acnt npetyoo.sbnf il las r sortidguc tneut e "

    const/4 v8, 0x5

    const-string/jumbo v1, "s utMouteuhinrdrsermtncientloitshesuancaeeb-ostoacpd  aaootnlu fyu a   ngn . tab t   ka"

    const-string v1, "Must set a non-null database name to a configuration that uses the no backup directory."

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    throw v0

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const-string v1, "atc  glpMs etst hnfabuekr oitetlrt ncoci.oaaucea"

    const-string v1, "Must set a callback to create the configuration."

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    throw v0
.end method

.method public c(Ll0/f$a;)Ll0/f$b$a;
    .locals 3
    .param p1    # Ll0/f$a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "llckocaa"

    const/4 v2, 0x5

    const-string/jumbo v0, "qaabcllk"

    const-string v0, "callback"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Ll0/f$b$a;->c:Ll0/f$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public d(Ljava/lang/String;)Ll0/f$b$a;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Ll0/f$b$a;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public e(Z)Ll0/f$b$a;
    .locals 2
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-boolean p1, p0, Ll0/f$b$a;->d:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method
