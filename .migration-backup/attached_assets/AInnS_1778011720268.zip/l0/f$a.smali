.class public abstract Ll0/f$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ll0/f$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSupportSQLiteOpenHelper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SupportSQLiteOpenHelper.kt\nandroidx/sqlite/db/SupportSQLiteOpenHelper$Callback\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Strings.kt\nkotlin/text/StringsKt__StringsKt\n*L\n1#1,425:1\n1#2:426\n1851#3,2:427\n107#4:429\n79#4,22:430\n*S KotlinDebug\n*F\n+ 1 SupportSQLiteOpenHelper.kt\nandroidx/sqlite/db/SupportSQLiteOpenHelper$Callback\n*L\n243#1:427,2\n251#1:429\n251#1:430,22\n*E\n"
.end annotation


# static fields
.field public static final b:Ll0/f$a$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:Ljava/lang/String; = "SupportSQLite"
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field public final a:I
    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ll0/f$a$a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ll0/f$a$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    sput-object v0, Ll0/f$a;->b:Ll0/f$a$a;

    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Ll0/f$a;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method private final a(Ljava/lang/String;)V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@ sK@~~oi~~uf@ t~i~~~@o@ i @ tr~o oS@nm/.  ~~   @/f~bo@@~@@@c  @~ds~@Ml-@l~ ~~@~y~~1 va 4b @b@o~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "ersm:ymo"

    const-string/jumbo v0, "m:sryome"

    const/4 v8, 0x2

    const-string/jumbo v0, "ryemoom:"

    const-string v0, ":memory:"

    const/4 v8, 0x6

    const/4 v1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p1, v0, v1}, Lkotlin/text/v;->K1(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-nez v0, :cond_8

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    sub-int/2addr v0, v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    const/4 v8, 0x6

    move v3, v2

    move v3, v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    move v4, v3

    move v4, v3

    const/4 v8, 0x5

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-gt v3, v0, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-nez v4, :cond_0

    const/4 v8, 0x4

    move v5, v3

    const/4 v8, 0x2

    goto :goto_1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    move v5, v0

    move v5, v0

    const/4 v8, 0x7

    move v5, v0

    move v5, v0

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {p1, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/16 v6, 0x20

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v5, v6}, Lkotlin/jvm/internal/l0;->t(II)I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-gtz v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    move v5, v1

    move v5, v1

    const/4 v8, 0x2

    move v5, v1

    move v5, v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_2

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v5, v2

    move v5, v2

    const/4 v8, 0x6

    move v5, v2

    move v5, v2

    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-nez v4, :cond_3

    const/4 v8, 0x6

    if-nez v5, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    move v4, v1

    move v4, v1

    const/4 v8, 0x2

    move v4, v1

    move v4, v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto :goto_0

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-nez v5, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_3

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_5
    :goto_3
    const/4 v8, 0x0

    add-int/2addr v0, v1

    const/4 v7, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {p1, v3, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-nez v0, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto :goto_4

    :cond_6
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v7, 0x2

    move v8, v7

    if-eqz v1, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_5

    :cond_7
    const/4 v8, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const-string v1, "etin bttagelfmhdlb e:edeiasa"

    const-string v1, "eetml daseftbdeltani :gehai "

    const/4 v8, 0x3

    const-string/jumbo v1, "inaastublhi  det:eefelad  et"

    const-string v1, "deleting the database file: "

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v1, "rieuttopQppSo"

    const-string/jumbo v1, "uoptoreQSStpi"

    const/4 v8, 0x2

    const-string/jumbo v1, "itLSteouqpprQ"

    const-string v1, "SupportSQLite"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance v0, Ljava/io/File;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v0}, Ll0/c$a;->c(Ljava/io/File;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_5

    :catch_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v0, "fdsdielae:ee tl"

    const-string v0, "delete failed: "

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v1, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_8
    :goto_5
    const/4 v7, 0x2

    const/4 v8, 0x5

    return-void
.end method


# virtual methods
.method public b(Ll0/e;)V
    .locals 3
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "db"

    const-string v0, "bd"

    const/4 v2, 0x7

    const-string v0, "bd"

    const-string v0, "db"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public c(Ll0/e;)V
    .locals 5
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v0, "nsbmdope"

    const-string v0, ".dsopben"

    const/4 v4, 0x0

    const-string/jumbo v0, "s.ecopdo"

    const-string/jumbo v0, "p.second"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, "db"

    const-string v1, "bd"

    const/4 v4, 0x7

    const-string v1, "bd"

    const-string v1, "db"

    const/4 v4, 0x2

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v2, "dstirbeubrCte o ep snpiytdn beaaraotr:q loo"

    const-string v2, "Corruption reported by sqlite on database: "

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "puh.u"

    const-string/jumbo v2, "tuph."

    const/4 v4, 0x0

    const-string v2, "ahpp."

    const-string v2, ".path"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "SeipurppotSQt"

    const/4 v4, 0x4

    const-string/jumbo v2, "uLotSiSeqptQp"

    const-string v2, "SupportSQLite"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p1}, Ll0/e;->isOpen()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ll0/e;->getPath()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Ll0/f$a;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p1}, Ll0/e;->u()Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_1

    :catch_0
    :goto_0
    :try_start_1
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_3

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v1, Landroid/util/Pair;

    const/4 v3, 0x2

    move v4, v3

    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-direct {p0, v1}, Ll0/f$a;->a(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    goto :goto_2

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p1}, Ll0/e;->getPath()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Ll0/f$a;->a(Ljava/lang/String;)V

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    throw v2

    :catch_1
    :goto_3
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    check-cast v1, Landroid/util/Pair;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0, v1}, Ll0/f$a;->a(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_4

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p1}, Ll0/e;->getPath()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Ll0/f$a;->a(Ljava/lang/String;)V

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public abstract d(Ll0/e;)V
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method

.method public e(Ll0/e;II)V
    .locals 4
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, "db"

    const-string v0, "db"

    const/4 v3, 0x4

    const-string v0, "db"

    const-string v0, "db"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    move v3, v2

    new-instance p1, Landroid/database/sqlite/SQLiteException;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "n swnearooim/v dr /s  qrteasgnebatdfaCa"

    const-string v1, " vaadertqdooeisanfrt oags/bmrnneC w/a  "

    const/4 v3, 0x1

    const-string v1, "foemn weaar /iab arrnamsdontdves do /gC"

    const-string v1, "Can\'t downgrade database from version "

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo p2, "ot  "

    const-string/jumbo p2, "t  o"

    const-string p2, "  to"

    const-string p2, " to "

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Landroid/database/sqlite/SQLiteException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p1
.end method

.method public f(Ll0/e;)V
    .locals 3
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "db"

    const-string v0, "bd"

    const/4 v2, 0x2

    const-string v0, "bd"

    const-string v0, "db"

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public abstract g(Ll0/e;II)V
    .param p1    # Ll0/e;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method
