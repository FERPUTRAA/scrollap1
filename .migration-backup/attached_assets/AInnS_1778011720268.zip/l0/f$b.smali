.class public final Ll0/f$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ll0/f$b$a;,
        Ll0/f$b$b;
    }
.end annotation


# static fields
.field public static final f:Ll0/f$b$b;
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field public final a:Landroid/content/Context;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final b:Ljava/lang/String;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final c:Ll0/f$a;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final d:Z
    .annotation build Lh8/e;
    .end annotation
.end field

.field public final e:Z
    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ll0/f$b$b;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ll0/f$b$b;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Ll0/f$b;->f:Ll0/f$b$b;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ll0/f$a;ZZ)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Ll0/f$a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "exscotn"

    const-string v0, "context"

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "aclmscbk"

    const-string v0, "bcslckal"

    const/4 v2, 0x4

    const-string/jumbo v0, "lacloabc"

    const-string v0, "callback"

    const/4 v2, 0x0

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p1, p0, Ll0/f$b;->a:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p0, Ll0/f$b;->b:Ljava/lang/String;

    iput-object p3, p0, Ll0/f$b;->c:Ll0/f$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean p4, p0, Ll0/f$b;->d:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean p5, p0, Ll0/f$b;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;Ll0/f$a;ZZILkotlin/jvm/internal/w;)V
    .locals 8

    const/4 v7, 0x0

    and-int/lit8 p7, p6, 0x8

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x5

    if-eqz p7, :cond_0

    const/4 v7, 0x5

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    :goto_0
    const/4 v7, 0x0

    and-int/lit8 p4, p6, 0x10

    const/4 v7, 0x7

    if-eqz p4, :cond_1

    const/4 v7, 0x3

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    const/4 v7, 0x2

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    move v6, p5

    move v6, p5

    move v6, p5

    move v6, p5

    :goto_1
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v7, 0x0

    invoke-direct/range {v1 .. v6}, Ll0/f$b;-><init>(Landroid/content/Context;Ljava/lang/String;Ll0/f$a;ZZ)V

    const/4 v7, 0x5

    return-void
.end method

.method public static final a(Landroid/content/Context;)Ll0/f$b$a;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Ll0/f$b;->f:Ll0/f$b$b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ll0/f$b$b;->a(Landroid/content/Context;)Ll0/f$b$a;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method
