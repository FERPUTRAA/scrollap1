.class public final Ll0/i$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ll0/i$a;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Ll0/i;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation runtime Lh8/m;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x3

    const-string/jumbo v2, "m s bc~oM~n i~d~~~. @@~@i@~l/~~~ @~o ~tK@ovo-@@@b 4f@yr~b@ o@Sa~@@~@ 1@~ lo ~ @ i~ / @ ~~stuf @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const-string/jumbo v0, "tbmmseela"

    const-string v0, "abslNmtee"

    const/4 v3, 0x4

    const-string v0, "Nlaeoaebt"

    const-string/jumbo v0, "tableName"

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Ll0/i;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Ll0/i;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method
