.class public final Ll0/b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ll0/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ll0/b$a;-><init>()V

    const/4 v1, 0x4

    return-void
.end method

.method private final a(Ll0/g;ILjava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "iSstn @@@~@f Kub~ @t~~~  lr ~Mf@d  ly4csvb@ ~ @i@@  ~/ ~@@o~ba@@ @o~~-~o~@1oi~o~o @~~ /~ @~.m~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    if-nez p3, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p1, p2}, Ll0/g;->W1(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto/16 :goto_1

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    instance-of v0, p3, [B

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast p3, [B

    const/4 v3, 0x1

    invoke-interface {p1, p2, p3}, Ll0/g;->B1(I[B)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v0, p3, Ljava/lang/Float;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast p3, Ljava/lang/Number;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p3}, Ljava/lang/Number;->floatValue()F

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    float-to-double v0, p3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->E(ID)V

    const/4 v2, 0x7

    move v3, v2

    goto/16 :goto_1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of v0, p3, Ljava/lang/Double;

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast p3, Ljava/lang/Number;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p3}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->E(ID)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v3, 0x5

    instance-of v0, p3, Ljava/lang/Long;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast p3, Ljava/lang/Number;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p3}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->u1(IJ)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto/16 :goto_1

    :cond_4
    const/4 v3, 0x4

    instance-of v0, p3, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_5

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p3, Ljava/lang/Number;

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    int-to-long v0, p3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->u1(IJ)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto/16 :goto_1

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    instance-of v0, p3, Ljava/lang/Short;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_6

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p3, Ljava/lang/Number;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p3}, Ljava/lang/Number;->shortValue()S

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    int-to-long v0, p3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->u1(IJ)V

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_1

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    instance-of v0, p3, Ljava/lang/Byte;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_7

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast p3, Ljava/lang/Number;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p3}, Ljava/lang/Number;->byteValue()B

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    int-to-long v0, p3

    const/4 v3, 0x6

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->u1(IJ)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_1

    :cond_7
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    instance-of v0, p3, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast p3, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-interface {p1, p2, p3}, Ll0/g;->Z0(ILjava/lang/String;)V

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_1

    :cond_8
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v0, p3, Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_a

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p3, Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p3, :cond_9

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-wide/16 v0, 0x1

    const/4 v3, 0x4

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_9
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {p1, p2, v0, v1}, Ll0/g;->u1(IJ)V

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :cond_a
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, " nbmiCndot a"

    const-string/jumbo v1, "oisd Cbnn at"

    const/4 v3, 0x4

    const-string/jumbo v1, "nandoi nbtC "

    const-string v1, "Cannot bind "

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p3, "eni dbtax "

    const-string p3, "ea midn tx"

    const-string/jumbo p3, "x aie ut d"

    const-string p3, " at index "

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p2, "DlFytiSptdl ngouge r eupSB,,eyptpy,rh  otn lettor tNo,a , oeL,arAuS oys,:bnIl B,"

    const-string p2, ",re otr p ua,yluo,sgyoIeoeotBitB nl ngurlA,:  e, paoty ,DFtlySSSL dNt r,phtt,enb"

    const/4 v3, 0x5

    const-string/jumbo p2, "yt ,gtolqyotlNp,aB reL :I Sdootrl,ty ,rtFe,,s  Bagen t ,tpprlnS,uyhr  SboiAenDeu"

    const-string p2, " Supported types: Null, ByteArray, Float, Double, Long, Int, Short, Byte, String"

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p1
.end method


# virtual methods
.method public final b(Ll0/g;[Ljava/lang/Object;)V
    .locals 5
    .param p1    # Ll0/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .annotation runtime Lh8/m;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "atstneset"

    const-string/jumbo v0, "statement"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    array-length v0, p2

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ge v1, v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    aget-object v2, p2, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, p1, v1, v2}, Ll0/b$a;->a(Ll0/g;ILjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method
