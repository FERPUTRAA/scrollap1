.class public interface abstract Lb2/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract getPickerViewText()Ljava/lang/String;
.end method
