.class public Lm1/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;F)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ssb~~y@@~  @ ~@ ~@~~~~ai v~ @  S~ dof@~o~4~~@@ @@@o ~clibo@t ~ 1tif@~ ~r@  @uoM~@l@~-./ mo~Kn@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    mul-float/2addr p1, p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/high16 p0, 0x3f000000    # 0.5f

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    add-float/2addr p1, p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    float-to-int p0, p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method public static b(Landroid/content/Context;)I
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0xd
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "wndmis"

    const-string/jumbo v0, "nwsdiw"

    const-string v0, "dwoion"

    const-string/jumbo v0, "window"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p0, Landroid/view/WindowManager;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget p0, v0, Landroid/graphics/Point;->y:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static c(Landroid/content/Context;)I
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0xd
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const-string v0, "dowmib"

    const-string/jumbo v0, "widmwo"

    const/4 v2, 0x2

    const-string/jumbo v0, "uniwwd"

    const-string/jumbo v0, "window"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    check-cast p0, Landroid/view/WindowManager;

    const/4 v1, 0x2

    move v2, v1

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    iget p0, v0, Landroid/graphics/Point;->x:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p0
.end method

.method public static d(Landroid/content/Context;F)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    div-float/2addr p1, p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/high16 p0, 0x3f000000    # 0.5f

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    add-float/2addr p1, p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    float-to-int p0, p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method
