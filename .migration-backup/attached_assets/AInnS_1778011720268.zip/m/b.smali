.class public final synthetic Lm/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Lm/c;Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "cas b@ 4~oif~uom@~~l@ ~~b @S vld o@~i~or@@M~b@/ @@@~n@~s~~y K  -@tfo i@@~o ~~.@ @@1  ~~@~t @ /~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-interface {p0, p1}, Lm/c;->setContentDescription(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public static bridge synthetic b(Lm/c;Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Lm/c;->setTooltipText(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method
