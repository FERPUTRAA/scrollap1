.class public final Lb1/d;
.super Ljava/lang/Object;


# direct methods
.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-is@no o@b~~rl~@ /@ So@c @ ~/~~ ~~vib~  @~m@~t y~~~@@~~M o4 uo~Kl@@i@~o@~@b@. f@ t@~a @ d s1~ @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-class v0, Lb1/d;

    const-class v0, Lb1/d;

    const/4 v3, 0x3

    const-class v0, Lb1/d;

    const-class v0, Lb1/d;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v3, 0x0

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1, p3}, La1/c;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1, v1}, Lb1/e;->b(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x6

    return-void

    :catchall_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x7

    return-void

    :catchall_1
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method
