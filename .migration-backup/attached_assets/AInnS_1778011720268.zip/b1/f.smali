.class public final Lb1/f;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@bs~~~ @@.  lrc~ 4 a~@ ~@@@1s @d~~M @~ ~~i~/~uKfm/@ o~oo@@~@~@~ f@ byt~@n~ @tv li@i@S -o@o~ b~~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-static {p0}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v1, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method
