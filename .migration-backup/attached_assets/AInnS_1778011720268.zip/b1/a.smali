.class public Lb1/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ts@lK@@f~@~ u/S  1 @~/~i4@ ~@ r@~ v~oo~ @  @@i~ fM~ @b@~o@~o@ib  l b~@mc~yn-.d~@ot@~a~~~  ~@@os"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const-class v0, Lb1/a;

    const/4 v4, 0x3

    const-class v0, Lb1/a;

    const-class v0, Lb1/a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-enter v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p0, p1, p2, v2}, Lb1/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    :try_start_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v1

    :cond_1
    :try_start_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p1, p0}, La1/c;->e(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :try_start_4
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v1

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-class v0, Lb1/a;

    const-class v0, Lb1/a;

    const/4 v3, 0x1

    const-class v0, Lb1/a;

    const-class v0, Lb1/a;

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p2}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, La1/c;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1, p3}, La1/c;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v1, Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-static {p0, p1, v1}, Lb1/e;->b(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :catchall_1
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method
