.class public final Lb1/b;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  syos ~    r ~@di~M@S~ @u@.@t~~~~@@am @/@c@@o@@ o@~@@v~io ~~@n~~b @ ~l ~b1o~4-iot ~@~K@/~~~fl f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-static {p0}, Lb1/f;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "nstmygSmoCe.i"

    const-string/jumbo v1, "iSstgComeyn.s"

    const/4 v3, 0x4

    const-string v1, "SmofoyCsnit.e"

    const-string v1, ".SystemConfig"

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0}, Lb1/c;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0
.end method
