.class public Ln0/c;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/view/View;I)Landroid/view/View;
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroid/view/View;",
            ">(",
            "Landroid/view/View;",
            "I)TT;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    instance-of v0, p0, Landroid/view/ViewGroup;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v1

    :cond_0
    const/4 v5, 0x7

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ge v2, v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v3, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v3

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v1
.end method
