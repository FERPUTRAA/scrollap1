.class public interface abstract Ln0/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract getRoot()Landroid/view/View;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method
