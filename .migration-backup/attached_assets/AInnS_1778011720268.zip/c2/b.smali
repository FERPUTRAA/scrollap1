.class public interface abstract Lc2/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(I)V
.end method
