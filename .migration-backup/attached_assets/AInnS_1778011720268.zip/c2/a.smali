.class public final Lc2/a;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;


# instance fields
.field private final a:Lcom/contrarywind/view/WheelView;


# direct methods
.method public constructor <init>(Lcom/contrarywind/view/WheelView;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lc2/a;->a:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~is @  ~~4@@ y@@ M  t/ ~~d@o@~t@ c~~o~-~~o@smK/o~ @~@@o~ @@ @vfaSb~@1i~~b~io@~n  u @l @r~~l~@.b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p1, p0, Lc2/a;->a:Lcom/contrarywind/view/WheelView;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, p4}, Lcom/contrarywind/view/WheelView;->scrollBy(F)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method
