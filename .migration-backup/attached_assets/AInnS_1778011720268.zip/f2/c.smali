.class public final Lf2/c;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lf2/c;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final b:I = 0xf

.field public static final c:I = 0x3

.field public static final d:I = 0xc

.field public static final e:I = 0x4

.field public static final f:I = 0x8

.field public static final g:I = 0x1

.field public static final h:I = 0x2

.field public static final i:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lf2/c;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lf2/c;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    sput-object v0, Lf2/c;->a:Lf2/c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method
