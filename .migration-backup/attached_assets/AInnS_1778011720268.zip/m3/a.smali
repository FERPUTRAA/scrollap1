.class public Lm3/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "MTGoogleBusiness"

.field private static volatile b:Lm3/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static a()Lm3/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s/ b~ o@i~@@ ~@n~r4v@d   i@y~@~~@ta@~@o@@~ lbMS~~     ist@~o@ @m~~lb1K@~@@f~u~ -oc ~o /@~~.fo "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lm3/a;->b:Lm3/a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-class v0, Lm3/a;

    const-class v0, Lm3/a;

    const/4 v3, 0x1

    const-class v0, Lm3/a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lm3/a;

    const/4 v3, 0x6

    invoke-direct {v1}, Lm3/a;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput-object v1, Lm3/a;->b:Lm3/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    sget-object v0, Lm3/a;->b:Lm3/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method public b(Landroid/content/Context;)V
    .locals 10

    const-string v0, "GsgmsuBoMoienses"

    const-string v0, "GossigeTneoBMssu"

    const/4 v9, 0x7

    const-string/jumbo v0, "olgMoessnGTsouie"

    const-string v0, "MTGoogleBusiness"

    :try_start_0
    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/g;->j(Landroid/content/Context;)I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v5, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v2, " :eotb,spu d ogslutoohen ocgmp"

    const-string/jumbo v2, "o dmseou,u lppoch:ntg poeots g"

    const/4 v9, 0x7

    const-string v2, "g t,  upnhtedrpcs uulsooogepo:"

    const-string/jumbo v2, "not support google push, code:"

    const/4 v8, 0x0

    and-int/2addr v9, v8

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    invoke-static {v0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/16 v4, 0xbba

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/16 v6, 0xf3c

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v7, 0x1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual/range {v2 .. v7}, Lm3/a;->c(Landroid/content/Context;IIII)V

    const/4 v9, 0x0

    return-void

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo v1, "phgsou pteolsrop po"

    const-string v1, "gppuouhsoo opstler "

    const/4 v9, 0x4

    const-string v1, " tupguegqrsohoopls "

    const-string/jumbo v1, "support google push"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {}, Lcom/google/firebase/messaging/FirebaseMessaging;->i()Lcom/google/firebase/messaging/FirebaseMessaging;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v1}, Lcom/google/firebase/messaging/FirebaseMessaging;->l()Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance v2, Ln3/a;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {v2, p1}, Ln3/a;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string/jumbo v2, "idse afiil n"

    const-string/jumbo v2, "init failed "

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method public c(Landroid/content/Context;IIII)V
    .locals 5

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v1, "oftmpbrl"

    const/4 v4, 0x4

    const-string v1, "aprmfmot"

    const-string/jumbo v1, "platform"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/16 v2, 0x8

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putByte(Ljava/lang/String;B)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v1, "oedc"

    const-string v1, "ecod"

    const/4 v4, 0x7

    const-string v1, "doce"

    const-string v1, "code"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo p2, "oCumo"

    const-string p2, "Cudom"

    const-string p2, "beCod"

    const-string/jumbo p2, "mCode"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p2, p3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo p2, "pyet"

    const-string/jumbo p2, "teyp"

    const/4 v4, 0x1

    const-string/jumbo p2, "type"

    const-string/jumbo p2, "type"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p2, p4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p2, "ofmr"

    const-string/jumbo p2, "romf"

    const/4 v4, 0x4

    const-string/jumbo p2, "orfm"

    const-string p2, "from"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p2, p5}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/16 p2, 0xbce

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1, p2, v0}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x1

    const-string p1, "BpsusMuenTeiosGg"

    const-string p1, "TGoiMBgpsesselun"

    const/4 v8, 0x6

    const-string p1, "MTGoogleBusiness"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo p2, "no ekomiqoetns:Ttyn kp"

    const/4 v8, 0x1

    const-string p2, "e:ykmnnpten eoTos tipk"

    const-string/jumbo p2, "onToken:token is empty"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {p1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/16 v1, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->e(B)Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0, p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->h(Ljava/lang/String;)Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v8, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v1, "eqgsasm"

    const-string/jumbo v1, "sesmgae"

    const/4 v8, 0x2

    const-string v1, "emsgass"

    const-string/jumbo v1, "message"

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p1}, Lj3/a;->l(Landroid/content/Context;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/16 p2, 0xbcd

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {p1, p2, v0}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/16 v3, 0xbc0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x3

    move v8, v7

    const/16 v5, 0xf3d

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x5

    move v6, p3

    const/4 v8, 0x0

    move v6, p3

    move v6, p3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual/range {v1 .. v6}, Lm3/a;->c(Landroid/content/Context;IIII)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    return-void
.end method
