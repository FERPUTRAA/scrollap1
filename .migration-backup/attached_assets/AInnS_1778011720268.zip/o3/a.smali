.class public Lo3/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "HttpClient"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;)[B
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  sot@b@.~K@~v@n /~@ @~b-u4~~idb ~ @@~~~  ~~@i@ o~ @ ~o@l@o@a  t~~@~fSis/1f omrMc~@ @~l@y ~ o~@~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x2

    const-string v0, "edsm ila lfes"

    const-string v0, "alssl e iedfc"

    const/4 v9, 0x7

    const-string v0, " ollodaic sef"

    const-string v0, "close failed "

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v2, "mttenbiClp"

    const-string v2, "HnpmteilCt"

    const/4 v9, 0x5

    const-string v2, "CHpittuenl"

    const-string v2, "HttpClient"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez p1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string p1, "Cct/eetpi /td,wg nenta ioosrn nodks"

    const-string/jumbo p1, "sk toec d/iCnnstoeod n/,tnegrita we"

    const/4 v9, 0x2

    const-string/jumbo p1, "rceCn a,qd/t  ikontwe esed/gcnitsno"

    const-string p1, "can\'t get, network is disConnected"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v2, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    return-object v1

    :cond_0
    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance p1, Ljava/net/URL;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {p1, p2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    check-cast p1, Ljava/net/HttpURLConnection;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string p2, "ETG"

    const-string p2, "ETG"

    const/4 v9, 0x3

    const-string p2, "GET"

    const-string p2, "GET"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, p2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/16 p2, 0x1770

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p1, p2}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    invoke-virtual {p1, p2}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string p2, "-nstEonAeccgcdp"

    const-string p2, "Accept-Encoding"

    const/4 v9, 0x6

    const-string/jumbo v3, "itemitdy"

    const-string v3, "eytiibdt"

    const/4 v9, 0x2

    const-string/jumbo v3, "itdtoeni"

    const-string/jumbo v3, "identity"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-string/jumbo p2, "nounnbicCt"

    const-string/jumbo p2, "iotCnnunoc"

    const/4 v9, 0x2

    const-string/jumbo p2, "oncitnunoe"

    const-string p2, "Connection"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v3, "eppCo"

    const-string v3, "Clpoe"

    const/4 v9, 0x3

    const-string v3, "eslqC"

    const-string v3, "Close"

    const/4 v9, 0x7

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->addRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string/jumbo p2, "qestCar"

    const-string p2, "hqrCtae"

    const/4 v9, 0x4

    const-string p2, "hasmter"

    const-string p2, "Charset"

    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    sget-object v3, Lx2/a;->b:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    instance-of p2, p1, Ljavax/net/ssl/HttpsURLConnection;

    if-eqz p2, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string p2, "LTS"

    const-string p2, "LST"

    const/4 v9, 0x6

    const-string p2, "LST"

    const-string p2, "TLS"

    const/4 v8, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p2}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2, v1, v1, v1}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    check-cast v3, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3, p2}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    check-cast p2, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v3, La3/a;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {v3, v4}, La3/a;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, v3}, Ljavax/net/ssl/HttpsURLConnection;->setHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 p2, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, p2}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/4 p2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1, p2}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/net/URLConnection;->getContentLength()I

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/16 v5, 0xc8

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-ne v4, v5, :cond_2

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1
    :try_end_1
    .catch Ljava/net/MalformedURLException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    const/4 v9, 0x0

    const/4 v8, 0x4

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_2
    .catch Ljava/net/MalformedURLException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-array v3, v3, [B

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v6, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eq v5, v6, :cond_3

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    invoke-virtual {v4, v3, p2, v5}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_3
    .catch Ljava/net/MalformedURLException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto/16 :goto_4

    :catch_0
    move-exception p2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto/16 :goto_8

    :catch_1
    move-exception p2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto/16 :goto_c

    :catchall_1
    move-exception p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_3

    :catch_2
    move-exception p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto/16 :goto_7

    :catch_3
    move-exception p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto/16 :goto_b

    :cond_2
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v4, :cond_4

    :try_start_4
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    goto :goto_1

    :catchall_2
    move-exception p1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz p1, :cond_8

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    goto/16 :goto_f

    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto/16 :goto_f

    :catchall_3
    move-exception p1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_3
    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    :goto_4
    :try_start_5
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v5, "eldfo iges "

    const-string v5, "  seelgdtfi"

    const-string v5, "g ldtbafe i"

    const-string v5, "get failed "

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v2, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_7

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v4, :cond_5

    :try_start_6
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v9, 0x1

    const/4 v8, 0x7

    goto :goto_5

    :catchall_4
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_6

    :cond_5
    :goto_5
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz p1, :cond_8

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    const/4 v9, 0x0

    const/4 v8, 0x3

    goto/16 :goto_f

    :goto_6
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto/16 :goto_f

    :catch_4
    move-exception p1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_7
    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    :goto_8
    :try_start_7
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const-string/jumbo v5, "titoiEueg:me pno"

    const-string/jumbo v5, "ittmpicEgee o:on"

    const/4 v9, 0x5

    const-string v5, "cgeEtoip nitxop:"

    const-string v5, "get ioException:"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v2, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_7

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v4, :cond_6

    :try_start_8
    const/4 v9, 0x3

    const/4 v8, 0x5

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v9, 0x7

    goto :goto_9

    :catchall_5
    move-exception p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_a

    :cond_6
    :goto_9
    const/4 v9, 0x3

    if-eqz p1, :cond_8

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto/16 :goto_f

    :goto_a
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto/16 :goto_f

    :catch_5
    move-exception p1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_b
    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    :goto_c
    :try_start_9
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo v5, "oeReoUiftcxeltgmm:nrE Lpoa"

    const/4 v9, 0x2

    const-string v5, " imleEetqUctLofdnrpg:aRoex"

    const-string v5, "get malformedURLException:"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {v2, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_7

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-eqz v4, :cond_7

    :try_start_a
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    goto :goto_d

    :catchall_6
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_e

    :cond_7
    :goto_d
    const/4 v9, 0x0

    const/4 v8, 0x0

    if-eqz p1, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_f

    :goto_e
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    :goto_f
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v4, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x2

    return-object v1

    :cond_9
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    return-object p1

    :catchall_7
    move-exception p2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v4, :cond_a

    :try_start_b
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_10

    :catchall_8
    move-exception p1

    const/4 v9, 0x5

    const/4 v8, 0x3

    goto :goto_11

    :cond_a
    :goto_10
    const/4 v9, 0x1

    const/4 v8, 0x0

    if-eqz p1, :cond_b

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_8

    const/4 v9, 0x3

    goto :goto_12

    :goto_11
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v8, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_b
    :goto_12
    const/4 v8, 0x4

    move v9, v8

    throw p2
.end method
