.class public Lo3/e;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "NotificationChannelUtil"

.field private static final b:Ljava/lang/String; = "ENGAGELAB_PRIVATES_CHANNEL_low"

.field private static final c:Ljava/lang/String; = "ENGAGELAB_PRIVATES_CHANNEL_normal"

.field private static final d:Ljava/lang/String; = "ENGAGELAB_PRIVATES_CHANNEL_high"

.field private static final e:Ljava/lang/String; = "ENGAGELAB_PRIVATES_CHANNEL_silence"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "oys r /@v@o~1b~lm@db-  ~  ni~@@~@ ~t @ @~~.~@@ 4~~ @~ooo@~~ ~@ S~ ioulia K@@@s~@b@~ /@f@~M~~~ ft"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/16 v1, 0x1a

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v2, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-ge v0, v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-object v2

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {p0, p1, p2}, Lo3/e;->b(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string/jumbo v1, "tofmoniscnta"

    const-string/jumbo v1, "tostinofacni"

    const/4 v10, 0x2

    const-string v1, "ctniotfoiain"

    const-string/jumbo v1, "notification"

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x2

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v1, v0}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {p0, p1, p2}, Lo3/e;->c(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I

    move-result v4

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v5, "UfimiNtncilontaCotehanl"

    const/4 v10, 0x3

    const-string v5, "attUebCtonnliiiailnhfoc"

    const-string v5, "NotificationChannelUtil"

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v3, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->q()I

    move-result p0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 p1, -0x1

    move v10, p1

    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string/jumbo p2, "sac oeul:hnIah"

    const-string p2, "hlnaoachs:Ied "

    const/4 v10, 0x5

    const-string/jumbo p2, "lhanh cpd:nseI"

    const-string p2, "has channelId:"

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eq p1, p0, :cond_1

    const/4 v10, 0x6

    invoke-static {v3, v4}, Lo3/c;->a(Landroid/app/NotificationChannel;I)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string/jumbo p1, "ohesnbetqnl aae :cdnnpIcarm"

    const-string/jumbo p1, "smdelb pantteh anearIocn:nc"

    const/4 v10, 0x3

    const-string/jumbo p1, "tcscmps:hoad nletna rn nIea"

    const-string p1, " and set channelImportance:"

    const/4 v10, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {v5, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    invoke-static {v5, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    return-object v0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {p0, p1, p2}, Lo3/e;->d(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v0, v3, v4}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {p0, p1, p2}, Lo3/f;->v(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Landroid/net/Uri;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {p0, p1, p2}, Lo3/f;->g(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I

    move-result v8

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {p0, p1, p2}, Lo3/f;->y(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v6, p0}, Lo3/d;->a(Landroid/app/NotificationChannel;I)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 p0, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 p1, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v7, :cond_3

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v6, v7, v2}, Landroidx/core/app/i0;->a(Landroid/app/NotificationChannel;Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_2

    :catchall_0
    move-exception p2

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_1

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    and-int/lit8 p2, v8, 0x1

    const/4 v9, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-eqz p2, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    move p2, p1

    move p2, p1

    const/4 v10, 0x0

    move p2, p1

    move p2, p1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_0

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x5

    move p2, p0

    move p2, p0

    const/4 v10, 0x5

    move p2, p0

    move p2, p0

    :goto_0
    const/4 v10, 0x0

    if-nez p2, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v6, v2, v2}, Landroidx/core/app/i0;->a(Landroid/app/NotificationChannel;Landroid/net/Uri;Landroid/media/AudioAttributes;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    goto :goto_2

    :goto_1
    const/4 v10, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string/jumbo v7, "l: maufenoudis"

    const-string v7, "eiao lusuf:dSn"

    const/4 v10, 0x3

    const-string v7, "feotod:lsnSuia"

    const-string/jumbo v7, "setSound fail:"

    const/4 v10, 0x7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-static {v5, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    and-int/lit8 p2, v8, 0x4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eqz p2, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x7

    move p2, p1

    move p2, p1

    const/4 v10, 0x4

    move p2, p1

    move p2, p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    goto :goto_3

    :cond_6
    const/4 v10, 0x3

    move p2, p0

    move p2, p0

    const/4 v10, 0x6

    move p2, p0

    move p2, p0

    :goto_3
    const/4 v9, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v6, p2}, Landroidx/core/app/j0;->a(Landroid/app/NotificationChannel;Z)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    and-int/lit8 p2, v8, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz p2, :cond_7

    const/4 v9, 0x5

    move v10, v9

    move p0, p1

    move p0, p1

    const/4 v10, 0x5

    move p0, p1

    move p0, p1

    :cond_7
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v6, p0}, Landroidx/core/app/m0;->a(Landroid/app/NotificationChannel;Z)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    invoke-static {v1, v6}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    const/4 v9, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const-string/jumbo p1, "nlhldbcnldacue hnaI:i pe"

    const-string/jumbo p1, "udiedlepclnb nahla :cnhI"

    const/4 v10, 0x1

    const-string p1, "ceinedun:nIlan blhchauld"

    const-string p1, "build channel channelId:"

    const/4 v9, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string p1, "hm ,eenpa:lqcn"

    const-string p1, "h ec:,anqmlnae"

    const/4 v10, 0x7

    const-string p1, "N:mehn,aqnleca"

    const-string p1, ", channelName:"

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string p1, "h:scncnnotls aa,pemI"

    const-string/jumbo p1, "plsrneantco:,chaInm "

    const/4 v10, 0x3

    const-string/jumbo p1, "pa mtccoeemhan:,nrln"

    const-string p1, ", channelImportance:"

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {v5, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    move v10, v9

    return-object v0
.end method

.method private static b(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    move v2, v1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string p1, "cLNAoPANBIGRm_EACNTn_LGEseHlESiAEe__N"

    const-string/jumbo p1, "lEAmBANSn_GcLTNGECVAiILRE_PHN_se_AENe"

    const/4 v2, 0x5

    const-string p1, "RGeN_bnLNs__ETAGecESLHENAEA_CANi_lVIB"

    const-string p1, "N_ENGAGELAB_PRIVATES_CHANNEL_silence_"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->h()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->h()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_1
    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, -0x2

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eq p0, p1, :cond_5

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, -0x1

    const/4 v1, 0x7

    move v2, v1

    if-eq p0, p1, :cond_5

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "_"

    const-string v0, "_"

    const/4 v2, 0x0

    const-string v0, "_"

    const-string v0, "_"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p0, p1, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eq p0, p1, :cond_3

    const/4 v2, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p1, "PVE_CruL_BTNIANENHS_E_oNoEGA_lnAmRGA"

    const-string p1, "AAr_oBNAN_TSAmELEHl_RGVNnNCoG_IPEEL_"

    const/4 v2, 0x5

    const-string p1, "NATEVE_p_BICEnNmaHNEN_GArAPSLL__AloR"

    const-string p1, "N_ENGAGELAB_PRIVATES_CHANNEL_normal_"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo p1, "ig__LEThqECP_LNAHSERh__VNEGAIGbNAA"

    const-string p1, "TNNBhbA_ELI_S_VEAEP_ChL_GHAARGiENg"

    const/4 v2, 0x7

    const-string p1, "AAsLhigRN_NESHEPN_IEVTNGLh_AEC_B_A"

    const-string p1, "N_ENGAGELAB_PRIVATES_CHANNEL_high_"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p0, :cond_4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0

    :cond_4
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0

    :cond_5
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string p1, "_NRmPLHAE_uVELGGowS_NNIATEAN_AE_C"

    const-string p1, "SwoIA_uEECTPNEN__LAB_GLNRH_VNEAGA"

    const/4 v2, 0x5

    const-string p1, "N_NGoTEBPN_HERVAoSEAAECNA_wLG_LIl"

    const-string p1, "N_ENGAGELAB_PRIVATES_CHANNEL_low_"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method private static c(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I
    .locals 2

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p1, -0x2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    if-eq p0, p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p0, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0

    :cond_0
    const/4 v1, 0x0

    const/4 p0, 0x1

    const/4 v1, 0x4

    move v0, p0

    move v0, p0

    const/4 v1, 0x6

    return p0

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p0}, Lo3/e;->e(I)I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p0
.end method

.method private static d(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "pitgsb"

    const-string/jumbo v0, "tpsgin"

    const/4 v3, 0x5

    const-string/jumbo v0, "ugtnsr"

    const-string/jumbo v0, "string"

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "GAEEnNGplH_ARSV_NNPILCLBeEEAsAi_Te"

    const-string v1, "ENGAGELAB_PRIVATES_CHANNEL_silence"

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p1, v1, v0, p2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-lez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const-string p0, "IqCELqS"

    const-string p0, "SqCNILE"

    const-string p0, "ECsNLES"

    const-string p0, "SILENCE"

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p2, -0x2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eq p1, p2, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p2, -0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eq p1, p2, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eq p1, p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p2, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq p1, p2, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p1, "AIsmN_Lr_CPoANTnEGSAE_LlBAHREEmaN"

    const-string p1, "aCs_A_ElITnRABEmGrA_NEHLLoEPNNSAG"

    const/4 v3, 0x3

    const-string p1, "PL_RoAanNVoBmATrEGAEICSLENNGE_l_A"

    const-string p1, "ENGAGELAB_PRIVATES_CHANNEL_normal"

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string p1, "ATAI_bEAiCBNPRSENGELmV_gGNhA_hL"

    const-string p1, "CBEmLNiAgAH_TAEGVSLPEANNhR_IGh_"

    const-string p1, "AiGhC_uHNILNEGAABVETL_RNEEPhAg_"

    const-string p1, "ENGAGELAB_PRIVATES_CHANNEL_high"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string p1, "_BLPNVlpIEREHEw__AoNoNSATECGAG"

    const-string p1, "LB_wo__SAHAVEANPNEGIElNTRELCGo"

    const/4 v3, 0x2

    const-string p1, "ENGAGELAB_PRIVATES_CHANNEL_low"

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p2, p1, v0, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-lez p1, :cond_4

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p0

    :cond_4
    const/4 v3, 0x7

    const-string p0, "ORqbLM"

    const-string p0, "MLOARb"

    const/4 v3, 0x5

    const-string p0, "NORMAL"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0
.end method

.method private static e(I)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, -0x2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq p0, v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, -0x1

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x2

    move v3, v2

    move v3, v2

    if-eq p0, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p0, v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eq p0, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 p0, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    return p0

    :cond_0
    const/4 v4, 0x4

    const/4 p0, 0x3

    const/4 v4, 0x2

    const/4 p0, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return p0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 p0, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    return p0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v2

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v1
.end method
