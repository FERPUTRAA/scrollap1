.class public final synthetic Lo3/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s@l@~.~~ ~b~~l@bnf~~4 t@ @~vM~m i~~o @ o-@1@~@/K@s      ~@iir ySd@@b@ ~~oof@ ~~@~a oto/uc ~@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setLockscreenVisibility(I)V

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
