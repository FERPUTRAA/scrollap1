.class public Lo3/f$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo3/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v1, 0x6

    and-int/2addr v2, v1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lo3/f$a;->a:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lo3/f$a;->d()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public static a(I)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sf @@o~~ou~o  f~/~@mys@ S @ ~@@ @o@n ob @a@@.-~@ v @cl~~~ i 4tK@~Mo@t~r@   /~@d~l ~1~~i@~b~@~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    if-eqz p0, :cond_2

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eq p0, v0, :cond_2

    const/4 v2, 0x6

    move v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eq p0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq p0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq p0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p0, -0x1

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 p0, -0x2

    const/4 p0, -0x2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p0
.end method

.method public static synthetic b(Lorg/json/JSONObject;)I
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-static {p0}, Lo3/f$a;->e(Lorg/json/JSONObject;)I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static c(Lorg/json/JSONObject;I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method

.method public static d()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v0, Lo3/f$a;->a:Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "ggemos"

    const-string/jumbo v1, "oosegg"

    const/4 v4, 0x2

    const-string v1, "eoolog"

    const-string v1, "google"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const-string v2, "cf"

    const-string v2, "fc"

    const/4 v4, 0x4

    const-string v2, "fc"

    const-string v2, "fc"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const-string v1, "ehmiab"

    const-string/jumbo v1, "uahmei"

    const/4 v4, 0x6

    const-string v1, "huawei"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const-string/jumbo v2, "wh"

    const-string v2, "hw"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "ohoro"

    const/4 v4, 0x2

    const-string v1, "honor"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, "hn"

    const-string/jumbo v2, "nh"

    const/4 v4, 0x2

    const-string v2, "hn"

    const-string v2, "hn"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    move v4, v3

    const-string v1, "buziu"

    const-string v1, "bzumi"

    const/4 v4, 0x1

    const-string/jumbo v1, "meizu"

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "mz"

    const-string/jumbo v2, "mz"

    const/4 v4, 0x0

    const-string/jumbo v2, "mz"

    const-string/jumbo v2, "mz"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-string/jumbo v1, "viov"

    const-string/jumbo v1, "vivo"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v2, "iv"

    const-string/jumbo v2, "vi"

    const/4 v4, 0x5

    const-string/jumbo v2, "vi"

    const-string/jumbo v2, "vi"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "ppoo"

    const-string/jumbo v1, "popo"

    const-string/jumbo v1, "oopp"

    const-string/jumbo v1, "oppo"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v2, "op"

    const-string/jumbo v2, "op"

    const/4 v4, 0x0

    const-string/jumbo v2, "po"

    const-string/jumbo v2, "op"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "umleer"

    const/4 v4, 0x5

    const-string/jumbo v1, "lpmear"

    const-string/jumbo v1, "realme"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const-string/jumbo v1, "pqunslo"

    const-string/jumbo v1, "oneplus"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v1, "ipsaim"

    const-string/jumbo v1, "ipaixm"

    const/4 v4, 0x4

    const-string v1, "aommix"

    const-string/jumbo v1, "xiaomi"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "xm"

    const-string/jumbo v2, "mx"

    const/4 v4, 0x4

    const-string/jumbo v2, "xm"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "krbaocaskh"

    const-string v1, "acbkrhksqa"

    const-string v1, "basrabkkhl"

    const-string v1, "blackshark"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method public static e(Lorg/json/JSONObject;)I
    .locals 6

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "innor_utmpce"

    const-string/jumbo v0, "n_importance"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez v2, :cond_0

    const/4 v5, 0x2

    invoke-static {p0, v1}, Lo3/f$a;->c(Lorg/json/JSONObject;I)I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    return p0

    :cond_0
    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v3, Lo3/f$a;->a:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const-string v1, ":mpvi"

    const-string/jumbo v1, "im_v:"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v1, "NoclttftqnsoUiai"

    const-string/jumbo v1, "onsiUitiafNcotlt"

    const-string v1, "cfsiNitaiitooUnt"

    const-string v1, "NotificationUtil"

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    move v5, v4

    return p0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0, v1}, Lo3/f$a;->c(Lorg/json/JSONObject;I)I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    return p0
.end method

.method public static f(Lorg/json/JSONObject;)I
    .locals 4

    const/4 v3, 0x3

    const-string/jumbo v0, "yo_miptrri"

    const-string/jumbo v0, "rromt_iypi"

    const/4 v3, 0x2

    const-string/jumbo v0, "ioytoirpn_"

    const-string/jumbo v0, "n_priority"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0}, Lo3/f$a;->e(Lorg/json/JSONObject;)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0}, Lo3/f$a;->a(I)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-le v0, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p0

    :cond_1
    return v0
.end method
