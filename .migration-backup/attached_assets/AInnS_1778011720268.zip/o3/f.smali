.class public Lo3/f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo3/f$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "NotificationUtil"

.field private static final b:Ljava/lang/String; = "checkOpNoThrow"

.field private static final c:Ljava/lang/String; = "OP_POST_NOTIFICATION"

.field public static final d:Ljava/lang/String; = "mtpush_notification_icon"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static A(Landroid/content/Context;I)Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~@s t@~b~l1 ~@~ @/y~ @@ ~@ c@~l ob@S~@o.o~i@iu~@4M~@o@of o tb~/ @@~ m ~fn@ @ r~K~ ~@~@ da~~v-s~ "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    const-string/jumbo v0, "tsomNloitcnaitUi"

    const-string/jumbo v0, "otslticaNoitniiU"

    const/4 v8, 0x7

    const-string/jumbo v0, "otUoonitifltNiia"

    const-string v0, "NotificationUtil"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo v1, "oedcubnh.nengrndcae/l/nha./moeiit/w.tug.:asobamsittre"

    const-string v1, "dudm:slie.dretostg.oinmeathob/nug/a.ae/nhecrnt./ainwc"

    const/4 v8, 0x1

    const-string v1, ".uteuhumre/aonoc/i:a/ntcgnite/.dobhd.iasencrtdwsnal.e"

    const-string v1, "content://com.huawei.android.launcher.settings/badge/"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const-string/jumbo v2, "nbdemc.pi.ahto/h:nsncahnor/csd/tdeo.ooltginreagrnou.ti"

    const-string/jumbo v2, "oadoorit.utacbrhnhni.degrmonco.snd//a/oece/ng.hitltsn:"

    const/4 v8, 0x6

    const-string v2, "contlr.iqgdo/nhausahe.n.tgbndmncnettsi.ooh:ecordir/ae/"

    const-string v2, "content://com.hihonor.android.launcher.settings/badge/"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v3, 0x0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v4, v2}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v5, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v4, v2}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const-string/jumbo p0, "see ubns oifgrBllaH ,rn lutiadio"

    const/4 v8, 0x0

    const-string p0, " iso,nds ta HrBsio une igurlfale"

    const-string p0, " setHonorBadge fail, uri is null"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    return v3

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v1, Landroid/os/Bundle;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v5, "gucmepa"

    const-string v5, "cekapgu"

    const/4 v8, 0x2

    const-string v5, "ceapoga"

    const-string/jumbo v5, "package"

    :try_start_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1, v5, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v5, "bsslc"

    const-string/jumbo v5, "slpsc"

    const/4 v8, 0x5

    const-string v5, "cusls"

    const-string v5, "class"

    :try_start_2
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p0}, Lo3/f;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v5, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo p0, "mbqeebdprnu"

    const-string/jumbo p0, "umebrgdeqbn"

    const/4 v8, 0x2

    const-string/jumbo p0, "nubebageqrd"

    const-string p0, "badgenumber"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v1, p0, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v8, 0x2

    const-string p0, "_escnadsgbgh"

    const-string p0, "_eshndcaeggb"

    const/4 v8, 0x1

    const-string p0, "c_gmaahbdeeg"

    const-string p0, "change_badge"

    const/4 v8, 0x3

    const/4 p1, 0x0

    const/4 v8, 0x6

    and-int/2addr v7, p1

    const/4 v8, 0x6

    invoke-virtual {v4, v2, p0, p1, v1}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 p0, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    return p0

    :catchall_0
    move-exception p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v1, "t:snoonrarr Hd ooeme rgreog"

    const-string v1, " Homa rrsoeodn:rtB renrogge"

    const/4 v8, 0x0

    const-string/jumbo v1, "te wob g orodenersrr:oHBagn"

    const-string v1, " setHonorBadge wrong error:"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    return v3
.end method

.method public static B(Landroid/content/Context;I)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v0, "aiifntuttlNUocoi"

    const-string/jumbo v0, "titioUoaoNcitfln"

    const/4 v6, 0x2

    const-string/jumbo v0, "iotainiplttcfoiN"

    const-string v0, "NotificationUtil"

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v1, Landroid/os/Bundle;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const-string v2, "gqaakbp"

    const-string v2, "gackabp"

    const/4 v6, 0x7

    const-string v2, "cpskgaa"

    const-string/jumbo v2, "package"

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-static {p0}, Lo3/f;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "g mmwebdNreBsuuiautHa"

    const-string/jumbo v4, "uaubgeumtBsewHr iaNde"

    const-string/jumbo v4, "tmbro gsudeeHiBuNeeaw"

    const-string/jumbo v4, "setHuaweiBadgeNumber "

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v3, "bpssa"

    const-string/jumbo v3, "sspac"

    const-string/jumbo v3, "susla"

    const-string v3, "class"

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v2, "dmnqebapgrb"

    const-string v2, "gebdmaenqrb"

    const/4 v6, 0x3

    const-string v2, "euraenbmqbd"

    const-string v2, "badgenumber"

    const/4 v6, 0x4

    invoke-virtual {v1, v2, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo p1, "ruseeeimdgtaod./a.clst.duaencicnnoa:thnrtwo//sb.hing/"

    const/4 v6, 0x6

    const-string p1, "bssecram/dt./htd.dgo:euetawlant/ciose.ieochnng/.urann"

    const-string p1, "content://com.huawei.android.launcher.settings/badge/"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "gngmbcae_dhe"

    const/4 v6, 0x2

    const-string v2, "change_badge"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0, p1, v2, v3, v1}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v1, "dram meesuBHwiee Nfulbgotedi"

    const-string/jumbo v1, "wfeeo eburNil tmusaieagdHdBe"

    const/4 v6, 0x7

    const-string v1, " resodHuaaueealiwm gtNeidfeB"

    const-string/jumbo v1, "setHuaweiBadgeNumber failed "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method

.method public static C(Landroid/content/Context;Landroid/app/Notification;I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez p2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x0

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Lo2/t;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int v1, v0, p2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lo2/c;->l(Landroid/content/Context;I)V

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v3, "otoiBbdaagneoNicnttcfsBNtaeaiecedfciohgiai[t"

    const-string/jumbo v3, "setNotificationBadge cacheNotificationBadge["

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v0, "an]tNbadinfi[tutooecBrirgec"

    const/4 v5, 0x5

    const-string v0, "[tniniurBNdotrg+etaauefc]oc"

    const-string v0, "]+currentNotificationBadge["

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v0, "]"

    const-string v0, "]"

    const-string v0, "]"

    const-string v0, "]"

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v2, "lfttiUupicotionN"

    const-string v2, "UilootuNttafcini"

    const/4 v5, 0x6

    const-string/jumbo v2, "oUfNiitiqoatiltc"

    const-string v2, "NotificationUtil"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v3, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    sparse-switch v2, :sswitch_data_0

    const/4 v5, 0x5

    goto :goto_0

    :sswitch_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v2, "ooshr"

    const-string/jumbo v2, "ooprh"

    const/4 v5, 0x4

    const-string/jumbo v2, "rnomo"

    const-string v2, "honor"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :sswitch_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo v2, "iqomox"

    const-string/jumbo v2, "ioqamx"

    const/4 v5, 0x6

    const-string/jumbo v2, "iaimob"

    const-string/jumbo v2, "xiaomi"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto :goto_0

    :sswitch_2
    const/4 v4, 0x0

    move v5, v4

    const-string/jumbo v2, "uuaewh"

    const-string v2, "huawei"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    packed-switch v3, :pswitch_data_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :pswitch_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p0, v1}, Lo3/f;->A(Landroid/content/Context;I)Z

    const/4 v5, 0x7

    goto :goto_1

    :pswitch_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0, p1, p2}, Lo3/f;->D(Landroid/content/Context;Landroid/app/Notification;I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    goto :goto_1

    :pswitch_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p0, v1}, Lo3/f;->B(Landroid/content/Context;I)V

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :sswitch_data_0
    .sparse-switch
        -0x47e95e19 -> :sswitch_2
        -0x2d450b45 -> :sswitch_1
        0x5edac6a -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static D(Landroid/content/Context;Landroid/app/Notification;I)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 p0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-gtz p2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    move p2, p0

    move p2, p0

    move p2, p0

    move p2, p0

    :cond_1
    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v1, "Nfxtottpriincoais"

    const-string/jumbo v1, "oNstieotcftnirxai"

    const/4 v6, 0x0

    const-string v1, "aenrfiatqoicottix"

    const-string v1, "extraNotification"

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v1, "tssneCeegmusast"

    const-string v1, "esCmuestsotgnea"

    const/4 v6, 0x7

    const-string v1, "geamtsMstneesuo"

    const-string/jumbo v1, "setMessageCount"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, 0x1

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v6, 0x0

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    aput-object v4, v3, p0

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    aput-object p2, v1, p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string p2, "XmoBoaeeaafdNtduiremlsgi ibe"

    const-string p2, "Ba NoXledebsoaeurdeifimmtagi"

    const/4 v6, 0x6

    const-string p2, "aurfabsleBeeNetidi  mgdoabmX"

    const-string/jumbo p2, "setXiaomiBadgeNumber failed "

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string p1, "biNUiiutonotlfta"

    const-string p1, "UoNltbitfinotiia"

    const/4 v6, 0x7

    const-string p1, "ciUnliapNtttfioi"

    const-string p1, "NotificationUtil"

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method

.method public static a(Ljava/lang/String;)[Ljava/lang/String;
    .locals 7

    const/4 v6, 0x4

    const/4 v0, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object v0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x0

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Lorg/json/JSONObject;->length()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-array v2, v2, [Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v4, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v4, Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    aput-object v4, v2, v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v2, "sduryvoeqef arcnToon lJirA"

    const-string/jumbo v2, "rilTnnuAdafreJys arocve oo"

    const/4 v6, 0x2

    const-string/jumbo v2, "iysdoavenaJ c AfTretronosl"

    const-string v2, "convertJsonToArray failed "

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v1, "aNcmiiittUtfnoop"

    const-string v1, "NicoiinptifattoU"

    const/4 v6, 0x0

    const-string/jumbo v1, "intooiiNtfUcioal"

    const-string v1, "NotificationUtil"

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object v0
.end method

.method public static b(Lorg/json/JSONObject;)Landroid/os/Bundle;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object v0

    :cond_0
    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object v0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v1, Landroid/os/Bundle;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v3, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v2, "lBotuTenqdnevfncJoe la odsi"

    const/4 v6, 0x5

    const-string/jumbo v2, "lodiJbloudncon tsan vfTrBee"

    const-string v2, "convertJsonToBundle failed "

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v1, "UitNosuitcoinila"

    const-string/jumbo v1, "itslUctoniiaoNit"

    const/4 v6, 0x0

    const-string/jumbo v1, "oiiUttlpocaiNfit"

    const-string v1, "NotificationUtil"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object v0
.end method

.method public static c(Ljava/util/Map;)Landroid/os/Bundle;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Landroid/os/Bundle;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$BigPictureStyle;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v1, Landroid/app/Notification$BigPictureStyle;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v1}, Landroid/app/Notification$BigPictureStyle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lo3/f;->q(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez p0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1, p0}, Landroid/app/Notification$BigPictureStyle;->bigPicture(Landroid/graphics/Bitmap;)Landroid/app/Notification$BigPictureStyle;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "lPtrlmygqefe  ee giudttibaS"

    const-string/jumbo v1, "lSim  releu idtytbgtaiePfge"

    const-string v1, "gisyli tefb agldtPreui eetS"

    const-string v1, "get bigPictureStyle failed "

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo p1, "iNtaoiUlnicoioft"

    const/4 v3, 0x2

    const-string/jumbo p1, "iicmltUiaNifntot"

    const-string p1, "NotificationUtil"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$BigTextStyle;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    new-instance p0, Landroid/app/Notification$BigTextStyle;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/app/Notification$BigTextStyle;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method public static f(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->i()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->i()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static g(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    and-int/lit8 p0, p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0

    :cond_0
    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    add-int/lit8 p0, p0, -0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p0

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    packed-switch p0, :pswitch_data_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p0, -0x1

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0

    :pswitch_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static h(Landroid/content/Context;[Ljava/lang/String;)Landroid/app/Notification$InboxStyle;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v4, 0x6

    move v5, v4

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v0, :cond_0

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Landroid/app/Notification$InboxStyle;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0}, Landroid/app/Notification$InboxStyle;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    array-length v1, p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-ge v2, v1, :cond_1

    const/4 v5, 0x0

    aget-object v3, p1, v2

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0, v3}, Landroid/app/Notification$InboxStyle;->addLine(Ljava/lang/CharSequence;)Landroid/app/Notification$InboxStyle;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const-string v2, "+  "

    const-string v2, "+  "

    const/4 v5, 0x3

    const-string v2, "+  "

    const-string v2, " + "

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    array-length p1, p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string p1, "gsma bnese ws"

    const/4 v5, 0x6

    const-string/jumbo p1, "ngseowe ms es"

    const-string p1, " new messages"

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/app/Notification$InboxStyle;->setSummaryText(Ljava/lang/CharSequence;)Landroid/app/Notification$InboxStyle;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v0

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "tfdob uxta elySiIglen"

    const/4 v5, 0x0

    const-string/jumbo v1, "ol ynbedelSIbtafxie t"

    const-string v1, "getInboxStyle failed "

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v0, "pfiiNiutoaUnoclt"

    const-string/jumbo v0, "tooilNcpafiitUni"

    const/4 v5, 0x5

    const-string/jumbo v0, "ttoofaipUicinlNi"

    const-string v0, "NotificationUtil"

    const/4 v5, 0x7

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object p0
.end method

.method public static i(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lo3/f;->q(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method private static j(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, ".c.NMnrdq.nioetnaItditAqan"

    const-string v3, "ei.AdoaNqiI.dntnt.nrntMaci"

    const-string v3, "NasainAnMItdcinoone.tt..dr"

    const-string v3, "android.intent.action.MAIN"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo p0, "tesiaeRNCLgcntdt.Err.iUyodnAano."

    const/4 v5, 0x1

    const-string/jumbo p0, "tdtmRa.yanHNEr.tiAr.UnidogneLeCc"

    const-string p0, "android.intent.category.LAUNCHER"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2, p0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/high16 p0, 0x10000

    const/4 v5, 0x5

    invoke-virtual {v1, v2, p0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez p0, :cond_1

    const/4 v5, 0x0

    const/4 p0, 0x0

    const/4 v5, 0x0

    xor-int/2addr v4, p0

    const/4 v5, 0x4

    invoke-virtual {v1, v0, p0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz p0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v1, " escomCtftsegNylhaniiceaalmtvLdauA"

    const-string v1, "eu mhcaCtgmeitaseiNdticyllavfaALns"

    const-string v1, "dciasbteetiga la ahtiLNCmfsevnyAul"

    const-string v1, "getLaunchActivityClassName failed "

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const-string v0, "fcNoiiunttUoailt"

    const-string/jumbo v0, "iiNtoalfniiUotct"

    const/4 v5, 0x2

    const-string/jumbo v0, "itlttfcpiooUNiia"

    const-string v0, "NotificationUtil"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object p0
.end method

.method public static k(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const-string v0, "dabqd"

    const-string v0, "bad_d"

    const/4 v3, 0x0

    const-string v0, "disa_"

    const-string v0, "ad_id"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "us_mig"

    const/4 v3, 0x3

    const-string/jumbo v0, "msim_g"

    const-string/jumbo v0, "msg_id"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "pjg_od_i"

    const-string v0, "_dj_gsip"

    const/4 v3, 0x4

    const-string v0, "dj_m_bgi"

    const-string v0, "_jmsgid_"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public static l(Ljava/lang/String;)I
    .locals 6

    :try_start_0
    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    return p0

    :catchall_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const-string v1, "edsm eu[g hteaI"

    const-string/jumbo v1, "the messageId ["

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v1, "3vrd2e plrwteoa cqi] onlt"

    const-string v1, "ecranwltq2 o] idolrv 3e t"

    const/4 v5, 0x0

    const-string v1, "3 lorlneqc]2v lt ra doiwe"

    const-string v1, "] will convert to adler32"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v1, "NisitnlsaiUfcoot"

    const-string/jumbo v1, "tisotaNiinfcUlot"

    const-string/jumbo v1, "ioUmtltiianfitcN"

    const-string v1, "NotificationUtil"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v0, Ljava/util/zip/Adler32;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/util/zip/Adler32;-><init>()V

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/util/zip/Adler32;->update([B)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/zip/Adler32;->getValue()J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    long-to-int p0, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    if-gez p0, :cond_0

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/lang/Math;->abs(I)I

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return p0

    :catchall_1
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v2, "lndfoN ttdgooIcmei iiitaa"

    const-string v2, "ctemgniaaf id oiilIfttdNo"

    const/4 v5, 0x3

    const-string/jumbo v2, "tfoIebtdinoiN adltcgaifie"

    const-string v2, "getNotificationId failed "

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 p0, 0x0

    const/4 v5, 0x1

    return p0
.end method

.method public static m(Lorg/json/JSONObject;)I
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0}, Lo3/f$a;->b(Lorg/json/JSONObject;)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p0
.end method

.method public static n(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Landroid/widget/RemoteViews;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v0, "otltinuiafNUctio"

    const-string/jumbo v0, "itlcoiUnioNoattf"

    const/4 v7, 0x4

    const-string/jumbo v0, "tnooicNpilfaitti"

    const-string v0, "NotificationUtil"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v7, 0x6

    invoke-static {}, Lo2/t;->c()Lo2/t;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->e()I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v2, p0, v3}, Lo2/t;->b(Landroid/content/Context;I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v3, "aNt:utyeqcn odIidofbutieitoirgbL"

    const-string/jumbo v3, "oiauobtleNd itIetb:fLtucydiignro"

    const/4 v7, 0x0

    const-string/jumbo v3, "nosftcb rliaettteLuodgiiId:uoaiN"

    const-string v3, "getNotificationLayout builderId:"

    const/4 v7, 0x3

    const/4 v6, 0x4

    if-nez v2, :cond_0

    :try_start_1
    const/4 v6, 0x4

    move v7, v6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->e()I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string p1, " ilmiyua otatnfo connsLut,ul"

    const-string/jumbo p1, "nau  fu,lltctsinyLt aiuoinoo"

    const/4 v7, 0x0

    const-string/jumbo p1, "uayconiu,li nnoa stloiiotLf "

    const-string p1, ", notificationLayout is null"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->e()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v3, " oci:bLytatnouoipftai"

    const-string/jumbo v3, "utfnyo pociLiaat,ot:i"

    const-string/jumbo v3, "tti,inuiau oayLno:fto"

    const-string v3, ", notificationLayout:"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v3, Landroid/widget/RemoteViews;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->e()I

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {v3, v4, v5}, Landroid/widget/RemoteViews;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->d()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-lez v4, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->d()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p0}, Lo3/f;->t(Landroid/content/Context;)I

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3, v4, v5}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p0, p1}, Lo3/f;->u(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Landroid/graphics/drawable/Icon;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v4, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->d()I

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v3, v5, v4}, Landroid/widget/RemoteViews;->setImageViewIcon(ILandroid/graphics/drawable/Icon;)V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->h()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-lez v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->h()I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p0, p1}, Lo3/f;->x(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v3, v4, v5}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->a()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-lez v4, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->a()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p0, p1}, Lo3/f;->f(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v4, p0}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_3
    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->g()I

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-lez p0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v2}, Lcom/engagelab/privates/push/api/NotificationLayout;->g()I

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo p1, "pmtsqiT"

    const-string/jumbo p1, "iqTemst"

    const/4 v7, 0x4

    const-string p1, "eqmisTt"

    const-string/jumbo p1, "setTime"

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, p0, p1, v4, v5}, Landroid/widget/RemoteViews;->setLong(ILjava/lang/String;J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-object v3

    :catchall_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const-string/jumbo v2, "lLse itgfoydtNiieastifcao auo"

    const-string v2, " gsleuynatiaLeNoifto odiictaf"

    const/4 v7, 0x5

    const-string v2, "getNotificationLayout failed "

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    return-object v1
.end method

.method public static o(Landroid/content/Context;)Z
    .locals 14

    const/4 v13, 0x2

    const/4 v12, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/16 v1, 0x18

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x0

    const-string/jumbo v2, "tUomiinNiatomift"

    const-string v2, "NtimcifitooiUnta"

    const/4 v13, 0x4

    const-string/jumbo v2, "tocnoiiaotiUitlN"

    const-string v2, "NotificationUtil"

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x1

    const-string v3, "ffantbtitiiolodagNcS et eeai"

    const-string/jumbo v3, "ointoadeait SffiNilege tctoa"

    const/4 v13, 0x1

    const-string/jumbo v3, "t ealtuetttaodfiii anceioNfg"

    const-string v3, "getNotificationState failed "

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x0

    const/4 v4, 0x0

    const/4 v13, 0x6

    if-lt v0, v1, :cond_1

    :try_start_0
    const/4 v13, 0x7

    const-string/jumbo v0, "totbaiopcifn"

    const-string/jumbo v0, "tonitbcnaoif"

    const/4 v13, 0x4

    const-string/jumbo v0, "nfoncioiqitt"

    const-string/jumbo v0, "notification"

    const/4 v13, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x5

    check-cast v0, Landroid/app/NotificationManager;

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x7

    if-nez v0, :cond_0

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    return v4

    :cond_0
    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-static {v0}, Landroidx/core/app/y3;->a(Landroid/app/NotificationManager;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    return p0

    :catchall_0
    move-exception v0

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-static {v2, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :try_start_1
    const/4 v12, 0x6

    move v13, v12

    const-string/jumbo v0, "opsasu"

    const-string/jumbo v0, "usopap"

    const/4 v13, 0x5

    const-string/jumbo v0, "opsmpp"

    const-string v0, "appops"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x6

    check-cast v0, Landroid/app/AppOpsManager;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x4

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v13, 0x5

    const-class v5, Landroid/app/AppOpsManager;

    const-class v5, Landroid/app/AppOpsManager;

    const/4 v13, 0x1

    const-class v5, Landroid/app/AppOpsManager;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x2

    const/4 v12, 0x3

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-string v6, "epohoccoTOrNwk"

    const-string/jumbo v6, "ooehrwcpOchkTN"

    const/4 v13, 0x0

    const-string v6, "crNoTbkchhpoeO"

    const-string v6, "checkOpNoThrow"

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v7, 0x3

    move v13, v7

    :try_start_2
    const/4 v12, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x4

    new-array v8, v7, [Ljava/lang/Class;

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x7

    sget-object v9, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x5

    aput-object v9, v8, v4

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/4 v10, 0x1

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x2

    aput-object v9, v8, v10

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x3

    const-class v9, Ljava/lang/String;

    const-class v9, Ljava/lang/String;

    const/4 v13, 0x4

    const-class v9, Ljava/lang/String;

    const-class v9, Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x1

    const/4 v11, 0x2

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x2

    aput-object v9, v8, v11

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v5, v6, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x3

    const-string v8, "OFPNTOuOqI_NC_STAOPT"

    const-string v8, "TNOIOOOFq_NSTPI_CPTA"

    const/4 v13, 0x6

    const-string v8, "FTNON_ApP_ICOOSIIOPT"

    const-string v8, "OP_POST_NOTIFICATION"

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v5, v8}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x3

    const-class v8, Ljava/lang/Integer;

    const-class v8, Ljava/lang/Integer;

    const/4 v13, 0x7

    const-class v8, Ljava/lang/Integer;

    const-class v8, Ljava/lang/Integer;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-virtual {v5, v8}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x5

    check-cast v5, Ljava/lang/Integer;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x5

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x4

    aput-object v5, v7, v4

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x5

    aput-object v1, v7, v10

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x0

    aput-object p0, v7, v11

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v6, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v13, 0x1

    const/4 v12, 0x3

    check-cast p0, Ljava/lang/Integer;

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x0

    if-nez p0, :cond_2

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x0

    move v4, v10

    move v4, v10

    const/4 v13, 0x1

    move v4, v10

    move v4, v10

    :cond_2
    const/4 v13, 0x2

    const/4 v12, 0x6

    return v4

    :catchall_1
    move-exception p0

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x4

    return v4
.end method

.method public static p(Landroid/content/Context;Ljava/lang/String;Lcom/engagelab/privates/push/api/NotificationMessage;)Landroid/app/PendingIntent;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-class v1, Lcom/engagelab/privates/common/component/MTCommonActivity;

    const-class v1, Lcom/engagelab/privates/common/component/MTCommonActivity;

    const/4 v3, 0x6

    const-class v1, Lcom/engagelab/privates/common/component/MTCommonActivity;

    const-class v1, Lcom/engagelab/privates/common/component/MTCommonActivity;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/high16 p1, 0x10800000

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance p1, Landroid/os/Bundle;

    const/4 v3, 0x3

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "message"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->x()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/high16 p2, 0x4000000

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, p1, v0, p2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0
.end method

.method public static q(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v0, "cnosfUiaqiotNlit"

    const-string v0, "UislttfoioinciaN"

    const/4 v6, 0x2

    const-string v0, "Uostiintlctiofai"

    const-string v0, "NotificationUtil"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x2

    sget-object v2, Landroid/util/Patterns;->WEB_URL:Ljava/util/regex/Pattern;

    const/4 v6, 0x0

    invoke-virtual {v2, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/util/regex/Matcher;->matches()Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1}, Landroid/webkit/URLUtil;->isValidUrl(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v3, "eramlbdm"

    const-string/jumbo v3, "rdamalbe"

    const/4 v6, 0x5

    const-string v3, "aldworba"

    const-string v3, "drawable"

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v2, p1, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {p0, p1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Runtime;->gc()V

    const/4 v6, 0x7

    return-object p0

    :cond_1
    :goto_0
    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v2, Lo3/a;

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-direct {v2}, Lo3/a;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2, p0, p1}, Lo3/a;->a(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez p0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo p0, "rogn bsytlecut  bueltiPi"

    const-string/jumbo p0, "ssugoit Pcnit y lreetlbu"

    const/4 v6, 0x0

    const-string p0, "gbrt iusslteune Pt yeicl"

    const-string p0, "getPicture bytes is null"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/lang/Runtime;->gc()V

    const/4 v6, 0x6

    return-object v1

    :cond_2
    :try_start_3
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    array-length p1, p0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    move v6, v5

    invoke-static {p0, v2, p1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Runtime;->gc()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_4
    const/4 v6, 0x7

    const/4 v5, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v2, "aiueplepitmct gd B aerbti"

    const-string/jumbo v2, "matecbtge lip B uirtdipea"

    const/4 v6, 0x0

    const-string v2, "fli  mrtq Btuiaeeeitpcgpa"

    const-string v2, "get pictureBitmap failed "

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/Runtime;->gc()V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/Runtime;->gc()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p0
.end method

.method public static r(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 p0, -0x1

    move v2, p0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eq p1, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq p1, p0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    const/4 p0, 0x1

    shl-int/2addr v2, p0

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    if-eq p1, p0, :cond_1

    const/4 v2, 0x6

    const/4 p0, 0x2

    const/4 v2, 0x5

    shl-int/2addr v1, p0

    const/4 v2, 0x7

    if-eq p1, p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p0
.end method

.method public static s(Lorg/json/JSONObject;)I
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0}, Lo3/f$a;->f(Lorg/json/JSONObject;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p0
.end method

.method public static t(Landroid/content/Context;)I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v2, "nhstnmu_ificsi_cnotoopua"

    const-string v2, "cotitnuitac_foiohmnunsp_"

    const/4 v5, 0x5

    const-string/jumbo v2, "mtpush_notification_icon"

    const/4 v4, 0x3

    move v5, v4

    const-string/jumbo v3, "rpwmadeb"

    const-string/jumbo v3, "rawdbaep"

    const/4 v5, 0x1

    const-string v3, "aldroebw"

    const-string v3, "drawable"

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-lez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v4, 0x7

    move v5, v4

    const/4 v0, 0x0

    move v5, v0

    :try_start_0
    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, p0, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->icon:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v2, "ee mab dltogilSg afecItn"

    const-string v2, "get getSmallIcon failed "

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const-string/jumbo v1, "ointttuoflUcaNiq"

    const-string/jumbo v1, "oftloiUtqtaNnici"

    const/4 v5, 0x7

    const-string/jumbo v1, "iiNctonptUitfilo"

    const-string v1, "NotificationUtil"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string p0, "f einss qitoet_ci rpcpnbisaauseelo tp howdo/cinnmial_na]ru"

    const-string p0, "cusi op[eonsra u_t lepedmcina/ainii lbnistt]r chw_onfaopes"

    const/4 v5, 0x1

    const-string/jumbo p0, "please put icon [mtpush_notification_icon] in res/drawable"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v0
.end method

.method public static u(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Landroid/graphics/drawable/Icon;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->C()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->C()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lo3/f;->q(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Landroid/graphics/drawable/Icon;->createWithBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v1, " tscmi lnalgeolSefad"

    const-string v1, "getSmallIcon failed "

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const-string/jumbo p1, "iUomlinmtoitctNf"

    const-string/jumbo p1, "ttNmlctoniiUifoi"

    const/4 v3, 0x2

    const-string/jumbo p1, "ttitoUiNfliiooca"

    const-string p1, "NotificationUtil"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public static v(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)Landroid/net/Uri;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v0, "Ulttobftiioocian"

    const-string v0, "alifonciiootttiU"

    const/4 v6, 0x6

    const-string v0, "NifitnuUiioalctt"

    const-string v0, "NotificationUtil"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-object v1

    :cond_0
    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz p1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object v1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v3, "awr"

    const-string/jumbo v3, "wra"

    const/4 v6, 0x6

    const-string v3, "awr"

    const-string/jumbo v3, "raw"

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string/jumbo p0, "rhserrep cne oso broeudeau "

    const-string p0, " doehbneecto uesarerr  srou"

    const/4 v6, 0x6

    const-string p0, "eeas nreq e  ornrduueoohrcs"

    const-string/jumbo p0, "there are no sound resource"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object v1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "ods/euu.ie/ordsc:an"

    const-string v2, "a:/cnuud.ooer/risde"

    const/4 v6, 0x3

    const-string v2, "android.resource://"

    const/4 v6, 0x4

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo p0, "w/rmp"

    const-string p0, "/wp/r"

    const/4 v6, 0x4

    const-string p0, "a/wro"

    const-string p0, "/raw/"

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    move v6, v5

    const-string p2, "gi ofb lSqntaideueU"

    const-string p2, " dnfUgeSqii oluatde"

    const/4 v6, 0x7

    const-string p2, "deageiuofltU inSu d"

    const-string p2, "getSoundUri failed "

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v5, 0x0

    return-object v1
.end method

.method public static w(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Landroid/app/Notification$Style;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->E()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eq v0, v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 p0, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->c()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lo3/f;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$BigPictureStyle;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_1
    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->r()[Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lo3/f;->h(Landroid/content/Context;[Ljava/lang/String;)Landroid/app/Notification$InboxStyle;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lo3/f;->e(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$BigTextStyle;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0
.end method

.method public static x(Landroid/content/Context;Lcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->F()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, p0}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationMessage;->F()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public static y(Landroid/content/Context;ZLcom/engagelab/privates/push/api/NotificationMessage;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p0, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    return p0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, -0x2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-eq p1, p2, :cond_1

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eq p1, p0, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-eq p1, p0, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 p2, 0x2

    shl-int/2addr v1, p2

    const/4 v0, 0x7

    move v1, v0

    if-eq p1, p2, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p0, 0x0

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p0
.end method

.method public static z(Landroid/content/Context;)Z
    .locals 7

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/16 v1, 0x1a

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/high16 v3, 0x10000000

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v4, "nrFA_TNpoT_OitAISTNSstsN.I.TGOPCPsIeIaidgE"

    const-string/jumbo v4, "insNE.oIA_S_dGTTtTsINIdtFSagIesiOAN.OrPTPC"

    const/4 v6, 0x7

    const-string v4, "As.diNNTqS_nAPtIr_OGtFTIIINsT.PESaCeOndgTi"

    const-string v4, "android.settings.APP_NOTIFICATION_SETTINGS"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-lt v0, v1, :cond_0

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v4}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v1, "_esrrErdmiAi.aGPor.dxvP.AdKoaCAnPe"

    const-string v1, "eoPm.rdxadPKnA_a.GpCAdioEirvrPeAr."

    const/4 v6, 0x1

    const-string/jumbo v1, "pximadaeA..rAdAGePEvdoPP.ro_iKrtnr"

    const-string v1, "android.provider.extra.APP_PACKAGE"

    :try_start_2
    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v1, "eDvaonpxidIra_riEtAooCLd.NrNoerH."

    const-string v1, "LAvEoaneirIi.e_NoCHDpaxod.rrr.Ntd"

    const/4 v6, 0x1

    const-string v1, "dDi_vboAtaLi.Nd.CxnINeHroaeEprrr."

    const-string v1, "android.provider.extra.CHANNEL_ID"

    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v4, v4, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    return v2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v4}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v1, "a_eappucgpk"

    const-string v1, "app_package"

    :try_start_4
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v1, "pd_appb"

    const-string/jumbo v1, "i_apdbp"

    const/4 v6, 0x4

    const-string v1, "dqupp_a"

    const-string v1, "app_uid"

    :try_start_5
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v4, v4, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v5, 0x4

    or-int/2addr v6, v5

    invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    return v2

    :catchall_0
    move-exception p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, "Tisdioiinfp nuooSlgceigfto astptaeN"

    const-string/jumbo v1, "lpf NiutgodooSasAietgaiip onTtnecfi"

    const/4 v6, 0x6

    const-string v1, "eiamo gosdgfociNpntiofA ipeTlntatit"

    const-string v1, "goToAppNotificationSettings failed "

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string v0, "ciitopiafointtlU"

    const-string/jumbo v0, "nUtofiipaclNitit"

    const/4 v6, 0x3

    const-string/jumbo v0, "itnoUbitNfloicti"

    const-string v0, "NotificationUtil"

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 p0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    return p0
.end method
