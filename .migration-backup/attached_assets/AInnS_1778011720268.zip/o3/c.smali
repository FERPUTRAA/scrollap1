.class public final synthetic Lo3/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s@ b~ Kbo~o~~fsv~~l~r@~oti~o b~S@~ @/~~o/~ ~@c~4@-y~mo @ @@@~@@n@. ~i@  ~@ @1i@f@ld~u~ M @ at "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setImportance(I)V

    const/4 v1, 0x5

    return-void
.end method
