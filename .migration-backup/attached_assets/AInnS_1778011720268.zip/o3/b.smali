.class public Lo3/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Lcom/engagelab/privates/push/api/AliasMessage;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@us @ @~/o@~b~y @~oao ~~@fd~~m @fvo@~ liK@4~ s ~~~/1n~.@~i   @@ @ @@~@~@~~Sto~~cr -~  Mb@o @@bil"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v1, "isams"

    const-string/jumbo v1, "slsai"

    const/4 v4, 0x6

    const-string/jumbo v1, "isalo"

    const-string v1, "alias"

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/AliasMessage;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "ecod"

    const/4 v4, 0x3

    const-string v1, "eocd"

    const-string v1, "code"

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/AliasMessage;->c()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "qecmsuee"

    const-string/jumbo v1, "qesuebcn"

    const-string/jumbo v1, "sequence"

    :try_start_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/AliasMessage;->d()I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0
.end method

.method private static b([Ljava/lang/String;)Lorg/json/JSONArray;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v0, Lorg/json/JSONArray;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    array-length v1, p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    aget-object v3, p0, v2

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object v0
.end method

.method public static c(Z)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "lenboe"

    const/4 v3, 0x6

    const-string/jumbo v1, "uealen"

    const-string v1, "enable"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method

.method private static d(Landroid/os/Bundle;)Lorg/json/JSONObject;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v5, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz p0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v0
.end method

.method public static e(Lcom/engagelab/privates/push/api/CustomMessage;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "pnecbtt"

    const-string v1, "cetntbn"

    const/4 v4, 0x4

    const-string v1, "cqnteon"

    const-string v1, "content"

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->a()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v1, "tosnyenceTu"

    const-string v1, "eeTyptuonnc"

    const/4 v4, 0x3

    const-string/jumbo v1, "tepmtceynTn"

    const-string v1, "contentType"

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->c()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "gsdsoImae"

    const-string/jumbo v1, "masedsgpI"

    const/4 v4, 0x6

    const-string v1, "Ieessbmdg"

    const-string/jumbo v1, "messageId"

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->e()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "faorlpum"

    const-string/jumbo v1, "qfmlproa"

    const/4 v4, 0x7

    const-string/jumbo v1, "olfrpamp"

    const-string/jumbo v1, "platform"

    :try_start_3
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->g()B

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "etpfsagmqMrdlIssa"

    const-string v1, "MIsgstdaeeapfrslm"

    const/4 v4, 0x2

    const-string/jumbo v1, "laseprmoIesgfsatM"

    const-string/jumbo v1, "platformMessageId"

    :try_start_4
    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "tltmi"

    const-string/jumbo v1, "itlmt"

    const/4 v4, 0x5

    const-string/jumbo v1, "ttleo"

    const-string/jumbo v1, "title"

    :try_start_5
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->i()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/CustomMessage;->d()Landroid/os/Bundle;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Lo3/b;->d(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "esrtxb"

    const-string/jumbo v1, "rsxeot"

    const/4 v4, 0x1

    const-string v1, "extras"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p0
.end method

.method public static f(Lcom/engagelab/privates/push/api/NotificationMessage;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "gudeb"

    const-string v1, "bdgeb"

    const/4 v4, 0x5

    const-string v1, "ebpdg"

    const-string v1, "badge"

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->a()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const-string v1, "bigPicture"

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->c()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "eqiTbxt"

    const-string v1, "bigText"

    :try_start_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "rusbiIldu"

    const-string v1, "beruliuId"

    const/4 v4, 0x5

    const-string/jumbo v1, "luimdbedr"

    const-string v1, "builderId"

    :try_start_3
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->e()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v1, "ecrtgyap"

    const/4 v4, 0x3

    const-string/jumbo v1, "rgeyooct"

    const-string v1, "category"

    :try_start_4
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->g()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "nIaedbqhn"

    const-string/jumbo v1, "nndlehIaq"

    const/4 v4, 0x0

    const-string/jumbo v1, "lecahdunn"

    const-string v1, "channelId"

    :try_start_5
    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "posectn"

    const-string/jumbo v1, "tnsotec"

    const/4 v4, 0x2

    const-string v1, "cqtenno"

    const-string v1, "content"

    :try_start_6
    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->i()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_6
    .catch Lorg/json/JSONException; {:try_start_6 .. :try_end_6} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "afumdlts"

    const/4 v4, 0x6

    const-string v1, "easfdlts"

    const-string v1, "defaults"

    :try_start_7
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->k()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->o()Landroid/os/Bundle;

    move-result-object v1
    :try_end_7
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_7} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v2, "saomte"

    const-string/jumbo v2, "sxtaoe"

    const/4 v4, 0x5

    const-string/jumbo v2, "ratsoe"

    const-string v2, "extras"

    :try_start_8
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v1}, Lo3/b;->d(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->r()[Ljava/lang/String;

    move-result-object v1
    :try_end_8
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_8} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v2, "bbxni"

    const-string v2, "boixn"

    const/4 v4, 0x6

    const-string/jumbo v2, "nuoxb"

    const-string/jumbo v2, "inbox"

    :try_start_9
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1}, Lo3/b;->b([Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_9
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_9} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, "Sleuintps"

    const-string/jumbo v1, "iSsnelutn"

    const/4 v4, 0x5

    const-string v1, "Sttsnnelq"

    const-string/jumbo v1, "intentSsl"

    :try_start_a
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->s()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_a
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_a} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "tUsnrpnei"

    const-string v1, "eUrintnpt"

    const/4 v4, 0x7

    const-string/jumbo v1, "intentUri"

    :try_start_b
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->u()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_b
    .catch Lorg/json/JSONException; {:try_start_b .. :try_end_b} :catch_0

    const/4 v4, 0x4

    const-string v1, "Ingmrcale"

    const-string/jumbo v1, "ngerIlcaq"

    const/4 v4, 0x6

    const-string/jumbo v1, "laIgonrec"

    const-string/jumbo v1, "largeIcon"

    :try_start_c
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->v()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_c
    .catch Lorg/json/JSONException; {:try_start_c .. :try_end_c} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "eadIsbesg"

    const-string/jumbo v1, "messageId"

    :try_start_d
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->w()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_d
    .catch Lorg/json/JSONException; {:try_start_d .. :try_end_d} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v1, "Iotcotufdiiian"

    const-string/jumbo v1, "notificationId"

    :try_start_e
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->x()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_e
    .catch Lorg/json/JSONException; {:try_start_e .. :try_end_e} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "esdIderpeMsoviare"

    const-string/jumbo v1, "rvsaeMgdedorIeeis"

    const/4 v4, 0x2

    const-string v1, "eiddMerIqasereogv"

    const-string/jumbo v1, "overrideMessageId"

    :try_start_f
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->y()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_f
    .catch Lorg/json/JSONException; {:try_start_f .. :try_end_f} :catch_0

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v1, "pfsmltmo"

    const-string/jumbo v1, "otamlpfm"

    const/4 v4, 0x2

    const-string/jumbo v1, "olfmtapr"

    const-string/jumbo v1, "platform"

    :try_start_10
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->z()B

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_10
    .catch Lorg/json/JSONException; {:try_start_10 .. :try_end_10} :catch_0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "ssfroMadtIeapoemo"

    const-string/jumbo v1, "trlpoamadIsfMosee"

    const/4 v4, 0x7

    const-string v1, "gaeatbdpmlfIrsoMe"

    const-string/jumbo v1, "platformMessageId"

    :try_start_11
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->A()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_11
    .catch Lorg/json/JSONException; {:try_start_11 .. :try_end_11} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "yiprbtui"

    const-string/jumbo v1, "iiortbpy"

    const/4 v4, 0x0

    const-string/jumbo v1, "priority"

    :try_start_12
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->B()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_12
    .catch Lorg/json/JSONException; {:try_start_12 .. :try_end_12} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "otapcrnpei"

    const-string/jumbo v1, "importance"

    :try_start_13
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->q()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_13
    .catch Lorg/json/JSONException; {:try_start_13 .. :try_end_13} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v1, "lluIsacoq"

    const-string/jumbo v1, "olmIlsuac"

    const-string/jumbo v1, "smallIcon"

    :try_start_14
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->C()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_14
    .catch Lorg/json/JSONException; {:try_start_14 .. :try_end_14} :catch_0

    const/4 v3, 0x1

    move v4, v3

    const-string/jumbo v1, "sospu"

    const-string/jumbo v1, "oupds"

    const/4 v4, 0x6

    const-string/jumbo v1, "usnmo"

    const-string/jumbo v1, "sound"

    :try_start_15
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->D()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_15
    .catch Lorg/json/JSONException; {:try_start_15 .. :try_end_15} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "qyeso"

    const-string/jumbo v1, "yleqs"

    const/4 v4, 0x4

    const-string v1, "btsle"

    const-string/jumbo v1, "style"

    :try_start_16
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->E()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_16
    .catch Lorg/json/JSONException; {:try_start_16 .. :try_end_16} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v1, "tutes"

    const-string/jumbo v1, "tesit"

    const/4 v4, 0x6

    const-string/jumbo v1, "ttpli"

    const-string/jumbo v1, "title"

    :try_start_17
    const/4 v3, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/NotificationMessage;->F()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_17
    .catch Lorg/json/JSONException; {:try_start_17 .. :try_end_17} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p0
.end method

.method public static g(Lcom/engagelab/privates/push/api/PlatformTokenMessage;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "qomamprl"

    const-string v1, "frlmpamo"

    const/4 v4, 0x4

    const-string v1, "afsmtlro"

    const-string/jumbo v1, "platform"

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v1, "koomn"

    const-string v1, "eokno"

    const/4 v4, 0x7

    const-string/jumbo v1, "oketo"

    const-string/jumbo v1, "token"

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0
.end method

.method public static h(Lcom/engagelab/privates/push/api/TagMessage;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const-string/jumbo v1, "oced"

    const-string v1, "doce"

    const/4 v4, 0x7

    const-string v1, "cdoe"

    const-string v1, "code"

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/TagMessage;->c()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "euqarbyg"

    const-string/jumbo v1, "yuaeqbrg"

    const/4 v4, 0x0

    const-string v1, "agTuyqur"

    const-string/jumbo v1, "queryTag"

    :try_start_1
    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/TagMessage;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "qnecusep"

    const-string v1, "eeqsncue"

    const/4 v4, 0x5

    const-string/jumbo v1, "qnquesce"

    const-string/jumbo v1, "sequence"

    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/TagMessage;->e()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/engagelab/privates/push/api/TagMessage;->g()[Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Lo3/b;->b([Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "gast"

    const-string/jumbo v1, "sgat"

    const/4 v4, 0x4

    const-string v1, "gsta"

    const-string/jumbo v1, "tags"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p0
.end method
