.class public final Lk1/a;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lh1/b;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:Lh1/a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final c:Lj1/a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:Z

.field private l:Z

.field private m:Z


# direct methods
.method public constructor <init>(Lj1/a;Lh1/b;Lh1/a;)V
    .locals 3
    .param p1    # Lj1/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lh1/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lh1/a;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "oesttnsiksrrtPosalecliSn"

    const-string/jumbo v0, "ossoanrScttPrkeistllienc"

    const/4 v2, 0x2

    const-string v0, "cPemrilSennctotrlaisktoy"

    const-string/jumbo v0, "stickyScrollPresentation"

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "ioefonodersecrIPmn"

    const-string v0, "eeimfenrcnodPosIvr"

    const/4 v2, 0x3

    const-string/jumbo v0, "odveebroecrsfnnirI"

    const-string/jumbo v0, "screenInfoProvider"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const-string v0, "PtevdoupcouodrayieeAerrRrs"

    const-string v0, "PpydotaeiucordevResAryrroe"

    const/4 v2, 0x7

    const-string/jumbo v0, "sPeryvoppreraetddAecuRiryo"

    const-string/jumbo v0, "typedArrayResourceProvider"

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {p3, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p2, p0, Lk1/a;->a:Lh1/b;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p3, p0, Lk1/a;->b:Lh1/a;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    iput-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p2}, Lh1/b;->b()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lk1/a;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p2}, Lh1/b;->a()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p1, p0, Lk1/a;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private final c(I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "vr~~yM~nqi-@@o@~@ c~~.@~ oK a~@~u~@@~@~@~d~b@@ @o@o Sf4t @ s ~/b~@~l~o   @l i ~1 f~@io @b~t/@ ~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p0, Lk1/a;->g:I

    const/4 v2, 0x0

    move v3, v2

    iget v1, p0, Lk1/a;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    sub-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget v1, p0, Lk1/a;->e:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-le p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1}, Lj1/a;->d()V

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x4

    shr-int/2addr v2, p1

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lk1/a;->f:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v1, p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lj1/a;->e(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 p1, 0x1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-boolean p1, p0, Lk1/a;->k:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private final d(I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lk1/a;->h:I

    const/4 v3, 0x3

    if-le p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    sub-int/2addr p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v1, p1}, Lj1/a;->a(I)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-interface {p1}, Lj1/a;->g()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean p1, p0, Lk1/a;->l:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lk1/a;->j:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public final b()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget-boolean v0, p0, Lk1/a;->m:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public final e(Ljava/lang/Integer;I)V
    .locals 4
    .param p1    # Ljava/lang/Integer;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput p1, p0, Lk1/a;->e:I

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    iget p1, p0, Lk1/a;->i:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    sub-int/2addr p2, p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput p2, p0, Lk1/a;->g:I

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget p1, p0, Lk1/a;->d:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    sub-int v0, p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, p0, Lk1/a;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v0, p0, Lk1/a;->f:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    sub-int/2addr p1, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-le p2, p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lj1/a;->e(I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-boolean p1, p0, Lk1/a;->k:Z

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public final f(Ljava/lang/Integer;)V
    .locals 2
    .param p1    # Ljava/lang/Integer;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 p1, 0x0

    shr-int/2addr v1, p1

    const/4 v0, 0x7

    const/4 v0, 0x4

    iput p1, p0, Lk1/a;->h:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lk1/a;->h:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public final g()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lk1/a;->k:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public final h()Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-boolean v0, p0, Lk1/a;->l:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public final i(II)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lk1/a;->a:Lh1/b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0}, Lh1/b;->a()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lk1/a;->j:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    sub-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    iput v1, p0, Lk1/a;->i:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v0, p0, Lk1/a;->j:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lk1/a;->b:Lh1/a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lh1/a;->b(I)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lj1/a;->b(I)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lk1/a;->b:Lh1/a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1, p2}, Lh1/a;->b(I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    iget-object p2, p0, Lk1/a;->c:Lj1/a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p2, p1}, Lj1/a;->f(I)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p0, Lk1/a;->b:Lh1/a;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1}, Lh1/a;->a()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public final j(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lk1/a;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lk1/a;->c(I)V

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lk1/a;->d(I)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public final k(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-boolean v0, p0, Lk1/a;->m:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lk1/a;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    sub-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lk1/a;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lk1/a;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sub-int/2addr v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget p1, p0, Lk1/a;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sub-int/2addr v0, p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lk1/a;->f:I

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lk1/a;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v0, p1}, Lk1/a;->e(Ljava/lang/Integer;I)V

    :goto_0
    const/4 v2, 0x3

    iget-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {p1}, Lj1/a;->c()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lk1/a;->c(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public final l(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lk1/a;->f(Ljava/lang/Integer;)V

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p1, p0, Lk1/a;->c:Lj1/a;

    const/4 v1, 0x2

    invoke-interface {p1}, Lj1/a;->c()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-direct {p0, p1}, Lk1/a;->d(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public final m(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput p1, p0, Lk1/a;->j:I

    const/4 v1, 0x1

    return-void
.end method

.method public final n(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-boolean p1, p0, Lk1/a;->m:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
