.class public Lo2/e;
.super Ljava/lang/Object;


# static fields
.field public static a:Landroid/content/SharedPreferences;


# direct methods
.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~os a@r ui@~@~~@~n  SM.~~~l@@1~tb~bo@-~s@@/c@  ~~y ~od~@ @@f@ftov /@@@4o Ki ~l~ ~b~i @m @~ o@  ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    invoke-static {p0}, Lo2/e;->e(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "soem_tmak_tprafilfl"

    const-string/jumbo v0, "tosp_kfael_tfimorla"

    const/4 v3, 0x6

    const-string/jumbo v0, "olt_orfinmektfoal_a"

    const-string/jumbo v0, "platform_token_fail"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0
.end method

.method public static b(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p0}, Lo2/e;->e(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "ae_imborrfmpnlftmto_k_la"

    const-string/jumbo v0, "mrfmnaoa_oimoetf_tlpl_rk"

    const/4 v2, 0x2

    const-string/jumbo v0, "tla_moutkm_rnefoaofli_pr"

    const-string/jumbo v0, "platform_token_fail_from"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v1, 0x5

    or-int/2addr v2, v1

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Lo2/e;->e(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "amtnrolpfoolktafpie"

    const-string/jumbo v0, "lrtoolnap_okmffiate"

    const/4 v2, 0x0

    const-string/jumbo v0, "lmkorft_q_ofnalaeti"

    const-string/jumbo v0, "platform_token_fail"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static d(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0}, Lo2/e;->e(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "afsfpt_lnoolibrrae_mtofk"

    const-string/jumbo v0, "lfaeab_tpkrfmoo__ntiorlf"

    const/4 v3, 0x2

    const-string/jumbo v0, "r_oma_llmfaoi_nofretkftm"

    const-string/jumbo v0, "platform_token_fail_from"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p0
.end method

.method public static e(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lo2/e;->a:Landroid/content/SharedPreferences;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v0, "ete.ofpvurmn.ba.a.aclmerrlppgegihaosts.pos"

    const-string v0, "com.engagelab.privates.push.prefs.platform"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object p0, Lo2/e;->a:Landroid/content/SharedPreferences;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object p0, Lo2/e;->a:Landroid/content/SharedPreferences;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0
.end method
