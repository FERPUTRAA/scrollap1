.class public Lo2/v;
.super Ljava/lang/Object;


# static fields
.field public static volatile a:Lo2/v;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static a()Lo2/v;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~~o@~~sb@/~@K @@@vffc oo@~~1lt~ b b~@@@@i~~@ uao4n~@/ ~m o .dy  ~ ~M~~ @@ @l ~~~@@ rit@ ~S-oi"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lo2/v;->a:Lo2/v;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-class v0, Lo2/v;

    const-class v0, Lo2/v;

    const/4 v3, 0x1

    const-class v0, Lo2/v;

    const-class v0, Lo2/v;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v1, Lo2/v;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v1}, Lo2/v;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    sput-object v1, Lo2/v;->a:Lo2/v;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lo2/v;->a:Lo2/v;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method public final b(Landroid/content/Context;IJ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p2, p3, p4}, Lo2/g;->b(IJ)[B

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    new-instance p3, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p3}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p4, 0x4

    const/4 v1, 0x4

    invoke-virtual {p3, p4}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p4, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p3, p4}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    sget-object p3, Li3/a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    new-instance p3, Landroid/os/Bundle;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const-string/jumbo p4, "roslpoto"

    const/4 v1, 0x4

    const-string/jumbo p4, "tolmcpoo"

    const-string/jumbo p4, "protocol"

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p3, p4, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/16 p2, 0x8ae

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public c(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, "enmoogcf"

    const-string v0, "eogmefnc"

    const/4 v10, 0x5

    const-string v0, "enoefbec"

    const-string v0, "geofence"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string v1, "MsesoeBsauessnTgM"

    const/4 v10, 0x0

    const-string v1, "MueBsnuseisasgseT"

    const-string v1, "MTMessageBusiness"

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string/jumbo v2, "loobcopp"

    const-string/jumbo v2, "rcloobop"

    const/4 v10, 0x6

    const-string/jumbo v2, "qtoooplr"

    const-string/jumbo v2, "protocol"

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {p2, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {p2}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v5, Ljava/io/LineNumberReader;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-instance v6, Ljava/io/StringReader;

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-direct {v6, p2}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-direct {v5, v6}, Ljava/io/LineNumberReader;-><init>(Ljava/io/Reader;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v5}, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v5}, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v5}, Ljava/io/LineNumberReader;->readLine()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {p2, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string v8, "]"

    const/4 v10, 0x2

    const-string v8, "]"

    const-string v8, "]"

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez v7, :cond_0

    :try_start_1
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string v0, "cIso lpsaetna[hiupeag mis  esd"

    const-string v0, "etmesau cIs hiasio[ ega ldppin"

    const-string v0, "Ipimotald ieset csem[hings a p"

    const-string/jumbo v0, "the message applicationId is ["

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-void

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    invoke-static {p1}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {v6, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez p2, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string/jumbo p2, "il noeceeymhpasa[sig Kppote ast"

    const-string/jumbo p2, "papeaslpoe ic eietaKi tgs[hynms"

    const/4 v10, 0x2

    const-string p2, "[pih bepseeyctsaK l aiai stonem"

    const-string/jumbo p2, "the message applicationKey is ["

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-void

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz p2, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo p1, "mg  eeshqimtepeays t"

    const-string p1, "eais tum geptey hses"

    const-string/jumbo p1, "the message is empty"

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    return-void

    :cond_2
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    new-instance p2, Lorg/json/JSONObject;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {p2, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string/jumbo v5, "opnl_n"

    const-string/jumbo v5, "nnslo_"

    const/4 v10, 0x4

    const-string/jumbo v5, "n_only"

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p2, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string v6, "hetpyos_q"

    const-string/jumbo v6, "show_type"

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p2, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p0, p1, v2, v3, v4}, Lo2/v;->b(Landroid/content/Context;IJ)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p2}, Lo2/y;->a(Lorg/json/JSONObject;)Lo2/y;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {p1, v2}, Lo2/a0;->c(Landroid/content/Context;Lo2/y;)Z

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v2, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-void

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance v2, Landroid/os/Bundle;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v3, "esgmame"

    const/4 v10, 0x2

    const-string/jumbo v3, "saseegs"

    const-string/jumbo v3, "message"

    :try_start_2
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const-string v4, ":asmgeoMen"

    const-string v4, ":esaonMgse"

    const/4 v10, 0x6

    const-string/jumbo v4, "sgo:oaseMe"

    const-string/jumbo v4, "onMessage:"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {p2}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v3, :cond_4

    const/4 v10, 0x1

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x7

    if-eqz p2, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v0, "ednecbfieo"

    const-string v0, "geofenceid"

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-nez p2, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string p2, "ffeei uob ecitiongnstnca"

    const-string/jumbo p2, "tsneobne ieffi ccgaiotno"

    const/4 v10, 0x2

    const-string/jumbo p2, "tong cnpieciiieoto nesfa"

    const-string/jumbo p2, "is geofence notification"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {v1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    const/16 p2, 0xf29

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {p1, p2, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-void

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const-string v0, "ey=a peuqsngtoM"

    const-string v0, "M ynotupe=sgase"

    const/4 v10, 0x6

    const-string/jumbo v0, "onMessage type="

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v0, " gsl=p"

    const-string v0, "=p lgf"

    const/4 v10, 0x2

    const-string v0, "a gm=l"

    const-string v0, " flag="

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v1, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 p2, 0x4

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-ne v6, p2, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {p2, p1, v2}, Lo2/x;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {}, Lo2/w;->e()Lo2/w;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v2}, Lo2/w;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    return-void

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 p2, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-ne v5, p2, :cond_6

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {}, Lo2/x;->r()Lo2/x;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v2}, Lo2/x;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    return-void

    :cond_6
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-nez v5, :cond_7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {}, Lo2/w;->e()Lo2/w;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p2, p1, v2}, Lo2/w;->c(Landroid/content/Context;Landroid/os/Bundle;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string v0, "aagfoni qeeesol M"

    const-string v0, " osdaefMqeeni lga"

    const/4 v10, 0x0

    const-string v0, " fsolbeeengMasadi"

    const-string/jumbo v0, "onMessage failed "

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void
.end method
