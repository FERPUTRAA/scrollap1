.class public Lo2/m;
.super Ljava/lang/Object;


# direct methods
.method public static a()Lo2/k;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tis@ /~  d~v@ ~4m~~oo@~@~ /nlr~.  y@@~bi@@u~  t@i f~o1~ @ bK@@MS~ @@~o b~~c@~@~@s~@ o@~ -a fo~@l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-static {}, Ly2/b;->y()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Lo2/n;

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-direct {v0}, Lo2/n;-><init>()V

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lo2/l;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lo2/l;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method
