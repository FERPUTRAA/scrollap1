.class public Lo2/t;
.super Ljava/lang/Object;


# static fields
.field public static volatile b:Lo2/t;


# instance fields
.field public a:I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    iput v0, p0, Lo2/t;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public static c()Lo2/t;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@os~~  ~~o~ bv@b ~~@@o~@~ .om@b ~@y@~@f @~@~~~   ~@/ u~snSi~t~ -~@@d1 @ iol@t4~/l@Kor c@ f@@ ~aM"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lo2/t;->b:Lo2/t;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-class v0, Lo2/t;

    const-class v0, Lo2/t;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v1, Lo2/t;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v1}, Lo2/t;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput-object v1, Lo2/t;->b:Lo2/t;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    sget-object v0, Lo2/t;->b:Lo2/t;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p1}, Lo2/c;->s(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p1
.end method

.method public b(Landroid/content/Context;I)Lcom/engagelab/privates/push/api/NotificationLayout;
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v0, "TsBmsPhnuessis"

    const-string/jumbo v0, "nssusBissTehPu"

    const/4 v10, 0x1

    const-string v0, "ePBioThssunuMs"

    const-string v0, "MTPushBusiness"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string v1, " aubobiogorlteNunciidyIfeat:dmLt"

    const-string v1, " iemuidntiLtiNayueao:lftboIdrgco"

    const/4 v10, 0x2

    const-string v1, " IotorudtiolfiLugNetataiuncyd:eb"

    const-string v1, "getNotificationLayout builderId:"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v2, 0x0

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p1, p2}, Lo2/c;->b(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eqz v3, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    return-object v2

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v3, Lorg/json/JSONObject;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v3}, Lorg/json/JSONObject;->length()I

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez p1, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-object v2

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string/jumbo p1, "yu_aiodpt"

    const-string/jumbo p1, "tay_oiduo"

    const/4 v10, 0x6

    const-string/jumbo p1, "ot_uadyiq"

    const-string/jumbo p1, "layout_id"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v3, p1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string v4, "_csdbwii_nev"

    const-string v4, "ec_vibinw_di"

    const-string/jumbo v4, "niim_eocvwid"

    const-string/jumbo v4, "icon_view_id"

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v5, "e__inuuccirdoeos"

    const/4 v10, 0x0

    const-string/jumbo v5, "u_esooriro_ndcci"

    const-string/jumbo v5, "icon_resource_id"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v6, "_eltwbvtpiid_"

    const-string/jumbo v6, "wiitt_lp_vede"

    const/4 v10, 0x0

    const-string v6, "editiiu_wel_v"

    const-string/jumbo v6, "title_view_id"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string/jumbo v7, "nd_qnt_pewotcie"

    const-string/jumbo v7, "oi_vctenqwed_tn"

    const/4 v10, 0x1

    const-string v7, "cntnewdvqi__iet"

    const-string v7, "content_view_id"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string/jumbo v8, "tvsi__ewsedm"

    const-string v8, "d_simeve_tiw"

    const/4 v10, 0x2

    const-string v8, "e_emvmdi_iwi"

    const-string/jumbo v8, "time_view_id"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v3, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    const/4 v10, 0x7

    const/4 v9, 0x2

    new-instance v8, Lcom/engagelab/privates/push/api/NotificationLayout;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-direct {v8}, Lcom/engagelab/privates/push/api/NotificationLayout;-><init>()V

    const/4 v10, 0x6

    invoke-virtual {v8, p1}, Lcom/engagelab/privates/push/api/NotificationLayout;->o(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p1, v4}, Lcom/engagelab/privates/push/api/NotificationLayout;->n(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1, v5}, Lcom/engagelab/privates/push/api/NotificationLayout;->k(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1, v6}, Lcom/engagelab/privates/push/api/NotificationLayout;->r(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1, v7}, Lcom/engagelab/privates/push/api/NotificationLayout;->i(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1, v3}, Lcom/engagelab/privates/push/api/NotificationLayout;->q(I)Lcom/engagelab/privates/push/api/NotificationLayout;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/NotificationLayout;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string p2, "a m odel"

    const-string p2, "d lm efa"

    const/4 v10, 0x7

    const-string p2, "aed lb f"

    const-string p2, " failed "

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    return-object v2
.end method

.method public final d(Landroid/content/Context;IZ)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v0, "ttienfu_otnsoaoait"

    const-string v0, "aenaontfocit_sotti"

    const/4 v4, 0x3

    const-string/jumbo v0, "nittnotp_atoceiisf"

    const-string/jumbo v0, "notification_state"

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Landroid/os/Bundle;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0, p3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/16 v2, 0xbbe

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1, v2, v1}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p3, "seegnegcqr_rt"

    const-string/jumbo p3, "trigger_scene"

    const/4 v4, 0x2

    invoke-virtual {v1, p3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance p2, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p2}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p3, "ntsnebiodoit_arsnoaafdi_tc"

    const-string/jumbo p3, "rtnttbonaofsciidao__etdani"

    const/4 v4, 0x4

    const-string/jumbo p3, "idomnrtoaenastti_ncotidia_"

    const-string p3, "android_notification_state"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p3, Landroid/os/Bundle;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v0, "crooooup"

    const-string/jumbo v0, "rlopocuo"

    const-string/jumbo v0, "orcopblo"

    const-string/jumbo v0, "protocol"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p3, v0, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/16 p2, 0x8b9

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/16 p2, 0xed7

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string p3, " SaonfucneeatoNatiittfpi di"

    const-string p3, "fic  eopanitaSNettioaofitdn"

    const/4 v4, 0x6

    const-string/jumbo p3, "telNciaptof inntad fStoeiao"

    const-string/jumbo p3, "onNotificationState failed "

    const/4 v4, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p2, "PMeshsnqqTuusi"

    const-string/jumbo p2, "uusihMBsqTPens"

    const/4 v4, 0x2

    const-string p2, "ThseisnBMuPuss"

    const-string p2, "MTPushBusiness"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method public e(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "taime_isoantnittsc"

    const-string v1, "e_soitasianitnctot"

    const/4 v3, 0x7

    const-string v1, "fiitontatnesoaotc_"

    const-string/jumbo v1, "notification_state"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onNotificationStatus(Landroid/content/Context;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "itnpibnettt dsosalfaMcioNSeoea irfci"

    const-string/jumbo v0, "processMainNotificationState failed "

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string p2, "esussmuMshuBPn"

    const-string/jumbo p2, "isBmseMhnPsusu"

    const/4 v3, 0x1

    const-string p2, "PesBssuphuiTMs"

    const-string p2, "MTPushBusiness"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x0

    return-void
.end method

.method public f(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    invoke-static {p1}, Lo2/c;->u(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1
.end method

.method public g(Landroid/content/Context;I)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p1}, Lo3/f;->o(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v1, p0, Lo2/t;->a:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const-string/jumbo v3, "tai n ctqttifsoeioio a"

    const-string/jumbo v3, "oaiconf ieststtaito i "

    const-string v3, " ssioitntnatofse taci "

    const-string/jumbo v3, "notification state is "

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v4, "BnbmPiussTeMhs"

    const-string/jumbo v4, "ihPunbTBsssMes"

    const/4 v6, 0x0

    const-string v4, "MTPushBusiness"

    const/4 v6, 0x5

    if-ne v1, v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v4, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v0, p0, Lo2/t;->a:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lo2/t;->d(Landroid/content/Context;IZ)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ne v1, v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo p2, "ip nonsotineedunno etoectftNooti:di aatfaca  itsulSeaatt"

    const-string p2, "dod ftueipcttsiait e asittofe:oao nnetnata uteNSanoictnl"

    const/4 v6, 0x0

    const-string p2, "cadopbunttte laiScioineiateaitso teo a to:tean ttnfNindf"

    const-string/jumbo p2, "no need update notification state lastNotificationState:"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget p2, p0, Lo2/t;->a:I

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string p2, "f,aN:putareSiitetonntcrtic"

    const-string/jumbo p2, "ortetNSpinta,cneariticftu:"

    const/4 v6, 0x5

    const-string/jumbo p2, "tNoconupitife:St,trcitarne"

    const-string p2, ",currentNotificationState:"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v4, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    move v6, v5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v4, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput v0, p0, Lo2/t;->a:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0, p1, p2, v0}, Lo2/t;->d(Landroid/content/Context;IZ)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void
.end method

.method public h(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "id"

    const-string/jumbo v0, "id"

    const/4 v3, 0x6

    const-string/jumbo v0, "id"

    const-string/jumbo v0, "id"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "NttfooyIquua odeiterciaLdilresi:bt"

    const-string/jumbo v1, "o idedsbqre:ioitlItNatriLauyutecof"

    const/4 v3, 0x5

    const-string/jumbo v1, "yusintc rbleadtLeider:NoiasItfutoi"

    const-string/jumbo v1, "resetNotificationLayout builderId:"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo v1, "nshmssMuusPTis"

    const-string v1, "hussMTPneusssi"

    const/4 v3, 0x6

    const-string v1, "BeMsosuTPhsins"

    const-string v1, "MTPushBusiness"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1, p2, v0}, Lo2/c;->f(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public i(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v0, "ieo_tbafnbditicona"

    const-string/jumbo v0, "notification_badge"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v0, "senBTPuMsuishs"

    const-string v0, "MTPushBusiness"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-gez p2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string p1, ">tibn0op sore ieum a in uetNcmB:omr=ecog rttrafsud"

    const-string/jumbo p1, "ne m  t ior r=gesto0: triNcnomsrniaucdeoBufab>metu"

    const/4 v5, 0x2

    const-string p1, ":oc=tneoqgfraesutunmnobo it r  stBd0e tm>eNrir cau"

    const-string/jumbo p1, "setNotificationBadge error: number count must >= 0"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lo2/c;->l(Landroid/content/Context;I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    const/4 v4, 0x4

    move v5, v4

    const-string v3, "ehsoaw"

    const-string v3, "hewaou"

    const/4 v5, 0x0

    const-string v3, "huawei"

    const/4 v5, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v3, "brnoo"

    const-string/jumbo v3, "rhomn"

    const-string v3, "honor"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p2, " tueotitfNoairs ndpceuoopB gtosai"

    const-string p2, "ec ttiun roifuoet atBsNsdgotaoppi"

    const/4 v5, 0x4

    const-string p2, "dsa ibine tnseotiforBtNuptopagct "

    const-string/jumbo p2, "setNotificationBadge not support "

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lo3/f;->A(Landroid/content/Context;I)Z

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1, p2}, Lo3/f;->B(Landroid/content/Context;I)V

    :goto_0
    const/4 v4, 0x2

    move v5, v4

    return-void
.end method

.method public j(Landroid/content/Context;)Z
    .locals 13

    const/4 v12, 0x5

    const-string/jumbo v0, "uiBhTpuessssuP"

    const-string/jumbo v0, "iussTMPpesuBhs"

    const/4 v12, 0x6

    const-string v0, "MTPushBusiness"

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    const/4 v1, 0x1

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-static {p1}, Lo2/c;->v(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-eqz v2, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    return v1

    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string/jumbo v3, "thiiiiTp wmqcnoSeiaetofiTsmNsoow"

    const-string v3, "eTtmohoiqctwNmifse oioisSnTa:wii"

    const/4 v12, 0x0

    const-string/jumbo v3, "wtnwiioaqmNshTocfiieT:m itShesoo"

    const-string/jumbo v3, "isNotificationShowTime showTime:"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    const-string v2, "_"

    const-string v2, "_"

    const/4 v12, 0x7

    const-string v2, "_"

    const-string v2, "_"

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v2, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    aget-object v3, p1, v2

    const/4 v12, 0x4

    const/4 v11, 0x6

    aget-object p1, p1, v1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v3}, Ljava/lang/String;->toCharArray()[C

    move-result-object v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    const-string v4, "//^"

    const-string v4, "\\^"

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {p1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x2

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v5, 0x7

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v4, v5}, Ljava/util/Calendar;->get(I)I

    move-result v5

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    const/16 v6, 0xb

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v4, v6}, Ljava/util/Calendar;->get(I)I

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string/jumbo v7, "iusiienetnNosiorhfrc cti:oHrmutoTwS"

    const/4 v12, 0x6

    const-string/jumbo v7, "iosnwuatcnootieNtfiircoHsirSrm:ueTh"

    const-string/jumbo v7, "isNotificationShowTime currentHour:"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string v7, "Deym:nr,cumr"

    const-string/jumbo v7, "rcym,reD:uan"

    const/4 v12, 0x5

    const-string v7, "ec,youD:arnr"

    const-string v7, ",currentDay:"

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    move v12, v11

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-static {v0, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    array-length v6, v3

    const/4 v11, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    move v7, v2

    move v7, v2

    move v7, v2

    move v7, v2

    :goto_0
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    if-ge v7, v6, :cond_3

    const/4 v12, 0x4

    aget-char v8, v3, v7

    const/4 v12, 0x0

    invoke-static {v8}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    move v12, v11

    const-string/jumbo v10, "ytDgoets:in"

    const-string v10, "Dt:egbtiyan"

    const-string/jumbo v10, "settingDay:"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    or-int/2addr v12, v11

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-static {v0, v9}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-int/lit8 v8, v8, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-eq v5, v8, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    goto :goto_1

    :cond_1
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    aget-object v8, p1, v2

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x2

    aget-object v9, p1, v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-lt v4, v8, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-gt v4, v9, :cond_2

    const/4 v12, 0x0

    return v1

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v12, 0x7

    const/4 v11, 0x3

    return v2

    :catchall_0
    move-exception p1

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo v3, "ostaonuoc itebdmeiTiSl fiNifaw"

    const-string v3, "dnNiibtfilo citshemoieTawaS fo"

    const/4 v12, 0x0

    const-string v3, "awiicTepitashfiooidolNmnfie t "

    const-string/jumbo v3, "isNotificationShowTime failed "

    const/4 v11, 0x6

    move v12, v11

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x3

    move v12, v11

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    move v12, v11

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x4

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    return v1
.end method

.method public k(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v0, "tnciutafqtnnuoooi_"

    const-string v0, "foitnnunicaooitut_"

    const/4 v4, 0x5

    const-string/jumbo v0, "notification_count"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v0, "BsspihsnPTueMs"

    const-string/jumbo v0, "sBeshuipTsnPsM"

    const/4 v4, 0x4

    const-string/jumbo v0, "ssimPBMsnsuThe"

    const-string v0, "MTPushBusiness"

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-gtz p2, :cond_1

    const/4 v4, 0x7

    const-string p1, "ett ocnosaCtiurtoo0teft>u n roors iiumn:c "

    const-string/jumbo p1, "setNotificationCount error: count must > 0"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const-string/jumbo v2, "toteNbsinctofaiCn oiq"

    const-string v2, "cC fsttoqunnetNaiioio"

    const/4 v4, 0x5

    const-string v2, "ftntocutNouCatisio in"

    const-string/jumbo v2, "setNotificationCount "

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1, p2}, Lo2/c;->q(Landroid/content/Context;I)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method public l(Landroid/content/Context;)Z
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string v0, ":"

    const-string v0, ":"

    const/4 v11, 0x4

    const-string v0, ":"

    const-string v0, ":"

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string/jumbo v1, "iePussspMsnhTB"

    const-string v1, "hisuTsMPesnssB"

    const/4 v11, 0x5

    const-string v1, "esunMsshqusPBi"

    const-string v1, "MTPushBusiness"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/4 v2, 0x0

    :try_start_0
    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-static {p1}, Lo2/c;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eqz v3, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    return v2

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string v4, "cesm tmcelitefSiioeSieen:NnocilaThcncimisTe"

    const-string/jumbo v4, "iS mfelecenitltmnnSsocci:omhciTTNeicieeieai"

    const/4 v11, 0x1

    const-string/jumbo v4, "nc:mhicTeieSciSTm tesaNiiicaeelfimitecenool"

    const-string/jumbo v4, "isNotificationSilenceTime cacheSilenceTime:"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-instance v3, Lorg/json/JSONObject;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct {v3, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const-string p1, "e_rgobhnuo"

    const-string p1, "bgrno_oehu"

    const-string/jumbo p1, "ouihnbe_bg"

    const-string p1, "begin_hour"

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v3, p1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const-string/jumbo v4, "nmenigueiubb"

    const-string/jumbo v4, "nuiiebb_nmge"

    const/4 v11, 0x5

    const-string/jumbo v4, "mebniunpei_t"

    const-string v4, "begin_minute"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo v5, "qrnouudh"

    const-string/jumbo v5, "ohru_nud"

    const/4 v11, 0x7

    const-string/jumbo v5, "urseohdn"

    const-string v5, "end_hour"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v6, "end_minute"

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/16 v7, 0xb

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v6, v7}, Ljava/util/Calendar;->get(I)I

    move-result v7

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/16 v8, 0xc

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v6, v8}, Ljava/util/Calendar;->get(I)I

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string/jumbo v9, "totmsrocefruniSmciaTnteiml:ep eeiinciT"

    const-string/jumbo v9, "taioc epcuoNTeSii:rnrfimnneistiteTcmel"

    const/4 v11, 0x5

    const-string v9, "e rSo:initclomTefitiesineNocniuamcTeti"

    const-string/jumbo v9, "isNotificationSilenceTime currentTime:"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    shl-int/2addr v11, v10

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string v9, "eT:clbnes emi,"

    const-string v9, "eT:cme,nql sei"

    const-string v9, "Tmc enuii:,eel"

    const-string v9, ", silenceTime:"

    const/4 v11, 0x2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move v11, v10

    const-string v9, "-"

    const-string v9, "-"

    const/4 v11, 0x2

    const-string v9, "-"

    const-string v9, "-"

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/4 v0, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-ge p1, v5, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-le v7, p1, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-ge v7, v5, :cond_1

    const/4 v11, 0x0

    const-string/jumbo p1, "iiton Spflaemceit1cisnoTs ii"

    const-string/jumbo p1, "ntso cc aoSinimtiilf1einsiTe"

    const/4 v11, 0x2

    const-string p1, "STceoiimqe nafnliciioit1stne"

    const-string/jumbo p1, "is notificationSilenceTime 1"

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    return v0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-ne v7, p1, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-lt v6, v4, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string p1, "fcstSii miiT 2lstineimonaecn"

    const-string p1, " nSmic sili2ametteioniceTinf"

    const/4 v11, 0x0

    const-string p1, "ennmii2eiSemtiaclc sTit fnoi"

    const-string/jumbo p1, "is notificationSilenceTime 2"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    xor-int/2addr v11, v10

    return v0

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-ne v7, v5, :cond_3

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-gt v6, v3, :cond_3

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string p1, "ccaeoTStio fonlenitmei3ioin "

    const-string p1, "Sclto3inniiociitT iao mnfeee"

    const/4 v11, 0x6

    const-string/jumbo p1, "ime ibSt3coltinfceanTisii ne"

    const-string/jumbo p1, "is notificationSilenceTime 3"

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    return v0

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x3

    const-string p1, "Tiloeeunatinfcionbit iomSt en"

    const-string p1, "a itnbniltoetSnf meiinicoeoT1"

    const/4 v11, 0x1

    const-string/jumbo p1, "t lcoiap eiif1nieetmocinTtnno"

    const-string/jumbo p1, "not notificationSilenceTime 1"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    return v2

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x6

    if-ne p1, v5, :cond_a

    const/4 v11, 0x2

    if-lt v4, v3, :cond_8

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eq v7, p1, :cond_5

    const/4 v10, 0x2

    and-int/2addr v11, v10

    const-string p1, "4Tccieunqile in taiesoSfoint"

    const-string/jumbo p1, "ot4iotueieeiS lnincina ciTfs"

    const/4 v11, 0x4

    const-string/jumbo p1, "icsifeoi4itcnSsn i oenmaileT"

    const-string/jumbo p1, "is notificationSilenceTime 4"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    return v0

    :cond_5
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-lt v6, v4, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string/jumbo p1, "netm eimpo 5cnToitiainlscfeS"

    const-string/jumbo p1, "ineit5spnTmic lfi inatocSoee"

    const-string/jumbo p1, "loc omTeis iSioc5entitnfieia"

    const-string/jumbo p1, "is notificationSilenceTime 5"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    return v0

    :cond_6
    const/4 v11, 0x6

    if-gt v6, v3, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string/jumbo p1, "iilfcbsiitTceento6 minianqSo"

    const-string p1, "ce simaoqSiTcofn nltiieniit6"

    const/4 v11, 0x3

    const-string/jumbo p1, "l atiiucefn siocmnteiSeiToi6"

    const-string/jumbo p1, "is notificationSilenceTime 6"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    return v0

    :cond_7
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string p1, "i  lmeipneo2tcinitoftTeoScnas"

    const-string/jumbo p1, "oestncoiSina ecTtnmiftnoi2l e"

    const/4 v11, 0x0

    const-string/jumbo p1, "tieanefoqicioot2nSiinem  ctnl"

    const-string/jumbo p1, "not notificationSilenceTime 2"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    return v2

    :cond_8
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-ne v7, p1, :cond_9

    const/4 v11, 0x5

    if-lt v6, v4, :cond_9

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-gt v6, v3, :cond_9

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string/jumbo p1, "icse lenniSoisnmtmeiiafic tT"

    const-string p1, "elfms imciinentTiStn eio7iac"

    const-string/jumbo p1, "is notificationSilenceTime 7"

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    return v0

    :cond_9
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo p1, "ictmeSiilo iaftnooe3 nTncmoni"

    const-string/jumbo p1, "mfclo3eiotn aetic niioTieSnno"

    const/4 v11, 0x1

    const-string/jumbo p1, "onm3o n iiolSTcentiitfceteaoi"

    const-string/jumbo p1, "not notificationSilenceTime 3"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    return v2

    :cond_a
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-le p1, v5, :cond_f

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-le v7, p1, :cond_b

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/16 v8, 0x17

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-gt v7, v8, :cond_b

    const/4 v11, 0x7

    const-string/jumbo p1, "saebnbTtc fieni8coiiimeli Sn"

    const-string/jumbo p1, "ne itbn8eiiminaicefoil cosTS"

    const/4 v11, 0x3

    const-string p1, "ciemcout8TSl taneoe isifnnii"

    const-string/jumbo p1, "is notificationSilenceTime 8"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    return v0

    :cond_b
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-ltz v7, :cond_c

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ge v7, v5, :cond_c

    const/4 v11, 0x3

    const-string/jumbo p1, "sato nepiuTtmnioni9i lSeifei"

    const-string p1, " teiniusinTeiltc nmiaf9oiSeo"

    const/4 v11, 0x0

    const-string p1, "Sioanom9qtfiiiic leTnsci net"

    const-string/jumbo p1, "is notificationSilenceTime 9"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    return v0

    :cond_c
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-ne v7, p1, :cond_d

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-lt v6, v4, :cond_d

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string/jumbo p1, "inoieosp l0ic eSeci1afminttnT"

    const/4 v11, 0x1

    const-string p1, "e snis0coitiaiSfmol1c ieentni"

    const-string/jumbo p1, "is notificationSilenceTime 10"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    shr-int/2addr v11, v10

    return v0

    :cond_d
    const/4 v10, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-ne v7, v5, :cond_e

    const/4 v10, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-gt v6, v3, :cond_e

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string/jumbo p1, "tnTmsel i1qnSemoocintice iifa"

    const-string p1, "coitneeoqsSm1 eiinT cliintfia"

    const/4 v11, 0x1

    const-string p1, "fo1eoSitTnlmtiiio scnice 1nea"

    const-string/jumbo p1, "is notificationSilenceTime 11"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    return v0

    :cond_e
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo p1, "tininb oisiooSnfmliTe4ncaetet"

    const-string/jumbo p1, "iosoTlnita iSte ncen4oeinfmit"

    const/4 v11, 0x4

    const-string p1, "centonuenTnlicSima4i iotift e"

    const-string/jumbo p1, "not notificationSilenceTime 4"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    return v2

    :catchall_0
    move-exception p1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const-string/jumbo v3, "mle iinpmcfacttsieiiToneNeSdlioa "

    const-string v3, " iimeiolTaimnf ecaiidneSsoitNlect"

    const/4 v11, 0x3

    const-string v3, "fieectisqdmTiotcnifliSlaione a ie"

    const-string/jumbo v3, "isNotificationSilenceTime failed "

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_f
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string p1, " 5sonfteicionoSioinn lcatiTmt"

    const-string p1, "i5 To iecamfSontncenoiioniltt"

    const/4 v11, 0x1

    const-string/jumbo p1, "tmomfieTeSt nolcotiie5innn ic"

    const-string/jumbo p1, "not notificationSilenceTime 5"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    return v2
.end method

.method public m(Landroid/content/Context;)V
    .locals 8

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const-string/jumbo v1, "iimeo"

    const-string v1, "bmiei"

    const/4 v7, 0x0

    const-string v1, "bmiet"

    const-string/jumbo v1, "itime"

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x5

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    div-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p1}, Lo2/q;->I(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Ld3/e;->i(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v2, "lnag"

    const/4 v7, 0x4

    const-string v2, "gnla"

    const-string/jumbo v2, "lang"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v1, "urnyco"

    const-string/jumbo v1, "unycor"

    const/4 v7, 0x7

    const-string/jumbo v1, "rpytco"

    const-string v1, "contry"

    :try_start_2
    const/4 v7, 0x0

    invoke-static {p1}, Ly2/b;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string v1, "eqrcrpi"

    const-string/jumbo v1, "prericr"

    const/4 v7, 0x4

    const-string/jumbo v1, "risecra"

    const-string v1, "carrier"

    :try_start_3
    const/4 v7, 0x2

    invoke-static {p1}, Ld3/e;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v1, "rismsne_vq"

    const-string/jumbo v1, "orvneis_qs"

    const/4 v7, 0x5

    const-string/jumbo v1, "iernoosv_s"

    const-string/jumbo v1, "os_version"

    :try_start_4
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {}, Ld3/e;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo v1, "ioc_obdssres_no"

    const-string/jumbo v1, "iossr_d_osvcnoe"

    const/4 v7, 0x0

    const-string v1, "co_nevuesosdr_o"

    const-string/jumbo v1, "os_version_code"

    :try_start_5
    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-static {}, Ld3/e;->s()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v1, "dmpel"

    const-string v1, "delmo"

    const-string/jumbo v1, "mloqd"

    const-string/jumbo v1, "model"

    :try_start_6
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {}, Ld3/e;->k()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v1, "ovse_nmieda"

    const-string v1, "eda_ocnemvi"

    const/4 v7, 0x2

    const-string/jumbo v1, "neema_vdiem"

    const-string v1, "device_name"

    :try_start_7
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {}, Ld3/e;->q()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    const/4 v7, 0x0

    const-string v1, "boptouc"

    const-string/jumbo v1, "upotcbr"

    const/4 v7, 0x7

    const-string/jumbo v1, "toucpbd"

    const-string/jumbo v1, "product"

    :try_start_8
    const/4 v7, 0x3

    invoke-static {}, Ld3/e;->l()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string/jumbo v1, "tnuruuufmace"

    const-string v1, "acefruumtanu"

    const/4 v7, 0x2

    const-string v1, "auratuepfncr"

    const-string/jumbo v1, "manufacturer"

    :try_start_9
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {}, Ld3/e;->j()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v1, "iztn_mpeq"

    const-string/jumbo v1, "omzitnep_"

    const/4 v7, 0x2

    const-string v1, "eis_emozt"

    const-string/jumbo v1, "time_zone"

    :try_start_a
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Ld3/e;->t()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v1, "z_et_ioiqenm"

    const/4 v7, 0x3

    const-string/jumbo v1, "m_imtzend_oe"

    const-string/jumbo v1, "time_zone_id"

    :try_start_b
    const/4 v6, 0x2

    const/4 v6, 0x7

    invoke-static {}, Ld3/e;->u()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v1, "apenorsvsp_"

    const-string/jumbo v1, "r_seiasppnv"

    const/4 v7, 0x2

    const-string/jumbo v1, "rianpbe_pso"

    const-string v1, "app_version"

    :try_start_c
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1}, Ly2/b;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v1, "_rddonuiai"

    const-string v1, "android_id"

    :try_start_d
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p1}, Ld3/e;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v1, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v1}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v2, "orimfsean_vo"

    const/4 v7, 0x4

    const-string/jumbo v2, "oversea_info"

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v1, Landroid/os/Bundle;

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    const-string/jumbo v2, "looooprp"

    const-string/jumbo v2, "oopoolcr"

    const/4 v7, 0x1

    const-string/jumbo v2, "qtoorcpl"

    const-string/jumbo v2, "protocol"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/16 v0, 0x8b9

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo v1, "opsrfredoeSIa fe tlbrieosa"

    const-string v1, "eIepsb rriola ooverSaftfde"

    const/4 v7, 0x3

    const-string v1, "ftdmolv e rorIrepaeeoiafSs"

    const-string/jumbo v1, "reportSoverseaInfo failed "

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v0, "esPsoThMBuuisu"

    const-string/jumbo v0, "ssuMihuTePusBs"

    const/4 v7, 0x3

    const-string v0, "PeiusbsnMhuBss"

    const-string v0, "MTPushBusiness"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-void
.end method

.method public n(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string v0, "hiusseusBPTnsu"

    const-string v0, "MTPushBusiness"

    :try_start_0
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-class v1, Lcom/engagelab/privates/push/api/NotificationLayout;

    const-class v1, Lcom/engagelab/privates/push/api/NotificationLayout;

    const/4 v10, 0x7

    const-class v1, Lcom/engagelab/privates/push/api/NotificationLayout;

    const-class v1, Lcom/engagelab/privates/push/api/NotificationLayout;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v9, 0x0

    or-int/2addr v10, v9

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v10, 0x5

    const-string/jumbo v1, "id"

    const-string v1, "di"

    const/4 v10, 0x0

    const-string/jumbo v1, "id"

    const-string/jumbo v1, "id"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string/jumbo v2, "tinylf_pictioaopnau"

    const-string v2, "futoaanptio_nlticyi"

    const/4 v10, 0x2

    const-string v2, "flnua_ttqooantciiyi"

    const-string/jumbo v2, "notification_layout"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p2, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    check-cast p2, Lcom/engagelab/privates/push/api/NotificationLayout;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v3, "oosi qsNunotitatytidec:Li"

    const-string/jumbo v3, "ontoiLttqtiocs ydaieuNfi:"

    const/4 v10, 0x2

    const-string/jumbo v3, "ya:mtNiatsoi oeLtnutifiod"

    const-string/jumbo v3, "setNotificationLayout id:"

    const/4 v10, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->e()I

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->d()I

    move-result v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->c()I

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->h()I

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->a()I

    move-result v6

    const/4 v10, 0x1

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/NotificationLayout;->g()I

    move-result p2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v7, Lorg/json/JSONObject;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string/jumbo v8, "tiyuodola"

    const-string/jumbo v8, "losyadiut"

    const/4 v10, 0x2

    const-string/jumbo v8, "uoytdb_il"

    const-string/jumbo v8, "layout_id"

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {v7, v8, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const-string/jumbo v2, "wivm_ec_diio"

    const/4 v10, 0x2

    const-string/jumbo v2, "icon_view_id"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v7, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-string/jumbo v2, "riecoour_neiscou"

    const-string v2, "co_ioseoiucne_rr"

    const/4 v10, 0x7

    const-string v2, "cincis_puerrdoe_"

    const-string/jumbo v2, "icon_resource_id"

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v7, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo v2, "t_td_weeqvlii"

    const-string/jumbo v2, "ite_dbwvt_iel"

    const-string/jumbo v2, "tlsiviet_ied_"

    const-string/jumbo v2, "title_view_id"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v7, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x7

    const-string v2, "c_dmnueti_ovitw"

    const-string/jumbo v2, "nwd_teuviciton_"

    const/4 v10, 0x5

    const-string/jumbo v2, "o_vnoinwetditec"

    const-string v2, "content_view_id"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v7, v2, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const-string/jumbo v2, "idw_vbpeemti"

    const-string/jumbo v2, "idte_mepw_vi"

    const/4 v10, 0x3

    const-string/jumbo v2, "time_view_id"

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v7, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p1, v1, p2}, Lo2/c;->f(Landroid/content/Context;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v1, "fiLqeyucufitaaoseattN niooidl"

    const-string/jumbo v1, "itteaiouqdofiatyNe tnoaifsclL"

    const/4 v10, 0x2

    const-string/jumbo v1, "tfcuidypon tLNs laeoioifiatte"

    const-string/jumbo v1, "setNotificationLayout failed "

    const/4 v10, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v9, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    return-void
.end method

.method public o(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1, v0}, Lo2/c;->l(Landroid/content/Context;I)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v3, "iuqaws"

    const-string/jumbo v3, "uiswea"

    const/4 v5, 0x6

    const-string v3, "hesuai"

    const-string v3, "huawei"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const-string/jumbo v3, "ormmo"

    const-string/jumbo v3, "rnomo"

    const/4 v5, 0x1

    const-string v3, "honor"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    or-int/2addr v5, v4

    const-string v0, "aoptogtircButiot s dpseNoef niton"

    const-string/jumbo v0, "uBenooetnt  odfis progNitisocaptt"

    const/4 v5, 0x3

    const-string/jumbo v0, "setNotificationBadge not support "

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v0, "husBPbenbuTsss"

    const-string/jumbo v0, "nBsPsbshueuiTs"

    const/4 v5, 0x5

    const-string v0, "eMsusBussinTuh"

    const-string v0, "MTPushBusiness"

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1, v0}, Lo3/f;->A(Landroid/content/Context;I)Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1, v0}, Lo3/f;->B(Landroid/content/Context;I)V

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-void
.end method

.method public p(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x2

    const-string v0, "BuusiunpTPMsse"

    const-string v0, "TnBsuiuusMPhse"

    const/4 v8, 0x7

    const-string/jumbo v0, "uMesnssiquhPTs"

    const-string v0, "MTPushBusiness"

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo v2, "iTsoiSetNtasichwep:fomon"

    const-string/jumbo v2, "iinmi:opacoSeetNfoiTtshw"

    const/4 v8, 0x6

    const-string/jumbo v2, "wohmtfoeNStmcins:eoiiTai"

    const-string/jumbo v2, "setNotificationShowTime:"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p2}, Lb3/a;->f(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "ayd"

    const-string v1, "dya"

    const/4 v8, 0x6

    const-string v1, "dya"

    const-string v1, "day"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    array-length v2, v1

    const/4 v8, 0x1

    if-nez v2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string p2, "faiSooh qctaT/Nht enhny, wfetiam/ sigkis0twtyne rse oetccmeiois.oD tenniTvaielwo"

    const/4 v8, 0x2

    const-string/jumbo p2, "moawoahlnwTot nifyik /see/tahvt hioiitcinT aooDw,eitreee.sni0cnNm oeisySfg tcste"

    const-string/jumbo p2, "setNotificationShowTime weekDays.length is 0, can\'t show notification everyTime"

    const/4 v8, 0x4

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v8, 0x3

    const-string p2, ""

    const-string p2, ""

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {p1, p2}, Lo2/c;->r(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    return-void

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo v2, "ng_srbohbi"

    const-string v2, "bosg_nhiru"

    const/4 v8, 0x6

    const-string v2, "g_oubiunrh"

    const-string v2, "begin_hour"

    const/4 v8, 0x0

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v3, "_rmnduhp"

    const-string/jumbo v3, "urdmnoh_"

    const/4 v8, 0x2

    const-string/jumbo v3, "qeon_urh"

    const-string v3, "end_hour"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v8, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const-string/jumbo v4, "ttsitostniwfuia:seotieaoHochmrTNr "

    const-string v4, "aimiowttuorhNcir STeeiftn:atsHsoto"

    const/4 v8, 0x0

    const-string v4, "aa mcnhmriSoTiftertiu:HNttwsoostio"

    const-string/jumbo v4, "setNotificationShowTime startHour:"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v4, "du,eonroH"

    const-string v4, ",endHour:"

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string v4, "eyD,bbw:sk"

    const-string/jumbo v4, "ke:,ebDysw"

    const/4 v8, 0x2

    const-string v4, ",eeakDuws:"

    const-string v4, ",weekDays:"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    array-length v4, v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v5, 0x0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-ge v5, v4, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    aget v6, v1, v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v5, v5, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v1, "_"

    const-string v1, "_"

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v1, "^"

    const-string v1, "^"

    const/4 v8, 0x6

    const-string v1, "^"

    const-string v1, "^"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string p2, "]-]-|99p[](|9-(9][0]-[21]2)||3[/^/-0[-00u1[00"

    const-string p2, "]|3|2]u]0[3[][-^90|90[0/[10-0/21-()-9|-(9]]-["

    const/4 v8, 0x1

    const-string p2, "([0-9]|1[0-9]|2[0-3])\\^([0-9]|1[0-9]|2[0-3])"

    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v2, "_]p(7[},q(6)00-"

    const-string v2, "])(,0-(p[6(}0_7"

    const/4 v8, 0x1

    const-string v2, "-]s(6}7_)0,((0{"

    const-string v2, "([0-6]{0,7})_(("

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const-string v2, ")(|"

    const-string v2, "(|)"

    const/4 v8, 0x0

    const-string v2, "()|"

    const-string v2, ")|("

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v2, "+-)("

    const-string v2, "(+-)"

    const/4 v8, 0x4

    const-string v2, "+-()"

    const-string v2, "-)+("

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string p2, "))"

    const-string p2, "))"

    const/4 v8, 0x6

    const-string p2, "))"

    const-string p2, "))"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p2}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p2, v3}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/util/regex/Matcher;->matches()Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz p2, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p1, p2}, Lo2/c;->r(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_1

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo p2, "oh mdim aifitai-emiowosrvntmlenTiac iftetNto  "

    const-string/jumbo p2, "icoinhm qmaoliafr-teist ve oiN iiTtdtoftwm ean"

    const/4 v8, 0x7

    const-string/jumbo p2, "tfNio o  oihTtmirwfmeS ta tatoa-nmldeecoiisnii"

    const-string/jumbo p2, "setNotificationShowTime invalid time format - "

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v1, "i atibnifosuselthaitTemPfNs oce"

    const-string v1, "efsn diimfhcaoaTo tlPistitesueN"

    const-string/jumbo v1, "setNotificationPushTime failed "

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void
.end method

.method public q(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v0, "PsTuBsuhsmneis"

    const-string/jumbo v0, "seMmiuTnhPsssB"

    const/4 v3, 0x6

    const-string/jumbo v0, "sehuiTspssBPun"

    const-string v0, "MTPushBusiness"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "NtsenntiqoitctuoCraefi"

    const-string/jumbo v1, "resetNotificationCount"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lo2/c;->q(Landroid/content/Context;I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public r(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 13

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string v0, ":"

    const-string v0, ":"

    const/4 v12, 0x2

    const-string v0, ":"

    const-string v0, ":"

    const/4 v12, 0x0

    const-string/jumbo v1, "mnsdnei_ut"

    const-string/jumbo v1, "unmdoe_nti"

    const/4 v12, 0x2

    const-string v1, "end_minute"

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo v2, "u_nmedro"

    const-string/jumbo v2, "neuodb_r"

    const/4 v12, 0x5

    const-string v2, "hdreouno"

    const-string v2, "end_hour"

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-string/jumbo v3, "nunembbt_ige"

    const-string/jumbo v3, "mnntu_ugieeb"

    const/4 v12, 0x7

    const-string v3, "begin_minute"

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    const-string/jumbo v4, "sBPhsiussnpeuu"

    const-string v4, "eTsusPhpnuBsis"

    const/4 v12, 0x4

    const-string/jumbo v4, "uhssuMBpnPsisT"

    const-string v4, "MTPushBusiness"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    const-string/jumbo v5, "oe_iqrbhqu"

    const-string/jumbo v5, "i_nbeohuqr"

    const/4 v12, 0x7

    const-string/jumbo v5, "uhsir_bgoe"

    const-string v5, "begin_hour"

    :try_start_0
    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {p2, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v6

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v7

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v8

    const/4 v12, 0x2

    const/4 v11, 0x2

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const-string/jumbo v10, "tcfmltiniiieenmTecS:Notoass"

    const-string v10, "anseTeeoitctltosinSmfeii:Nc"

    const/4 v12, 0x1

    const-string/jumbo v10, "tft:oeceomastieelTiiniiNnoc"

    const-string/jumbo v10, "setNotificationSilenceTime:"

    const/4 v11, 0x6

    shr-int/2addr v12, v11

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x3

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    const-string v10, "-"

    const-string v10, "-"

    const/4 v12, 0x6

    const-string v10, "-"

    const-string v10, "-"

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v9, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    invoke-static {v4, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-virtual {v0, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v0, v3, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v0, v2, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v12, 0x3

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {p1, p2}, Lo2/c;->t(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const-string/jumbo v0, "iicdTbaii tflmnfeamtenNioloSesec t"

    const-string/jumbo v0, "isimi  eictaefetmnilicStfeTNdoanol"

    const/4 v12, 0x7

    const-string/jumbo v0, "oifiTau nNcscmlteiiiiSeeteonatl df"

    const-string/jumbo v0, "setNotificationSilenceTime failed "

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v4, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    return-void
.end method

.method public s(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const-string/jumbo v0, "onishsPpMBsuTu"

    const-string/jumbo v0, "suuhoBiMnssPTs"

    const/4 v3, 0x7

    const-string v0, "PBnusMssqThiue"

    const-string v0, "MTPushBusiness"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "iosnboeahireftwieoScTttsm"

    const-string/jumbo v1, "omihobattSrNescetioTiwfen"

    const/4 v3, 0x0

    const-string/jumbo v1, "oiomfsSciiwmnNrtaoeeTteih"

    const-string/jumbo v1, "resetNotificationShowTime"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lo2/c;->r(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public t(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "usBuohuMPssisT"

    const-string/jumbo v0, "sMushsuiusPnTB"

    const/4 v3, 0x6

    const-string v0, "BhsnubsiMeuPsT"

    const-string v0, "MTPushBusiness"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "aomicruiefilnoSTscenteteieti"

    const-string/jumbo v1, "resetNotificationSilenceTime"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lo2/c;->t(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method
