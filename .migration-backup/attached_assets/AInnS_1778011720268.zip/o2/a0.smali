.class public Lo2/a0;
.super Ljava/lang/Object;


# static fields
.field public static a:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue<",
            "Lo2/y;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/ArrayList<",
            "Lo2/y;",
            ">;"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@bs~ o~f4K~~ @ ~M~@@@o @i~um~/ i~f ybn~r@~.~@t~cb@@~o~@o~@1/ Svd~ -~@  o   @@oa~ tsli@ ~l@ ~ ~@@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    const-class v0, Lo2/a0;

    const-class v0, Lo2/a0;

    const/4 v8, 0x0

    const-class v0, Lo2/a0;

    const-class v0, Lo2/a0;

    const/4 v8, 0x5

    const/4 v7, 0x3

    monitor-enter v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x5

    move v8, v7

    if-nez p0, :cond_0

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo p0, "slgmsMuiuesQU"

    const-string/jumbo p0, "sisMueuglQeUs"

    const/4 v8, 0x0

    const-string p0, "MUsioeultsgeQ"

    const-string p0, "MsgQueueUtils"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo p1, "ot eubtcxxspdnlnentle ciu e,"

    const-string/jumbo p1, "unexcepted , context is null"

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    monitor-exit v0

    const/4 v8, 0x4

    return-object v1

    :cond_0
    :try_start_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    new-instance v2, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v7, 0x6

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v3, Ljava/io/File;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {v3, v4, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v4, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v4}, Ld3/q;->h(Ljava/io/InputStream;)[B

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v3, Lorg/json/JSONArray;

    const/4 v8, 0x5

    new-instance v5, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v5, v1}, Ljava/lang/String;-><init>([B)V

    const/4 v8, 0x0

    invoke-direct {v3, v5}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-ge v1, v5, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-virtual {v3, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v5}, Lo2/y;->a(Lorg/json/JSONObject;)Lo2/y;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_1

    :catchall_0
    move-exception v1

    move-object v3, v1

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_2

    :cond_2
    :goto_1
    :try_start_4
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x6

    goto :goto_3

    :catchall_1
    move-exception v3

    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v4, "mgussQuilUMet"

    const-string/jumbo v4, "slMmseUugietQ"

    const/4 v8, 0x4

    const-string/jumbo v4, "uUMgustpeilQe"

    const-string v4, "MsgQueueUtils"
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    :try_start_5
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string/jumbo v6, "rtr orboqcasolo :de"

    const-string v6, " lcooere:troobra sd"

    const-string/jumbo v6, "oes:doblr stojerc a"

    const-string/jumbo v6, "load objects error:"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v4, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p0, p1}, Lo2/a0;->d(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1}, Ld3/q;->a(Ljava/io/Closeable;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    monitor-exit v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-object v2

    :catchall_2
    move-exception p0

    :try_start_7
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    throw p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    :catchall_3
    move-exception p0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    monitor-exit v0

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    throw p0
.end method

.method public static declared-synchronized b(Landroid/content/Context;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lo2/y;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-class v0, Lo2/a0;

    const/4 v4, 0x3

    const-class v0, Lo2/a0;

    const-class v0, Lo2/a0;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "tubmUlgiQsues"

    const-string v1, "gluisbQsMueUt"

    const/4 v4, 0x2

    const-string v1, "QueMosesUutgl"

    const-string v1, "MsgQueueUtils"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "tbAjseusvno -aOcceti"

    const/4 v4, 0x3

    const-string/jumbo v2, "saci-bvotctbj seAe n"

    const-string v2, "Action - saveObjects"

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {v1, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p0, "iMgspeulusQUt"

    const-string/jumbo p0, "stMueeipsUlQg"

    const/4 v4, 0x7

    const-string/jumbo p0, "suiuUQlpgsMte"

    const-string p0, "MsgQueueUtils"

    const/4 v4, 0x7

    const-string/jumbo p1, "inetqs uqdxun ,nxeet poltl c"

    const-string/jumbo p1, "o dletpcql tne t,unuseeni xx"

    const/4 v4, 0x4

    const-string p1, " ls ntu,u spxdeecnltxitneoe "

    const-string/jumbo p1, "unexcepted , context is null"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez p2, :cond_1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo p0, "sMemuiugtUslQ"

    const-string/jumbo p0, "tesgUuisQuelM"

    const/4 v4, 0x3

    const-string p0, "euQUolguMtsie"

    const-string p0, "MsgQueueUtils"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string p1, " tumcbsOllLnjii emb"

    const-string/jumbo p1, "l imeniss jcultLmOb"

    const-string p1, "OeibLiu jmtsutnclsl"

    const-string/jumbo p1, "mObjectList is null"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :cond_1
    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v1, Ljava/io/File;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-direct {v1, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    new-instance p0, Lorg/json/JSONArray;

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x0

    xor-int/2addr v4, p1

    :goto_0
    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge p1, v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast v2, Lo2/y;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v2}, Lo2/y;->b()Lorg/json/JSONObject;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1, p0}, Ld3/f;->k(Ljava/lang/String;Ljava/lang/String;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :catchall_0
    move-exception p0

    :try_start_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string p2, "ec:vrropso aeetjOs b"

    const-string/jumbo p2, "rj :oot Osarces eveb"

    const/4 v4, 0x5

    const-string p2, "av rct eq:josb Osrer"

    const-string/jumbo p2, "save Objects  error:"

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string/jumbo p1, "stsUiuQsMlgbu"

    const-string/jumbo p1, "tMsQsbuiulgUe"

    const/4 v4, 0x2

    const-string/jumbo p1, "lUemQtuMgesis"

    const-string p1, "MsgQueueUtils"

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1, p0}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :goto_1
    const/4 v3, 0x6

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :catchall_1
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    throw p0
.end method

.method public static c(Landroid/content/Context;Lo2/y;)Z
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x2

    sget-object v0, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x3

    const-string/jumbo v1, "sr_io0t3qeeevagp_vu5_mu"

    const-string/jumbo v1, "tqeivsuea_v_5pr_0mu3uge"

    const-string/jumbo v1, "sav0vbsre_qm3eeugt5_pui"

    const-string/jumbo v1, "msg_queue_v350_privates"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v2, "sulgUpueMsQue"

    const-string v2, "QtegUulpeMuss"

    const/4 v7, 0x4

    const-string/jumbo v2, "liMsQuupeUetg"

    const-string v2, "MsgQueueUtils"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v6, 0x3

    and-int/2addr v7, v6

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    sput-object v0, Lo2/a0;->a:Ljava/util/Queue;

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p0, v1}, Lo2/a0;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast v3, Lo2/y;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object v4, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x6

    invoke-interface {v4, v3}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v4, "efMq Qiique:sdlusaa enlgi"

    const-string/jumbo v4, "nsQd:uaiqtiee e Mlglsuiaf"

    const/4 v7, 0x1

    const-string/jumbo v4, "sgsMs :teeiiQituaanf ulld"

    const-string/jumbo v4, "init lastMsgQueue failed:"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v2, v0}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x2

    move v7, v6

    const/4 v0, 0x0

    or-int/2addr v7, v0

    const/4 v6, 0x0

    if-nez p0, :cond_1

    const/4 v7, 0x0

    const-string/jumbo p0, "lntmexunesep#tdtcaxnscu-  e wo"

    const-string p0, "a scpn#oxnuel-ecttndsx  twuele"

    const/4 v7, 0x3

    const-string/jumbo p0, "tnncotselex t# d enxcouw-al ue"

    const-string p0, "#unexcepted - context was null"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v2, p0}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    return v0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v3, "xu ltbp y #eenee-wtnadisK ctnlyu"

    const-string v3, "#unexcepted - entityKey was null"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v2, v3}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget-object v3, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v3, p1}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v3, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v0, "uppiDiu iud.lvpc  -emogrts cn msg aGs"

    const-string/jumbo v0, "oi-mp t udvnapr msgl secup DiG.e gsic"

    const/4 v7, 0x1

    const-string/jumbo v0, "r eesu paiipppto-ils gesG mucg .ndcD "

    const-string v0, "Duplicated msg. Give up processing - "

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v2, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 p0, 0x1

    const/4 v7, 0x2

    return p0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-object v3, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {v3}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/16 v4, 0xc8

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-lt v3, v4, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v3, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v3}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v3, Lo2/a0;->a:Ljava/util/Queue;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v3, p1}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p0, v1}, Lo2/a0;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez v3, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v3, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/16 v5, 0x32

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-lt v4, v5, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_6
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p0, v1, v3}, Lo2/a0;->b(Landroid/content/Context;Ljava/lang/String;Ljava/util/ArrayList;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const-string v1, "eiavioe q sd:ps  mngaf"

    const-string v1, "i  noifpelad sasg: evm"

    const/4 v7, 0x0

    const-string v1, "ess nams evg:p sdaiif "

    const-string/jumbo v1, "msg save in sp failed:"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-static {v2, p0}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    return v0
.end method

.method public static declared-synchronized d(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-class v0, Lo2/a0;

    const/4 v3, 0x4

    const-class v0, Lo2/a0;

    const-class v0, Lo2/a0;

    const/4 v3, 0x7

    monitor-enter v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo p0, "utUmbeuQgiesl"

    const-string p0, "UgteMbusuileQ"

    const/4 v3, 0x0

    const-string/jumbo p0, "seteolMgQUsuu"

    const-string p0, "MsgQueueUtils"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo p1, "necelbxtceldi t,xnnuo  uuesp"

    const-string/jumbo p1, "tnutxeuilcc eenlntupsxo , ed"

    const/4 v3, 0x3

    const-string/jumbo p1, "unexcepted , context is null"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x3

    or-int/2addr v3, v2

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p0, "lssepiugueUQt"

    const-string p0, "egsQiuepstulU"

    const/4 v3, 0x1

    const-string/jumbo p0, "leegMsupuiUtQ"

    const-string p0, "MsgQueueUtils"

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    const-string p1, "gider/ nqteq /clts a"

    const-string/jumbo p1, "r  tigsiq aen/dlt/ce"

    const/4 v3, 0x6

    const-string/jumbo p1, "lcsntt /i/rsifdeg ea"

    const-string p1, "can\'t get files dir"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_1
    :try_start_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v1, Ljava/io/File;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p0, :cond_2

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    invoke-virtual {v1}, Ljava/io/File;->delete()Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0
.end method
