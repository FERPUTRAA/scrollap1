.class public Lo2/w;
.super Lo2/v;


# static fields
.field public static volatile b:Lo2/w;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lo2/v;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static e()Lo2/w;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " fs MuS~~@lcb ~~@@ @v@~@ob s~4~@@y~ Ko-o@~i~@@i~~o /~i ~t@ bnd  ~ l~  m@t1oa.@@@f/@@~ r~ @@~~~ o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lo2/w;->b:Lo2/w;

    const/4 v3, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-class v0, Lo2/w;

    const/4 v3, 0x2

    const-class v0, Lo2/w;

    const-class v0, Lo2/w;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v1, Lo2/w;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1}, Lo2/w;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    sput-object v1, Lo2/w;->b:Lo2/w;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v2, 0x2

    move v3, v2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lo2/w;->b:Lo2/w;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method


# virtual methods
.method public c(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v0, "tismsuCosuTsseBn"

    const/4 v8, 0x6

    const-string v0, "MTCustomBusiness"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v1, "egsmems"

    const-string/jumbo v1, "message"

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eqz v2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    return-void

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    new-instance v2, Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {v2, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string p2, "amd_o"

    const-string p2, "aidm_"

    const/4 v8, 0x1

    const-string p2, "bd_di"

    const-string p2, "ad_id"

    const/4 v7, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v2, p2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string p1, "aa //auslacecodcssme,inbsaMgttcskIe t usumsgssomi cl/tnoulh/l e"

    const-string/jumbo p1, "utl o/ciao tnke,cassg/msMtsi elses hne sc csoadgltmcba/maul/sIu"

    const/4 v8, 0x6

    const-string p1, "hsc/aeap itmk gatcuesnslosctlla,esdsnsocg/uI csMue/is a mlm b/ "

    const-string p1, "customMessage\'s messageId is null, can\'t callback this custom"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v3, "tliqe"

    const-string v3, "bietl"

    const/4 v8, 0x0

    const-string v3, "eislt"

    const-string/jumbo v3, "title"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v5, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string p1, "c /muiacu/nbcenms oelaskt ll sscscungtitsnlma t t/hcouos /,te"

    const-string p1, "i osllugn t /nstshcs/c ostsa,lt emtaeaicnncum/Mubult o/ csekc"

    const/4 v8, 0x4

    const-string/jumbo p1, "os Moaeccsuslankccs lcg/oub no en i tn,usttmstilel/am// shcat"

    const-string p1, "customMessage\'s content is null, can\'t callback this custom"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    or-int/2addr v8, v7

    return-void

    :cond_2
    const/4 v8, 0x7

    const-string/jumbo v5, "teyttbpncnpo"

    const-string/jumbo v5, "yttetcopnenp"

    const/4 v8, 0x4

    const-string v5, "_ntncoueepty"

    const-string v5, "content_type"

    const/4 v8, 0x2

    const/4 v7, 0x7

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo v6, "qpstrx"

    const-string/jumbo v6, "trqxsa"

    const/4 v8, 0x3

    const-string/jumbo v6, "saqetx"

    const-string v6, "extras"

    const/4 v8, 0x7

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v2}, Lo3/f;->b(Lorg/json/JSONObject;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    new-instance v6, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v6}, Lcom/engagelab/privates/push/api/CustomMessage;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v6, p2}, Lcom/engagelab/privates/push/api/CustomMessage;->q(Ljava/lang/String;)Lcom/engagelab/privates/push/api/CustomMessage;

    move-result-object p2

    const/4 v8, 0x7

    invoke-virtual {p2, v3}, Lcom/engagelab/privates/push/api/CustomMessage;->u(Ljava/lang/String;)Lcom/engagelab/privates/push/api/CustomMessage;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2, v4}, Lcom/engagelab/privates/push/api/CustomMessage;->k(Ljava/lang/String;)Lcom/engagelab/privates/push/api/CustomMessage;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p2, v5}, Lcom/engagelab/privates/push/api/CustomMessage;->n(Ljava/lang/String;)Lcom/engagelab/privates/push/api/CustomMessage;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p2, v2}, Lcom/engagelab/privates/push/api/CustomMessage;->o(Landroid/os/Bundle;)Lcom/engagelab/privates/push/api/CustomMessage;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v2, Landroid/os/Bundle;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/16 p2, 0xbb9

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {p1, p2, v2}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    move v8, v7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string v1, "Mlssaeonesa f egs"

    const-string v1, "a so Mengslaefsde"

    const/4 v8, 0x4

    const-string v1, "eelm eafios dngMs"

    const-string/jumbo v1, "onMessage failed "

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-void
.end method

.method public d(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const-class p2, Lcom/engagelab/privates/push/api/CustomMessage;

    const-class p2, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v2, 0x6

    const-class p2, Lcom/engagelab/privates/push/api/CustomMessage;

    const-class p2, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, p2}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string p2, "asgsoee"

    const-string/jumbo p2, "message"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p3, p2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p2, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_0
    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :cond_1
    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onCustomMessage(Landroid/content/Context;Lcom/engagelab/privates/push/api/CustomMessage;)V

    const/4 v2, 0x1

    const/16 p2, 0xf9f

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x3

    const-string/jumbo p3, "niMaebdaie oapfslse ssmMec"

    const-string/jumbo p3, "iosmfesndMaseMer csaa liep"

    const/4 v2, 0x0

    const-string p3, "g ecM uosefraneMsdileasiap"

    const-string/jumbo p3, "processMainMessage failed "

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo p2, "ussmCsnpMsitTBuo"

    const-string p2, "TMsConuBmistessu"

    const/4 v2, 0x6

    const-string/jumbo p2, "uusMnosmqCstsTei"

    const-string p2, "MTCustomBusiness"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public f(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string p2, "BmsbuCintTesossu"

    const-string p2, "ToCMnbseutmisusB"

    const/4 v5, 0x6

    const-string p2, "MssmusCBmTeouist"

    const-string p2, "MTCustomBusiness"

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-class v0, Lcom/engagelab/privates/push/api/CustomMessage;

    const-class v0, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v5, 0x1

    const-class v0, Lcom/engagelab/privates/push/api/CustomMessage;

    const-class v0, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v0, "sgusoea"

    const-string v0, "gsmaesu"

    const/4 v5, 0x4

    const-string/jumbo v0, "megesba"

    const-string/jumbo v0, "message"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast p3, Lcom/engagelab/privates/push/api/CustomMessage;

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-nez p3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v0, "msCoeputouesnMa"

    const-string v0, "gneaomCpsoeuMst"

    const/4 v5, 0x2

    const-string v0, "egesasmpnCotuos"

    const-string/jumbo v0, "onCustomMessage"

    const/4 v4, 0x4

    move v5, v4

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v1, "siq_md"

    const-string/jumbo v1, "sdqim_"

    const/4 v5, 0x6

    const-string/jumbo v1, "issmdg"

    const-string/jumbo v1, "msg_id"

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p3}, Lcom/engagelab/privates/push/api/CustomMessage;->e()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    invoke-virtual {p3}, Lcom/engagelab/privates/push/api/CustomMessage;->g()B

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v1, "sdtmsekp"

    const-string/jumbo v1, "sps_etdk"

    const/4 v5, 0x0

    const-string/jumbo v1, "tykdopes"

    const-string/jumbo v1, "sdk_type"

    :try_start_2
    const/4 v5, 0x2

    invoke-virtual {p3}, Lcom/engagelab/privates/push/api/CustomMessage;->g()B

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "sgd_mbi"

    const-string v1, "gimms_d"

    const/4 v5, 0x1

    const-string/jumbo v1, "s_idgtu"

    const-string/jumbo v1, "tmsg_id"

    :try_start_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3}, Lcom/engagelab/privates/push/api/CustomMessage;->h()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo p3, "sst__auptrmidgos"

    const-string p3, "ats_o_thmurdsgis"

    const/4 v5, 0x0

    const-string/jumbo p3, "third_msg_status"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v1, 0xc82

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo p3, "msbt_tsuqg"

    const-string p3, "_mtgubssta"

    const/4 v5, 0x0

    const-string p3, "a_smtsssgu"

    const-string/jumbo p3, "msg_status"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/16 v1, 0xc81

    :goto_0
    :try_start_4
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "suumlr"

    const-string/jumbo v2, "urtlus"

    const/4 v5, 0x6

    const-string/jumbo v2, "sluroe"

    const-string/jumbo v2, "result"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/16 v3, 0x3fa

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x4

    new-instance v2, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v2}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2, p3}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p3, v2}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Landroid/os/Bundle;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v3, "ooporltp"

    const/4 v5, 0x1

    const-string/jumbo v3, "optroboc"

    const-string/jumbo v3, "protocol"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3, p3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/16 p3, 0x8b9

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p1, p3, v2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance p3, Landroid/os/Bundle;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v2, "osnj"

    const-string/jumbo v2, "osjn"

    const/4 v5, 0x0

    const-string/jumbo v2, "jnso"

    const-string/jumbo v2, "json"

    :try_start_5
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p3, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1, v1, p3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v0, "es Mamucseelfa drietgopsoqes"

    const-string/jumbo v0, "tmeresicqaoRgMae foed sesspl"

    const/4 v5, 0x7

    const-string/jumbo v0, "scmRearpfseesilopdestoeg ae "

    const-string/jumbo v0, "processRemoteMessage failed "

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method
