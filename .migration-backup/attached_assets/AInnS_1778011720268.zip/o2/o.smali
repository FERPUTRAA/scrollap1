.class public Lo2/o;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/net/DatagramSocket;

.field public b:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "ois M~~ ~. /@/ b@o s d@~@@ ~bao f~ cf-n~ @~K@@ @t@~y@@@@l @@~4~~i~@ b~@m@~~~o1lvt S~~r o~@ ~~i o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    const-string/jumbo v0, "ptstrro_htp"

    const/4 v7, 0x4

    const-string/jumbo v0, "trrmpteohp_"

    const-string v0, "http_report"

    const/4 v7, 0x3

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v1, Ljava/util/LinkedHashSet;

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x0

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-lez v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ge v3, v4, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v5, "/mh:opt"

    const-string v5, "/t/m:hp"

    const/4 v7, 0x4

    const-string v5, ":ttp/b/"

    const-string v5, "http://"

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v0, "hep_oouttptr"

    const-string/jumbo v0, "ttesoporth_p"

    const/4 v7, 0x2

    const-string/jumbo v0, "prtt_sopherp"

    const-string v0, "https_report"

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz p2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-lez v0, :cond_1

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ge v2, v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v3, "qts:phb/"

    const-string/jumbo v3, "thts/b:p"

    const/4 v7, 0x2

    const-string v3, "/ps/ths:"

    const-string v3, "https://"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p2, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p1, v1}, Lo2/q;->f(Landroid/content/Context;Ljava/util/Set;)V

    const/4 v6, 0x1

    move v7, v6

    return-void
.end method

.method public final b(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v0, "Utnmpuldi"

    const-string/jumbo v0, "neltUduip"

    const/4 v6, 0x5

    const-string/jumbo v0, "ntUdopCle"

    const-string v0, "UdpClient"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    return v1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-gtz p3, :cond_1

    const/4 v6, 0x3

    return v1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v3, "cd tpbunc ne"

    const-string v3, "dtcoc npeu n"

    const/4 v6, 0x2

    const-string v3, " ed cuucpntn"

    const-string/jumbo v3, "udp connect "

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    move v6, v5

    const-string v3, ":"

    const-string v3, ":"

    const/4 v6, 0x2

    const-string v3, ":"

    const-string v3, ":"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lo2/o;->d(Landroid/content/Context;)[B

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    return v1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v3, Ljava/net/DatagramPacket;

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    array-length v4, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v3, v2, v4, p2, p3}, Ljava/net/DatagramPacket;-><init>([BILjava/net/InetAddress;I)V

    const/4 v6, 0x0

    new-instance p2, Ljava/net/DatagramSocket;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p2}, Ljava/net/DatagramSocket;-><init>()V

    const/4 v6, 0x0

    iput-object p2, p0, Lo2/o;->a:Ljava/net/DatagramSocket;

    const/4 v6, 0x5

    const/16 p3, 0x1770

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p2, p3}, Ljava/net/DatagramSocket;->setSoTimeout(I)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object p2, p0, Lo2/o;->a:Ljava/net/DatagramSocket;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2, v3}, Ljava/net/DatagramSocket;->send(Ljava/net/DatagramPacket;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 p2, 0x400

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array p3, p2, [B

    const/4 v6, 0x3

    const/4 v5, 0x1

    new-instance v2, Ljava/net/DatagramPacket;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v2, p3, p2}, Ljava/net/DatagramPacket;-><init>([BI)V

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p2, p0, Lo2/o;->a:Ljava/net/DatagramSocket;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p2, v2}, Ljava/net/DatagramSocket;->receive(Ljava/net/DatagramPacket;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0, p1, p3}, Lo2/o;->c(Landroid/content/Context;[B)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    return p1

    :catchall_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    move v6, v5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string p3, " fccqoupteid n peld"

    const-string p3, "e nuf doqpitcd ncle"

    const/4 v6, 0x5

    const-string p3, "atndopufqc n idcle "

    const-string/jumbo p3, "udp connect failed "

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    return v1
.end method

.method public final c(Landroid/content/Context;[B)Z
    .locals 13

    const/4 v12, 0x0

    const-string v0, "disCsetpl"

    const-string/jumbo v0, "itslpCden"

    const-string v0, "Udimlepnt"

    const-string v0, "UdpClient"

    const/4 v12, 0x3

    const/16 v1, 0xa

    const/4 v12, 0x5

    const/4 v2, 0x0

    :try_start_0
    const/4 v12, 0x4

    new-array v3, v1, [B

    const/4 v12, 0x3

    invoke-static {p2, v2, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v12, 0x1

    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v12, 0x4

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    const/4 v12, 0x7

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->getShort()S

    const/4 v12, 0x7

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v5

    const/4 v12, 0x7

    ushr-int/lit8 v6, v5, 0x18

    const/4 v12, 0x7

    const v7, 0xffffff

    const/4 v12, 0x2

    and-int/2addr v5, v7

    const/4 v12, 0x4

    int-to-long v7, v5

    const/4 v12, 0x5

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->getShort()S

    const/4 v12, 0x7

    ushr-int/lit8 v3, v6, 0x4

    const/4 v12, 0x5

    const/4 v5, 0x1

    const/4 v12, 0x1

    and-int/2addr v6, v5

    const/4 v12, 0x0

    invoke-static {v7, v8}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x0

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const-string/jumbo v11, "teeLoe tevnglirhmc:t"

    const-string/jumbo v11, "tatmichLege :ventrel"

    const-string/jumbo v11, "ng:cLbeie rvotaeelth"

    const-string/jumbo v11, "receive totalLength:"

    const/4 v12, 0x7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v11, "non i,upry:ec"

    const-string v11, ", encryption:"

    const/4 v12, 0x4

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string/jumbo v11, "oco,p rpesm"

    const-string/jumbo v11, "sor,omp c:e"

    const-string/jumbo v11, "rs comp:qs,"

    const-string v11, ", compress:"

    const/4 v12, 0x3

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string v11, ":,sbsd"

    const-string v11, "d, s:b"

    const-string v11, "i ,md:"

    const-string v11, ", sid:"

    const/4 v12, 0x7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v10, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x0

    invoke-static {v0, v7}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    sub-int/2addr v4, v1

    const/4 v12, 0x3

    new-array v7, v4, [B

    const/4 v12, 0x0

    invoke-static {p2, v1, v7, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v12, 0x7

    if-eq v3, v5, :cond_1

    const/4 v12, 0x5

    const/4 p2, 0x2

    if-eq v3, p2, :cond_0

    invoke-static {v7, v9}, Ld3/a;->c([BLjava/lang/String;)[B

    move-result-object p2

    const/4 v12, 0x6

    goto :goto_0

    :cond_0
    const/4 v12, 0x3

    invoke-static {v7, v9}, Ld3/n;->h([BLjava/lang/String;)[B

    move-result-object p2

    const/4 v12, 0x7

    goto :goto_0

    :cond_1
    const/4 v12, 0x0

    const/16 p2, 0x10

    const/4 v12, 0x4

    invoke-virtual {v9, v2, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x1

    invoke-static {v7, v9, p2}, Ld3/a;->d([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object p2

    :goto_0
    const/4 v12, 0x1

    if-ne v6, v5, :cond_2

    const/4 v12, 0x0

    invoke-static {p2}, Ld3/g;->b([B)[B

    move-result-object p2

    :cond_2
    const/4 v12, 0x7

    new-instance v1, Ljava/lang/String;

    const/4 v12, 0x0

    invoke-direct {v1, p2}, Ljava/lang/String;-><init>([B)V

    const/4 v12, 0x5

    new-instance p2, Lorg/json/JSONObject;

    const/4 v12, 0x0

    invoke-direct {p2, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    const-string/jumbo v3, "icvuodeuer  "

    const-string/jumbo v3, "vir ueudce e"

    const-string/jumbo v3, "udp receive "

    const/4 v12, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-static {p2}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x4

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    invoke-virtual {p0, p1, p2}, Lo2/o;->j(Landroid/content/Context;Lorg/json/JSONObject;)V

    const/4 v12, 0x7

    invoke-virtual {p0, p1, p2}, Lo2/o;->h(Landroid/content/Context;Lorg/json/JSONObject;)V

    const/4 v12, 0x7

    invoke-virtual {p0, p1, p2}, Lo2/o;->f(Landroid/content/Context;Lorg/json/JSONObject;)V

    const/4 v12, 0x1

    invoke-virtual {p0, p1, p2}, Lo2/o;->a(Landroid/content/Context;Lorg/json/JSONObject;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x6

    return v5

    :catchall_0
    move-exception p1

    const/4 v12, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x5

    const-string v1, "efaeebailpsrp pes Rod"

    const-string/jumbo v1, "osslap pseR frieapede"

    const-string v1, "efpnaauRei leopsersd "

    const-string/jumbo v1, "parseResponse failed "

    const/4 v12, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    return v2
.end method

.method public final d(Landroid/content/Context;)[B
    .locals 14

    const/4 v12, 0x1

    const/4 v13, 0x1

    const-string/jumbo v0, "pqitneUpC"

    const-string/jumbo v0, "netiCUpdq"

    const/4 v13, 0x7

    const-string v0, "epdnUltiq"

    const-string v0, "UdpClient"

    :try_start_0
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x4

    new-instance v1, Lorg/json/JSONObject;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    const-string/jumbo v2, "tosspfal"

    const-string v2, "fostarpl"

    const/4 v13, 0x5

    const-string/jumbo v2, "mtlmfapo"

    const-string/jumbo v2, "platform"

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x0

    const/4 v3, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x4

    const-string/jumbo v2, "sedmok"

    const-string v2, "dsrmek"

    const-string v2, "dvserb"

    const-string/jumbo v2, "sdkver"

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x1

    const-string v4, ".uo5."

    const-string v4, "5..4o"

    const-string v4, ".3p45"

    const-string v4, "4.3.5"

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x2

    const-string/jumbo v2, "ykqppa"

    const-string v2, "akppyb"

    const/4 v13, 0x0

    const-string v2, "appkey"

    :try_start_1
    invoke-static {p1}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    const-string/jumbo v2, "iud"

    const-string/jumbo v2, "udi"

    const/4 v13, 0x6

    const-string v2, "dui"

    const-string/jumbo v2, "uid"

    :try_start_2
    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-static {p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v4

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-virtual {v1, v2, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x2

    const-string/jumbo v2, "ptye"

    const-string/jumbo v2, "type"

    :try_start_3
    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-static {}, Ly2/b;->w()I

    move-result v4

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x7

    const-string/jumbo v2, "pasur"

    const-string/jumbo v2, "rupae"

    const/4 v13, 0x5

    const-string/jumbo v2, "rpame"

    const-string/jumbo v2, "opera"

    :try_start_4
    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-static {}, Ly2/b;->t()Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v13, 0x6

    invoke-static {}, Ly2/b;->y()Z

    move-result v2

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    const/4 v4, 0x1

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x3

    if-eqz v2, :cond_1

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-static {p1}, Lo2/q;->h(Landroid/content/Context;)I

    move-result p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const-string/jumbo v2, "vreeo_tc"

    const-string v2, "cert_ver"

    const/4 v12, 0x4

    xor-int/2addr v13, v12

    const/4 v5, -0x1

    const/4 v5, -0x1

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x1

    if-ne p1, v5, :cond_0

    const/4 v12, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    move p1, v4

    const/4 v13, 0x6

    move p1, v4

    move p1, v4

    :cond_0
    :try_start_5
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_1
    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x4

    const-string/jumbo v2, "pd upbdne"

    const-string v2, " :edpudpn"

    const/4 v13, 0x6

    const-string v2, ":dupesud "

    const-string/jumbo v2, "udp send:"

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-static {v1}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    const/4 v12, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-static {p1}, Ld3/o;->k(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v13, 0x2

    invoke-static {p1}, Ld3/g;->c([B)[B

    move-result-object v1

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    if-nez v1, :cond_2

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x2

    move v1, v3

    move v1, v3

    const/4 v13, 0x3

    move v1, v3

    move v1, v3

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    goto :goto_0

    :cond_2
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x1

    move v1, v4

    move v1, v4

    const/4 v13, 0x7

    move v1, v4

    move v1, v4

    :goto_0
    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x5

    array-length v2, p1

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-static {}, Ld3/a;->h()I

    move-result v5

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    int-to-long v6, v5

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-static {v6, v7}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x6

    if-eqz v1, :cond_3

    const/4 v13, 0x4

    int-to-byte v9, v4

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x5

    goto :goto_1

    :cond_3
    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x0

    move v9, v3

    move v9, v3

    const/4 v13, 0x3

    move v9, v3

    move v9, v3

    :goto_1
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-static {}, Ly2/b;->p()I

    move-result v10

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    const/16 v11, 0x10

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x6

    if-eq v10, v4, :cond_5

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    if-eq v10, v4, :cond_4

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-static {p1, v8}, Ld3/a;->e([BLjava/lang/String;)[B

    move-result-object p1

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x5

    goto :goto_2

    :cond_4
    const/4 v13, 0x1

    const/4 v12, 0x7

    or-int/lit8 v4, v9, 0x20

    const/4 v13, 0x4

    int-to-byte v9, v4

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v8, v3, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-static {p1, v8, v4}, Ld3/n;->k([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_2

    :cond_5
    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x4

    or-int/lit8 v4, v9, 0x10

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x3

    int-to-byte v9, v4

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-virtual {v8, v3, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-static {p1, v8, v4}, Ld3/a;->f([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    :goto_2
    const/4 v13, 0x2

    const/4 v12, 0x0

    new-instance v4, Lf3/b;

    const/4 v13, 0x6

    array-length v8, p1

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    add-int/lit8 v8, v8, 0xa

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-direct {v4, v8}, Lf3/b;-><init>(I)V

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-virtual {v4, v3}, Lf3/b;->l(I)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    const-string v8, "GU"

    const-string v8, "UG"

    const/4 v13, 0x3

    const-string v8, "UG"

    const-string v8, "UG"

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-virtual {v8}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {v4, v8}, Lf3/b;->h([B)V

    const/4 v13, 0x3

    invoke-virtual {v4, v6, v7}, Lf3/b;->n(J)V

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x1

    const/4 v6, 0x4

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v4, v9, v6}, Lf3/b;->s(II)V

    const/4 v13, 0x4

    invoke-virtual {v4, v2}, Lf3/b;->l(I)V

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-virtual {v4, p1}, Lf3/b;->h([B)V

    const/4 v13, 0x4

    invoke-virtual {v4}, Lf3/b;->b()I

    move-result p1

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v4, p1, v3}, Lf3/b;->m(II)V

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x0

    const-string v2, "Ldneh:tp eqongats"

    const-string v2, "aest:dhtqneongL t"

    const/4 v13, 0x5

    const-string v2, "dhtngalLqnt:e tos"

    const-string/jumbo v2, "send totalLength:"

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v4}, Lf3/b;->b()I

    move-result v2

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x0

    const-string v2, " tspcenry,:on"

    const-string/jumbo v2, "tpsoc:n nyer,"

    const/4 v13, 0x1

    const-string/jumbo v2, "ypnme:ict ron"

    const-string v2, ", encryption:"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    move v13, v12

    invoke-virtual {p1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "e:c osopmsr"

    const-string v2, "e smpocs:mr"

    const/4 v13, 0x4

    const-string/jumbo v2, "r:pcobs,m s"

    const-string v2, ", compress:"

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x4

    const-string/jumbo v1, "u:d io"

    const-string v1, "d,:io "

    const/4 v13, 0x1

    const-string/jumbo v1, "ipds, "

    const-string v1, ", sid:"

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v4}, Lf3/b;->g()[B

    move-result-object p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    const-string v2, "aiRleebpqgea adkueqfc "

    const-string v2, " fecdbaeqRgpuelsa kaei"

    const/4 v13, 0x6

    const-string/jumbo v2, "packageRequest failed "

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/4 p1, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    return-object p1
.end method

.method public final e(Landroid/content/Context;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lo2/o;->g(Landroid/content/Context;)Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public final f(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Ly2/b;->y()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo v0, "tvse_cre"

    const-string v0, "cveetru_"

    const/4 v4, 0x4

    const-string/jumbo v0, "veemrr_c"

    const-string v0, "cert_ver"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Lo2/q;->F(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    new-instance v1, Ljava/util/LinkedHashSet;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, v1}, Lo2/q;->o(Landroid/content/Context;Ljava/util/Set;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lo2/q;->v(Landroid/content/Context;I)V

    const/4 v4, 0x4

    const-string/jumbo v0, "psiposs"

    const-string/jumbo v0, "p_pssis"

    const/4 v4, 0x2

    const-string/jumbo v0, "sssplb_"

    const-string/jumbo v0, "ssl_ips"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-lez v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ge v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lo2/q;->o(Landroid/content/Context;Ljava/util/Set;)V

    const/4 v4, 0x5

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p2, "deUnqiupC"

    const-string p2, "eidtnpCUq"

    const/4 v4, 0x4

    const-string p2, "ditUnCppl"

    const-string p2, "UdpClient"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "r_s enahqtrs eo"

    const-string v0, "aesnrv so_re ht"

    const/4 v4, 0x1

    const-string/jumbo v0, "no has cert_ver"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p2, Ljava/util/LinkedHashSet;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p2}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1, p2}, Lo2/q;->o(Landroid/content/Context;Ljava/util/Set;)V

    :cond_3
    :goto_1
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public final g(Landroid/content/Context;)Ljava/util/Set;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {p1}, Lo2/q;->G(Landroid/content/Context;)Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {p1}, Lh3/b;->a(Landroid/content/Context;)Lcom/engagelab/privates/core/api/Address;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->i()I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-gtz v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    return-object v0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->g()[Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-string v3, ":"

    const-string v3, ":"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v4, 0x0

    move v10, v4

    const/4 v9, 0x3

    move v10, v9

    if-eqz v2, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    array-length v5, v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-lez v5, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    array-length v5, v2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    move v6, v4

    move v6, v4

    const/4 v10, 0x7

    move v6, v4

    move v6, v4

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-ge v6, v5, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    aget-object v7, v2, v6

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {v0, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v6, v6, 0x1

    const/4 v9, 0x0

    move v10, v9

    goto :goto_0

    :cond_1
    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->h()[Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz p1, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    array-length v2, p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-lez v2, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    array-length v2, p1

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-ge v4, v2, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    aget-object v5, p1, v4

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    invoke-interface {v0, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_1

    :cond_2
    const/4 v9, 0x6

    const/4 v10, 0x1

    return-object v0
.end method

.method public final h(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v0, "psi"

    const-string/jumbo v0, "spi"

    const/4 v4, 0x3

    const-string/jumbo v0, "isp"

    const-string/jumbo v0, "ips"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-lez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lo2/q;->l(Landroid/content/Context;Ljava/util/Set;)V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method public i(Landroid/content/Context;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-boolean v0, p0, Lo2/o;->b:Z

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo v1, "misnteCpl"

    const-string v1, "Cnimdlpte"

    const/4 v9, 0x3

    const-string v1, "CdimpUlnt"

    const-string v1, "UdpClient"

    const/4 v8, 0x4

    move v9, v8

    if-eqz v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string p1, "doctocU,pontne/ ganiCine tc/soc"

    const-string p1, "/soionnonen  tnpUtci,accgctde/C"

    const-string p1, "cCngebaUntcp/n iocodnsctn i/,en"

    const-string p1, "can\'t connect, isUdpConnecting"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v0, 0x1

    const/4 v9, 0x3

    iput-boolean v0, p0, Lo2/o;->b:Z

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {p0, p1}, Lo2/o;->e(Landroid/content/Context;)Ljava/util/List;

    move-result-object v2

    const/4 v8, 0x7

    move v9, v8

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v3, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string p1, "an  otue tecsd rnadenuro rechedb"

    const-string p1, "e derb ecaa teeonsu nnct dhprodr"

    const/4 v9, 0x0

    const-string p1, " nhu onprpeate csd eaceeon drtsd"

    const-string/jumbo p1, "there are no udp connect address"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    return-void

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v3, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v6, 0x3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-ge v5, v6, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {v3, v2}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto :goto_0

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v3, :cond_6

    const/4 v8, 0x2

    move v9, v8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    check-cast v3, Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p1}, Lo2/q;->p(Landroid/content/Context;)Z

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez v5, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v0, "eea/nnscqttacoctce eis,snnt  tfno c/al"

    const-string/jumbo v0, "nsoettutiac t acne/sf  cc/seonn,aletnc"

    const/4 v9, 0x2

    const-string v0, "eesi, ft tns/c/a tntaecooencnatl s csc"

    const-string v0, "can\'t connect ,connect state is false"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    invoke-virtual {p0, p1}, Lo2/o;->l(Landroid/content/Context;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    return-void

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-nez v5, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string p1, "entmecsdo oCcantp,nneo/ dwcn tir/ iskec"

    const-string p1, "cnowns pkCedn,tcrono/ee d tcsin/ena tic"

    const/4 v9, 0x1

    const-string p1, "dn/toCteennaor cdt/c eesk ,ooncwicti nn"

    const-string p1, "can\'t connect, network is disConnected"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    return-void

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v5, ":"

    const-string v5, ":"

    const-string v5, ":"

    const-string v5, ":"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    array-length v6, v5

    const/4 v9, 0x6

    sub-int/2addr v6, v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    aget-object v5, v5, v6

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    sub-int/2addr v6, v7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    sub-int/2addr v6, v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v3, v4, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0, p1, v3, v5}, Lo2/o;->b(Landroid/content/Context;Ljava/lang/String;I)Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v3, :cond_3

    const/4 v9, 0x5

    invoke-virtual {p0, p1}, Lo2/o;->k(Landroid/content/Context;)V

    :cond_6
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    return-void
.end method

.method public final j(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/json/JSONException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v0, "ssi_ibq"

    const-string/jumbo v0, "iqsss_i"

    const/4 v4, 0x2

    const-string/jumbo v0, "ipssisu"

    const-string/jumbo v0, "sis_ips"

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-eqz p2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-lez v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v4, 0x5

    const/4 v1, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-ge v1, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lo2/q;->t(Landroid/content/Context;Ljava/util/Set;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method public final k(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Ly2/b;->y()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Lo2/q;->h(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1}, Lo2/q;->F(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v0, v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v1, v2, :cond_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, "_uL1rccpsaonctvft_Sef/"

    const-string/jumbo v3, "rtscoufa1nSefLvn/c_tc_"

    const/4 v5, 0x3

    const-string v3, "SatnfcnLqf_Srov/teu_cc"

    const-string v3, "connectSSL_crt_v\uff1a"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "tCsUpnemd"

    const-string v2, "UntmlpCde"

    const/4 v5, 0x2

    const-string v2, "UlemptCnd"

    const-string v2, "UdpClient"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v3, "Sv_totfL/eAc1dsrcdpfar_sS"

    const-string/jumbo v3, "tcpAddressSSL_crt_v\uff1a"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-static {p1}, Lo2/j;->b(Landroid/content/Context;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const-string v1, "grte/b1ff act"

    const-string v1, "get crt\uff1a"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v2, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public l(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-boolean p1, p0, Lo2/o;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Lo2/o;->a:Ljava/net/DatagramSocket;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo p1, "poiUtnuCe"

    const-string p1, "enidoCtpU"

    const/4 v2, 0x5

    const-string/jumbo p1, "nCtpleipd"

    const-string p1, "UdpClient"

    const/4 v2, 0x0

    const-string v0, " noedcdpqnctub"

    const-string v0, "ecndobnc idtup"

    const/4 v2, 0x0

    const-string v0, " usdpcdtcsnion"

    const-string/jumbo v0, "udp disconnect"

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lo2/o;->a:Ljava/net/DatagramSocket;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/net/DatagramSocket;->close()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
