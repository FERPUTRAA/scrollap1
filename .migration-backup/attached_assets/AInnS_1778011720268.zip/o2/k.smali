.class public abstract Lo2/k;
.super Ljava/lang/Object;


# instance fields
.field public final a:Ljava/util/concurrent/ConcurrentMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentMap<",
            "Lcom/engagelab/privates/core/api/MTProtocol;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public b:Z

.field public c:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lo2/k;->a:Ljava/util/concurrent/ConcurrentMap;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;[B)Lcom/engagelab/privates/core/api/MTProtocol;
    .locals 20

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-direct {v2}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v3, 0x2

    new-array v4, v3, [B

    const/4 v5, 0x0

    invoke-static {v0, v5, v4, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static {v4}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    ushr-int/lit8 v6, v4, 0xf

    const/4 v7, 0x1

    and-int/2addr v6, v7

    ushr-int/lit8 v8, v4, 0xe

    and-int/2addr v8, v7

    and-int/lit16 v4, v4, 0x3fff

    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, ",issaochc:ihyetrentn:pa ele2e gedrn"

    const-string v11, ",est:o: vancdhieetnrprnheeaei2ylcg "

    const-string v11, "2almv edtr e iehceerannciytegop,::h"

    const-string/jumbo v11, "receive ahead length:2, encryption:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "x adoe:n,"

    const-string v6, ", expand:"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "teLhabt:l ,mno"

    const-string/jumbo v6, "ottmL:an,lh et"

    const-string v6, ",ttog u:lLaten"

    const-string v6, ", totalLength:"

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v9, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v6, v4, -0x2

    new-array v9, v6, [B

    invoke-static {v0, v3, v9, v5, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static {v9}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    if-ne v8, v7, :cond_1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v6

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v10

    goto :goto_0

    :cond_1
    const/16 v6, 0x14

    move v10, v5

    move v10, v5

    move v10, v5

    :goto_0
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v11

    xor-int/lit8 v11, v11, 0x5a

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v12

    xor-int/lit8 v12, v12, 0x5a

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v13

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    xor-long/2addr v13, v15

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v17

    move/from16 v19, v4

    move/from16 v19, v4

    move/from16 v19, v4

    xor-long v3, v17, v15

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v15

    if-ne v8, v7, :cond_2

    if-ne v10, v7, :cond_2

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v0

    goto :goto_1

    :cond_2
    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    :goto_1
    invoke-virtual {v2, v11}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-virtual {v2, v12}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-virtual {v2, v3, v4}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "gervecepen dhe h :til"

    const-string/jumbo v7, "receive head  length:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "iaodV,n qrhs:o"

    const-string v7, "Vi ,or:shdneoa"

    const-string v7, "dssnVre :,aohe"

    const-string v7, ", headVersion:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, ":bcmnm,odm"

    const-string/jumbo v7, "ocmdnbma,:"

    const-string/jumbo v7, "m:a,ocm nd"

    const-string v7, ", command:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "ue: ob,riv"

    const-string v7, ":i s,ouvre"

    const-string/jumbo v7, "vo rneuis,"

    const-string v7, ", version:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, " piu:,"

    const-string/jumbo v7, "ip:,u "

    const-string v7, ", uid:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v7, "diq :,"

    const-string v7, " ,qid:"

    const-string v7, "i,s:rd"

    const-string v7, ", rid:"

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, "c1cm, :r"

    const-string v3, "1,sc cr:"

    const-string v3, "c:c o61,"

    const-string v3, ", crc16:"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "rncp b:ymt"

    const-string v3, " :nm,rpcyt"

    const-string v3, "e: ,rtuypn"

    const-string v3, ", encrypt:"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v8, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    sub-int v4, v19, v6

    const/4 v1, 0x2

    sub-int/2addr v4, v1

    new-array v1, v4, [B

    invoke-static {v9, v6, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-static/range {p1 .. p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v6

    invoke-static {v6, v7}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v3

    if-eqz v0, :cond_5

    const/4 v6, 0x1

    if-eq v0, v6, :cond_4

    const/4 v6, 0x2

    if-eq v0, v6, :cond_3

    goto :goto_3

    :cond_3
    invoke-static {v1, v3}, Ld3/n;->h([BLjava/lang/String;)[B

    move-result-object v0

    goto :goto_2

    :cond_4
    const/16 v0, 0x10

    invoke-virtual {v3, v5, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v3, v0}, Ld3/a;->d([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v0

    goto :goto_2

    :cond_5
    invoke-static {v1, v3}, Ld3/a;->c([BLjava/lang/String;)[B

    move-result-object v0

    :goto_2
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_3
    invoke-virtual {v2, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "bl : iopynedveoetgr e"

    const-string/jumbo v5, "lb:voengeedr t eyc oi"

    const-string v5, "hdet:nivqecege ly r o"

    const-string/jumbo v5, "receive body  length:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "tys,:n yecetdhgoLdpr"

    const-string v4, ", decryptBodyLength:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v1, v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    return-object v2

    :catchall_0
    const/4 v0, 0x0

    goto :goto_4

    :catchall_1
    move-object v0, v1

    move-object v0, v1

    :goto_4
    return-object v0
.end method

.method public abstract b()Ljava/lang/String;
.end method

.method public abstract c(Landroid/content/Context;)V
.end method

.method public d(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@c@mo ~~ @S4u~  i~ioy~/@.  K @~v@~@@~ ~@  ~s-~ntl ~@~ bm@oa~ @@ @bM~o@d1 @l@@tfrb~ ~/~~~@o@~oi ~"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x2

    const-string/jumbo v0, "taad"

    const/4 v11, 0x5

    const-string/jumbo v0, "taad"

    const-string v0, "data"

    const/4 v11, 0x6

    if-nez p2, :cond_0

    :try_start_0
    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string v0, " i/bol ddub/sn,nletunecn  s"

    const-string v0, ",ddtlbn /icea s  nebunul/sn"

    const/4 v11, 0x1

    const-string/jumbo v0, "ieunab/d ll bsu/cdsnn , tne"

    const-string v0, "can\'t send, bundle is null"

    const/4 v10, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    return-void

    :catchall_0
    move-exception p2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto/16 :goto_1

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v1, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-boolean v1, p0, Lo2/k;->b:Z

    const/4 v10, 0x3

    const/4 v10, 0x4

    if-eqz v1, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-nez v1, :cond_1

    const/4 v11, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p0, p1, p2}, Lo2/k;->i(Landroid/content/Context;[B)V

    const/4 v11, 0x4

    return-void

    :cond_2
    :goto_0
    const/4 v11, 0x2

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string/jumbo v0, "n cn eutuneinac,to snc dottetspdadca//"

    const-string/jumbo v0, "sdenn,uctstt  ciotoecn  a//ndaendtpca "

    const/4 v11, 0x7

    const-string/jumbo v0, "oo/dndcp/,a itnec dc  aeaptc sttnne ts"

    const-string v0, "can\'t send data, tcp is not connected"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-void

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    const-class v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const-class v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const-class v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const-class v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string/jumbo v0, "qtocolro"

    const-string/jumbo v0, "otolcrop"

    const/4 v11, 0x6

    const-string v0, "cpsroool"

    const-string/jumbo v0, "protocol"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    check-cast v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string v3, "csnmt/ nm:dde qcm/aa"

    const-string v3, "dds mnmtqa/n:cn/ eac"

    const/4 v11, 0x5

    const-string/jumbo v3, "naeoot/:dan dcm/s nm"

    const-string v3, "can\'t send command:"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-nez v1, :cond_4

    :try_start_1
    const/4 v10, 0x7

    move v11, v10

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v3

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    move v11, v10

    const-string/jumbo v3, "n   ibnenkdCrce,dssoiwstt"

    const-string/jumbo v3, "nes kcone tstC esddrin,iw"

    const/4 v11, 0x5

    const-string/jumbo v3, "sotnodu,ewikt iCed nrsne "

    const-string v3, ", network is disConnected"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->e()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v6

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x1

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static/range {v4 .. v9}, Lq2/a;->i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    return-void

    :cond_4
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    iget-boolean v1, p0, Lo2/k;->b:Z

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-nez v1, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v3

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string v3, "Cntc idpses ie,tocn p"

    const-string v3, ", tcp is disConnected"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x2

    move v11, v10

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->e()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x1

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static/range {v4 .. v9}, Lq2/a;->i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-void

    :cond_5
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    cmp-long v1, v1, v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez v1, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {}, Lh3/b;->m()J

    move-result-wide v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    :cond_6
    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string v3, " edmn"

    const/4 v11, 0x0

    const-string v3, "dseq "

    const-string/jumbo v3, "send "

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v1, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->e()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p0, p1, v0}, Lo2/k;->g(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)[B

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x0

    if-nez v1, :cond_7

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    return-void

    :cond_7
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p0, p1, v1}, Lo2/k;->i(Landroid/content/Context;[B)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-eqz v1, :cond_8

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    return-void

    :cond_8
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    iget-object v1, p0, Lo2/k;->a:Ljava/util/concurrent/ConcurrentMap;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-wide/16 v7, 0x2710

    const/4 v11, 0x7

    const-wide/16 v7, 0x2710

    const-wide/16 v7, 0x2710

    move-object v3, p1

    move-object v3, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static/range {v3 .. v8}, Lq2/a;->i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto :goto_2

    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v2, "eessilo afdn"

    const-string v2, "elsdofae  in"

    const/4 v11, 0x0

    const-string/jumbo v2, "s  midlefned"

    const-string/jumbo v2, "send failed "

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v0, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p2, 0x4

    or-int/2addr v11, p2

    const/4 p2, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p0, p1, p2}, Lo2/k;->e(Landroid/content/Context;Z)V

    :goto_2
    const/4 v11, 0x0

    return-void
.end method

.method public e(Landroid/content/Context;Z)V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v1, " npdebosccintt"

    const/4 v8, 0x2

    const-string/jumbo v1, "ipneocctodst n"

    const-string/jumbo v1, "tcp disconnect"

    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v0, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    iput-boolean v0, p0, Lo2/k;->b:Z

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/16 v1, 0xbb0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {p1, v0, v1}, Lq2/a;->g(Landroid/content/Context;Ljava/lang/String;I)V

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Lo2/k;->c(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v3, "acdu bniond tleefi"

    const-string v3, "eidna u eindlcftoc"

    const/4 v8, 0x6

    const-string v3, "ctndclua edfneoii "

    const-string v3, "disconnect failed "

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz p2, :cond_1

    const/4 v8, 0x4

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v0, "oncpt eptrptcne c"

    const-string v0, " ec tenpcrctpnotr"

    const/4 v8, 0x7

    const-string v0, "enpcetc qrtnt orc"

    const-string/jumbo v0, "tcp retry connect"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result p2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-nez p2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string p2, "a snttcpeyq nrorch stte ne to"

    const-string p2, " ecs  reqytnrtt honpnot tnaec"

    const/4 v8, 0x1

    const-string/jumbo p2, "topmrychs nonece  n ntrt ttec"

    const-string/jumbo p2, "tcp retry connect not has net"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/16 p2, 0xbb1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p1, p2, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object v2, Le3/a;->a:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/16 p2, 0xbae

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {p1, v2, p2}, Lq2/a;->g(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/16 v3, 0xbae

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-wide/16 v5, 0x7d0

    const-wide/16 v5, 0x7d0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static/range {v1 .. v6}, Lq2/a;->i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-void
.end method

.method public final f(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo p3, "in ooerown,kCo eesnaidsdtc/ecccn/ttsn t"

    const-string/jumbo p3, "iisn c/cwne/Cedeodtsn ctoocne tnraskn,t"

    const/4 v5, 0x4

    const-string/jumbo p3, "n,n tbriskioecceCo atno ndt/nwdc/etsec "

    const-string p3, "can\'t connect, network is disConnected"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p2, p3}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v3, "pmnct ucneoc"

    const-string/jumbo v3, "n cmtpnoctce"

    const/4 v5, 0x4

    const-string/jumbo v3, "tcp connect "

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v3, ":"

    const-string v3, ":"

    const-string v3, ":"

    const-string v3, ":"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lo2/k;->l(Landroid/content/Context;Ljava/lang/String;I)Z

    move-result p2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p2, :cond_1

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo p3, "ncsco cet pscetcusn"

    const/4 v5, 0x3

    const-string p3, " cposnspsete nucctc"

    const-string/jumbo p3, "tcp connect success"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p2, p3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 p2, 0x1

    and-int/2addr v5, p2

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    iput-boolean p2, p0, Lo2/k;->b:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    return p2

    :catchall_0
    move-exception p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v2, "ncp lceeqd  ncotafb"

    const-string v2, "eo nabtcpfi  cnedlc"

    const/4 v5, 0x1

    const-string/jumbo v2, "p scc neelifatctd o"

    const-string/jumbo v2, "tcp connect failed "

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p3, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, p1, v0}, Lo2/k;->e(Landroid/content/Context;Z)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v0
.end method

.method public final g(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)[B
    .locals 19

    :try_start_0
    invoke-virtual/range {p2 .. p2}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v0

    invoke-virtual/range {p2 .. p2}, Lcom/engagelab/privates/core/api/MTProtocol;->g()I

    move-result v1

    invoke-static/range {p1 .. p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v2

    invoke-static/range {p1 .. p1}, Lo2/q;->A(Landroid/content/Context;)I

    move-result v4

    invoke-virtual/range {p2 .. p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v5

    invoke-static {}, Ly2/b;->p()I

    move-result v7

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eq v7, v9, :cond_0

    if-eq v7, v8, :cond_0

    const/16 v11, 0x18

    move v12, v10

    move v12, v10

    move v12, v10

    move v12, v10

    goto :goto_0

    :cond_0
    const/16 v11, 0x1b

    move v12, v9

    move v12, v9

    move v12, v9

    move v12, v9

    :goto_0
    new-instance v13, Lf3/b;

    invoke-direct {v13, v11}, Lf3/b;-><init>(I)V

    if-eqz v12, :cond_1

    invoke-virtual {v13, v11}, Lf3/b;->r(I)V

    invoke-virtual {v13, v12}, Lf3/b;->r(I)V

    move v14, v9

    move v14, v9

    move v14, v9

    move v14, v9

    goto :goto_1

    :cond_1
    move v14, v10

    move v14, v10

    move v14, v10

    move v14, v10

    :goto_1
    xor-int/lit8 v15, v0, 0x5a

    invoke-virtual {v13, v15}, Lf3/b;->r(I)V

    xor-int/lit8 v15, v1, 0x5a

    invoke-virtual {v13, v15}, Lf3/b;->r(I)V

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    const-wide v15, 0x5a5a5a5a5a5a5a5aL

    xor-long v8, v2, v15

    invoke-virtual {v13, v8, v9}, Lf3/b;->p(J)V

    int-to-long v8, v4

    invoke-virtual {v13, v8, v9}, Lf3/b;->n(J)V

    xor-long v8, v5, v15

    invoke-virtual {v13, v8, v9}, Lf3/b;->p(J)V

    invoke-virtual {v13, v10}, Lf3/b;->l(I)V

    const/4 v4, 0x1

    if-ne v12, v4, :cond_2

    invoke-virtual {v13, v7}, Lf3/b;->r(I)V

    :cond_2
    invoke-virtual {v13}, Lf3/b;->g()[B

    move-result-object v4

    invoke-virtual/range {p2 .. p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object v8

    invoke-static/range {p1 .. p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v15

    invoke-static/range {v15 .. v16}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v9

    if-eqz v7, :cond_5

    const/16 v13, 0x10

    const/4 v15, 0x1

    if-eq v7, v15, :cond_4

    const/4 v15, 0x2

    if-eq v7, v15, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v9, v10, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    invoke-static {v8, v9, v13}, Ld3/n;->k([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v8

    goto :goto_2

    :cond_4
    invoke-virtual {v9, v10, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    invoke-static {v8, v9, v13}, Ld3/a;->f([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v8

    goto :goto_2

    :cond_5
    invoke-static {v8, v9}, Ld3/a;->e([BLjava/lang/String;)[B

    move-result-object v8

    :goto_2
    array-length v9, v8

    add-int/lit8 v13, v11, 0x2

    add-int v15, v13, v9

    move-object/from16 p1, v8

    move-object/from16 p1, v8

    move-object/from16 p1, v8

    const/4 v10, 0x2

    new-array v8, v10, [B

    ushr-int/lit8 v10, v15, 0x8

    and-int/lit16 v10, v10, 0xff

    int-to-byte v10, v10

    const/16 v16, 0x0

    aput-byte v10, v8, v16

    move/from16 p2, v13

    move/from16 p2, v13

    move/from16 p2, v13

    move/from16 p2, v13

    and-int/lit16 v13, v15, 0xff

    int-to-byte v13, v13

    const/16 v17, 0x1

    aput-byte v13, v8, v17

    or-int/lit16 v10, v10, 0x80

    int-to-byte v10, v10

    const/4 v13, 0x0

    aput-byte v10, v8, v13

    if-eqz v14, :cond_6

    or-int/lit8 v10, v10, 0x40

    int-to-byte v10, v10

    aput-byte v10, v8, v13

    :cond_6
    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v10

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v18, v4

    move-object/from16 v18, v4

    move-object/from16 v18, v4

    move-object/from16 v18, v4

    const-string v4, "eseme,r hn  ay:nnenclddg:othia2p"

    const-string/jumbo v4, "send ahead length:2, encryption:"

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, ",p:eod an"

    const-string v4, ", expand:"

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "egno bLt,aulht"

    const-string/jumbo v4, "ttloLauheng ,:"

    const-string/jumbo v4, "ntohetuLa t:,g"

    const-string v4, ", totalLength:"

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v10, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v4

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, " ehenaepdhl gtd:ps"

    const-string v13, "edlhthspa e:gnd  e"

    const-string v13, "gd:hatehqelnnd  e "

    const-string/jumbo v13, "send head  length:"

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, ": sedh,Vqsrnai"

    const-string/jumbo v13, "resed:, qhVnia"

    const-string v13, "hedmnr,sai o:V"

    const-string v13, ", headVersion:"

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v12, ":m cosando"

    const-string/jumbo v12, "odsanmcm :"

    const-string v12, ", command:"

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "o:e nbvr,i"

    const-string v0, ", version:"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "umu, i"

    const-string v0, "i: m,u"

    const-string v0, "dpi,u "

    const-string v0, ", uid:"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, "d,rio:"

    const-string/jumbo v0, "rdq:i,"

    const-string v0, ", rid:"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, ", crc16:"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ",nscy:t bp"

    const-string/jumbo v0, "py :,bcnte"

    const-string v0, ",nymcptr:e"

    const-string v0, ", encrypt:"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "etl os gde:nnhb dy"

    const-string/jumbo v2, "send body  length:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    new-array v0, v15, [B

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v8, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    move-object/from16 v3, v18

    invoke-static {v3, v2, v0, v1, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move/from16 v11, p2

    move/from16 v11, p2

    move/from16 v11, p2

    move/from16 v11, p2

    invoke-static {v8, v2, v0, v11, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final h(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)V
    .locals 10

    const/4 v8, 0x3

    move v9, v8

    new-instance v0, Landroid/os/Bundle;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string/jumbo v1, "oplrobuo"

    const-string/jumbo v1, "ooroplut"

    const/4 v9, 0x7

    const-string/jumbo v1, "loootrup"

    const-string/jumbo v1, "protocol"

    const/4 v9, 0x5

    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v1, p0, Lo2/k;->a:Ljava/util/concurrent/ConcurrentMap;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v3, " ieeverp"

    const-string/jumbo v3, "rve eeip"

    const/4 v9, 0x4

    const-string/jumbo v3, "qeviee r"

    const-string/jumbo v3, "receive "

    const/4 v8, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    check-cast v2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v4

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v6

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    cmp-long v4, v4, v6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez v4, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    iget-object v4, p0, Lo2/k;->a:Ljava/util/concurrent/ConcurrentMap;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    check-cast v4, Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p2, v4}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    shl-int/2addr v9, v8

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v5, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v2}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-static {p1, v4, v1}, Lq2/a;->g(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {p1, v4, p2, v0}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-void

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v1, v1, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v2, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    check-cast v2, Lc3/b;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-virtual {v2, v4}, Lc3/b;->j(I)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-nez v4, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2}, Lc3/b;->f()[Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    aget-object v2, v2, v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p2, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    or-int/2addr v9, v8

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v4, v5}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->c()I

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-static {p1, v2, v4, v0}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v9, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    return-void
.end method

.method public final i(Landroid/content/Context;[B)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v0, 0x1

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-boolean v1, p0, Lo2/k;->b:Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x5

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "nts /ea  etsocconsedtc/n,i  qncdn"

    const-string/jumbo v1, "icetpndoqocnsdc nn/ e/tetas  c ,n"

    const/4 v5, 0x3

    const-string v1, " enmssadtc/dncic,ocon   p ttneet/"

    const-string v1, "can\'t send, tcp is not connected"

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {p2, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0, p1, p2}, Lo2/k;->n(Landroid/content/Context;[B)Z

    move-result p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v3, " pd:osnem"

    const-string/jumbo v3, "nesId: pm"

    const-string v3, "Ip nebmds"

    const-string/jumbo v3, "sendImp :"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/nio/channels/NotYetConnectedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto/16 :goto_0

    :catchall_0
    move-exception p2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string v3, "d la rusmhnboee"

    const-string v3, " whmabseln oerd"

    const/4 v5, 0x6

    const-string v3, "hetwnb p oeslda"

    const-string/jumbo v3, "send throwable "

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, p1, v0}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto/16 :goto_0

    :catch_0
    move-exception p2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v3, "nYoCesndqidtxeot o NeentcEpcon"

    const-string/jumbo v3, "nE noNYee xieCoodopcetcdttnens"

    const/4 v5, 0x2

    const-string/jumbo v3, "xosCpYnnsocoNcn eeedntedtEit t"

    const-string/jumbo v3, "send NotYetConnectedException "

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1, p2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, p1, v0}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :catch_1
    move-exception p2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const-string v3, "eOpmocdbent xIiE "

    const-string v3, "eE Isbicexpnd tOo"

    const/4 v5, 0x0

    const-string/jumbo v3, "oeOnoepniIs xtEd "

    const-string/jumbo v3, "send IOException "

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1, v2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    if-eqz p2, :cond_1

    const/4 v5, 0x3

    const-string v1, "MyCertificateException:"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 p2, -0x1

    move v5, p2

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    invoke-static {p1, p2}, Lo2/q;->c(Landroid/content/Context;I)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, p1, v0}, Lo2/k;->e(Landroid/content/Context;Z)V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Lo2/k;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public final k(Landroid/content/Context;)Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p1}, Lo2/r;->i(Landroid/content/Context;)[B

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v1, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v6, 0x6

    move v7, v6

    invoke-direct {v1}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {}, Lh3/b;->m()J

    move-result-wide v2

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 v3, 0x17

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1, v0}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget-object v1, Le3/a;->c:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x0

    move v7, v1

    const/4 v6, 0x5

    and-int/2addr v7, v6

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v0, "lfeuibtd ieagniuordad neq  seflsl"

    const-string v0, "aogfleu indf, sqeni deasledri tlu"

    const/4 v7, 0x5

    const-string/jumbo v0, "s  gddueedrtlfeil,eoainqnl is eau"

    const-string/jumbo v0, "login failed, send request failed"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    return v1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string v5, "dsppn"

    const-string v5, "dspn "

    const/4 v7, 0x6

    const-string/jumbo v5, "nd qs"

    const-string/jumbo v5, "send "

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v3, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, p1, v0}, Lo2/k;->g(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)[B

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0, p1, v0}, Lo2/k;->i(Landroid/content/Context;[B)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0, p1}, Lo2/k;->o(Landroid/content/Context;)[B

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p0, p1, v0}, Lo2/k;->a(Landroid/content/Context;[B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v0, "nesvsioelslaeodffe egeiaen qr r dii,l"

    const-string v0, "erilal sqdeifgneeades n,piero f elivo"

    const/4 v7, 0x4

    const-string/jumbo v0, "pi mrea nven,seriseodeeaoleffic ligld"

    const-string/jumbo v0, "login failed, receive response failed"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    return v1

    :cond_1
    const/4 v7, 0x2

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v5, "ersc eie"

    const/4 v7, 0x1

    const-string/jumbo v5, "veeiorc "

    const-string/jumbo v5, "receive "

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v3, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {p1, v0}, Lo2/r;->a(Landroid/content/Context;[B)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Lo2/d;->b(Landroid/content/Context;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/16 v0, 0x7d1

    const/4 v7, 0x1

    invoke-static {p1, v0, v3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/16 v0, 0xbb7

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p1, v0, v3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    return v2

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/16 v0, 0x7d2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p1, v0, v3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v0, 0xbb6

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1, v0, v3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    return v1
.end method

.method public abstract l(Landroid/content/Context;Ljava/lang/String;I)Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation
.end method

.method public abstract m(Landroid/content/Context;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract n(Landroid/content/Context;[B)Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract o(Landroid/content/Context;)[B
.end method

.method public final p(Landroid/content/Context;)V
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "..igebe.inrvc.."

    const-string v1, "gncm...ev..irie"

    const-string v1, "..nci.u..vg.eer"

    const-string/jumbo v1, "receiving......"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lo2/k;->b:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lo2/k;->o(Landroid/content/Context;)[B

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p1, v0}, Lo2/k;->a(Landroid/content/Context;[B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "esnpprdpsloa eifesoR"

    const-string/jumbo v1, "sdeRosrip nfseaelpoa"

    const/4 v3, 0x5

    const-string v1, "faoseaedqpseirn epsR"

    const-string/jumbo v1, "parseResponse failed"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p1, v0}, Lo2/k;->h(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public final q(Landroid/content/Context;)Z
    .locals 9

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p1}, Lo2/q;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p1}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const-string/jumbo v6, "idseb:s ugtrr"

    const-string v6, ": trubsriiegd"

    const/4 v8, 0x4

    const-string/jumbo v6, "is merd:urteg"

    const-string/jumbo v6, "register uid:"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v5, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v6, "udi:o"

    const-string v6, ",ui:d"

    const/4 v8, 0x2

    const-string v6, "brid,"

    const-string v6, ",rid:"

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v6, "dpspawurso"

    const-string/jumbo v6, "s:rposwpad"

    const/4 v8, 0x5

    const-string v6, ",password:"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-static {v4, v5}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    cmp-long v0, v0, v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-lez v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x2

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    return v1

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p1}, Lo2/r;->j(Landroid/content/Context;)[B

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance v2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {v2}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {}, Lh3/b;->m()J

    move-result-wide v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v3, v4}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/16 v4, 0x13

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v2, v4}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v2, v0}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    sget-object v2, Le3/a;->c:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-nez v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v0, "i,egduepqirsrledafattei e rlsdsfeq n"

    const-string v0, "gfses  tqeual  dridel,etanerefsdiqir"

    const/4 v8, 0x5

    const-string v0, " de e,esqnega rredaqsidsteiterluiff "

    const-string/jumbo v0, "register failed, send request failed"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    return v3

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const-string v5, " essn"

    const-string/jumbo v5, "sesn "

    const/4 v8, 0x3

    const-string/jumbo v5, "sndme"

    const-string/jumbo v5, "send "

    const/4 v8, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v2, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0, p1, v0}, Lo2/k;->g(Landroid/content/Context;Lcom/engagelab/privates/core/api/MTProtocol;)[B

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p0, p1, v0}, Lo2/k;->i(Landroid/content/Context;[B)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Lo2/k;->o(Landroid/content/Context;)[B

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p0, p1, v0}, Lo2/k;->a(Landroid/content/Context;[B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-nez v0, :cond_2

    const/4 v8, 0x2

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo v0, "nrsroeti eoped erlidlmeef searei,vfc gae"

    const-string/jumbo v0, "rlfmedsfievreeao,epresar c nti  slidegee"

    const/4 v8, 0x7

    const-string v0, "dpreib reteasav e ic,fgslsoeerld enfreii"

    const-string/jumbo v0, "register failed, receive response failed"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    return v3

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v5, "evecoiue"

    const-string v5, "eec oevi"

    const/4 v8, 0x7

    const-string v5, " ierevcp"

    const-string/jumbo v5, "receive "

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v2, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p1, v0}, Lo2/r;->d(Landroid/content/Context;[B)I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez v0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {}, Lo2/d;->a()Lo2/d;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, p1}, Lo2/d;->d(Landroid/content/Context;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    return v1

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v0, 0x7d2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/16 v0, 0xbb6

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    return v3
.end method

.method public r(Landroid/content/Context;)V
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v0, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    iput-boolean v0, p0, Lo2/k;->c:Z

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-boolean v1, p0, Lo2/k;->b:Z

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v1, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string v0, "ea, T/ncqtcnpnisic nnCogctotebn"

    const-string v0, ", tcnbonTpcoe ccCngiacnet/nitsn"

    const/4 v11, 0x0

    const-string/jumbo v0, "otsntceeiigcn/c act,nC snc/npTo"

    const-string v0, "can\'t connect, isTcpConnecting"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    return-void

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-boolean v0, p0, Lo2/k;->b:Z

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p0, p1}, Lo2/k;->m(Landroid/content/Context;)Ljava/util/List;

    move-result-object v1

    const/4 v11, 0x4

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    const/4 v3, 0x0

    const/4 v11, 0x7

    if-eqz v2, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const-string/jumbo v1, "octmruhnae ce endrtrc  na eseopd"

    const-string v1, "  teenuddontc  reapeeratosh nccr"

    const/4 v11, 0x0

    const-string/jumbo v1, "there are no tcp connect address"

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v0, v1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p0, p1, v3}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    return-void

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance v2, Ljava/util/ArrayList;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v11, 0x5

    invoke-static {}, Lh3/b;->b()I

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    move v4, v3

    move v4, v3

    const/4 v11, 0x4

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-ge v4, v1, :cond_8

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string v7, "  rto i erupeytnscootcc"

    const-string v7, "cir nuop eyt tt rscecno"

    const/4 v11, 0x3

    const-string/jumbo v7, "ytc ebrc nnn usoctet or"

    const-string v7, "connect retry count is "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v5, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-eqz v6, :cond_7

    const/4 v11, 0x3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    check-cast v6, Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p1}, Lo2/q;->p(Landroid/content/Context;)Z

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-nez v7, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string/jumbo v0, "s/in eutoe,s tnace  cqccnlaeaf/tn tnco"

    const-string v0, "cen sei/q/secof t,os cnctatc anenlnta "

    const/4 v11, 0x6

    const-string v0, " t/o aapnnttacscnei cns /slnec eoectt,"

    const-string v0, "can\'t connect ,connect state is false"

    const/4 v11, 0x5

    const/4 v10, 0x5

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    return-void

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-boolean v7, p0, Lo2/k;->c:Z

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-nez v7, :cond_3

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0}, Lo2/k;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v0, "/coc s/sqfanttesei tntpc e l,saatn"

    const-string/jumbo v0, "otsn,/ssnnpta ttfeaa e ls  i/eccct"

    const/4 v11, 0x3

    const-string v0, "can\'t connect ,tcp state is false"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    return-void

    :cond_3
    const/4 v11, 0x2

    const/4 v10, 0x6

    const-string v7, ":"

    const-string v7, ":"

    const/4 v11, 0x0

    const-string v7, ":"

    const-string v7, ":"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    array-length v8, v7

    const/4 v10, 0x5

    or-int/2addr v11, v10

    sub-int/2addr v8, v0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    aget-object v7, v7, v8

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    sub-int/2addr v8, v9

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    sub-int/2addr v8, v0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v6, v3, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p0, p1, v6, v7}, Lo2/k;->f(Landroid/content/Context;Ljava/lang/String;I)Z

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-nez v6, :cond_4

    const/4 v11, 0x2

    invoke-virtual {p0, p1, v3}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto/16 :goto_1

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0, p1}, Lo2/k;->q(Landroid/content/Context;)Z

    move-result v6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-nez v6, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {p0, p1, v3}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto/16 :goto_1

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p0, p1}, Lo2/k;->k(Landroid/content/Context;)Z

    move-result v6

    const/4 v11, 0x2

    if-nez v6, :cond_6

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p0, p1, v3}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    goto/16 :goto_1

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {p0, p1}, Lo2/k;->p(Landroid/content/Context;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    goto/16 :goto_1

    :cond_7
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_8
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    return-void
.end method

.method public s(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x4

    move v3, v2

    iput-boolean v0, p0, Lo2/k;->c:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, p1, v0}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v0, 0x7d2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v0, 0xbb6

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method
