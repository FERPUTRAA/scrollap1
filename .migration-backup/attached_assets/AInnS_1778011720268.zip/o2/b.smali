.class public Lo2/b;
.super Lc3/b;


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    invoke-static {}, Lx2/a;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "MNsCsO"

    const-string v1, "NMsOOC"

    const/4 v3, 0x0

    const-string v1, "MCOmNO"

    const-string v1, "COMMON"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sput-object v0, Lo2/b;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lc3/b;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @~~o~@ .oKi~S~vi@c ~~~@@ o/M @a ~m@~~~@ ~@ ~b y-/~t@lo4r@~ ~ no~bo@@ @ ~ o@~s@f@d@@1f   bu@t~~l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lo2/b;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0, p2, p3}, Lq2/a;->h(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;)V

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public f()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lo2/b;->a:Ljava/lang/String;

    const/4 v1, 0x1

    move v2, v1

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public g(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/16 p3, 0x3e8

    const/4 v0, 0x5

    const/4 v1, 0x6

    if-eq p2, p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {}, Lr2/a;->b()Lr2/a;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Lr2/a;->e(Landroid/content/Context;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public h(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x3

    const/16 v0, 0x3e8

    const/4 v1, 0x3

    move v2, v1

    if-eq p2, v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/16 v0, 0x3f5

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eq p2, v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/16 v0, 0x3ef

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eq p2, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/16 v0, 0x3f0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eq p2, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    packed-switch p2, :pswitch_data_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_0
    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lu2/b;->a()Lu2/b;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p2, p1, p3}, Lu2/b;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lt2/a;->a()Lt2/a;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p2, p1, p3}, Lt2/a;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {}, Lt2/a;->a()Lt2/a;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p2, p1, p3}, Lt2/a;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Lu2/b;->a()Lu2/b;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p2, p1, p3}, Lu2/b;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lt2/a;->a()Lt2/a;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p2, p1, p3}, Lt2/a;->c(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lr2/a;->b()Lr2/a;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Lr2/a;->e(Landroid/content/Context;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x7ca
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public j(I)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v0, 0x3e8

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/16 v0, 0x3f5

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v0, 0x3ef

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/16 v0, 0x3f0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    packed-switch p1, :pswitch_data_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1

    :cond_0
    :pswitch_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x7ca
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
