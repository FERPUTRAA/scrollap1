.class public Lo2/e0;
.super Lo2/b0;


# static fields
.field public static volatile c:Lo2/e0;


# instance fields
.field public final b:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Integer;",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Lo2/b0;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public static k()Lo2/e0;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@oso~l ~   n~@~iadbi@Ko@i~@@l@ t @ v1~@ @~ b@@~@~oy@4@~~~t@@-@~/ f @~c f/r~ ms b.~ oM@uS ~o~~~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lo2/e0;->c:Lo2/e0;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-class v0, Lo2/e0;

    const-class v0, Lo2/e0;

    const/4 v3, 0x6

    const-class v0, Lo2/e0;

    const-class v0, Lo2/e0;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x6

    move v3, v2

    new-instance v1, Lo2/e0;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v1}, Lo2/e0;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v1, Lo2/e0;->c:Lo2/e0;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v0, Lo2/e0;->c:Lo2/e0;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method


# virtual methods
.method public final b(I)I
    .locals 2

    const/4 v1, 0x5

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    return p1

    :pswitch_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/16 p1, 0xbc3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1

    :pswitch_1
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/16 p1, 0xbc4

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1

    :pswitch_2
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/16 p1, 0xbc5

    const/4 v1, 0x1

    const/4 v0, 0x1

    return p1

    :pswitch_3
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/16 p1, 0xbc6

    const/4 v1, 0x2

    return p1

    :pswitch_4
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/16 p1, 0xbc7

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p1

    :pswitch_5
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/16 p1, 0xbc8

    const/4 v1, 0x0

    return p1

    :pswitch_data_0
    .packed-switch 0xf90
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final c(Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget p1, Lj3/a$a;->f:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p1

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "$0sm0+[u-5u&/@49+fA--z]_!$^#a=9Za/|e-."

    const-string/jumbo v0, "u]s@4z^9!---u=a_+$+|/a$e9&[-0#A5f*.Z0/"

    const-string v0, "4A9]o[=/uaz5!Z0*&9u@$e--0-^|-#_fa/.0$+"

    const-string v0, "^[\u4e00-\u9fa50-9a-zA-Z_!@#$&*+=.|]+$"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x1

    sget p1, Lj3/a$a;->f:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p1

    :cond_1
    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    array-length p1, p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v0, 0x28

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-le p1, v0, :cond_2

    const/4 v3, 0x6

    sget p1, Lj3/a$a;->g:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v1, "ale ibedytgts Bf"

    const-string v1, "getBytes failed "

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, "BaMunguTsTssm"

    const-string/jumbo v0, "iTMmuBsTsgans"

    const/4 v3, 0x3

    const-string v0, "essBagipTnTsu"

    const-string v0, "MTTagBusiness"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1
.end method

.method public final d([Ljava/lang/String;)I
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0}, Lo2/b0;->a()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    return v0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    array-length v0, p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v1, 0x3e8

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    if-le v0, v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    sget p1, Lj3/a$a;->h:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    return p1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    array-length v0, p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    move v2, v1

    move v2, v1

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ge v2, v0, :cond_5

    aget-object v4, p1, v2

    const/4 v8, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v5, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    sget p1, Lj3/a$a;->f:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    return p1

    :cond_2
    const-string v5, "0=z9u-e5q/#4/f---|o]a+*0!@9$+.Z&uA[^_a"

    const-string v5, "9-e=o./--zu|A0$!*+^[+]9_4auZa5-&@/$0f#"

    const/4 v8, 0x5

    const-string v5, "--s*!-_-=a$u4z.0[a0|0$9@+efu95/Z#]A/&+"

    const-string v5, "^[\u4e00-\u9fa50-9a-zA-Z_!@#$&*+=.|]+$"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {v5}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v5, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v5}, Ljava/util/regex/Matcher;->matches()Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-nez v5, :cond_3

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget p1, Lj3/a$a;->f:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    return p1

    :cond_3
    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget-object v5, Lx2/a;->b:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    array-length v4, v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/16 v5, 0x28

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-le v4, v5, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget p1, Lj3/a$a;->g:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    return p1

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-int/2addr v3, v4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_1

    :catchall_0
    move-exception v4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string/jumbo v6, "y emet efiadBstl"

    const-string v6, "dBetfb  aeisetyl"

    const/4 v8, 0x7

    const-string/jumbo v6, "tleeoeBfg dt asi"

    const-string v6, "getBytes failed "

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string/jumbo v5, "saBeMbTsungiT"

    const-string v5, "BeiasguMnTTsu"

    const/4 v8, 0x5

    const-string v5, "TsTiBaussgMeu"

    const-string v5, "MTTagBusiness"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v5, v4}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/16 p1, 0x1388

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-le v3, p1, :cond_6

    const/4 v7, 0x2

    xor-int/2addr v8, v7

    sget p1, Lj3/a$a;->i:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    return p1

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    return v1
.end method

.method public final e(Landroid/content/Context;IIII[Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v0, "seTisaspgBpTu"

    const-string v0, "gTsueTMpiBssa"

    const/4 v7, 0x7

    const-string/jumbo v0, "iTsMngeuqsasB"

    const-string v0, "MTTagBusiness"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p5, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez p4, :cond_0

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_0
    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v2, :cond_1

    const/4 v7, 0x4

    iget-object v2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    check-cast v2, [Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    array-length v3, p6

    const/4 v7, 0x4

    array-length v4, v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/2addr v3, v4

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p6, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    check-cast v3, [Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    array-length p6, p6

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    array-length v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x6

    invoke-static {v2, v5, v3, p6, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p6, v3

    move-object p6, v3

    move-object p6, v3

    move-object p6, v3

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-ge p4, p5, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object p2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p2, p5, p6}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 p2, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/2addr p4, p2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p5, Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p5}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo p6, "olsrptaq"

    const-string/jumbo p6, "qptomral"

    const/4 v7, 0x2

    const-string/jumbo p6, "platform"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const-string v2, "a"

    const-string v2, "a"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p5, p6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const-string/jumbo p6, "op"

    const/4 v7, 0x3

    const-string/jumbo p6, "op"

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v2, "egt"

    const-string/jumbo v2, "teg"

    const/4 v7, 0x3

    const-string/jumbo v2, "teg"

    const-string v2, "get"

    const/4 v7, 0x3

    invoke-virtual {p5, p6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo p6, "rruc"

    const-string/jumbo p6, "urrc"

    const/4 v7, 0x1

    const-string p6, "crru"

    const-string p6, "curr"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p5, p6, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance p6, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const-string v2, ":pnmnseganuetaserq Toscide"

    const-string/jumbo v2, "tasde nqgTO:ninepescoeausr"

    const-string/jumbo v2, "n:geodneeeoTu pearnstiqOac"

    const-string/jumbo v2, "sendTagOperation sequence:"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p6, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v2, "cte: b,mto"

    const-string/jumbo v2, "t ,mencto:"

    const/4 v7, 0x6

    const-string v2, "ctto ,unn:"

    const-string v2, ", content:"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p5}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p5

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p6, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v0, p5}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p4}, Lo2/g;->d(Ljava/lang/String;)[B

    move-result-object p4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance p5, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {p5}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    int-to-long v2, p3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p5, v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/16 p5, 0x1c

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p3, p5}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {p2, p4}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object p3, Li3/a;->a:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance p3, Landroid/os/Bundle;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo p4, "oroootlp"

    const-string/jumbo p4, "rooooplt"

    const-string/jumbo p4, "qcoooltr"

    const-string/jumbo p4, "protocol"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p3, p4, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 p2, 0x8ae

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object v1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object p1, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, p4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p1, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p1}, Lcom/engagelab/privates/push/api/TagMessage;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, p3}, Lcom/engagelab/privates/push/api/TagMessage;->o(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/push/api/TagMessage;->i(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1, p6}, Lcom/engagelab/privates/push/api/TagMessage;->q([Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo p3, "nasrfelb ylg dlouQAai"

    const-string p3, "QeorTbldlAy i gulanaf"

    const/4 v7, 0x3

    const-string/jumbo p3, "iulmfTlQAoged e naayl"

    const-string/jumbo p3, "onTagQueryAll failed "

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v1
.end method

.method public f(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-class v0, Lcom/engagelab/privates/push/api/TagMessage;

    const-class v0, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v2, 0x6

    const-class v0, Lcom/engagelab/privates/push/api/TagMessage;

    const-class v0, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const-string/jumbo v0, "tga"

    const-string v0, "gta"

    const/4 v2, 0x7

    const-string v0, "atg"

    const-string/jumbo v0, "tag"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x7

    check-cast p3, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez p3, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-void

    :cond_1
    const/4 v2, 0x7

    packed-switch p2, :pswitch_data_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p3}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onTagMessage(Landroid/content/Context;Lcom/engagelab/privates/push/api/TagMessage;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string p3, "dsaeornosacau lMep sifisMe"

    const-string p3, "eagrndualic pMesssoesia Mf"

    const-string p3, "Ma gab edenlsfssieospicrea"

    const-string/jumbo p3, "processMainMessage failed "

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p2, "epiMTBuasnugs"

    const-string/jumbo p2, "niuBMaepsTgTs"

    const-string p2, "BeTnsuTpMigas"

    const-string p2, "MTTagBusiness"

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xbc3
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public g(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v0, "eTqTBinsqugss"

    const-string/jumbo v0, "ssTengauqsTBi"

    const-string v0, "gasuTnsMBTess"

    const-string v0, "MTTagBusiness"

    :try_start_0
    const/4 v5, 0x6

    const-string/jumbo v1, "oromplcs"

    const-string/jumbo v1, "poscoolr"

    const/4 v5, 0x0

    const-string v1, "crpoootl"

    const-string/jumbo v1, "protocol"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    long-to-int p2, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v1, [Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v2, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v2}, Lcom/engagelab/privates/push/api/TagMessage;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, p2}, Lcom/engagelab/privates/push/api/TagMessage;->o(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget v3, Lj3/a$a;->c:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/push/api/TagMessage;->i(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/push/api/TagMessage;->q([Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v3, "nlcFiboes:pAedqlnneraiitOoeesa a"

    const-string/jumbo v3, "onAliasOperationFailed sequence:"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo p2, "sg,gMsuaemat "

    const-string/jumbo p2, "t,Mmsgegase a"

    const/4 v5, 0x0

    const-string p2, "e:agas pstge,"

    const-string p2, ", tagMessage:"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/engagelab/privates/push/api/TagMessage;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance p2, Landroid/os/Bundle;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "gta"

    const-string v2, "atg"

    const/4 v5, 0x1

    const-string v2, "gat"

    const-string/jumbo v2, "tag"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/16 v1, 0xbc3

    const/4 v5, 0x5

    invoke-static {p1, v1, p2}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v1, "llpifadAqaroidOlsont i aeoeFen"

    const-string v1, "aailoodi oeOlApdFetinfilr eans"

    const/4 v5, 0x3

    const-string v1, "ais  fneaOtllploroaaiFdeAdniie"

    const-string/jumbo v1, "onAliasOperationFailed failed "

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method public final h(Lorg/json/JSONArray;)[Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-array v0, v0, [Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0
.end method

.method public final i(Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, -0x1

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    sparse-switch v0, :sswitch_data_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    goto/16 :goto_0

    :sswitch_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v0, "vlbmi"

    const-string v0, "bvdli"

    const/4 v4, 0x2

    const-string v0, "avldo"

    const-string/jumbo v0, "valid"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    const/4 v2, 0x5

    move v4, v2

    const/4 v3, 0x1

    move v4, v3

    goto/16 :goto_0

    :sswitch_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v0, "buacn"

    const-string/jumbo v0, "nucae"

    const/4 v4, 0x7

    const-string v0, "auecn"

    const-string v0, "clean"

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x4

    goto/16 :goto_0

    :sswitch_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "ets"

    const/4 v4, 0x5

    const-string/jumbo v0, "set"

    const-string/jumbo v0, "set"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :sswitch_3
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v0, "tge"

    const-string/jumbo v0, "tge"

    const/4 v4, 0x7

    const-string v0, "gte"

    const-string v0, "get"

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez p1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :sswitch_4
    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v0, "led"

    const-string v0, "eld"

    const/4 v4, 0x5

    const-string v0, "edl"

    const-string v0, "del"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez p1, :cond_4

    const/4 v4, 0x5

    goto :goto_0

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :sswitch_5
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, "add"

    const-string v0, "add"

    const-string v0, "add"

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez p1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    move v2, v1

    move v2, v1

    const/4 v4, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    packed-switch v2, :pswitch_data_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1

    :pswitch_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 p1, 0xbc6

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return p1

    :pswitch_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 p1, 0xbc7

    const/4 v4, 0x6

    return p1

    :pswitch_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/16 p1, 0xbc5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p1

    :pswitch_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/16 p1, 0xbc8

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return p1

    :pswitch_4
    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 p1, 0xbc4

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return p1

    :pswitch_5
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 p1, 0xbc3

    const/4 v4, 0x6

    const/4 v3, 0x5

    return p1

    :sswitch_data_0
    .sparse-switch
        0x178a1 -> :sswitch_5
        0x1840b -> :sswitch_4
        0x18f56 -> :sswitch_3
        0x1bc62 -> :sswitch_2
        0x5a5b649 -> :sswitch_1
        0x6ac8ffc -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final j(I)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1

    :pswitch_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    const-string p1, "dad"

    const-string p1, "dda"

    const/4 v1, 0x7

    const-string p1, "add"

    const/4 v1, 0x3

    return-object p1

    :pswitch_1
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    const-string/jumbo p1, "led"

    const-string p1, "edl"

    const/4 v1, 0x1

    const-string p1, "dle"

    const-string p1, "del"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1

    :pswitch_2
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    const-string p1, "est"

    const/4 v1, 0x0

    const-string/jumbo p1, "set"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1

    :pswitch_3
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string/jumbo p1, "idppl"

    const-string/jumbo p1, "vipld"

    const/4 v1, 0x0

    const-string p1, "dvlqa"

    const-string/jumbo p1, "valid"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1

    :pswitch_4
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    const-string p1, "easlc"

    const-string p1, "ealqc"

    const/4 v1, 0x2

    const-string p1, "ancme"

    const-string p1, "clean"

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1

    :pswitch_5
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    const-string/jumbo p1, "tge"

    const-string/jumbo p1, "teg"

    const/4 v1, 0x4

    const-string p1, "gte"

    const-string p1, "get"

    const/4 v0, 0x3

    move v1, v0

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0xf90
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final l([Ljava/lang/String;)Lorg/json/JSONArray;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Lorg/json/JSONArray;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x4

    const/4 v5, 0x4

    array-length v1, p1

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x3

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v5, 0x6

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-object v3, p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object v0
.end method

.method public m(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v0, "TMsBoaTesssnu"

    const-string/jumbo v0, "sTsMunsBaTsei"

    const/4 v8, 0x0

    const-string v0, "aMBisbseusTnT"

    const-string v0, "MTTagBusiness"

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v1, "eseemcun"

    const-string v1, "euemnces"

    const/4 v8, 0x3

    const-string/jumbo v1, "sequence"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p3, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0, p2}, Lo2/e0;->j(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0, p2}, Lo2/e0;->b(I)I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance v4, Lorg/json/JSONObject;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const/4 v8, 0x5

    const-string/jumbo v5, "loprtmop"

    const-string/jumbo v5, "lotfoprm"

    const-string/jumbo v5, "qtpfmaor"

    const-string/jumbo v5, "platform"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v6, "a"

    const-string v6, "a"

    const/4 v8, 0x2

    const-string v6, "a"

    const-string v6, "a"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string/jumbo v5, "op"

    const-string/jumbo v5, "po"

    const-string/jumbo v5, "op"

    const-string/jumbo v5, "op"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v4, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v2, "gsta"

    const/4 v8, 0x4

    const-string v2, "astg"

    const-string/jumbo v2, "tags"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v5, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const-string v6, "atg"

    const-string v6, "atg"

    const/4 v8, 0x4

    const-string v6, "gat"

    const-string/jumbo v6, "tag"

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    packed-switch p2, :pswitch_data_0

    :pswitch_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto/16 :goto_0

    :pswitch_1
    :try_start_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p3, v6}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0, p2}, Lo2/e0;->d([Ljava/lang/String;)I

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz p3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v2, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v7, 0x0

    move v8, v7

    invoke-direct {v2}, Lcom/engagelab/privates/push/api/TagMessage;-><init>()V

    const/4 v8, 0x6

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/push/api/TagMessage;->o(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1, p3}, Lcom/engagelab/privates/push/api/TagMessage;->i(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/push/api/TagMessage;->q([Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    new-instance p3, Landroid/os/Bundle;

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p3, v6, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-static {p1, v3, p3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object p3, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p3, v3, p2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0, p2}, Lo2/e0;->l([Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :pswitch_2
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p3, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, p2}, Lo2/e0;->c(Ljava/lang/String;)I

    move-result p3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz p3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v2, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-direct {v2}, Lcom/engagelab/privates/push/api/TagMessage;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/push/api/TagMessage;->o(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, p3}, Lcom/engagelab/privates/push/api/TagMessage;->i(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/push/api/TagMessage;->k(Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance p3, Landroid/os/Bundle;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p3, v6, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    invoke-static {p1, v3, p3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x4

    return-void

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object p3, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {p3, v3, v6}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v4, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :pswitch_3
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string/jumbo p2, "rucr"

    const/4 v8, 0x7

    const-string/jumbo p2, "rucr"

    const-string p2, "curr"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v4, p2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move v8, v7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const-string p3, "i s:stOeAqeinpuelacserndoean"

    const-string p3, "erisebd:Aatneseuoacl nneipOq"

    const/4 v8, 0x6

    const-string/jumbo p3, "ni meuAotOda:nncsreeesleqasp"

    const-string/jumbo p3, "sendAliasOperation sequence:"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo p3, "ucnno:tt, "

    const-string p3, ":e,nc uttn"

    const-string/jumbo p3, "o,e cbnt:n"

    const-string p3, ", content:"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v4}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {p2}, Lo2/g;->d(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-nez p2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-void

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance p3, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {p3}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    int-to-long v1, v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p3, v1, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/16 v1, 0x1c

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p3, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p3, v5}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object p3, Li3/a;->a:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    new-instance p3, Landroid/os/Bundle;

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const-string v1, "cotpoour"

    const-string/jumbo v1, "protocol"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p3, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/16 p2, 0x8ae

    const/4 v8, 0x7

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string p3, "aespnorp nagfdilOtdeTaie"

    const-string/jumbo p3, "sdd ineptgiTer noOalefaa"

    const/4 v8, 0x1

    const-string/jumbo p3, "iosfadOaqtnn g eiedlTear"

    const-string/jumbo p3, "sendTagOperation failed "

    const/4 v8, 0x5

    const/4 v7, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x7

    move v8, v7

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xf90
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public n(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 13

    const/4 v12, 0x5

    const-string v0, "assTuigMTsnBe"

    const-string v0, "guaMTsTnqsiBe"

    const-string v0, "BTsmgeianMsus"

    const-string v0, "MTTagBusiness"

    :try_start_0
    const/4 v12, 0x0

    const-string/jumbo v1, "octsopro"

    const-string/jumbo v1, "opstocor"

    const-string/jumbo v1, "ocptlboo"

    const-string/jumbo v1, "protocol"

    const/4 v12, 0x2

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v12, 0x4

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v12, 0x3

    if-nez p2, :cond_0

    const/4 v12, 0x4

    return-void

    :cond_0
    const/4 v12, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v1

    const/4 v12, 0x1

    long-to-int v6, v1

    const/4 v12, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    const/4 v12, 0x7

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v12, 0x5

    invoke-static {p2}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v12, 0x5

    invoke-direct {v1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const-string/jumbo v2, "pmOgctuesc inoTnaarcqees:usunSe"

    const-string v2, "eacmpreOgqcauseisnTnosntc :Suee"

    const-string v2, "gO nuoepTunairsnpeeqeccats:scoS"

    const-string/jumbo v2, "onTagOperationSuccess sequence:"

    const/4 v12, 0x1

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-virtual {p2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string/jumbo v2, "neotnt :q,"

    const-string v2, ",: tontecn"

    const-string/jumbo v2, "tesnoctn ,"

    const-string v2, ", content:"

    const/4 v12, 0x3

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-static {v1}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x1

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const-string p2, "doec"

    const-string p2, "dcoe"

    const-string p2, "coed"

    const-string p2, "code"

    invoke-virtual {v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    const/4 v12, 0x2

    new-instance p2, Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v12, 0x1

    invoke-direct {p2}, Lcom/engagelab/privates/push/api/TagMessage;-><init>()V

    const/4 v12, 0x4

    invoke-virtual {p2, v6}, Lcom/engagelab/privates/push/api/TagMessage;->o(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p2

    const/4 v12, 0x3

    invoke-virtual {p2, v5}, Lcom/engagelab/privates/push/api/TagMessage;->i(I)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p2

    const/4 v12, 0x0

    const-string/jumbo v2, "op"

    const-string/jumbo v2, "po"

    const-string/jumbo v2, "op"

    const/4 v12, 0x2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x3

    invoke-virtual {p0, v2}, Lo2/e0;->i(Ljava/lang/String;)I

    move-result v10

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/4 v12, 0x0

    const/4 v4, 0x0

    const/4 v12, 0x7

    const/4 v7, 0x5

    const/4 v12, 0x1

    const/4 v8, 0x3

    const/4 v12, 0x0

    const/4 v9, 0x2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    sparse-switch v3, :sswitch_data_0

    const/4 v12, 0x1

    goto/16 :goto_0

    :sswitch_0
    const/4 v12, 0x1

    const-string/jumbo v3, "ibamd"

    const-string v3, "bdaiv"

    const-string/jumbo v3, "vaido"

    const-string/jumbo v3, "valid"

    const/4 v12, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x1

    if-eqz v2, :cond_1

    const/4 v12, 0x3

    move v2, v8

    move v2, v8

    const/4 v12, 0x0

    goto :goto_1

    :sswitch_1
    const/4 v12, 0x3

    const-string v3, "becnl"

    const-string/jumbo v3, "nulce"

    const-string v3, "clean"

    const/4 v12, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x3

    if-eqz v2, :cond_1

    const/4 v12, 0x0

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_2
    const-string/jumbo v3, "tes"

    const-string v3, "est"

    const-string/jumbo v3, "ste"

    const-string/jumbo v3, "set"

    const/4 v12, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x1

    if-eqz v2, :cond_1

    const/4 v12, 0x4

    move v2, v9

    move v2, v9

    move v2, v9

    move v2, v9

    goto :goto_1

    :sswitch_3
    const/4 v12, 0x7

    const-string v3, "egt"

    const-string v3, "egt"

    const-string v3, "etg"

    const-string v3, "get"

    const/4 v12, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x4

    if-eqz v2, :cond_1

    const/4 v12, 0x5

    move v2, v7

    move v2, v7

    move v2, v7

    const/4 v12, 0x2

    goto :goto_1

    :sswitch_4
    const/4 v12, 0x4

    const-string v3, "del"

    const-string v3, "eld"

    const-string v3, "edl"

    const-string v3, "del"

    const/4 v12, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x5

    if-eqz v2, :cond_1

    const/4 v12, 0x1

    move v2, v11

    move v2, v11

    move v2, v11

    move v2, v11

    const/4 v12, 0x5

    goto :goto_1

    :sswitch_5
    const-string v3, "add"

    const-string v3, "add"

    const-string v3, "dda"

    const-string v3, "add"

    const/4 v12, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x0

    if-eqz v2, :cond_1

    const/4 v12, 0x0

    move v2, v4

    move v2, v4

    move v2, v4

    const/4 v12, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v12, 0x0

    const/4 v2, -0x1

    :goto_1
    const/4 v12, 0x2

    if-eqz v2, :cond_4

    const/4 v12, 0x7

    if-eq v2, v11, :cond_4

    const/4 v12, 0x4

    if-eq v2, v9, :cond_4

    if-eq v2, v8, :cond_3

    const/4 v12, 0x4

    if-eq v2, v7, :cond_2

    const/4 v12, 0x7

    goto/16 :goto_2

    :cond_2
    const/4 v12, 0x2

    const-string p2, "gtsa"

    const-string/jumbo p2, "tags"

    invoke-virtual {v1, p2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v12, 0x2

    invoke-virtual {p0, p2}, Lo2/e0;->h(Lorg/json/JSONArray;)[Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x0

    const-string p2, "aultp"

    const-string/jumbo p2, "oaplt"

    const-string/jumbo p2, "toptl"

    const-string/jumbo p2, "total"

    const/4 v12, 0x7

    invoke-virtual {v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    const/4 v12, 0x1

    const-string/jumbo p2, "urrc"

    const-string p2, "crur"

    const-string/jumbo p2, "rrcu"

    const-string p2, "curr"

    const/4 v12, 0x0

    invoke-virtual {v1, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v12, 0x6

    invoke-virtual/range {v3 .. v9}, Lo2/e0;->e(Landroid/content/Context;IIII[Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object p2

    const/4 v12, 0x6

    goto :goto_2

    :cond_3
    const/4 v12, 0x4

    iget-object v2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v12, 0x3

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v12, 0x5

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x1

    check-cast v2, [Ljava/lang/String;

    aget-object v2, v2, v4

    const/4 v12, 0x0

    iget-object v3, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v12, 0x2

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v12, 0x1

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x4

    const-string/jumbo v3, "lvadtdqiq"

    const-string v3, "dvialdetq"

    const-string/jumbo v3, "vdstdlaie"

    const-string/jumbo v3, "validated"

    const/4 v12, 0x7

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x0

    invoke-virtual {p2, v2}, Lcom/engagelab/privates/push/api/TagMessage;->k(Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    move-result-object v2

    const/4 v12, 0x0

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/push/api/TagMessage;->n(Z)Lcom/engagelab/privates/push/api/TagMessage;

    const/4 v12, 0x3

    goto :goto_2

    :cond_4
    const/4 v12, 0x2

    iget-object v1, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v12, 0x1

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v12, 0x3

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x6

    check-cast v1, [Ljava/lang/String;

    const/4 v12, 0x7

    iget-object v2, p0, Lo2/e0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v12, 0x1

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v12, 0x4

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2, v1}, Lcom/engagelab/privates/push/api/TagMessage;->q([Ljava/lang/String;)Lcom/engagelab/privates/push/api/TagMessage;

    :goto_2
    const/4 v12, 0x5

    if-nez p2, :cond_5

    const/4 v12, 0x6

    return-void

    :cond_5
    const/4 v12, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const-string/jumbo v2, "sssmsa naunttcSraeegecooOpaMeg:si"

    const-string v2, "i scpstoeOaso:nMarassecgngegtuSea"

    const-string v2, "MasaonSusgesOicctnotsgp:eg eaeoTr"

    const-string/jumbo v2, "onTagOperationSuccess tagMessage:"

    const/4 v12, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/TagMessage;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x3

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    new-instance v1, Landroid/os/Bundle;

    const/4 v12, 0x7

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v12, 0x2

    const-string v2, "gta"

    const-string/jumbo v2, "tga"

    const-string v2, "gta"

    const-string/jumbo v2, "tag"

    const/4 v12, 0x7

    invoke-virtual {v1, v2, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v12, 0x2

    invoke-static {p1, v10, v1}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x5

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v12, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x7

    const-string v1, "OaedabSlrsnftumpes cgoTenicao"

    const-string/jumbo v1, "ufomcirc siseeOaTtnaaSodegnlp"

    const-string/jumbo v1, "onTagOperationSuccess failed "

    const/4 v12, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    const/4 v12, 0x2

    return-void

    :sswitch_data_0
    .sparse-switch
        0x178a1 -> :sswitch_5
        0x1840b -> :sswitch_4
        0x18f56 -> :sswitch_3
        0x1bc62 -> :sswitch_2
        0x5a5b649 -> :sswitch_1
        0x6ac8ffc -> :sswitch_0
    .end sparse-switch
.end method
