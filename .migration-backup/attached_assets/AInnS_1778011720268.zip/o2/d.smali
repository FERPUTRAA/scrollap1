.class public Lo2/d;
.super Ljava/lang/Object;


# static fields
.field public static volatile a:Lo2/d;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Lo2/d;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c~s~t ~ ~l~@-~@~~~ o/ u @o@@@@ @d~ /~~il t.~~@ ~va~Sr1K@ ~~@f  o4oi~b~ ~s@b@y   f@@~im@@@Moo @nb"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lo2/d;->a:Lo2/d;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-class v0, Lo2/d;

    const-class v0, Lo2/d;

    const/4 v3, 0x6

    const-class v0, Lo2/d;

    const-class v0, Lo2/d;

    const/4 v3, 0x2

    const/4 v2, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    new-instance v1, Lo2/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v1}, Lo2/d;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    sput-object v1, Lo2/d;->a:Lo2/d;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lo2/d;->a:Lo2/d;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method


# virtual methods
.method public b(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p1}, Lo2/q;->u(Landroid/content/Context;)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p1}, Lo2/q;->A(Landroid/content/Context;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p1}, Lo2/q;->B(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v4, Landroid/os/Bundle;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v5, "doec"

    const-string v5, "deco"

    const/4 v7, 0x3

    const-string v5, "code"

    const/4 v6, 0x6

    const/4 v6, 0x4

    invoke-virtual {v4, v5, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "_simdee"

    const-string v0, "d_sdiee"

    const/4 v7, 0x3

    const-string v0, "diesod_"

    const-string/jumbo v0, "seed_id"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v0, "vtsembir_er"

    const-string v0, "ee_mretrisv"

    const/4 v7, 0x5

    const-string/jumbo v0, "ter_eruivsm"

    const-string/jumbo v0, "server_time"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4, v0, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/16 v0, 0x836

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {p1, v0, v4}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-void
.end method

.method public c(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v0, "oTMnruipssCBse"

    const-string/jumbo v0, "iersosBTnMusCe"

    const/4 v7, 0x0

    const-string/jumbo v0, "uneisMeBqrossC"

    const-string v0, "MTCoreBusiness"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const-string/jumbo v1, "ocsobotl"

    const-string/jumbo v1, "roootblc"

    const/4 v7, 0x4

    const-string/jumbo v1, "octmorol"

    const-string/jumbo v1, "protocol"

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    const/4 v6, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-array v4, v4, [B

    const/4 v7, 0x1

    const/4 v6, 0x4

    invoke-virtual {p2, v4}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance p2, Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v5, Lx2/a;->b:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {p2, v4, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v4, Lf3/b;

    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v4}, Lf3/b;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Lf3/b;->l(I)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v2, v3}, Lf3/b;->p(J)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v5, ""

    const-string v5, ""

    const/4 v7, 0x4

    const-string v5, ""

    const-string v5, ""

    const/4 v7, 0x5

    const/4 v6, 0x3

    invoke-virtual {v5}, Ljava/lang/String;->getBytes()[B

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Lf3/b;->j([B)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v5, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v5}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    invoke-virtual {v5, v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v3, 0x19

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v4}, Lf3/b;->g()[B

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v3, Landroid/os/Bundle;

    const/4 v6, 0x0

    or-int/2addr v7, v6

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3, v1, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v2, 0x8ae

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {p1, v2, v3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v2, Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-direct {v2, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    move v7, v6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v3, " tlConu"

    const/4 v7, 0x2

    const-string/jumbo v3, "on lotC"

    const-string/jumbo v3, "onCtrl "

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v2}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string p2, "cdm"

    const-string/jumbo p2, "mdc"

    const/4 v7, 0x1

    const-string p2, "dmc"

    const-string p2, "cmd"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v3, "etoptbc"

    const-string/jumbo v3, "ptconte"

    const/4 v7, 0x7

    const-string/jumbo v3, "tecntnu"

    const-string v3, "content"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    new-instance v3, Landroid/os/Bundle;

    const/4 v7, 0x6

    const/4 v6, 0x7

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v3, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p1, p2, v3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v1, "dtlflCop qne i"

    const-string v1, "Contdlf qie lr"

    const/4 v7, 0x0

    const-string v1, "C rdlantq lfeo"

    const-string/jumbo v1, "onCtrl failed "

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-void
.end method

.method public d(Landroid/content/Context;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p1}, Lo2/q;->y(Landroid/content/Context;)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-static {p1}, Lo2/q;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p1}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance v5, Landroid/os/Bundle;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const-string/jumbo v6, "odec"

    const-string v6, "deoc"

    const/4 v8, 0x3

    const-string/jumbo v6, "odec"

    const-string v6, "code"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v5, v6, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v0, "des_ssi"

    const-string/jumbo v0, "idsu_es"

    const/4 v8, 0x0

    const-string v0, "edum_ri"

    const-string/jumbo v0, "user_id"

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {v5, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v0, "oiitomgrts_deia"

    const-string v0, "gdtm_rrieiiatos"

    const/4 v8, 0x3

    const-string v0, "ar_egbsroiitndi"

    const-string/jumbo v0, "registration_id"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v5, v0, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    or-int/2addr v8, v7

    const-string/jumbo v0, "wsroapud"

    const-string/jumbo v0, "oprdosaw"

    const/4 v8, 0x0

    const-string/jumbo v0, "ospwrsap"

    const-string/jumbo v0, "password"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v5, v0, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/16 v0, 0x835

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-static {p1, v0, v5}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void
.end method

.method public e(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p1, "doce"

    const-string p1, "edco"

    const/4 v4, 0x4

    const-string p1, "deoc"

    const-string p1, "code"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v0, "dqei_de"

    const-string/jumbo v0, "i_dedbe"

    const/4 v4, 0x5

    const-string v0, "_isesdd"

    const-string/jumbo v0, "seed_id"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "vmimsueete_"

    const-string v1, "evsietume_r"

    const/4 v4, 0x6

    const-string/jumbo v1, "vr_eorismee"

    const-string/jumbo v1, "server_time"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1}, Lh3/b;->t(I)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Lh3/b;->A(I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lh3/b;->B(J)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method

.method public f(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string p1, "cdeo"

    const-string/jumbo p1, "oedc"

    const/4 v5, 0x2

    const-string p1, "ecod"

    const-string p1, "code"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v0, "uri_ebp"

    const-string/jumbo v0, "pisue_r"

    const/4 v5, 0x6

    const-string/jumbo v0, "idr_euu"

    const-string/jumbo v0, "user_id"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "o_srtadiqnriite"

    const/4 v5, 0x4

    const-string v2, "drn_gosprtiieai"

    const-string/jumbo v2, "registration_id"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v3, "qswaodss"

    const-string v3, "asspwdos"

    const/4 v5, 0x3

    const-string v3, "asspswro"

    const-string/jumbo v3, "password"

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p1}, Lh3/b;->y(I)V

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lh3/b;->C(J)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-static {v2}, Lh3/b;->z(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-static {p2}, Lh3/b;->w(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method
