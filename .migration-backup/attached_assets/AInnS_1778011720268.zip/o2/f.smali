.class public Lo2/f;
.super Ljava/lang/Object;


# static fields
.field public static volatile c:Lo2/f;


# instance fields
.field public a:J

.field public b:J


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    iput-wide v0, p0, Lo2/f;->a:J

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lo2/f;->b:J

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public static a()Lo2/f;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "d@s@o@@i v~l~1o  S@~M~ o bs@ @~ -~ayt~ @@ /f~/~ b@.@K@~  @o~~@4@~un br~o~@~i ~~f~@cm~~o@@@t   li"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lo2/f;->c:Lo2/f;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-class v0, Lo2/f;

    const-class v0, Lo2/f;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v1, Lo2/f;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v1}, Lo2/f;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-object v1, Lo2/f;->c:Lo2/f;

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lo2/f;->c:Lo2/f;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method


# virtual methods
.method public b(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Lo2/q;->p(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-wide v0, p0, Lo2/f;->b:J

    const/4 v3, 0x7

    return-void
.end method

.method public c(Landroid/content/Context;)V
    .locals 10

    const/4 v8, 0x4

    move v9, v8

    invoke-static {p1}, Lo2/q;->p(Landroid/content/Context;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v9, 0x7

    return-void

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0}, Lo2/i;->f()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v1, "cenmvMisATsiesBu"

    const-string/jumbo v1, "iTsuMeecssBtinAv"

    const/4 v9, 0x6

    const-string/jumbo v1, "susioTAtMseviBen"

    const-string v1, "MTActiveBusiness"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-nez v0, :cond_1

    const/4 v9, 0x7

    const-string v0, " Ftmeotogdurncnr eocorn"

    const/4 v9, 0x7

    const-string/jumbo v0, "otcdrbcoeee  ronFtgonnr"

    const-string/jumbo v0, "re connect toForeground"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/16 v0, 0xbb2

    const/4 v9, 0x4

    const/4 v1, 0x6

    const/4 v9, 0x3

    const/4 v1, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v8, 0x7

    and-int/2addr v9, v8

    return-void

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x3

    iget-wide v2, p0, Lo2/f;->b:J

    const/4 v9, 0x3

    const/4 v8, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    cmp-long v0, v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v0, :cond_2

    return-void

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    iput-wide v2, p0, Lo2/f;->a:J

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-wide v4, p0, Lo2/f;->b:J

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    sub-long/2addr v2, v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {}, Lh3/b;->c()J

    move-result-wide v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-wide/16 v6, 0x2

    const-wide/16 v6, 0x2

    const/4 v9, 0x5

    const-wide/16 v6, 0x2

    const-wide/16 v6, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    div-long/2addr v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    cmp-long v0, v2, v4

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-gez v0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-void

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string/jumbo v0, "oeea euhtrar"

    const-string v0, " bteorheeraa"

    const/4 v9, 0x2

    const-string v0, "e taetrpabhr"

    const-string/jumbo v0, "re heartbeat"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Lo2/i;->k(Landroid/content/Context;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {}, Lo2/i;->a()Lo2/i;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v0, p1}, Lo2/i;->i(Landroid/content/Context;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-void
.end method
