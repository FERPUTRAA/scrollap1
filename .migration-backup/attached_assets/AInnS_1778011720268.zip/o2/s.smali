.class public Lo2/s;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[B)I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @s@ iy @~~ @/S@~b@fua M~ ~ s o~4~~o@~o~ -1tlrb~~~v@@/ o~ .@c~~@ m~@ d@@  @@~~io  @~ntl@oiK~b@~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    const-string/jumbo v0, "stnmltpCti"

    const-string/jumbo v0, "lpsnettiCt"

    const/4 v6, 0x2

    const-string/jumbo v0, "lptHoCitte"

    const-string v0, "HttpClient"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v3, Ljava/net/URL;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v3, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    check-cast p1, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v3, "POST"

    const-string v3, "POST"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/16 v3, 0x1770

    const/4 v6, 0x4

    invoke-virtual {p1, v3}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    invoke-virtual {p1, v3}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v3, "oromAtzihiutn"

    const/4 v6, 0x7

    const-string/jumbo v3, "tniizbruootah"

    const-string v3, "Authorization"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1, v3, p2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/net/SocketTimeoutException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string p2, "Charset"

    :try_start_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    sget-object v3, Lx2/a;->b:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo p2, "uAtpco"

    const-string p2, "cctpoA"

    const/4 v6, 0x7

    const-string p2, "epctAp"

    const-string p2, "Accept"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v3, "pntooinaqsb/acaij"

    const-string v3, "cnatsb/niajiopola"

    const/4 v6, 0x2

    const-string v3, "application/jason"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo p2, "tdsgeEcnpAunci-"

    const-string/jumbo p2, "nEnp-ductegcAoi"

    const/4 v6, 0x2

    const-string p2, "ccdmEgAe-onintc"

    const-string p2, "Accept-Encoding"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v3, "pigz"

    const-string v3, "gzpi"

    const/4 v6, 0x1

    const-string/jumbo v3, "pzgi"

    const-string v3, "gzip"

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo p2, "nc-toetppytn"

    const-string p2, "ctttneypen-p"

    const/4 v6, 0x6

    const-string/jumbo p2, "nttctbonyepe"

    const-string p2, "content-type"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "ntc/t-uecimqsalipopeaatt"

    const-string/jumbo v3, "tpnecleoqa-/astmttiaipco"

    const/4 v6, 0x0

    const-string/jumbo v3, "iraptc-patco/otilteanesm"

    const-string v3, "application/octet-stream"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/net/SocketTimeoutException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string p2, "LCetttonqhgne-"

    const-string p2, "Content-Length"

    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    array-length v3, p3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1, p2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string p2, "AysKXpes-"

    const-string p2, "Kpsy-e-AX"

    const/4 v6, 0x4

    const-string/jumbo p2, "ypAm-e-pK"

    const-string p2, "X-App-Key"

    :try_start_4
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {p0}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, p2, p0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    invoke-static {}, Ly2/b;->p()I

    move-result p0
    :try_end_4
    .catch Ljava/net/SocketTimeoutException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 p2, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ne p0, p2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string p0, "SM4"

    const-string p0, "S4M"

    const/4 v6, 0x5

    const-string p0, "S4M"

    const-string p0, "SM4"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const-string p0, ""

    const-string p0, ""

    :goto_0
    :try_start_5
    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo p2, "mpy-orTyecEn"

    const-string p2, "cpymynEr-Tpe"

    const/4 v6, 0x6

    const-string p2, "EtpcybTeynp-"

    const-string p2, "Encrypt-Type"

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1, p2, p0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    instance-of p0, p1, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string p0, "TLS"

    const-string p0, "LST"

    const/4 v6, 0x1

    const-string p0, "LTS"

    const-string p0, "TLS"

    const/4 v6, 0x6

    invoke-static {p0}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0, v2, v2, v2}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast p2, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p2, p0}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast p0, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance p2, La3/a;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p2, v3}, La3/a;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0, p2}, Ljavax/net/ssl/HttpsURLConnection;->setHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V

    :cond_1
    const/4 p0, 0x1

    const/4 v6, 0x4

    move v5, p0

    move v5, p0

    const/4 v6, 0x7

    invoke-virtual {p1, p0}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1, p0}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 p0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1, p0}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    invoke-virtual {p1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p0
    :try_end_5
    .catch Ljava/net/SocketTimeoutException; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0, p3}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/io/OutputStream;->flush()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1
    :try_end_6
    .catch Ljava/net/SocketTimeoutException; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p0}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    goto/16 :goto_4

    :catchall_0
    move-exception p2

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_1

    :catch_0
    move-exception p2

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_2

    :catchall_1
    move-exception p0

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_1

    :catch_1
    move-exception p0

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    :goto_1
    :try_start_7
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v3, "ilsd fuooa e"

    const-string v3, " odlos aieft"

    const/4 v6, 0x4

    const-string/jumbo v3, "idtoaefp  ls"

    const-string/jumbo v3, "post failed "

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {p3, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x6

    and-int/2addr v6, v5

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x7

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz p2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_3

    :catch_2
    move-exception p0

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    :goto_2
    :try_start_8
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, ":eeTstEkqix tosttoebnpccoiup"

    const-string/jumbo v3, "seeoTb:E tntpioxeooctkiscutp"

    const-string v3, "Tospuemt exktiotnsoio:epEscc"

    const-string/jumbo v3, "post socketTimeoutException:"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p3, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x0

    move v6, v5

    if-eqz p2, :cond_2

    :goto_3
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_4
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_2
    const/4 v6, 0x7

    return v1

    :catchall_3
    move-exception p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p1}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2}, Ld3/q;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x3

    if-eqz p2, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p2}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    throw p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string/jumbo v0, "s f aeuelolic"

    const/4 v8, 0x0

    const-string v0, " eamce dflils"

    const-string v0, "close failed "

    const/4 v7, 0x7

    move v8, v7

    invoke-static {p0}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result p0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string/jumbo v2, "ptCHoipnel"

    const-string/jumbo v2, "tentClippH"

    const/4 v8, 0x7

    const-string/jumbo v2, "leCttbntiH"

    const-string v2, "HttpClient"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez p0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo p0, "regadewoqen nt eCn ntssc/kt, tiocdi"

    const/4 v8, 0x7

    const-string p0, "etdt kugnts n/wneorCcosnedet, iic/ "

    const-string p0, "can\'t get, network is disConnected"

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v2, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object v1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const-string/jumbo v3, "teqrUesp:sl"

    const-string/jumbo v3, "rlsee:qUstu"

    const/4 v8, 0x5

    const-string/jumbo v3, "lerqutUsqr:"

    const-string/jumbo v3, "requestUrl:"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v2, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v7, 0x5

    new-instance p0, Ljava/net/URL;

    const/4 v8, 0x0

    invoke-direct {p0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x4

    check-cast p0, Ljava/net/HttpURLConnection;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string p1, "ETG"

    const-string p1, "ETG"

    const/4 v8, 0x2

    const-string p1, "EGT"

    const-string p1, "GET"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p0, p1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/16 p1, 0x1770

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo p1, "toszrahiutino"

    const-string/jumbo p1, "itzmnrohtoiua"

    const-string/jumbo p1, "utimoarhoAint"

    const-string p1, "Authorization"

    const/4 v8, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0, p1, p2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_7
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_6
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string p1, "hrCooet"

    const-string/jumbo p1, "taheorC"

    const/4 v8, 0x0

    const-string/jumbo p1, "sehCabt"

    const-string p1, "Charset"

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object p2, Lx2/a;->b:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p0, p1, p2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    instance-of p1, p0, Ljavax/net/ssl/HttpsURLConnection;
    :try_end_1
    .catch Ljava/net/MalformedURLException; {:try_start_1 .. :try_end_1} :catch_7
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_6
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    const/4 v8, 0x0

    const/4 v7, 0x3

    if-eqz p1, :cond_1

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string p1, "STL"

    const/4 v8, 0x4

    const-string p1, "TSL"

    const-string p1, "TLS"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p1}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p1, v1, v1, v1}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    check-cast p2, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p2, p1}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    check-cast p1, Ljavax/net/ssl/HttpsURLConnection;

    const/4 v7, 0x2

    move v8, v7

    new-instance p2, La3/a;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {p2, v3}, La3/a;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ljavax/net/ssl/HttpsURLConnection;->setHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V
    :try_end_2
    .catch Ljava/net/MalformedURLException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto/16 :goto_4

    :catch_0
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto/16 :goto_8

    :catch_1
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto/16 :goto_c

    :cond_1
    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 p1, 0x1

    :try_start_3
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 p1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0}, Ljava/net/URLConnection;->connect()V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/net/URLConnection;->getContentLength()I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/16 v3, 0xc8

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-ne p2, v3, :cond_6

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p0
    :try_end_3
    .catch Ljava/net/MalformedURLException; {:try_start_3 .. :try_end_3} :catch_7
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_6
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    :try_start_4
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance p2, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    invoke-direct {p2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_4
    .catch Ljava/net/MalformedURLException; {:try_start_4 .. :try_end_4} :catch_5
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/16 v3, 0x400

    :try_start_5
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-array v3, v3, [B

    :goto_1
    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p0, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v5, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eq v4, v5, :cond_2

    const/4 v8, 0x2

    invoke-virtual {p2, v3, p1, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_1

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1
    :try_end_5
    .catch Ljava/net/MalformedURLException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    const/4 v8, 0x3

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v8, 0x5

    const/4 v7, 0x2

    goto :goto_2

    :catchall_1
    move-exception p0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object p1

    :catchall_2
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    goto :goto_4

    :catch_2
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto/16 :goto_8

    :catch_3
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto/16 :goto_c

    :catchall_3
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_3

    :catch_4
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto/16 :goto_7

    :catch_5
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto/16 :goto_b

    :catchall_4
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_3
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_4
    :try_start_7
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v4, "f btd uagel"

    const-string v4, "el  gbaftid"

    const/4 v8, 0x2

    const-string v4, " tga dlpeef"

    const-string v4, "get failed "

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_8

    const/4 v8, 0x5

    if-eqz p2, :cond_3

    :try_start_8
    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto :goto_5

    :catchall_5
    move-exception p0

    const/4 v7, 0x7

    move v8, v7

    goto :goto_6

    :cond_3
    :goto_5
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz p1, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto/16 :goto_f

    :goto_6
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto/16 :goto_f

    :catch_6
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_7
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_8
    :try_start_9
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "goioc: nqpettxEe"

    const-string/jumbo v4, "p tooxuEnicege:t"

    const/4 v8, 0x3

    const-string v4, "Egsx:ieoioc tnet"

    const-string v4, "get ioException:"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_8

    const/4 v8, 0x3

    if-eqz p2, :cond_4

    :try_start_a
    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x6

    const/4 v7, 0x2

    goto :goto_9

    :catchall_6
    move-exception p0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    goto :goto_a

    :cond_4
    :goto_9
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz p1, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    const/4 v7, 0x7

    move v8, v7

    goto/16 :goto_f

    :goto_a
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    goto/16 :goto_f

    :catch_7
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_b
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_c
    :try_start_b
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v4, "mtomrate:iEexpelfo mLnpdcU"

    const-string v4, "Ee maeepmcpxrttoUi:ofLndlg"

    const/4 v8, 0x0

    const-string/jumbo v4, "optnodLimf elrmxeeoEatgRU:"

    const-string v4, "get malformedURLException:"

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    or-int/2addr v8, v7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_8

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz p2, :cond_5

    :try_start_c
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_d

    :catchall_7
    move-exception p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_e

    :cond_5
    :goto_d
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz p1, :cond_6

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto :goto_f

    :goto_e
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v2, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    :goto_f
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-object v1

    :catchall_8
    move-exception p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz p2, :cond_7

    :try_start_d
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_10

    :catchall_9
    move-exception p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto :goto_11

    :cond_7
    :goto_10
    const/4 v8, 0x4

    if-eqz p1, :cond_8

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_9

    const/4 v7, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_12

    :goto_11
    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    :goto_12
    const/4 v8, 0x3

    const/4 v7, 0x6

    throw p0
.end method
