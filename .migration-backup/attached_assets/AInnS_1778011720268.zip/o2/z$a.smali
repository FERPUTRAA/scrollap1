.class public Lo2/z$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/z;->h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic b:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Lo2/z;Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p2, p0, Lo2/z$a;->a:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p3, p0, Lo2/z$a;->b:Landroid/os/Bundle;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ s~4l~@@~i@~.o~ ~ o b @~@~M/~@~s u@o@1/~ c rfvia~o-Kf@ Sil  b~ @ ~@y~d~t@@o ~~@ @~no@ @~t@@ @b~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lo2/z$a;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lo2/z$a;->b:Landroid/os/Bundle;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/16 v2, 0xf8b

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0, v2, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method
