.class public Lo2/p;
.super Ljava/lang/Object;


# static fields
.field public static c:I = 0xc8

.field public static volatile d:Lo2/p;


# instance fields
.field public a:Z

.field public b:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean v0, p0, Lo2/p;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static c()Lo2/p;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lo2/p;->d:Lo2/p;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-class v0, Lo2/p;

    const-class v0, Lo2/p;

    const/4 v3, 0x0

    const-class v0, Lo2/p;

    const-class v0, Lo2/p;

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v1, Lo2/p;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1}, Lo2/p;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v1, Lo2/p;->d:Lo2/p;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lo2/p;->d:Lo2/p;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/content/Context;Ljava/lang/String;Lorg/json/JSONObject;Ljava/io/File;)I
    .locals 16

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    const-string v1, "/esr3/pvro"

    const-string/jumbo v1, "oes/3p/rvr"

    const-string/jumbo v1, "pr/mtv/ero"

    const-string v1, "/v3/report"

    const-string v2, "eoptor3/mvs/gr"

    const-string v2, "/v3/sgm/report"

    const-string v3, "gms"

    const-string/jumbo v3, "sgm"

    const-string v4, ":"

    const-string v4, ":"

    const-string v4, ":"

    const-string v4, ":"

    const-string/jumbo v5, "smBrobMeeTuRsist"

    const-string/jumbo v5, "nosmTtrssBMiueeR"

    const-string/jumbo v5, "rsBTeoupMtRessun"

    const-string v5, "MTReportBusiness"

    const/4 v6, -0x1

    :try_start_0
    invoke-static/range {p1 .. p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result v7

    if-nez v7, :cond_0

    const-string/jumbo v0, "rirnd  pn,tcoiC sernp/ckeosdaeewoot/tn"

    const-string/jumbo v0, "tcreonnC/wdik rcot /pde,oanoietnst ers"

    const-string/jumbo v0, "inteenioqn rpn,s aCccodot/ws rkdrt /et"

    const-string v0, "can\'t report, network is disConnected"

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v6

    :cond_0
    invoke-static/range {p1 .. p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v7

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    cmp-long v9, v7, v9

    if-nez v9, :cond_1

    const-string v0, "b s s0di"

    const-string v0, "0sdi bi "

    const-string/jumbo v0, "s imi0d "

    const-string/jumbo v0, "uid is 0"

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v6

    :cond_1
    invoke-static/range {p1 .. p1}, Lh3/b;->d(Landroid/content/Context;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_2

    const-string/jumbo v0, "penroo tau hrl  reertru"

    const-string/jumbo v0, "rthe ru rrapoen outl er"

    const-string/jumbo v0, "ou  eb l rhaeepnrtrerto"

    const-string/jumbo v0, "there are no report url"

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v6

    :cond_2
    const-string/jumbo v10, "udi"

    const-string/jumbo v10, "uid"

    const-string/jumbo v10, "idu"

    const-string/jumbo v10, "uid"

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    invoke-virtual {v11, v10, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    invoke-virtual/range {p3 .. p3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v10

    sget-object v12, Lx2/a;->b:Ljava/lang/String;

    invoke-virtual {v10, v12}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v10

    invoke-static {v10}, Ld3/g;->c([B)[B

    move-result-object v10

    invoke-static {}, Ld3/a;->h()I

    move-result v12

    int-to-long v12, v12

    invoke-static {v12, v13}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x10

    new-array v13, v13, [B

    fill-array-data v13, :array_0

    new-instance v14, Ljava/lang/String;

    const-string v15, "8upFU"

    const-string v15, "F8pU-"

    const-string v15, "FUp-8"

    const-string v15, "UTF-8"

    invoke-static {v15}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-direct {v14, v13, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v13, 0x62

    invoke-static {v14, v13}, Ld3/a;->j(Ljava/lang/String;C)Ljava/lang/String;

    move-result-object v13

    invoke-static {}, Ly2/b;->p()I

    move-result v14

    const/4 v15, 0x2

    if-eq v14, v15, :cond_3

    invoke-static {v10, v12, v13}, Ld3/a;->f([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v10

    const/4 v14, 0x1

    goto :goto_0

    :cond_3
    invoke-static {v10, v12, v13}, Ld3/n;->k([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v10

    :goto_0
    invoke-static/range {p1 .. p1}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Ld3/o;->i(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v10}, Ld3/o;->h([B)Ljava/lang/String;

    move-result-object v15

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ld3/o;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " iqBqs"

    const-string v7, " sqBai"

    const-string/jumbo v7, "sBsi a"

    const-string v7, "Basic "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    const/16 v7, 0xa

    invoke-static {v4, v7}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x0

    :goto_1
    const/4 v12, 0x3

    if-ge v8, v12, :cond_4

    invoke-interface {v6, v9}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_4
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_a

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_5

    invoke-virtual {v8, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_5

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_5
    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_6

    invoke-virtual {v8, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_6

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :cond_6
    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    invoke-static {v9, v8, v4, v10}, Lo2/s;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;[B)I

    move-result v12
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v13, 0xc8

    const-string v15, "a lmis:,Nem"

    const-string v15, "eis: e,Nmla"

    const-string/jumbo v15, "l,eioafm :N"

    const-string v15, ", fileName:"

    const-string/jumbo v7, "rum: b"

    const-string/jumbo v7, "u rml:"

    const-string/jumbo v7, "ul, ru"

    const-string v7, ", url:"

    if-ne v12, v13, :cond_9

    :try_start_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "toecoucscrytsrep  :repn"

    const-string v1, "cyee opptr espnturscc:r"

    const-string/jumbo v1, "report success encrypt:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p3 .. p3}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_7

    const/4 v0, 0x0

    return v0

    :cond_7
    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->delete()Z

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "lqed be"

    const-string v2, "delteb "

    const-string v2, "etsdee "

    const-string v2, "delete "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v0, :cond_8

    const-string/jumbo v0, "scsmueu"

    const-string/jumbo v0, "sesucsu"

    const-string v0, "cucsoss"

    const-string/jumbo v0, "success"

    goto :goto_3

    :cond_8
    const-string/jumbo v0, "leipdb"

    const-string/jumbo v0, "ipeldf"

    const-string/jumbo v0, "ualedf"

    const-string v0, "failed"

    :goto_3
    :try_start_2
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "fpe: i"

    const-string v0, " file:"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x0

    return v13

    :cond_9
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v0, "qoerdtf:q epia dlcr"

    const-string v0, "det:par qlofiecro d"

    const-string v0, "fosd eorareilde :tc"

    const-string/jumbo v0, "report failed code:"

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p3 .. p3}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    goto/16 :goto_2

    :catchall_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " tsadiorrpelf "

    const-string/jumbo v2, "paomdtleerr f "

    const-string/jumbo v2, "report failed "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_a
    const/4 v1, -0x1

    return v1

    nop

    :array_0
    .array-data 1
        0xbt
        0xdt
        0x12t
        0x50t
        0x52t
        0x51t
        0x52t
        0x56t
        0x52t
        0x57t
        0x52t
        0x54t
        0x3t
        0x32t
        0x9t
        0x43t
    .end array-data
.end method

.method public b(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v0, "sTeMoRnuetosBisp"

    const-string v0, "MTReportBusiness"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Lo2/p;->b:Ljava/lang/String;

    const/4 v6, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p1}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    sget-object v2, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const-string/jumbo v4, "o_iemberetlcogs_gnarbpvema_"

    const-string v4, "_simocnpot_rmcerelgbe_veaag"

    const/4 v6, 0x7

    const-string/jumbo v4, "mrrce_ua_peanbgiea_gosevtol"

    const-string v4, "com_engagelab_privates_core"

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    iput-object p1, p0, Lo2/p;->b:Ljava/lang/String;

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, p0, Lo2/p;->b:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object v2, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v3, "s: eoalpie"

    const-string v3, " isao:elev"

    const/4 v6, 0x7

    const-string v3, " aseile:qf"

    const-string/jumbo v3, "save file:"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v2, Ljava/io/File;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz p1, :cond_1

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object v1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/File;->createNewFile()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez p1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object v1

    :cond_2
    const/4 v6, 0x6

    new-instance p1, Ljava/io/FileOutputStream;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    sget-object v3, Lx2/a;->b:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p2, v3}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1, p2}, Ljava/io/FileOutputStream;->write([B)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object v2

    :catchall_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "oiesabet Rentd lCponeatrf"

    const/4 v6, 0x6

    const-string/jumbo v2, "les ReedtCt tnfeainpaorsv"

    const-string/jumbo v2, "saveReportContent failed "

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object v1
.end method

.method public final d(Landroid/content/Context;Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v0, "miume"

    const-string/jumbo v0, "mueii"

    const/4 v6, 0x4

    const-string/jumbo v0, "tiemo"

    const-string/jumbo v0, "itime"

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    div-long/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p2, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v0, "dti_pbucna"

    const-string/jumbo v0, "iucodanp_t"

    const/4 v6, 0x4

    const-string/jumbo v0, "ndiao_uctu"

    const-string v0, "account_id"

    const/4 v5, 0x4

    const/4 v5, 0x6

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-virtual {p2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v5, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    new-instance v1, Lorg/json/JSONArray;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1, p2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo p2, "ptcnoqt"

    const-string p2, "cqttonn"

    const/4 v6, 0x1

    const-string p2, "cqntetn"

    const-string p2, "content"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo p2, "omsflsra"

    const-string/jumbo p2, "oasrpmfl"

    const/4 v6, 0x0

    const-string/jumbo p2, "lapmmtrf"

    const-string/jumbo p2, "platform"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v1, "a"

    const-string v1, "a"

    const/4 v6, 0x3

    const-string v1, "a"

    const-string v1, "a"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo p2, "idu"

    const-string/jumbo p2, "idu"

    const/4 v6, 0x7

    const-string/jumbo p2, "udi"

    const-string/jumbo p2, "uid"

    :try_start_1
    const/4 v5, 0x1

    move v6, v5

    invoke-static {p1}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, p2, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo p2, "n_ivoproesa"

    const-string p2, "app_version"

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-static {p1}, Ly2/b;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string p2, "aym_pbp"

    const-string p2, "_pampky"

    const/4 v6, 0x1

    const-string p2, "aekpypu"

    const-string p2, "app_key"

    :try_start_3
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p1}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo p2, "paeonnc"

    const-string p2, "caleonn"

    const-string p2, "aqcnnhe"

    const-string p2, "channel"

    :try_start_4
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Ly2/b;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x0

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object p1, p1, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p2, :cond_3

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast p2, Lc3/b;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {p2}, Lc3/b;->i()Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p2}, Lc3/b;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p2}, Lc3/b;->e()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p2}, Lc3/b;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2}, Lc3/b;->e()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x2

    return-object v0

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const-string/jumbo v0, "nasiaeppertsRorelb Jdfo e"

    const-string v0, " anfoblarptperoesieedJRp "

    const/4 v6, 0x5

    const-string/jumbo v0, "prepareReportJson failed "

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo p2, "suimtMpuesoeBsnT"

    const-string p2, "esiBpsutsTMueoRn"

    const/4 v6, 0x3

    const-string/jumbo p2, "uesroRBTieposntM"

    const-string p2, "MTReportBusiness"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object p1
.end method

.method public declared-synchronized e(Landroid/content/Context;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-boolean v0, p0, Lo2/p;->a:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    monitor-exit p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    return-void

    :cond_0
    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v0, "MsueTbstBRnsprpi"

    const-string v0, "RiTssteperMpsuBn"

    const/4 v9, 0x7

    const-string/jumbo v0, "pnTtsiuRsBsueeor"

    const-string v0, "MTReportBusiness"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v1, "eopcacephbgt rqirn"

    const-string v1, "ehgerpeoqia bntccr"

    const/4 v9, 0x0

    const-string/jumbo v1, "nrgatce qochbpeeir"

    const-string/jumbo v1, "report cache begin"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v0, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    iput-boolean v0, p0, Lo2/p;->a:Z

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v0, p0, Lo2/p;->b:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v1, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x0

    if-eqz v0, :cond_1

    const/4 v8, 0x7

    and-int/2addr v9, v8

    iput-boolean v1, p0, Lo2/p;->a:Z

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string/jumbo p1, "tTspsBsneeMrouss"

    const-string p1, "essinuTesrposMtB"

    const/4 v9, 0x0

    const-string p1, "MTReportBusiness"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v0, "  am noepmceeerher attrhc"

    const-string v0, "eacmeeona eet t rcrh hopr"

    const/4 v9, 0x3

    const-string/jumbo v0, "rr roee ceerahhna pooctt "

    const-string/jumbo v0, "there are no report cache"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    monitor-exit p0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-void

    :cond_1
    :try_start_2
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v0, Ljava/io/File;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v2, p0, Lo2/p;->b:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez v2, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    iput-boolean v1, p0, Lo2/p;->a:Z

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string p1, "MnsspbTeioueRrto"

    const-string/jumbo p1, "itpuoRsrTMseoesn"

    const/4 v9, 0x3

    const-string/jumbo p1, "oriBMtuuRsTeepsn"

    const-string p1, "MTReportBusiness"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string v0, " o ephep nrrco hreaeractt"

    const-string v0, "hcerobtaep eetrnhro   rca"

    const/4 v9, 0x7

    const-string v0, "ancrch oqpera  oeet reher"

    const-string/jumbo v0, "there are no report cache"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-exit p0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    return-void

    :cond_2
    :try_start_3
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v2, p0, Lo2/p;->b:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    sget v3, Lo2/p;->c:I

    const/4 v9, 0x6

    invoke-static {v2, v3}, Ld3/f;->d(Ljava/lang/String;I)V

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v0, :cond_7

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    array-length v2, v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez v2, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto/16 :goto_1

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v2, Lo2/p$a;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v2, p0}, Lo2/p$a;-><init>(Lo2/p;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v9, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v2, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    check-cast v2, Ljava/io/File;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v3, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string/jumbo v4, "leshc cieFu"

    const-string v4, "eecFihul [c"

    const/4 v9, 0x1

    const-string v4, "e [mFlhacei"

    const-string v4, "cacheFile ["

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v2, "ixnet]sps o i"

    const/4 v9, 0x3

    const-string v2, " sinoet  os]i"

    const-string v2, "] is no exist"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string/jumbo v3, "snsoebrMqTpRuest"

    const-string/jumbo v3, "snesuorTqRMpseti"

    const/4 v9, 0x6

    const-string/jumbo v3, "rtBiTeusseMoRpus"

    const-string v3, "MTReportBusiness"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v3, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_0

    :cond_4
    :try_start_4
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance v3, Ljava/io/FileInputStream;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v3, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/io/FileInputStream;->available()I

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-array v4, v4, [B

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3, v4}, Ljava/io/FileInputStream;->read([B)I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance v3, Ljava/lang/String;

    const/4 v9, 0x5

    sget-object v5, Lx2/a;->b:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v4, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    monitor-exit p0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-void

    :cond_5
    :try_start_5
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v4, Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v3, "type"

    const/4 v9, 0x1

    const-string/jumbo v3, "ytep"

    const-string/jumbo v3, "type"

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v4, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string/jumbo v5, "ssinrsppuseoBRTM"

    const-string v5, "TospesntrBiuMssR"

    const-string v5, "ToeReMnrqBistpss"

    const-string v5, "MTReportBusiness"
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :try_start_7
    const/4 v8, 0x1

    const/4 v8, 0x4

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v7, "m seotfa:hcCrlepr"

    const-string v7, "epem:oC tfarhlrce"

    const/4 v9, 0x6

    const-string/jumbo v7, "rh mfetpiaeCrec:o"

    const-string/jumbo v7, "reportCache file:"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p0, p1, v3, v4, v2}, Lo2/p;->a(Landroid/content/Context;Ljava/lang/String;Lorg/json/JSONObject;Ljava/io/File;)I
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v2

    :try_start_8
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v4, "toiCo flcoaadhprree"

    const-string v4, "dcfeoatlaore heiCrp"

    const/4 v9, 0x2

    const-string/jumbo v4, "reportCache failed "

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo v3, "nMstebousBrsTepi"

    const-string/jumbo v3, "sMnBTbseoterupsi"

    const/4 v9, 0x0

    const-string v3, "RMotrBuisenepsus"

    const-string v3, "MTReportBusiness"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {v3, v2}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto/16 :goto_0

    :cond_6
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    iput-boolean v1, p0, Lo2/p;->a:Z

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string/jumbo p1, "teRriMnpToeuuBss"

    const-string p1, "MeponsuuseBRTrit"

    const/4 v9, 0x2

    const-string p1, "BoiRTesnqsMsrepu"

    const-string p1, "MTReportBusiness"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v0, "iasnhrhtor  sepcipe"

    const-string/jumbo v0, "ihh irapreotcpnce s"

    const/4 v9, 0x1

    const-string/jumbo v0, "ntimo  chrhrsaeepci"

    const-string/jumbo v0, "report cache finish"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    monitor-exit p0

    const/4 v9, 0x7

    return-void

    :cond_7
    :goto_1
    :try_start_9
    const/4 v8, 0x7

    move v9, v8

    iput-boolean v1, p0, Lo2/p;->a:Z

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo p1, "nousiRrTqepetBss"

    const/4 v9, 0x3

    const-string/jumbo p1, "nTsRosBepieuMtso"

    const-string p1, "MTReportBusiness"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string/jumbo v0, "retahbtapense  o herrrc c"

    const-string/jumbo v0, "rtseee ahrr hoen rc pcato"

    const/4 v9, 0x0

    const-string/jumbo v0, "there are no report cache"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    monitor-exit p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    return-void

    :catchall_1
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    monitor-exit p0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    throw p1
.end method

.method public f(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v0, "cloprmut"

    const-string/jumbo v0, "oromtplc"

    const/4 v4, 0x7

    const-string/jumbo v0, "olocrptp"

    const-string/jumbo v0, "protocol"

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Lcom/engagelab/privates/core/api/MTReporter;

    const-class v1, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v4, 0x5

    const-class v1, Lcom/engagelab/privates/core/api/MTReporter;

    const-class v1, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Lo2/p;->e(Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast p2, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTReporter;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "epty"

    const-string v1, "etpy"

    const/4 v4, 0x0

    const-string v1, "epyt"

    const-string/jumbo v1, "type"

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTReporter;->c()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v0}, Lo2/p;->d(Landroid/content/Context;Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v1}, Lo2/p;->b(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTReporter;->c()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2, v0, v1}, Lo2/p;->a(Landroid/content/Context;Ljava/lang/String;Lorg/json/JSONObject;Ljava/io/File;)I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Lo2/p;->e(Landroid/content/Context;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string v0, "aeolrrdfqe ito"

    const-string/jumbo v0, "odeaort l refi"

    const/4 v4, 0x6

    const-string/jumbo v0, "pfsdaret e oir"

    const-string/jumbo v0, "report failed "

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string p2, "esimuTepBtnsrMRs"

    const-string p2, "MTReportBusiness"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x5

    return-void
.end method
