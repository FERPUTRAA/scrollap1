.class public Lo2/q;
.super Ljava/lang/Object;


# static fields
.field public static a:Landroid/content/SharedPreferences;


# direct methods
.method public static A(Landroid/content/Context;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@sb d ttb1  @~@f~ ~~oS@-~~4l @@K@~f.@o~@@@r  ~  @~@ mo~@M~i@~yb~~~uil~ @v~~o  a n s/@@ @~iooc~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object p0, Lo2/q;->a:Landroid/content/SharedPreferences;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "ddemis_"

    const-string v0, "eissdd_"

    const/4 v3, 0x6

    const-string v0, "eeido_d"

    const-string/jumbo v0, "seed_id"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return p0
.end method

.method public static B(Landroid/content/Context;)J
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v0, "etsvrbimrme"

    const-string/jumbo v0, "rrem_svtemi"

    const/4 v4, 0x3

    const-string v0, "_etsvmuriee"

    const-string/jumbo v0, "server_time"

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {p0, v0, v1, v2}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-wide v0
.end method

.method public static C(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v0, Lo2/q;->a:Landroid/content/SharedPreferences;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0}, Ly2/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v2, "etipeAppaNo:"

    const-string/jumbo v2, "ti:poAeempaN"

    const/4 v5, 0x2

    const-string/jumbo v2, "t:iaSpepqNAm"

    const-string v2, "AppSiteName:"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const-string/jumbo v2, "iosnTegCroCf"

    const-string v2, "fioTrbeoCCgn"

    const/4 v5, 0x1

    const-string v2, "MTCoreConfig"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v2, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "uenmSaogp"

    const-string/jumbo v1, "niSapgueo"

    const/4 v5, 0x5

    const-string v1, "anrpoiogS"

    const-string v1, "Singapore"

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    and-int/2addr v5, v4

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v0, ".arprba.lnpaeti.gmregcbeosopc.eef"

    const-string v0, "airlr.speagp.frto.sneeeebgc.aopmc"

    const/4 v5, 0x3

    const-string v0, ".natsru.b.gpecoeaeme.gisfrcovraep"

    const-string v0, "com.engagelab.privates.core.prefs"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    sput-object p0, Lo2/q;->a:Landroid/content/SharedPreferences;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v3, ".efqgnop.t.r.eeivocrealecpsag_abrs"

    const-string/jumbo v3, "srobsgeeqer.pia.eoamrn.tcg.vafelc_"

    const/4 v5, 0x4

    const-string/jumbo v3, "oslb.esiqaegrpnaveetcr.oaegrm_p.cf"

    const-string v3, "com.engagelab.privates.core.prefs_"

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-object p0, Lo2/q;->a:Landroid/content/SharedPreferences;

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object p0, Lo2/q;->a:Landroid/content/SharedPreferences;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p0
.end method

.method public static D(Landroid/content/Context;)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v1, "stsssdap_ec"

    const-string v1, "_csrtdsapes"

    const/4 v3, 0x2

    const-string v1, "_cdmsrdsate"

    const-string/jumbo v1, "tcp_address"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0
.end method

.method public static E(Landroid/content/Context;)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    move v3, v2

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "__smaeclpdtrsss"

    const-string/jumbo v1, "s__dotcssardsep"

    const-string/jumbo v1, "tcp_address_ssl"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static F(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, "c__o_bvalsssprdtdsc"

    const-string/jumbo v0, "stplo_sacrds_cds__v"

    const/4 v3, 0x0

    const-string/jumbo v0, "res_acussl_tdcsdvp_"

    const-string/jumbo v0, "tcp_address_ssl_c_v"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return p0
.end method

.method public static G(Landroid/content/Context;)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    const-string v1, "e_dardbpsdp"

    const-string v1, "e_rdabpsdds"

    const-string/jumbo v1, "sddper_sqau"

    const-string/jumbo v1, "udp_address"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public static H(Landroid/content/Context;)J
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v0, "_usdrui"

    const-string v0, "edu_riu"

    const/4 v4, 0x0

    const-string/jumbo v0, "sium_er"

    const-string/jumbo v0, "user_id"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    invoke-interface {p0, v0, v1, v2}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-wide v0
.end method

.method public static I(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v0, "u_uloeeanpagg"

    const-string v0, "guasagepl_uen"

    const/4 v3, 0x7

    const-string v0, "asruabe_uegnl"

    const-string/jumbo v0, "user_language"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const-string/jumbo v0, "ncttrcu_snlscq_"

    const-string/jumbo v0, "lscosnn_qttr_cc"

    const/4 v3, 0x2

    const-string v0, "e_sn_rsplonttcc"

    const-string v0, "connect_ssl_crt"

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0
.end method

.method public static b(Landroid/content/Context;B)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "ospttf_eqtsaal"

    const-string v0, "amspaoseflt_tt"

    const/4 v2, 0x2

    const-string v0, "frslttt_apemao"

    const-string/jumbo v0, "platform_state"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public static c(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "o_cm_tcmnvsnlc_"

    const-string/jumbo v0, "nc_motes_cvlnc_"

    const/4 v2, 0x6

    const-string/jumbo v0, "osc_ot_ecl_nsnv"

    const-string v0, "connect_ssl_c_v"

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public static d(Landroid/content/Context;J)V
    .locals 3

    const/4 v2, 0x1

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "o_tesbirmer"

    const-string/jumbo v0, "iereose_mtr"

    const/4 v2, 0x0

    const-string/jumbo v0, "v_teerusier"

    const-string/jumbo v0, "server_time"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p0, v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "_lcstbcntr_soec"

    const/4 v2, 0x2

    const-string/jumbo v0, "olcsn__pesntcct"

    const-string v0, "connect_ssl_crt"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public static f(Landroid/content/Context;Ljava/util/Set;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "pdsehsr_qtua"

    const-string v0, "aht_psuesrdd"

    const/4 v2, 0x3

    const-string/jumbo v0, "stsehrpdd_ts"

    const-string v0, "http_address"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public static g(Landroid/content/Context;Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const-string/jumbo v0, "tenmtcnetpc_s"

    const-string v0, "cttecnapsetn_"

    const/4 v2, 0x7

    const-string/jumbo v0, "oeasotcetntcn"

    const-string v0, "connect_state"

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public static h(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "enoctbssq_vnc__"

    const-string/jumbo v0, "ns__voscqcet_nc"

    const/4 v3, 0x4

    const-string/jumbo v0, "n_vnc_uls_eccso"

    const-string v0, "connect_ssl_c_v"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return p0
.end method

.method public static i(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "oignclope_"

    const-string/jumbo v0, "login_code"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public static j(Landroid/content/Context;J)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "sqisreu"

    const-string v0, "disrseu"

    const/4 v2, 0x4

    const-string v0, "e_suisd"

    const-string/jumbo v0, "user_id"

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-interface {p0, v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public static k(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "mwpmrsoa"

    const-string v0, "assmrwpo"

    const/4 v2, 0x2

    const-string/jumbo v0, "rodpoaws"

    const-string/jumbo v0, "password"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public static l(Landroid/content/Context;Ljava/util/Set;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string v0, "adpe_brsots"

    const-string v0, "eas_ocrtpds"

    const/4 v2, 0x1

    const-string/jumbo v0, "td_spsuraec"

    const-string/jumbo v0, "tcp_address"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static m(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "register_code"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static n(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "eantoirprigtsdi"

    const-string/jumbo v0, "registration_id"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static o(Landroid/content/Context;Ljava/util/Set;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string v0, "_tdssblascers_p"

    const/4 v2, 0x3

    const-string/jumbo v0, "rsa_s_scqsdpldt"

    const-string/jumbo v0, "tcp_address_ssl"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public static p(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, "atsocsnneetcu"

    const-string v0, "_oecntuetancs"

    const/4 v3, 0x6

    const-string/jumbo v0, "naome_nccsttt"

    const-string v0, "connect_state"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    move v3, v2

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return p0
.end method

.method public static q(Landroid/content/Context;)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v3, 0x2

    const-string/jumbo v1, "tasrohpdste_"

    const-string/jumbo v1, "sdsthreptda_"

    const/4 v3, 0x5

    const-string/jumbo v1, "tdhtabdres_s"

    const-string v1, "http_address"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0
.end method

.method public static r(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "qiee_du"

    const-string v0, "dqedei_"

    const-string/jumbo v0, "ps_diee"

    const-string/jumbo v0, "seed_id"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public static s(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "aunes_rgqaelg"

    const-string v0, "aesserug_nlga"

    const/4 v2, 0x7

    const-string v0, "easnguealsugr"

    const-string/jumbo v0, "user_language"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public static t(Landroid/content/Context;Ljava/util/Set;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, "dummsd_raed"

    const-string v0, "ddumerss_da"

    const/4 v2, 0x4

    const-string v0, "durso_addsp"

    const-string/jumbo v0, "udp_address"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public static u(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "o_odgbeolc"

    const-string/jumbo v0, "ogodoecl_n"

    const/4 v3, 0x6

    const-string/jumbo v0, "loi_egucdo"

    const-string/jumbo v0, "login_code"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p0
.end method

.method public static v(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "avebsd_p_pclstsdrs_"

    const-string v0, "_rs_vblcassdpt_dse_"

    const/4 v2, 0x4

    const-string/jumbo v0, "tcsadspsq_sev_clrd_"

    const-string/jumbo v0, "tcp_address_ssl_c_v"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public static w(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "rpsaoduw"

    const-string v0, "dswapour"

    const/4 v3, 0x4

    const-string v0, "dwrmsasp"

    const-string/jumbo v0, "password"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0
.end method

.method public static x(Landroid/content/Context;)B
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "rpetotpastlo_a"

    const-string/jumbo v0, "tmpoelapatts_r"

    const/4 v3, 0x1

    const-string/jumbo v0, "ra_tobetsflmpa"

    const-string/jumbo v0, "platform_state"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    int-to-byte p0, p0

    const/4 v3, 0x1

    return p0
.end method

.method public static y(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "descoeuri_rtg"

    const-string/jumbo v0, "register_code"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return p0
.end method

.method public static z(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0}, Lo2/q;->C(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "qogsi_tptrernii"

    const-string/jumbo v0, "iitotseiq_drrgn"

    const/4 v3, 0x5

    const-string/jumbo v0, "ngitsoidq_ertir"

    const-string/jumbo v0, "registration_id"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-object p0
.end method
