.class public Lo2/y;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lo2/y;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p2, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method

.method public static a(Lorg/json/JSONObject;)Lo2/y;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o.sl4 /m ~oa@@~~b1u-@ ~@l @@  s@i@@@~~~~ ~bfb~ t@@@~~~@/o~i@K~n~ vo@~@o~fM  ~ Sry~id@  @~@t   ~c"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0}, Lo3/f;->k(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "egemv_dir_smsoi"

    const-string/jumbo v1, "sdsd_vom_gieier"

    const-string v1, "ddemos_iogervi_"

    const-string/jumbo v1, "override_msg_id"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lo2/y;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v1, v0, p0}, Lo2/y;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    return-object v1
.end method


# virtual methods
.method public b()Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v1, "mmisgb"

    const-string v1, "dsimmg"

    const/4 v4, 0x3

    const-string/jumbo v1, "u_dsmi"

    const-string/jumbo v1, "msg_id"

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lo2/y;->a:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const-string v1, "erosdvgpoirimd_"

    const-string v1, "dimeorre_vigsdo"

    const/4 v4, 0x0

    const-string/jumbo v1, "override_msg_id"

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    instance-of v0, p1, Lo2/y;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x3

    return v1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p1, Lo2/y;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lo2/y;->a:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v0, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget-object v0, p1, Lo2/y;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lo2/y;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p1, Lo2/y;->a:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v4, 0x5

    return v1

    :cond_2
    const/4 v3, 0x1

    move v4, v3

    iget-object v0, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v3, 0x7

    move v4, v3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p1, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return v2

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p1, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p1, Lo2/y;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    move v1, v2

    move v1, v2

    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    :cond_4
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const-string v1, "dbm=  i_q"

    const-string v1, "_mig b=d "

    const/4 v3, 0x3

    const-string v1, " gsis_ d="

    const-string/jumbo v1, "msg_id = "

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    iget-object v1, p0, Lo2/y;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    const-string v1, "de mv__r mrgsoei d ,i"

    const-string v1, "eg mdou r di__r ,esiv"

    const/4 v3, 0x2

    const-string v1, ",dsgooe_rmi =e_vi d r"

    const-string v1, ",  override_msg_id = "

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lo2/y;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method
