.class public Lo2/b0;
.super Ljava/lang/Object;


# static fields
.field public static a:Ljava/util/concurrent/ConcurrentLinkedQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentLinkedQueue<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    sput-object v0, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()I
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "  s.~bl~~aod n~@r~@@~~oi~v~ oi b4  @f@@~o M1if~ @@~@S @~c~ /~/@@tK@@  u@@t~~~ lb ~@-~~ myo~o@ @s"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->size()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v3, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/16 v4, 0xa

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-ge v2, v4, :cond_0

    const/4 v11, 0x3

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->offer(Ljava/lang/Object;)Z

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    return v3

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/util/AbstractQueue;->element()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    check-cast v2, Ljava/lang/Long;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    sub-long v5, v0, v5

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-wide/16 v7, 0x0

    const/4 v11, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    cmp-long v2, v5, v7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const-string v7, "BrsmsOeTeusoannstpi"

    const-string/jumbo v7, "sOseTpusionsrBiaten"

    const/4 v11, 0x2

    const-string/jumbo v7, "siMpososnTaeuOrBnie"

    const-string v7, "MTOperationBusiness"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-gez v2, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x7

    sget-object v0, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->clear()V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v0, " eretbtolamatis//irsetgaf asyf iu0lmaendh  aprar atcseff,ig s"

    const-string v0, "aoamidrrt  satfey0,auesfea eeclanh r/ a/rssgf tltatmiplfis ig"

    const/4 v11, 0x5

    const-string/jumbo v0, "s img0ula rtrll fseaifsheat aadu/t oeer  iyepfcf,raetanstgasi"

    const-string/jumbo v0, "set tags/alias failed, time shaft error\uff0cplease try again"

    const/4 v10, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v7, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    sget v0, Lj3/a$a;->l:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    return v0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-wide/16 v8, 0x2710

    const-wide/16 v8, 0x2710

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    cmp-long v2, v5, v8

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-lez v2, :cond_3

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->size()I

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-lt v2, v4, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->poll()Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    goto :goto_0

    :cond_2
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    sget-object v2, Lo2/b0;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->offer(Ljava/lang/Object;)Z

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    return v3

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string/jumbo v0, "veo1 0opn,ioni lsr   g /1tetoistsos ts oa0eas"

    const-string v0, " onoovl10 itsi 0as eos,eias tor /1ota ste gsn"

    const/4 v11, 0x3

    const-string v0, "e  /so gqosirleo0sts1aiv1en ,nis o0mtatt a  s"

    const-string/jumbo v0, "set tags/alias too soon, over 10 times in 10s"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v7, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    sget v0, Lj3/a$a;->l:I

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    return v0
.end method
