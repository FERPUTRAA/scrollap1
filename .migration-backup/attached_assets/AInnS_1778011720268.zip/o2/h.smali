.class public Lo2/h;
.super Ljava/lang/Object;


# static fields
.field public static volatile a:Lo2/h;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a()Lo2/h;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~su~~~ ~~ //@@@.y~~   @@vort@b@o 4K@ o~@~ @ ~o@M~@so~@~@iSi1o@b @~-cm~l~i~a~    f @ d@n~~f@~ tl"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lo2/h;->a:Lo2/h;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-class v0, Lo2/h;

    const-class v0, Lo2/h;

    const/4 v3, 0x4

    const-class v0, Lo2/h;

    const-class v0, Lo2/h;

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object v1, Lo2/h;->a:Lo2/h;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v1, Lo2/h;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1}, Lo2/h;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    sput-object v1, Lo2/h;->a:Lo2/h;

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lo2/h;->a:Lo2/h;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0
.end method


# virtual methods
.method public b(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 5

    const/4 v3, 0x4

    move v4, v3

    if-nez p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const-string p1, "eoamcyispfpkg_"

    const-string/jumbo p1, "ofsg_ip_ecykpa"

    const/4 v4, 0x2

    const-string p1, "eppfocn__iykga"

    const-string p1, "config_app_key"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "BMTsiboinsnmfuCe"

    const-string v1, "MsomgBesiCfunniT"

    const/4 v4, 0x7

    const-string v1, "CnsuBiuesiTMsngf"

    const-string v1, "MTConfigBusiness"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const-string/jumbo v2, "ypkpa:op"

    const-string/jumbo v2, "yaekopp:"

    const/4 v4, 0x2

    const-string/jumbo v2, "qeyk_p:a"

    const-string v2, "app_key:"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Ly2/b;->E(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x0

    const-string p1, "gesbaofnpiapn_cnl_"

    const-string/jumbo p1, "nieacb_ppon_nlgacf"

    const/4 v4, 0x4

    const-string p1, "gnnmoihap_lacf_epn"

    const-string p1, "config_app_channel"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v2, "_aeno:hpaluc"

    const-string v2, "_p:lhauenapc"

    const/4 v4, 0x7

    const-string v2, "h:nnabcple_p"

    const-string v2, "app_channel:"

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1}, Ly2/b;->D(Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x7

    const-string/jumbo p1, "o_pnituenfimcepsa_gp"

    const-string/jumbo p1, "sfgm__epiapont_ipnec"

    const/4 v4, 0x1

    const-string p1, "_osenifppem_pnia_ctg"

    const-string p1, "config_app_site_name"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "mapes:a_qpt_ni"

    const/4 v4, 0x6

    const-string v2, "e_anp_tmqsipe:"

    const-string v2, "app_site_name:"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1}, Ly2/b;->F(Ljava/lang/String;)V

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo p1, "s_snsifigscso"

    const-string p1, "_csogfsssinil"

    const/4 v4, 0x5

    const-string/jumbo p1, "sgomcn_l_sfsi"

    const-string p1, "config_is_ssl"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_4

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "is_lo:s"

    const-string/jumbo v2, "is_ssl:"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1}, Ly2/b;->Q(Z)V

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo p1, "odc_eb_mfimndgguo"

    const-string p1, "fedmimogn_b_ucgdo"

    const/4 v4, 0x1

    const-string/jumbo p1, "oeg_ouub_nddmeifg"

    const-string p1, "config_debug_mode"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Ly2/b;->I(Z)V

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "b_d:oouegdm"

    const/4 v4, 0x4

    const-string v0, ":ee_duopmdb"

    const-string v0, "debug_mode:"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method
