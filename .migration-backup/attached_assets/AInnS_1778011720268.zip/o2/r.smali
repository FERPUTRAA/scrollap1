.class public Lo2/r;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;[B)I
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "i s~~@f 4@d~  ~@b~@~M @l@ ~~~.~@~a to~@@K~ @ybf @~@@@~s~ ~  l~c u~ @S/omo@~ii~@-1/ @bnvo@o t ro~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    invoke-static {p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p0, v0}, Lo2/q;->i(Landroid/content/Context;I)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v1, "olemsorMTooPct"

    const-string v1, "PCsolTotMocoer"

    const/4 v7, 0x0

    const-string/jumbo v1, "toCrooPrcMeTlo"

    const-string v1, "MTCoreProtocol"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/16 v2, 0x6c

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eq v0, v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-static {p1}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v2, "feliob:d laiem ngd"

    const-string/jumbo v2, "ldemi d nfcloe:gia"

    const/4 v7, 0x2

    const-string v2, "a:eie u confldidlo"

    const-string/jumbo v2, "login failed code:"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo v2, "masse: peg"

    const-string v2, "aes o:esmg"

    const/4 v7, 0x0

    const-string/jumbo v2, "s,ame gsqe"

    const-string v2, ", message:"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p0, v2, v3}, Lo2/q;->j(Landroid/content/Context;J)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p0, p1}, Lo2/q;->n(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p0, p1}, Lo2/q;->k(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 p1, 0x0

    move v7, p1

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    invoke-static {p0, p1}, Lo2/q;->r(Landroid/content/Context;I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p0, v2, v3}, Lo2/q;->d(Landroid/content/Context;J)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string p0, " lsswdoil,eLnoarib neeilg-gFrir"

    const-string p0, ",so obnalrewgieir ie-gltniFdrLl"

    const/4 v7, 0x5

    const-string p0, "Ft ma,ie-lnwrLeriireig nlolesdg"

    const-string/jumbo p0, "onLoginFailed, will re-register"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p1}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    const/4 v7, 0x7

    invoke-static {p0, v2}, Lo2/q;->r(Landroid/content/Context;I)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    int-to-long v4, v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p0, v4, v5}, Lo2/q;->d(Landroid/content/Context;J)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string p1, "eeeuocsoc Id:ssduonSin"

    const-string p1, "cnud nucIeiedS:ogssose"

    const/4 v7, 0x6

    const-string p1, "cinodbegoceeLSI :nsdsu"

    const-string/jumbo p1, "onLoginSuccess seedId:"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const-string p1, "ei:rTvup,ser "

    const-string p1, "i:eer ,pTvesr"

    const/4 v7, 0x6

    const-string p1, "ei:mvr,p Tesr"

    const-string p1, ", serverTime:"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v1, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    return v0
.end method

.method public static b()Ljava/lang/String;
    .locals 11

    const/4 v10, 0x5

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, v0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    move v2, v1

    move v2, v1

    const/4 v10, 0x5

    move v2, v1

    move v2, v1

    :cond_0
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz v3, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    check-cast v3, Lc3/b;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v3}, Lc3/b;->i()Z

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez v4, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto :goto_0

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v3}, Lc3/b;->d()I

    move-result v3

    const/4 v9, 0x1

    move v10, v9

    if-ge v2, v3, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    move v2, v3

    move v2, v3

    const/4 v10, 0x3

    move v2, v3

    move v2, v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_0

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v3, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    move v4, v3

    const/4 v10, 0x7

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v9, 0x3

    move v10, v9

    if-gt v4, v2, :cond_6

    const/4 v9, 0x4

    move v10, v9

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v5, v5, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v5}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v6, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    check-cast v6, Lc3/b;

    const/4 v9, 0x6

    move v10, v9

    invoke-virtual {v6}, Lc3/b;->i()Z

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-nez v7, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_2

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6}, Lc3/b;->d()I

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eq v7, v4, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_2

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v6}, Lc3/b;->e()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v7, "/./"

    const-string v7, ".//"

    const/4 v10, 0x0

    const-string v7, "//."

    const-string v7, "\\."

    const/4 v10, 0x5

    const/4 v9, 0x2

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    aget-object v7, v6, v1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    shl-int/lit8 v7, v7, 0x10

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    aget-object v8, v6, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    shl-int/lit8 v8, v8, 0x8

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    add-int/2addr v7, v8

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v8, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    aget-object v6, v6, v8

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    const/4 v9, 0x0

    const/4 v10, 0x6

    add-int/2addr v7, v6

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    goto/16 :goto_2

    :cond_5
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_6
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-object v0
.end method

.method public static c(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "$$"

    const-string v1, "$$"

    const/4 v4, 0x1

    const-string v1, "$$"

    const-string v1, "$$"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Ly2/b;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lo2/r;->e()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p0}, Ld3/p;->d(Landroid/content/Context;)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p0}, Ld3/e;->n(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object p0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p0
.end method

.method public static d(Landroid/content/Context;[B)I
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p0, v0}, Lo2/q;->m(Landroid/content/Context;I)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v1, "roTPloCMqrqtoc"

    const-string v1, "TocPltCoqooMrr"

    const-string/jumbo v1, "rostPoMrCeTclo"

    const-string v1, "MTCoreProtocol"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    const/4 v7, 0x5

    invoke-static {p1}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v2, ":iemderes gciRoaFstdne"

    const-string v2, "elsdtoeF:rgRadseiie cn"

    const/4 v7, 0x6

    const-string v2, "ateFoeenodeRrcsgd:oili"

    const-string/jumbo v2, "onRegisterFailed code:"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const-string v2, ",mesmb:sg "

    const-string v2, ":e mm,gses"

    const/4 v7, 0x7

    const-string v2, ":mese,uga "

    const-string v2, ", message:"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v1, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p1}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p0, v2, v3}, Lo2/q;->j(Landroid/content/Context;J)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p0, p1}, Lo2/q;->n(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p0, v4}, Lo2/q;->k(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v5, "teseocspoc ieindguRuS:"

    const-string/jumbo v5, "us uoet:ingSsRseceicdo"

    const/4 v7, 0x4

    const-string/jumbo v5, "reei duRqS:coecstsinsg"

    const-string/jumbo v5, "onRegisterSuccess uid:"

    const/4 v7, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    invoke-virtual {p0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v2, "gistd,rntsi oeaIb"

    const-string v2, ",ednrbIo iasitgt:"

    const/4 v7, 0x6

    const-string/jumbo v2, "iiamrt:nsIgdtoe ,"

    const-string v2, ", registrationId:"

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo p1, "opsaou dr:,"

    const-string/jumbo p1, "wo draup:s,"

    const-string/jumbo p1, "oa,:wbs spd"

    const-string p1, ", password:"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v1, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    return v0
.end method

.method public static e()Ljava/lang/String;
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v0, v0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    move v2, v1

    move v2, v1

    const/4 v8, 0x0

    move v2, v1

    move v2, v1

    :cond_0
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v3, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x2

    check-cast v3, Lc3/b;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v3}, Lc3/b;->i()Z

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-nez v4, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v3}, Lc3/b;->d()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-ge v2, v3, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v2, v3

    move v2, v3

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    or-int/2addr v8, v7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    move v3, v1

    move v3, v1

    const/4 v8, 0x3

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-gt v3, v2, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v4, v4, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    const/4 v8, 0x7

    const/4 v7, 0x0

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v5, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    check-cast v5, Lc3/b;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v5}, Lc3/b;->i()Z

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-nez v6, :cond_3

    goto :goto_2

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v5}, Lc3/b;->d()I

    move-result v6

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eq v6, v3, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_2

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v5}, Lc3/b;->e()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v5, "|"

    const-string/jumbo v5, "|"

    const/4 v8, 0x0

    const-string/jumbo v5, "|"

    const-string/jumbo v5, "|"

    const/4 v8, 0x3

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_2

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_1

    :cond_6
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/lit8 v2, v2, -0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-object v0
.end method

.method public static f(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0}, Ly2/b;->o(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "0$$"

    const-string v1, "$0$"

    const-string v1, "$0$"

    const-string v1, "0$$"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string p0, " $$  $u $p$$"

    const-string p0, "  $$$$$p $$ "

    const-string p0, "$$ $$$ p$ $ "

    const-string p0, "$$ $$ $$ $$ "

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public static g()S
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, v0, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v2, v1

    move v2, v1

    const/4 v7, 0x1

    move v2, v1

    move v2, v1

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast v3, Lc3/b;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v3}, Lc3/b;->i()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez v4, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    invoke-virtual {v3}, Lc3/b;->d()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ge v2, v3, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    move v2, v3

    move v2, v3

    const/4 v7, 0x4

    move v2, v3

    move v2, v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v0, v1

    move v0, v1

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-gt v1, v2, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {}, Lc3/a;->b()Lc3/a;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v3, v3, Lc3/a;->a:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v3}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v4, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    check-cast v4, Lc3/b;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4}, Lc3/b;->i()Z

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-nez v5, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_2

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v4}, Lc3/b;->d()I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eq v5, v1, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_2

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v4}, Lc3/b;->b()S

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    or-int/2addr v0, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    int-to-short v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_2

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_6
    return v0
.end method

.method public static h(Landroid/content/Context;)[B
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p0, Lf3/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lf3/b;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lo2/r;->g()S

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lf3/b;->r(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lf3/b;->g()[B

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static i(Landroid/content/Context;)[B
    .locals 13

    const/4 v12, 0x4

    invoke-static {p0}, Lo2/q;->w(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-static {v0}, Ld3/o;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-static {}, Lo2/r;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {p0}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {}, Lo2/r;->g()S

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {p0}, Lo2/q;->x(Landroid/content/Context;)B

    move-result v4

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-static {}, Ly2/b;->w()I

    move-result v5

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-static {p0}, Lv2/a;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {p0}, Ly2/b;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v9, "i ug:i oqqdlhnt"

    const-string/jumbo v9, "luodnt gq :ihwi"

    const/4 v12, 0x4

    const-string v9, "hust id o:niwgl"

    const-string/jumbo v9, "login with uid:"

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {p0}, Lo2/q;->H(Landroid/content/Context;)J

    move-result-wide v9

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string v9, " :smrtitIieso,dgn"

    const-string/jumbo v9, "tgs,aIrsoti:edni "

    const/4 v12, 0x4

    const-string/jumbo v9, "iIdootrersg:an i,"

    const-string v9, ", registrationId:"

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-static {p0}, Lo2/q;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v8, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    const-string p0, "afm ,brl:tp"

    const-string p0, ", platform:"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v8, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v8, "ComTcluroeoPMr"

    const-string/jumbo v8, "oCcmrloPetoMTr"

    const/4 v12, 0x7

    const-string v8, "TcooorlpteroCP"

    const-string v8, "MTCoreProtocol"

    const/4 v12, 0x5

    const/4 v11, 0x5

    invoke-static {v8, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    const-string v6, ""

    const-string v6, ""

    const/4 v12, 0x2

    const-string v6, ""

    const-string v6, ""

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    move-result-object v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    const/4 v12, 0x6

    array-length v9, p0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x3

    add-int/lit8 v9, v9, 0x4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    array-length v10, v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    add-int/2addr v9, v10

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    array-length v10, v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    add-int/2addr v9, v10

    const/4 v11, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    add-int/lit8 v9, v9, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    add-int/lit8 v9, v9, 0x4

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    add-int/lit8 v9, v9, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    add-int/lit8 v9, v9, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    array-length v10, v2

    const/4 v12, 0x4

    add-int/2addr v9, v10

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    array-length v10, v8

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    add-int/2addr v9, v10

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    array-length v10, v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    add-int/2addr v9, v10

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    array-length v10, v6

    const/4 v12, 0x5

    add-int/2addr v9, v10

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    new-instance v10, Lf3/b;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-direct {v10, v9}, Lf3/b;-><init>(I)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/16 v9, 0x61

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {v10, v9}, Lf3/b;->r(I)V

    const/4 v11, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v9, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {v10, v9}, Lf3/b;->r(I)V

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v10, v9}, Lf3/b;->l(I)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v10, p0}, Lf3/b;->j([B)V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v10, v0}, Lf3/b;->j([B)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v10, v1}, Lf3/b;->j([B)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v10, v9}, Lf3/b;->r(I)V

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    int-to-long v0, v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v10, v0, v1}, Lf3/b;->n(J)V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v10, v4}, Lf3/b;->r(I)V

    const/4 v11, 0x4

    move v12, v11

    invoke-virtual {v10, v5}, Lf3/b;->r(I)V

    const/4 v12, 0x3

    invoke-virtual {v10, v2}, Lf3/b;->j([B)V

    const/4 v12, 0x0

    invoke-virtual {v10, v8}, Lf3/b;->j([B)V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v10, v7}, Lf3/b;->j([B)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v10, v6}, Lf3/b;->j([B)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v10}, Lf3/b;->g()[B

    move-result-object p0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    return-object p0
.end method

.method public static j(Landroid/content/Context;)[B
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p0, v0, v1}, Lo2/q;->j(Landroid/content/Context;J)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-static {p0, v2}, Lo2/q;->n(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p0, v2}, Lo2/q;->k(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p0, v3}, Lo2/q;->r(Landroid/content/Context;I)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p0, v0, v1}, Lo2/q;->d(Landroid/content/Context;J)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v1, "$$q$o "

    const-string v1, " $$$o$"

    const/4 v9, 0x5

    const-string v1, "$$s $$"

    const-string v1, " $$ $$"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v1, "$$"

    const-string v1, "$$"

    const/4 v9, 0x0

    const-string v1, "$$"

    const-string v1, "$$"

    const/4 v8, 0x3

    shl-int/2addr v9, v8

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    xor-int/2addr v9, v8

    invoke-static {p0}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p0}, Ly2/b;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p0}, Lo2/r;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p0}, Lo2/r;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {}, Lo2/r;->g()S

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const-string/jumbo v7, "tnimelceibgrtfh sIroe: tn"

    const-string v7, "eitttbeowfe lnc:gnIhi rsr"

    const/4 v9, 0x4

    const-string/jumbo v7, "ngroos Itre:l tfetnwiieci"

    const-string/jumbo v7, "register with clientInfo:"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v7, "cvInube fod,:"

    const-string v7, "eni f,u:Idvco"

    const/4 v9, 0x0

    const-string v7, "I:fne uioe,cd"

    const-string v7, ", deviceInfo:"

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string/jumbo v7, "opotoPcpMCelrT"

    const-string v7, "croPleopCTroMt"

    const/4 v9, 0x1

    const-string/jumbo v7, "reMPtoroqToolC"

    const-string v7, "MTCoreProtocol"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v7, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/String;->getBytes()[B

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    array-length v6, v0

    const/4 v9, 0x6

    array-length v7, v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    add-int/2addr v6, v7

    const/4 v8, 0x2

    const/4 v9, 0x0

    array-length v7, v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    add-int/2addr v6, v7

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    add-int/lit8 v6, v6, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    array-length v7, p0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/2addr v6, v7

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v6, v6, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x1

    array-length v7, v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/2addr v6, v7

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v7, Lf3/b;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v7, v6}, Lf3/b;-><init>(I)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v7, v0}, Lf3/b;->j([B)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v7, v1}, Lf3/b;->j([B)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v7, v4}, Lf3/b;->j([B)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {v7, v3}, Lf3/b;->r(I)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v7, p0}, Lf3/b;->j([B)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    int-to-long v0, v5

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v7, v0, v1}, Lf3/b;->n(J)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v7, v2}, Lf3/b;->j([B)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v7}, Lf3/b;->g()[B

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-object p0
.end method
