.class public Lo2/i;
.super Ljava/lang/Object;


# static fields
.field public static volatile d:Lo2/i;


# instance fields
.field public final a:Lo2/o;

.field public final b:Lo2/k;

.field public c:I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lo2/o;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lo2/o;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lo2/i;->a:Lo2/o;

    const/4 v2, 0x3

    invoke-static {}, Lo2/m;->a()Lo2/k;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lo2/i;->b:Lo2/k;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p0, Lo2/i;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public static a()Lo2/i;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~isS@  c@@ @- /4 @~o  @~@@ s@@~~ ~1~~v~~tf~o@dbf@o~yMa~K@o~u ol @~@. ~@io@~~@/n m b @@b~r  ~~~tl"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lo2/i;->d:Lo2/i;

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-class v0, Lo2/i;

    const-class v0, Lo2/i;

    const/4 v3, 0x4

    const-class v0, Lo2/i;

    const-class v0, Lo2/i;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v1, Lo2/i;->d:Lo2/i;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v1, Lo2/i;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1}, Lo2/i;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    sput-object v1, Lo2/i;->d:Lo2/i;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lo2/i;->d:Lo2/i;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method public b(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lo2/i;->c:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput v0, p0, Lo2/i;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const-string v1, "cdamlkFenoi :"

    const-string/jumbo v1, "onAckFailed :"

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    iget v1, p0, Lo2/i;->c:I

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "oTseoeMnuCtBnnsis"

    const-string/jumbo v1, "oisMssunnBeTCsnet"

    const/4 v3, 0x1

    const-string/jumbo v1, "snCnnbseMBcouesiT"

    const-string v1, "MTConnectBusiness"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v0, p0, Lo2/i;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    move v3, v2

    if-ge v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lo2/i;->k(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lo2/i;->i(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v0, p0, Lo2/i;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v0, 0xbb1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x2

    const/16 v0, 0xbb2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public c(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v0, "rolocpum"

    const-string/jumbo v0, "oormpclo"

    const/4 v7, 0x4

    const-string/jumbo v0, "ocrpotop"

    const-string/jumbo v0, "protocol"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const-string/jumbo v5, "keaAmodsqcm :unSsocon"

    const-string/jumbo v5, "odmkocsmcAeuaSsnno c:"

    const/4 v7, 0x1

    const-string/jumbo v5, "mksou cn:dneScAcosscm"

    const-string/jumbo v5, "onAckSuccess command:"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const-string v5, "esumb t:,"

    const-string/jumbo v5, "tu:e,bs r"

    const/4 v7, 0x6

    const-string/jumbo v5, "lr: o,tus"

    const-string v5, ", result:"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v1, ",oe :bd"

    const-string v1, ", code:"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v1, "reTue:ue,si m"

    const-string v1, "Terv eui:sem,"

    const/4 v7, 0x1

    const-string/jumbo v1, "s:rievep,Tmr "

    const-string v1, ", serverTime:"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v1, "eCnnBuMtqcsispnTe"

    const-string/jumbo v1, "nCnonecpieBsstTuM"

    const/4 v7, 0x4

    const-string/jumbo v1, "iMsseTtcoCBsnuenn"

    const-string v1, "MTConnectBusiness"

    const/4 v6, 0x2

    and-int/2addr v7, v6

    invoke-static {v1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 p2, 0x2

    const/4 v6, 0x5

    move v7, v6

    if-ne v0, p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo p2, "tsnmeotercSaueHabs"

    const-string/jumbo p2, "onHeartbeatSuccess"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1, p2}, Lb3/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 p2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput p2, p0, Lo2/i;->c:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/16 p2, 0x7d3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {p1, p2, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 p2, 0xbb5

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1, p2, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/16 p2, 0x8b9

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p1, p2, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method public d(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1, v1}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onConnectStatus(Landroid/content/Context;Z)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public e(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lo2/i;->b:Lo2/k;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Lo2/k;->d(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lo2/i;->b:Lo2/k;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lo2/k;->j()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public g(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, p1, v1}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onConnectStatus(Landroid/content/Context;Z)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public h(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lo2/q;->p(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "MTnnocuiBqseotses"

    const-string v1, "TusMecseqsinBCton"

    const/4 v3, 0x3

    const-string/jumbo v1, "uesCebnTssBotnciM"

    const-string v1, "MTConnectBusiness"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p1, "aiC tnueatt eesanlfcc/tr sna,sect c/s ostno"

    const-string p1, "eests Canto cco//cantst ,ln sanainr etcfest"

    const/4 v3, 0x6

    const-string/jumbo p1, "ona antpe/atsleotnstein c  sce,ta ntCrtsf/c"

    const-string p1, "connect state is false, can\'t startConnect"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "rnoseCnaqttm"

    const-string/jumbo v0, "tnnmroeatsCc"

    const/4 v3, 0x3

    const-string v0, "crstnnosCett"

    const-string/jumbo v0, "startConnect"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lo2/i;->a:Lo2/o;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lo2/o;->i(Landroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lo2/i;->b:Lo2/k;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lo2/k;->r(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public i(Landroid/content/Context;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string/jumbo v0, "tocmnMCesTusinoBn"

    const-string/jumbo v0, "noecotneissnBuCTM"

    const-string/jumbo v0, "ocBtoneTuisnMeCss"

    const-string v0, "MTConnectBusiness"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo v1, "trrbtbasateHbt"

    const-string/jumbo v1, "rtbHebtrettsaa"

    const/4 v9, 0x6

    const-string/jumbo v1, "sttteautHrbaar"

    const-string/jumbo v1, "startHeartbeat"

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    sget-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {}, Lh3/b;->c()J

    move-result-wide v6

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/16 v4, 0xbb0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v5, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static/range {v2 .. v7}, Lq2/a;->i(Landroid/content/Context;Ljava/lang/String;ILandroid/os/Bundle;J)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1}, Lo2/r;->h(Landroid/content/Context;)[B

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-instance v2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v9, 0x2

    invoke-direct {v2}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v3, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/4 v3, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1, v0}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    new-instance v1, Landroid/os/Bundle;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string/jumbo v2, "luporotp"

    const-string/jumbo v2, "ltoropuo"

    const/4 v9, 0x1

    const-string/jumbo v2, "qoopclor"

    const-string/jumbo v2, "protocol"

    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x5

    or-int/2addr v9, v8

    invoke-virtual {p0, p1, v1}, Lo2/i;->e(Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    return-void
.end method

.method public j(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "TMssCuepnoBesnics"

    const-string/jumbo v0, "ntiTssCpcnuMBesoe"

    const/4 v3, 0x7

    const-string/jumbo v0, "inCmennosssMcuBTt"

    const-string v0, "MTConnectBusiness"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "nqtcopnoeos"

    const-string/jumbo v1, "oCnostneqcp"

    const/4 v3, 0x3

    const-string/jumbo v1, "stopConnect"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lo2/i;->a:Lo2/o;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lo2/o;->l(Landroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lo2/i;->b:Lo2/k;

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lo2/k;->s(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public k(Landroid/content/Context;)V
    .locals 4

    const/4 v2, 0x1

    const-string/jumbo v0, "nCectbsBnuMsTensi"

    const-string/jumbo v0, "nssnTcsnusBCeiMte"

    const/4 v3, 0x0

    const-string v0, "MTConnectBusiness"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "srattbumteoep"

    const-string v1, "aaemetsbrtopt"

    const/4 v3, 0x6

    const-string v1, "arpteHtpbtaes"

    const-string/jumbo v1, "stopHeartbeat"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v0, Le3/a;->a:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/16 v1, 0xbb0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->g(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public l(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "MsCtosnBeesTnonic"

    const/4 v3, 0x6

    const-string v0, "CceuiBosqnenMTssn"

    const-string v0, "MTConnectBusiness"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v1, "unsfteftorbCnc"

    const-string v1, "fcfntbuoetnCrn"

    const/4 v3, 0x1

    const-string/jumbo v1, "tofmnufrcnenCO"

    const-string/jumbo v1, "turnOffConnect"

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lo2/q;->g(Landroid/content/Context;Z)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 v0, 0xbb1

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public m(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "osnBoseucieuTstnC"

    const-string/jumbo v0, "ncsnMtuBCeTusseio"

    const/4 v3, 0x6

    const-string v0, "MsutebTCcBesnsoni"

    const-string v0, "MTConnectBusiness"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const-string v1, "cOuoCpunnernt"

    const-string/jumbo v1, "nnnOourpcCnet"

    const/4 v3, 0x7

    const-string v1, "ConunetpnctnO"

    const-string/jumbo v1, "turnOnConnect"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lo2/q;->g(Landroid/content/Context;Z)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v0, 0xbb2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
