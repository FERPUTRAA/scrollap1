.class public Lo2/n$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljavax/net/ssl/X509TrustManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/n$a$a;
    }
.end annotation


# instance fields
.field public a:Ljavax/net/ssl/X509TrustManager;

.field public b:Ljava/security/cert/X509Certificate;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/cert/CertificateException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v0, "0ss5X"

    const-string v0, "9Xs50"

    const/4 v5, 0x7

    const-string v0, "X5.m0"

    const-string v0, "X.509"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    check-cast p1, Ljava/security/cert/X509Certificate;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    const/4 v5, 0x6

    iput-object p1, p0, Lo2/n$a;->b:Ljava/security/cert/X509Certificate;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Ljava/security/KeyStore$TrustedCertificateEntry;

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Ljava/security/KeyStore$TrustedCertificateEntry;-><init>(Ljava/security/cert/Certificate;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {}, Ljava/security/KeyStore;->getDefaultType()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/security/KeyStore;->getInstance(Ljava/lang/String;)Ljava/security/KeyStore;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v1, v1}, Ljava/security/KeyStore;->load(Ljava/io/InputStream;[C)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v2, "oo_moac"

    const-string v2, "_tcmooa"

    const/4 v5, 0x2

    const-string v2, "cooa_br"

    const-string v2, "ca_root"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1, v2, v0, v1}, Ljava/security/KeyStore;->setEntry(Ljava/lang/String;Ljava/security/KeyStore$Entry;Ljava/security/KeyStore$ProtectionParameter;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Ljavax/net/ssl/TrustManagerFactory;->getDefaultAlgorithm()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-static {v0}, Ljavax/net/ssl/TrustManagerFactory;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/TrustManagerFactory;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Ljavax/net/ssl/TrustManagerFactory;->init(Ljava/security/KeyStore;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljavax/net/ssl/TrustManagerFactory;->getTrustManagers()[Ljavax/net/ssl/TrustManager;

    move-result-object p1

    const/4 v4, 0x3

    move v5, v4

    array-length v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ge v1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    aget-object v2, p1, v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    instance-of v3, v2, Ljavax/net/ssl/X509TrustManager;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v2, Ljavax/net/ssl/X509TrustManager;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object v2, p0, Lo2/n$a;->a:Ljavax/net/ssl/X509TrustManager;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const-string/jumbo v1, "ilfateunorrgr n Mtsa,r:rueideti "

    const-string/jumbo v1, "init trustManager failed, error:"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v1, "tnLsMSrpoaguSer"

    const-string/jumbo v1, "uTneoSgStrLraMs"

    const/4 v5, 0x7

    const-string v1, "earsSgSLqTrtMun"

    const-string v1, "SSLTrustManager"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v0, Lo2/n$a$a;

    const/4 v5, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "tMs LSieb iuanaStrs gr:"

    const-string v2, "SaiSMbenu nritrag Ls: t"

    const/4 v5, 0x5

    const-string v2, "genmSiarais:rLttM  T Su"

    const-string v2, "SSLTrustManager init : "

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v0, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    throw v0
.end method


# virtual methods
.method public checkClientTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/cert/CertificateException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~nb~o~@@  o l4oo~bi a~f@MS@if~b /~@u~~vKo~d @ct@  r@~ is~ -@l tym~@@/~.~~ o~ @ ~~1 @~o@@~~@@@@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const-string/jumbo v0, "raganbuuLTterMs"

    const-string/jumbo v0, "sgnuMauatTSerLr"

    const/4 v3, 0x3

    const-string v0, "TMrSuSutsaagenr"

    const-string v0, "SSLTrustManager"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "dieeCctpshTkurepnt"

    const-string/jumbo v1, "uedTeklphCnesttric"

    const-string/jumbo v1, "lstkudeeqnCheTccir"

    const-string v1, "checkClientTrusted"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lo2/n$a;->a:Ljavax/net/ssl/X509TrustManager;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0, p1, p2}, Ljavax/net/ssl/X509TrustManager;->checkClientTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public checkServerTrusted([Ljava/security/cert/X509Certificate;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/cert/CertificateException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string p2, "hqskreudevcrcTstre"

    const-string/jumbo p2, "rSedcreequvthcrkTs"

    const/4 v5, 0x0

    const-string p2, "TrSmdkscreeuctervh"

    const-string p2, "checkServerTrusted"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v0, "tTugoaSMLrnares"

    const-string v0, "SSLTrustManager"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz p1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    array-length p2, p1

    const/4 v5, 0x2

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    move v5, v4

    const/4 p2, 0x6

    const/4 p2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    aget-object v1, p1, p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    array-length v1, p1

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-ge p2, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-object v2, p1, p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/security/cert/X509Certificate;->checkValidity()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v3, p0, Lo2/n$a;->b:Ljava/security/cert/X509Certificate;

    const/4 v5, 0x5

    invoke-virtual {v3}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;)V
    :try_end_0
    .catch Ljava/security/cert/CertificateExpiredException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/security/cert/CertificateNotYetValidException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/security/InvalidKeyException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/security/SignatureException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/security/NoSuchProviderException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/lit8 p2, p2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v1, "sTuocbdcnrh:oEiSruver dptxehrkoSeeviee:PNcts:"

    const-string/jumbo v1, "rrsc:ouhdichdcete:SPoiSexeNsnp vveoutkerrr:ET"

    const/4 v5, 0x3

    const-string v1, "::ureEuincieddSo PecvehcxcttorveTsrSoperkN:ru"

    const-string v1, ":checkServerTrusted: NoSuchProviderException:"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const-string/jumbo v1, "vtimeEopdhuPSorr:oNepcxn"

    const-string v1, ":oumNvSrieEhrxnePoticpdo"

    const/4 v5, 0x3

    const-string v1, "hvotiScNqeprPe:riudEcxoo"

    const-string v1, "NoSuchProviderException:"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    throw p2

    :catch_1
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "pxseau iecS:tkeecnoSvTrorrhnrtdciuE:ges:"

    const-string/jumbo v1, "tr eos:evtpcruhcg::eTxcdaeriSeSukeiEonnr"

    const/4 v5, 0x7

    const-string v1, "SiamrhdextoEecg::srnct:kceeurSerTvp utie"

    const-string v1, ":checkServerTrusted: SignatureException:"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v1, "acEtoieeiutpo:Sbnxg"

    const-string/jumbo v1, "xnEptbtiaegcuSorei:"

    const/4 v5, 0x6

    const-string v1, "ateinbtSgoueExrncp:"

    const-string v1, "SignatureException:"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw p2

    :catch_2
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, ":ucnveud ilTxuicyIeeEocrdrea:eSpketsKrnv:"

    const-string v1, "Er epeuiksrvduKveIcStaolex:ti:c:drTcnenye"

    const/4 v5, 0x1

    const-string/jumbo v1, "ytKnelrpeS:ccirdsevxkoedvtIa:pcee:uhrinTE"

    const-string v1, ":checkServerTrusted: InvalidKeyException:"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v1, "ixtevaEpqieIlnKodync"

    const-string/jumbo v1, "vciIptepalxnKenEyodi"

    const/4 v5, 0x6

    const-string v1, "KaspldnvE:Icoietexni"

    const-string v1, "InvalidKeyException:"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw p2

    :catch_3
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const-string/jumbo v1, "xnrmSegeih:tcodEke::uuvopetlrrccehrqoTNcm tAiS"

    const-string/jumbo v1, "rnreke:rq:ihoTgtivlctmpuordcSeA c:uxcthohSeNeE"

    const/4 v5, 0x2

    const-string v1, ":checkServerTrusted: NoSuchAlgorithmException:"

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const-string v1, "hstpoNocEicltoAxmnhurigoe"

    const-string/jumbo v1, "trsoeuNoio:pnlhEAthcmgicx"

    const/4 v5, 0x4

    const-string v1, "gxE:cbomhrAinSthoitNlcepo"

    const-string v1, "NoSuchAlgorithmException:"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    throw p2

    :catch_4
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v1, "ToisSeuitiprevNEcncdmtrehrfa:uYlxo e:rteee:tttekVCacc"

    const-string/jumbo v1, "lftmperNat ue:ihteStcrervoEinctxc:eCoeteVkYcddeis:Tra"

    const/4 v5, 0x4

    const-string v1, "c:eectNpvlSenTYtdraedpxtsoCaoVtereeiurkiit fctheiEr:c"

    const-string v1, ":checkServerTrusted: CertificateNotYetValidException:"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "dooafittqo:lieiNpntaVeetcExtCYer"

    const-string v1, "aixtoontrEeVaoeilCe:eNidftYcpttc"

    const-string v1, "CertificateNotYetValidException:"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    throw p2

    :catch_5
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "xad:tb:eveeorE eTe:iCckcprdursxricentfeceEpriStit"

    const/4 v5, 0x3

    const-string v1, "ecsiexhieirdkttenrp aSC:oc:evrxs:upeeicrrETEtfedc"

    const-string v1, ":checkServerTrusted: CertificateExpiredException:"

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance p2, Lo2/n$a$a;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "pipmtdEtaie:fxreCciorEcxutni"

    const-string v1, "ECentiuetxpiorrdf:eEciitxpac"

    const/4 v5, 0x5

    const-string v1, "Encxoitfi:piroiCtarepdtexEce"

    const-string v1, "CertificateExpiredException:"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p2, p1}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    throw p2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p1, Lo2/n$a$a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const-string p2, "aerh bSri ce tx9vesp5ekmC0rftetcyeips "

    const-string p2, "atvrS5ep scstekCr0tf ciyhe9 eixepCr me"

    const/4 v5, 0x7

    const-string p2, "aiexrructC eimsehet ikcr5fy ts09Cpev S"

    const-string p2, "Check Server x509Certificates is empty"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Lo2/n$a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    throw p1
.end method

.method public getAcceptedIssuers()[Ljava/security/cert/X509Certificate;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "asMSrngprqeatSu"

    const-string v0, "MgarTarSqnestSu"

    const/4 v3, 0x6

    const-string v0, "TgtnSaarqLMursS"

    const-string v0, "SSLTrustManager"

    const/4 v2, 0x6

    or-int/2addr v3, v2

    const-string/jumbo v1, "tusrpegesesAIccest"

    const-string v1, "eAsseeutcpsrgcstIe"

    const/4 v3, 0x0

    const-string v1, "eutmrtcIAcedpsgses"

    const-string v1, "getAcceptedIssuers"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lo2/n$a;->a:Ljavax/net/ssl/X509TrustManager;

    const/4 v3, 0x3

    invoke-interface {v0}, Ljavax/net/ssl/X509TrustManager;->getAcceptedIssuers()[Ljava/security/cert/X509Certificate;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method
