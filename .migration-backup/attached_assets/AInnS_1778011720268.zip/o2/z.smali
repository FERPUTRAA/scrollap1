.class public Lo2/z;
.super Lo2/v;


# static fields
.field public static volatile f:Lo2/z;


# instance fields
.field public final b:Ljava/util/concurrent/ConcurrentMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentMap<",
            "Ljava/lang/Long;",
            "Lcom/engagelab/privates/push/api/PlatformTokenMessage;",
            ">;"
        }
    .end annotation
.end field

.field public c:Z

.field public final d:Ljava/util/concurrent/ConcurrentMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentMap<",
            "Ljava/lang/Byte;",
            "Lcom/engagelab/privates/push/api/PlatformTokenMessage;",
            ">;"
        }
    .end annotation
.end field

.field public e:Landroid/os/Bundle;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lo2/v;-><init>()V

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x3

    iput-object v0, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-boolean v0, p0, Lo2/z;->c:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lo2/z;->d:Ljava/util/concurrent/ConcurrentMap;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " /soyi~ a@ ~@~~@@ 1 ~@o@ ~  ~/ @@~.v~s@t~ft@  o@i4MSo@b@d~~-~~cf~@uobK~~@~ ~ @lnl~ib@ ~~o@ r @ @"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const-string/jumbo v0, "imemrPsaMTBsussntl"

    const-string/jumbo v0, "ussnTaBePmrtlisfsM"

    const/4 v6, 0x4

    const-string/jumbo v0, "rtPooBsmneTssiflMu"

    const-string v0, "MTPlatformBusiness"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x1

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-class v3, Ljava/lang/String;

    const/4 v6, 0x3

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-object v3, v2, v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x7

    aput-object p0, v1, v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v3, "PmSipbsoydtir.sdoeeertsoram"

    const-string/jumbo v3, "permitadSionosssrPoem.yrted"

    const/4 v6, 0x0

    const-string/jumbo v3, "sy.penumsodii.ratSdsrooerPt"

    const-string v3, "android.os.SystemProperties"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v4, "get"

    const-string v4, "get"

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3, v4, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x1

    move v6, v5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const-string v3, " tge"

    const-string v3, "g et"

    const/4 v6, 0x3

    const-string v3, " get"

    const-string v3, "get "

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v3, ":inv oopiesr"

    const-string/jumbo v3, "rnevo: iisos"

    const/4 v6, 0x6

    const-string/jumbo v3, "ve r soiqsni"

    const-string v3, " version is:"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v3, "e sg "

    const-string v3, "b ge "

    const/4 v6, 0x3

    const-string v3, "eg m "

    const-string v3, " get "

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string p0, ":w oorrrnor e"

    const-string p0, " wrong error:"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-static {v0, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object p0
.end method

.method public static k()Lo2/z;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lo2/z;->f:Lo2/z;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-class v0, Lo2/z;

    const-class v0, Lo2/z;

    const/4 v3, 0x4

    const-class v0, Lo2/z;

    const-class v0, Lo2/z;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v1, Lo2/z;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v1}, Lo2/z;-><init>()V

    const/4 v3, 0x7

    sput-object v1, Lo2/z;->f:Lo2/z;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    move v3, v2

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lo2/z;->f:Lo2/z;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method

.method public static q()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "bnrivbisomelu.uoe.di."

    const-string/jumbo v0, "mnebidu.iseuiorl.vo.u"

    const/4 v3, 0x6

    const-string v0, "i.l.orunerdm.ouviusbi"

    const-string/jumbo v0, "ro.build.version.emui"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lo2/z;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "pcigmpa"

    const-string/jumbo v1, "pgicima"

    const/4 v3, 0x4

    const-string v1, "cqmiiga"

    const-string/jumbo v1, "magicui"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "gascomi"

    const-string v1, "aqogmic"

    const/4 v3, 0x7

    const-string/jumbo v1, "isgmamc"

    const-string/jumbo v1, "magicos"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0
.end method


# virtual methods
.method public final A(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v0, "oppo"

    const-string/jumbo v0, "oppo"

    const/4 v8, 0x7

    const-string/jumbo v0, "poop"

    const-string/jumbo v0, "oppo"

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v0, "eresol"

    const-string/jumbo v0, "lesear"

    const/4 v8, 0x1

    const-string/jumbo v0, "lemreb"

    const-string/jumbo v0, "realme"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo v0, "mlpuenu"

    const-string/jumbo v0, "penmslu"

    const/4 v8, 0x7

    const-string/jumbo v0, "pouplen"

    const-string/jumbo v0, "oneplus"

    const/4 v8, 0x0

    const/4 v7, 0x4

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez p2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string p2, "a.ivc.leqa.ospot.ohMOe.erganmpptomlspp.ppfgroaou"

    const-string/jumbo p2, "omeuo.lsooOtvrca.Tooa.pp.amnslgiepg.ep.rMppphatf"

    const/4 v8, 0x5

    const-string p2, "cosa.s..spm.atmnioguolelbMr.tpapvppeopopfeOrg.ha"

    const-string p2, "com.engagelab.privates.push.platform.oppo.MTOppo"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x2

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    check-cast p2, Lc3/b;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_0

    :catchall_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo p2, "tTimmsuMBslboeasPf"

    const-string p2, "BmfMTbniPuslasotse"

    const/4 v8, 0x6

    const-string p2, "TsisotmnsuMelrPaBf"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v0, "etptibaoeu.dra pgronnoa"

    const-string/jumbo v0, "npat eurtogpioan redo.a"

    const/4 v8, 0x4

    const-string v0, ".rapa uoropnogett eanit"

    const-string/jumbo v0, "not integrated oppo.aar"

    const/4 v8, 0x0

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v3, 0x4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v4, 0xbb9

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x7

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method

.method public final B(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo v0, "vvio"

    const-string/jumbo v0, "ivvo"

    const/4 v8, 0x5

    const-string/jumbo v0, "voiv"

    const-string/jumbo v0, "vivo"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-nez p2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string p2, "aplo.afpoapebsViavh.l.ovgpMisteT.rrvm.ouvgmci.tp"

    const-string/jumbo p2, "opve.aapsucivhlsTmi.vi.ntoVe..vflbg.grmrtoappoaM"

    const/4 v8, 0x4

    const-string/jumbo p2, "omMgui.mqpaoeoare.forphcilt.elbi.sgnasv.vvtap.VT"

    const-string p2, "com.engagelab.privates.push.platform.vivo.MTVivo"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    check-cast p2, Lc3/b;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_0

    :catchall_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo p2, "ntsmPrMfauoilBqses"

    const-string p2, "MlnsBisfqTutmaoPre"

    const/4 v8, 0x1

    const-string p2, "euMmsfsPornBtaTilm"

    const-string p2, "MTPlatformBusiness"

    const/4 v7, 0x1

    shr-int/2addr v8, v7

    const-string/jumbo v0, "rtiioaneedgaavsvot.t no"

    const-string v0, "ans.radeogtvatev  itino"

    const/4 v8, 0x1

    const-string v0, " vd .bavinetogtitoaaern"

    const-string/jumbo v0, "not integrated vivo.aar"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v3, 0x5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v4, 0xbb9

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x1

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void
.end method

.method public final d(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sparse-switch v0, :sswitch_data_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto/16 :goto_0

    :sswitch_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v0, "iuzmu"

    const-string/jumbo v0, "mizmu"

    const-string/jumbo v0, "zepum"

    const-string/jumbo v0, "meizu"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/16 v1, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto/16 :goto_0

    :sswitch_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v0, "horqo"

    const-string/jumbo v0, "rhooo"

    const/4 v3, 0x2

    const-string/jumbo v0, "oosnr"

    const-string v0, "honor"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    goto/16 :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto/16 :goto_0

    :sswitch_2
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v0, "viov"

    const-string/jumbo v0, "ivvo"

    const/4 v3, 0x4

    const-string/jumbo v0, "vivo"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    move v3, v2

    goto/16 :goto_0

    :sswitch_3
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v0, "oopp"

    const/4 v3, 0x4

    const-string/jumbo v0, "oppo"

    const-string/jumbo v0, "oppo"

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p2, :cond_3

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_4
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v0, "xmbmii"

    const-string/jumbo v0, "iximab"

    const/4 v3, 0x2

    const-string v0, "aomioi"

    const-string/jumbo v0, "xiaomi"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x2

    and-int/2addr v3, v2

    if-nez p2, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto/16 :goto_0

    :sswitch_5
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "lreaeb"

    const-string/jumbo v0, "realme"

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez p2, :cond_5

    const/4 v3, 0x0

    goto :goto_0

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :sswitch_6
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "uiaeuh"

    const-string/jumbo v0, "uuheia"

    const/4 v3, 0x6

    const-string v0, "epauih"

    const-string v0, "huawei"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-nez p2, :cond_6

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_6
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :sswitch_7
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "oqpnelp"

    const-string/jumbo v0, "pplnoes"

    const/4 v3, 0x4

    const-string/jumbo v0, "pnsuoel"

    const-string/jumbo v0, "oneplus"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p2, :cond_7

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_7
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :sswitch_8
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "krqmlckasb"

    const-string/jumbo v0, "rlsakacbqk"

    const-string v0, "blackshark"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p2, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_8
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const-string/jumbo p2, "pourorbsooln..omeo.dirip"

    const-string/jumbo p2, "ro.build.version.opporom"

    const/4 v3, 0x7

    packed-switch v1, :pswitch_data_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :pswitch_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo p2, "mryeobsinfdovr.is.e"

    const-string/jumbo p2, "ofsdii..eernmvyor.s"

    const/4 v3, 0x5

    const-string p2, "eioiy.unrsmfl.eov.d"

    const-string/jumbo p2, "ro.flyme.version.id"

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :pswitch_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p2, "rivesudpo.bmi.lrgoncam"

    const-string/jumbo p2, "os.migraublo.iemdricvn"

    const-string p2, "euicoingqsvoar.dibrm.l"

    const-string/jumbo p2, "ro.build.version.magic"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p1

    :pswitch_2
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p2, ".dsrss.io.aiivubo..poyldilo"

    const-string p2, ".dioovrodi.s..bdio.ylaiulps"

    const/4 v3, 0x3

    const-string/jumbo p2, "su.mldl..pvyii..doiosrviodb"

    const-string/jumbo p2, "ro.vivo.os.build.display.id"

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1

    :pswitch_3
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :pswitch_4
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo p2, "voaro..e.ui.niienmsmiub"

    const-string/jumbo p2, "oavimbs.i.nenu..uiiorme"

    const/4 v3, 0x2

    const-string p2, ".ovr.b.auinesuinerom.ii"

    const-string/jumbo p2, "ro.miui.ui.version.name"

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    return-object p1

    :pswitch_5
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string p2, "edrslou.ln.ebruvoirmia.ie"

    const/4 v3, 0x4

    const-string/jumbo p2, "ro.build.version.realmeui"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1

    :pswitch_6
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo p2, "p.elbiu.rvdinuoume.so"

    const-string p2, "eobmv.ip.suor.luedini"

    const-string/jumbo p2, "o.ori.upsdv.eblieinmu"

    const-string/jumbo p2, "ro.build.version.emui"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_9

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p2, "ecq_h.roqi.bpssd.olatmiunlrv"

    const-string/jumbo p2, "ohusedvbqs.nrpmtrl.ci.l_iaof"

    const/4 v3, 0x2

    const-string p2, "bssfns..heml.iwlcpdiouotrv_a"

    const-string p2, "hw_sc.build.platform.version"

    const/4 v2, 0x4

    and-int/2addr v3, v2

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_9
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p2

    :pswitch_7
    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "nm.moioro.rrse"

    const-string/jumbo v0, "ro.rom.version"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p1, v0}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_a

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p1

    :cond_a
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :pswitch_8
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo p2, "svdyoueo..cirijr.suni.eo"

    const-string p2, "cuseisynirue.ivr.oo.doj."

    const/4 v3, 0x0

    const-string/jumbo p2, "oovuyb.ioe.nj.i.esrucrio"

    const-string/jumbo p2, "ro.joyui.ui.version.code"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lo2/z;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p1

    :sswitch_data_0
    .sparse-switch
        -0x608d18ba -> :sswitch_8
        -0x4eb36700 -> :sswitch_7
        -0x47e95e19 -> :sswitch_6
        -0x37ba884a -> :sswitch_5
        -0x2d450b45 -> :sswitch_4
        0x3427a0 -> :sswitch_3
        0x373cac -> :sswitch_2
        0x5edac6a -> :sswitch_1
        0x62f84cc -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public f(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x3

    const-string/jumbo v0, "i_nincutnp_cn totecde"

    const-string v0, " dnmietc_tcieontncn_p"

    const/4 v10, 0x5

    const-string v0, " pn_citpnetndeco_nito"

    const-string/jumbo v0, "on_tcp_connected init"

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v1, "eBtPmTonqualsMrsif"

    const-string v1, "MTPlatformBusiness"

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {p1}, Lo2/e;->d(Landroid/content/Context;)I

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    move v10, v9

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string/jumbo v3, "osstlmarF"

    const-string/jumbo v3, "moaFostrl"

    const/4 v10, 0x2

    const-string/jumbo v3, "lsom:rmtF"

    const-string/jumbo v3, "lastFrom:"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v1, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    if-lez v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {p1}, Lo2/e;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-nez v2, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string v2, "_"

    const-string v2, "_"

    const-string v2, "_"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    aget-object v2, v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v2}, Ljava/lang/Byte;->parseByte(Ljava/lang/String;)B

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    aget-object v2, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v6

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v2, 0x2

    const/4 v10, 0x5

    aget-object v0, v0, v2

    const/4 v9, 0x6

    move v10, v9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string v2, "fPaoominf rdtetlt mrpsl=boialta"

    const-string v2, " fpmrbfNaatilPtloomstr=nd iealt"

    const/4 v10, 0x0

    const-string/jumbo v2, "srd nbem oaafo=lttlmapliiNroftt"

    const-string/jumbo v2, "init lastPlatformNode platform="

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string/jumbo v2, "ud= cu"

    const-string/jumbo v2, "ud =ec"

    const/4 v10, 0x5

    const-string v2, "epc=od"

    const-string v2, " code="

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string/jumbo v2, "qcemo_ ="

    const-string v2, " m_code="

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v8, ""

    const/4 v10, 0x7

    const-string v8, ""

    const-string v8, ""

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-virtual/range {v3 .. v8}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-static {p1, v0}, Lo2/e;->c(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    move v10, v9

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string/jumbo v3, "mFs aefal todilp"

    const-string/jumbo v3, "ia flaFplm oesdt"

    const/4 v10, 0x0

    const-string v3, " ofm atdllrFimse"

    const-string/jumbo v3, "lastFrom failed "

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eqz v2, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-void

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {p1}, Ly2/b;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string v4, "atqfornasceri m "

    const-string/jumbo v4, "ti crfn qmraasue"

    const/4 v10, 0x1

    const-string/jumbo v4, "rnumebsuicraa  f"

    const-string/jumbo v4, "manufacturer is "

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const-string v4, ":dsyreuou nC,c"

    const-string/jumbo v4, "t:sydcCoren,u "

    const/4 v10, 0x6

    const-string v4, ", countryCode:"

    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p0, p1}, Lo2/z;->l(Landroid/content/Context;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    invoke-virtual {p0, p1, v2}, Lo2/z;->s(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p0, p1, v0}, Lo2/z;->v(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p0, p1, v0}, Lo2/z;->x(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p0, p1, v0}, Lo2/z;->y(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p0, p1, v0}, Lo2/z;->p(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0, p1, v0}, Lo2/z;->z(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p0, p1, v0}, Lo2/z;->A(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    invoke-virtual {p0, p1, v0}, Lo2/z;->B(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object v0, p0, Lo2/z;->e:Landroid/os/Bundle;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/16 v1, 0xc1d

    const/4 v9, 0x4

    move v10, v9

    invoke-static {p1, v1, v0}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    return-void
.end method

.method public final g(Landroid/content/Context;BIILjava/lang/String;)V
    .locals 10

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {p1}, Lh3/b;->j(Landroid/content/Context;)B

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {p1}, Ly2/b;->k(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    sget-object v2, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    sget-object v3, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    sget-object v4, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p0, p1, v3}, Lo2/z;->d(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x4

    new-instance v6, Lorg/json/JSONObject;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v7, "aftlrmop"

    const-string/jumbo v7, "mtlmaofr"

    const/4 v9, 0x5

    const-string/jumbo v7, "qalptfro"

    const-string/jumbo v7, "platform"

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {v6, v7, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo p2, "ocde"

    const-string p2, "cdoe"

    const/4 v9, 0x6

    const-string p2, "dceo"

    const-string p2, "code"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v6, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string p2, "eos_mc"

    const-string/jumbo p2, "mcd_oe"

    const/4 v9, 0x1

    const-string/jumbo p2, "m_code"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v6, p2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string p2, "_lmmgb"

    const-string/jumbo p2, "lg_mfb"

    const/4 v9, 0x0

    const-string p2, "g_floa"

    const-string/jumbo p2, "m_flag"

    const/4 v9, 0x5

    invoke-virtual {v6, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo p2, "konetmu"

    const/4 v9, 0x3

    const-string/jumbo p2, "notmkb_"

    const-string/jumbo p2, "m_token"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v6, p2, p5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-string/jumbo p2, "tpyoc_uodcnr"

    const-string/jumbo p2, "tonodrypc_uc"

    const/4 v9, 0x6

    const-string/jumbo p2, "noocy_rpcdtu"

    const-string p2, "country_code"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v6, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x7

    move v9, v8

    const-string/jumbo p2, "product"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6, p2, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x7

    const-string/jumbo p2, "utauqamnqrfc"

    const-string/jumbo p2, "rcrnfautqmau"

    const/4 v9, 0x1

    const-string/jumbo p2, "ntsfuaecmarr"

    const-string/jumbo p2, "manufacturer"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v6, p2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string/jumbo p2, "stsmmen_orysve"

    const-string p2, "evsomisnr_sety"

    const/4 v9, 0x2

    const-string/jumbo p2, "svsoomn_tyeesi"

    const-string/jumbo p2, "system_version"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v6, p2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string/jumbo p2, "rsitebeymm__ssvn"

    const-string/jumbo p2, "m_system_version"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v6, p2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    new-instance p2, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {p2}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string p3, "domlftupremno"

    const-string/jumbo p3, "tnlmraedmofop"

    const/4 v9, 0x7

    const-string/jumbo p3, "lod_orppemfna"

    const-string/jumbo p3, "platform_node"

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance p3, Landroid/os/Bundle;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo p4, "qpootlcr"

    const-string/jumbo p4, "lcotopor"

    const/4 v9, 0x1

    const-string/jumbo p4, "rpsotoco"

    const-string/jumbo p4, "protocol"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p3, p4, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/16 p2, 0x8b9

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    shr-int/2addr v9, v8

    const-string p3, "fefmbp aodlPNrdreloeomr ai"

    const-string p3, "flrNebdirafaeelo o odprPtm"

    const/4 v9, 0x7

    const-string/jumbo p3, "rfPeoNoltrlaom doeteai rpd"

    const-string/jumbo p3, "reportPlatformNode failed "

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string/jumbo p2, "rfBsubsMoteanPiTsu"

    const-string/jumbo p2, "tfieaTuMmBnossuPrs"

    const/4 v9, 0x1

    const-string/jumbo p2, "sPusnsuMlBoitaTfme"

    const-string p2, "MTPlatformBusiness"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-void
.end method

.method public final h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lo2/z;->d:Ljava/util/concurrent/ConcurrentMap;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p3, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lo2/z;->d:Ljava/util/concurrent/ConcurrentMap;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    if-eqz p3, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance p3, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x6

    move v4, v3

    const-string/jumbo v0, "ppsmaes"

    const-string/jumbo v0, "pgssema"

    const/4 v4, 0x2

    const-string/jumbo v0, "message"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p3, v0, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const-string/jumbo p2, "qeiprs_oqs_nneitet"

    const-string/jumbo p2, "tiet_ensqopirnise_"

    const/4 v4, 0x4

    const-string/jumbo p2, "is_repetition_send"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p3, p2, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object p2, Li3/a;->a:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Lo2/z$a;

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, p0, p1, p3}, Lo2/z$a;-><init>(Lo2/z;Landroid/content/Context;Landroid/os/Bundle;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v4, 0x7

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, p2, v0, v1, v2}, Lq2/a;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;J)V

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string p3, "cesmoTamkt  alesohf:nh T,pttarn roaeoolckfp"

    const/4 v4, 0x4

    const-string p3, ",ms Tch:enlrkoaTcpp oamehnfoosntr t tkfaalo"

    const-string p3, "cache not has platformToken, platformToken:"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string p2, "fsTmiolBssrmPnMuea"

    const-string p2, "foTmsBlrsaensMuiPt"

    const/4 v4, 0x6

    const-string/jumbo p2, "mriMoslsesoPaunBtT"

    const-string p2, "MTPlatformBusiness"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p2, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public final i(Lcom/engagelab/privates/push/api/PlatformTokenMessage;Landroid/os/Bundle;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lo2/z;->d:Ljava/util/concurrent/ConcurrentMap;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v0, "nrto_bspie_eseniti"

    const-string/jumbo v0, "is_repetition_send"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p2, :cond_1

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    move v4, v3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v0, "oke_etunspedo:npeTiRsotot_rtnee iiins"

    const-string/jumbo v0, "nep_oTi_ensoiteeR ikespdt:seiiotrotnn"

    const/4 v4, 0x6

    const-string v0, "_pteninporisTtitsne_dte eik:neseiopiR"

    const-string/jumbo v0, "isRepetitionToken is_repetition_send:"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo p2, "sltBfMrPquoesmbTsi"

    const-string p2, "fousabeltPsTmrsBMi"

    const/4 v4, 0x3

    const-string/jumbo p2, "mtsflsBPaTMieosuns"

    const-string p2, "MTPlatformBusiness"

    const/4 v4, 0x7

    invoke-static {p2, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p2, p0, Lo2/z;->d:Ljava/util/concurrent/ConcurrentMap;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-interface {p2, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return v1
.end method

.method public final j(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v0, "poPrSruseos.iemasdtnidoer.y"

    const/4 v5, 0x4

    const-string/jumbo v0, "sepmPdny.Smsdoe.striertoaoi"

    const-string v0, "android.os.SystemProperties"

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-array v1, v0, [Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x5

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v2, v1, v3

    const/4 v4, 0x1

    move v5, v4

    const-string/jumbo v2, "tge"

    const-string v2, "gte"

    const/4 v5, 0x0

    const-string v2, "get"

    const-string v2, "get"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, v2, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x6

    aput-object p2, v0, v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast p1, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const-string v0, "gaPsopVtfrrdeiee guilotrintelepS"

    const-string v0, "eitnuerpa rPplSlitasgeefdoegitVr"

    const/4 v5, 0x5

    const-string/jumbo v0, "sgdt baeeVefPlapgtSiiroiereltrnu"

    const-string v0, "getPropertiesStringValue failed "

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo p2, "meofBtulqiTsusPnar"

    const-string/jumbo p2, "suTtasMBqnfeorPmli"

    const-string/jumbo p2, "toMsfmupTBelssaniP"

    const-string p2, "MTPlatformBusiness"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v5, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p1
.end method

.method public final l(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v1, 0x1a

    const/4 v4, 0x1

    if-ge v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v0, "cafioistqint"

    const-string/jumbo v0, "tistnaocfini"

    const/4 v4, 0x6

    const-string v0, "cfsiotoinina"

    const-string/jumbo v0, "notification"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast p1, Landroid/app/NotificationManager;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "uTemmvstiMrPa_"

    const-string v0, "aePm_MiPvTtusr"

    const/4 v4, 0x4

    const-string v0, "MTPush_Private"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1, v0}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x7

    const-string v1, "faiootcNtini"

    const/4 v4, 0x2

    const-string/jumbo v1, "otanotiicfNo"

    const-string v1, "Notification"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1, v0}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public m(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 13

    const-string v0, "_"

    const-string v0, "_"

    const-string v0, "_"

    const-string v0, "_"

    const-string v1, "Frm tbrb=urno"

    const-string v1, "F=otubme rrrn"

    const-string/jumbo v1, "r=Fcrmu ontur"

    const-string v1, " currentFrom="

    const-string/jumbo v2, "snPleftpsBouTsmraM"

    const-string v2, "MTPlatformBusiness"

    :try_start_0
    const-string/jumbo v3, "qlfutpmr"

    const-string v3, "alrmpfut"

    const-string/jumbo v3, "platform"

    invoke-virtual {p2, v3}, Landroid/os/Bundle;->getByte(Ljava/lang/String;)B

    move-result v6

    const-string v3, "edoc"

    const-string v3, "code"

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v7

    const-string/jumbo v3, "pmsed"

    const-string/jumbo v3, "moped"

    const-string/jumbo v3, "mCode"

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v8

    const-string/jumbo v3, "ypte"

    const-string/jumbo v3, "yept"

    const-string/jumbo v3, "peyt"

    const-string/jumbo v3, "type"

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v3

    const-string/jumbo v4, "morf"

    const-string v4, "from"

    const-string/jumbo v4, "ofmr"

    const-string v4, "from"

    invoke-virtual {p2, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    invoke-static {p1, v6}, Lo2/c;->k(Landroid/content/Context;B)Ljava/lang/String;

    move-result-object v9

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "pPomq=rNonolortmfmt lafd"

    const-string/jumbo v5, "tll Nfotqfrmo=poePdaonmr"

    const-string/jumbo v5, "onPlatformNode platform="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "sed oo"

    const-string v5, "d s=oe"

    const-string v5, "co deb"

    const-string v5, " code="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "dmm _oue"

    const-string v5, "eocm d_m"

    const-string v5, "co_d emp"

    const-string v5, " m_code="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "qeo= mno"

    const-string/jumbo v5, "o=Tnoe m"

    const-string v5, "e sokmT="

    const-string v5, " mToken="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "b=pmey"

    const-string/jumbo v5, "tyep=b"

    const-string v5, "=y toe"

    const-string v5, " type="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v4, 0xf3c

    const-string v10, ""

    const-string v10, ""

    const-string v10, ""

    const-string v10, ""

    const/4 v11, 0x0

    if-ne v4, v3, :cond_1

    :try_start_1
    invoke-static {p1}, Lo2/e;->d(Landroid/content/Context;)I

    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    xor-int v4, v3, p2

    const/4 v5, 0x3

    const-string/jumbo v12, "toF=absrm "

    const-string v12, " lastFrom="

    if-ne v4, v5, :cond_0

    :try_start_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "oemtaiun oTobo iuakndhanFl, oldFeo mr=et"

    const-string v5, "bo ohaumednr nTaedalnF iooFtktliol=,m oe"

    const-string/jumbo v5, "oalnoeopk= lrrmhoei lF domob iTdeFatnan,"

    const-string/jumbo v5, "onTokenFailed, all method obtain orFrom="

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v2, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0xbbd

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    invoke-virtual/range {v4 .. v9}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    invoke-static {p1, v11}, Lo2/e;->b(Landroid/content/Context;I)V

    invoke-static {p1, v10}, Lo2/e;->c(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    invoke-static {p1, p2}, Lo2/e;->b(Landroid/content/Context;I)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lo2/e;->c(Landroid/content/Context;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "e,doFrnphnmeee mono,ik=Toorlted ti naao bF"

    const-string/jumbo v0, "o boirroqT nmkntide= o,l,nFe mhoFonaoedtae"

    const-string/jumbo v0, "oneTokenFailed, one method obtain, orFrom="

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    invoke-virtual/range {v4 .. v9}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    const/16 p2, 0xf3d

    if-ne p2, v3, :cond_2

    invoke-static {p1, v11}, Lo2/e;->b(Landroid/content/Context;I)V

    invoke-static {p1, v10}, Lo2/e;->c(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "NPsdotdea lreofriqflaoemrt"

    const-string v0, "addfreo qftlNeatroilemrpPo"

    const-string v0, "doamtffPe eaNirorlreomptdl"

    const-string/jumbo v0, "reportPlatformNode failed "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public n(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-boolean p1, p0, Lo2/z;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public o(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-string/jumbo v0, "lcotoosr"

    const-string/jumbo v0, "rcspolto"

    const/4 v11, 0x5

    const-string/jumbo v0, "topolbor"

    const-string/jumbo v0, "protocol"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v11, 0x3

    const/4 v10, 0x3

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object p2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-interface {p2, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-nez p2, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x2

    return-void

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object p2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-interface {p2, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    check-cast p2, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-object v2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-interface {v2, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const-string/jumbo v3, "r iPfnuloid:,kndTemeaFoatlo"

    const-string/jumbo v3, "onPlatformTokenFailed, rid:"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const-string v0, ",on rmTpelkfpmo:"

    const-string/jumbo v0, "lTom fr:,enmtpko"

    const/4 v11, 0x6

    const-string/jumbo v0, "r,tamnoTqo: kpfe"

    const-string v0, ", platformToken:"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string v1, "aisTMrsPsBosfmounl"

    const-string/jumbo v1, "nslPosoMTisrmuBatf"

    const/4 v11, 0x4

    const-string v1, "esfmlaBrMPiTmoussn"

    const-string v1, "MTPlatformBusiness"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {p1, v6}, Lo2/c;->k(Landroid/content/Context;B)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {v9, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v2, 0x1

    const/4 v11, 0x4

    if-eqz v0, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v0, "eaano te stptmtrblon o peaddu"

    const-string/jumbo v0, "tl adbp otdnetmofpraaes uetn "

    const/4 v11, 0x5

    const-string/jumbo v0, "tapetbnaelsupom r otdadtne f "

    const-string/jumbo v0, "no need update platform state"

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-static {v1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/16 v7, 0xbbe

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v8, 0x0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual/range {v4 .. v9}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p0, p1, p2, v2}, Lo2/z;->h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    return-void

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {p1}, Lh3/b;->j(Landroid/content/Context;)B

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    or-int/2addr v0, v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    int-to-byte v0, v0

    const/4 v10, 0x0

    const/4 v10, 0x7

    const/16 v3, 0x8

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-ne v6, v3, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    and-int/lit16 v0, v0, 0xdf

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto :goto_0

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    or-int/lit16 v0, v0, 0x80

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    int-to-byte v0, v0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v10, 0x3

    const-string/jumbo v4, "otmteuupfeats  al:r"

    const-string v4, "eetraoufaplttsm :t "

    const/4 v11, 0x3

    const-string/jumbo v4, "p smreapaefsottt:tl"

    const-string/jumbo v4, "set platform state:"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {v1, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    shr-int/2addr v11, v10

    invoke-static {p1, v0}, Lh3/b;->x(Landroid/content/Context;B)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/16 v7, 0xbbe

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v11, 0x1

    move v10, v8

    move v10, v8

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    invoke-virtual/range {v4 .. v9}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p0, p1, p2, v2}, Lo2/z;->h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    return-void
.end method

.method public final p(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo v0, "maqpoi"

    const-string/jumbo v0, "ipoaim"

    const/4 v8, 0x7

    const-string/jumbo v0, "oisiax"

    const-string/jumbo v0, "xiaomi"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v0, "cbamashkkq"

    const-string/jumbo v0, "kacshrbkqa"

    const/4 v8, 0x5

    const-string/jumbo v0, "klhkoasabc"

    const-string v0, "blackshark"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez p2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string p2, "hriafbmlm.toipveaTeplsubb.laamgMsg.lo..lMosbc..paGgorlain"

    const-string/jumbo p2, "ogs.eipoM..GarTesiallMfopalrmm.alh..gbacpugslvtoieb.ablmn"

    const/4 v8, 0x7

    const-string p2, "com.engagelab.privates.push.platform.mi.global.MTMiGlobal"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    check-cast p2, Lc3/b;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :catchall_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string p2, "essPmBulminfTautor"

    const-string/jumbo p2, "ssrmtseamloTnuPfiB"

    const/4 v8, 0x5

    const-string/jumbo p2, "oituBmspsMrsenlfaT"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v0, " aa o orqntrldemtnaog.leibta"

    const-string/jumbo v0, "ronloeagm gdir laet b.onaatt"

    const/4 v8, 0x7

    const-string/jumbo v0, "nis regoaal.i gnt dtltaoebar"

    const-string/jumbo v0, "not integrated global mi.aar"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v3, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/16 v4, 0xbb9

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v5, 0x0

    const/4 v8, 0x7

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x3

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    return-void
.end method

.method public r(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 13

    const-string/jumbo v0, "obomtrpl"

    const-string/jumbo v0, "pocrtblo"

    const-string/jumbo v0, "lptroooo"

    const-string/jumbo v0, "protocol"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v0

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v6

    iget-object p2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-interface {p2, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    const-string/jumbo v2, "tao,lb PoFfniT:nlurredidoak"

    const-string/jumbo v2, "odiarmuirnenlafolTodktFP: ,"

    const-string v2, "TFoefiunor dt,lkardo:Paemil"

    const-string/jumbo v2, "onPlatformTokenFailed, rid:"

    const-string v3, "elnmPsippraftBuTso"

    const-string/jumbo v3, "somTsiaprfnultPsBe"

    const-string v3, "PaMeTuriqftslnBsms"

    const-string v3, "MTPlatformBusiness"

    if-nez p2, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo p2, "nisrrneeorrta  q"

    const-string p2, " tneairrq,er nro"

    const-string/jumbo p2, "lermri,n  rtaneo"

    const-string p2, ", internal error"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    iget-object p2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-interface {p2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    iget-object v4, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v9

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v12

    if-eqz v6, :cond_1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, " de,oc:"

    const-string v0, "ces:, d"

    const-string/jumbo v0, "oc:d,b "

    const-string v0, ", code:"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v5, 0xbbe

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move v4, v9

    move v4, v9

    move v4, v9

    move v4, v9

    move-object v7, v12

    move-object v7, v12

    move-object v7, v12

    move-object v7, v12

    invoke-virtual/range {v2 .. v7}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lo2/z;->h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V

    return-void

    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "mo lieusoesfrcrndknTaoc,uPS:"

    const-string/jumbo v4, "onPlatformTokenSuccess, rid:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "leop:map moTnf,t"

    const-string v0, "em:m ftlpkoTon,a"

    const-string v0, ", platformToken:"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v3, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p1, v9}, Lo2/c;->k(Landroid/content/Context;B)Ljava/lang/String;

    move-result-object p2

    invoke-static {v12, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_2

    const-string/jumbo p2, "p reledaqotunant epe mast tod"

    const-string/jumbo p2, "na eoaettumooenlart pt d sdep"

    const-string p2, " rstutnpeea tnamepsl ooftdaed"

    const-string/jumbo p2, "no need update platform state"

    invoke-static {v3, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v10, 0xbbf

    const/4 v11, 0x0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    invoke-virtual/range {v7 .. v12}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    return-void

    :cond_2
    invoke-static {p1, v9, v12}, Lo2/c;->d(Landroid/content/Context;BLjava/lang/String;)V

    invoke-static {p1}, Lh3/b;->j(Landroid/content/Context;)B

    move-result p2

    or-int/2addr p2, v9

    int-to-byte p2, p2

    const/16 v0, 0x8

    if-ne v9, v0, :cond_3

    or-int/lit8 p2, p2, 0x20

    goto :goto_0

    :cond_3
    and-int/lit8 p2, p2, 0x7f

    :goto_0
    int-to-byte p2, p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " btmeptfelmt raos:a"

    const-string v1, " :etlbfrtpateaoms t"

    const-string/jumbo v1, "ltetors:o faeastt p"

    const-string/jumbo v1, "set platform state:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p1, p2}, Lh3/b;->x(Landroid/content/Context;B)V

    const/16 v10, 0xbbf

    const/4 v11, 0x0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    invoke-virtual/range {v7 .. v12}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    return-void
.end method

.method public final s(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v0, "NC"

    const-string v0, "CN"

    const/4 v8, 0x0

    const-string v0, "NC"

    const-string v0, "CN"

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x0

    if-eqz p2, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string/jumbo p2, "l3.b"

    const-string p2, "3.bl"

    const/4 v8, 0x2

    const-string/jumbo p2, "l.3b"

    const-string/jumbo p2, "l3.b"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast p2, Lc3/b;

    const/4 v8, 0x6

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo p2, "issmaouetsTBluMPnr"

    const/4 v8, 0x2

    const-string p2, "auiMsbfsmloBPTstre"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x5

    const-string/jumbo v0, "ogteapu.laio a grdreetgto"

    const-string v0, "e.idao pgotgntraloree gta"

    const/4 v8, 0x0

    const-string v0, "glg dnrpaeitoraotoet ea.g"

    const-string/jumbo v0, "not integrated google.aar"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/16 v3, 0x8

    const/4 v8, 0x6

    const/16 v4, 0xbb9

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x4

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v7, 0x3

    move v8, v7

    return-void
.end method

.method public final t(Landroid/content/Context;)Z
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string/jumbo v0, "lnrosTtfqmiasPMsuB"

    const-string v0, "MTPlatformBusiness"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string v2, ".hsiun.daqcpioh.mspr_ph"

    const-string/jumbo v2, "iphooph.qcsarmi..n_hdpu"

    const/4 v9, 0x4

    const-string v2, "com.hihonor.push.app_id"

    const/4 v9, 0x4

    invoke-static {p1, v2}, Ly2/b;->s(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    if-eqz v2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string p1, " pamuuhor nr Iinhooptptpsyss,e td  s ropooph"

    const-string p1, " psuIp ht oyrsrospi rt  hnpdeopahun osm,otpo"

    const/4 v9, 0x5

    const-string/jumbo p1, "ys oonpnppr rt t,d  rm hpIapiphsouoeouo stnh"

    const-string/jumbo p1, "not support honor push, honor appId is empty"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    return v1

    :cond_0
    const/4 v9, 0x6

    const-string v2, ".hhtPbmhn.eruodCclkisoosom.snh.ipuHn"

    const-string/jumbo v2, "rkpm.stnihoChodnmouohHlussr.e.nPhic."

    const/4 v9, 0x5

    const-string v2, "h.hncsuoHnCrosmtrshkeiinou.uph.ld.oP"

    const-string v2, "com.hihonor.push.sdk.HonorPushClient"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v3, "eganescpotn"

    const-string/jumbo v3, "tnenoIgeasc"

    const/4 v9, 0x0

    const-string/jumbo v3, "ntgceInaqse"

    const-string v3, "getInstance"

    :try_start_1
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-array v4, v1, [Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v3, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v4, "kesnbHctpcSosrrPhouup"

    const-string/jumbo v4, "tkHSobuhnspcerpcouPor"

    const/4 v9, 0x4

    const-string v4, "checkSupportHonorPush"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v5, 0x1

    :try_start_2
    const/4 v9, 0x6

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v9, 0x3

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    aput-object v7, v6, v1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v3, v4, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-array v4, v5, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    aput-object p1, v4, v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v3, ":unmhera bavlloai"

    const-string v3, "a: liauv bronahle"

    const/4 v9, 0x4

    const-string/jumbo v3, "lolno:rabev ohi a"

    const-string v3, "honor available :"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v3, "hoHoeb Sspo:ruuirpsopPnrt"

    const-string/jumbo v3, "rouotoepnpSsoPirrup Hrh:s"

    const-string v3, " rtouou:oueShssirprrHnPop"

    const-string/jumbo v3, "isSupportHonorPush error:"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    xor-int/2addr v9, v8

    return v1
.end method

.method public u(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v0, "pmseeag"

    const-string v0, "gqeaesm"

    const-string v0, "eqmsasg"

    const-string/jumbo v0, "message"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-nez v1, :cond_1

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1, v3, v2}, Lo2/c;->d(Landroid/content/Context;BLjava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    move v6, v5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v4, "nessTknoraiMso:ec"

    const-string/jumbo v4, "oesiaeT:Mrnssncko"

    const/4 v6, 0x2

    const-string v4, ":oamiskpceTnnreso"

    const-string/jumbo v4, "processMainToken:"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v3, "PMauoTsnsBmoefmltr"

    const-string/jumbo v3, "mtrmfMoPuielBasnsT"

    const/4 v6, 0x7

    const-string/jumbo v3, "tTrimbensMuosBflsa"

    const-string v3, "MTPlatformBusiness"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v3, v2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, p1, v0}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onPlatformToken(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/16 v0, 0xf8b

    const/4 v6, 0x5

    invoke-static {p1, v0, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-void
.end method

.method public final v(Landroid/content/Context;Ljava/lang/String;)V
    .locals 10

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string/jumbo v0, "ueiuoh"

    const-string v0, "aihuoe"

    const/4 v9, 0x2

    const-string v0, "epawuh"

    const-string v0, "huawei"

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string v1, "MsrsenBoqmTbltPsua"

    const-string v1, "aoTlsbBmrsMPuntsfe"

    const/4 v9, 0x7

    const-string v1, "TssPntBlMomussaeif"

    const-string v1, "MTPlatformBusiness"

    const/4 v9, 0x3

    const/4 v8, 0x3

    if-nez v0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v0, "rhumn"

    const-string/jumbo v0, "ruhno"

    const/4 v9, 0x0

    const-string/jumbo v0, "rooho"

    const-string v0, "honor"

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v9, 0x6

    const/4 v8, 0x4

    if-eqz p2, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0, p1}, Lo2/z;->t(Landroid/content/Context;)Z

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-nez p2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {}, Lo2/z;->q()Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz p2, :cond_0

    const/4 v8, 0x0

    or-int/2addr v9, v8

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo p1, "witp b eeoatetunrgnh"

    const-string p1, "eghw onpti nieeurtta"

    const-string p1, "g oatnuiuhweieert an"

    const-string/jumbo p1, "not integrate huawei"

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string/jumbo p2, "pe.Muvippahuigwbmeea...eahu.Htwrgo.ricpTsfesaqlmotnl"

    const-string p2, "ach...vsqTi.etab.MgueariprewwgnpHfeum.ltsuoiaopaemlh"

    const/4 v9, 0x6

    const-string p2, "h.paeoM.qiafsl..rlpsh.gtawi.rTieepwbmutcnHueaeugavma"

    const-string p2, "com.engagelab.privates.push.platform.huawei.MTHuawei"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    check-cast p2, Lc3/b;

    const/4 v8, 0x6

    const/4 v8, 0x3

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto :goto_1

    :catchall_0
    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string p2, "assraana er idt.owtineeut"

    const-string/jumbo p2, "tas. nawturetaoiih eednar"

    const/4 v9, 0x1

    const-string p2, " eemta.arrugdnwathntoi ai"

    const-string/jumbo p2, "not integrated huawei.aar"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v1, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v4, 0x5

    const/4 v9, 0x6

    const/4 v4, 0x2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/16 v5, 0xbb9

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v6, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v7, ""

    const-string v7, ""

    const/4 v9, 0x0

    const-string v7, ""

    const-string v7, ""

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual/range {v2 .. v7}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-void
.end method

.method public w(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-class v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const-class v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v6, 0x4

    const-class v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const-class v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v0, "gemmoes"

    const-string/jumbo v0, "sgemmea"

    const/4 v6, 0x5

    const-string/jumbo v0, "sesagbe"

    const-string/jumbo v0, "message"

    const/4 v6, 0x0

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    check-cast v0, Lcom/engagelab/privates/push/api/PlatformTokenMessage;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-boolean v1, p0, Lo2/z;->c:Z

    const/4 v6, 0x1

    const-string/jumbo v2, "oortsnuTulfBiMeasP"

    const-string v2, "asTuoMBfsiPtnorlse"

    const/4 v6, 0x1

    const-string v2, "MTPlatformBusiness"

    const/4 v6, 0x7

    if-nez v1, :cond_0

    const/4 v6, 0x0

    const/4 p2, 0x1

    const/4 v6, 0x4

    move v5, p2

    move v5, p2

    const/4 v6, 0x6

    invoke-virtual {p0, p1, v0, p2}, Lo2/z;->h(Landroid/content/Context;Lcom/engagelab/privates/push/api/PlatformTokenMessage;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string p2, " pftkTfpn pf:as omiisrtpdmloon  okerosannb,gertolTt"

    const-string/jumbo p2, "opnnnbl skToooo nf skaeoritlim ttmegfrTfa:erp,tp ds"

    const/4 v6, 0x5

    const-string p2, "fT: rmpTqtklnfsrot ttLiepfik rdooenno samo,ge losan"

    const-string/jumbo p2, "stop send platformToken Login first, platformToken:"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0, v0, p2}, Lo2/z;->i(Lcom/engagelab/privates/push/api/PlatformTokenMessage;Landroid/os/Bundle;)Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz p2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo p2, "ltst :kfttoprnasrennkti,Tumemepof Tinoao so epdeol"

    const-string p2, "afo  nuroropdtmeetfep,oni:iet notselTtmpTkospnak l"

    const/4 v6, 0x6

    const-string p2, " kmmsoltt:Tnfeo,datietoplnofinp enptm raseTr opero"

    const-string/jumbo p2, "stop send repetition platformToken, platformToken:"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-void

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Lh3/b;->m()J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object p2, p0, Lo2/z;->b:Ljava/util/concurrent/ConcurrentMap;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {p2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v1, "dedmrtnploe,  :afpkorTis"

    const-string/jumbo v1, "rmdtod:np ifsa eekTlo,nr"

    const-string/jumbo v1, "send platformToken, rid:"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v1, "q:olmbtTeonr ,ka"

    const-string/jumbo v1, "om, rt:nqkTpeola"

    const/4 v6, 0x5

    const-string/jumbo v1, "om:foTuepla kn,r"

    const-string v1, ", platformToken:"

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2, p2}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->a()B

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/engagelab/privates/push/api/PlatformTokenMessage;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p2, v1, v0}, Lo2/g;->a(BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v0, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v6, 0x6

    invoke-direct {v0}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v3, v4}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/16 v1, 0x1b

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x2

    move v6, v1

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, p2}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object v0, Li3/a;->a:Ljava/lang/String;

    const/4 v6, 0x2

    invoke-virtual {p2, v0}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v1, "rocoopsp"

    const-string/jumbo v1, "oosotrpc"

    const/4 v6, 0x4

    const-string/jumbo v1, "qorptlco"

    const-string/jumbo v1, "protocol"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/16 p2, 0x8ae

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1, p2, v0}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    const/4 v6, 0x6

    return-void
.end method

.method public final x(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v0, "ooshm"

    const-string v0, "hromo"

    const/4 v8, 0x6

    const-string v0, "hnomo"

    const-string v0, "honor"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-nez p2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string/jumbo p2, "lsaeonogmorpoa..mbrnousropo.Htarpn.hlafeiht.veMc.g"

    const-string p2, "com.engagelab.privates.push.platform.honor.MTHonor"

    const/4 v8, 0x6

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast p2, Lc3/b;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string/jumbo p2, "sresMbBaotmPiulfos"

    const-string p2, "anMiomrelsftBPusos"

    const/4 v8, 0x6

    const-string p2, "BslnrPutassmfeiuMT"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v0, "rartn epdoraogo.tnib eha"

    const-string/jumbo v0, "rtn gbronti aeetaao.drho"

    const/4 v8, 0x1

    const-string v0, ".orrtt nqnedgaohrtoa ina"

    const-string/jumbo v0, "not integrated honor.aar"

    const/4 v8, 0x0

    const/4 v7, 0x4

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v3, 0x7

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/16 v4, 0xbb9

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-void
.end method

.method public final y(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x6

    const-string/jumbo v0, "xisaiu"

    const-string/jumbo v0, "uxamii"

    const-string/jumbo v0, "iaimmo"

    const-string/jumbo v0, "xiaomi"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo v0, "rhkaolcskb"

    const-string v0, "blackshark"

    const/4 v8, 0x3

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-nez p2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string/jumbo p2, "rpesfbaasv.gmihmnmogMerlp.pibo.a.ecu.tTta.pi"

    const-string p2, "asrsfgnpigme.mepct.e.bprlMhaou...mipaitvaToM"

    const/4 v8, 0x4

    const-string p2, "com.engagelab.privates.push.platform.mi.MTMi"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    check-cast p2, Lc3/b;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_0

    :catchall_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo p2, "lnessruafBmMosuPti"

    const-string/jumbo p2, "iMfraPBmqosslutsen"

    const/4 v8, 0x4

    const-string p2, "aePfussplMsrtToniB"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v0, "easient aomtr. rgadtn"

    const-string/jumbo v0, "ream .irqotaennitgdta"

    const-string/jumbo v0, "not integrated mi.aar"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/16 v4, 0xbb9

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x7

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-void
.end method

.method public final z(Landroid/content/Context;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v0, "emsmz"

    const-string/jumbo v0, "muemz"

    const/4 v8, 0x6

    const-string v0, "euimm"

    const-string/jumbo v0, "meizu"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez p2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo p2, "o.ieoaMmeztaigprhp.Mruapfeaoeu.bign.levu.zclsTt.ms"

    const-string p2, "com.engagelab.privates.push.platform.meizu.MTMeizu"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x0

    move v8, v7

    check-cast p2, Lc3/b;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {p1, p2}, Lq2/a;->d(Landroid/content/Context;Lc3/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_0

    :catchall_0
    const/4 v8, 0x1

    const-string/jumbo p2, "rsfPibsTtmoasuMBeo"

    const-string/jumbo p2, "sPMmouiortsfeBansT"

    const/4 v8, 0x5

    const-string/jumbo p2, "nMaPsrusTmfBleotiu"

    const-string p2, "MTPlatformBusiness"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const-string v0, "dnat orpezbergutiaei .nm"

    const-string/jumbo v0, "rioaabgnade t uznme.itre"

    const/4 v8, 0x3

    const-string/jumbo v0, "naridraeqgmzout  at.iten"

    const-string/jumbo v0, "not integrated meizu.aar"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {p2, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v3, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/16 v4, 0xbb9

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v5, 0x0

    const/4 v8, 0x1

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Lo2/z;->g(Landroid/content/Context;BIILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    return-void
.end method
