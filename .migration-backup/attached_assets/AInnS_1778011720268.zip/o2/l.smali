.class public Lo2/l;
.super Lo2/k;


# instance fields
.field public d:Ljava/nio/channels/Selector;

.field public e:Ljava/nio/channels/SocketChannel;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Lo2/k;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public b()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "Sos~41i ~/@blo@  ~@@~~~-  i ~@ r@~o@u t@~@~~~yobvt~@/@@s~nlf@f ~@@odMK ~ @c~mb a~@ @@~i . ~o ~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-string/jumbo v0, "nhlmCtnlscnpeTC"

    const-string/jumbo v0, "nTsCpelCltnnahc"

    const/4 v2, 0x7

    const-string/jumbo v0, "lCnconpTnCelaih"

    const-string v0, "TcpChannlClient"

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method

.method public c(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo p1, "tnoinbIt cccmedpm"

    const-string p1, "Icomp dnctmsteicn"

    const-string/jumbo p1, "tcp disconnectImp"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v0, "lntTlcuCiapeonh"

    const-string v0, "TnnCoclptaCielh"

    const/4 v4, 0x7

    const-string/jumbo v0, "lTlnptCpcanneCh"

    const-string v0, "TcpChannlClient"

    const/4 v4, 0x5

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/nio/channels/Selector;->isOpen()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/nio/channels/Selector;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/nio/channels/SocketChannel;->isConnected()Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/nio/channels/SocketChannel;->finishConnect()Z

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string v2, "anli esoqfcndice d"

    const-string v2, "cns iboaeec lddfin"

    const/4 v4, 0x2

    const-string v2, " dsnei eiastocdfln"

    const-string v2, "disconnect failed "

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public l(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Ld3/p;->c(Landroid/content/Context;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "ClCmtnTilnuchae"

    const-string/jumbo v1, "iclnnauTChelnCt"

    const/4 v4, 0x3

    const-string/jumbo v1, "ninCoptllchnCaT"

    const-string v1, "TcpChannlClient"

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v4, 0x4

    const-string p1, "cntonbew/nc tspce oas rk/dtncindit,eC n"

    const-string/jumbo p1, "rtw oCipnoaneec cdnndkt tis t/ceno/cns,"

    const/4 v4, 0x7

    const-string/jumbo p1, "ncr  nusntCk/ cdwtso,onntenaetiicee/odc"

    const-string p1, "can\'t connect, network is disConnected"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v1, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v2, " notpncpt qc"

    const-string v2, " e ocpntqctn"

    const/4 v4, 0x2

    const-string v2, " ctto enqpnc"

    const-string/jumbo v2, "tcp connect "

    const/4 v4, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, ":"

    const-string v2, ":"

    const/4 v4, 0x6

    const-string v2, ":"

    const-string v2, ":"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance p1, Ljava/net/InetSocketAddress;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, p2, p3}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {}, Ljava/nio/channels/SocketChannel;->open()Ljava/nio/channels/SocketChannel;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object p2, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Ljava/nio/channels/SelectableChannel;->configureBlocking(Z)Ljava/nio/channels/SelectableChannel;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Ljava/nio/channels/Selector;->open()Ljava/nio/channels/Selector;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object p2, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p3, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/16 v2, 0x8

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p3, p2, v2}, Ljava/nio/channels/SelectableChannel;->register(Ljava/nio/channels/Selector;I)Ljava/nio/channels/SelectionKey;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object p2, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Ljava/nio/channels/SocketChannel;->connect(Ljava/net/SocketAddress;)Z

    const/4 v4, 0x7

    iget-object p1, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/nio/channels/Selector;->select()I

    const/4 v3, 0x3

    and-int/2addr v4, v3

    iget-object p1, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/nio/channels/Selector;->selectedKeys()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p1, "eKse lietnysli sulcns"

    const/4 v4, 0x3

    const-string/jumbo p1, "uKsseilcnysltons ei e"

    const-string/jumbo p1, "selectionKeys is null"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p2, :cond_2

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    const-string p1, "eipm messeiKloecyymt n"

    const-string/jumbo p1, "yeomesiytme clpnsiKes "

    const/4 v4, 0x0

    const-string/jumbo p1, "selectionKeys is empty"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast p1, Ljava/nio/channels/SelectionKey;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz p1, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/nio/channels/SelectionKey;->isConnectable()Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez p2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/nio/channels/SelectionKey;->isConnectable()Z

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez p2, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string p1, "KonnoeCdetnyset ldi ciseecoi"

    const-string/jumbo p1, "selectionKey is disConnected"

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/nio/channels/SelectionKey;->channel()Ljava/nio/channels/SelectableChannel;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    check-cast p1, Ljava/nio/channels/SocketChannel;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/nio/channels/SocketChannel;->isConnectionPending()Z

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez p2, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p1, " tiscbocfhnneo"

    const-string/jumbo p1, "ncioofnnhes ct"

    const/4 v4, 0x2

    const-string/jumbo p1, "tsincouh ecfin"

    const-string p1, "finish connect"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/nio/channels/SocketChannel;->finishConnect()Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p2, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 p3, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, p2, p3}, Ljava/nio/channels/SelectableChannel;->register(Ljava/nio/channels/Selector;I)Ljava/nio/channels/SelectionKey;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p1, "cutpctepsnobc cn es"

    const-string/jumbo p1, "ucsecbnt pctcnseo s"

    const/4 v4, 0x7

    const-string/jumbo p1, "nsctnsu qeetcposccc"

    const-string/jumbo p1, "tcp connect success"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return p3

    :cond_6
    :goto_0
    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p1, "nslieKutel elounsyci"

    const/4 v4, 0x2

    const-string/jumbo p1, "s slenniyeisutoleK c"

    const-string/jumbo p1, "selectionKey is null"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    return v0
.end method

.method public m(Landroid/content/Context;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lo2/l;->t(Landroid/content/Context;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public n(Landroid/content/Context;[B)Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/nio/channels/SocketChannel;->isConnected()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lo2/l;->e:Ljava/nio/channels/SocketChannel;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Ljava/nio/channels/SocketChannel;->write(Ljava/nio/ByteBuffer;)I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1
.end method

.method public o(Landroid/content/Context;)[B
    .locals 13

    const/4 v12, 0x2

    const-string/jumbo v0, "lCnmhlCnapeipcn"

    const-string v0, "CainnphpTcenCll"

    const/4 v12, 0x1

    const-string/jumbo v0, "tnhcopClnnTlaie"

    const-string v0, "TcpChannlClient"

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v1, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    const/4 v2, 0x0

    :try_start_0
    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {p0}, Lo2/k;->j()Z

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-nez v3, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-string/jumbo v3, "icponbnsqigeoncct n  "

    const-string v3, "ciocio eqsg  nntpntnc"

    const/4 v12, 0x1

    const-string v3, "enctonun cctntgs ioip"

    const-string/jumbo v3, "tcp is not connecting"

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    return-object v2

    :cond_0
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v3, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-virtual {v3}, Ljava/nio/channels/Selector;->select()I

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-object v3, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v3}, Ljava/nio/channels/Selector;->isOpen()Z

    move-result v3

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-nez v3, :cond_1

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    const-string v3, "cses olpstdol ecer"

    const-string/jumbo v3, "selector is closed"

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    return-object v2

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget-object v3, p0, Lo2/l;->d:Ljava/nio/channels/Selector;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v3}, Ljava/nio/channels/Selector;->selectedKeys()Ljava/util/Set;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-nez v3, :cond_2

    const/4 v11, 0x6

    or-int/2addr v12, v11

    const-string v3, "e oeulssqctelisy nKsn"

    const-string v3, "eusyelo stclneslKins "

    const/4 v12, 0x3

    const-string/jumbo v3, "sisltn scu soniyeKeel"

    const-string/jumbo v3, "selectionKeys is null"

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    move v12, v11

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    return-object v2

    :cond_2
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-interface {v3}, Ljava/util/Set;->isEmpty()Z

    move-result v4

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-eqz v4, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x2

    const-string/jumbo v3, "oetmKn styeeyii pslems"

    const-string/jumbo v3, "ie mesKsitlostynemype "

    const/4 v12, 0x2

    const-string v3, "ettyosscmpiKe yi eensl"

    const-string/jumbo v3, "selectionKeys is empty"

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    return-object v2

    :cond_3
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-nez v4, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string v3, "h/xcobiena /Keytntele nots"

    const-string v3, "e i/oylnst/xee centthsonaK"

    const/4 v12, 0x0

    const-string/jumbo v3, "schy/eueoexn t/sinst Klnta"

    const-string/jumbo v3, "selectionKeys hasn\'t next"

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    return-object v2

    :cond_4
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    check-cast v3, Ljava/nio/channels/SelectionKey;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-nez v3, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string v3, " yoe sbpilKclselnniu"

    const-string v3, "Klsleb uiintyls coen"

    const/4 v12, 0x4

    const-string/jumbo v3, "lesllcyuq io enitKes"

    const-string/jumbo v3, "selectionKey is null"

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    return-object v2

    :cond_5
    const/4 v12, 0x0

    invoke-virtual {v3}, Ljava/nio/channels/SelectionKey;->isReadable()Z

    move-result v4

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    if-nez v4, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x6

    const-string/jumbo v3, "sssi teeecRboludaniisdelye "

    const-string v3, "aResosute elensed yicliaibd"

    const/4 v12, 0x7

    const-string v3, "ReKmadnsadbiilslotey s eeei"

    const-string/jumbo v3, "selectionKey is disReadable"

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    return-object v2

    :cond_6
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v3}, Ljava/nio/channels/SelectionKey;->channel()Ljava/nio/channels/SelectableChannel;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    check-cast v3, Ljava/nio/channels/SocketChannel;

    const/4 v12, 0x4

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/nio/channels/SocketChannel;->isConnected()Z

    move-result v4

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-nez v4, :cond_7

    const/4 v12, 0x6

    const/4 v11, 0x6

    const-string v3, "dtcnocnsn oaeCpskChosltedei i"

    const-string/jumbo v3, "nece eopdleCkitCs dnssnhocati"

    const/4 v12, 0x3

    const-string/jumbo v3, "socketChannel is disConnected"

    const/4 v12, 0x6

    const/4 v11, 0x1

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x6

    return-object v2

    :cond_7
    const/4 v11, 0x4

    move v12, v11

    invoke-virtual {p0}, Lo2/k;->j()Z

    move-result v4

    const/4 v12, 0x4

    if-eqz v4, :cond_c

    const/4 v12, 0x3

    const/4 v4, 0x7

    const/4 v12, 0x4

    const/4 v4, 0x2

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v4

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v3, v4}, Ljava/nio/channels/SocketChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v5

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-gez v5, :cond_8

    const/4 v12, 0x4

    const/4 v11, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    const-string v4, "eteanb ahdd  glr=qha"

    const-string/jumbo v4, "n =eeatgql ahrdadhe "

    const/4 v12, 0x1

    const-string v4, "a nadhu  hrtlg=eea d"

    const-string/jumbo v4, "read ahead length = "

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-object v2

    :cond_8
    const/4 v12, 0x5

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v4}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v5

    const/4 v12, 0x6

    const/4 v11, 0x3

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v5

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    and-int/lit16 v5, v5, 0x3fff

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-nez v5, :cond_9

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string/jumbo v4, "tensltoplard  th=  a"

    const-string/jumbo v4, "o srlttaa et=  glnhd"

    const/4 v12, 0x4

    const-string v4, "atheldotqnlg t  e =r"

    const-string/jumbo v4, "read total length = "

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    return-object v2

    :cond_9
    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    add-int/lit8 v6, v5, -0x2

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v6

    :cond_a
    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v6}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result v7

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    if-eqz v7, :cond_b

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v3, v6}, Ljava/nio/channels/SocketChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v7

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    int-to-long v7, v7

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    cmp-long v9, v7, v9

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-gez v9, :cond_a

    const/4 v12, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string v4, " es mr  netnatoc="

    const-string v4, "d cm t rn=oaent e"

    const/4 v12, 0x5

    const-string v4, "d tmco rn=te  ann"

    const-string/jumbo v4, "read content n = "

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v3, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    const-string v4, "  neooditoo  =tinpraonce"

    const-string/jumbo v4, "ietao=c irendops   ntnoo"

    const/4 v12, 0x5

    const-string/jumbo v4, "oinoibc taetrtd =enso p "

    const-string/jumbo v4, "read content position = "

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {v6}, Ljava/nio/Buffer;->position()I

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string/jumbo v4, "read content limit = "

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v6}, Ljava/nio/Buffer;->limit()I

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-object v2

    :cond_b
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-array v5, v5, [B

    const/4 v12, 0x3

    const/4 v11, 0x4

    array-length v6, v4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v7, 0x0

    and-int/2addr v12, v7

    const/4 v11, 0x2

    shr-int/2addr v12, v11

    invoke-static {v4, v7, v5, v7, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    array-length v4, v4

    const/4 v12, 0x1

    const/4 v11, 0x3

    array-length v6, v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    invoke-static {v3, v7, v5, v4, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    return-object v5

    :catchall_0
    move-exception v3

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    move v12, v11

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v5, "bei d ueielcfre"

    const-string v5, "caelibedfeier  "

    const/4 v12, 0x4

    const-string v5, "ecveiirp de lef"

    const-string/jumbo v5, "receive failed "

    const/4 v12, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    goto :goto_0

    :catch_0
    move-exception v3

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string v5, "One p xcqIritieeEoce"

    const-string/jumbo v5, "receive IOException "

    const/4 v12, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    invoke-virtual {p0, p1, v1}, Lo2/k;->e(Landroid/content/Context;Z)V

    :cond_c
    :goto_0
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    return-object v2
.end method

.method public final t(Landroid/content/Context;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lo2/l;->u(Landroid/content/Context;)Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final u(Landroid/content/Context;)Ljava/util/Set;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {p1}, Lo2/q;->D(Landroid/content/Context;)Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {p1}, Lh3/b;->a(Landroid/content/Context;)Lcom/engagelab/privates/core/api/Address;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->d()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-gtz v1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    return-object v0

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->a()[Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string v3, ":"

    const-string v3, ":"

    const/4 v10, 0x3

    const-string v3, ":"

    const-string v3, ":"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v4, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v2, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    array-length v5, v2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-lez v5, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    array-length v5, v2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    move v6, v4

    move v6, v4

    :goto_0
    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-ge v6, v5, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    aget-object v7, v2, v6

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez v8, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x5

    invoke-interface {v0, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v10, 0x7

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    goto :goto_0

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->c()[Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz p1, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    array-length v2, p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-lez v2, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    array-length v2, p1

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ge v4, v2, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    aget-object v5, p1, v4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-nez v6, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {v0, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_1

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    return-object v0
.end method
