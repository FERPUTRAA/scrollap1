.class public Lo2/c0;
.super Lo2/b0;


# static fields
.field public static volatile c:Lo2/c0;


# instance fields
.field public b:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lo2/b0;-><init>()V

    const/4 v1, 0x2

    move v2, v1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public static e()Lo2/c0;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@tsb flu~i~ob m~~ /v@~@ i~Kd@~@1@ ~f t@@o4~~n- c l oy@a~  o@ @~ S~@ r@~b@~/~~~@i@@@@o~~.~s~oM @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lo2/c0;->c:Lo2/c0;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-class v0, Lo2/c0;

    const-class v0, Lo2/c0;

    const/4 v3, 0x7

    const-class v0, Lo2/c0;

    const-class v0, Lo2/c0;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lo2/c0;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1}, Lo2/c0;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v1, Lo2/c0;->c:Lo2/c0;

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lo2/c0;->c:Lo2/c0;

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public final b(Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lo2/b0;->a()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    sget p1, Lj3/a$a;->d:I

    const/4 v3, 0x1

    return p1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    const/4 v3, 0x5

    array-length v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x28

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-le v0, v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget p1, Lj3/a$a;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    return p1

    :cond_2
    const/4 v2, 0x6

    move v3, v2

    const-string v0, "=/am_s^]+u[-4/&.$+!az-#-90f@5*-|90Z$0A"

    const-string v0, "-|s.0_9af$/*]/A=[-&50Z+$^ae!4u-9-#+0@z"

    const/4 v3, 0x5

    const-string/jumbo v0, "u-a#o^/+0/u0@_!f$&4Z.e*5-A-0+z-|$99a]="

    const-string v0, "^[\u4e00-\u9fa50-9a-zA-Z_!@#$&*+=.|]+$"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/util/regex/Matcher;->matches()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez p1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget p1, Lj3/a$a;->d:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p1

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p1
.end method

.method public c(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 3

    :try_start_0
    const/4 v1, 0x4

    move v2, v1

    const-class v0, Lcom/engagelab/privates/push/api/AliasMessage;

    const-class v0, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v2, 0x4

    const-class v0, Lcom/engagelab/privates/push/api/AliasMessage;

    const-class v0, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v1, 0x4

    const/4 v1, 0x4

    const-string v0, "basma"

    const-string/jumbo v0, "iaams"

    const/4 v2, 0x7

    const-string/jumbo v0, "iuaal"

    const-string v0, "alias"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p3, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p3, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez p3, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Ly2/b;->g(Landroid/content/Context;)Lcom/engagelab/privates/common/component/MTCommonReceiver;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    packed-switch p2, :pswitch_data_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p3}, Lcom/engagelab/privates/common/component/MTCommonReceiver;->onAliasMessage(Landroid/content/Context;Lcom/engagelab/privates/push/api/AliasMessage;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string p3, "enc oapi afMsregdeaioMslss"

    const/4 v2, 0x4

    const-string/jumbo p3, "poiagf pcdeeMsiealasnr ess"

    const-string/jumbo p3, "processMainMessage failed "

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p2, "BelsMbssqiisTnu"

    const-string/jumbo p2, "sAiBibMsnuselTs"

    const/4 v2, 0x4

    const-string/jumbo p2, "snseTlsisuiAsBa"

    const-string p2, "MTAliasBusiness"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p2, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xbc9
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public d(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v0, "nsimseAssMuauBT"

    const-string v0, "MeBsasuuslsTAin"

    const/4 v5, 0x5

    const-string v0, "BaMiolnseisuTsA"

    const-string v0, "MTAliasBusiness"

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v1, "rctoobpl"

    const-string/jumbo v1, "protocol"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez p2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    long-to-int p2, v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x7

    move v5, v4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v2, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v2}, Lcom/engagelab/privates/push/api/AliasMessage;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2, p2}, Lcom/engagelab/privates/push/api/AliasMessage;->h(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget v3, Lj3/a$a;->c:I

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/push/api/AliasMessage;->g(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Lcom/engagelab/privates/push/api/AliasMessage;->e(Ljava/lang/String;)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const-string/jumbo v3, "naAiunuloesndaploer:qtsea iecOei"

    const-string/jumbo v3, "onAliasOperationFailed sequence:"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string p2, "a psa:ipleseMgs"

    const-string/jumbo p2, "sssaeelpaig ,M:"

    const/4 v5, 0x3

    const-string p2, "ass:eesiqga,M a"

    const-string p2, ", aliasMessage:"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/engagelab/privates/push/api/AliasMessage;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance p2, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v2, "lisaq"

    const-string v2, "aalqi"

    const-string v2, "aisma"

    const-string v2, "alias"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p2, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/16 v1, 0xbc9

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p1, v1, p2}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "liesopeiAstfaeOnrioaldl i oFad"

    const-string v1, " lsdlieiialaeoepndrta nFiOsofA"

    const/4 v5, 0x5

    const-string/jumbo v1, "olidob easa FldaOefnrtiAialpne"

    const-string/jumbo v1, "onAliasOperationFailed failed "

    const/4 v4, 0x1

    or-int/2addr v5, v4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x5

    return-void
.end method

.method public f(Landroid/content/Context;ILandroid/os/Bundle;)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v0, "mMsBiAusuessinT"

    const-string/jumbo v0, "sMumaisAsTsneBi"

    const-string/jumbo v0, "ueTaAMspslssnii"

    const-string v0, "MTAliasBusiness"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v1, "ialao"

    const/4 v7, 0x7

    const-string v1, "aaiqs"

    const-string v1, "alias"

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v2, "ensqsbeu"

    const-string v2, "eeeuqbns"

    const/4 v7, 0x3

    const-string/jumbo v2, "ueqmcsne"

    const-string/jumbo v2, "sequence"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p3, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-virtual {p3, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    packed-switch p2, :pswitch_data_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :pswitch_0
    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0, p3}, Lo2/c0;->b(Ljava/lang/String;)I

    move-result p2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz p2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v3, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v7, 0x4

    invoke-direct {v3}, Lcom/engagelab/privates/push/api/AliasMessage;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Lcom/engagelab/privates/push/api/AliasMessage;->h(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, p2}, Lcom/engagelab/privates/push/api/AliasMessage;->g(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/push/api/AliasMessage;->e(Ljava/lang/String;)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance p3, Landroid/os/Bundle;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p3, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 p2, 0xbc9

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p1, p2, p3}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo p2, "tse"

    const-string p2, "est"

    const/4 v7, 0x1

    const-string/jumbo p2, "ste"

    const-string/jumbo p2, "set"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_0

    :pswitch_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo p2, "tge"

    const/4 v7, 0x0

    const-string p2, "get"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :pswitch_2
    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string p2, "edl"

    const-string p2, "eld"

    const/4 v7, 0x6

    const-string p2, "eld"

    const-string p2, "del"

    :goto_0
    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v3, Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v4, "rtmuolpa"

    const-string/jumbo v4, "lpaomrut"

    const/4 v7, 0x5

    const-string/jumbo v4, "rptamblf"

    const-string/jumbo v4, "platform"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v5, "a"

    const-string v5, "a"

    const-string v5, "a"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v4, "op"

    const-string/jumbo v4, "po"

    const/4 v7, 0x2

    const-string/jumbo v4, "po"

    const-string/jumbo v4, "op"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3, v4, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x4

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez p2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object p2, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, v4, p3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3, v1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const-string/jumbo p3, "pnuediusoaelsiqnpteceareO nA"

    const-string/jumbo p3, "naetoOApnqidnucse:epileear s"

    const/4 v7, 0x7

    const-string p3, "ceenn opiuaesstA:sdeeaOrnplq"

    const-string/jumbo p3, "sendAliasOperation sequence:"

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo p3, "tnt:qne,qc"

    const-string p3, "cnetn,: qt"

    const/4 v7, 0x5

    const-string p3, "ets:,ton c"

    const-string p3, ", content:"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-static {v3}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-static {p2}, Lo2/g;->d(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    if-nez p2, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x1

    return-void

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance p3, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {p3}, Lcom/engagelab/privates/core/api/MTProtocol;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    int-to-long v1, v2

    const/4 v7, 0x6

    invoke-virtual {p3, v1, v2}, Lcom/engagelab/privates/core/api/MTProtocol;->k(J)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/16 v1, 0x1d

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p3, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->i(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p3, v1}, Lcom/engagelab/privates/core/api/MTProtocol;->o(I)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p3, p2}, Lcom/engagelab/privates/core/api/MTProtocol;->h([B)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-object p3, Li3/a;->a:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, p3}, Lcom/engagelab/privates/core/api/MTProtocol;->n(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTProtocol;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance p3, Landroid/os/Bundle;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v1, "srpmtcoo"

    const-string/jumbo v1, "rcsoptoo"

    const/4 v7, 0x4

    const-string v1, "coltopor"

    const-string/jumbo v1, "protocol"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p3, v1, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/16 p2, 0x8ae

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p1, p2, p3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x0

    move v7, v6

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const-string p3, "aendabfiOloA l dnriapiemst"

    const-string p3, " pAmta fdnOsosdrieailinlea"

    const/4 v7, 0x1

    const-string p3, "elaAi uesidne arpldatsnoOi"

    const-string/jumbo p3, "sendAliasOperation failed "

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xf8d
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public g(Landroid/content/Context;Landroid/os/Bundle;)V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v0, "ssMsseupaiBlnTi"

    const-string/jumbo v0, "slisoTsuseniMBa"

    const/4 v9, 0x5

    const-string/jumbo v0, "ssMnBuiaqsAlTei"

    const-string v0, "MTAliasBusiness"

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v1, "posobcrt"

    const-string v1, "cotprbol"

    const/4 v9, 0x6

    const-string/jumbo v1, "pocmotlr"

    const-string/jumbo v1, "protocol"

    const/4 v9, 0x4

    invoke-virtual {p2, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    check-cast p2, Lcom/engagelab/privates/core/api/MTProtocol;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-nez p2, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->d()J

    move-result-wide v1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    long-to-int v1, v1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p2}, Lcom/engagelab/privates/core/api/MTProtocol;->a()[B

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p2}, Ld3/o;->j(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-instance v2, Lorg/json/JSONObject;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {v2, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string v3, "enOeocc:urcsseualnooqsue pnaSeist"

    const-string v3, ":csnicusqoesoauputee clrnasienOeS"

    const/4 v9, 0x0

    const-string/jumbo v3, "toecabSiiqeslc cpesAsearunoOuesnn"

    const-string/jumbo v3, "onAliasOperationSuccess sequence:"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    move v9, v8

    const-string v3, "cn:,tounte"

    const-string v3, ", content:"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v2}, Lb3/a;->g(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x3

    invoke-static {v0, p2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string p2, "deoc"

    const-string p2, "edoc"

    const-string p2, "cdeo"

    const-string p2, "code"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2, p2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string/jumbo v3, "op"

    const-string/jumbo v3, "po"

    const/4 v9, 0x3

    const-string/jumbo v3, "op"

    const-string/jumbo v3, "op"

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    const v5, 0x1840b

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v6, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v7, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eq v4, v5, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    const v5, 0x18f56

    const/4 v8, 0x3

    move v9, v8

    if-eq v4, v5, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const v5, 0x1bc62

    const/4 v8, 0x5

    move v9, v8

    if-eq v4, v5, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v4, "est"

    const-string/jumbo v4, "ste"

    const/4 v9, 0x6

    const-string/jumbo v4, "set"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x3

    if-eqz v3, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string v4, "gte"

    const-string v4, "get"

    const/4 v9, 0x1

    const-string/jumbo v4, "tge"

    const-string v4, "get"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v3, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    move v3, v6

    move v3, v6

    const/4 v9, 0x7

    move v3, v6

    move v3, v6

    const/4 v9, 0x6

    goto :goto_1

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v4, "edl"

    const-string v4, "del"

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v3, :cond_4

    const/4 v8, 0x7

    move v9, v8

    move v3, v7

    move v3, v7

    const/4 v9, 0x2

    move v3, v7

    move v3, v7

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v3, -0x1

    :goto_1
    const/4 v9, 0x6

    const/16 v4, 0xbc9

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string/jumbo v5, "ilpaa"

    const-string v5, "aapil"

    const/4 v9, 0x2

    const-string v5, "alsqa"

    const-string v5, "alias"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v3, :cond_7

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eq v3, v6, :cond_6

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eq v3, v7, :cond_5

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    goto :goto_2

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/16 v4, 0xbcb

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_2

    :cond_6
    :try_start_1
    const/4 v9, 0x0

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/16 v4, 0xbca

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_2

    :cond_7
    const/4 v8, 0x0

    move v9, v8

    iget-object v2, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    check-cast v2, Ljava/lang/String;

    const/4 v8, 0x2

    move v9, v8

    iget-object v3, p0, Lo2/c0;->b:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v3, v6}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    new-instance v3, Lcom/engagelab/privates/push/api/AliasMessage;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v3}, Lcom/engagelab/privates/push/api/AliasMessage;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x6

    invoke-virtual {v3, v1}, Lcom/engagelab/privates/push/api/AliasMessage;->h(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1, p2}, Lcom/engagelab/privates/push/api/AliasMessage;->g(I)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p2, v2}, Lcom/engagelab/privates/push/api/AliasMessage;->e(Ljava/lang/String;)Lcom/engagelab/privates/push/api/AliasMessage;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    shl-int/2addr v9, v8

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v2, "i:OsanatqAsnr oauSaoiMlsecepgsslciaee"

    const/4 v9, 0x2

    const-string/jumbo v2, "onAliasOperationSuccess aliasMessage:"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/engagelab/privates/push/api/AliasMessage;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    new-instance v1, Landroid/os/Bundle;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v1, v5, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {p1, v4, v1}, Lq2/a;->j(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const-string/jumbo v1, "iasiusd inOanstaslAoesfe eSplco"

    const-string/jumbo v1, "srsfSdoaospelunic AliOatn eseia"

    const/4 v9, 0x5

    const-string v1, "earms  ietilsAoucacpanlOSisefdo"

    const-string/jumbo v1, "onAliasOperationSuccess failed "

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v0, p1}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    return-void
.end method
