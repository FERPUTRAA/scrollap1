.class public Lo2/g;
.super Ljava/lang/Object;


# direct methods
.method public static a(BLjava/lang/String;Ljava/lang/String;)[B
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~Ss~ ~~b@/ @l m sbd1@la@f .n~o@~t@fv@@@co@ @~b@@  ~i~o@MK~~~~i y4 r~@~@~o  ~o~@~@ ~@i - t~ ~ ou/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x2

    sget-object v1, Lx2/a;->b:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v1, Lx2/a;->b:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    array-length v1, p2

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-lez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    array-length v1, p1

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    array-length v2, p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    add-int/2addr v1, v2

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    array-length v1, p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v2, Lf3/b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v2, v1}, Lf3/b;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2, p1}, Lf3/b;->j([B)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v2, p0}, Lf3/b;->r(I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    array-length p0, p2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-lez p0, :cond_2

    const/4 v4, 0x7

    invoke-virtual {v2, p2}, Lf3/b;->j([B)V

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Lf3/b;->g()[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p2, "mromeByagafn iofkcoaltd Tleekdpa"

    const-string/jumbo p2, "packagePlatformTokenBody failed "

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo p1, "uPthoPTsocoosM"

    const-string/jumbo p1, "oPshtcosluPMoT"

    const/4 v4, 0x2

    const-string/jumbo p1, "oPcTtbushooPlr"

    const-string p1, "MTPushProtocol"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0
.end method

.method public static b(IJ)[B
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Lf3/b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/16 v1, 0xb

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lf3/b;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lf3/b;->l(I)V

    const/4 v3, 0x6

    int-to-byte p0, p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Lf3/b;->r(I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lf3/b;->p(J)V

    const/4 v3, 0x4

    invoke-virtual {v0}, Lf3/b;->g()[B

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p0
.end method

.method public static c(Ljava/lang/String;)[B
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    array-length v0, p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v2, Lf3/b;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v2, v0}, Lf3/b;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x7

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v2, v0}, Lf3/b;->r(I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Lf3/b;->r(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2, p0}, Lf3/b;->j([B)V

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {v2}, Lf3/b;->g()[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    move v4, v3

    const-string v1, "efpyceuaBilkNabd ioaMomem ugdbr"

    const-string/jumbo v1, "ypimeflckB aoruembdoalMgNdaibe "

    const/4 v4, 0x2

    const-string/jumbo v1, "looayg padbidel aebNBprekmuiMce"

    const-string/jumbo v1, "packageMobileNumberBody failed "

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "PcMlrtPTqohosu"

    const-string v0, "MTPushProtocol"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 p0, 0x2

    const/4 v4, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    return-object p0
.end method

.method public static d(Ljava/lang/String;)[B
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lx2/a;->b:Ljava/lang/String;

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    array-length v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lf3/b;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1, v0}, Lf3/b;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p0}, Lf3/b;->j([B)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1}, Lf3/b;->g()[B

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const-string v1, "ceslpaaofia k sqleuRiesdgeA"

    const-string/jumbo v1, "pa qolfaAeekssguRicalidaee "

    const/4 v3, 0x6

    const-string v1, " eimleugstlqpe aRfadesAckia"

    const-string/jumbo v1, "packageAliasRequest failed "

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "hPlroutMbocsoT"

    const-string v0, "PurtobsclToPhM"

    const/4 v3, 0x0

    const-string v0, "hrPcTblsoMPuot"

    const-string v0, "MTPushProtocol"

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method
