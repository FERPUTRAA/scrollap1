.class public Lo2/n;
.super Lo2/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/n$a;
    }
.end annotation


# instance fields
.field public d:Ljavax/net/ssl/SSLSocket;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lo2/k;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public b()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osn@d@~~  f/@s@ . @~MKl@~ @om~t~o@~~~4~i/@iu1 y ~@ ~a@@b@   @@tf~~~~ @@i c@@ob~o~-  Sr~  @l~ovb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-string v0, "cSnmiLTCplte"

    const-string v0, "ecslLSiCtTnp"

    const/4 v2, 0x7

    const-string/jumbo v0, "pLSnoTltScie"

    const-string v0, "TcpSSLClient"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public c(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "SetlnbLmCicp"

    const-string p1, "ceCmSLptnTli"

    const/4 v4, 0x2

    const-string p1, "cTSpiLulenCS"

    const-string p1, "TcpSSLClient"

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "smdtociocnn Itcep"

    const/4 v4, 0x3

    const-string/jumbo v0, "pinocntpp Isdcmtc"

    const-string/jumbo v0, "tcp disconnectImp"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v0, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "dctl bioqs nnadfei"

    const-string v2, "e naibdoscclnf idt"

    const/4 v4, 0x2

    const-string/jumbo v2, "nissetenc dfd caoi"

    const-string v2, "disconnect failed "

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public l(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lo2/n;->u(Landroid/content/Context;Ljava/lang/String;I)Ljavax/net/ssl/SSLSocket;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const-string/jumbo p2, "lSpmutnLCScT"

    const-string/jumbo p2, "nelSTCuLptSc"

    const/4 v1, 0x0

    const-string p2, "TneSocLCiltp"

    const-string p2, "TcpSSLClient"

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    const-string/jumbo p1, "soe cbscucpt ptcenc"

    const-string p1, "ettc cupenoccnspcs "

    const/4 v1, 0x3

    const-string/jumbo p1, "tscescu optccesnn c"

    const-string/jumbo p1, "tcp connect success"

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p2, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x4

    return p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    const-string p1, "fo ccctp apnien"

    const-string/jumbo p1, "tcp connect fai"

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-static {p2, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p1
.end method

.method public m(Landroid/content/Context;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lo2/n;->v(Landroid/content/Context;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public n(Landroid/content/Context;[B)Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    iget-object p1, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/net/Socket;->isConnected()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p1, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x6

    move v2, v1

    return p1
.end method

.method public o(Landroid/content/Context;)[B
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    const-string v0, "TSneitlSqqcC"

    const-string/jumbo v0, "ilSpCnStqceT"

    const-string v0, "TcpSSLClient"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/4 v1, 0x0

    const/4 v11, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/4 v2, 0x1

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p0}, Lo2/k;->j()Z

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    if-nez v3, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string/jumbo v3, "itsncpcse nn oi sttcg"

    const-string/jumbo v3, "scsnogioncc tp n tiet"

    const/4 v12, 0x0

    const-string v3, " npmntgc n snocecoitt"

    const-string/jumbo v3, "tcp is not connecting"

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-static {v0, v3}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-object v1

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget-object v3, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v3}, Ljava/net/Socket;->isConnected()Z

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    if-nez v3, :cond_1

    const/4 v12, 0x2

    const-string/jumbo v3, "scnnot  iceodistCnodnksleehmC"

    const-string/jumbo v3, "nktmoC icdiselnsCcnesntoeh ed"

    const/4 v12, 0x2

    const-string/jumbo v3, "neeoibtnenesCoca  dltCcdsksih"

    const-string/jumbo v3, "socketChannel is disConnected"

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    return-object v1

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {p0}, Lo2/k;->j()Z

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-eqz v3, :cond_6

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    const/4 v3, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-array v4, v3, [B

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-object v5, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {v5}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v5

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {v5, v4}, Ljava/io/InputStream;->read([B)I

    move-result v5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-gez v5, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string v4, "ada eauheogrt = dhen"

    const-string/jumbo v4, "n aaortedhle= gdeh a"

    const/4 v12, 0x4

    const-string/jumbo v4, "read ahead length = "

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    return-object v1

    :cond_2
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {v4}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v5

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v5

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    and-int/lit16 v5, v5, 0x3fff

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const-string/jumbo v7, "trnoab pt etg=  dhll"

    const-string v7, "hd a ble=neoltg tr t"

    const/4 v12, 0x6

    const-string v7, "ea t ttnqor= hdlgel "

    const-string/jumbo v7, "read total length = "

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v0, v6}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-nez v5, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    return-object v1

    :cond_3
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    add-int/lit8 v6, v5, -0x2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v6

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v6}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result v7

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    if-eqz v7, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {v6}, Ljava/nio/Buffer;->remaining()I

    move-result v7

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    new-array v7, v7, [B

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-object v8, p0, Lo2/n;->d:Ljavax/net/ssl/SSLSocket;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v8}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v8

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v8, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    const/4 v12, 0x5

    const/4 v11, 0x2

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const-string/jumbo v10, "t saetcntd ehle nogr n"

    const-string/jumbo v10, "rt egnua enttcenohdl  "

    const/4 v12, 0x4

    const-string v10, "dntmtngalhrt  ce=nee  "

    const-string/jumbo v10, "read content length = "

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    shl-int/2addr v12, v11

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {v0, v9}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-gtz v8, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    return-object v1

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v6, v7}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    goto :goto_0

    :cond_5
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    const-string v8, "hec oogl.e  tnytttaratseond nB=el"

    const-string/jumbo v8, "read total contentBytes.length = "

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    array-length v8, v6

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-static {v0, v7}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    new-array v5, v5, [B

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    const/4 v7, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {v4, v7, v5, v7, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    array-length v4, v6

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v6, v7, v5, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    return-object v5

    :catchall_0
    move-exception v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-string v5, "ceelpbeaidi frv"

    const-string v5, "edeecr pfii val"

    const-string v5, "i cia ueevrdfle"

    const-string/jumbo v5, "receive failed "

    const/4 v12, 0x3

    const/4 v11, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    goto :goto_1

    :catch_0
    move-exception v3

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    const-string/jumbo v5, "xeIqpcopivt encO rEe"

    const-string/jumbo v5, "ovIreciiqpE eOcxe tn"

    const/4 v12, 0x0

    const-string/jumbo v5, "v xeonEiqetIpc Orcei"

    const-string/jumbo v5, "receive IOException "

    const/4 v11, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-static {v0, v3}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {p0, p1, v2}, Lo2/k;->e(Landroid/content/Context;Z)V

    :cond_6
    :goto_1
    const/4 v12, 0x1

    return-object v1
.end method

.method public final t(Ljava/lang/String;)Ljavax/net/ssl/TrustManager;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/cert/CertificateException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lo2/n$a;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lo2/n$a;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final u(Landroid/content/Context;Ljava/lang/String;I)Ljavax/net/ssl/SSLSocket;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v0, "TtsCLelnpSSs"

    const-string/jumbo v0, "tTslSLeinSpC"

    const/4 v7, 0x1

    const-string v0, "TcpSSLClient"

    const/4 v7, 0x5

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    invoke-static {p1}, Lo2/q;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo p1, "lcimus slermn  "

    const-string p1, " sem  scllurnis"

    const/4 v7, 0x5

    const-string/jumbo p1, "rni ossu llsc l"

    const-string/jumbo p1, "ssl cer is null"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-object v1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v3, "btoso"

    const-string/jumbo v3, "tso:o"

    const/4 v7, 0x5

    const-string v3, ":utso"

    const-string v3, "host:"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const-string/jumbo v3, "rptbop"

    const-string/jumbo v3, "trop:b"

    const/4 v7, 0x3

    const-string/jumbo v3, "poq:,r"

    const-string v3, ",port:"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v0, v2}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const-string v2, "SLS"

    const-string v2, "LSS"

    const/4 v7, 0x5

    const-string v2, "SSL"

    const-string v2, "SSL"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v2}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-array v4, v3, [Ljavax/net/ssl/TrustManager;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Lo2/n;->t(Ljava/lang/String;)Ljavax/net/ssl/TrustManager;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    aput-object p1, v4, v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance p1, Ljava/security/SecureRandom;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {p1}, Ljava/security/SecureRandom;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2, v1, v4, p1}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1, p2, p3}, Ljavax/net/SocketFactory;->createSocket(Ljava/lang/String;I)Ljava/net/Socket;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast p1, Ljavax/net/ssl/SSLSocket;
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_b
    .catch Ljava/security/KeyManagementException; {:try_start_0 .. :try_end_0} :catch_a
    .catch Ljava/security/cert/CertificateException; {:try_start_0 .. :try_end_0} :catch_9
    .catch Ljava/net/SocketException; {:try_start_0 .. :try_end_0} :catch_8
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_7
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_6

    :try_start_1
    const/4 v7, 0x0

    invoke-virtual {p1, v3}, Ljava/net/Socket;->setKeepAlive(Z)V
    :try_end_1
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/security/KeyManagementException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/security/cert/CertificateException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/net/SocketException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/net/UnknownHostException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto/16 :goto_7

    :catch_0
    move-exception p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :catch_1
    move-exception p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_1

    :catch_2
    move-exception p2

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto/16 :goto_2

    :catch_3
    move-exception p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto/16 :goto_3

    :catch_4
    move-exception p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto/16 :goto_4

    :catch_5
    move-exception p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto/16 :goto_5

    :catch_6
    move-exception p1

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo p3, "tcsn :oiOuIsEexl"

    const-string p3, ": noxeuctsiEIlOs"

    const/4 v7, 0x7

    const-string p3, " eimIplo:snEtOsc"

    const-string/jumbo p3, "ssl IOException:"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto/16 :goto_6

    :catch_7
    move-exception p1

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string p3, ":cnsooonUopiHtewsklnEt xp"

    const-string/jumbo p3, "loositspknUoHntpcEewn :xn"

    const/4 v7, 0x5

    const-string p3, " tnUobns:txilkwenonEsHcsp"

    const-string/jumbo p3, "ssl UnknownHostException:"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    xor-int/2addr v7, v6

    goto/16 :goto_6

    :catch_8
    move-exception p1

    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string p3, "ecttqouspsSExkl:oicn"

    const-string/jumbo p3, "noikxpsoqct let:csSE"

    const/4 v7, 0x5

    const-string/jumbo p3, "toeSkslptxcoe cpi:nE"

    const-string/jumbo p3, "ssl SocketException:"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto/16 :goto_6

    :catch_9
    move-exception p1

    :goto_3
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo p3, "oafCsiseqtEepirti:lccets "

    const-string p3, " esCiEcsceiexp:stiaftotrl"

    const/4 v7, 0x4

    const-string/jumbo p3, "ssl CertificateException:"

    const/4 v7, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_6

    :catch_a
    move-exception p1

    :goto_4
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string p3, ":nsitMKetycnseeg oanEspleax"

    const-string/jumbo p3, "ssl KeyManagementException:"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_6

    :catch_b
    move-exception p1

    :goto_5
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo p3, "thEmlmpm:ccSti esonsoliAhxguo"

    const-string p3, "Nitmhl toonguolcpAhEcmi:sesSx"

    const-string/jumbo p3, "toxoohsiNguhs eEcnl:rtpociSAm"

    const-string/jumbo p3, "ssl NoSuchAlgorithmException:"

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0, p1}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_6
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_7
    const/4 v7, 0x1

    const/4 v6, 0x6

    return-object p1
.end method

.method public final v(Landroid/content/Context;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lo2/n;->w(Landroid/content/Context;)Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public final w(Landroid/content/Context;)Ljava/util/Set;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x5

    invoke-static {p1}, Lo2/q;->E(Landroid/content/Context;)Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    sget-boolean v1, Ly2/b;->b:Z

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz v1, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-object v0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {p1}, Lh3/b;->a(Landroid/content/Context;)Lcom/engagelab/privates/core/api/Address;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->d()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-gtz v1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    return-object v0

    :cond_1
    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->a()[Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string v3, ":"

    const-string v3, ":"

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v4, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v2, :cond_3

    const/4 v10, 0x5

    array-length v5, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-lez v5, :cond_3

    const/4 v10, 0x5

    array-length v5, v2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    move v6, v4

    move v6, v4

    const/4 v10, 0x2

    move v6, v4

    move v6, v4

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-ge v6, v5, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    aget-object v7, v2, v6

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    if-nez v8, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v0, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_0

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/engagelab/privates/core/api/Address;->c()[Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p1, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x3

    array-length v2, p1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-lez v2, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    array-length v2, p1

    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-ge v4, v2, :cond_5

    const/4 v10, 0x3

    aget-object v5, p1, v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-nez v6, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    move v10, v9

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {v0, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto :goto_1

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-object v0
.end method
