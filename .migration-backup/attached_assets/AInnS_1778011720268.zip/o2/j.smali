.class public Lo2/j;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 14

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v12, "b4std b~@M/~.oo  @1 -cl@~ @~r ~~~v@l@oi~~um o@o~ ~~/ ~@~@ tsS b~f@  @@y@@~@ f@@n@o ii~~@K@~ ~ ~a"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x2

    const-string/jumbo v0, "terc"

    const-string v0, "cter"

    const/4 v13, 0x4

    const-string v0, "cret"

    const-string v0, "cert"

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x0

    const-string v1, "CrtClient"

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x3

    const/4 v2, 0x0

    :try_start_0
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-static {p0}, Lh3/b;->d(Landroid/content/Context;)Ljava/util/List;

    move-result-object v3

    const/4 v13, 0x7

    const/4 v12, 0x2

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    if-eqz v4, :cond_0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    const-string/jumbo p0, "r emurreo  rpsnhtaoel r"

    const-string/jumbo p0, "oosrnptr leare r htu re"

    const/4 v13, 0x4

    const-string/jumbo p0, "ru hoenetolero ra rpt r"

    const-string/jumbo p0, "there are no report url"

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x4

    return-object v2

    :cond_0
    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-static {}, Ld3/a;->h()I

    move-result v4

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x3

    int-to-long v4, v4

    const/4 v13, 0x1

    invoke-static {v4, v5}, Ld3/a;->k(J)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/16 v5, 0x10

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    new-array v5, v5, [B

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x7

    fill-array-data v5, :array_0

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x2

    new-instance v6, Ljava/lang/String;

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-string v7, "bm8UT"

    const-string v7, "F8TmU"

    const/4 v13, 0x4

    const-string v7, "UuTF-"

    const-string v7, "UTF-8"

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v7

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-direct {v6, v5, v7}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x6

    const/16 v5, 0x62

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-static {v6, v5}, Ld3/a;->j(Ljava/lang/String;C)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-static {p0}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x7

    const-string v8, ":"

    const-string v8, ":"

    const/4 v13, 0x2

    const-string v8, ":"

    const-string v8, ":"

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x6

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x0

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x7

    const-string v9, ":ant"

    const-string/jumbo v9, "tn:a"

    const/4 v13, 0x6

    const-string v9, "at:n"

    const-string v9, "atn:"

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    move v13, v12

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-static {v1, v8}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v7}, Ld3/o;->k(Ljava/lang/String;)[B

    move-result-object v7

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-static {v6}, Ld3/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-static {v7, v8, v5}, Ld3/n;->k([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object v7

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x0

    const-string v9, "cpo aB"

    const-string v9, " aBioc"

    const/4 v13, 0x6

    const-string v9, "aBqsc "

    const-string v9, "Basic "

    const/4 v13, 0x1

    const/4 v12, 0x5

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/16 v9, 0xa

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-static {v7, v9}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x2

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x2

    new-instance v8, Ljava/util/ArrayList;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x5

    const/4 v10, 0x0

    :goto_0
    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x4

    const/4 v11, 0x3

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x3

    if-ge v10, v11, :cond_1

    const/4 v12, 0x5

    invoke-interface {v8, v3}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v13, 0x1

    const/4 v12, 0x7

    add-int/lit8 v10, v10, 0x1

    const/4 v13, 0x5

    const/4 v12, 0x0

    goto :goto_0

    :cond_1
    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x5

    const/4 v12, 0x7

    const-string v10, "/?sbrgte_teecr"

    const-string v10, "cregebtvr/e_t?"

    const-string v10, "/get_cert?ver="

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    invoke-static {p0}, Lo2/q;->F(Landroid/content/Context;)I

    move-result v10

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x4

    const-string v10, "&k="

    const-string v10, "=&k"

    const/4 v13, 0x5

    const-string v10, "&k="

    const-string v10, "&k="

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x6

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_2
    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x4

    if-eqz v8, :cond_4

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x4

    check-cast v8, Ljava/lang/String;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-static {p0, v8, v7}, Lo2/s;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v8

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x3

    if-eqz v8, :cond_2

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x2

    new-instance p0, Ljava/lang/String;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x6

    sget-object v3, Lx2/a;->b:Ljava/lang/String;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-direct {p0, v8, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x4

    new-instance v3, Lorg/json/JSONObject;

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-direct {v3, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x0

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x3

    if-eqz p0, :cond_3

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-static {p0, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-static {p0, v4, v5}, Ld3/n;->i([BLjava/lang/String;Ljava/lang/String;)[B

    move-result-object p0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    new-instance v4, Ljava/lang/String;

    const/4 v13, 0x3

    sget-object v5, Lx2/a;->b:Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-direct {v4, p0, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v3, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x1

    return-object p0

    :cond_4
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x3

    const-string p0, "frcm idugttel "

    const-string/jumbo p0, "il ftcur tedga"

    const-string p0, " tgdoietcrf la"

    const-string p0, "get crt failed"

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    return-object v2

    :catch_0
    move-exception p0

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    and-int/2addr v13, v12

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    move v13, v12

    const-string/jumbo v3, "in:arbeg u  cdptefl"

    const-string/jumbo v3, "nrigfu pal c :te de"

    const/4 v13, 0x7

    const-string/jumbo v3, "lc ft ugre id:an et"

    const-string v3, "get crt failed un :"

    const/4 v13, 0x6

    const/4 v12, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x7

    return-object v2

    nop

    :array_0
    .array-data 1
        0xbt
        0xdt
        0x12t
        0x50t
        0x52t
        0x51t
        0x52t
        0x56t
        0x52t
        0x57t
        0x52t
        0x54t
        0x3t
        0x32t
        0x9t
        0x43t
    .end array-data
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 7

    invoke-static {p0}, Lo2/j;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v3, "rCteitlnq"

    const/4 v6, 0x6

    const-string v3, "CltinrCpt"

    const-string v3, "CrtClient"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo p0, "riecg l qtteas"

    const-string p0, "gcseitl at der"

    const/4 v6, 0x5

    const-string p0, "g slcaiftedet "

    const-string p0, "get crt failed"

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v3, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    return v2

    :cond_0
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const-string v4, "d gm  tb yemoc:"

    const-string v4, "eobmcyd r :t  g"

    const/4 v6, 0x6

    const-string v4, "b e ocgr: otty "

    const-string v4, "get crt body : "

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v3, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v0, "oced"

    const-string v0, "code"

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v4, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v0, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-nez v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v0, "rev"

    const-string/jumbo v0, "vre"

    const-string v0, "erv"

    const-string/jumbo v0, "ver"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v4, "cert"

    const-string v4, "ectr"

    const/4 v6, 0x0

    const-string/jumbo v4, "terc"

    const-string v4, "cert"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0, v0}, Lo2/q;->c(Landroid/content/Context;I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p0, v1}, Lo2/q;->e(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v1, "ec eebSv  r rctssguoc "

    const-string v1, "  ucogcresS ceres tv t"

    const/4 v6, 0x7

    const-string v1, "get crt Success ver = "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    invoke-static {v3, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 p0, 0x1

    move v6, p0

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    return p0

    :cond_1
    const/4 v6, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const-string/jumbo v0, "ogtfsiuctlb jrbndOace:ee jt "

    const-string/jumbo v0, "r jesblcidct:g n boO atfjeet"

    const/4 v6, 0x6

    const-string/jumbo v0, "te  adjpO e scofrngctt:ijbe "

    const-string v0, "get crt failed jsonObject : "

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v3, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v1, "  t lfu:qieatc ge"

    const-string v1, " tg lcurta :fie e"

    const/4 v6, 0x2

    const-string v1, " gsfla etd ct er:"

    const-string v1, "get crt failed : "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-static {v3, p0}, Lb3/a;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v2
.end method
