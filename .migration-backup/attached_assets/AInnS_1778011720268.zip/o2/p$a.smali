.class public Lo2/p$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/p;->e(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Ljava/io/File;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lo2/p;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Ljava/io/File;Ljava/io/File;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "v@soi/ o1@ ~@~  l-~@~@ @ ~ ~  dS @M@oK  ~@ ~/@~@ymr@@i.@~tol~~ ~~nbs ft@f4b@ ~@~~@~~~~i~oob au@c"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/io/File;->lastModified()J

    move-result-wide p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    sub-long/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x4

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    cmp-long p1, v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-gez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-lez p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    check-cast p1, Ljava/io/File;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p2, Ljava/io/File;

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lo2/p$a;->a(Ljava/io/File;Ljava/io/File;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method
