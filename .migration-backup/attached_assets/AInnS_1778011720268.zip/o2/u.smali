.class public Lo2/u;
.super Ljava/lang/Object;


# static fields
.field public static volatile d:Lo2/u;


# instance fields
.field public a:J

.field public b:J

.field public c:Z


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    iput-wide v0, p0, Lo2/u;->a:J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-wide v0, p0, Lo2/u;->b:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-boolean v0, p0, Lo2/u;->c:Z

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;J)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "m@s o~~o @@K @@~ btb@ins i  1 ul@o~ @i@~~~~~r/M@~~@~@@v oy l~~d@~ ~S~4.-/@ @f@f~a~b @co@~ o@ t~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Ly2/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v4, 0x5

    invoke-static {p0}, Ly2/b;->o(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p0}, Ld3/o;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object p0
.end method

.method public static b()Lo2/u;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lo2/u;->d:Lo2/u;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-class v0, Lo2/u;

    const-class v0, Lo2/u;

    const/4 v3, 0x1

    const-class v0, Lo2/u;

    const-class v0, Lo2/u;

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    new-instance v1, Lo2/u;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v1}, Lo2/u;-><init>()V

    const/4 v3, 0x5

    sput-object v1, Lo2/u;->d:Lo2/u;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x3

    sget-object v0, Lo2/u;->d:Lo2/u;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public static d(Landroid/content/Context;JJ)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v0, "_"

    const-string v0, "_"

    const/4 v5, 0x3

    const-string v0, "_"

    const-string v0, "_"

    const/4 v5, 0x6

    const-string v1, "MAnmivisuBtsTecs"

    const-string/jumbo v1, "uTsBsseAstcviniM"

    const/4 v5, 0x7

    const-string/jumbo v1, "issTocnBesvueAtM"

    const-string v1, "MTActiveBusiness"

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p0}, Lo2/c;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v4, 0x5

    move v5, v4

    const-string/jumbo p0, "usilnblns ose s"

    const-string/jumbo p0, "session is null"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    sub-long/2addr p1, p3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-wide/16 p3, 0x3e8

    const-wide/16 p3, 0x3e8

    const/4 v5, 0x7

    const-wide/16 p3, 0x3e8

    const-wide/16 p3, 0x3e8

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    div-long/2addr p1, p3

    const/4 v5, 0x3

    invoke-static {}, Ld3/b;->d()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p3, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p4

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x0

    move v5, v4

    aget-object p4, p4, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p3, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    aget-object p3, p3, v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v3, "iem_dsuson"

    const-string/jumbo v3, "siomne_sds"

    const/4 v5, 0x2

    const-string/jumbo v3, "session_id"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "daet"

    const-string v2, "aedt"

    const/4 v5, 0x0

    const-string v2, "edta"

    const-string v2, "date"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v2, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string p4, "eimt"

    const-string/jumbo p4, "mtie"

    const-string/jumbo p4, "iemt"

    const-string/jumbo p4, "time"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, p4, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo p3, "oorniatp"

    const-string/jumbo p3, "iouaonrt"

    const/4 v5, 0x0

    const-string/jumbo p3, "qtdurain"

    const-string p3, "duration"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, p3, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p0, p1}, Lo2/c;->n(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const-string/jumbo p2, "obsgarde nclsfe arkpucsoB"

    const-string/jumbo p2, "sg usbdrdpeaolok efancrcB"

    const/4 v5, 0x2

    const-string/jumbo p2, "slrmek fccnusaderopBoaid "

    const-string/jumbo p2, "processBackground failed "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public static f(Landroid/content/Context;J)V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string v0, "_"

    const-string v0, "_"

    const/4 v8, 0x0

    const-string v0, "_"

    const-string v0, "_"

    const/4 v7, 0x3

    move v8, v7

    const-string/jumbo v1, "sBMnoTseiuvusAei"

    const-string/jumbo v1, "neiuieusBTscsMAv"

    const/4 v8, 0x6

    const-string/jumbo v1, "vnciTbuMesiAsets"

    const-string v1, "MTActiveBusiness"

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p0}, Lo2/c;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/16 v4, 0x8b9

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v5, "pcploout"

    const-string/jumbo v5, "pcrlotop"

    const/4 v8, 0x6

    const-string v5, "cltrpoop"

    const-string/jumbo v5, "protocol"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-nez v3, :cond_0

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v3, Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v3, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v2, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v2}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v6, "ecirmvnqqetaaeit"

    const-string/jumbo v6, "itranc_iqtmevaee"

    const-string/jumbo v6, "t_scateriavmente"

    const-string v6, "active_terminate"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v2, v6}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v2, v3}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v3, Landroid/os/Bundle;

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v3, v5, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p0, v4, v3}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V

    :cond_0
    const/4 v8, 0x5

    invoke-static {p0, p1, p2}, Lo2/u;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz p2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo p0, "iuemsisslns  ns"

    const-string p0, " essuillsinnss "

    const/4 v8, 0x7

    const-string p0, "enssol ssu niil"

    const-string/jumbo p0, "session is null"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1, p0}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p0, p1}, Lo2/c;->h(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {}, Ld3/b;->d()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    aget-object v2, v2, v3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 v0, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    aget-object p2, p2, v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v3, "odeimbniss"

    const-string/jumbo v3, "osemisnisd"

    const/4 v8, 0x0

    const-string/jumbo v3, "issi_sunde"

    const-string/jumbo v3, "session_id"

    const/4 v8, 0x0

    invoke-virtual {v0, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string p1, "eatd"

    const-string p1, "date"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, p1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo p1, "ietm"

    const-string/jumbo p1, "meit"

    const/4 v8, 0x7

    const-string/jumbo p1, "mtei"

    const-string/jumbo p1, "time"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance p1, Lcom/engagelab/privates/core/api/MTReporter;

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-direct {p1}, Lcom/engagelab/privates/core/api/MTReporter;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo p2, "oicuht_plcanv"

    const-string/jumbo p2, "iahtoe_clvncu"

    const/4 v8, 0x2

    const-string p2, "active_launch"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/core/api/MTReporter;->e(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p1, p2}, Lcom/engagelab/privates/core/api/MTReporter;->d(Ljava/lang/String;)Lcom/engagelab/privates/core/api/MTReporter;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance p2, Landroid/os/Bundle;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, v5, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p0, v4, p2}, Lq2/a;->k(Landroid/content/Context;ILandroid/os/Bundle;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo p2, "usalfdorq scbgp Fneoiedro"

    const-string p2, "flso borau eirdpgneFcdseo"

    const/4 v8, 0x3

    const-string p2, "ersF oue arfslsdeicpdnorg"

    const-string/jumbo p2, "processForeground failed "

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v1, p0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x0

    return-void
.end method


# virtual methods
.method public c(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-boolean v0, p0, Lo2/u;->c:Z

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-wide v0, p0, Lo2/u;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    cmp-long v0, v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const-string p1, "eeimtTuMnsvuBiAs"

    const-string p1, "cuAneiuvetMTssiB"

    const/4 v5, 0x5

    const-string/jumbo p1, "nAssoMscBiieutev"

    const-string p1, "MTActiveBusiness"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v0, "ugdotbotFcpdigaaenei oTm krr  lTsBr0ons"

    const-string v0, " rrdBiapToorgslgae nikcdou0  FTosotetnm"

    const/4 v5, 0x7

    const-string/jumbo v0, "oBc0aTuno edTlsodoke urmnuF giriatso gt"

    const-string/jumbo v0, "toBackground lastToForegroundTime is 0 "

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1, v0}, Lb3/a;->h(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-wide v2, p0, Lo2/u;->a:J

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1, v0, v1, v2, v3}, Lo2/u;->d(Landroid/content/Context;JJ)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-wide v0, p0, Lo2/u;->b:J

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1, v0, v1}, Lo2/c;->g(Landroid/content/Context;J)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method public e(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-boolean v0, p0, Lo2/u;->c:Z

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-wide v2, p0, Lo2/u;->b:J

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1}, Lo2/c;->p(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    iput-wide v2, p0, Lo2/u;->b:J

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-wide v2, p0, Lo2/u;->b:J

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    sub-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-wide/16 v4, 0x7530

    const-wide/16 v4, 0x7530

    const/4 v7, 0x2

    const-wide/16 v4, 0x7530

    const-wide/16 v4, 0x7530

    const/4 v7, 0x7

    const/4 v6, 0x0

    cmp-long v2, v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-gez v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-void

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-wide v0, p0, Lo2/u;->a:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1, v0, v1}, Lo2/c;->m(Landroid/content/Context;J)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p1, v0, v1}, Lo2/u;->f(Landroid/content/Context;J)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lo2/u;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method
