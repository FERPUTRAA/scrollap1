.class public interface abstract annotation Lp2/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;
