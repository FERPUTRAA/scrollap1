.class public interface abstract annotation Lp2/a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;
