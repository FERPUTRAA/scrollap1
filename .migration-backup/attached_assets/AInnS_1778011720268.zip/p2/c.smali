.class public interface abstract annotation Lp2/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;
