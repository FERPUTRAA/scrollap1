.class public final synthetic Li2/a;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(J)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i so~@s.oS b@mi@f//c4 ~bo@on~~@~u~@~rK~ti~yo  ~o  @b~@@a@  @@~~~@~ ~~tl@~l@d1~ ~~M  @ @v   -~@@f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/16 v0, 0x20

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    ushr-long v0, p0, v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    xor-long/2addr p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    long-to-int p0, p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p0
.end method
