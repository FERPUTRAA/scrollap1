.class public Lc1/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0x493e0

.field public static final b:Ljava/lang/String; = "1"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
