.class public Ln3/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/tasks/OnCompleteListener;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/android/gms/tasks/OnCompleteListener<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field private static final b:Ljava/lang/String; = "MTGoogleListener"


# instance fields
.field private final a:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Ln3/a;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onComplete(Lcom/google/android/gms/tasks/Task;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@~sMo@b~ ~ aob4~~Kf@ t@ . ~1o@ vbo~  ~@-m@@o~~@@l@@@ ~~~~ i s/ @@/~~ @@@cd~ilyuf~r~   Si~~@~ no@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    const-string v0, "TesnrioeoMeltLGs"

    const/4 v8, 0x0

    const-string/jumbo v0, "oeMmGierglneTstL"

    const-string v0, "MTGoogleListener"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-nez p1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo p1, "nnkeodaolFemo"

    const-string/jumbo p1, "okemFnTenodal"

    const-string p1, "TdoiFbnenloke"

    const-string/jumbo p1, "onTokenFailed"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {}, Lm3/a;->a()Lm3/a;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v2, p0, Ln3/a;->a:Landroid/content/Context;

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    const/16 v3, 0xbbb

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v4, 0x0

    and-int/2addr v8, v4

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    const/16 v5, 0xf3c

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual/range {v1 .. v6}, Lm3/a;->c(Landroid/content/Context;IIII)V

    const/4 v8, 0x4

    return-void

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-nez v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string/jumbo v2, "lnd oeukFoTeoa"

    const-string v2, "TdeaookeFl ino"

    const/4 v8, 0x2

    const-string/jumbo v2, "onTokenFailed "

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/Task;->getException()Ljava/lang/Exception;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {}, Lm3/a;->a()Lm3/a;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object v2, p0, Ln3/a;->a:Landroid/content/Context;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v3, 0xbbb

    const/4 v7, 0x1

    move v8, v7

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/16 v5, 0xf3c

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Lm3/a;->c(Landroid/content/Context;IIII)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-void

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/Task;->getResult()Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast p1, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v1, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string p1, " mbengnploee TteskpedoyiFitntok:"

    const-string p1, "i geebopstkn:emTtenlani ytFeodok"

    const/4 v8, 0x4

    const-string/jumbo p1, "syomntadq ieeoFlntnee :e Tkpogti"

    const-string/jumbo p1, "onTokenFailed:get token is empty"

    const/4 v7, 0x3

    move v8, v7

    invoke-static {v0, p1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {}, Lm3/a;->a()Lm3/a;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v2, p0, Ln3/a;->a:Landroid/content/Context;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v3, 0xbbb

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/16 v5, 0xf3c

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v6, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual/range {v1 .. v6}, Lm3/a;->c(Landroid/content/Context;IIII)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const-string v2, "esssn u scutn:SiT entoekcgoo"

    const-string/jumbo v2, "o e ttuegisucnooksseTk Snn:c"

    const/4 v8, 0x2

    const-string v2, "eosmn toskgu e:sTc oncteiSnk"

    const-string/jumbo v2, "onTokenSuccess:get token is "

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v1}, Lb3/a;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {}, Lm3/a;->a()Lm3/a;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v1, p0, Ln3/a;->a:Landroid/content/Context;

    const/4 v8, 0x6

    const/4 v2, 0x6

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v1, p1, v2}, Lm3/a;->d(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    return-void
.end method
