.class public final Ln2/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "com.drake.statusbar"

.field public static final c:Ljava/lang/String; = "release"

.field public static final d:I = 0x1

.field public static final e:Ljava/lang/String; = "1.0"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method
