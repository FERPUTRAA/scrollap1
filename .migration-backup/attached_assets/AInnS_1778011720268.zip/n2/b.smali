.class public final Ln2/b;
.super Ljava/lang/Object;


# static fields
.field private static final a:I


# direct methods
.method private static final A(Landroid/content/Context;Landroid/view/ViewGroup;I)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const v0, 0x102002b

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Landroid/view/View;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {v1, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Landroid/view/View;->setId(I)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, -0x1

    const/4 v4, 0x4

    invoke-static {p0}, Ln2/b;->e(Landroid/content/Context;)I

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0, v2, p0}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p2}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method

.method public static final B(Landroidx/fragment/app/Fragment;I)Lkotlin/s2;
    .locals 3
    .param p0    # Landroidx/fragment/app/Fragment;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "lusrsohBsoCtai$ta$ts"

    const-string v0, "i$sahtroslraot$BCuts"

    const/4 v2, 0x2

    const-string v0, "ChtmatsrsBot$alrsiuo"

    const-string v0, "$this$statusBarColor"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1}, Ln2/b;->C(Landroid/app/Activity;I)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public static final C(Landroid/app/Activity;I)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "lCsaomtisBshoatu$rto"

    const-string v0, "$irmrCssultBootshata"

    const-string/jumbo v0, "rBsaCbusarihtltoots$"

    const-string v0, "$this$statusBarColor"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Landroid/view/Window;->setStatusBarColor(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static final D(Landroidx/fragment/app/Fragment;I)Lkotlin/s2;
    .locals 3
    .param p0    # Landroidx/fragment/app/Fragment;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const-string/jumbo v0, "rt$$oChRairetlasBsostos"

    const/4 v2, 0x2

    const-string/jumbo v0, "oelr$auCsu$tosrBhRsitts"

    const-string v0, "$this$statusBarColorRes"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0, p1}, Ln2/b;->E(Landroid/app/Activity;I)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static final E(Landroid/app/Activity;I)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "rutosltpsrRCsB$ah$tasbo"

    const-string/jumbo v0, "tor$$btrsalhsRsiotsCuaB"

    const/4 v2, 0x4

    const-string/jumbo v0, "tlisreasqs$R$toohstruaB"

    const-string v0, "$this$statusBarColorRes"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p1}, Ln2/b;->C(Landroid/app/Activity;I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public static final F(Landroid/view/View;)V
    .locals 5
    .param p0    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p0, v2, v0, v1}, Ln2/b;->H(Landroid/view/View;ZILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public static final G(Landroid/view/View;Z)V
    .locals 4
    .param p0    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "susri$ghsasiuntM$t"

    const-string v0, "Mrastauu$$sgtshiin"

    const/4 v3, 0x6

    const-string v0, "h$gmitanM$sssitaut"

    const-string v0, "$this$statusMargin"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Ln2/b;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    iget p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v3, 0x5

    if-ge p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    sub-int/2addr p1, v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    iget p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-lt p1, v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/2addr p1, v0

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    iput p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string p1, "alduonyogyuom-opPnaan.MpnalsbilnatenoL.ntlrtGuacs t vnrei od w icero r.ipVua t"

    const-string p1, ". eocoopra reiolyuuitisevaulntolLwMVaPanwr aranl.gd nt i -.pGnmocb ydsatnnntup"

    const/4 v3, 0x2

    const-string p1, "cns bb oota ol dawd.gn.celtLuoGn-ntt  nrlauauyVntnla oMsreypii.vPeeiniuopramar"

    const-string/jumbo p1, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw p0
.end method

.method public static synthetic H(Landroid/view/View;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x7

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/4 p1, 0x0

    :cond_0
    const/4 v0, 0x5

    move v1, v0

    invoke-static {p0, p1}, Ln2/b;->G(Landroid/view/View;Z)V

    const/4 v1, 0x6

    return-void
.end method

.method public static final I(Landroid/view/View;)V
    .locals 5
    .param p0    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0, v2, v0, v1}, Ln2/b;->K(Landroid/view/View;ZILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method public static final J(Landroid/view/View;Z)V
    .locals 5
    .param p0    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v3, 0x0

    move v4, v3

    const-string v0, "asdt$dutugiPsnqst$i"

    const-string v0, "asdsidt$qniPugst$at"

    const/4 v4, 0x0

    const-string v0, "$tdsPitpsani$uashdg"

    const-string v0, "$this$statusPadding"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    instance-of v0, p0, Landroid/widget/RelativeLayout;

    const/4 v4, 0x3

    if-nez v0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Ln2/b;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-lez v2, :cond_0

    const/4 v4, 0x5

    add-int/2addr v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ge p1, v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    sub-int/2addr v1, v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0, p1, v1, v0, v2}, Landroid/view/View;->setPadding(IIII)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-lt p1, v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-int/2addr v1, v0

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, p1, v1, v0, v2}, Landroid/view/View;->setPadding(IIII)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string p1, "gaoPedurqse sdUtptr eudtf eli oyivasupnanatstsoL"

    const-string p1, "a suvttylsLtsfsPornuuepatpeood dr n Uaidstegaeti"

    const-string/jumbo p1, "vRspoosepteaoaidt enutruslPt se rtusa dftaUydinL"

    const-string p1, "Unsupported set statusPadding for RelativeLayout"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw p0
.end method

.method public static synthetic K(Landroid/view/View;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1}, Ln2/b;->J(Landroid/view/View;Z)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public static final L(Landroid/app/Activity;)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "\u5efa\u8bae\u4f7f\u7528immersive\u53d6\u4ee3, \u56e0\u4e3a\u8be5\u51fd\u6570\u4f1a\u5f71\u54cd\u952e\u76d8\u906e\u6321\u89e3\u51b3\u65b9\u6848"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "immersive"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p0, v2, v0, v1, v0}, Ln2/b;->O(Landroid/app/Activity;ZLjava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public static final M(Landroid/app/Activity;Z)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "\u5efa\u8bae\u4f7f\u7528immersive\u53d6\u4ee3, \u56e0\u4e3a\u8be5\u51fd\u6570\u4f1a\u5f71\u54cd\u952e\u76d8\u906e\u6321\u89e3\u51b3\u65b9\u6848"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "immersive"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, p1, v0, v1, v0}, Ln2/b;->O(Landroid/app/Activity;ZLjava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public static final N(Landroid/app/Activity;ZLjava/lang/Boolean;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Boolean;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "\u5efa\u8bae\u4f7f\u7528immersive\u53d6\u4ee3, \u56e0\u4e3a\u8be5\u51fd\u6570\u4f1a\u5f71\u54cd\u952e\u76d8\u906e\u6321\u89e3\u51b3\u65b9\u6848"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "immersive"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "s$tmhnau$nemstlcr"

    const-string v0, "$h$msleatstucntnr"

    const/4 v2, 0x2

    const-string/jumbo v0, "iestonc$a$hslutnr"

    const-string v0, "$this$translucent"

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/high16 v0, 0x4000000

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/Window;->clearFlags(I)V

    :goto_0
    const/4 v2, 0x3

    if-eqz p2, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0, p1}, Ln2/b;->b(Landroid/app/Activity;Z)V

    :cond_1
    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public static synthetic O(Landroid/app/Activity;ZLjava/lang/Boolean;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    and-int/lit8 p4, p3, 0x1

    const/4 v1, 0x2

    if-eqz p4, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 p1, 0x1

    move v1, p1

    :cond_0
    const/4 v0, 0x3

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x7

    if-eqz p3, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p2, 0x0

    :cond_1
    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Ln2/b;->N(Landroid/app/Activity;ZLjava/lang/Boolean;)V

    const/4 v1, 0x0

    return-void
.end method

.method public static final a(Landroid/app/Activity;)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0, v2, v0, v1}, Ln2/b;->c(Landroid/app/Activity;ZILjava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public static final b(Landroid/app/Activity;Z)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "oMta$b$rdoiedk"

    const-string v0, "aehrotkddoi$$M"

    const/4 v4, 0x7

    const-string v0, "Mthra$uk$dsode"

    const-string v0, "$this$darkMode"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "ipnwob"

    const-string/jumbo v1, "odnwib"

    const/4 v4, 0x5

    const-string/jumbo v1, "iwqowd"

    const-string/jumbo v1, "window"

    const/4 v3, 0x4

    move v4, v3

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v2, "ews.codVwiedroui"

    const-string/jumbo v2, "oeedodu.iwciVwrn"

    const/4 v4, 0x3

    const-string v2, "ewVmndiocred.iww"

    const-string/jumbo v2, "window.decorView"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    or-int/lit16 p1, v0, 0x2000

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    and-int/lit16 p1, v0, -0x2001

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public static synthetic c(Landroid/app/Activity;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 p3, 0x0

    const/4 p3, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    and-int/2addr p2, p3

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    move p1, p3

    move p1, p3

    const/4 v1, 0x3

    move p1, p3

    move p1, p3

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1}, Ln2/b;->b(Landroid/app/Activity;Z)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static final d(Landroid/content/Context;)I
    .locals 7
    .param p0    # Landroid/content/Context;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "mdepo"

    const-string v2, "empdn"

    const/4 v6, 0x7

    const-string v2, "beimn"

    const-string v2, "dimen"

    const/4 v6, 0x6

    const-string v3, "doqardu"

    const-string/jumbo v3, "oqridad"

    const/4 v6, 0x4

    const-string/jumbo v3, "pdraond"

    const-string v3, "android"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const-string/jumbo v4, "ibvrhsgiqtnahgie_ta_n"

    const-string/jumbo v4, "iisrhi_hgntna_tgveoab"

    const/4 v6, 0x5

    const-string v4, "bgsr_aiaohatnetgiv_in"

    const-string/jumbo v4, "navigation_bar_height"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, v4, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-lez v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    return v0
.end method

.method public static final e(Landroid/content/Context;)I
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v4, 0x4

    move v5, v4

    if-eqz p0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "enimm"

    const/4 v5, 0x3

    const-string/jumbo v1, "idemn"

    const-string v1, "dimen"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v2, "rdonoad"

    const/4 v5, 0x4

    const-string/jumbo v2, "ndirodo"

    const-string v2, "android"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo v3, "tigb_bhht_etsausb"

    const-string v3, "_uhgtbatesthsri_b"

    const/4 v5, 0x5

    const-string v3, "eathuhustrtgb__as"

    const-string/jumbo v3, "status_bar_height"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-lez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 p0, 0x18

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    int-to-float p0, p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v1, "eRusrgsp)tyoc.meSse(t"

    const-string v1, "Ssmer.uegR(sye)ousctt"

    const-string/jumbo v1, "osesRgscquyttmSe.)re("

    const-string v1, "Resources.getSystem()"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x5

    move v4, v1

    move v4, v1

    const/4 v5, 0x2

    invoke-static {v1, p0, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    float-to-int p0, p0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    return p0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    return p0
.end method

.method public static final f(Landroid/app/Activity;)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ObsoleteSdkInt"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    invoke-static {p0, v2, v0, v1, v0}, Ln2/b;->k(Landroid/app/Activity;ILjava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method public static final g(Landroid/app/Activity;I)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ObsoleteSdkInt"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1, v0}, Ln2/b;->k(Landroid/app/Activity;ILjava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public static final h(Landroid/app/Activity;ILjava/lang/Boolean;)V
    .locals 7
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Boolean;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ObsoleteSdkInt"
        }
    .end annotation

    .annotation build Lh8/i;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v0, "$ispvmish$strie"

    const-string v0, "heesitvp$iims$r"

    const/4 v6, 0x6

    const-string v0, "$this$immersive"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/high16 v0, -0x80000000

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/high16 v1, 0x4000000

    const/4 v5, 0x0

    move v6, v5

    const-string v2, ".iemcnqowdVdrwwe"

    const-string/jumbo v2, "w.Vdwcinqorweeod"

    const/4 v6, 0x0

    const-string/jumbo v2, "weirocodVdiw.one"

    const-string/jumbo v2, "window.decorView"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v3, "sowwib"

    const-string/jumbo v3, "wdsiow"

    const/4 v6, 0x6

    const-string/jumbo v3, "uwniwo"

    const-string/jumbo v3, "window"

    const/4 v5, 0x5

    move v6, v5

    if-eqz p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v4, v1}, Landroid/view/Window;->clearFlags(I)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    and-int/lit16 v1, v1, 0x400

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    and-int/lit16 v1, v1, 0x100

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v4, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v4, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x4

    invoke-virtual {v4, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroid/view/Window;->setStatusBarColor(I)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v4, v1}, Landroid/view/Window;->clearFlags(I)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    or-int/lit16 v1, v1, 0x400

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    or-int/lit16 v1, v1, 0x100

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v4, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v4, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v4, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Landroid/view/Window;->setStatusBarColor(I)V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz p2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p0, p1}, Ln2/b;->b(Landroid/app/Activity;Z)V

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void
.end method

.method public static final i(Landroid/app/Activity;Landroid/view/View;)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    const/4 v1, 0x2

    move v3, v1

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    invoke-static {p0, p1, v0, v1, v0}, Ln2/b;->l(Landroid/app/Activity;Landroid/view/View;Ljava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public static final j(Landroid/app/Activity;Landroid/view/View;Ljava/lang/Boolean;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Boolean;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "tsevii$phrmsm$m"

    const-string/jumbo v0, "viimretsmm$sh$e"

    const-string v0, "eemhisirq$i$stv"

    const-string v0, "$this$immersive"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const-string/jumbo v0, "iwve"

    const-string/jumbo v0, "wevi"

    const/4 v2, 0x1

    const-string v0, "eviw"

    const-string/jumbo v0, "view"

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    instance-of v0, p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Ln2/b;->h(Landroid/app/Activity;ILjava/lang/Boolean;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static synthetic k(Landroid/app/Activity;ILjava/lang/Boolean;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    and-int/lit8 p4, p3, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x6

    if-eqz p4, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x2

    if-eqz p3, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p2, 0x0

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Ln2/b;->h(Landroid/app/Activity;ILjava/lang/Boolean;)V

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static synthetic l(Landroid/app/Activity;Landroid/view/View;Ljava/lang/Boolean;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p2, 0x0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Ln2/b;->j(Landroid/app/Activity;Landroid/view/View;Ljava/lang/Boolean;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public static final m(Landroid/app/Activity;)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "$estimsosimhteviExi"

    const-string v0, "ehtsoEiiieirsxm$vmt"

    const/4 v3, 0x6

    const-string v0, "$mEmxsmhsiietvieir$"

    const-string v0, "$this$immersiveExit"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/high16 v1, 0x4000000

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/high16 v0, -0x80000000

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/Window;->clearFlags(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public static final n(Landroid/app/Activity;I)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1, v0, v1, v0}, Ln2/b;->p(Landroid/app/Activity;ILjava/lang/Boolean;ILjava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public static final o(Landroid/app/Activity;ILjava/lang/Boolean;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Boolean;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, "eimsovrsmiibst$he$"

    const-string/jumbo v0, "ss$$hbsemveermitii"

    const/4 v2, 0x3

    const-string/jumbo v0, "tesisbhveimri$esmR"

    const-string v0, "$this$immersiveRes"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getColor(I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Ln2/b;->h(Landroid/app/Activity;ILjava/lang/Boolean;)V

    const/4 v2, 0x1

    return-void
.end method

.method public static synthetic p(Landroid/app/Activity;ILjava/lang/Boolean;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p2, 0x0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Ln2/b;->o(Landroid/app/Activity;ILjava/lang/Boolean;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method

.method public static final q(Landroid/app/Activity;)Z
    .locals 9
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x2

    if-eqz p0, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v2, "uduwni"

    const-string/jumbo v2, "uniwwd"

    const/4 v8, 0x4

    const-string v2, "dpwnoi"

    const-string/jumbo v2, "window"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    instance-of v2, v1, Landroid/view/ViewGroup;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-nez v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v1, 0x0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    check-cast v1, Landroid/view/ViewGroup;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eqz v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    move v3, v0

    move v3, v0

    const/4 v8, 0x0

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    if-ge v3, v2, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v5, "p()t.CepqdgAtliv"

    const-string/jumbo v5, "ipe.tlCpd)igAv(t"

    const/4 v8, 0x2

    const-string v5, ".gsvpde)C(Altihi"

    const-string/jumbo v5, "vp.getChildAt(i)"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v6, "lexm.nhC)(tvpitoiqgAettc"

    const-string/jumbo v6, "tvi.(hetqoCpe)x.cAgtlint"

    const/4 v8, 0x1

    const-string/jumbo v6, "o.tCohtilenA.tvcxdi(gept"

    const-string/jumbo v6, "vp.getChildAt(i).context"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v4, v6}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v6, -0x1

    move v8, v6

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eq v4, v6, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v6, v5}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v6}, Landroid/view/View;->getId()I

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v5, "uBcvkbinnotdBaingarsraa"

    const-string/jumbo v5, "ntsavBkidrBcarngaonguai"

    const/4 v8, 0x2

    const-string/jumbo v5, "rkoanguaouBBigdrctvnnia"

    const-string/jumbo v5, "navigationBarBackground"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v5, v4}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v4, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 p0, 0x1

    const/4 v7, 0x6

    const/4 v7, 0x4

    return p0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    return v0
.end method

.method public static final r(Landroidx/appcompat/app/AppCompatActivity;I)V
    .locals 3
    .param p0    # Landroidx/appcompat/app/AppCompatActivity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo v0, "s$i$taBproncrAktsatdgmhouenB"

    const-string v0, "e$smBitaatsrtonkAcrudgBcohn$"

    const/4 v2, 0x3

    const-string/jumbo v0, "re$rBgitqckitastsnoBcuon$Aha"

    const-string v0, "$this$setActionBarBackground"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->getSupportActionBar()Landroidx/appcompat/app/a;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p0, v0}, Landroidx/appcompat/app/a;->T(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public static final s(Landroidx/appcompat/app/AppCompatActivity;I)V
    .locals 4
    .param p0    # Landroidx/appcompat/app/AppCompatActivity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v3, 0x6

    const-string/jumbo v0, "kRsisooaechsurescBgrtaittA$nB$o"

    const-string/jumbo v0, "nsocoeRghiBaBrskisturotAnta$$ce"

    const/4 v3, 0x2

    const-string/jumbo v0, "tkgmec$csonnhireasuBaBdrtoA$iRt"

    const-string v0, "$this$setActionBarBackgroundRes"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->getSupportActionBar()Landroidx/appcompat/app/a;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getColor(I)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-direct {v1, p0}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroidx/appcompat/app/a;->T(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method

.method public static final t(Landroidx/appcompat/app/AppCompatActivity;)V
    .locals 4
    .param p0    # Landroidx/appcompat/app/AppCompatActivity;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "tsacootBieeTnrtnbahsnipas$Arr"

    const-string/jumbo v0, "pAieBbto$nnaecrsTa$hrstnsairt"

    const-string/jumbo v0, "snsBobtreAtrhnpnattTi$aarsie$"

    const-string v0, "$this$setActionBarTransparent"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/app/AppCompatActivity;->getSupportActionBar()Landroidx/appcompat/app/a;

    move-result-object p0

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/app/a;->T(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public static final u(Landroid/app/Activity;)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-static {p0, v2, v0, v1}, Ln2/b;->w(Landroid/app/Activity;ZILjava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method public static final v(Landroid/app/Activity;Z)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v0, "uhssllueetcn$Fru$et"

    const-string/jumbo v0, "ls$$neuFssuhlcrette"

    const/4 v4, 0x5

    const-string/jumbo v0, "les$er$ptesntcFshli"

    const-string v0, "$this$setFullscreen"

    const/4 v3, 0x5

    move v4, v3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v1, "dwqnpi"

    const-string/jumbo v1, "wpniwd"

    const/4 v4, 0x7

    const-string/jumbo v1, "woswid"

    const-string/jumbo v1, "window"

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v2, ".ocmdVdeqwieowwn"

    const-string/jumbo v2, "r.eeodViqwncwodw"

    const/4 v4, 0x1

    const-string/jumbo v2, "iwrdodVcweo.eino"

    const-string/jumbo v2, "window.decorView"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {p0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    or-int/lit8 p1, v0, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/lit16 p1, p1, 0x100

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    or-int/lit16 p1, v0, 0x100

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    and-int/lit8 p1, p1, -0x5

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method public static synthetic w(Landroid/app/Activity;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p3, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    and-int/2addr p2, p3

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    move p1, p3

    move p1, p3

    const/4 v1, 0x7

    move p1, p3

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-static {p0, p1}, Ln2/b;->v(Landroid/app/Activity;Z)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static final x(Landroid/app/Activity;)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    and-int/2addr v4, v0

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0, v2, v0, v1}, Ln2/b;->z(Landroid/app/Activity;ZILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public static final y(Landroid/app/Activity;Z)V
    .locals 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "Bvtreb$gaNinstiaaohssi"

    const-string/jumbo v0, "ntsrNsieaagaiivhtB$s$o"

    const/4 v4, 0x4

    const-string v0, "aigtrNuiB$staatis$oevn"

    const-string v0, "$this$setNavigationBar"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "dpwiom"

    const-string/jumbo v1, "idnmow"

    const/4 v4, 0x3

    const-string/jumbo v1, "woqdni"

    const-string/jumbo v1, "window"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v2, "owsdicwreoVinwod"

    const-string v2, "edVwowoeicidowrn"

    const/4 v4, 0x4

    const-string v2, "drimoocww.neVdiw"

    const-string/jumbo v2, "window.decorView"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    and-int/lit8 p1, v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    and-int/lit16 p1, p1, 0x1000

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    or-int/lit8 p1, v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    or-int/lit16 p1, p1, 0x1000

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method public static synthetic z(Landroid/app/Activity;ZILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 p3, 0x1

    const/4 v1, 0x0

    move v0, p3

    move v0, p3

    const/4 v1, 0x2

    and-int/2addr p2, p3

    const/4 v1, 0x2

    const/4 v0, 0x7

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    move p1, p3

    move p1, p3

    const/4 v1, 0x1

    move p1, p3

    :cond_0
    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0, p1}, Ln2/b;->y(Landroid/app/Activity;Z)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
