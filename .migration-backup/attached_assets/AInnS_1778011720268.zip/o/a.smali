.class public Lo/a;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static a(II)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~~@@bd~@@ @~bio~i@f~t  @~~c~@@v~1@- t ~b @~~@oom @~ @l/@ ~ ~ fos@u~a~n l ~S@~ ~o@y4/.K M@roi@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    add-int v0, p0, p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    xor-int/2addr p0, v0

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    xor-int/2addr p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    and-int/2addr p0, p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ltz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo p1, "wtfmovorln eegei"

    const-string/jumbo p1, "ltswfeiov geenor"

    const-string/jumbo p1, "tle orfregnwvoeo"

    const-string/jumbo p1, "integer overflow"

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p0
.end method

.method public static b(JJ)J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-long v0, p0, p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    xor-long/2addr p0, v0

    const/4 v3, 0x4

    xor-long/2addr p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    and-long/2addr p0, p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const-wide/16 p2, 0x0

    const-wide/16 p2, 0x0

    const/4 v3, 0x2

    const-wide/16 p2, 0x0

    const-wide/16 p2, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    cmp-long p0, p0, p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ltz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-wide v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo p1, "lroomblofngw "

    const-string p1, "eofmrnw llogo"

    const/4 v3, 0x7

    const-string/jumbo p1, "weolgouolnvfr"

    const-string/jumbo p1, "long overflow"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    throw p0
.end method

.method public static c(DDD)D
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    cmpg-double v0, p0, p2

    const/4 v2, 0x3

    if-gez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-wide p2

    :cond_0
    const/4 v2, 0x7

    cmpl-double p2, p0, p4

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-lez p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-wide p4

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-wide p0
.end method

.method public static d(FFF)F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    cmpg-float v0, p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-gez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    cmpl-float p1, p0, p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-lez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p2

    :cond_1
    const/4 v1, 0x7

    const/4 v2, 0x4

    return p0
.end method

.method public static e(III)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    if-ge p0, p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-le p0, p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p2

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p0
.end method

.method public static f(JJJ)J
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    cmp-long v0, p0, p2

    const/4 v2, 0x6

    if-gez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-wide p2

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    cmp-long p2, p0, p4

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-lez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-wide p4

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-wide p0
.end method

.method public static g(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    add-int/lit8 p0, p0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo v0, "ntwo orpeeflvrig"

    const-string/jumbo v0, "reglooitwv ofenr"

    const/4 v2, 0x3

    const-string/jumbo v0, "wlvefertqeignoo "

    const-string/jumbo v0, "integer overflow"

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    throw p0
.end method

.method public static h(J)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x1

    cmp-long v0, p0, v0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sub-long/2addr p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p1, " vsnollgfebro"

    const-string p1, "eoglnb vorflo"

    const-string p1, " ofmlenovwrlg"

    const-string/jumbo p1, "long overflow"

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw p0
.end method

.method public static i(I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const v0, 0x7fffffff

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    add-int/lit8 p0, p0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x0

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo v0, "luieofw enrovert"

    const-string/jumbo v0, "ioengturlrfe vwe"

    const/4 v2, 0x2

    const-string v0, "gl tebniofovrewr"

    const-string/jumbo v0, "integer overflow"

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    throw p0
.end method

.method public static j(J)J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    cmp-long v0, p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-long/2addr p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-wide p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p1, "pf oenulvglwr"

    const-string/jumbo p1, "oegnlvwporfl "

    const/4 v3, 0x1

    const-string/jumbo p1, "oeolwlrpnov f"

    const-string/jumbo p1, "long overflow"

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw p0
.end method

.method public static k(II)I
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    int-to-long v0, p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    int-to-long p0, p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    mul-long/2addr v0, p0

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    long-to-int p0, v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    int-to-long v2, p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    cmp-long p1, v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return p0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string p1, "egr toqvqiweolre"

    const-string p1, "eno rgevqroleiwt"

    const/4 v5, 0x7

    const-string/jumbo p1, "ifsneg eveowrtlo"

    const-string/jumbo p1, "integer overflow"

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    throw p0
.end method

.method public static l(JJ)J
    .locals 8

    const/4 v7, 0x7

    mul-long v0, p0, p2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {p0, p1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p2, p3}, Ljava/lang/Math;->abs(J)J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    or-long/2addr v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/16 v4, 0x1f

    const/4 v7, 0x4

    const/4 v6, 0x3

    ushr-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz v2, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    cmp-long v2, p2, v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    div-long v2, v0, p2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    cmp-long v2, v2, p0

    const/4 v6, 0x1

    move v7, v6

    if-nez v2, :cond_1

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v7, 0x5

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    cmp-long p0, p0, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez p0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-wide/16 p0, -0x1

    const-wide/16 p0, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    cmp-long p0, p2, p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo p1, "sglmrfovone w"

    const-string p1, " lswfenovgroo"

    const-string/jumbo p1, "vnolol fwegro"

    const-string/jumbo p1, "long overflow"

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    throw p0

    :cond_2
    :goto_0
    return-wide v0
.end method

.method public static m(I)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/high16 v0, -0x80000000

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    neg-int p0, p0

    const/4 v1, 0x0

    and-int/2addr v2, v1

    return p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x4

    const-string/jumbo v0, "rwneob ifveotlmr"

    const-string v0, "etrmviogw elrofn"

    const/4 v2, 0x6

    const-string v0, "eonlriuegftrwove"

    const-string/jumbo v0, "integer overflow"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p0
.end method

.method public static n(J)J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x2

    cmp-long v0, p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    neg-long p0, p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-wide p0

    :cond_0
    const/4 v3, 0x4

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const-string/jumbo p1, "lnv looperoof"

    const-string/jumbo p1, "nreoo lvlogof"

    const-string/jumbo p1, "nl roewgqlofo"

    const-string/jumbo p1, "long overflow"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p0
.end method

.method public static o(II)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sub-int v0, p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    xor-int/2addr p1, p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    xor-int/2addr p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    and-int/2addr p0, p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-ltz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string p1, "gfsreneobrtelw o"

    const-string/jumbo p1, "orownbgeertl evf"

    const/4 v2, 0x4

    const-string p1, "enwmv trofilegor"

    const-string/jumbo p1, "integer overflow"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p0
.end method

.method public static p(JJ)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    sub-long v0, p0, p2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    xor-long/2addr p2, p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    xor-long/2addr p0, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    and-long/2addr p0, p2

    const-wide/16 p2, 0x0

    const/4 v3, 0x1

    const-wide/16 p2, 0x0

    const-wide/16 p2, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    cmp-long p0, p0, p2

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ltz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-wide v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p1, "u llovnrgofeo"

    const-string p1, "g evoluoflonr"

    const/4 v3, 0x2

    const-string/jumbo p1, "long overflow"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw p0
.end method

.method public static q(J)I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    long-to-int v0, p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    int-to-long v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    cmp-long p0, v1, p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo p1, "reoetrgpowei vln"

    const/4 v4, 0x0

    const-string/jumbo p1, "toev boirfelnwrg"

    const-string/jumbo p1, "integer overflow"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    throw p0
.end method
