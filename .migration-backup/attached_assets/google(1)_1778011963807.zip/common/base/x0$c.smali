.class Lcom/google/common/base/x0$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/w0;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/w0<",
        "TA;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field final f:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "TA;+TB;>;"
        }
    .end annotation
.end field

.field final p:Lcom/google/common/base/w0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/w0<",
            "TB;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lcom/google/common/base/w0;Lcom/google/common/base/s;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "p",
            "f"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/w0<",
            "TB;>;",
            "Lcom/google/common/base/s<",
            "TA;+TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    check-cast p1, Lcom/google/common/base/w0;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    check-cast p1, Lcom/google/common/base/s;

    iput-object p1, p0, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/base/w0;Lcom/google/common/base/s;Lcom/google/common/base/x0$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/common/base/x0$c;-><init>(Lcom/google/common/base/w0;Lcom/google/common/base/s;)V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TA;)Z"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/common/base/x0$c;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast p1, Lcom/google/common/base/x0$c;

    const/4 v4, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v3, 0x7

    move v4, v3

    iget-object v2, p1, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0, v2}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object p1, p1, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0, p1}, Lcom/google/common/base/w0;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    and-int/2addr v4, v1

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    xor-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    iget-object v1, p0, Lcom/google/common/base/x0$c;->p:Lcom/google/common/base/w0;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, "("

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/common/base/x0$c;->f:Lcom/google/common/base/s;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method
