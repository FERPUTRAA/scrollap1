.class Lcom/google/common/base/e$a0;
.super Lcom/google/common/base/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a0"
.end annotation


# instance fields
.field private final b:Ljava/lang/String;

.field private final c:[C

.field private final d:[C


# direct methods
.method constructor <init>(Ljava/lang/String;[C[C)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "description",
            "rangeStarts",
            "rangeEnds"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/common/base/e;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/common/base/e$a0;->b:Ljava/lang/String;

    const/4 v4, 0x7

    move v5, v4

    iput-object p2, p0, Lcom/google/common/base/e$a0;->c:[C

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-object p3, p0, Lcom/google/common/base/e$a0;->d:[C

    const/4 v5, 0x7

    array-length p1, p2

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    array-length v0, p3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne p1, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    move p1, v1

    move p1, v1

    const/4 v5, 0x2

    move p1, v1

    move p1, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    move p1, v2

    move p1, v2

    const/4 v5, 0x2

    move p1, v2

    :goto_0
    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    move p1, v2

    move p1, v2

    move p1, v2

    move p1, v2

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    array-length v0, p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ge p1, v0, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    aget-char v0, p2, p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    aget-char v3, p3, p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-gt v0, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v5, 0x0

    move v0, v1

    move v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-int/lit8 v0, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    array-length v3, p2

    const/4 v5, 0x3

    if-ge v0, v3, :cond_3

    const/4 v4, 0x2

    move v5, v4

    aget-char p1, p3, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    aget-char v3, p2, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ge p1, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    move p1, v1

    move p1, v1

    const/4 v5, 0x2

    move p1, v1

    move p1, v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    move p1, v2

    move p1, v2

    const/4 v5, 0x4

    move p1, v2

    move p1, v2

    :goto_3
    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->d(Z)V

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    move p1, v0

    move p1, v0

    const/4 v5, 0x0

    move p1, v0

    move p1, v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_1

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x4

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@osM~Sd@ ~b l/   @@c@@@ @t~ @@u @ @@ ~~ Kvbn~.yorio ~~s1@m ~t~o@@/ofb 4@i~~a~@ ~ @~~o- f~~~@i~l~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/base/e$a0;->c:[C

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, p1}, Ljava/util/Arrays;->binarySearch([CC)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    not-int v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    sub-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ltz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/common/base/e$a0;->d:[C

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    aget-char v0, v2, v0

    if-gt p1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p1, Ljava/lang/Character;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/base/e$a0;->b:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method
