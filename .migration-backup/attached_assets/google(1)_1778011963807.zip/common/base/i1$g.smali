.class Lcom/google/common/base/i1$g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/h1<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field final instance:Ljava/lang/Object;
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "instance"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~s~~f u~~ @4@~@~~@nob@o@.b  ll  b@~v~  mi@oc@@ ~~~  d @@t@1~@~~M~ @y@tar~  ~@ o/~/s@- @~K@fo~iS"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    instance-of v0, p1, Lcom/google/common/base/i1$g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    and-int/2addr v2, v1

    check-cast p1, Lcom/google/common/base/i1$g;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p1, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x6

    or-int/2addr v2, v1

    return p1
.end method

.method public get()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v3, 0x7

    move v4, v3

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "pssmaepi(IonSueftlcsn"

    const-string/jumbo v1, "itslpaenefncso(usISpr"

    const/4 v3, 0x7

    const-string/jumbo v1, "t.(pouieInrlfacoesnsp"

    const-string v1, "Suppliers.ofInstance("

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/base/i1$g;->instance:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method
