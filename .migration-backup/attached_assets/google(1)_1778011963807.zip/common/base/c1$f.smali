.class public final Lcom/google/common/base/c1$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/c1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# static fields
.field private static final c:Ljava/lang/String; = "Chunk [%s] is not a valid entry"


# instance fields
.field private final a:Lcom/google/common/base/c1;

.field private final b:Lcom/google/common/base/c1;


# direct methods
.method private constructor <init>(Lcom/google/common/base/c1;Lcom/google/common/base/c1;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "outerSplitter",
            "entrySplitter"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/base/c1$f;->a:Lcom/google/common/base/c1;

    const/4 v0, 0x2

    or-int/2addr v1, v0

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p1, Lcom/google/common/base/c1;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/base/c1$f;->b:Lcom/google/common/base/c1;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/base/c1;Lcom/google/common/base/c1;Lcom/google/common/base/c1$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/common/base/c1$f;-><init>(Lcom/google/common/base/c1;Lcom/google/common/base/c1;)V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/CharSequence;)Ljava/util/Map;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x4

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/google/common/base/c1$f;->a:Lcom/google/common/base/c1;

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1, p1}, Lcom/google/common/base/c1;->n(Ljava/lang/CharSequence;)Ljava/lang/Iterable;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/google/common/base/c1$f;->b:Lcom/google/common/base/c1;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v2, v1}, Lcom/google/common/base/c1;->a(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Ljava/util/Iterator;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v4, "rds%yCnnth nisieusovl [s  ]aa k"

    const-string/jumbo v4, "tuse% ns syk inrv an ]odahil[tC"

    const/4 v8, 0x1

    const-string/jumbo v4, "s  mdkye%urtnilvo][ h tsnC  aai"

    const-string v4, "Chunk [%s] is not a valid entry"

    const/4 v8, 0x4

    invoke-static {v3, v4, v1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {v0, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    xor-int/lit8 v5, v5, 0x1

    const/4 v8, 0x3

    const-string/jumbo v6, "slctoiu [ yop ]k.nDfaeudm"

    const-string v6, "  Dmypulfa]tsnoueicd%.k ["

    const/4 v8, 0x5

    const-string v6, "Duplicate key [%s] found."

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v5, v6, v3}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v5, v4, v1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x7

    move v8, v7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-interface {v0, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    xor-int/lit8 v2, v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v2, v4, v1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-object p1
.end method
