.class public final synthetic Lcom/google/common/base/k0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Ljava/util/OptionalLong;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s@ iorm~oi@lo uco ~~~.t~v/~@~~~~~   b@b@S4 aK@ ~ yM~ofs~ @@ ~~~b@d n @@t@@1o~f ~@ @l@@~-~@@/~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p0, Ljava/util/OptionalLong;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method
