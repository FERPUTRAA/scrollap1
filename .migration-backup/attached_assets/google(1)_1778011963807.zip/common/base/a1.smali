.class public final synthetic Lcom/google/common/base/a1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Iterable;)Ljava/util/Spliterator;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~~b~b d@ @~sf /1@ @@@~  - o@~@ @@~ vt@iM~~@r@@~o4~ o/c.~b S~~Kn~i@@y~o ou@ l@tloi~ @a@ ~ mf ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-interface {p0}, Ljava/lang/Iterable;->spliterator()Ljava/util/Spliterator;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method
