.class public abstract Lcom/google/common/base/e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/w0;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/e$j;,
        Lcom/google/common/base/e$k;,
        Lcom/google/common/base/e$d;,
        Lcom/google/common/base/e$n;,
        Lcom/google/common/base/e$o;,
        Lcom/google/common/base/e$m;,
        Lcom/google/common/base/e$z;,
        Lcom/google/common/base/e$b;,
        Lcom/google/common/base/e$w;,
        Lcom/google/common/base/e$b0;,
        Lcom/google/common/base/e$l;,
        Lcom/google/common/base/e$q;,
        Lcom/google/common/base/e$t;,
        Lcom/google/common/base/e$u;,
        Lcom/google/common/base/e$s;,
        Lcom/google/common/base/e$r;,
        Lcom/google/common/base/e$p;,
        Lcom/google/common/base/e$h;,
        Lcom/google/common/base/e$a0;,
        Lcom/google/common/base/e$e;,
        Lcom/google/common/base/e$g;,
        Lcom/google/common/base/e$c0;,
        Lcom/google/common/base/e$y;,
        Lcom/google/common/base/e$c;,
        Lcom/google/common/base/e$f;,
        Lcom/google/common/base/e$x;,
        Lcom/google/common/base/e$v;,
        Lcom/google/common/base/e$i;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/common/base/w0<",
        "Ljava/lang/Character;",
        ">;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final a:I = 0x10000


# direct methods
.method protected constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method

.method public static G()Lcom/google/common/base/e;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s ~~~@S-@oao~@4o~o@  i ~ib~r~@oi~f@@ ltM~su ~~@@ d @ K~@t@ l. ~vbm@/ @ @ ~n~o@~f1c  y~@~@~~b/@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/e$y;->c:Lcom/google/common/base/e$y;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public static H(Ljava/lang/CharSequence;)Lcom/google/common/base/e;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/common/base/e;->d(Ljava/lang/CharSequence;)Lcom/google/common/base/e;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-virtual {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-object p0
.end method

.method private static L(ILjava/util/BitSet;Ljava/lang/String;)Lcom/google/common/base/e;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "totalCharacters",
            "table",
            "description"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq p0, v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x5

    if-eq p0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/util/BitSet;->length()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/google/common/base/e;->t(II)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1, p2}, Lcom/google/common/base/z0;->a0(Ljava/util/BitSet;Ljava/lang/String;)Lcom/google/common/base/e;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p0, Lcom/google/common/base/e$f;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/base/e$f;-><init>(Ljava/util/BitSet;Ljava/lang/String;Lcom/google/common/base/e$a;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->nextSetBit(I)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    int-to-char p0, p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 p2, p0, 0x1

    invoke-virtual {p1, p2}, Ljava/util/BitSet;->nextSetBit(I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    int-to-char p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lcom/google/common/base/e;->r(CC)Lcom/google/common/base/e$n;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->nextSetBit(I)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-char p0, p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/common/base/e;->G()Lcom/google/common/base/e;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method

.method private static R(C)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v0, 0x6

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-array v0, v0, [C

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    fill-array-data v0, :array_0

    const/4 v6, 0x2

    move v7, v6

    const/4 v1, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x4

    const/4 v7, 0x7

    if-ge v1, v2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    rsub-int/lit8 v3, v1, 0x5

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    and-int/lit8 v4, p0, 0xf

    const/4 v6, 0x3

    move v7, v6

    const-string v5, "C08m5F1379DsB4AE"

    const-string v5, "F6sA59E3DC847B10"

    const/4 v7, 0x3

    const-string v5, "EBC4o03269A5FD17"

    const-string v5, "0123456789ABCDEF"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v5, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    aput-char v4, v0, v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    shr-int/2addr p0, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    int-to-char p0, p0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v0}, Ljava/lang/String;->copyValueOf([C)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object p0

    nop

    :array_0
    .array-data 2
        0x5cs
        0x75s
        0x0s
        0x0s
        0x0s
        0x0s
    .end array-data
.end method

.method public static S()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    move v2, v1

    sget-object v0, Lcom/google/common/base/e$b0;->e:Lcom/google/common/base/e$b0;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public static X()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/base/e$c0;->f:Lcom/google/common/base/e$c0;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic a(C)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/common/base/e;->R(C)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p0
.end method

.method public static c()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/base/e$c;->c:Lcom/google/common/base/e$c;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public static d(Ljava/lang/CharSequence;)Lcom/google/common/base/e;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x7

    move v4, v2

    move v4, v2

    const/4 v5, 0x7

    if-eq v0, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-eq v0, v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v0, Lcom/google/common/base/e$d;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/base/e$d;-><init>(Ljava/lang/CharSequence;)V

    const/4 v5, 0x0

    return-object v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p0}, Lcom/google/common/base/e;->r(CC)Lcom/google/common/base/e$n;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p0

    :cond_1
    const/4 v5, 0x5

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object p0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/common/base/e;->G()Lcom/google/common/base/e;

    move-result-object p0

    const/4 v5, 0x1

    return-object p0
.end method

.method public static f()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/base/e$e;->c:Lcom/google/common/base/e$e;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static g()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/base/e$g;->b:Lcom/google/common/base/e;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static j()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/e$h;->f:Lcom/google/common/base/e$h;

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method private k(Ljava/lang/CharSequence;IICLjava/lang/StringBuilder;Z)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "sequence",
            "start",
            "end",
            "replacement",
            "builder",
            "inMatchingGroup"
        }
    .end annotation

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ge p2, p3, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p6, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p5, p4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p6, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p5, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p6, 0x0

    :cond_1
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1
.end method

.method public static l(Lcom/google/common/base/w0;)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "predicate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/w0<",
            "-",
            "Ljava/lang/Character;",
            ">;)",
            "Lcom/google/common/base/e;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    instance-of v0, p0, Lcom/google/common/base/e;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p0, Lcom/google/common/base/e;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/base/e$j;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/base/e$j;-><init>(Lcom/google/common/base/w0;)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static m(CC)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "startInclusive",
            "endInclusive"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/base/e$k;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/e$k;-><init>(CC)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    return-object v0
.end method

.method public static p()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/e$l;->g:Lcom/google/common/base/e$l;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static q(C)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "match"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    new-instance v0, Lcom/google/common/base/e$m;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/base/e$m;-><init>(C)V

    const/4 v2, 0x1

    return-object v0
.end method

.method private static r(CC)Lcom/google/common/base/e$n;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "c1",
            "c2"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/base/e$n;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/e$n;-><init>(CC)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public static s(C)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "match"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/base/e$o;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/base/e$o;-><init>(C)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method private static t(II)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "totalCharacters",
            "tableLength"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/16 v0, 0x3ff

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-gt p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    mul-int/lit8 p0, p0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    mul-int/lit8 p0, p0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-le p1, p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p0, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0
.end method

.method public static u()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/base/e$p;->b:Lcom/google/common/base/e$p;

    const/4 v2, 0x4

    return-object v0
.end method

.method public static v()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/base/e$q;->c:Lcom/google/common/base/e$q;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public static w()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/base/e$r;->b:Lcom/google/common/base/e$r;

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static x()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/base/e$s;->b:Lcom/google/common/base/e$s;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public static y()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    sget-object v0, Lcom/google/common/base/e$t;->b:Lcom/google/common/base/e$t;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object v0
.end method

.method public static z()Lcom/google/common/base/e;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/base/e$u;->b:Lcom/google/common/base/e$u;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public A(Ljava/lang/CharSequence;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ltz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p1, -0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p1
.end method

.method public abstract B(C)Z
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation
.end method

.method public C(Ljava/lang/CharSequence;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    sub-int/2addr v0, v1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ltz v0, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x6

    move v4, v3

    return p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1
.end method

.method public D(Ljava/lang/CharSequence;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->E(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    xor-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method public E(Ljava/lang/CharSequence;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->n(Ljava/lang/CharSequence;)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1
.end method

.method public F()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/base/e$w;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/base/e$w;-><init>(Lcom/google/common/base/e;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-object v0
.end method

.method public I(Lcom/google/common/base/e;)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/base/e$z;

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/e$z;-><init>(Lcom/google/common/base/e;Lcom/google/common/base/e;)V

    const/4 v2, 0x0

    return-object v0
.end method

.method public J()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/google/common/base/t0;->j(Lcom/google/common/base/e;)Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method K()Lcom/google/common/base/e;
    .locals 8
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v0, Ljava/util/BitSet;

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/util/BitSet;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/base/e;->Q(Ljava/util/BitSet;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/BitSet;->cardinality()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    mul-int/lit8 v2, v1, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/high16 v3, 0x10000

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-gt v2, v3, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/common/base/e;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v1, v0, v2}, Lcom/google/common/base/e;->L(ILjava/util/BitSet;Ljava/lang/String;)Lcom/google/common/base/e;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-object v0

    :cond_0
    const/4 v7, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v2, v3}, Ljava/util/BitSet;->flip(II)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    sub-int/2addr v3, v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/common/base/e;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v4, "egm.nba(t"

    const-string v4, "eg(m.etan"

    const/4 v7, 0x5

    const-string/jumbo v4, "g.nee(u)a"

    const-string v4, ".negate()"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_1

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    add-int/lit8 v4, v4, -0x9

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v4, Lcom/google/common/base/e$a;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v3, v0, v2}, Lcom/google/common/base/e;->L(ILjava/util/BitSet;Ljava/lang/String;)Lcom/google/common/base/e;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {v4, p0, v0, v1}, Lcom/google/common/base/e$a;-><init>(Lcom/google/common/base/e;Lcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    return-object v4
.end method

.method public M(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v6, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->n(Ljava/lang/CharSequence;)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v1, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne v0, v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    add-int/2addr v0, v1

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    array-length v3, p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-ne v0, v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x1

    move v6, v5

    sub-int/2addr v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1, p1, v3, v0}, Ljava/lang/String;-><init>([CII)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    aget-char v3, p1, v0

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Lcom/google/common/base/e;->B(C)Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v6, 0x6

    sub-int v3, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    aget-char v4, p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-char v4, p1, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x0

    goto :goto_1
.end method

.method public N(Ljava/lang/CharSequence;C)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "replacement"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->n(Ljava/lang/CharSequence;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-char p2, p1, v0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x7

    array-length v1, p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    if-ge v0, v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    aget-char v1, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    aput-char p2, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    new-instance p2, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p2, p1}, Ljava/lang/String;-><init>([C)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p2
.end method

.method public O(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "replacement"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->M(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-object p1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-ne v0, v2, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {p2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/common/base/e;->N(Ljava/lang/CharSequence;C)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    return-object p1

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->n(Ljava/lang/CharSequence;)I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v3, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-ne v0, v3, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-object p1

    :cond_2
    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    move v8, v7

    mul-int/lit8 v6, v4, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    div-int/lit8 v6, v6, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    add-int/lit8 v6, v6, 0x10

    const/4 v8, 0x0

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(I)V

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v5, p1, v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    add-int/lit8 v1, v0, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, p1, v1}, Lcom/google/common/base/e;->o(Ljava/lang/CharSequence;I)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-ne v0, v3, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v5, p1, v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object p1
.end method

.method public P(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->M(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const v0, 0xffff

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ltz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    int-to-char v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->set(I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public T(Ljava/lang/CharSequence;C)Ljava/lang/String;
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "replacement"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    add-int/lit8 v1, v0, -0x1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x4

    move v5, v2

    move v5, v2

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-ge v5, v0, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-interface {p1, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v2, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    goto :goto_0

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-le v0, v5, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-eqz v2, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    goto :goto_1

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-nez v5, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-ne v0, v1, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/base/e;->h(Ljava/lang/CharSequence;C)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    goto :goto_2

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    add-int/lit8 v6, v0, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    sub-int v0, v6, v5

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v8, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v9, 0x0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    move v7, p2

    move v7, p2

    const/4 v11, 0x1

    move v7, p2

    move v7, p2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct/range {v3 .. v9}, Lcom/google/common/base/e;->k(Ljava/lang/CharSequence;IICLjava/lang/StringBuilder;Z)Ljava/lang/String;

    move-result-object p1

    :goto_2
    const/4 v11, 0x0

    const/4 v10, 0x5

    return-object p1
.end method

.method public U(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ge v1, v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-nez v2, :cond_0

    const/4 v4, 0x6

    goto :goto_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-le v0, v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_3

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_2

    :cond_3
    :goto_3
    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p1, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p1
.end method

.method public V(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    if-ge v1, v0, :cond_1

    const/4 v4, 0x3

    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-interface {p1, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string p1, ""

    const/4 v4, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v4, 0x3

    const/4 v3, 0x0

    return-object p1
.end method

.method public W(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ltz v0, :cond_1

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p1, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Ljava/lang/Character;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p1
.end method

.method public b(Lcom/google/common/base/e;)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/e$b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/e$b;-><init>(Lcom/google/common/base/e;Lcom/google/common/base/e;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public e(Ljava/lang/Character;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/base/e;->B(C)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p1
.end method

.method public h(Ljava/lang/CharSequence;C)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "replacement"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v1, v0

    move v1, v0

    const/4 v8, 0x0

    move v1, v0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-ge v1, v3, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v4, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ne v2, p2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v2, v3, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eq v1, v2, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    add-int/lit8 v2, v1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-nez v2, :cond_1

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v5, p1, v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v6, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    move v4, p2

    move v4, p2

    const/4 v8, 0x7

    move v4, p2

    move v4, p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v6}, Lcom/google/common/base/e;->k(Ljava/lang/CharSequence;IICLjava/lang/StringBuilder;Z)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-object p1

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    return-object p1
.end method

.method public i(Ljava/lang/CharSequence;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-ge v0, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0, v2}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1
.end method

.method public n(Ljava/lang/CharSequence;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/common/base/e;->o(Ljava/lang/CharSequence;I)I

    move-result p1

    const/4 v1, 0x2

    and-int/2addr v2, v1

    return p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public o(Ljava/lang/CharSequence;I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "start"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lcom/google/common/base/u0;->d0(II)I

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    if-ge p2, v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/google/common/base/e;->B(C)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p2

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p1
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method
