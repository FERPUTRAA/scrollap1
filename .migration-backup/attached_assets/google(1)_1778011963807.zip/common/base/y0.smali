.class final Lcom/google/common/base/y0;
.super Lcom/google/common/base/p0;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/base/p0<",
        "TT;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final reference:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "reference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/base/p0;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public b()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TT;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ltsn bi@i@/@~co1f@~b~~~b ~  ~@ ~o~S4 ~ K @ @o u~Ml @~m/f~@@~t ~ ~d-~~ ~@~@ y.@i@ao@~~r o@s@o@@@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public e()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    instance-of v0, p1, Lcom/google/common/base/y0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p1, Lcom/google/common/base/y0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p1, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public h(Lcom/google/common/base/p0;)Lcom/google/common/base/p0;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "secondChoice"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/p0<",
            "+TT;>;)",
            "Lcom/google/common/base/p0<",
            "TT;>;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const v1, 0x598df91c

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public i(Lcom/google/common/base/h1;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "supplier"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/h1<",
            "+TT;>;)TT;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "defaultValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)TT;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "te.mnou(ia lr aOo).snouOulntdpstelsla)  Nol(oipfnl"

    const-string v0, "N souon f(p)llndslo)p.nuiosOee aou.lOaialrl(tt tni"

    const/4 v2, 0x6

    const-string v0, "Oo eoi(ofleursa lollnau( tat)r.nl n)u.piNpodntioOl"

    const-string/jumbo v0, "use Optional.orNull() instead of Optional.or(null)"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method public k()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public o(Lcom/google/common/base/s;)Lcom/google/common/base/p0;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/base/s<",
            "-TT;TV;>;)",
            "Lcom/google/common/base/p0<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/google/common/base/y0;

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v1, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p1, v1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "omonubnr e t a tlmu.dor(snc mlnilt sOup)s uais.etttroan rtntoFhfn"

    const-string v1, "animnd hnsstlirse (ana teuclnotto t)rFtun mueru f ptmon.lsr o.tOo"

    const/4 v3, 0x7

    const-string/jumbo v1, "uulot uniaei.nun oo l (rpttnF.snutlrot cOamdth te )fro pmnnrsatse"

    const-string/jumbo v1, "the Function passed to Optional.transform() must not return null."

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, v1}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, p1}, Lcom/google/common/base/y0;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "oo.opOfp(ati"

    const-string/jumbo v1, "t.f(oooaOnip"

    const/4 v3, 0x3

    const-string v1, "Oaoo.itnqp(f"

    const-string v1, "Optional.of("

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/y0;->reference:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x3

    const-string v1, ")"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method
