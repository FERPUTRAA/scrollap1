.class final Lcom/google/common/base/y$b$a;
.super Lcom/google/common/base/y$b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/y$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/common/base/y$b$b;-><init>(Lcom/google/common/base/y$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/base/y$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/base/y$b$a;-><init>()V

    return-void
.end method
