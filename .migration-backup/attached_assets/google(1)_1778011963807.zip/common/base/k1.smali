.class public final Lcom/google/common/base/k1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "sun.misc.JavaLangAccess"
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field static final b:Ljava/lang/String; = "sun.misc.SharedSecrets"
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field private static final c:Ljava/lang/Object;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field private static final d:Ljava/lang/reflect/Method;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field private static final e:Ljava/lang/reflect/Method;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/base/k1;->h()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    sput-object v0, Lcom/google/common/base/k1;->c:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/common/base/k1;->g()Ljava/lang/reflect/Method;

    move-result-object v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    sput-object v2, Lcom/google/common/base/k1;->d:Ljava/lang/reflect/Method;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/common/base/k1;->k(Ljava/lang/Object;)Ljava/lang/reflect/Method;

    move-result-object v1

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    sput-object v1, Lcom/google/common/base/k1;->e:Ljava/lang/reflect/Method;

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a()Ljava/lang/reflect/Method;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@@~o ~~  noa i~~~ @ @ ~@~@@i.@ ~f~ ~f -ul~d@//~ @ob4@1 l~r~bKMvcs~i@@tm@Sb t  oy~@o@o@~~@~@  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/base/k1;->d:Ljava/lang/reflect/Method;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic b()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/base/k1;->c:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic c(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/google/common/base/k1;->m(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic d()Ljava/lang/reflect/Method;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/base/k1;->e:Ljava/lang/reflect/Method;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public static e(Ljava/lang/Throwable;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    move v2, v1

    move v2, v1

    move-object v1, p0

    move-object v1, p0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz p0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eq p0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    xor-int/lit8 v2, v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "hsamouaa Ldic c.cp esnt edtlen"

    const-string/jumbo v1, "oisatop u c. lcceathed aeLndns"

    const/4 v4, 0x5

    const-string v1, " .d oaodsionLlune cteiacca eph"

    const-string v1, "Loop in causal chain detected."

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    throw v0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p0
.end method

.method public static f(Ljava/lang/Throwable;Ljava/lang/Class;)Ljava/lang/Throwable;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "throwable",
            "expectedCauseType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X:",
            "Ljava/lang/Throwable;",
            ">(",
            "Ljava/lang/Throwable;",
            "Ljava/lang/Class<",
            "TX;>;)TX;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p1, Ljava/lang/Throwable;
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1

    :catch_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    throw p1
.end method

.method private static g()Ljava/lang/reflect/Method;
    .locals 5
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array v0, v0, [Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    and-int/2addr v3, v1

    const/4 v4, 0x0

    const-class v2, Ljava/lang/Throwable;

    const-class v2, Ljava/lang/Throwable;

    const/4 v4, 0x2

    const-class v2, Ljava/lang/Throwable;

    const-class v2, Ljava/lang/Throwable;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x2

    move v4, v3

    sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "ceaetbntgmmTlScaretE"

    const-string/jumbo v1, "etcmttnTlcaegEaermSe"

    const/4 v4, 0x3

    const-string v1, "TgtmtnuelccrESeeakea"

    const-string/jumbo v1, "getStackTraceElement"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/google/common/base/k1;->i(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method private static h()Ljava/lang/Object;
    .locals 7
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v0, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "sumnhc.p.cSeSorsetaisr"

    const-string/jumbo v1, "nsaeosred.iucsmScShr.t"

    const/4 v6, 0x0

    const-string/jumbo v1, "sun.misc.SharedSecrets"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v2, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const-string v3, "eagnavebqtAssJLcg"

    const-string v3, "JasLebeagsatngvcA"

    const/4 v6, 0x0

    const-string/jumbo v3, "getJavaLangAccess"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v5, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/ThreadDeath; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    throw v0
.end method

.method private static varargs i(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "name",
            "parameterTypes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/reflect/Method;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/ThreadDeath;
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v1, "ncscs..vAuaussJngaeiscm"

    const-string/jumbo v1, "naacmnus.cs.ucvieaAssgJ"

    const/4 v4, 0x5

    const-string/jumbo v1, "niAmscmsavaaL.cJcgnsuse"

    const-string/jumbo v1, "sun.misc.JavaLangAccess"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, p0, p1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/ThreadDeath; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :catchall_0
    const/4 v4, 0x3

    return-object v0

    :catch_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw p0
.end method

.method public static j(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v2, v0, :cond_1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    xor-int/lit8 v1, v1, 0x1

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v0, "np aocpcie ntooiLaheu dact .sl"

    const-string v0, " uac copc ihisoeae ntpLlt.dnea"

    const/4 v4, 0x4

    const-string v0, "cct  beicu itnnhsadpdlaa L.ooe"

    const-string v0, "Loop in causal chain detected."

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-direct {p0, v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw p0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0
.end method

.method private static k(Ljava/lang/Object;)Ljava/lang/reflect/Method;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "jla"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, "aaretccSqetepgTthD"

    const/4 v7, 0x7

    const-string v1, "eThcaguDSaceepttkt"

    const-string/jumbo v1, "getStackTraceDepth"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x5

    move v7, v6

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-class v4, Ljava/lang/Throwable;

    const-class v4, Ljava/lang/Throwable;

    const/4 v7, 0x1

    const-class v4, Ljava/lang/Throwable;

    const-class v4, Ljava/lang/Throwable;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    aput-object v4, v3, v5

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v3}, Lcom/google/common/base/k1;->i(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    if-nez v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-object v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v3, Ljava/lang/Throwable;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v3}, Ljava/lang/Throwable;-><init>()V

    const/4 v7, 0x2

    aput-object v3, v2, v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    return-object v1

    :catch_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-object v0
.end method

.method public static l(Ljava/lang/Throwable;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/io/StringWriter;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    const/4 v2, 0x6

    move v3, v2

    new-instance v1, Ljava/io/PrintWriter;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p0
.end method

.method private static varargs m(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "method",
            "receiver",
            "params"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/common/base/k1;->q(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    throw p0

    :catch_1
    move-exception p0

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method private static n(Ljava/lang/Throwable;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "t"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/base/k1$a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/base/k1$a;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public static o(Ljava/lang/Throwable;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/base/k1;->p()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/google/common/base/k1;->n(Ljava/lang/Throwable;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static p()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/k1;->d:Ljava/lang/reflect/Method;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/base/k1;->e:Ljava/lang/reflect/Method;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public static q(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/google/common/base/k1;->w(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    throw v0
.end method

.method public static r(Ljava/lang/Throwable;Ljava/lang/Class;)V
    .locals 2
    .param p0    # Ljava/lang/Throwable;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "throwable",
            "declaredType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X:",
            "Ljava/lang/Throwable;",
            ">(",
            "Ljava/lang/Throwable;",
            "Ljava/lang/Class<",
            "TX;>;)V^TX;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lcom/google/common/base/k1;->v(Ljava/lang/Throwable;Ljava/lang/Class;)V

    :cond_0
    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public static s(Ljava/lang/Throwable;)V
    .locals 2
    .param p0    # Ljava/lang/Throwable;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/common/base/k1;->w(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static t(Ljava/lang/Throwable;Ljava/lang/Class;)V
    .locals 2
    .param p0    # Ljava/lang/Throwable;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "throwable",
            "declaredType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X:",
            "Ljava/lang/Throwable;",
            ">(",
            "Ljava/lang/Throwable;",
            "Ljava/lang/Class<",
            "TX;>;)V^TX;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/common/base/k1;->r(Ljava/lang/Throwable;Ljava/lang/Class;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/base/k1;->s(Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static u(Ljava/lang/Throwable;Ljava/lang/Class;Ljava/lang/Class;)V
    .locals 2
    .param p0    # Ljava/lang/Throwable;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "throwable",
            "declaredType1",
            "declaredType2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X1:",
            "Ljava/lang/Throwable;",
            "X2:",
            "Ljava/lang/Throwable;",
            ">(",
            "Ljava/lang/Throwable;",
            "Ljava/lang/Class<",
            "TX1;>;",
            "Ljava/lang/Class<",
            "TX2;>;)V^TX1;^TX2;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;,
            Ljava/lang/Throwable;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/common/base/k1;->r(Ljava/lang/Throwable;Ljava/lang/Class;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0, p2}, Lcom/google/common/base/k1;->t(Ljava/lang/Throwable;Ljava/lang/Class;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public static v(Ljava/lang/Throwable;Ljava/lang/Class;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "throwable",
            "declaredType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X:",
            "Ljava/lang/Throwable;",
            ">(",
            "Ljava/lang/Throwable;",
            "Ljava/lang/Class<",
            "TX;>;)V^TX;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p0, Ljava/lang/Throwable;

    const/4 v2, 0x4

    throw p0
.end method

.method public static w(Ljava/lang/Throwable;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "throwable"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    instance-of v0, p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    instance-of v0, p0, Ljava/lang/Error;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p0, Ljava/lang/Error;

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p0

    :cond_1
    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p0
.end method
