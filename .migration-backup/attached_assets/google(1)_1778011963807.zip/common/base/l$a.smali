.class final Lcom/google/common/base/l$a;
.super Lcom/google/common/base/i;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Enum<",
        "TT;>;>",
        "Lcom/google/common/base/i<",
        "Ljava/lang/String;",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final enumClass:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Class;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enumClass"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/common/base/i;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Class;

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/bs@~@ rot~~@ ~@@~1M  ~o @~mo@ o/@vcdo fyu~ -@@Si.@@s4 @b~t~@@~ ~f~ai~~K~l@~~ @@l ibn~~@  @ o~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/common/base/l$a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p1, Lcom/google/common/base/l$a;

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1
.end method

.method protected bridge synthetic h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "enumValue"
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/Enum;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/base/l$a;->o(Ljava/lang/Enum;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    return v0
.end method

.method protected bridge synthetic i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v0, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/l$a;->p(Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method protected o(Ljava/lang/Enum;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enumValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method protected p(Ljava/lang/String;)Ljava/lang/Enum;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v1, "rismgeteumsrr(.tvEnonn"

    const-string v1, "Enums.stringConverter("

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v1, p0, Lcom/google/common/base/l$a;->enumClass:Ljava/lang/Class;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "ss.lo)s"

    const-string/jumbo v1, "sss)la."

    const/4 v3, 0x2

    const-string/jumbo v1, "l).csbs"

    const-string v1, ".class)"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object v0
.end method
