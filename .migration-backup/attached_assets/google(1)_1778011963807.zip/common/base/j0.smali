.class public final synthetic Lcom/google/common/base/j0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " osm~@S@i~b-@4 o@so~ y@~~@@~  @l~ @o@c1 Kt~vb~i@/a ~@~ o  @~@o~ @  @ ~@~r@~~~dfn @uft~~li~@M./~b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    instance-of p0, p0, Ljava/util/OptionalLong;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method
