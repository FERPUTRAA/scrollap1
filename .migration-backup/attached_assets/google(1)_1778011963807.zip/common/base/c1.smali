.class public final Lcom/google/common/base/c1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/c1$g;,
        Lcom/google/common/base/c1$h;,
        Lcom/google/common/base/c1$f;
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field private final a:Lcom/google/common/base/e;

.field private final b:Z

.field private final c:Lcom/google/common/base/c1$h;

.field private final d:I


# direct methods
.method private constructor <init>(Lcom/google/common/base/c1$h;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "strategy"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/common/base/e;->G()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const v1, 0x7fffffff

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, p1, v2, v0, v1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;ZLcom/google/common/base/e;I)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method private constructor <init>(Lcom/google/common/base/c1$h;ZLcom/google/common/base/e;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "strategy",
            "omitEmptyStrings",
            "trimmer",
            "limit"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/base/c1;->c:Lcom/google/common/base/c1$h;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p2, p0, Lcom/google/common/base/c1;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/google/common/base/c1;->a:Lcom/google/common/base/e;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p4, p0, Lcom/google/common/base/c1;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Ljava/util/Iterator;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-direct {p0, p1}, Lcom/google/common/base/c1;->q(Ljava/lang/CharSequence;)Ljava/util/Iterator;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic b(Lcom/google/common/base/c1;)Lcom/google/common/base/e;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/common/base/c1;->a:Lcom/google/common/base/e;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic c(Lcom/google/common/base/c1;)Z
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-boolean p0, p0, Lcom/google/common/base/c1;->b:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic d(Lcom/google/common/base/c1;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p0, p0, Lcom/google/common/base/c1;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method

.method public static e(I)Lcom/google/common/base/c1;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-lez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v1, "absesTstlemht n  eaonynte  lh sg1"

    const-string v1, "eash hlbln1y   g ttatT enmeoes sn"

    const/4 v3, 0x1

    const-string v1, "The length may not be less than 1"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v3, 0x7

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v3, 0x0

    const/4 v2, 0x2

    new-instance v1, Lcom/google/common/base/c1$d;

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {v1, p0}, Lcom/google/common/base/c1$d;-><init>(I)V

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    invoke-direct {v0, v1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public static h(C)Lcom/google/common/base/c1;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separator"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/common/base/c1;->i(Lcom/google/common/base/e;)Lcom/google/common/base/c1;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method public static i(Lcom/google/common/base/e;)Lcom/google/common/base/c1;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "separatorMatcher"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v1, Lcom/google/common/base/c1$a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/google/common/base/c1$a;-><init>(Lcom/google/common/base/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method private static j(Lcom/google/common/base/h;)Lcom/google/common/base/c1;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "separatorPattern"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/base/h;->d(Ljava/lang/CharSequence;)Lcom/google/common/base/g;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/common/base/g;->d()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "ro m:e%tam  etathtc himh trat enyegp pns nsymt"

    const/4 v3, 0x5

    const-string v1, "The pattern may not match the empty string: %s"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0, v1, p0}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/google/common/base/c1$c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/google/common/base/c1$c;-><init>(Lcom/google/common/base/h;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method

.method public static k(Ljava/lang/String;)Lcom/google/common/base/c1;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "separator"
        }
    .end annotation

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    move v0, v1

    move v0, v1

    const/4 v5, 0x0

    move v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x1

    const-string/jumbo v3, "ytTmsta goebrtm na p opy otmhhtee a nrsi.e"

    const-string/jumbo v3, "rts omti.p athspTe e eentrbength m aa ooyy"

    const/4 v5, 0x3

    const-string v3, ".sr om t rmhhTettysaatypotenpea   gb nrioe"

    const-string v3, "The separator may not be the empty string."

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v3}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ne v0, v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/google/common/base/c1;->h(C)Lcom/google/common/base/c1;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object p0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Lcom/google/common/base/c1$b;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v1, p0}, Lcom/google/common/base/c1$b;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;)V

    const/4 v5, 0x1

    return-object v0
.end method

.method public static l(Ljava/util/regex/Pattern;)Lcom/google/common/base/c1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPattern"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/base/w;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/base/w;-><init>(Ljava/util/regex/Pattern;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {v0}, Lcom/google/common/base/c1;->j(Lcom/google/common/base/h;)Lcom/google/common/base/c1;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public static m(Ljava/lang/String;)Lcom/google/common/base/c1;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPattern"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/base/t0;->b(Ljava/lang/String;)Lcom/google/common/base/h;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/common/base/c1;->j(Lcom/google/common/base/h;)Lcom/google/common/base/c1;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method private q(Ljava/lang/CharSequence;)Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/Iterator<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/base/c1;->c:Lcom/google/common/base/c1$h;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/common/base/c1$h;->a(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Ljava/util/Iterator;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1
.end method


# virtual methods
.method public f(I)Lcom/google/common/base/c1;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "maxItems"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-lez p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "teeu bzogtr eb tas rneams b%r"

    const-string/jumbo v1, "zeaerb art stm eeub% no:gtrs "

    const/4 v5, 0x5

    const-string v1, "bo e aur%rte mgeta :nturse zh"

    const-string/jumbo v1, "must be greater than zero: %s"

    const/4 v4, 0x7

    move v5, v4

    invoke-static {v0, v1, p1}, Lcom/google/common/base/u0;->k(ZLjava/lang/String;I)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/common/base/c1;->c:Lcom/google/common/base/c1$h;

    const/4 v4, 0x3

    move v5, v4

    iget-boolean v2, p0, Lcom/google/common/base/c1;->b:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/common/base/c1;->a:Lcom/google/common/base/e;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v0, v1, v2, v3, p1}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;ZLcom/google/common/base/e;I)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v0
.end method

.method public g()Lcom/google/common/base/c1;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/common/base/c1;->c:Lcom/google/common/base/c1$h;

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/common/base/c1;->a:Lcom/google/common/base/e;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v3, p0, Lcom/google/common/base/c1;->d:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x1

    move v6, v4

    const/4 v5, 0x4

    move v6, v5

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;ZLcom/google/common/base/e;I)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object v0
.end method

.method public n(Ljava/lang/CharSequence;)Ljava/lang/Iterable;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "sequence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/lang/Iterable<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/base/c1$e;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/c1$e;-><init>(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public o(Ljava/lang/CharSequence;)Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/base/c1;->q(Ljava/lang/CharSequence;)Ljava/util/Iterator;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p1
.end method

.method public p(Ljava/lang/CharSequence;)Ljava/util/stream/Stream;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")",
            "Ljava/util/stream/Stream<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/base/c1;->n(Ljava/lang/CharSequence;)Ljava/lang/Iterable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/common/base/a1;->a(Ljava/lang/Iterable;)Ljava/util/Spliterator;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/b1;->a(Ljava/util/Spliterator;Z)Ljava/util/stream/Stream;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public r()Lcom/google/common/base/c1;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    invoke-static {}, Lcom/google/common/base/e;->X()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/base/c1;->s(Lcom/google/common/base/e;)Lcom/google/common/base/c1;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public s(Lcom/google/common/base/e;)Lcom/google/common/base/c1;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "trimmer"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v0, Lcom/google/common/base/c1;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/base/c1;->c:Lcom/google/common/base/c1$h;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-boolean v2, p0, Lcom/google/common/base/c1;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/common/base/c1;->d:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v0, v1, v2, p1, v3}, Lcom/google/common/base/c1;-><init>(Lcom/google/common/base/c1$h;ZLcom/google/common/base/e;I)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v0
.end method

.method public t(C)Lcom/google/common/base/c1$f;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separator"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/common/base/c1;->h(C)Lcom/google/common/base/c1;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/base/c1;->u(Lcom/google/common/base/c1;)Lcom/google/common/base/c1$f;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public u(Lcom/google/common/base/c1;)Lcom/google/common/base/c1$f;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "keyValueSplitter"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lcom/google/common/base/c1$f;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, p0, p1, v1}, Lcom/google/common/base/c1$f;-><init>(Lcom/google/common/base/c1;Lcom/google/common/base/c1;Lcom/google/common/base/c1$a;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method public v(Ljava/lang/String;)Lcom/google/common/base/c1$f;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separator"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-static {p1}, Lcom/google/common/base/c1;->k(Ljava/lang/String;)Lcom/google/common/base/c1;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/base/c1;->u(Lcom/google/common/base/c1;)Lcom/google/common/base/c1$f;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method
