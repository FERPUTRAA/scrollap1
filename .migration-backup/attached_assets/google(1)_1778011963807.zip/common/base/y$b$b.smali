.class Lcom/google/common/base/y$b$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/y$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field a:Ljava/lang/String;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field b:Ljava/lang/Object;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field c:Lcom/google/common/base/y$b$b;
    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/base/y$a;)V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/base/y$b$b;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    return-void
.end method
