.class public final Lcom/google/common/base/i1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/i1$f;,
        Lcom/google/common/base/i1$e;,
        Lcom/google/common/base/i1$h;,
        Lcom/google/common/base/i1$g;,
        Lcom/google/common/base/i1$a;,
        Lcom/google/common/base/i1$c;,
        Lcom/google/common/base/i1$b;,
        Lcom/google/common/base/i1$d;
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Lcom/google/common/base/s;Lcom/google/common/base/h1;)Lcom/google/common/base/h1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "function",
            "supplier"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<F:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/base/s<",
            "-TF;TT;>;",
            "Lcom/google/common/base/h1<",
            "TF;>;)",
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/base/i1$d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/i1$d;-><init>(Lcom/google/common/base/s;Lcom/google/common/base/h1;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static b(Lcom/google/common/base/h1;)Lcom/google/common/base/h1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/base/h1<",
            "TT;>;)",
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    instance-of v0, p0, Lcom/google/common/base/i1$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    instance-of v0, p0, Lcom/google/common/base/i1$b;

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x3

    goto :goto_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    instance-of v0, p0, Ljava/io/Serializable;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/base/i1$b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/base/i1$b;-><init>(Lcom/google/common/base/h1;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    move v2, v1

    new-instance v0, Lcom/google/common/base/i1$c;

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/base/i1$c;-><init>(Lcom/google/common/base/h1;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0

    :cond_2
    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static c(Lcom/google/common/base/h1;JLjava/util/concurrent/TimeUnit;)Lcom/google/common/base/h1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "delegate",
            "duration",
            "unit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/base/h1<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")",
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/base/i1$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/google/common/base/i1$a;-><init>(Lcom/google/common/base/h1;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static d(Ljava/lang/Object;)Lcom/google/common/base/h1;
    .locals 3
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "instance"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/i1$g;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/base/i1$g;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0
.end method

.method public static e()Lcom/google/common/base/s;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/base/s<",
            "Lcom/google/common/base/h1<",
            "TT;>;TT;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    sget-object v0, Lcom/google/common/base/i1$f;->a:Lcom/google/common/base/i1$f;

    const/4 v2, 0x5

    return-object v0
.end method

.method public static f(Lcom/google/common/base/h1;)Lcom/google/common/base/h1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/base/h1<",
            "TT;>;)",
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/base/i1$h;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/common/base/i1$h;-><init>(Lcom/google/common/base/h1;)V

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method
