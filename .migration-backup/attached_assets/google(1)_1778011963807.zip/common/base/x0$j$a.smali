.class final enum Lcom/google/common/base/x0$j$a;
.super Lcom/google/common/base/x0$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/x0$j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4010
    name = null
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/base/x0$j;-><init>(Ljava/lang/String;ILcom/google/common/base/x0$a;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s/i@~s @@~@id@t amfn@ @~ t-f~o  .@o@ ~4 @~~ c~ @ ~~@@ o~b~yo uo ~ ~i~lK@ @S~ @~/b~@b~1@M@~vl~r"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string v0, ")adm.uawysc(eeelaTtrssi"

    const-string v0, "e)sT(ara.ciwtasrlsydeue"

    const/4 v2, 0x4

    const-string/jumbo v0, "taeaoisc)ayeus.PerTdrl("

    const-string v0, "Predicates.alwaysTrue()"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method
