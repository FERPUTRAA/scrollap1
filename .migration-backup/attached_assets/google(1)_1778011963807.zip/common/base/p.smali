.class public Lcom/google/common/base/p;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/p$b;,
        Lcom/google/common/base/p$a;,
        Lcom/google/common/base/p$d;,
        Lcom/google/common/base/p$c;
    }
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field private static final d:Ljava/util/logging/Logger;

.field private static final e:Ljava/lang/String; = "com.google.common.base.internal.Finalizer"

.field private static final f:Ljava/lang/reflect/Method;


# instance fields
.field final a:Ljava/lang/ref/ReferenceQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/ReferenceQueue<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/ref/PhantomReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/PhantomReference<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final c:Z


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-class v0, Lcom/google/common/base/p;

    const-class v0, Lcom/google/common/base/p;

    const/4 v4, 0x1

    const-class v0, Lcom/google/common/base/p;

    const-class v0, Lcom/google/common/base/p;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/base/p;->d:Ljava/util/logging/Logger;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-array v0, v0, [Lcom/google/common/base/p$c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Lcom/google/common/base/p$d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/google/common/base/p$d;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x5

    new-instance v1, Lcom/google/common/base/p$a;

    invoke-direct {v1}, Lcom/google/common/base/p$a;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    new-instance v1, Lcom/google/common/base/p$b;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1}, Lcom/google/common/base/p$b;-><init>()V

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput-object v1, v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/common/base/p;->d([Lcom/google/common/base/p$c;)Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/common/base/p;->c(Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sput-object v0, Lcom/google/common/base/p;->f:Ljava/lang/reflect/Method;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/ref/ReferenceQueue;

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/common/base/p;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance v1, Ljava/lang/ref/PhantomReference;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {v1, p0, v0}, Ljava/lang/ref/PhantomReference;-><init>(Ljava/lang/Object;Ljava/lang/ref/ReferenceQueue;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-object v1, p0, Lcom/google/common/base/p;->b:Ljava/lang/ref/PhantomReference;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object v3, Lcom/google/common/base/p;->f:Ljava/lang/reflect/Method;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v4, 0x3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-class v5, Lcom/google/common/base/FinalizableReference;

    const-class v5, Lcom/google/common/base/FinalizableReference;

    const-class v5, Lcom/google/common/base/FinalizableReference;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    aput-object v5, v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v5, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    aput-object v0, v4, v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v0, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    aput-object v1, v4, v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v3, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    move v2, v5

    move v2, v5

    const/4 v7, 0x3

    move v2, v5

    move v2, v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    sget-object v1, Lcom/google/common/base/p;->d:Ljava/util/logging/Logger;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    sget-object v3, Ljava/util/logging/Level;->INFO:Ljava/util/logging/Level;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v4, "tzstieinfhscefwaef.neu.ctrelteeernadloceeeaFi  epdslarcn   datcaec erw  r lrlhnrR nerolnf rcenr yoeuere ie eaw"

    const/4 v7, 0x2

    const-string v4, " ssnrpF wrndce niltloa.rlener zcnetyaree  ced nh elsetfnafeea Rotcecuenrheirf.reurw roe eiaeta elialwfc cree d"

    const-string v4, "Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created."

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1, v3, v4, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    iput-boolean v2, p0, Lcom/google/common/base/p;->c:Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-void

    :catch_0
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/AssertionError;

    const/4 v6, 0x1

    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    throw v1
.end method

.method static synthetic a()Ljava/util/logging/Logger;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~l m@@ .a b~cur~~~~ @oo@@ M~ @@   l@~ @ vis~4Kimo@~ @~i@~@on~@@Sy-/ @bof~ ~fbtd/@~~1t ~@o ~~~@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/base/p;->d:Ljava/util/logging/Logger;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method static c(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "finalizer"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/reflect/Method;"
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v0, "ltmtorizasFarn"

    const-string v0, "Ftamrtizlsniar"

    const/4 v5, 0x2

    const-string/jumbo v0, "ltzanbaiFrsrei"

    const-string/jumbo v0, "startFinalizer"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-class v2, Ljava/lang/Class;

    const/4 v5, 0x1

    const-class v2, Ljava/lang/Class;

    const-class v2, Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    aput-object v2, v1, v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-class v2, Ljava/lang/ref/ReferenceQueue;

    const-class v2, Ljava/lang/ref/ReferenceQueue;

    const/4 v5, 0x1

    const-class v2, Ljava/lang/ref/ReferenceQueue;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput-object v2, v1, v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-class v2, Ljava/lang/ref/PhantomReference;

    const-class v2, Ljava/lang/ref/PhantomReference;

    const/4 v5, 0x0

    const-class v2, Ljava/lang/ref/PhantomReference;

    const-class v2, Ljava/lang/ref/PhantomReference;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v3, 0x2

    aput-object v2, v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    return-object p0

    :catch_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v0, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    throw v0
.end method

.method private static varargs d([Lcom/google/common/base/p$c;)Ljava/lang/Class;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "loaders"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/common/base/p$c;",
            ")",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    array-length v0, p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-ge v1, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    aget-object v2, p0, v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v2}, Lcom/google/common/base/p$c;->a()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v2

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    throw p0
.end method


# virtual methods
.method b()V
    .locals 6

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/google/common/base/p;->c:Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    return-void

    :cond_0
    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/common/base/p;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->clear()V

    :try_start_0
    const/4 v5, 0x2

    check-cast v0, Lcom/google/common/base/FinalizableReference;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v0}, Lcom/google/common/base/FinalizableReference;->finalizeReferent()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x7

    sget-object v1, Lcom/google/common/base/p;->d:Ljava/util/logging/Logger;

    const/4 v4, 0x0

    move v5, v4

    sget-object v2, Ljava/util/logging/Level;->SEVERE:Ljava/util/logging/Level;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v3, "ngeE  uirfuen rnfelparcecoeartero "

    const-string v3, " ncEo fpagauencrrfi troeeeenl rre."

    const/4 v5, 0x5

    const-string v3, "ee rnp pe.clfraronferrearE eg nuit"

    const-string v3, "Error cleaning up after reference."

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method public close()V
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/base/p;->b:Ljava/lang/ref/PhantomReference;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->enqueue()Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/base/p;->b()V

    const/4 v2, 0x2

    return-void
.end method
