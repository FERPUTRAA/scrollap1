.class Lcom/google/common/base/x$b;
.super Lcom/google/common/base/x;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/x;->q()Lcom/google/common/base/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Lcom/google/common/base/x;


# direct methods
.method constructor <init>(Lcom/google/common/base/x;Lcom/google/common/base/x;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            "this$0",
            "prototype"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/base/x$b;->b:Lcom/google/common/base/x;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p2, p1}, Lcom/google/common/base/x;-><init>(Lcom/google/common/base/x;Lcom/google/common/base/x$a;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public d(Ljava/lang/Appendable;Ljava/util/Iterator;)Ljava/lang/Appendable;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "appendable",
            "parts"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<A::",
            "Ljava/lang/Appendable;",
            ">(TA;",
            "Ljava/util/Iterator<",
            "+",
            "Ljava/lang/Object;",
            ">;)TA;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "dpsnealsap"

    const-string v0, "desalpanep"

    const/4 v3, 0x7

    const-string v0, "bnpmelaepa"

    const-string v0, "appendable"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const-string/jumbo v0, "mtpao"

    const-string/jumbo v0, "tramp"

    const/4 v3, 0x7

    const-string v0, "btrsp"

    const-string/jumbo v0, "parts"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/base/x$b;->b:Lcom/google/common/base/x;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Lcom/google/common/base/x;->r(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/common/base/x$b;->b:Lcom/google/common/base/x;

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {v1}, Lcom/google/common/base/x;->a(Lcom/google/common/base/x;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    invoke-interface {p1, v1}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/base/x$b;->b:Lcom/google/common/base/x;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Lcom/google/common/base/x;->r(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p1
.end method

.method public s(Ljava/lang/String;)Lcom/google/common/base/x;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nullText"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "rpidl uf sylsucoklpeaNiesda"

    const-string v0, "dleuoyk esNicfasdrpilaip sl"

    const/4 v2, 0x4

    const-string/jumbo v0, "ppaidr psslefNdlceislyukie "

    const-string v0, "already specified skipNulls"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method public u(Ljava/lang/String;)Lcom/google/common/base/x$d;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "kvs"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, " lpsubsuea /N.lwsitita/kp( m)n sc"

    const/4 v2, 0x0

    const-string v0, "a. sanc/quk ihu)l/(iNwp sl metsts"

    const-string v0, "can\'t use .skipNulls() with maps"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    throw p1
.end method
