.class Lcom/google/common/base/e$w;
.super Lcom/google/common/base/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "w"
.end annotation


# instance fields
.field final b:Lcom/google/common/base/e;


# direct methods
.method constructor <init>(Lcom/google/common/base/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "original"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/base/e;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Lcom/google/common/base/e;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~s@~~ / o~yn@~~mt1it@ ~b@@@ o b@ Ms~@i~/~~ @K@ @~. ~~4 ludv~~ l~~-@S f~@ roa@~ ~@ @@b@ cof@ o@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->B(C)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    xor-int/lit8 p1, p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public C(Ljava/lang/CharSequence;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->E(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1
.end method

.method public E(Ljava/lang/CharSequence;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->C(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method public F()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Ljava/util/BitSet;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/BitSet;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Lcom/google/common/base/e;->Q(Ljava/util/BitSet;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/high16 v2, 0x10000

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/BitSet;->flip(II)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->or(Ljava/util/BitSet;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Character;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public i(Ljava/lang/CharSequence;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {v1, p1}, Lcom/google/common/base/e;->i(Ljava/lang/CharSequence;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    sub-int/2addr v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/base/e$w;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/google/common/base/e$w;->b:Lcom/google/common/base/e;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "geamen(.)"

    const-string v1, ".negate()"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method
