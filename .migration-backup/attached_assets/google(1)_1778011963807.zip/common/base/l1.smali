.class public abstract Lcom/google/common/base/l1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field private static final a:Lcom/google/common/base/l1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/base/l1$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/common/base/l1$a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sput-object v0, Lcom/google/common/base/l1;->a:Lcom/google/common/base/l1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method protected constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static b()Lcom/google/common/base/l1;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@si @~o~a~~ft@~ol~ S@@.l/ i@d~@~/@ ~4r1@ @b~~@@ @u@b  ~  co~~  io n~o~@~~b Mt@y~ s~o@vm f@@ K~-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/base/l1;->a:Lcom/google/common/base/l1;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public abstract a()J
.end method
