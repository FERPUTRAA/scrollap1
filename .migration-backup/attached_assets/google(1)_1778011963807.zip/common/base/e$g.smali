.class final Lcom/google/common/base/e$g;
.super Lcom/google/common/base/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "g"
.end annotation


# static fields
.field static final b:Lcom/google/common/base/e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/e$g;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/base/e$g;-><init>()V

    const/4 v2, 0x6

    sput-object v0, Lcom/google/common/base/e$g;->b:Lcom/google/common/base/e;

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/base/e;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os ~ ~~ l-@~4 @ b~@@tc@o@rM u~  o@t o@@~d@ ~~o  m~@  1/ @K~ so@bn@~iaf@~~@~~i@/fl~Sv~b@y @i~~~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/16 v0, 0x20

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq p1, v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/16 v0, 0x85

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eq p1, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/16 v0, 0x1680

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/16 v0, 0x2007

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    if-eq p1, v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/16 v0, 0x205f

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/16 v0, 0x3000

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v0, 0x2028

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eq p1, v0, :cond_2

    const/4 v4, 0x7

    const/16 v0, 0x2029

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eq p1, v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    packed-switch p1, :pswitch_data_0

    const/4 v4, 0x1

    const/16 v0, 0x2000

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-lt p1, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v0, 0x200a

    const/4 v4, 0x1

    if-gt p1, v0, :cond_0

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    move v1, v2

    move v1, v2

    const/4 v4, 0x5

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1

    :cond_1
    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return v2

    :cond_2
    :pswitch_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x9
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/Character;

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "etkmhn).irstgsMapiree(CbWrahacac"

    const-string v0, "csseaMrahpti.(rWteCrhgabhkea)nic"

    const/4 v2, 0x1

    const-string/jumbo v0, "khtcohaeMpaee(tiraWC.ias)hebrngc"

    const-string v0, "CharMatcher.breakingWhitespace()"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method
