.class Lcom/google/common/base/k1$a;
.super Ljava/util/AbstractList;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/k1;->n(Ljava/lang/Throwable;)Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/AbstractList<",
        "Ljava/lang/StackTraceElement;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Throwable;


# direct methods
.method constructor <init>(Ljava/lang/Throwable;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "val$t"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/base/k1$a;->a:Ljava/lang/Throwable;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/util/AbstractList;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(I)Ljava/lang/StackTraceElement;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "n"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Ss@i@uby~~~n.s~t~~~~b1@~~~ i ~ @o  -@@~@ @@~ ~f@ @@ocM~  i~@ ~@@b/@ 4~o  @ @lt@~amrov Ko@/olf ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/common/base/k1;->a()Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/common/base/k1;->b()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x4

    move v6, v5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    iget-object v4, p0, Lcom/google/common/base/k1$a;->a:Ljava/lang/Throwable;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    aput-object v4, v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    aput-object p1, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v1, v2}, Lcom/google/common/base/k1;->c(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    check-cast p1, Ljava/lang/StackTraceElement;

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object p1
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "n"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/base/k1$a;->a(I)Ljava/lang/StackTraceElement;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public size()I
    .locals 7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {}, Lcom/google/common/base/k1;->d()Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Lcom/google/common/base/k1;->b()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/common/base/k1$a;->a:Ljava/lang/Throwable;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    aput-object v4, v2, v3

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v1, v2}, Lcom/google/common/base/k1;->c(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    check-cast v0, Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v0
.end method
