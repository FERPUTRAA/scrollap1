.class synthetic Lcom/google/common/base/f1$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/f1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    invoke-static {}, Ljava/util/concurrent/TimeUnit;->values()[Ljava/util/concurrent/TimeUnit;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    array-length v0, v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-array v0, v0, [I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    sput-object v0, Lcom/google/common/base/f1$a;->a:[I

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x1

    and-int/2addr v4, v2

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MICROSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    const/4 v3, 0x1

    move v4, v3

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x6

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v3, 0x6

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    :try_start_4
    const/4 v3, 0x3

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    aput v2, v0, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    :try_start_5
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x2

    sget-object v1, Ljava/util/concurrent/TimeUnit;->HOURS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x6

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    aput v2, v0, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    :try_start_6
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v1, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x7

    const/4 v4, 0x5

    aput v2, v0, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    :catch_6
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method
