.class Lcom/google/common/base/u$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/s;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/s<",
        "TA;TC;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final f:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "TA;+TB;>;"
        }
    .end annotation
.end field

.field private final g:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "TB;TC;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/common/base/s;Lcom/google/common/base/s;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "g",
            "f"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/s<",
            "TB;TC;>;",
            "Lcom/google/common/base/s<",
            "TA;+TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TA;)TC;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    iget-object v1, p0, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v1, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    instance-of v0, p1, Lcom/google/common/base/u$d;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast p1, Lcom/google/common/base/u$d;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p1, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0, v2}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p1, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v0, p1}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    xor-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/u$d;->g:Lcom/google/common/base/s;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    move v3, v2

    const-string v1, "("

    const-string v1, "("

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/base/u$d;->f:Lcom/google/common/base/s;

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method
