.class final enum Lcom/google/common/base/i1$f;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/base/i1$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/base/i1$f;",
        ">;",
        "Lcom/google/common/base/i1$e<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/base/i1$f;

.field private static final synthetic b:[Lcom/google/common/base/i1$f;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Lcom/google/common/base/i1$f;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "NNsAEICS"

    const-string v1, "SAsNCEIN"

    const/4 v4, 0x0

    const-string v1, "SACmNTIE"

    const-string v1, "INSTANCE"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/i1$f;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x2

    sput-object v0, Lcom/google/common/base/i1$f;->a:Lcom/google/common/base/i1$f;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/base/i1$f;->a()[Lcom/google/common/base/i1$f;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    sput-object v0, Lcom/google/common/base/i1$f;->b:[Lcom/google/common/base/i1$f;

    const/4 v4, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/base/i1$f;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/bobo~@  ~ n t@ r ~@lio ~od @~m@~bi~~~.@@@~~ ~ilo~~ ~M@uKSv@@@-@o 4ft fc /@@ ~~as~~~ @@o1 y@~@@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-array v0, v0, [Lcom/google/common/base/i1$f;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v2, Lcom/google/common/base/i1$f;->a:Lcom/google/common/base/i1$f;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/base/i1$f;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-class v0, Lcom/google/common/base/i1$f;

    const-class v0, Lcom/google/common/base/i1$f;

    const-class v0, Lcom/google/common/base/i1$f;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    check-cast p0, Lcom/google/common/base/i1$f;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lcom/google/common/base/i1$f;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/base/i1$f;->b:[Lcom/google/common/base/i1$f;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, [Lcom/google/common/base/i1$f;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    check-cast v0, [Lcom/google/common/base/i1$f;

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method


# virtual methods
.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "input"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/base/h1;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/base/i1$f;->b(Lcom/google/common/base/h1;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public b(Lcom/google/common/base/h1;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/h1<",
            "Ljava/lang/Object;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-interface {p1}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "ntepibpsepluu)rilumsn(pori.F"

    const-string/jumbo v0, "plpmsnepetlp)usrFi(cinuir.ou"

    const/4 v2, 0x1

    const-string/jumbo v0, "rcieeruuppFu)lssnoSnpipt(uli"

    const-string v0, "Suppliers.supplierFunction()"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method
