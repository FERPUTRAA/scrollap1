.class public final Lcom/google/common/base/g1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "a",
            "b"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x5

    if-ge v2, v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ne v3, v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/lit8 v0, v2, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p0, v0}, Lcom/google/common/base/g1;->k(Ljava/lang/CharSequence;I)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->k(Ljava/lang/CharSequence;I)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz p1, :cond_2

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v2, v2, -0x1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {p0, v1, v2}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object p0
.end method

.method public static b(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "a",
            "b"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ge v1, v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    sub-int/2addr v2, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 v2, v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    sub-int/2addr v3, v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/lit8 v3, v3, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p1, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne v2, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-int/2addr v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0, v0}, Lcom/google/common/base/g1;->k(Ljava/lang/CharSequence;I)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    sub-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->k(Ljava/lang/CharSequence;I)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v1, v1, -0x1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    sub-int/2addr p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {p0, p1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/common/base/t0;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public static d(Ljava/lang/String;)Z
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/common/base/t0;->k(Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    return p0
.end method

.method public static varargs e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 8
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "template",
            "args"
        }
    .end annotation

    const/4 v7, 0x1

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 p1, 0x1

    const/4 v7, 0x6

    move v6, p1

    const/4 v7, 0x4

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v1, "bcsuO[e(l])sjt"

    const-string v1, "]esblcOl()u[jt"

    const/4 v7, 0x2

    const-string v1, "(b[m]j)ceutllO"

    const-string v1, "(Object[])null"

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    aput-object v1, p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v1, v0

    move v1, v0

    const/4 v7, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    array-length v2, p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-ge v1, v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    aget-object v2, p1, v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/google/common/base/g1;->f(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    aput-object v2, p1, v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    array-length v3, p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    mul-int/lit8 v3, v3, 0x10

    const/4 v7, 0x5

    const/4 v6, 0x1

    add-int/2addr v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v2, v0

    move v2, v0

    const/4 v7, 0x0

    move v2, v0

    move v2, v0

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    array-length v3, p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-ge v0, v3, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v3, "%s"

    const-string/jumbo v3, "s%"

    const-string/jumbo v3, "s%"

    const-string v3, "%s"

    const/4 v7, 0x3

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v4, -0x1

    const/4 v7, 0x3

    if-ne v3, v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_3

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, p0, v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    add-int/lit8 v2, v0, 0x1

    aget-object v0, p1, v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v0, v3, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    move v5, v2

    move v5, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    move v2, v0

    move v2, v0

    const/4 v7, 0x7

    move v2, v0

    move v2, v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    move v0, v5

    move v0, v5

    const/4 v7, 0x1

    move v0, v5

    move v0, v5

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_2

    :cond_3
    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1, p0, v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    array-length p0, p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ge v0, p0, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string p0, " ["

    const-string p0, " ["

    const/4 v7, 0x0

    const-string p0, "[ "

    const-string p0, " ["

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    add-int/lit8 p0, v0, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    aget-object v0, p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_4
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    array-length v0, p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ge p0, v0, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v0, ", "

    const-string v0, ", "

    const/4 v7, 0x7

    const-string v0, ", "

    const-string v0, ", "

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    add-int/lit8 v0, p0, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    aget-object p0, p1, p0

    const/4 v7, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    move p0, v0

    move p0, v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_4

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/16 p0, 0x5d

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p0
.end method

.method private static f(Ljava/lang/Object;)Ljava/lang/String;
    .locals 7
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-string/jumbo p0, "nllu"

    const-string/jumbo p0, "llnu"

    const/4 v6, 0x4

    const-string/jumbo p0, "ulln"

    const-string/jumbo p0, "null"

    const/4 v6, 0x7

    const/4 v5, 0x5

    return-object p0

    :cond_0
    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object p0

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    move v6, v5

    const/16 v2, 0x40

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v1, "mascoogrecmgmtSonl.om.e.ons.io"

    const-string/jumbo v1, "onSmcgmcsgesmae.o.rogno.imt.ol"

    const/4 v6, 0x2

    const-string v1, ".ogoSb.mgs.erlmiogmncaeocots.b"

    const-string v1, "com.google.common.base.Strings"

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-static {v1}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v4, " lrrcaudfuitiEpeotntF x rnen eoioon"

    const-string/jumbo v4, "rri o EnaiclfFnopooetrenid u nextmt"

    const/4 v6, 0x0

    const-string v4, "en toplpE nrriodtxFgennacm iiufr oe"

    const-string v4, "Exception during lenientFormat for "

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v2, "<"

    const-string v2, "<"

    const/4 v6, 0x2

    const-string v2, "<"

    const-string v2, "<"

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo p0, "tqrw eh"

    const-string p0, " hwtebr"

    const-string p0, "e srwt "

    const-string p0, " threw "

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string p0, ">"

    const-string p0, ">"

    const/4 v6, 0x3

    const-string p0, ">"

    const-string p0, ">"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-object p0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/common/base/t0;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public static h(Ljava/lang/String;IC)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "string",
            "minLength",
            "padChar"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-lt v0, p1, :cond_0

    const/4 v1, 0x4

    move v2, v1

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-ge p0, p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    add-int/lit8 p0, p0, 0x1

    const/4 v1, 0x7

    move v2, v1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static i(Ljava/lang/String;IC)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "string",
            "minLength",
            "padChar"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-lt v0, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    if-ge v1, p1, :cond_1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0
.end method

.method public static j(Ljava/lang/String;I)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "string",
            "count"
        }
    .end annotation

    .annotation build Ly4/l;
        replacement = "string.repeat(count)"
    .end annotation

    .annotation build Ly4/m;
        value = "Java 11+ API only"
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-gt p1, v1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ltz p1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v0, v1

    move v0, v1

    const/4 v7, 0x1

    move v0, v1

    move v0, v1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v1, ":damisnoctn%iu v "

    const-string/jumbo v1, "oic n uuavdt:%nsi"

    const/4 v7, 0x7

    const-string/jumbo v1, "toscov%u iinda l:"

    const-string/jumbo v1, "invalid count: %s"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v1, p1}, Lcom/google/common/base/u0;->k(ZLjava/lang/String;I)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez p1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string p0, ""

    const-string p0, ""

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-object p0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    int-to-long v2, v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    int-to-long v4, p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    mul-long/2addr v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    long-to-int p1, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    int-to-long v4, p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    cmp-long v4, v4, v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez v4, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x0

    new-array v2, p1, [C

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v0, v1, v2, v0}, Ljava/lang/String;->getChars(II[CI)V

    :goto_0
    const/4 v6, 0x1

    move v7, v6

    sub-int p0, p1, v1

    const/4 v6, 0x5

    move v7, v6

    if-ge v1, p0, :cond_3

    const/4 v7, 0x5

    invoke-static {v2, v0, v2, v1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    shl-int/lit8 v1, v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v2, v0, v2, v1, p0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance p0, Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0, v2}, Ljava/lang/String;-><init>([C)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    return-object p0

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v0, "r:lupb a eeR iza gs dyarieooteq"

    const-string/jumbo v0, "yd oeo paqr u sRarzreiieleat g:"

    const-string/jumbo v0, "r got uRree aq ldyeer rauioa:iz"

    const-string v0, "Required array size too large: "

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {p0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    throw p0
.end method

.method static k(Ljava/lang/CharSequence;I)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "string",
            "index"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-ltz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    add-int/lit8 v0, v0, -0x2

    const/4 v1, 0x7

    move v2, v1

    if-gt p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    add-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/lang/Character;->isLowSurrogate(C)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method
