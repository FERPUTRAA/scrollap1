.class public final synthetic Lcom/google/common/base/v0;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "_this",
            "input"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~ 4~o~~ l@@Ks~y  @df   1~@@u@-ob ~t~@o~ ~bS.i~@~@/ @rM~b ~@o~vn ~i o~o@/@cal~m~@ it ~@~@@~f @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-interface {p0, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p0
.end method
