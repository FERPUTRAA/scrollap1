.class abstract Lcom/google/common/base/c1$g;
.super Lcom/google/common/base/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/c1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/base/b<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final c:Ljava/lang/CharSequence;

.field final d:Lcom/google/common/base/e;

.field final e:Z

.field f:I

.field g:I


# direct methods
.method protected constructor <init>(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "splitter",
            "toSplit"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/common/base/b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/common/base/c1;->b(Lcom/google/common/base/c1;)Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/base/c1$g;->d:Lcom/google/common/base/e;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/google/common/base/c1;->c(Lcom/google/common/base/c1;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/google/common/base/c1$g;->e:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/common/base/c1;->d(Lcom/google/common/base/c1;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/common/base/c1$g;->g:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method protected bridge synthetic a()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "K@s f. 4v@r@o@@~ubf@too@i@@ -~@@o~~ n@b   @~ @o~/s~@ @l~@/ ~ i~~i~oMltb~a  m~@1~~c y@~ S d~~~@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Lcom/google/common/base/c1$g;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method protected d()Ljava/lang/String;
    .locals 8
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v0, p0, Lcom/google/common/base/c1$g;->f:I

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget v1, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v2, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eq v1, v2, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Lcom/google/common/base/c1$g;->f(I)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    if-ne v1, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput v2, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v1}, Lcom/google/common/base/c1$g;->e(I)I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput v3, p0, Lcom/google/common/base/c1$g;->f:I

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget v3, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ne v3, v0, :cond_2

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput v3, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-le v3, v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput v2, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ge v0, v1, :cond_3

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/google/common/base/c1$g;->d:Lcom/google/common/base/e;

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-interface {v4, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/google/common/base/e;->B(C)Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v3, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_2

    :cond_3
    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-le v1, v0, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/google/common/base/c1$g;->d:Lcom/google/common/base/e;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x2

    add-int/lit8 v5, v1, -0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v4, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/google/common/base/e;->B(C)Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v3, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-int/lit8 v1, v1, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_3

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-boolean v3, p0, Lcom/google/common/base/c1$g;->e:Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v3, :cond_5

    const/4 v7, 0x0

    if-ne v0, v1, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget v0, p0, Lcom/google/common/base/c1$g;->f:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget v3, p0, Lcom/google/common/base/c1$g;->g:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-ne v3, v4, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput v2, p0, Lcom/google/common/base/c1$g;->f:I

    :goto_4
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-le v1, v0, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/common/base/c1$g;->d:Lcom/google/common/base/e;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v6, 0x0

    move v7, v6

    add-int/lit8 v4, v1, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-interface {v3, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Lcom/google/common/base/e;->B(C)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v2, :cond_7

    const/4 v6, 0x0

    move v7, v6

    add-int/lit8 v1, v1, -0x1

    goto :goto_4

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    sub-int/2addr v3, v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    iput v3, p0, Lcom/google/common/base/c1$g;->g:I

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v2, v0, v1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-object v0

    :cond_8
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/common/base/b;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x2

    return-object v0
.end method

.method abstract e(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPosition"
        }
    .end annotation
.end method

.method abstract f(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "start"
        }
    .end annotation
.end method
