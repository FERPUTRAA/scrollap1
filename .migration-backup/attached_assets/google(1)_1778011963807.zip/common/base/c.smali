.class public final Lcom/google/common/base/c;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field public static final A:B = 0x17t

.field public static final B:B = 0x18t

.field public static final C:B = 0x19t

.field public static final D:B = 0x1at

.field public static final E:B = 0x1bt

.field public static final F:B = 0x1ct

.field public static final G:B = 0x1dt

.field public static final H:B = 0x1et

.field public static final I:B = 0x1ft

.field public static final J:B = 0x20t

.field public static final K:B = 0x20t

.field public static final L:B = 0x7ft

.field public static final M:C = '\u0000'

.field public static final N:C = '\u007f'

.field private static final O:C = ' '

.field public static final a:B = 0x0t

.field public static final b:B = 0x1t

.field public static final c:B = 0x2t

.field public static final d:B = 0x3t

.field public static final e:B = 0x4t

.field public static final f:B = 0x5t

.field public static final g:B = 0x6t

.field public static final h:B = 0x7t

.field public static final i:B = 0x8t

.field public static final j:B = 0x9t

.field public static final k:B = 0xat

.field public static final l:B = 0xat

.field public static final m:B = 0xbt

.field public static final n:B = 0xct

.field public static final o:B = 0xdt

.field public static final p:B = 0xet

.field public static final q:B = 0xft

.field public static final r:B = 0x10t

.field public static final s:B = 0x11t

.field public static final t:B = 0x11t

.field public static final u:B = 0x12t

.field public static final v:B = 0x13t

.field public static final w:B = 0x13t

.field public static final x:B = 0x14t

.field public static final y:B = 0x15t

.field public static final z:B = 0x16t


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "s1",
            "s2"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "oKs @ ~@~/~s~ o o@ 1bf@~@l@f.@@~n  S~ o~@ o4t~@@vyb~@M ~/r  mla ~it@@~@~@@ic~ ~~-uo~@i@~@ ~d~~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-ne p0, p1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    return v1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v3, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eq v0, v2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    return v3

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-ge v2, v0, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-ne v4, v5, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    goto :goto_1

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v4}, Lcom/google/common/base/c;->b(C)I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/16 v6, 0x1a

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-ge v4, v6, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-static {v5}, Lcom/google/common/base/c;->b(C)I

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-ne v4, v5, :cond_3

    :goto_1
    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_0

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x6

    return v3

    :cond_4
    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    return v1
.end method

.method private static b(C)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    or-int/lit8 p0, p0, 0x20

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    add-int/lit8 p0, p0, -0x61

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    int-to-char p0, p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    return p0
.end method

.method public static c(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v2, 0x3

    const/16 v0, 0x61

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-lt p0, v0, :cond_0

    const/4 v2, 0x7

    const/16 v0, 0x7a

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-gt p0, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static d(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/16 v0, 0x41

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-lt p0, v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x5a

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-gt p0, v0, :cond_0

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x4

    move v1, p0

    move v1, p0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x1

    return p0
.end method

.method public static e(C)C
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/google/common/base/c;->d(C)Z

    move-result v0

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    xor-int/lit8 p0, p0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    int-to-char p0, p0

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p0
.end method

.method public static f(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "chars"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    instance-of v0, p0, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/common/base/c;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object p0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-array v1, v0, [C

    const/4 v4, 0x7

    move v5, v4

    const/4 v2, 0x0

    move v5, v2

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v3}, Lcom/google/common/base/c;->e(C)C

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    aput-char v3, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/String;->valueOf([C)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object p0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ge v1, v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v2}, Lcom/google/common/base/c;->d(C)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ge v1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    aget-char v2, p0, v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/google/common/base/c;->d(C)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    xor-int/lit8 v2, v2, 0x20

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    int-to-char v2, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    aput-char v2, p0, v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf([C)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-object p0
.end method

.method public static h(C)C
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/google/common/base/c;->c(C)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    xor-int/lit8 p0, p0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    int-to-char p0, p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p0
.end method

.method public static i(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "chars"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    instance-of v0, p0, Ljava/lang/String;

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    check-cast p0, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/google/common/base/c;->j(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object p0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-array v1, v0, [C

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v3}, Lcom/google/common/base/c;->h(C)C

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    aput-char v3, v1, v2

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/lang/String;->valueOf([C)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    return-object p0
.end method

.method public static j(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ge v1, v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v2}, Lcom/google/common/base/c;->c(C)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ge v1, v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    aget-char v2, p0, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v2}, Lcom/google/common/base/c;->c(C)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    xor-int/lit8 v2, v2, 0x20

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    int-to-char v2, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    aput-char v2, p0, v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    move v5, v4

    invoke-static {p0}, Ljava/lang/String;->valueOf([C)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    return-object p0

    :cond_2
    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x3

    return-object p0
.end method

.method public static k(Ljava/lang/CharSequence;ILjava/lang/String;)Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "seq",
            "maxLength",
            "truncationIndicator"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    sub-int v0, p1, v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-ltz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string/jumbo v3, "f imgtba  ue tnLes=)ts dat>snlh(h oiero   % ig(nnnarcthuttxmo%)ce"

    const-string/jumbo v3, "maxLength (%s) must be >= length of the truncation indicator (%s)"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2, v3, p1, v4}, Lcom/google/common/base/u0;->m(ZLjava/lang/String;II)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-gt v2, p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-gt v2, p1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-direct {v2, p1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2, p0, v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object p0
.end method
