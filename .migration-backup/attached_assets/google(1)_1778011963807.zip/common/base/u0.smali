.class public final Lcom/google/common/base/u0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static A(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3",
            "p4"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " /s@@v ~@S4~ @~   @ @~o~1~fb@ oy~K~@@b~@ao~  ~@lb@ loi~td~i@~~~~-i@@ @~ sM ~ ~orm~n/.@ o@c@@f ut"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    const/4 p2, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    aput-object p4, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p2, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput-object p5, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    throw p0
.end method

.method public static A0(ZLjava/lang/String;Ljava/lang/Object;J)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p0
.end method

.method public static varargs B(ZLjava/lang/String;[Ljava/lang/Object;)V
    .locals 2
    .param p2    # [Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "errorMessageArgs"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    throw p0
.end method

.method public static B0(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    or-int/2addr v3, v2

    const/4 v0, 0x2

    and-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p0
.end method

.method public static C(II)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "size"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "ixemn"

    const-string/jumbo v0, "xisen"

    const/4 v2, 0x0

    const-string/jumbo v0, "xiedo"

    const-string/jumbo v0, "index"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Lcom/google/common/base/u0;->D(IILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p0
.end method

.method public static C0(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    xor-int/2addr v2, v1

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p2, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    aput-object p4, v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p0
.end method

.method public static D(IILjava/lang/String;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "index",
            "size",
            "desc"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-ltz p0, :cond_0

    const/4 v2, 0x6

    if-ge p0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lcom/google/common/base/u0;->a(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    throw v0
.end method

.method public static D0(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3",
            "p4"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    const/4 v0, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    move v3, v2

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p2, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    aput-object p4, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p2, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    aput-object p5, v0, p2

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw p0
.end method

.method public static E(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "reference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public static varargs E0(ZLjava/lang/String;[Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "errorMessageArgs"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    throw p0
.end method

.method public static F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessage"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    throw p0
.end method

.method public static G(Ljava/lang/Object;Ljava/lang/String;C)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "C)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    throw p0
.end method

.method public static H(Ljava/lang/Object;Ljava/lang/String;CC)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "CC)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    const/4 v0, 0x2

    shr-int/2addr v3, v0

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw p0
.end method

.method public static I(Ljava/lang/Object;Ljava/lang/String;CI)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "CI)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x1

    move v2, p2

    move v2, p2

    const/4 v3, 0x0

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    throw p0
.end method

.method public static J(Ljava/lang/Object;Ljava/lang/String;CJ)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "CJ)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x5

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    aput-object p3, v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p0
.end method

.method public static K(Ljava/lang/Object;Ljava/lang/String;CLjava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "C",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p0
.end method

.method public static L(Ljava/lang/Object;Ljava/lang/String;I)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "I)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x0

    move v3, v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    throw p0
.end method

.method public static M(Ljava/lang/Object;Ljava/lang/String;IC)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "IC)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    aput-object p2, v0, v1

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x0

    move v2, p2

    move v2, p2

    const/4 v3, 0x4

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p0
.end method

.method public static N(Ljava/lang/Object;Ljava/lang/String;II)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "II)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw p0
.end method

.method public static O(Ljava/lang/Object;Ljava/lang/String;IJ)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "IJ)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v2, 0x5

    move v3, v2

    const/4 p2, 0x1

    move v3, p2

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p0
.end method

.method public static P(Ljava/lang/Object;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method

.method public static Q(Ljava/lang/Object;Ljava/lang/String;J)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "J)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x7

    move v3, v2

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    throw p0
.end method

.method public static R(Ljava/lang/Object;Ljava/lang/String;JC)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "JC)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x7

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p0
.end method

.method public static S(Ljava/lang/Object;Ljava/lang/String;JI)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "JI)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p0
.end method

.method public static T(Ljava/lang/Object;Ljava/lang/String;JJ)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "JJ)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p0
.end method

.method public static U(Ljava/lang/Object;Ljava/lang/String;JLjava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "J",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    aput-object p4, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw p0
.end method

.method public static V(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p0
.end method

.method public static W(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;C)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "C)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 p2, 0x4

    const/4 v3, 0x7

    const/4 p2, 0x1

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p0
.end method

.method public static X(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;I)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "I)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x0

    shr-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static Y(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;J)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "J)TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw p0
.end method

.method public static Z(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v2, 0x1

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw p0
.end method

.method private static a(IILjava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "index",
            "size",
            "desc"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-gez p0, :cond_0

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-array p1, v2, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    aput-object p2, p1, v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    aput-object p0, p1, v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string p0, "%e%ttb  )evmunmsonias (b gs "

    const-string/jumbo p0, "ev mie (%tsu a sb emn)g%sont"

    const/4 v5, 0x5

    const-string/jumbo p0, "i nabous)e% ge tm(n u%stse v"

    const-string p0, "%s (%s) must not be negative"

    const/4 v5, 0x2

    invoke-static {p0, p1}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    return-object p0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ltz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput-object p2, v3, v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    aput-object p0, v3, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    aput-object p0, v3, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string p0, " th(n sps%% s  s( am eo)tibze)%euss"

    const-string/jumbo p0, "s slo( % iesstt) n%zu a  she%(emb)s"

    const/4 v5, 0x6

    const-string/jumbo p0, "mshs% %tq sn eis%)(  steelzas (bsu)"

    const-string p0, "%s (%s) must be less than size (%s)"

    invoke-static {p0, v3}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object p0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v0, "ivsee ai:gtsb n"

    const-string/jumbo v0, "na tgb:s ieizve"

    const/4 v5, 0x4

    const-string/jumbo v0, "isgmenzi t e:ae"

    const-string/jumbo v0, "negative size: "

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    throw p0
.end method

.method public static a0(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v2, 0x6

    move v3, v2

    const/4 p2, 0x7

    const/4 p2, 0x2

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    aput-object p4, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    throw p0
.end method

.method private static b(IILjava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "index",
            "size",
            "desc"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x2

    const/4 v5, 0x5

    if-gez p0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-array p1, v2, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    aput-object p2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput-object p0, p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p0, " nt%oagnvsesme utet u%b oi(s"

    const-string p0, "esg%tvuonutia t) %(nmes ebs "

    const/4 v5, 0x7

    const-string/jumbo p0, "gtnmvbe ios e )a(%ns  estbut"

    const-string p0, "%s (%s) must not be negative"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0, p1}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object p0

    :cond_0
    const/4 v5, 0x5

    if-ltz p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x3

    aput-object p2, v3, v1

    const/4 v4, 0x4

    move v5, v4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    aput-object p0, v3, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    aput-object p0, v3, v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string p0, " gtomeu(rsee    ae%nsr(  )stzph asbs%utitn"

    const-string p0, " igesn pato  srsr( e% uee%)attm%(tzss bhn "

    const/4 v5, 0x5

    const-string/jumbo p0, "srt% t)p so (ae  zgmsss a% r inenh)(be%ttu"

    const-string p0, "%s (%s) must not be greater than size (%s)"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0, v3}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object p0

    :cond_1
    const/4 v5, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v0, "eqsz ntaq:vegie"

    const-string/jumbo v0, "ni:eazseqtve  g"

    const/4 v5, 0x2

    const-string v0, " sstve:zeiiane "

    const-string/jumbo v0, "negative size: "

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    move v5, v4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    throw p0
.end method

.method public static b0(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3",
            "p4"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    aput-object p2, v0, v1

    const/4 v2, 0x7

    move v3, v2

    const/4 p2, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput-object p3, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    aput-object p4, v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p2, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    aput-object p5, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw p0
.end method

.method private static c(III)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "start",
            "end",
            "size"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ltz p0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-le p0, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-ltz p1, :cond_2

    const/4 v2, 0x5

    if-le p1, p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p2, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    aput-object p1, p2, v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    aput-object p0, p2, p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo p0, "nrem iaetxdhnsti%o lbd x s(sen (esnm tsat%dnts)  se)u"

    const-string p0, "dts%dxbmns sn(t )osesut%)s e  et  nhex (inndie tlaars"

    const/4 v2, 0x1

    const-string p0, "e h odaeix  sti%o s%an m)nnn ld(se dntt (t)eurxse ssb"

    const-string p0, "end index (%s) must not be less than start index (%s)"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0, p2}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_2
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string p0, "dmxidbn e"

    const-string/jumbo p0, "nximeedd "

    const/4 v2, 0x1

    const-string/jumbo p0, "nddi nuex"

    const-string p0, "end index"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1, p2, p0}, Lcom/google/common/base/u0;->b(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0

    :cond_3
    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string p1, " rstxntpoed"

    const-string p1, "dsttoxnae r"

    const/4 v2, 0x4

    const-string p1, "axsdtneiqtr"

    const-string/jumbo p1, "start index"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p2, p1}, Lcom/google/common/base/u0;->b(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static varargs c0(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "reference",
            "errorMessageTemplate",
            "errorMessageArgs"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    throw p0
.end method

.method public static d(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expression"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    throw p0
.end method

.method public static d0(II)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "size"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "besnx"

    const-string v0, "bnexi"

    const-string/jumbo v0, "indmx"

    const-string/jumbo v0, "index"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lcom/google/common/base/u0;->e0(IILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method

.method public static e(ZLjava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessage"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    throw p0
.end method

.method public static e0(IILjava/lang/String;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "index",
            "size",
            "desc"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ltz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-gt p0, p1, :cond_0

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lcom/google/common/base/u0;->b(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw v0
.end method

.method public static f(ZLjava/lang/String;C)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x3

    move v2, v0

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    throw p0
.end method

.method public static f0(III)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "start",
            "end",
            "size"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-ltz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-lt p1, p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-gt p1, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p0, p1, p2}, Lcom/google/common/base/u0;->c(III)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw v0
.end method

.method public static g(ZLjava/lang/String;CC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-object p3, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static g0(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expression"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    throw p0
.end method

.method public static h(ZLjava/lang/String;CI)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x7

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p0
.end method

.method public static h0(ZLjava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessage"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    throw p0
.end method

.method public static i(ZLjava/lang/String;CJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    aput-object p3, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    and-int/2addr v3, v2

    throw p0
.end method

.method public static i0(ZLjava/lang/String;C)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p2, v0, v1

    const/4 v2, 0x2

    and-int/2addr v3, v2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw p0
.end method

.method public static j(ZLjava/lang/String;CLjava/lang/Object;)V
    .locals 4
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x4

    move v2, p2

    move v2, p2

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p0
.end method

.method public static j0(ZLjava/lang/String;CC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x3

    move v3, v2

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 p2, 0x0

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw p0
.end method

.method public static k(ZLjava/lang/String;I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method public static k0(ZLjava/lang/String;CI)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v2, 0x2

    move v3, v2

    const/4 p2, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw p0
.end method

.method public static l(ZLjava/lang/String;IC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x5

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method public static l0(ZLjava/lang/String;CJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    and-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v2, 0x2

    move v3, v2

    const/4 p2, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p0
.end method

.method public static m(ZLjava/lang/String;II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw p0
.end method

.method public static m0(ZLjava/lang/String;CLjava/lang/Object;)V
    .locals 4
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x2

    move v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p0
.end method

.method public static n(ZLjava/lang/String;IJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x6

    move v3, v2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    throw p0
.end method

.method public static n0(ZLjava/lang/String;I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p0
.end method

.method public static o(ZLjava/lang/String;ILjava/lang/Object;)V
    .locals 4
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v1, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p2, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p0
.end method

.method public static o0(ZLjava/lang/String;IC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0
.end method

.method public static p(ZLjava/lang/String;J)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p0
.end method

.method public static p0(ZLjava/lang/String;II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    move v3, v2

    const/4 v0, 0x2

    and-int/2addr v3, v0

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    move v2, v1

    move v2, v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput-object p3, v0, p2

    const/4 v2, 0x0

    move v3, v2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw p0
.end method

.method public static q(ZLjava/lang/String;JC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-static {p4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    throw p0
.end method

.method public static q0(ZLjava/lang/String;IJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p0
.end method

.method public static r(ZLjava/lang/String;JI)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p0
.end method

.method public static r0(ZLjava/lang/String;ILjava/lang/Object;)V
    .locals 4
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw p0
.end method

.method public static s(ZLjava/lang/String;JJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x6

    move v3, v2

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p0
.end method

.method public static s0(ZLjava/lang/String;J)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    move v2, v0

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p0
.end method

.method public static t(ZLjava/lang/String;JLjava/lang/Object;)V
    .locals 4
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v0, 0x5

    move v3, v0

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v2, 0x3

    move v3, v2

    const/4 p2, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput-object p4, v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    throw p0
.end method

.method public static t0(ZLjava/lang/String;JC)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x2

    or-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    throw p0
.end method

.method public static u(ZLjava/lang/String;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw p0
.end method

.method public static u0(ZLjava/lang/String;JI)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    xor-int/2addr v2, v1

    const/4 v3, 0x6

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    throw p0
.end method

.method public static v(ZLjava/lang/String;Ljava/lang/Object;C)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static v0(ZLjava/lang/String;JJ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    aput-object p2, v0, v1

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x6

    aput-object p3, v0, p2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p0
.end method

.method public static w(ZLjava/lang/String;Ljava/lang/Object;I)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p3, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    throw p0
.end method

.method public static w0(ZLjava/lang/String;JLjava/lang/Object;)V
    .locals 4
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    aput-object p4, v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw p0
.end method

.method public static x(ZLjava/lang/String;Ljava/lang/Object;J)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static x0(ZLjava/lang/String;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    aput-object p2, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0
.end method

.method public static y(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x4

    move v3, v2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p0
.end method

.method public static y0(ZLjava/lang/String;Ljava/lang/Object;C)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v1, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw p0
.end method

.method public static z(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2",
            "p3"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v0, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    aput-object p2, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p3, v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p2, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    aput-object p4, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static z0(ZLjava/lang/String;Ljava/lang/Object;I)V
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "expression",
            "errorMessageTemplate",
            "p1",
            "p2"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x5

    or-int/2addr v3, v2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p2, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    aput-object p3, v0, p2

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw p0
.end method
