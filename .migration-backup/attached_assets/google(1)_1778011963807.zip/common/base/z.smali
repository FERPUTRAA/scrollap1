.class public final synthetic Lcom/google/common/base/z;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~sl Ko @S@t@Mo ~~ f~ @ @t@ @c@ @ybur~  i~ v4/@@f@n/m o @~ ~o~.@~~@o~d- ~~@soa@ i@~l i~@b~1~~~@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    instance-of p0, p0, Ljava/util/Optional;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method
