.class Lcom/google/common/base/x0$k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/w0;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/w0<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final components:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "+",
            "Lcom/google/common/base/w0<",
            "-TT;>;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "components"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/google/common/base/w0<",
            "-TT;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Ljava/util/List;Lcom/google/common/base/x0$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/base/x0$k;-><init>(Ljava/util/List;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "t"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v2, Lcom/google/common/base/w0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v2, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v2, 0x3

    instance-of v0, p1, Lcom/google/common/base/x0$k;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Lcom/google/common/base/x0$k;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const v1, 0x53c91cf

    const/4 v3, 0x6

    const/4 v2, 0x2

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "ro"

    const-string/jumbo v0, "ro"

    const/4 v3, 0x5

    const-string/jumbo v0, "or"

    const-string/jumbo v0, "or"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/x0$k;->components:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/common/base/x0;->a(Ljava/lang/String;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    move v3, v2

    return-object v0
.end method
