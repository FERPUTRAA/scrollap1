.class public final synthetic Lcom/google/common/base/o0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s @moi@~i@4@l@~~~ n~ S@@ @lo@  ~~1oo r~@~  / ~@ov~ u@ b~tfK~yiM@~@ s/ ~~@@dt. f~~c@ o-b@ @b~~a"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method
