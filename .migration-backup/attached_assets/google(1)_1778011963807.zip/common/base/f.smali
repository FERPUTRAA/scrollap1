.class public final Lcom/google/common/base/f;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field public static final a:Ljava/nio/charset/Charset;
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field public static final b:Ljava/nio/charset/Charset;

.field public static final c:Ljava/nio/charset/Charset;

.field public static final d:Ljava/nio/charset/Charset;
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field public static final e:Ljava/nio/charset/Charset;
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field

.field public static final f:Ljava/nio/charset/Charset;
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "A-ssCSUI"

    const-string v0, "A-sIUISC"

    const/4 v2, 0x4

    const-string v0, "SUIm-SIC"

    const-string v0, "US-ASCII"

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lcom/google/common/base/f;->a:Ljava/nio/charset/Charset;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "9O-Io18S5m"

    const-string v0, "5O-m1S9I8-"

    const/4 v2, 0x3

    const-string v0, "ISO-8859-1"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lcom/google/common/base/f;->b:Ljava/nio/charset/Charset;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const-string v0, "bFUT8"

    const-string v0, "TFU8o"

    const/4 v2, 0x6

    const-string v0, "8uUF-"

    const-string v0, "UTF-8"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/base/f;->c:Ljava/nio/charset/Charset;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string v0, "b-T6BUFp"

    const-string v0, "UBT6-bF1"

    const-string/jumbo v0, "qE6F-1BT"

    const-string v0, "UTF-16BE"

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    sput-object v0, Lcom/google/common/base/f;->d:Ljava/nio/charset/Charset;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string v0, "61suEFLT"

    const-string v0, "LE61F-uT"

    const/4 v2, 0x2

    const-string v0, "-6UmLEFT"

    const-string v0, "UTF-16LE"

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lcom/google/common/base/f;->e:Ljava/nio/charset/Charset;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, "1-p6oF"

    const-string v0, "1pF-U6"

    const/4 v2, 0x5

    const-string v0, "6FUT-b"

    const-string v0, "UTF-16"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sput-object v0, Lcom/google/common/base/f;->f:Ljava/nio/charset/Charset;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method
