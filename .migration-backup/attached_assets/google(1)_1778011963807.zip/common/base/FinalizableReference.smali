.class public interface abstract Lcom/google/common/base/FinalizableReference;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation

.annotation runtime Ly4/f;
    value = "Use an instance of one of the Finalizable*Reference classes"
.end annotation


# virtual methods
.method public abstract finalizeReferent()V
.end method
