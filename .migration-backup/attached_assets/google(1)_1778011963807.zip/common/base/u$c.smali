.class Lcom/google/common/base/u$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/s;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/s<",
        "TK;TV;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field final defaultValue:Ljava/lang/Object;
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field final map:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;+TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/util/Map;Ljava/lang/Object;)V
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "map",
            "defaultValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TK;+TV;>;TV;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    check-cast p1, Ljava/util/Map;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TV;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/common/base/l0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    instance-of v0, p1, Lcom/google/common/base/u$c;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Lcom/google/common/base/u$c;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v3, 0x2

    iget-object v2, p1, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-interface {v0, v2}, Ljava/util/Map;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p1, p1, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x2

    move v4, v3

    iget-object v2, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    move v3, v1

    move v3, v1

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "Frso.fcstnpino(sM"

    const-string v1, "ansptF(irnfo.sMoc"

    const/4 v3, 0x4

    const-string v1, "Functions.forMap("

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/base/u$c;->map:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, " aemmdl=tuefV,u"

    const-string v1, "adumelu etVl=f,"

    const/4 v3, 0x5

    const-string/jumbo v1, "ludeo,uelft= aa"

    const-string v1, ", defaultValue="

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/common/base/u$c;->defaultValue:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method
