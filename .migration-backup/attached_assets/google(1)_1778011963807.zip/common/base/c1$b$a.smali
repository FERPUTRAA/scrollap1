.class Lcom/google/common/base/c1$b$a;
.super Lcom/google/common/base/c1$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/c1$b;->b(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Lcom/google/common/base/c1$g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic h:Lcom/google/common/base/c1$b;


# direct methods
.method constructor <init>(Lcom/google/common/base/c1$b;Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            "this$0",
            "splitter",
            "toSplit"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/base/c1$b$a;->h:Lcom/google/common/base/c1$b;

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0, p2, p3}, Lcom/google/common/base/c1$g;-><init>(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public e(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPosition"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/base/c1$b$a;->h:Lcom/google/common/base/c1$b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, v0, Lcom/google/common/base/c1$b;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    add-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method public f(I)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "start"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/common/base/c1$b$a;->h:Lcom/google/common/base/c1$b;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, v0, Lcom/google/common/base/c1$b;->a:Ljava/lang/String;

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr v1, v0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-gt p1, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_1
    const/4 v6, 0x4

    if-ge v2, v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int v4, v2, p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {v3, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/common/base/c1$b$a;->h:Lcom/google/common/base/c1$b;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v4, v4, Lcom/google/common/base/c1$b;->a:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v4, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    return p1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 p1, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    return p1
.end method
