.class Lcom/google/common/base/p$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/p$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "Could not load Finalizer in its own class loader. Loading Finalizer in the current class loader instead. As a result, you will not be able to garbage collect this class loader. To support reclaiming this class loader, either resolve the underlying issue, or move Guava to your system class path."


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Class;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/common/base/p$a;->b()Ljava/net/URL;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/base/p$a;->c(Ljava/net/URL;)Ljava/net/URLClassLoader;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v1, "atsn.lsmeoraFlbnco.nle.zinoo.mgageirseicm"

    const-string/jumbo v1, "i.sgannFsoireomonzl.irelo.m.gctalenbmaceo"

    const/4 v5, 0x3

    const-string/jumbo v1, "ocimlee.claomgn.rnr.noa.gbFoleona.mztmiie"

    const-string v1, "com.google.common.base.internal.Finalizer"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/common/base/p;->a()Ljava/util/logging/Logger;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v3, "ottioohleleirs cci ulrddenalaotLe rvsrstlidhc eildlaolta  ru e   seC e a bo enllonr hsrioiAis  ses u,nm e rdaiwsuiyz. e n  oisy rai i.ssecetalcs ngl w smllnstnialds odTsh r.eeGroos oces,ceoa  ry iugclbaenphob antnca tealng Fteahytuogapdte psrlsvttlnu o. eg aua iavmrzuata o lood le,  rsrarFitol "

    const-string v3, "Could not load Finalizer in its own class loader. Loading Finalizer in the current class loader instead. As a result, you will not be able to garbage collect this class loader. To support reclaiming this class loader, either resolve the underlying issue, or move Guava to your system class path."

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    move v5, v4

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method b()Ljava/net/URL;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v1, 0x2e

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/16 v2, 0x2f

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v3, "nrllmb.b.actsoegecmrl.imonigeFn.aaenzmo.o"

    const-string v3, ".sbmogzilanFn.cco.lnortamroea.g.eoelnmmei"

    const-string v3, ".aogliubmnac.rmonoiz.n.ent.lamcioeoelgeFs"

    const-string v3, "com.google.common.base.internal.Finalizer"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v3, v1, v2}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v1, "cpaslo"

    const-string/jumbo v1, "lcasos"

    const/4 v5, 0x7

    const-string v1, ".class"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/ClassLoader;->getResource(Ljava/lang/String;)Ljava/net/URL;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    sub-int/2addr v3, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v2, Ljava/net/URL;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {v2, v1, v0}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object v2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/io/IOException;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v3, "bsspyUt qtaon:d heuplrte"

    const-string/jumbo v3, "pdhnyb trt upaosetlU:s e"

    const/4 v5, 0x7

    const-string/jumbo v3, "lds:naepssterp u ptohytU"

    const-string v3, "Unsupported path style: "

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    throw v0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/io/FileNotFoundException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1, v0}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    throw v1
.end method

.method c(Ljava/net/URL;)Ljava/net/URLClassLoader;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "base"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Ljava/net/URLClassLoader;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array v1, v1, [Ljava/net/URL;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    aput-object p1, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1, p1}, Ljava/net/URLClassLoader;-><init>([Ljava/net/URL;Ljava/lang/ClassLoader;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0
.end method
