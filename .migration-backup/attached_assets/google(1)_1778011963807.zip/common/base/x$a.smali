.class Lcom/google/common/base/x$a;
.super Lcom/google/common/base/x;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/x;->s(Ljava/lang/String;)Lcom/google/common/base/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/google/common/base/x;


# direct methods
.method constructor <init>(Lcom/google/common/base/x;Lcom/google/common/base/x;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x1010
        }
        names = {
            "this$0",
            "prototype",
            "val$nullText"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/base/x$a;->c:Lcom/google/common/base/x;

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/common/base/x$a;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p2, p1}, Lcom/google/common/base/x;-><init>(Lcom/google/common/base/x;Lcom/google/common/base/x$a;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public q()Lcom/google/common/base/x;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "s s@ @/~~~@t~o@lb@~1~@~4~~ioo@ ~u i ~M   bK~oa~@ ~ @~~ @b@@@l@r  d~~-@S~m~/y f@if o.~ot@ v ~@@cn"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "ifemcau llseyiddrroesuNsepl "

    const-string v1, "ees dreucalyeidfliupo lsasrN"

    const/4 v3, 0x4

    const-string/jumbo v1, "leioo uNuaressdlceediFlry af"

    const-string v1, "already specified useForNull"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v0
.end method

.method r(Ljava/lang/Object;)Ljava/lang/CharSequence;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "part"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/common/base/x$a;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/base/x$a;->c:Lcom/google/common/base/x;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Lcom/google/common/base/x;->r(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object p1

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method public s(Ljava/lang/String;)Lcom/google/common/base/x;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nullText"
        }
    .end annotation

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const-string/jumbo v0, "iseumbdoNcyrfilrlpls eeFuea "

    const-string/jumbo v0, "seemNucrsaoepul idldfr Fliey"

    const/4 v2, 0x6

    const-string v0, "essriNuoFepfd ldaelceayr uui"

    const-string v0, "already specified useForNull"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1
.end method
