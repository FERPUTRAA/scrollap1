.class Lcom/google/common/base/x0$i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/w0;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/w0<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field final predicate:Lcom/google/common/base/w0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/w0<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/base/w0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "predicate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/w0<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/base/w0;

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/base/r0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "t"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    xor-int/lit8 p1, p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    instance-of v0, p1, Lcom/google/common/base/x0$i;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Lcom/google/common/base/x0$i;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/google/common/base/w0;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    not-int v0, v0

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "tss.siatPe(odce"

    const-string v1, "aesircPtd(.seot"

    const/4 v3, 0x6

    const-string v1, "dnomi.c(rPteats"

    const-string v1, "Predicates.not("

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/base/x0$i;->predicate:Lcom/google/common/base/w0;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x7

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method
