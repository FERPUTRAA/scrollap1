.class final Lcom/google/common/base/e$u;
.super Lcom/google/common/base/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "u"
.end annotation


# static fields
.field static final b:Lcom/google/common/base/e$u;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcom/google/common/base/e$u;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/base/e$u;-><init>()V

    const/4 v2, 0x1

    sput-object v0, Lcom/google/common/base/e$u;->b:Lcom/google/common/base/e$u;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/base/e;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@smv@~1uo~  b db-~ ~~~~~~~~~ot@~   o. / ~ ~@no M@ro@c  li~~ i@@ y@~~@@@s~@f t/@4il@fob@~@aK S@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Character;

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "UCrmsch.er(t)CrehMaaaapjepa"

    const-string v0, "CharMatcher.javaUpperCase()"

    const/4 v1, 0x7

    const/4 v1, 0x4

    return-object v0
.end method
