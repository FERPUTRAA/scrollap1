.class public final synthetic Lcom/google/common/base/b1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Spliterator;Z)Ljava/util/stream/Stream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s@o @ o  1 ~@b~~~u  ~t~lc~@ o m @v~~~a@~~~ ti@ro@~@~~i@b~.@fS@ @bios~/~@  4@@ @dM f@K~~-y~o/@l"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0, p1}, Ljava/util/stream/StreamSupport;->stream(Ljava/util/Spliterator;Z)Ljava/util/stream/Stream;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method
