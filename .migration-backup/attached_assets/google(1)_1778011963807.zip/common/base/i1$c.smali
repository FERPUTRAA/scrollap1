.class Lcom/google/common/base/i1$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/h1<",
        "TT;>;"
    }
.end annotation

.annotation build Lx4/e;
.end annotation


# static fields
.field private static final c:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private volatile a:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation
.end field

.field private b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/base/j1;

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/base/j1;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/google/common/base/i1$c;->c:Lcom/google/common/base/h1;

    const/4 v2, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method constructor <init>(Lcom/google/common/base/h1;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/h1<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Lcom/google/common/base/h1;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public static synthetic a()Ljava/lang/Void;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~so@ di. f ~~~~lo~@@b@ ~i@~ynfo~ ~-u~@li@/v@~@a /t @~o4@ bcr ~o  @@ S~~o~ s@~@tM@~bK@m @@ ~1 ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/common/base/i1$c;->b()Ljava/lang/Void;

    move-result-object v0

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method private static synthetic b()Ljava/lang/Void;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    throw v0
.end method


# virtual methods
.method public get()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Lcom/google/common/base/i1$c;->c:Lcom/google/common/base/h1;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/common/base/i1$c;->b:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw v0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/base/i1$c;->b:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/common/base/l0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/base/i1$c;->a:Lcom/google/common/base/h1;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v2, "iu(mperzi.ssemempl"

    const-string/jumbo v2, "irsmSpimuzepsee(l."

    const/4 v4, 0x3

    const-string v2, ".speoezuomiei(mprl"

    const-string v2, "Suppliers.memoize("

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object v2, Lcom/google/common/base/i1$c;->c:Lcom/google/common/base/h1;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-ne v0, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v2, "u<amph etdu er itslerrnt"

    const/4 v4, 0x5

    const-string v2, "apth besel rd ur<tniptur"

    const-string v2, "<supplier that returned "

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/base/i1$c;->b:Ljava/lang/Object;

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ">"

    const-string v2, ">"

    const/4 v4, 0x1

    const-string v2, ">"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v0, ")"

    const-string v0, ")"

    const/4 v4, 0x3

    const-string v0, ")"

    const-string v0, ")"

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0
.end method
