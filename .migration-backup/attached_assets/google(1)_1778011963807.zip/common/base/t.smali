.class final Lcom/google/common/base/t;
.super Lcom/google/common/base/m;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<F:",
        "Ljava/lang/Object;",
        "T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/base/m<",
        "TF;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final function:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "-TF;+TT;>;"
        }
    .end annotation
.end field

.field private final resultEquivalence:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/base/s;Lcom/google/common/base/m;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "function",
            "resultEquivalence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/s<",
            "-TF;+TT;>;",
            "Lcom/google/common/base/m<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/base/m;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lcom/google/common/base/m;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "a",
            "b"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TF;TF;)Z"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v1, p2}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/google/common/base/m;->d(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p1
.end method

.method protected b(Ljava/lang/Object;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TF;)I"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-interface {v1, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/google/common/base/m;->f(Ljava/lang/Object;)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne p1, p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v4, 0x6

    instance-of v1, p1, Lcom/google/common/base/t;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast p1, Lcom/google/common/base/t;

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v5, 0x2

    const/4 v4, 0x7

    iget-object v3, p1, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v1, v3}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v2
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/t;->resultEquivalence:Lcom/google/common/base/m;

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v1, "ofsOsRentul."

    const-string/jumbo v1, "tlssn.fRouO("

    const-string v1, ".onResultOf("

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/base/t;->function:Lcom/google/common/base/s;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x6

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method
