.class public Lcom/google/common/base/internal/Finalizer;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static final d:Ljava/util/logging/Logger;

.field private static final e:Ljava/lang/String; = "com.google.common.base.FinalizableReference"

.field private static final f:Ljava/lang/reflect/Constructor;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/reflect/Constructor<",
            "Ljava/lang/Thread;",
            ">;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private static final g:Ljava/lang/reflect/Field;
    .annotation runtime Lv7/a;
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Ljava/lang/Class<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/lang/ref/PhantomReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/PhantomReference<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/lang/ref/ReferenceQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/ReferenceQueue<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-class v0, Lcom/google/common/base/internal/Finalizer;

    const-class v0, Lcom/google/common/base/internal/Finalizer;

    const/4 v2, 0x0

    const-class v0, Lcom/google/common/base/internal/Finalizer;

    const-class v0, Lcom/google/common/base/internal/Finalizer;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/base/internal/Finalizer;->d:Ljava/util/logging/Logger;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/base/internal/Finalizer;->b()Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Lcom/google/common/base/internal/Finalizer;->f:Ljava/lang/reflect/Constructor;

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/base/internal/Finalizer;->d()Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/base/internal/Finalizer;->g:Ljava/lang/reflect/Field;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/Class;Ljava/lang/ref/ReferenceQueue;Ljava/lang/ref/PhantomReference;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "finalizableReferenceClass",
            "queue",
            "frqReference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/ref/ReferenceQueue<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/ref/PhantomReference<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/common/base/internal/Finalizer;->c:Ljava/lang/ref/ReferenceQueue;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/base/internal/Finalizer;->a:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/google/common/base/internal/Finalizer;->b:Ljava/lang/ref/PhantomReference;

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method private a(Ljava/lang/ref/Reference;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "reference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/Reference<",
            "*>;)Z"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/google/common/base/internal/Finalizer;->c()Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->clear()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/common/base/internal/Finalizer;->b:Ljava/lang/ref/PhantomReference;

    const/4 v6, 0x3

    if-ne p1, v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    return v1

    :cond_1
    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, p1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    sget-object v2, Lcom/google/common/base/internal/Finalizer;->d:Ljava/util/logging/Logger;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v3, Ljava/util/logging/Level;->SEVERE:Ljava/util/logging/Level;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v4, "eEsucnrrl ranerpsae ice .tfgforere"

    const-string v4, "crsrrrnpeguE.i oetlafnreeerf e nac"

    const/4 v6, 0x2

    const-string/jumbo v4, "eugml aera p.crEft eoner ncrfeirer"

    const-string v4, "Error cleaning up after reference."

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v3, v4, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/google/common/base/internal/Finalizer;->c:Ljava/lang/ref/ReferenceQueue;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-nez p1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 p1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    return p1
.end method

.method private static b()Ljava/lang/reflect/Constructor;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/reflect/Constructor<",
            "Ljava/lang/Thread;",
            ">;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-class v0, Ljava/lang/Thread;

    const-class v0, Ljava/lang/Thread;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v1, 0x5

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v5, 0x2

    const-class v2, Ljava/lang/ThreadGroup;

    const-class v2, Ljava/lang/ThreadGroup;

    const/4 v5, 0x4

    const-class v2, Ljava/lang/ThreadGroup;

    const-class v2, Ljava/lang/ThreadGroup;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    aput-object v2, v1, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-class v2, Ljava/lang/Runnable;

    const-class v2, Ljava/lang/Runnable;

    const/4 v5, 0x7

    const-class v2, Ljava/lang/Runnable;

    const-class v2, Ljava/lang/Runnable;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    aput-object v2, v1, v3

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x5

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    aput-object v2, v1, v3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v3, 0x4

    const/4 v5, 0x6

    const/4 v3, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x2

    aput-object v2, v1, v3

    const/4 v5, 0x3

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v3, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v0

    :catchall_0
    const/4 v5, 0x5

    const/4 v0, 0x5

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v0
.end method

.method private c()Ljava/lang/reflect/Method;
    .locals 5
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/base/internal/Finalizer;->a:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const-string/jumbo v1, "nlreozieRmnftaee"

    const-string v1, "Reemlrfneatzefni"

    const/4 v4, 0x0

    const-string v1, "eaeenbltezfiriRn"

    const-string/jumbo v1, "finalizeReferent"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/AssertionError;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw v1
.end method

.method private static d()Ljava/lang/reflect/Field;
    .locals 5
    .annotation runtime Lv7/a;
    .end annotation

    :try_start_0
    const-class v0, Ljava/lang/Thread;

    const-class v0, Ljava/lang/Thread;

    const/4 v4, 0x1

    const-class v0, Ljava/lang/Thread;

    const-class v0, Ljava/lang/Thread;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "oehhLiucsbolnltrrTaeiae"

    const-string/jumbo v1, "hleToitrbroacehaiLledns"

    const/4 v4, 0x4

    const-string/jumbo v1, "ieeeaahpdTLahlblcisrron"

    const-string/jumbo v1, "inheritableThreadLocals"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0

    :catchall_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/google/common/base/internal/Finalizer;->d:Ljava/util/logging/Logger;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object v1, Ljava/util/logging/Level;->INFO:Ljava/util/logging/Level;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v2, "u.rlheLiq rRisaaTaen.nfsadta/rwtci  nhTaeehhl zlcl aoetb cnredll oieavetc snrlahoi eersriCieeletscldf/e hbdrd."

    const-string/jumbo v2, "rholrbra dzrseslhta hfacllci vaTC.ecnle.lcatiieTbdsuoer/e  iedsaeRs eedarci nhw l/.dhaLelel intah roatretinnfe"

    const/4 v4, 0x7

    const-string/jumbo v2, "hssaaocr/nnhoas.cnri ei cetClrnhrtee llzrl.ioisiavcfa  eadl.ewaelbldae aedhihr u d/efir ReTrtlutdlnctTehs eesL"

    const-string v2, "Couldn\'t access Thread.inheritableThreadLocals. Reference finalizer threads will inherit thread local values."

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method public static startFinalizer(Ljava/lang/Class;Ljava/lang/ref/ReferenceQueue;Ljava/lang/ref/PhantomReference;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "finalizableReferenceClass",
            "queue",
            "frqReference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/ref/ReferenceQueue<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/ref/PhantomReference<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v1, "caemebreiilmcgf.enoogsaeneRFuob.olmemzo.n.c"

    const-string v1, "caeibeumrnzeeRgm.ioo.nblomFeaae.lncec.osofg"

    const/4 v6, 0x4

    const-string/jumbo v1, "reenosagifmecR.ocl.e.eaobFozglnbonolc.iamee"

    const-string v1, "com.google.common.base.FinalizableReference"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    new-instance v0, Lcom/google/common/base/internal/Finalizer;

    const/4 v6, 0x5

    invoke-direct {v0, p0, p1, p2}, Lcom/google/common/base/internal/Finalizer;-><init>(Ljava/lang/Class;Ljava/lang/ref/ReferenceQueue;Ljava/lang/ref/PhantomReference;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-class p0, Lcom/google/common/base/internal/Finalizer;

    const-class p0, Lcom/google/common/base/internal/Finalizer;

    const/4 v6, 0x6

    const-class p0, Lcom/google/common/base/internal/Finalizer;

    const-class p0, Lcom/google/common/base/internal/Finalizer;

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object p1, Lcom/google/common/base/internal/Finalizer;->f:Ljava/lang/reflect/Constructor;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 p2, 0x1

    const/4 v5, 0x1

    move v6, v5

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz p1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, 0x5

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v3, 0x0

    move v5, v3

    move v5, v3

    const/4 v6, 0x2

    aput-object v1, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object v0, v2, p2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    aput-object p0, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v4, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-object v3, v2, v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v4, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    aput-object v3, v2, v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, v2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    check-cast p1, Ljava/lang/Thread;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v2, Lcom/google/common/base/internal/Finalizer;->d:Ljava/util/logging/Logger;

    const/4 v5, 0x3

    move v6, v5

    sget-object v3, Ljava/util/logging/Level;->INFO:Ljava/util/logging/Level;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v4, "hto rbaaeitc  udehuaoteerlvtthelpeFirlda eatadiis-onha  dc wre "

    const-string v4, "-craavope ai ldsrieoFah raoati ne edrt ltecedteiheu ahth dltutw"

    const/4 v6, 0x5

    const-string v4, "Failed to create a thread without inherited thread-local values"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2, v3, v4, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x1

    move v6, v5

    new-instance p1, Ljava/lang/Thread;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {p1, v1, v0, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;)V

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/Thread;->setDaemon(Z)V

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    sget-object p0, Lcom/google/common/base/internal/Finalizer;->g:Ljava/lang/reflect/Field;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p0, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0, p1, v1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object p2, Lcom/google/common/base/internal/Finalizer;->d:Ljava/util/logging/Logger;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object v0, Ljava/util/logging/Level;->INFO:Ljava/util/logging/Level;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v1, "aeaioru t eaerqtaeltlursecdefd alFelhiciznrcb h ih.vier af lee loyed anedtnr"

    const-string/jumbo v1, "nafarfeeqi  secl ded nehbohaoiretaldt rirv eace tullceF ezrn. etiaallrheyidr"

    const/4 v6, 0x5

    const-string v1, "Failed to clear thread local values inherited by reference finalizer thread."

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p2, v0, v1, p0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_3
    const/4 v6, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const-string/jumbo p1, "msoeecfponmgFbn.i.gEo tmredx.la.oRsiceeeplolcnae.ceab"

    const-string/jumbo p1, "zts.eRebcoceF.raslgbc.e. xnoeceeomoplmeoanndEimilfa.g"

    const/4 v6, 0x3

    const-string p1, "Expected com.google.common.base.FinalizableReference."

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    throw p0
.end method


# virtual methods
.method public run()V
    .locals 3

    :catch_0
    :cond_0
    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/base/internal/Finalizer;->c:Ljava/lang/ref/ReferenceQueue;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->remove()Ljava/lang/ref/Reference;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/common/base/internal/Finalizer;->a(Ljava/lang/ref/Reference;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method
