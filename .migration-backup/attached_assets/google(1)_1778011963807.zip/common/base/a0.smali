.class public final synthetic Lcom/google/common/base/a0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/OptionalLong;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~~l@rood4@.@~ ~@i  t~~~  o 1 Mo~fb@l@ -@/ctK ~auv ~~@@~ ~n~ ~b~@~s@m @@~~@i@yo~o/~ f~S  i @@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/util/OptionalLong;->isPresent()Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method
