.class final Lcom/google/common/base/t0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/t0$b;
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final a:Ljava/util/logging/Logger;

.field private static final b:Lcom/google/common/base/s0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-class v0, Lcom/google/common/base/t0;

    const-class v0, Lcom/google/common/base/t0;

    const/4 v2, 0x0

    const-class v0, Lcom/google/common/base/t0;

    const-class v0, Lcom/google/common/base/t0;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/google/common/base/t0;->a:Ljava/util/logging/Logger;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/common/base/t0;->f()Lcom/google/common/base/s0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/google/common/base/t0;->b:Lcom/google/common/base/s0;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "-@sM@o ~@o @@t@~co@ @~vn @ b~/m~~@@rl  ~~ ~  ~t~@i~a o bd~  4i fy~1/l@@Kus @~bi~~f~@oo@.~~@~@S~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const-string/jumbo v0, "sslmf"

    const-string/jumbo v0, "seslf"

    const/4 v5, 0x4

    const-string v0, "eaflo"

    const-string/jumbo v0, "false"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "gtpmmn.e_eyulabeaecveggrrnawc_e."

    const/4 v5, 0x1

    const-string v1, ".wbnpbcaergemeela_raegvrentg_.cu"

    const-string/jumbo v1, "guava.gwt.emergency_reenable_rpc"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v1, v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v0, Lcom/google/common/base/t0;->a:Ljava/util/logging/Logger;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/Throwable;

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-direct {v2}, Ljava/lang/Throwable;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v3, "Tn yhcui.nii revsnwpoeant rW n2ol  kwYytn0u ceapndoa ioacT hoa ttegt PeraYsitmvC ipaa dCf w  ar igh he  Ras,R-w sh r apbm nc.ttye.o veGsle cubha Geeagno ne eyr Li0b Gsleero- rssl  ps2cvdhtuik alwtuetoafkyGce tlcitraea y,weui otaehuaPW  eeig i nu"

    const-string v3, "-rGnolaaic efah ,vsp t aw  w opievohW Gbtt .ytl a dyYcpliikg nnsuRhegcaon tLCh iswcreuPs twpe b t 2eeemagra e ath vls pc etr ieairhhstunukdyiC  a  TTayoiy ,eYaatkRaulePo erW0nacrtnn  ue beo.h-   eecdnef iena Gioronirmlevy t G0a wt gea2.s uscowsi"

    const/4 v5, 0x3

    const-string v3, "e vheoiptevtnvgh sa a yrciorGsrr-.tkheyiiluea nyeciosTuosvgw2nw nWh  rf ptwng0antd ,uas raa eoai rkwlecd erYon cbetmk  yeL  da. ,-Gcl0eitaalae  eG h  naa 2 P ltoYcWafpgp eG teuC shciiylhu RbpCPaeraRe anpw th u  otii atteeniwb cTeysuem irs ns.  t"

    const-string v3, "Later in 2020, we will remove GWT-RPC support for Guava types. You are seeing this warning because you are sending a Guava type over GWT-RPC, which will break. You can identify which type by looking at the class name in the attached stack trace."

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v3, v2}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v2, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    aput-object v1, v2, v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v3, "cf4o8s1tq5erobk8tl5c14/6w:/o9vqs/./m9p/2h"

    const-string v3, "4p4ttbr6.c1cv8otlq9s1/:ok/5e/5298/fwh/mso"

    const/4 v5, 0x5

    const-string/jumbo v3, "https://stackoverflow.com/q/5189914/28465"

    const/4 v5, 0x6

    const/4 v4, 0x6

    aput-object v3, v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x2

    const/4 v5, 0x4

    const-string v3, "egsuondznAovJgsQgsp/N/ulcooYwg/eoTdorn.H.ag/h7tEHsn:cm/u3g/F-Zrea/auFpm"

    const-string/jumbo v3, "ogd-avuna3g7uoQsagohp/wnEnHnmeo../gcAcprToY:mloF/udzeHNewsJ/usgtZgr/F//"

    const/4 v5, 0x2

    const-string v3, "ZFgme.aYr7/opwgouFAl/trwzohu/gs:amgHdEescp.J3Q/as/HTgcnodo/nuev/ntg-omn"

    const-string/jumbo v3, "https://groups.google.com/d/msg/guava-announce/zHZTFg7YF3o/rQNnwdHeEwAJ"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    aput-object v3, v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v1, "r raogrbeaueooaemrmmC uesP.ruRp rgseyra sps  vtG  ysb ltesGemPira t t  eiFsteu/np eCpoaoeropt,rFsttyirumoyul a i ssTyW Wur nrstp %RGereocup.-setnetresTfoeva esb-,upot vmyY. eb oe  to t nep rpGW t.rohporo  %ea/soapp  os "

    const-string/jumbo v1, "oRerrpPpuG tetomtGiTbsmr-et terpeo  ,y Tmteaeavtaoome Wasb cgntrt/rp %usb..pnsp  u a eCe s osoyoas  /tepa stu sGumr%r-uPpm euepy urp% eprCuan  ttarrv eRsyolp rYoobeF resvoyF oWs tn Wto .fe ph risro. risrel,yaeGgeo eiss "

    const/4 v5, 0x5

    const-string v1, " ornlb%pr tas  yssr oco .tp upestpateylbtWot   eF-re%epC srPa asvnogoreas msWCorrp p.RaerTtg /ifsuR, r pvi sGmo b  pmst es uutsWeou pmh%ey bYe sureumprytGr ta.rs-yenemePetboo/r.te Gueovpn o   oi a yFsetT rttrGoeaoeeira,"

    const-string v1, "We are removing GWT-RPC support for Guava types. You can temporarily reenable support by setting the system property %s to true. For more about system properties, see %s. For more about Guava\'s GWT-RPC support, see %s."

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v2}, Lcom/google/common/base/g1;->e(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw v0
.end method

.method static b(Ljava/lang/String;)Lcom/google/common/base/h;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pattern"
        }
    .end annotation

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/t0;->b:Lcom/google/common/base/s0;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lcom/google/common/base/s0;->a(Ljava/lang/String;)Lcom/google/common/base/h;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/common/base/t0;->k(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p0, 0x0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method static d(D)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x3

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    aput-object p0, v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string p0, "4.g%"

    const-string p0, "%.4g"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p0, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0
.end method

.method static e(Ljava/lang/Class;Ljava/lang/String;)Lcom/google/common/base/p0;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enumClass",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Enum<",
            "TT;>;>(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Ljava/lang/String;",
            ")",
            "Lcom/google/common/base/p0<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/base/l;->a(Ljava/lang/Class;)Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p1, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/common/base/p0;->a()Lcom/google/common/base/p0;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    check-cast p0, Ljava/lang/Enum;

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p0}, Lcom/google/common/base/p0;->g(Ljava/lang/Object;)Lcom/google/common/base/p0;

    move-result-object p0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method private static f()Lcom/google/common/base/s0;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/base/t0$b;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/common/base/t0$b;-><init>(Lcom/google/common/base/t0$a;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method private static g(Ljava/util/ServiceConfigurationError;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "e"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v0, Lcom/google/common/base/t0;->a:Ljava/util/logging/Logger;

    const/4 v4, 0x4

    const/4 v3, 0x5

    sget-object v1, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v4, 0x7

    const-string/jumbo v2, "mnlnle xqa f  tcldpriparioongte ob, noltr o gcEarigxreioe"

    const/4 v4, 0x2

    const-string/jumbo v2, "kg cErunna,lnxotmlrrl orpbgi eoonec ifodxatope ea g til r"

    const-string v2, "Error loading regex compiler, falling back to next option"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2, p0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    return-void
.end method

.method static h(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x1

    const-string p0, ""

    const-string p0, ""

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method static i()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/base/t0;->b:Lcom/google/common/base/s0;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/google/common/base/s0;->b()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method static j(Lcom/google/common/base/e;)Lcom/google/common/base/e;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "matcher"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/common/base/e;->K()Lcom/google/common/base/e;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method static k(Ljava/lang/String;)Z
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-eqz p0, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p0, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method
