.class public final Lcom/google/common/base/y;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/y$b;
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public static a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "first",
            "second"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;TT;)TT;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-object p0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    if-eqz p1, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    const-string/jumbo p1, "tasorr Bnle mea sahestrl"

    const-string p1, "Bmslrla auhtrree tso nea"

    const/4 v1, 0x3

    const-string p1, "aehmlu  a nlrBretpmoraet"

    const-string p1, "Both parameters are null"

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    throw p0
.end method

.method public static b(Ljava/lang/Class;)Lcom/google/common/base/y$b;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "clazz"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/google/common/base/y$b;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/google/common/base/y$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, p0, v1}, Lcom/google/common/base/y$b;-><init>(Ljava/lang/String;Lcom/google/common/base/y$a;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public static c(Ljava/lang/Object;)Lcom/google/common/base/y$b;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "self"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Lcom/google/common/base/y$b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    move v3, v2

    invoke-direct {v0, p0, v1}, Lcom/google/common/base/y$b;-><init>(Ljava/lang/String;Lcom/google/common/base/y$a;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method public static d(Ljava/lang/String;)Lcom/google/common/base/y$b;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "className"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lcom/google/common/base/y$b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/google/common/base/y$b;-><init>(Ljava/lang/String;Lcom/google/common/base/y$a;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method
