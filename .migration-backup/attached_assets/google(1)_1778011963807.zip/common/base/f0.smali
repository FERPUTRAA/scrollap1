.class public final synthetic Lcom/google/common/base/f0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Optional;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s @d  ~o@ot ~ M~uo@~~ b iSia@ ~   ~c@@~~~-~~@o~ f~@@@~@~~14/vsKblt~b / ~y@im @ nor.f~l@@ @@~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/util/Optional;->isPresent()Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p0
.end method
