.class Lcom/google/common/base/c1$c$a;
.super Lcom/google/common/base/c1$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/c1$c;->b(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Lcom/google/common/base/c1$g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic h:Lcom/google/common/base/g;


# direct methods
.method constructor <init>(Lcom/google/common/base/c1$c;Lcom/google/common/base/c1;Ljava/lang/CharSequence;Lcom/google/common/base/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0,
            0x1010
        }
        names = {
            "this$0",
            "splitter",
            "toSplit",
            "val$matcher"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/google/common/base/c1$c$a;->h:Lcom/google/common/base/g;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p2, p3}, Lcom/google/common/base/c1$g;-><init>(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public e(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPosition"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "M~s~o~ /@.t@@n~a o@ @~1o@~f v~yfl dor- i@ 4 @~~~@i@b@cli~b@K@@ @~osu~@~~~@b t  m/  ~@  ~ ~@~S@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/google/common/base/c1$c$a;->h:Lcom/google/common/base/g;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/google/common/base/g;->a()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    return p1
.end method

.method public f(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "start"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/base/c1$c$a;->h:Lcom/google/common/base/g;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/base/g;->c(I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/common/base/c1$c$a;->h:Lcom/google/common/base/g;

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/common/base/g;->f()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method
