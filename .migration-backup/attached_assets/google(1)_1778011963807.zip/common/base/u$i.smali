.class final enum Lcom/google/common/base/u$i;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/base/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/base/u$i;",
        ">;",
        "Lcom/google/common/base/s<",
        "Ljava/lang/Object;",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/base/u$i;

.field private static final synthetic b:[Lcom/google/common/base/u$i;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Lcom/google/common/base/u$i;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v1, "ENsCTINs"

    const-string v1, "NNsIESTC"

    const/4 v4, 0x3

    const-string v1, "ENCmTIAN"

    const-string v1, "INSTANCE"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/u$i;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    sput-object v0, Lcom/google/common/base/u$i;->a:Lcom/google/common/base/u$i;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/common/base/u$i;->a()[Lcom/google/common/base/u$i;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    sput-object v0, Lcom/google/common/base/u$i;->b:[Lcom/google/common/base/u$i;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/base/u$i;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@  o@~4~~~urKo~o~@@@~/i@@i~  1@ @l ~~ v-~~ s~ ~  dom@y@ ~ ~catM@@fo @St ~~ bibol@n@b~~/~o.@ @f~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x6

    new-array v0, v0, [Lcom/google/common/base/u$i;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    sget-object v2, Lcom/google/common/base/u$i;->a:Lcom/google/common/base/u$i;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/base/u$i;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/base/u$i;

    const-class v0, Lcom/google/common/base/u$i;

    const/4 v2, 0x0

    const-class v0, Lcom/google/common/base/u$i;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    check-cast p0, Lcom/google/common/base/u$i;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/google/common/base/u$i;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/base/u$i;->b:[Lcom/google/common/base/u$i;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/google/common/base/u$i;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, [Lcom/google/common/base/u$i;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/base/u$i;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public b(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "S)nctboFcomniitiFtutn(.rnsno"

    const-string v0, "Ft)mnF(nouttrcg.nncosiSoinit"

    const/4 v2, 0x0

    const-string v0, ".toutnuo)FsuFntcigtcinri(Snn"

    const-string v0, "Functions.toStringFunction()"

    return-object v0
.end method
