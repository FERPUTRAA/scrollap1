.class public final Lcom/google/common/base/f1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field private final a:Lcom/google/common/base/l1;

.field private b:Z

.field private c:J

.field private d:J


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/base/l1;->b()Lcom/google/common/base/l1;

    move-result-object v0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/base/f1;->a:Lcom/google/common/base/l1;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>(Lcom/google/common/base/l1;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ticker"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "kisres"

    const-string/jumbo v0, "kesric"

    const/4 v2, 0x5

    const-string/jumbo v0, "etrmkc"

    const-string/jumbo v0, "ticker"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p1, Lcom/google/common/base/l1;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/common/base/f1;->a:Lcom/google/common/base/l1;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method private static a(Ljava/util/concurrent/TimeUnit;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unit"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "f~~Mo  ~Sod~o/~c~~1l@~ to@~@lb@~~b@K@~~@a@@~@ @@ soio r@@v    -y ~@ ~ib~~ .~@@u/t@ m@nf@ io~ ~4~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/base/f1$a;->a:[I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    aget p0, v0, p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    packed-switch p0, :pswitch_data_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    throw p0

    :pswitch_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string p0, "d"

    const-string p0, "d"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :pswitch_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const-string/jumbo p0, "h"

    const-string/jumbo p0, "h"

    const/4 v2, 0x5

    const-string/jumbo p0, "h"

    const-string/jumbo p0, "h"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0

    :pswitch_2
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo p0, "min"

    const-string/jumbo p0, "imn"

    const/4 v2, 0x0

    const-string/jumbo p0, "inm"

    const-string/jumbo p0, "min"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0

    :pswitch_3
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo p0, "s"

    const-string/jumbo p0, "s"

    const-string/jumbo p0, "s"

    const-string/jumbo p0, "s"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0

    :pswitch_4
    const/4 v2, 0x6

    const-string/jumbo p0, "ms"

    const-string/jumbo p0, "ms"

    const/4 v2, 0x6

    const-string/jumbo p0, "sm"

    const-string/jumbo p0, "ms"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :pswitch_5
    const/4 v2, 0x4

    const/4 v1, 0x3

    const-string/jumbo p0, "s/bmuc0"

    const/4 v2, 0x0

    const-string p0, "c/bsub3"

    const-string/jumbo p0, "\u03bcs"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0

    :pswitch_6
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo p0, "ns"

    const-string/jumbo p0, "sn"

    const/4 v2, 0x3

    const-string/jumbo p0, "ns"

    const-string/jumbo p0, "ns"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static b(J)Ljava/util/concurrent/TimeUnit;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nanos"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v0, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    cmp-long v2, v2, v4

    const/4 v6, 0x4

    move v7, v6

    if-lez v2, :cond_0

    const/4 v6, 0x6

    move v7, v6

    return-object v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    sget-object v0, Ljava/util/concurrent/TimeUnit;->HOURS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-lez v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    return-object v0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-lez v2, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object v0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    cmp-long v2, v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-lez v2, :cond_3

    const/4 v7, 0x2

    return-object v0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-lez v2, :cond_4

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object v0

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MICROSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, p0, p1, v1}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    cmp-long p0, p0, v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-lez p0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v0

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object v1
.end method

.method public static c()Lcom/google/common/base/f1;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/base/f1;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/common/base/f1;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/common/base/f1;->l()Lcom/google/common/base/f1;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public static d(Lcom/google/common/base/l1;)Lcom/google/common/base/f1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ticker"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/base/f1;

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/base/f1;-><init>(Lcom/google/common/base/l1;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/common/base/f1;->l()Lcom/google/common/base/f1;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static e()Lcom/google/common/base/f1;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/f1;

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/base/f1;-><init>()V

    const/4 v2, 0x7

    return-object v0
.end method

.method public static f(Lcom/google/common/base/l1;)Lcom/google/common/base/f1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ticker"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/base/f1;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    invoke-direct {v0, p0}, Lcom/google/common/base/f1;-><init>(Lcom/google/common/base/l1;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method private i()J
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-boolean v0, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/common/base/f1;->a:Lcom/google/common/base/l1;

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/common/base/l1;->a()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/common/base/f1;->d:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    sub-long/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/base/f1;->c:J

    const/4 v5, 0x1

    add-long/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/google/common/base/f1;->c:J

    :goto_0
    const/4 v5, 0x1

    return-wide v0
.end method


# virtual methods
.method public g(Ljava/util/concurrent/TimeUnit;)J
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "desiredUnit"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/common/base/f1;->i()J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object v2, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-wide v0
.end method

.method public h()Ljava/time/Duration;
    .locals 4
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/common/base/f1;->i()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/base/e1;->a(J)Ljava/time/Duration;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public k()Lcom/google/common/base/f1;
    .locals 4
    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/google/common/base/f1;->c:J

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0
.end method

.method public l()Lcom/google/common/base/f1;
    .locals 5
    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    xor-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v2, "osnsetuTpiyts ganniu  aa.hiodlhr c"

    const-string/jumbo v2, "sreioocanTt hnp nl  drtii.sauagshy"

    const/4 v4, 0x0

    const-string v2, "  pirtwpch adisyeonsstgnrauTlnha.i"

    const-string v2, "This stopwatch is already running."

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0, v2}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean v1, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/base/f1;->a:Lcom/google/common/base/l1;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/common/base/l1;->a()J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/google/common/base/f1;->d:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    return-object p0
.end method

.method public m()Lcom/google/common/base/f1;
    .locals 8
    .annotation build Ly4/a;
    .end annotation

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/common/base/f1;->a:Lcom/google/common/base/l1;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/google/common/base/l1;->a()J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-boolean v2, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo v3, "spiiowe qtdTcrpesohbasl.s  pd ayth"

    const-string/jumbo v3, "ishawbcts.  d lsorapydptehi peotsT"

    const/4 v7, 0x4

    const-string/jumbo v3, "ldsae. owsespidapts  hroThtycs pai"

    const-string v3, "This stopwatch is already stopped."

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v2, v3}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-boolean v2, p0, Lcom/google/common/base/f1;->b:Z

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/google/common/base/f1;->c:J

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-wide v4, p0, Lcom/google/common/base/f1;->d:J

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    sub-long/2addr v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-long/2addr v2, v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    iput-wide v2, p0, Lcom/google/common/base/f1;->c:J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/google/common/base/f1;->i()J

    move-result-wide v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lcom/google/common/base/f1;->b(J)Ljava/util/concurrent/TimeUnit;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    long-to-double v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget-object v3, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x2

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v3, v4, v5, v2}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    long-to-double v3, v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    div-double/2addr v0, v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lcom/google/common/base/t0;->d(D)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v0, " "

    const-string v0, " "

    const/4 v7, 0x4

    const-string v0, " "

    const-string v0, " "

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-static {v2}, Lcom/google/common/base/f1;->a(Ljava/util/concurrent/TimeUnit;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object v0
.end method
