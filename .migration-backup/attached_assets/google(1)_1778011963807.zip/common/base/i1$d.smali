.class Lcom/google/common/base/i1$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<F:",
        "Ljava/lang/Object;",
        "T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/h1<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field final function:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "-TF;TT;>;"
        }
    .end annotation
.end field

.field final supplier:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "TF;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/base/s;Lcom/google/common/base/h1;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "function",
            "supplier"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/s<",
            "-TF;TT;>;",
            "Lcom/google/common/base/h1<",
            "TF;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p1, Lcom/google/common/base/h1;

    iput-object p1, p0, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, ".ls  @1 ~~b-~db f@~o~a@@  o ~@@io~m/ ~S~~@~~@~@4K ~~ oo~l@ t @v u @@ c@/i~si~@y n~r@b~f~@~tM@o@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    instance-of v0, p1, Lcom/google/common/base/i1$d;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    check-cast p1, Lcom/google/common/base/i1$d;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p1, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0, v2}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p1, p1, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v1
.end method

.method public get()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v1}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, v1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "epimSessor.mpcuosl"

    const-string/jumbo v1, "rSsesooppl.cemsiup"

    const/4 v3, 0x3

    const-string/jumbo v1, "rpiuoSmps.(oecpols"

    const-string v1, "Suppliers.compose("

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/base/i1$d;->function:Lcom/google/common/base/s;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x7

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/common/base/i1$d;->supplier:Lcom/google/common/base/h1;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x6

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method
