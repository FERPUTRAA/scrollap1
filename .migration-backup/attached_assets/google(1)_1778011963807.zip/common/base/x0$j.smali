.class abstract enum Lcom/google/common/base/x0$j;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/base/w0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4408
    name = "j"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/base/x0$j;",
        ">;",
        "Lcom/google/common/base/w0<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/base/x0$j;

.field public static final enum b:Lcom/google/common/base/x0$j;

.field public static final enum c:Lcom/google/common/base/x0$j;

.field public static final enum d:Lcom/google/common/base/x0$j;

.field private static final synthetic e:[Lcom/google/common/base/x0$j;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Lcom/google/common/base/x0$j$a;

    const/4 v4, 0x7

    const-string v1, "ATsSsU_LAYR"

    const-string v1, "R_sYSULATEA"

    const/4 v4, 0x0

    const-string v1, "TUEmL_RWAYA"

    const-string v1, "ALWAYS_TRUE"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/x0$j$a;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    sput-object v0, Lcom/google/common/base/x0$j;->a:Lcom/google/common/base/x0$j;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Lcom/google/common/base/x0$j$b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "ALS_oYAmSFAE"

    const-string v1, "ALSmAEAY_LSF"

    const/4 v4, 0x6

    const-string v1, "ALWAYS_FALSE"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/x0$j$b;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/base/x0$j;->b:Lcom/google/common/base/x0$j;

    const/4 v4, 0x0

    new-instance v0, Lcom/google/common/base/x0$j$c;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v1, "NUISobL"

    const-string v1, "USLNoI_"

    const/4 v4, 0x2

    const-string v1, "LNILU_u"

    const-string v1, "IS_NULL"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/x0$j$c;-><init>(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/base/x0$j;->c:Lcom/google/common/base/x0$j;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Lcom/google/common/base/x0$j$d;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const-string v1, "b_NLTLNp"

    const-string v1, "T_NNObLL"

    const/4 v4, 0x5

    const-string/jumbo v1, "qNL_OTNU"

    const-string v1, "NOT_NULL"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/x0$j$d;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    sput-object v0, Lcom/google/common/base/x0$j;->d:Lcom/google/common/base/x0$j;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/common/base/x0$j;->a()[Lcom/google/common/base/x0$j;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    sput-object v0, Lcom/google/common/base/x0$j;->e:[Lcom/google/common/base/x0$j;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;ILcom/google/common/base/x0$a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/common/base/x0$j;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/base/x0$j;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s@4 io/S~~@nK~i~@~ ~~ ~o s~ @@t @d@~@@/@~~vbl~@~@a~1bo@r~mc~oi @  ~@ f t@@ o ~ y u.-~ @fbol @@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-array v0, v0, [Lcom/google/common/base/x0$j;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Lcom/google/common/base/x0$j;->a:Lcom/google/common/base/x0$j;

    const/4 v4, 0x1

    const/4 v3, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v2, Lcom/google/common/base/x0$j;->b:Lcom/google/common/base/x0$j;

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x4

    move v3, v1

    move v3, v1

    const/4 v4, 0x6

    sget-object v2, Lcom/google/common/base/x0$j;->c:Lcom/google/common/base/x0$j;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Lcom/google/common/base/x0$j;->d:Lcom/google/common/base/x0$j;

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/base/x0$j;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/base/x0$j;

    const-class v0, Lcom/google/common/base/x0$j;

    const/4 v2, 0x2

    const-class v0, Lcom/google/common/base/x0$j;

    const-class v0, Lcom/google/common/base/x0$j;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p0, Lcom/google/common/base/x0$j;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lcom/google/common/base/x0$j;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/base/x0$j;->e:[Lcom/google/common/base/x0$j;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {v0}, [Lcom/google/common/base/x0$j;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, [Lcom/google/common/base/x0$j;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method b()Lcom/google/common/base/w0;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/base/w0<",
            "TT;>;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method
