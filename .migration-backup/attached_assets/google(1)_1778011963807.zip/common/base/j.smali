.class public final Lcom/google/common/base/j;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field private static final a:Ljava/lang/Double;

.field private static final b:Ljava/lang/Float;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sput-object v0, Lcom/google/common/base/j;->a:Ljava/lang/Double;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    sput-object v0, Lcom/google/common/base/j;->b:Ljava/lang/Float;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_7

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne p0, v0, :cond_0

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ne p0, v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ne p0, v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne p0, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-ne p0, v0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne p0, v0, :cond_5

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ne p0, v0, :cond_6

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object p0, Lcom/google/common/base/j;->b:Ljava/lang/Float;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0

    :cond_6
    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne p0, v0, :cond_7

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object p0, Lcom/google/common/base/j;->a:Ljava/lang/Double;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p0

    :cond_7
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0
.end method
