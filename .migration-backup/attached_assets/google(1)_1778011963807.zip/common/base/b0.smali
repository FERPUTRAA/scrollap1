.class public final synthetic Lcom/google/common/base/b0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s@~~-~@i~@@@4/ofb~ o~ / ~1 il~@~ ~~vu~@KM @  S~~@t @.~ i l@~ar ~d @bn@s @t @o@@~o~m@f o b@o~cy"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    instance-of p0, p0, Ljava/util/OptionalDouble;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0
.end method
