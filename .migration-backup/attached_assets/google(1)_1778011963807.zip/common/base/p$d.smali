.class Lcom/google/common/base/p$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/p$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# static fields
.field static a:Z
    .annotation build Lx4/e;
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Class;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-boolean v0, Lcom/google/common/base/p$d;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    return-object v1

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Ljava/lang/ClassLoader;->getSystemClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v2, "rnsal.oetzasinnm.Fiooenscgcml..ragomebol."

    const-string/jumbo v2, "sosmlicl.Fmrroo.ngiz.l.nacembitaeaoengo.n"

    const/4 v4, 0x0

    const-string/jumbo v2, "otcm.or.gnlmgeFsaln.r.mibimeeoanoilo.encz"

    const-string v2, "com.google.common.base.internal.Finalizer"

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, v2}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0

    :catch_0
    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v1

    :catch_1
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/common/base/p;->a()Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "mdyeoastsm tlcc sooloa asdceolw Ne lare .t"

    const-string/jumbo v2, "scwm.aatasNcedetslooad  soltolyrlemsce    "

    const/4 v4, 0x1

    const-string/jumbo v2, "seaeNb aomtl asctelddc.l e  lossys cwoaors"

    const-string v2, "Not allowed to access system class loader."

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/util/logging/Logger;->info(Ljava/lang/String;)V

    const/4 v4, 0x4

    return-object v1
.end method
