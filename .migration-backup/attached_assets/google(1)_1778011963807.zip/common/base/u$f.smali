.class final enum Lcom/google/common/base/u$f;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/base/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/base/u$f;",
        ">;",
        "Lcom/google/common/base/s<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/base/u$f;

.field private static final synthetic b:[Lcom/google/common/base/u$f;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Lcom/google/common/base/u$f;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "ECsNTSIA"

    const/4 v4, 0x6

    const-string v1, "TEsINASN"

    const-string v1, "INSTANCE"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Lcom/google/common/base/u$f;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/base/u$f;->a:Lcom/google/common/base/u$f;

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/common/base/u$f;->a()[Lcom/google/common/base/u$f;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    sput-object v0, Lcom/google/common/base/u$f;->b:[Lcom/google/common/base/u$f;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/base/u$f;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "lK~m @  vy/oM ~l~o@bco~@so.~@ r~d @ ~t~4~~@S~ @t  @~~@@ ~1~~uo@ab @f@ i@ @@~ni~~io~f ~ m@ ~@b-/@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-array v0, v0, [Lcom/google/common/base/u$f;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x3

    sget-object v2, Lcom/google/common/base/u$f;->a:Lcom/google/common/base/u$f;

    const/4 v4, 0x7

    const/4 v3, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/base/u$f;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const-class v0, Lcom/google/common/base/u$f;

    const-class v0, Lcom/google/common/base/u$f;

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/base/u$f;

    const-class v0, Lcom/google/common/base/u$f;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p0, Lcom/google/common/base/u$f;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lcom/google/common/base/u$f;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/base/u$f;->b:[Lcom/google/common/base/u$f;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/google/common/base/u$f;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast v0, [Lcom/google/common/base/u$f;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "t)dm(tuticneiinsyoF."

    const/4 v2, 0x0

    const-string v0, "(denoyo)tti.nFusnici"

    const-string v0, "Functions.identity()"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method
