.class public final Lcom/google/common/base/m1;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Ljava/lang/CharSequence;)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sequence"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@s@@y@  u~.o ~  K4@@  i c~~~oiS1tbban oo /lt-f~dfi~@l~b@~~@ @~@ ~~~ @@@@~ @@ ~~r~ov@ ~o/ ~@~sm@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ge v1, v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/16 v3, 0x80

    const/4 v6, 0x7

    if-ge v2, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    move v2, v0

    move v2, v0

    const/4 v6, 0x7

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    if-ge v1, v0, :cond_2

    const/4 v6, 0x3

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/16 v4, 0x800

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ge v3, v4, :cond_1

    const/4 v6, 0x2

    rsub-int/lit8 v3, v3, 0x7f

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    ushr-int/lit8 v3, v3, 0x1f

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/2addr v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p0, v1}, Lcom/google/common/base/m1;->b(Ljava/lang/CharSequence;I)I

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    add-int/2addr v2, p0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-lt v2, v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    return v2

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v1, "e:emn nsgotUlhni  idntFoT  ti ts -"

    const-string v1, " ishTiniFdn t lt8n  en  -:stoegotU"

    const/4 v6, 0x7

    const-string/jumbo v1, "fto o tl- nnd e:siT nFgit  eUhonit"

    const-string v1, "UTF-8 length does not fit in int: "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    int-to-long v1, v2

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    const-wide v3, 0x100000000L

    const-wide v3, 0x100000000L

    const/4 v6, 0x7

    const-wide v3, 0x100000000L

    const-wide v3, 0x100000000L

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-long/2addr v1, v3

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    throw p0
.end method

.method private static b(Ljava/lang/CharSequence;I)I
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sequence",
            "start"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x2

    if-ge p1, v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/16 v3, 0x800

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ge v2, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    rsub-int/lit8 v2, v2, 0x7f

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    ushr-int/lit8 v2, v2, 0x1f

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const v3, 0xd800

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-gt v3, v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const v3, 0xdfff

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-gt v2, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0, p1}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v3, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/common/base/m1;->f(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw p0

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x7

    return v1
.end method

.method public static c([B)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bytes"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    array-length v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-static {p0, v1, v0}, Lcom/google/common/base/m1;->d([BII)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p0
.end method

.method public static d([BII)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "bytes",
            "off",
            "len"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    add-int/2addr p2, p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    array-length v0, p0

    const/4 v2, 0x2

    invoke-static {p1, p2, v0}, Lcom/google/common/base/u0;->f0(III)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ge p1, p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    aget-byte v0, p0, p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-gez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0, p1, p2}, Lcom/google/common/base/m1;->e([BII)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    const/4 p0, 0x7

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p0
.end method

.method private static e([BII)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "bytes",
            "off",
            "end"
        }
    .end annotation

    :cond_0
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-lt p1, p2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 p0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    return p0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    add-int/lit8 v0, p1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    aget-byte p1, p0, p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-gez p1, :cond_c

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/16 v1, -0x20

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/16 v2, -0x41

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ge p1, v1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ne v0, p2, :cond_2

    const/4 v7, 0x7

    return v3

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/16 v1, -0x3e

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lt p1, v1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-int/lit8 p1, v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    aget-byte v0, p0, v0

    const/4 v7, 0x5

    if-le v0, v2, :cond_0

    :cond_3
    const/4 v7, 0x1

    return v3

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/16 v4, -0x10

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-ge p1, v4, :cond_9

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/lit8 v4, v0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-lt v4, p2, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    return v3

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    aget-byte v0, p0, v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-gt v0, v2, :cond_8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/16 v5, -0x60

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne p1, v1, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-lt v0, v5, :cond_8

    :cond_6
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/16 v1, -0x13

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-ne p1, v1, :cond_7

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-le v5, v0, :cond_8

    :cond_7
    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 p1, v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    aget-byte v0, p0, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-le v0, v2, :cond_0

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x1

    return v3

    :cond_9
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    add-int/lit8 v1, v0, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-lt v1, p2, :cond_a

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    return v3

    :cond_a
    const/4 v7, 0x5

    add-int/lit8 v1, v0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    aget-byte v0, p0, v0

    const/4 v7, 0x4

    if-gt v0, v2, :cond_b

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    shl-int/lit8 p1, p1, 0x1c

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/lit8 v0, v0, 0x70

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/2addr p1, v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    shr-int/lit8 p1, p1, 0x1e

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez p1, :cond_b

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 p1, v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    aget-byte v0, p0, v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-gt v0, v2, :cond_b

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    add-int/lit8 v0, p1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    aget-byte p1, p0, p1

    const/4 v7, 0x4

    if-le p1, v2, :cond_c

    :cond_b
    const/4 v7, 0x0

    const/4 v6, 0x6

    return v3

    :cond_c
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    move p1, v0

    move p1, v0

    const/4 v7, 0x5

    move p1, v0

    move p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto/16 :goto_0
.end method

.method private static f(I)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "adruxbeagdom siUrttane r  pi"

    const-string v1, "deamti taoirde as Uxr unpgre"

    const/4 v3, 0x1

    const-string v1, "Unpaired surrogate at index "

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0
.end method
