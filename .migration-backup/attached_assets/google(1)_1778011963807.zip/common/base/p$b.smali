.class Lcom/google/common/base/p$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/p$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Class;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s1@/ y~~@~@-~@co@o @~  o@ ~~@~m/@  iut~~~d~@r ~~S@ Kna @sfo@il@ @~f@ voib~~ ~t  b. @4l@@~bM~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const-string v0, "cenmgncgaraesomimt.Fnboi.sz.ae.nillo.lemo"

    const-string/jumbo v0, "lmsanenombFomsioriaaz.cnei.go.telo.e.lgnc"

    const/4 v3, 0x6

    const-string/jumbo v0, "o.gcozrloncbomoenima.oea.n.atiieFgn.selrm"

    const-string v0, "com.google.common.base.internal.Finalizer"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v1, Ljava/lang/AssertionError;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v1
.end method
