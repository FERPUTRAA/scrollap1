.class public final synthetic Lcom/google/common/base/d0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/OptionalDouble;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l@so@cn/@ S~@r~~@ . 4  it1o @@/ ~mdft@b i ~@a-@K~@@@~v@~i@~@~@~ f~o ~b ~ o  ~@~~u@s~ l~@obo~~y~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/util/OptionalDouble;->isPresent()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p0
.end method
