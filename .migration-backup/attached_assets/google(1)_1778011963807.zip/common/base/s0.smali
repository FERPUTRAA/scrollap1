.class interface abstract Lcom/google/common/base/s0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;)Lcom/google/common/base/h;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pattern"
        }
    .end annotation
.end method

.method public abstract b()Z
.end method
