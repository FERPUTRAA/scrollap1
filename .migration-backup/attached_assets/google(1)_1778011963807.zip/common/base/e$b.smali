.class final Lcom/google/common/base/e$b;
.super Lcom/google/common/base/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation


# instance fields
.field final b:Lcom/google/common/base/e;

.field final c:Lcom/google/common/base/e;


# direct methods
.method constructor <init>(Lcom/google/common/base/e;Lcom/google/common/base/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "a",
            "b"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/base/e;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Lcom/google/common/base/e;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/e$b;->b:Lcom/google/common/base/e;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/base/e;

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/base/e$b;->c:Lcom/google/common/base/e;

    const/4 v0, 0x7

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/tss-~ ~~oK @.~~~~ ~r@ 4S@1nt~@v~fblf@~~@@@ @@oc@@ ~M@@y~m~~~~ i @~ o al@/@ b@i uo@o b~~~di@   o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/common/base/e$b;->b:Lcom/google/common/base/e;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->B(C)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/common/base/e$b;->c:Lcom/google/common/base/e;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/base/e;->B(C)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Ljava/util/BitSet;

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/BitSet;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/base/e$b;->b:Lcom/google/common/base/e;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/google/common/base/e;->Q(Ljava/util/BitSet;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/util/BitSet;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/util/BitSet;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/common/base/e$b;->c:Lcom/google/common/base/e;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Lcom/google/common/base/e;->Q(Ljava/util/BitSet;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/BitSet;->and(Ljava/util/BitSet;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->or(Ljava/util/BitSet;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "character"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Character;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/base/e;->e(Ljava/lang/Character;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/common/base/e;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "rh(meMrhcaaa.tns"

    const-string v1, "ChsMhr(rat.aance"

    const/4 v3, 0x5

    const-string/jumbo v1, "r.haotnc(rCaMeah"

    const-string v1, "CharMatcher.and("

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/base/e$b;->b:Lcom/google/common/base/e;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x2

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/base/e$b;->c:Lcom/google/common/base/e;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x7

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method
