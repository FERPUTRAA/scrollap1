.class public final synthetic Lcom/google/common/base/i0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/OptionalInt;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @sod @~n~@ u@ybS~f@~@~t~v@f~o@@@~@ ~c M~-ot/@ s~~ ~Kl~m ~@@@@~@lb o~ i  ~ /~~biior~ao  .@ ~14@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/util/OptionalInt;->isPresent()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method
