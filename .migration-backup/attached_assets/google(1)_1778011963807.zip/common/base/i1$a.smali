.class Lcom/google/common/base/i1$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/h1<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/e;
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field volatile transient a:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field volatile transient b:J

.field final delegate:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "TT;>;"
        }
    .end annotation
.end field

.field final durationNanos:J


# direct methods
.method constructor <init>(Lcom/google/common/base/h1;JLjava/util/concurrent/TimeUnit;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "delegate",
            "duration",
            "unit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/h1<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p1, Lcom/google/common/base/h1;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/common/base/i1$a;->delegate:Lcom/google/common/base/h1;

    const/4 v3, 0x6

    invoke-virtual {p4, p2, p3}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/google/common/base/i1$a;->durationNanos:J

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    cmp-long p1, p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-lez p1, :cond_0

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x7

    const-string v0, "  s s m0ut)d>ta%un%sbriss (o"

    const-string/jumbo v0, "rustn)o% (au >  sisdest%m0 b"

    const/4 v3, 0x7

    const-string/jumbo v0, "rntm0steu(%  musib a)o  sd >"

    const-string v0, "duration (%s %s) must be > 0"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p1, v0, p2, p3, p4}, Lcom/google/common/base/u0;->t(ZLjava/lang/String;JLjava/lang/Object;)V

    const/4 v2, 0x7

    move v3, v2

    return-void
.end method


# virtual methods
.method public get()Ljava/lang/Object;
    .locals 10
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-wide v0, p0, Lcom/google/common/base/i1$a;->b:J

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    cmp-long v6, v0, v4

    const/4 v8, 0x5

    shl-int/2addr v9, v8

    if-eqz v6, :cond_0

    const/4 v9, 0x0

    sub-long v6, v2, v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    cmp-long v6, v6, v4

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-ltz v6, :cond_3

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-wide v6, p0, Lcom/google/common/base/i1$a;->b:J

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    cmp-long v0, v0, v6

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez v0, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/common/base/i1$a;->delegate:Lcom/google/common/base/h1;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-interface {v0}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    iput-object v0, p0, Lcom/google/common/base/i1$a;->a:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-wide v6, p0, Lcom/google/common/base/i1$a;->durationNanos:J

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    add-long/2addr v2, v6

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    cmp-long v1, v2, v4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v1, :cond_1

    const/4 v9, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    iput-wide v2, p0, Lcom/google/common/base/i1$a;->b:J

    const/4 v9, 0x4

    monitor-exit p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-object v0

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/common/base/i1$a;->a:Ljava/lang/Object;

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/google/common/base/l0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v3, 0x1

    move v4, v3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string/jumbo v1, "pxamEWiuilopp(ihretztrnSeim.osem"

    const-string/jumbo v1, "tirnopszmSaoEie(eoWh.lpmiiiputxr"

    const-string v1, "Suppliers.memoizeWithExpiration("

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/common/base/i1$a;->delegate:Lcom/google/common/base/h1;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v1, ", "

    const-string v1, ", "

    const-string v1, ", "

    const-string v1, ", "

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/google/common/base/i1$a;->durationNanos:J

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    const-string v1, ")oSN bA,"

    const-string v1, "O,)NoA S"

    const/4 v4, 0x3

    const-string v1, ",O) SNuN"

    const-string v1, ", NANOS)"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0
.end method
