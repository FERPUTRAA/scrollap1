.class abstract Lcom/google/common/base/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/b$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field private a:Lcom/google/common/base/b$b;

.field private b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method protected constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/base/b$b;->b:Lcom/google/common/base/b$b;

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private c()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "s@s~ /@~Mt@c@~~/ot@~~4f @dn~  io @@ l ~ @ bo.@y@@@~~ @~@~  @1bi~~mK~~f~u@ @ @@lSr v~~~bo~o ~oi- "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lcom/google/common/base/b$b;->d:Lcom/google/common/base/b$b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/common/base/b;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/common/base/b;->b:Ljava/lang/Object;

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    sget-object v1, Lcom/google/common/base/b$b;->c:Lcom/google/common/base/b$b;

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    sget-object v0, Lcom/google/common/base/b$b;->a:Lcom/google/common/base/b$b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x0

    return v0
.end method


# virtual methods
.method protected abstract a()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end method

.method protected final b()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    sget-object v0, Lcom/google/common/base/b$b;->c:Lcom/google/common/base/b$b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    return-object v0
.end method

.method public final hasNext()Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    sget-object v1, Lcom/google/common/base/b$b;->d:Lcom/google/common/base/b$b;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    move v0, v3

    move v0, v3

    const/4 v5, 0x2

    move v0, v3

    move v0, v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    move v0, v2

    move v0, v2

    const/4 v5, 0x5

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v0, Lcom/google/common/base/b$a;->a:[I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    aget v0, v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v0, v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq v0, v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/common/base/b;->c()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v2
.end method

.method public final next()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/base/r0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/common/base/b;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/google/common/base/b$b;->b:Lcom/google/common/base/b$b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/common/base/b;->a:Lcom/google/common/base/b$b;

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/base/b;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/common/base/l0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/google/common/base/b;->b:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw v0
.end method

.method public final remove()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    throw v0
.end method
