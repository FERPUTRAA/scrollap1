.class Lcom/google/common/base/x$c;
.super Ljava/util/AbstractList;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/x;->j(Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Iterable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/AbstractList<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/Object;

.field final synthetic b:Ljava/lang/Object;

.field final synthetic c:Ljava/lang/Object;


# direct methods
.method constructor <init>([Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$rest",
            "val$first",
            "val$second"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/x$c;->a:[Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/common/base/x$c;->b:Ljava/lang/Object;

    const/4 v0, 0x7

    move v1, v0

    iput-object p3, p0, Lcom/google/common/base/x$c;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/util/AbstractList;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public get(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/common/base/x$c;->a:[Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    aget-object p1, v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/common/base/x$c;->c:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1

    :cond_1
    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/common/base/x$c;->b:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/base/x$c;->a:[Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    array-length v0, v0

    const/4 v1, 0x5

    const/4 v2, 0x5

    add-int/lit8 v0, v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method
