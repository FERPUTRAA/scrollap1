.class abstract Lcom/google/common/base/n;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method
