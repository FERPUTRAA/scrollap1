.class public final synthetic Lcom/google/common/base/g0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ns @ sv~~d~~b~@ii~/@ @K ~ r@ b ~o@c @S@@@u ol1/@~fl@~t4t  ~@~@~ @y~.o~M~@@ofo  mi- @ao@@~ ~~~ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    instance-of p0, p0, Ljava/util/OptionalInt;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return p0
.end method
