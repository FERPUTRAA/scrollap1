.class final Lcom/google/common/base/i$c;
.super Lcom/google/common/base/i;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/base/i<",
        "TA;TB;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# instance fields
.field private final backwardFunction:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "-TB;+TA;>;"
        }
    .end annotation
.end field

.field private final forwardFunction:Lcom/google/common/base/s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/s<",
            "-TA;+TB;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lcom/google/common/base/s;Lcom/google/common/base/s;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "forwardFunction",
            "backwardFunction"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/s<",
            "-TA;+TB;>;",
            "Lcom/google/common/base/s<",
            "-TB;+TA;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/base/i;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/base/s;

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/base/s;Lcom/google/common/base/s;Lcom/google/common/base/i$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/common/base/i$c;-><init>(Lcom/google/common/base/s;Lcom/google/common/base/s;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "cMs f@~o@i@/f lrooby~~  bu~@/~ @  @i  ~~~ os4vS@ ~@@~- m@@K o~@t ~~~ ~@@i~~ @@a~l~.t@o@~1@nd@~~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    instance-of v0, p1, Lcom/google/common/base/i$c;

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast p1, Lcom/google/common/base/i$c;

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p1, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v0, v2}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, p1, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lcom/google/common/base/s;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v1
.end method

.method protected h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "b"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)TA;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    mul-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/2addr v0, v1

    const/4 v3, 0x4

    return v0
.end method

.method protected i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TA;)TB;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/google/common/base/s;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "ftnmoeseCo(r.vr"

    const-string/jumbo v1, "n(sfotrCreev.mo"

    const-string/jumbo v1, "rnetormofre(.Co"

    const-string v1, "Converter.from("

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/i$c;->forwardFunction:Lcom/google/common/base/s;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x4

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/i$c;->backwardFunction:Lcom/google/common/base/s;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const/4 v2, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    return-object v0
.end method
