.class Lcom/google/common/base/c1$a$a;
.super Lcom/google/common/base/c1$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/base/c1$a;->b(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)Lcom/google/common/base/c1$g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic h:Lcom/google/common/base/c1$a;


# direct methods
.method constructor <init>(Lcom/google/common/base/c1$a;Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0,
            0x0
        }
        names = {
            "this$0",
            "splitter",
            "toSplit"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/c1$a$a;->h:Lcom/google/common/base/c1$a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p2, p3}, Lcom/google/common/base/c1$g;-><init>(Lcom/google/common/base/c1;Ljava/lang/CharSequence;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method e(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "separatorPosition"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o sS@@@@ ~ /@@  ~~on@a@@   ~u~@@i~ d~~~~y.fv@blMo@i io 4@@~@ m1s~~bKo~~ b  @t~cr~/~ ~o~@ lf@@~-t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x6

    return p1
.end method

.method f(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "start"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/base/c1$a$a;->h:Lcom/google/common/base/c1$a;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, v0, Lcom/google/common/base/c1$a;->a:Lcom/google/common/base/e;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/base/c1$g;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Lcom/google/common/base/e;->o(Ljava/lang/CharSequence;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p1
.end method
