.class final Lcom/google/common/base/m$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/w0;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/base/w0<",
        "TT;>;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final equivalence:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "TT;>;"
        }
    .end annotation
.end field

.field private final target:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/base/m;Ljava/lang/Object;)V
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "equivalence",
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/m<",
            "TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/base/m;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v3, 0x7

    const-string v2, "/@s f~v  @r1oa~  ~uo~@@o~ @llo@@~@n~4~   @~i~K ~~@ot~ ~@.~c@ ~i @obM@@-fmti b~ @~@bS~@ s~ /~~yd@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1, v1}, Lcom/google/common/base/m;->d(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne p0, p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    instance-of v1, p1, Lcom/google/common/base/m$c;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    check-cast p1, Lcom/google/common/base/m$c;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v5, 0x3

    iget-object v3, p1, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p1, p1, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v5, 0x1

    invoke-static {v1, p1}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    const/4 v5, 0x0

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    return v0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v2
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x7

    move v3, v0

    move v3, v0

    const/4 v4, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    iget-object v2, p0, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v0
.end method

.method public synthetic test(Ljava/lang/Object;)Z
    .locals 2

    invoke-static {p0, p1}, Lcom/google/common/base/v0;->a(Lcom/google/common/base/w0;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/base/m$c;->equivalence:Lcom/google/common/base/m;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "vTsmqlieu(ane."

    const-string/jumbo v1, "ntsaiTueelvq.("

    const/4 v3, 0x3

    const-string/jumbo v1, "ilqToaenu(.vet"

    const-string v1, ".equivalentTo("

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/base/m$c;->target:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x3

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method
