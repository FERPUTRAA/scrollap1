.class public abstract enum Lcom/google/common/base/d;
.super Ljava/lang/Enum;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/base/d$f;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/base/d;",
        ">;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/base/d;

.field public static final enum b:Lcom/google/common/base/d;

.field public static final enum c:Lcom/google/common/base/d;

.field public static final enum d:Lcom/google/common/base/d;

.field public static final enum e:Lcom/google/common/base/d;

.field private static final synthetic f:[Lcom/google/common/base/d;


# instance fields
.field private final wordBoundary:Lcom/google/common/base/e;

.field private final wordSeparator:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    new-instance v0, Lcom/google/common/base/d$a;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/16 v1, 0x2d

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v1}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string v2, "-"

    const/4 v10, 0x4

    const-string v2, "-"

    const-string v2, "-"

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v3, "_YsHPHWsEONR"

    const-string v3, "HRsOPN_WYEEH"

    const/4 v10, 0x6

    const-string v3, "R_PmNWHEYHEL"

    const-string v3, "LOWER_HYPHEN"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/google/common/base/d$a;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    sput-object v0, Lcom/google/common/base/d;->a:Lcom/google/common/base/d;

    const/4 v9, 0x4

    move v10, v9

    new-instance v0, Lcom/google/common/base/d$b;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/16 v1, 0x5f

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string v3, "O_NDoRCLOEmRRSEW"

    const-string v3, "CROm_RNUDLOEESWR"

    const/4 v10, 0x0

    const-string v3, "SEEORbERWNULCDOR"

    const-string v3, "LOWER_UNDERSCORE"

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v4, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v5, "_"

    const-string v5, "_"

    const/4 v10, 0x6

    const-string v5, "_"

    const-string v5, "_"

    const/4 v10, 0x0

    invoke-direct {v0, v3, v4, v2, v5}, Lcom/google/common/base/d$b;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    sput-object v0, Lcom/google/common/base/d;->b:Lcom/google/common/base/d;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v0, Lcom/google/common/base/d$c;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/16 v2, 0x41

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/16 v3, 0x5a

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v2, v3}, Lcom/google/common/base/e;->m(CC)Lcom/google/common/base/e;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v6, "LREE_AuMOWL"

    const-string v6, "LOWER_CAMEL"

    const/4 v10, 0x7

    const/4 v7, 0x6

    const/4 v10, 0x7

    const/4 v7, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string v8, ""

    const-string v8, ""

    const/4 v10, 0x7

    const-string v8, ""

    const-string v8, ""

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {v0, v6, v7, v4, v8}, Lcom/google/common/base/d$c;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    sput-object v0, Lcom/google/common/base/d;->c:Lcom/google/common/base/d;

    const/4 v9, 0x4

    and-int/2addr v10, v9

    new-instance v0, Lcom/google/common/base/d$d;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v4, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v2, v3}, Lcom/google/common/base/e;->m(CC)Lcom/google/common/base/e;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    const-string v3, "MLPPAERpoUC"

    const-string v3, "UERLoM_APPC"

    const/4 v10, 0x4

    const-string v3, "RELPUCPEq_M"

    const-string v3, "UPPER_CAMEL"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-direct {v0, v3, v4, v2, v8}, Lcom/google/common/base/d$d;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    sput-object v0, Lcom/google/common/base/d;->d:Lcom/google/common/base/d;

    const/4 v10, 0x3

    const/4 v9, 0x6

    new-instance v0, Lcom/google/common/base/d$e;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v2, 0x4

    const/4 v10, 0x2

    invoke-static {v1}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string v3, "RNs_PRREPUEOSECb"

    const-string v3, "_DEREbPUORRNPESC"

    const/4 v10, 0x1

    const-string v3, "SERmEDNOER_CRPUU"

    const-string v3, "UPPER_UNDERSCORE"

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-direct {v0, v3, v2, v1, v5}, Lcom/google/common/base/d$e;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    sput-object v0, Lcom/google/common/base/d;->e:Lcom/google/common/base/d;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {}, Lcom/google/common/base/d;->a()[Lcom/google/common/base/d;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    sput-object v0, Lcom/google/common/base/d;->f:[Lcom/google/common/base/d;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "wordBoundary",
            "wordSeparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/e;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/common/base/d;->wordBoundary:Lcom/google/common/base/e;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/google/common/base/d;->wordSeparator:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;Lcom/google/common/base/d$a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/common/base/d;-><init>(Ljava/lang/String;ILcom/google/common/base/e;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/base/d;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~ oo@ ~ylo  @ ~ ~~bor @@~ 1@i/~-~~bol~@v @~@~@~ f b@@@i4os~@~f~@.@~~ tic/  noM@um KaS@@t~d@@~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-array v0, v0, [Lcom/google/common/base/d;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    shr-int/2addr v4, v1

    const/4 v3, 0x0

    move v4, v3

    sget-object v2, Lcom/google/common/base/d;->a:Lcom/google/common/base/d;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v2, Lcom/google/common/base/d;->b:Lcom/google/common/base/d;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x1

    sget-object v2, Lcom/google/common/base/d;->c:Lcom/google/common/base/d;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v2, Lcom/google/common/base/d;->d:Lcom/google/common/base/d;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v1, 0x4

    move v3, v1

    const/4 v4, 0x6

    sget-object v2, Lcom/google/common/base/d;->e:Lcom/google/common/base/d;

    aput-object v2, v0, v1

    const/4 v4, 0x4

    return-object v0
.end method

.method static synthetic b(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/common/base/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method private static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "word"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/google/common/base/c;->h(C)C

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/google/common/base/c;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/base/d;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-class v0, Lcom/google/common/base/d;

    const-class v0, Lcom/google/common/base/d;

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/base/d;

    const-class v0, Lcom/google/common/base/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p0, Lcom/google/common/base/d;

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public static values()[Lcom/google/common/base/d;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/base/d;->f:[Lcom/google/common/base/d;

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {v0}, [Lcom/google/common/base/d;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, [Lcom/google/common/base/d;

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method c(Lcom/google/common/base/d;Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "format",
            "s"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v2, -0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    move v3, v2

    move v3, v2

    const/4 v7, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/common/base/d;->wordBoundary:Lcom/google/common/base/e;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v4, p2, v3}, Lcom/google/common/base/e;->o(Ljava/lang/CharSequence;I)I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eq v3, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez v1, :cond_0

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v5, p1, Lcom/google/common/base/d;->wordSeparator:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    mul-int/lit8 v5, v5, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-int/2addr v4, v5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p2, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1, v1}, Lcom/google/common/base/d;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :cond_0
    const/4 v6, 0x4

    move v7, v6

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1, v1}, Lcom/google/common/base/d;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v1, p1, Lcom/google/common/base/d;->wordSeparator:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/common/base/d;->wordSeparator:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/2addr v1, v3

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v7, 0x3

    if-nez v1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1, p2}, Lcom/google/common/base/d;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_2

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Lcom/google/common/base/d;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object p1
.end method

.method public d(Lcom/google/common/base/d;)Lcom/google/common/base/i;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "targetFormat"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/d;",
            ")",
            "Lcom/google/common/base/i<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/base/d$f;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lcom/google/common/base/d$f;-><init>(Lcom/google/common/base/d;Lcom/google/common/base/d;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method f(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "word"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/base/d;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method abstract g(Ljava/lang/String;)Ljava/lang/String;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "word"
        }
    .end annotation
.end method

.method public final h(Lcom/google/common/base/d;Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "format",
            "str"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-ne p1, p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/common/base/d;->c(Lcom/google/common/base/d;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p2
.end method
