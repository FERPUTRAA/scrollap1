.class final Lcom/google/common/cache/v$e;
.super Ljava/util/AbstractQueue;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/AbstractQueue<",
        "Lcom/google/common/cache/f0<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final a:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/util/AbstractQueue;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/cache/v$e$a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$e$a;-><init>(Lcom/google/common/cache/v$e;)V

    const/4 v1, 0x6

    move v2, v1

    iput-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/f0;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)Z"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p1}, Lcom/google/common/cache/f0;->d()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/common/cache/v;->f(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/google/common/cache/f0;->d()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/google/common/cache/v;->f(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/common/cache/v;->f(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x0

    move v2, p1

    move v2, p1

    return p1
.end method

.method public b()Lcom/google/common/cache/f0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0
.end method

.method public clear()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/cache/v;->M(Lcom/google/common/cache/f0;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-interface {v1, v1}, Lcom/google/common/cache/f0;->p(Lcom/google/common/cache/f0;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, v0}, Lcom/google/common/cache/f0;->g(Lcom/google/common/cache/f0;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {p1}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/cache/v$r;->a:Lcom/google/common/cache/v$r;

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p1
.end method

.method public d()Lcom/google/common/cache/f0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    move v3, v0

    move v2, v0

    move v2, v0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v$e;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public isEmpty()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    and-int/2addr v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Lcom/google/common/cache/v$e$b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v$e;->b()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lcom/google/common/cache/v$e$b;-><init>(Lcom/google/common/cache/v$e;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic offer(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v$e;->a(Lcom/google/common/cache/f0;)Z

    move-result p1

    const/4 v0, 0x1

    move v1, v0

    return p1
.end method

.method public bridge synthetic peek()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v$e;->b()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic poll()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/cache/v$e;->d()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v2, 0x0

    move v3, v2

    invoke-interface {p1}, Lcom/google/common/cache/f0;->d()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/common/cache/v;->f(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/common/cache/v;->M(Lcom/google/common/cache/f0;)V

    const/4 v2, 0x5

    move v3, v2

    sget-object p1, Lcom/google/common/cache/v$r;->a:Lcom/google/common/cache/v$r;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq v1, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p1
.end method

.method public size()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/common/cache/v$e;->a:Lcom/google/common/cache/f0;

    const/4 v4, 0x3

    if-eq v0, v2, :cond_0

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/common/cache/f0;->f()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    return v1
.end method
