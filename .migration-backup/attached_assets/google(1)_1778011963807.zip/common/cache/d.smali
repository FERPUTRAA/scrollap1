.class public final synthetic Lcom/google/common/cache/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/time/Duration;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s ~ b~@ @ tf u/@m~~-@@@@i~ibo~@o n@ofl@~ ~c ~ @@ S~i@~K~do@~@@ 4Ma/~~~o.s@  r1 b~~tv~~o@ly ~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/time/Duration;->toNanos()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method
