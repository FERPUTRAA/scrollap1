.class Lcom/google/common/cache/h$c;
.super Lcom/google/common/cache/h$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/google/common/cache/h$f;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected b(Lcom/google/common/cache/h;I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "spec",
            "value"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "i~s@r@~f-. d~@@~@s om@/ @S~K~~o @i@ @oti@ ~~bl /~@1ol~~~vf ~oc@ Ma~@ ~~u o~~t@n@ @b~ 4~@@y ~  @b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p1, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v2, "vnsm l % oaoeyrrcstyusdceleas  warl tee"

    const-string/jumbo v2, "tsslewse yyue ceoaveal nrsrodl %t acrc "

    const/4 v4, 0x7

    const-string/jumbo v2, "vyeuo%ael yoc eanest tansrcr cso rldwel"

    const-string v2, "concurrency level was already set to %s"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object p2, p1, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x3

    return-void
.end method
