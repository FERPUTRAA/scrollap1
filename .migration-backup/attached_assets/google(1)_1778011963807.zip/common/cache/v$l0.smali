.class final Lcom/google/common/cache/v$l0;
.super Ljava/util/AbstractQueue;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "l0"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/AbstractQueue<",
        "Lcom/google/common/cache/f0<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final a:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/util/AbstractQueue;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/cache/v$l0$a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$l0$a;-><init>(Lcom/google/common/cache/v$l0;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/f0;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)Z"
        }
    .end annotation

    const/4 v3, 0x0

    const-string v2, "c.s@m@-f~ oo~i   S@@@~/K~~s@ tbb@@l~ ~u~~~~~@v@i @l  ~ ~~d@ o~i~n1~@ f4oyar~   @t@/ @bo~o@~@@@~M"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-interface {p1}, Lcom/google/common/cache/f0;->h()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/cache/v;->g(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v2, 0x4

    move v3, v2

    invoke-interface {v0}, Lcom/google/common/cache/f0;->h()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/google/common/cache/v;->g(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/common/cache/v;->g(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p1
.end method

.method public b()Lcom/google/common/cache/f0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method

.method public clear()V
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/common/cache/v;->N(Lcom/google/common/cache/f0;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v1, v1}, Lcom/google/common/cache/f0;->q(Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-interface {v0, v0}, Lcom/google/common/cache/f0;->s(Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-interface {p1}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/cache/v$r;->a:Lcom/google/common/cache/v$r;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1
.end method

.method public d()Lcom/google/common/cache/f0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v$l0;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public isEmpty()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/cache/v$l0$b;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/cache/v$l0;->b()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/google/common/cache/v$l0$b;-><init>(Lcom/google/common/cache/v$l0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic offer(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v$l0;->a(Lcom/google/common/cache/f0;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public bridge synthetic peek()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v$l0;->b()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic poll()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v$l0;->d()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast p1, Lcom/google/common/cache/f0;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p1}, Lcom/google/common/cache/f0;->h()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p1}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {v0, v1}, Lcom/google/common/cache/v;->g(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/common/cache/v;->N(Lcom/google/common/cache/f0;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object p1, Lcom/google/common/cache/v$r;->a:Lcom/google/common/cache/v$r;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eq v1, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p1
.end method

.method public size()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/common/cache/v$l0;->a:Lcom/google/common/cache/f0;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq v0, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/common/cache/f0;->e()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v1
.end method
