.class final Lcom/google/common/cache/v$k;
.super Lcom/google/common/cache/v$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/cache/v<",
        "TK;TV;>.j<TK;>;"
    }
.end annotation


# direct methods
.method constructor <init>(Lcom/google/common/cache/v;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/cache/v$j;-><init>(Lcom/google/common/cache/v;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public next()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TK;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "r@s@~ct~i~ ~~@~ ~ o . ~/@ln @o@ ta~o   @sM~@~o~b~ @f il S~@/o@-~  K@u1~d4@@bbm @i ~o@~v~@@~@~@~y"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->c()Lcom/google/common/cache/v$m0;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/google/common/cache/v$m0;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method
