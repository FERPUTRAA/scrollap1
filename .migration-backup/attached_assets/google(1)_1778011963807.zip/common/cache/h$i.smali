.class Lcom/google/common/cache/h$i;
.super Lcom/google/common/cache/h$h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "i"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/cache/h$h;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected b(Lcom/google/common/cache/h;J)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "spec",
            "value"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s@r@c@d~@~t@o~@~i~/Ky@~af@ @i @ o@Mn ib~~@~tf4@ ~@o~ lb ~@~~~ ~ ~bo@o~  -@~/@v lS o~  . m 1~su"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p1, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x1

    move v3, v1

    move v3, v1

    const/4 v6, 0x0

    move v3, v1

    move v3, v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    const/4 v6, 0x6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v4, " awm  a iiaetxds eulsmy%o smsmsrza"

    const-string/jumbo v4, "msssm d%srai lwzeeaxaiay  em tso u"

    const/4 v6, 0x1

    const-string/jumbo v4, "maximum size was already set to %s"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v3, v4, v0}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p1, Lcom/google/common/cache/h;->c:Ljava/lang/Long;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    move v6, v5

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v2, "y amotg siuamis  hexw%elm datae mrow"

    const-string v2, "alemw etsu dmam gro% iw  xstyishmeaa"

    const/4 v6, 0x2

    const-string v2, "%oyw bms iaxesm atutwdahetsm i  glre"

    const-string/jumbo v2, "maximum weight was already set to %s"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput-object p2, p1, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method
