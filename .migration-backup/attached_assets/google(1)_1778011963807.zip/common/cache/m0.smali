.class abstract Lcom/google/common/cache/m0;
.super Ljava/lang/Number;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/cache/m0$b;
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "[I>;"
        }
    .end annotation
.end field

.field static final c:Ljava/util/Random;

.field static final d:I

.field private static final e:Lsun/misc/Unsafe;

.field private static final f:J

.field private static final g:J


# instance fields
.field volatile transient a:[Lcom/google/common/cache/m0$b;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field volatile transient base:J

.field volatile transient busy:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v4, 0x7

    and-int/2addr v5, v4

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v5, 0x4

    sput-object v0, Lcom/google/common/cache/m0;->b:Ljava/lang/ThreadLocal;

    const/4 v5, 0x0

    new-instance v0, Ljava/util/Random;

    const/4 v4, 0x0

    move v5, v4

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    sput-object v0, Lcom/google/common/cache/m0;->c:Ljava/util/Random;

    const/4 v5, 0x7

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    sput v0, Lcom/google/common/cache/m0;->d:I

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/common/cache/m0;->g()Lsun/misc/Unsafe;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    sput-object v0, Lcom/google/common/cache/m0;->e:Lsun/misc/Unsafe;

    const/4 v5, 0x7

    const-class v1, Lcom/google/common/cache/m0;

    const-class v1, Lcom/google/common/cache/m0;

    const/4 v5, 0x0

    const-string v2, "abes"

    const-string v2, "abse"

    const/4 v5, 0x2

    const-string/jumbo v2, "sabe"

    const-string v2, "base"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-wide v2, Lcom/google/common/cache/m0;->f:J

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v2, "buys"

    const-string/jumbo v2, "suby"

    const/4 v5, 0x2

    const-string/jumbo v2, "syub"

    const-string v2, "busy"

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    sput-wide v0, Lcom/google/common/cache/m0;->g:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/Error;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Ljava/lang/Error;-><init>(Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    throw v1
.end method

.method constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Number;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic c()Lsun/misc/Unsafe;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@Ks o~t - .~ @/~~y ~@~m~ Snl/c@o@ ui@a ~~M@dt~v~@o@r ~@o~ l@b @@1f @~~ ii@@~ ~bs @@@ 4~b~~o~o @f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/google/common/cache/m0;->g()Lsun/misc/Unsafe;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method private static g()Lsun/misc/Unsafe;
    .locals 5

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {}, Lsun/misc/Unsafe;->getUnsafe()Lsun/misc/Unsafe;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object v0

    :catch_0
    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/google/common/cache/m0$a;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/google/common/cache/m0$a;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/security/AccessController;->doPrivileged(Ljava/security/PrivilegedExceptionAction;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v0, Lsun/misc/Unsafe;
    :try_end_1
    .catch Ljava/security/PrivilegedActionException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :catch_1
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "iszmnniiiientallt td  iCrsosuni"

    const-string/jumbo v2, "oCsiidile in zntutissctin liarn"

    const/4 v4, 0x5

    const-string/jumbo v2, "nrsio oCtn zoilicidu sitietinna"

    const-string v2, "Could not initialize intrinsics"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/security/PrivilegedActionException;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw v1
.end method


# virtual methods
.method final d(JJ)Z
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "cmp",
            "val"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    sget-object v0, Lcom/google/common/cache/m0;->e:Lsun/misc/Unsafe;

    const/4 v9, 0x3

    sget-wide v2, Lcom/google/common/cache/m0;->f:J

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-wide v4, p1

    move-wide v6, p3

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual/range {v0 .. v7}, Lsun/misc/Unsafe;->compareAndSwapLong(Ljava/lang/Object;JJJ)Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    return p1
.end method

.method final e()Z
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object v0, Lcom/google/common/cache/m0;->e:Lsun/misc/Unsafe;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget-wide v2, Lcom/google/common/cache/m0;->g:J

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v5, 0x1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual/range {v0 .. v5}, Lsun/misc/Unsafe;->compareAndSwapInt(Ljava/lang/Object;JII)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    return v0
.end method

.method abstract f(JJ)J
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "currentValue",
            "newValue"
        }
    .end annotation
.end method

.method final h(J)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "initialValue"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-wide p1, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    array-length v1, v0

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x0

    move v5, v4

    if-ge v2, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    aget-object v3, v0, v2

    const/4 v5, 0x5

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-wide p1, v3, Lcom/google/common/cache/m0$b;->value:J

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    return-void
.end method

.method final i(J[IZ)V
    .locals 16
    .param p3    # [I
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "x",
            "hc",
            "wasUncontended"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-wide/from16 v2, p1

    const/4 v0, 0x1

    const/4 v4, 0x0

    if-nez p3, :cond_1

    sget-object v5, Lcom/google/common/cache/m0;->b:Ljava/lang/ThreadLocal;

    new-array v6, v0, [I

    invoke-virtual {v5, v6}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    sget-object v5, Lcom/google/common/cache/m0;->c:Ljava/util/Random;

    invoke-virtual {v5}, Ljava/util/Random;->nextInt()I

    move-result v5

    if-nez v5, :cond_0

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    :cond_0
    aput v5, v6, v4

    goto :goto_0

    :cond_1
    aget v5, p3, v4

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    :goto_0
    move v8, v4

    move v8, v4

    move v8, v4

    move v8, v4

    move v7, v5

    move v7, v5

    move v7, v5

    move v7, v5

    move/from16 v5, p4

    move/from16 v5, p4

    move/from16 v5, p4

    move/from16 v5, p4

    :cond_2
    :goto_1
    iget-object v9, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-eqz v9, :cond_d

    array-length v10, v9

    if-lez v10, :cond_d

    add-int/lit8 v11, v10, -0x1

    and-int/2addr v11, v7

    aget-object v11, v9, v11

    if-nez v11, :cond_5

    iget v9, v1, Lcom/google/common/cache/m0;->busy:I

    if-nez v9, :cond_4

    new-instance v9, Lcom/google/common/cache/m0$b;

    invoke-direct {v9, v2, v3}, Lcom/google/common/cache/m0$b;-><init>(J)V

    iget v10, v1, Lcom/google/common/cache/m0;->busy:I

    if-nez v10, :cond_4

    invoke-virtual/range {p0 .. p0}, Lcom/google/common/cache/m0;->e()Z

    move-result v10

    if-eqz v10, :cond_4

    :try_start_0
    iget-object v10, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-eqz v10, :cond_3

    array-length v11, v10

    if-lez v11, :cond_3

    add-int/lit8 v11, v11, -0x1

    and-int/2addr v11, v7

    aget-object v12, v10, v11

    if-nez v12, :cond_3

    aput-object v9, v10, v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    goto :goto_2

    :cond_3
    move v9, v4

    move v9, v4

    move v9, v4

    move v9, v4

    :goto_2
    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    if-eqz v9, :cond_2

    goto/16 :goto_7

    :catchall_0
    move-exception v0

    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    throw v0

    :cond_4
    :goto_3
    move v8, v4

    move v8, v4

    move v8, v4

    move v8, v4

    goto :goto_5

    :cond_5
    if-nez v5, :cond_6

    move v5, v0

    move v5, v0

    goto :goto_5

    :cond_6
    iget-wide v12, v11, Lcom/google/common/cache/m0$b;->value:J

    invoke-virtual {v1, v12, v13, v2, v3}, Lcom/google/common/cache/m0;->f(JJ)J

    move-result-wide v14

    invoke-virtual {v11, v12, v13, v14, v15}, Lcom/google/common/cache/m0$b;->a(JJ)Z

    move-result v11

    if-eqz v11, :cond_7

    goto/16 :goto_7

    :cond_7
    sget v11, Lcom/google/common/cache/m0;->d:I

    if-ge v10, v11, :cond_4

    iget-object v11, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-eq v11, v9, :cond_8

    goto :goto_3

    :cond_8
    if-nez v8, :cond_9

    move v8, v0

    move v8, v0

    move v8, v0

    move v8, v0

    goto :goto_5

    :cond_9
    iget v11, v1, Lcom/google/common/cache/m0;->busy:I

    if-nez v11, :cond_c

    invoke-virtual/range {p0 .. p0}, Lcom/google/common/cache/m0;->e()Z

    move-result v11

    if-eqz v11, :cond_c

    :try_start_1
    iget-object v8, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-ne v8, v9, :cond_b

    shl-int/lit8 v8, v10, 0x1

    new-array v8, v8, [Lcom/google/common/cache/m0$b;

    move v11, v4

    move v11, v4

    move v11, v4

    :goto_4
    if-ge v11, v10, :cond_a

    aget-object v12, v9, v11

    aput-object v12, v8, v11

    add-int/lit8 v11, v11, 0x1

    goto :goto_4

    :cond_a
    iput-object v8, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_b
    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    move v8, v4

    move v8, v4

    goto/16 :goto_1

    :catchall_1
    move-exception v0

    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    throw v0

    :cond_c
    :goto_5
    shl-int/lit8 v9, v7, 0xd

    xor-int/2addr v7, v9

    ushr-int/lit8 v9, v7, 0x11

    xor-int/2addr v7, v9

    shl-int/lit8 v9, v7, 0x5

    xor-int/2addr v7, v9

    aput v7, v6, v4

    goto/16 :goto_1

    :cond_d
    iget v10, v1, Lcom/google/common/cache/m0;->busy:I

    if-nez v10, :cond_f

    iget-object v10, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-ne v10, v9, :cond_f

    invoke-virtual/range {p0 .. p0}, Lcom/google/common/cache/m0;->e()Z

    move-result v10

    if-eqz v10, :cond_f

    :try_start_2
    iget-object v10, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    if-ne v10, v9, :cond_e

    const/4 v9, 0x2

    new-array v9, v9, [Lcom/google/common/cache/m0$b;

    and-int/lit8 v10, v7, 0x1

    new-instance v11, Lcom/google/common/cache/m0$b;

    invoke-direct {v11, v2, v3}, Lcom/google/common/cache/m0$b;-><init>(J)V

    aput-object v11, v9, v10

    iput-object v9, v1, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    goto :goto_6

    :cond_e
    move v9, v4

    move v9, v4

    move v9, v4

    :goto_6
    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    if-eqz v9, :cond_2

    goto :goto_7

    :catchall_2
    move-exception v0

    iput v4, v1, Lcom/google/common/cache/m0;->busy:I

    throw v0

    :cond_f
    iget-wide v9, v1, Lcom/google/common/cache/m0;->base:J

    invoke-virtual {v1, v9, v10, v2, v3}, Lcom/google/common/cache/m0;->f(JJ)J

    move-result-wide v11

    invoke-virtual {v1, v9, v10, v11, v12}, Lcom/google/common/cache/m0;->d(JJ)Z

    move-result v9

    if-eqz v9, :cond_2

    :goto_7
    return-void
.end method
