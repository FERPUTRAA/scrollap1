.class public final synthetic Lcom/google/common/cache/w;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/function/Predicate;Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "sus~idt/b~@@o~b@@f14o. @~~~t@v  @   omi~lcbK~l @~@ @~~ @~@~@~ @Mo~of~ @~ @  -/ o ~~ry@@@@n~ia S~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-interface {p0, p1}, Ljava/util/function/Predicate;->test(Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return p0
.end method
