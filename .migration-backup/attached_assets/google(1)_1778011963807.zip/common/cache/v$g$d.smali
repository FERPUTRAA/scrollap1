.class final enum Lcom/google/common/cache/v$g$d;
.super Lcom/google/common/cache/v$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v$g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4010
    name = null
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/cache/v$g;-><init>(Ljava/lang/String;ILcom/google/common/cache/v$a;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method c(Lcom/google/common/cache/v$s;Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;Ljava/lang/Object;)Lcom/google/common/cache/f0;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "segment",
            "original",
            "newNext",
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;TK;)",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/common/cache/v$g;->c(Lcom/google/common/cache/v$s;Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;Ljava/lang/Object;)Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-virtual {p0, p2, p1}, Lcom/google/common/cache/v$g;->b(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p0, p2, p1}, Lcom/google/common/cache/v$g;->d(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-object p1
.end method

.method f(Lcom/google/common/cache/v$s;Ljava/lang/Object;ILcom/google/common/cache/f0;)Lcom/google/common/cache/f0;
    .locals 2
    .param p4    # Lcom/google/common/cache/f0;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "segment",
            "key",
            "hash",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;TK;I",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    new-instance p1, Lcom/google/common/cache/v$w;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p1, p2, p3, p4}, Lcom/google/common/cache/v$w;-><init>(Ljava/lang/Object;ILcom/google/common/cache/f0;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method
