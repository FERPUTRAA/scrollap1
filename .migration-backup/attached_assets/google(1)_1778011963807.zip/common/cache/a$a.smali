.class public final Lcom/google/common/cache/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/a$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Lcom/google/common/cache/b0;

.field private final b:Lcom/google/common/cache/b0;

.field private final c:Lcom/google/common/cache/b0;

.field private final d:Lcom/google/common/cache/b0;

.field private final e:Lcom/google/common/cache/b0;

.field private final f:Lcom/google/common/cache/b0;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/common/cache/a$a;->a:Lcom/google/common/cache/b0;

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/cache/a$a;->b:Lcom/google/common/cache/b0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/common/cache/a$a;->c:Lcom/google/common/cache/b0;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/common/cache/a$a;->d:Lcom/google/common/cache/b0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/common/cache/a$a;->e:Lcom/google/common/cache/b0;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/cache/c0;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/common/cache/a$a;->f:Lcom/google/common/cache/b0;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method private static h(J)J
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~isyvc@@@ m  l~@d@@ @i~~/@@b~ ~~o@@ou@ a/~ 4 t S@t@~@~@.~ ~ ~ r@lo ~1i~os~o  n~~@b-~fof ~M~K@@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    cmp-long v0, p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-wide p0, 0x7fffffffffffffffL

    const-wide p0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    const-wide p0, 0x7fffffffffffffffL

    const-wide p0, 0x7fffffffffffffffL

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-wide p0
.end method


# virtual methods
.method public a(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "count"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/cache/a$a;->a:Lcom/google/common/cache/b0;

    const/4 v3, 0x0

    move v4, v3

    int-to-long v1, p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    return-void
.end method

.method public b(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "count"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/cache/a$a;->b:Lcom/google/common/cache/b0;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    int-to-long v1, p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/a$a;->f:Lcom/google/common/cache/b0;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/google/common/cache/b0;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public d(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "loadTime"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/a$a;->d:Lcom/google/common/cache/b0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-interface {v0}, Lcom/google/common/cache/b0;->a()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/cache/a$a;->e:Lcom/google/common/cache/b0;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public e(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "loadTime"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/cache/a$a;->c:Lcom/google/common/cache/b0;

    const/4 v1, 0x6

    move v2, v1

    invoke-interface {v0}, Lcom/google/common/cache/b0;->a()V

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/a$a;->e:Lcom/google/common/cache/b0;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public f()Lcom/google/common/cache/k;
    .locals 15

    const/4 v14, 0x0

    new-instance v13, Lcom/google/common/cache/k;

    const/4 v14, 0x4

    iget-object v0, p0, Lcom/google/common/cache/a$a;->a:Lcom/google/common/cache/b0;

    const/4 v14, 0x7

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v0

    const/4 v14, 0x2

    invoke-static {v0, v1}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v1

    const/4 v14, 0x3

    iget-object v0, p0, Lcom/google/common/cache/a$a;->b:Lcom/google/common/cache/b0;

    const/4 v14, 0x0

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v3

    const/4 v14, 0x1

    invoke-static {v3, v4}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v3

    const/4 v14, 0x3

    iget-object v0, p0, Lcom/google/common/cache/a$a;->c:Lcom/google/common/cache/b0;

    const/4 v14, 0x4

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v5

    const/4 v14, 0x1

    invoke-static {v5, v6}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v5

    const/4 v14, 0x1

    iget-object v0, p0, Lcom/google/common/cache/a$a;->d:Lcom/google/common/cache/b0;

    const/4 v14, 0x3

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v7

    const/4 v14, 0x5

    invoke-static {v7, v8}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v7

    const/4 v14, 0x4

    iget-object v0, p0, Lcom/google/common/cache/a$a;->e:Lcom/google/common/cache/b0;

    const/4 v14, 0x5

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v9

    const/4 v14, 0x0

    invoke-static {v9, v10}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v9

    const/4 v14, 0x6

    iget-object v0, p0, Lcom/google/common/cache/a$a;->f:Lcom/google/common/cache/b0;

    const/4 v14, 0x0

    invoke-interface {v0}, Lcom/google/common/cache/b0;->b()J

    move-result-wide v11

    const/4 v14, 0x3

    invoke-static {v11, v12}, Lcom/google/common/cache/a$a;->h(J)J

    move-result-wide v11

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    const/4 v14, 0x0

    invoke-direct/range {v0 .. v12}, Lcom/google/common/cache/k;-><init>(JJJJJJ)V

    const/4 v14, 0x3

    return-object v13
.end method

.method public g(Lcom/google/common/cache/a$b;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p1}, Lcom/google/common/cache/a$b;->f()Lcom/google/common/cache/k;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/cache/a$a;->a:Lcom/google/common/cache/b0;

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/common/cache/k;->c()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/cache/a$a;->b:Lcom/google/common/cache/b0;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/common/cache/k;->j()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/cache/a$a;->c:Lcom/google/common/cache/b0;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/common/cache/k;->h()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/cache/a$a;->d:Lcom/google/common/cache/b0;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/k;->f()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/cache/a$a;->e:Lcom/google/common/cache/b0;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/common/cache/k;->n()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/cache/a$a;->f:Lcom/google/common/cache/b0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/k;->b()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Lcom/google/common/cache/b0;->add(J)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method
