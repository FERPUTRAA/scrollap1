.class public abstract enum Lcom/google/common/cache/g0;
.super Ljava/lang/Enum;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/cache/g0;",
        ">;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/cache/g0;

.field public static final enum b:Lcom/google/common/cache/g0;

.field public static final enum c:Lcom/google/common/cache/g0;

.field public static final enum d:Lcom/google/common/cache/g0;

.field public static final enum e:Lcom/google/common/cache/g0;

.field private static final synthetic f:[Lcom/google/common/cache/g0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Lcom/google/common/cache/g0$a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v1, "XIsPILCE"

    const/4 v4, 0x3

    const-string v1, "ITsLICXP"

    const-string v1, "EXPLICIT"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g0$a;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    sput-object v0, Lcom/google/common/cache/g0;->a:Lcom/google/common/cache/g0;

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lcom/google/common/cache/g0$b;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const-string v1, "LEDmACEP"

    const-string v1, "ALPmCEED"

    const/4 v4, 0x6

    const-string v1, "DCAEoLER"

    const-string v1, "REPLACED"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g0$b;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    sput-object v0, Lcom/google/common/cache/g0;->b:Lcom/google/common/cache/g0;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Lcom/google/common/cache/g0$c;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v1, "TDoELbOCL"

    const-string v1, "TLLCoCEDO"

    const/4 v4, 0x0

    const-string v1, "COLDELuET"

    const-string v1, "COLLECTED"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g0$c;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    sput-object v0, Lcom/google/common/cache/g0;->c:Lcom/google/common/cache/g0;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Lcom/google/common/cache/g0$d;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "pRPXbDE"

    const-string v1, "EDRPXbE"

    const/4 v4, 0x5

    const-string v1, "DqEXPIE"

    const-string v1, "EXPIRED"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g0$d;-><init>(Ljava/lang/String;I)V

    const/4 v3, 0x2

    move v4, v3

    sput-object v0, Lcom/google/common/cache/g0;->d:Lcom/google/common/cache/g0;

    const/4 v4, 0x4

    new-instance v0, Lcom/google/common/cache/g0$e;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "ZSEI"

    const-string v1, "IZSE"

    const/4 v4, 0x6

    const-string v1, "SIZE"

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    const/4 v2, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g0$e;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/cache/g0;->e:Lcom/google/common/cache/g0;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/common/cache/g0;->a()[Lcom/google/common/cache/g0;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    sput-object v0, Lcom/google/common/cache/g0;->f:[Lcom/google/common/cache/g0;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;ILcom/google/common/cache/g0$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/common/cache/g0;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/cache/g0;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " oso~~~@t~ @ -io~@S@@~@  ~/@d@o@@oy.bf ~~ oK @ @Mtlf@ain~u1bb~~ ~ c@~l~/@~ ~ ~is~4 r@~@v@@~@~ m "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-array v0, v0, [Lcom/google/common/cache/g0;

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    shr-int/2addr v3, v1

    sget-object v2, Lcom/google/common/cache/g0;->a:Lcom/google/common/cache/g0;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v1, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    sget-object v2, Lcom/google/common/cache/g0;->b:Lcom/google/common/cache/g0;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Lcom/google/common/cache/g0;->c:Lcom/google/common/cache/g0;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v2, Lcom/google/common/cache/g0;->d:Lcom/google/common/cache/g0;

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v2, Lcom/google/common/cache/g0;->e:Lcom/google/common/cache/g0;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/cache/g0;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-class v0, Lcom/google/common/cache/g0;

    const-class v0, Lcom/google/common/cache/g0;

    const/4 v2, 0x2

    const-class v0, Lcom/google/common/cache/g0;

    const-class v0, Lcom/google/common/cache/g0;

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/google/common/cache/g0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lcom/google/common/cache/g0;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/google/common/cache/g0;->f:[Lcom/google/common/cache/g0;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/google/common/cache/g0;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast v0, [Lcom/google/common/cache/g0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object v0
.end method


# virtual methods
.method abstract b()Z
.end method
