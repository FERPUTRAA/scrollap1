.class public final Lcom/google/common/cache/h;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/cache/h$l;,
        Lcom/google/common/cache/h$o;,
        Lcom/google/common/cache/h$b;,
        Lcom/google/common/cache/h$d;,
        Lcom/google/common/cache/h$k;,
        Lcom/google/common/cache/h$n;,
        Lcom/google/common/cache/h$g;,
        Lcom/google/common/cache/h$c;,
        Lcom/google/common/cache/h$j;,
        Lcom/google/common/cache/h$i;,
        Lcom/google/common/cache/h$e;,
        Lcom/google/common/cache/h$h;,
        Lcom/google/common/cache/h$f;,
        Lcom/google/common/cache/h$m;
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field private static final o:Lcom/google/common/base/c1;

.field private static final p:Lcom/google/common/base/c1;

.field private static final q:Lcom/google/common/collect/w9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/w9<",
            "Ljava/lang/String;",
            "Lcom/google/common/cache/h$m;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:Ljava/lang/Integer;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field b:Ljava/lang/Long;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field c:Ljava/lang/Long;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field d:Ljava/lang/Integer;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field e:Lcom/google/common/cache/v$u;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field f:Lcom/google/common/cache/v$u;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field g:Ljava/lang/Boolean;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field h:J
    .annotation build Lx4/e;
    .end annotation
.end field

.field i:Ljava/util/concurrent/TimeUnit;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field j:J
    .annotation build Lx4/e;
    .end annotation
.end field

.field k:Ljava/util/concurrent/TimeUnit;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field l:J
    .annotation build Lx4/e;
    .end annotation
.end field

.field m:Ljava/util/concurrent/TimeUnit;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field private final n:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/16 v0, 0x2c

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/google/common/base/c1;->h(C)Lcom/google/common/base/c1;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/common/base/c1;->r()Lcom/google/common/base/c1;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sput-object v0, Lcom/google/common/cache/h;->o:Lcom/google/common/base/c1;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v0, 0x3d

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/google/common/base/c1;->h(C)Lcom/google/common/base/c1;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/common/base/c1;->r()Lcom/google/common/base/c1;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    sput-object v0, Lcom/google/common/cache/h;->p:Lcom/google/common/base/c1;

    const/4 v4, 0x5

    move v5, v4

    invoke-static {}, Lcom/google/common/collect/w9;->b()Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Lcom/google/common/cache/h$e;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1}, Lcom/google/common/cache/h$e;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "yCsapistnaliaic"

    const-string v2, "anscypiiaCltiai"

    const-string/jumbo v2, "nitmpaylitcaaii"

    const-string/jumbo v2, "initialCapacity"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v1, Lcom/google/common/cache/h$i;

    const/4 v5, 0x7

    invoke-direct {v1}, Lcom/google/common/cache/h$i;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string v2, "emumoSixizm"

    const-string/jumbo v2, "maximumSize"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Lcom/google/common/cache/h$j;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v1}, Lcom/google/common/cache/h$j;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v2, "miWagbummhmei"

    const-string/jumbo v2, "hemmWitmgaumi"

    const-string/jumbo v2, "mmmahiuxgetWu"

    const-string/jumbo v2, "maximumWeight"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v1, Lcom/google/common/cache/h$c;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v1}, Lcom/google/common/cache/h$c;-><init>()V

    const/4 v5, 0x3

    const-string v2, "Leoovlcpcrynceen"

    const-string/jumbo v2, "unelocnycLcovree"

    const/4 v5, 0x7

    const-string/jumbo v2, "nrvuccleqynLcree"

    const-string v2, "concurrencyLevel"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    new-instance v1, Lcom/google/common/cache/h$g;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object v2, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Lcom/google/common/cache/h$g;-><init>(Lcom/google/common/cache/v$u;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v3, "yesweKab"

    const-string v3, "eKyawbek"

    const/4 v5, 0x0

    const-string v3, "Kwameeys"

    const-string/jumbo v3, "weakKeys"

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v3, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Lcom/google/common/cache/h$n;

    const/4 v5, 0x0

    sget-object v3, Lcom/google/common/cache/v$u;->b:Lcom/google/common/cache/v$u;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1, v3}, Lcom/google/common/cache/h$n;-><init>(Lcom/google/common/cache/v$u;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v3, "suasouoVlf"

    const-string v3, "eVlfasusuo"

    const/4 v5, 0x7

    const-string/jumbo v3, "euotfbaVls"

    const-string/jumbo v3, "softValues"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Lcom/google/common/cache/h$n;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Lcom/google/common/cache/h$n;-><init>(Lcom/google/common/cache/v$u;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v2, "weakValues"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Lcom/google/common/cache/h$k;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v1}, Lcom/google/common/cache/h$k;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v2, "satrcpuSoed"

    const-string/jumbo v2, "tcdseatpSro"

    const/4 v5, 0x0

    const-string/jumbo v2, "rtodcatpSre"

    const-string/jumbo v2, "recordStats"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Lcom/google/common/cache/h$b;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v1}, Lcom/google/common/cache/h$b;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v2, "exescAftqrAiersqc"

    const-string/jumbo v2, "rAsciexcqterpfAse"

    const/4 v5, 0x7

    const-string/jumbo v2, "xisfeApecAeesstrc"

    const-string/jumbo v2, "expireAfterAccess"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    new-instance v1, Lcom/google/common/cache/h$o;

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v1}, Lcom/google/common/cache/h$o;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v2, "pAimseeieefxrtWr"

    const-string/jumbo v2, "xesretipWAetefri"

    const/4 v5, 0x5

    const-string v2, "eieropWrtAfetxei"

    const-string/jumbo v2, "expireAfterWrite"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Lcom/google/common/cache/h$l;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1}, Lcom/google/common/cache/h$l;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v2, "tiAfrbeWmteerfsre"

    const-string/jumbo v2, "rrimfsrerWeetftAe"

    const-string v2, "eAerrWufihrtsreet"

    const-string/jumbo v2, "refreshAfterWrite"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Lcom/google/common/cache/h$l;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v1}, Lcom/google/common/cache/h$l;-><init>()V

    const/4 v5, 0x3

    const-string/jumbo v2, "teslaerpvefnhIr"

    const-string/jumbo v2, "fetroreveIhlsan"

    const/4 v5, 0x0

    const-string v2, "eeslranfqvehItr"

    const-string/jumbo v2, "refreshInterval"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v1}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/w9$b;->e()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    sput-object v0, Lcom/google/common/cache/h;->q:Lcom/google/common/collect/w9;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "specification"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/cache/h;->n:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " os@so~Ki o.l~lSo~  ~~md  @a@@~~r i@@o-~ @~f  ~~~ /o~n@ /y@b ~~i@@~@~@M~1c@@t@b@t~@@b~4f~@ ~  v "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/google/common/cache/h;->d(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public static b()Lcom/google/common/cache/h;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "iSimammebu=m0"

    const-string/jumbo v0, "mizSub=ia0mem"

    const/4 v2, 0x4

    const-string/jumbo v0, "iezSomuax=mm0"

    const-string/jumbo v0, "maximumSize=0"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/common/cache/h;->e(Ljava/lang/String;)Lcom/google/common/cache/h;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-object v0
.end method

.method private static c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;
    .locals 2
    .param p2    # Ljava/util/concurrent/TimeUnit;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "duration",
            "unit"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-nez p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p0, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p2, p0, p1}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method private static varargs d(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "format",
            "args"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public static e(Ljava/lang/String;)Lcom/google/common/cache/h;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "cacheBuilderSpecification"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v0, Lcom/google/common/cache/h;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/cache/h;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-nez v1, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object v1, Lcom/google/common/cache/h;->o:Lcom/google/common/base/c1;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, p0}, Lcom/google/common/base/c1;->n(Ljava/lang/CharSequence;)Ljava/lang/Iterable;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v1, :cond_3

    const/4 v7, 0x4

    shl-int/2addr v8, v7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    sget-object v2, Lcom/google/common/cache/h;->p:Lcom/google/common/base/c1;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v2, v1}, Lcom/google/common/base/c1;->n(Ljava/lang/CharSequence;)Ljava/lang/Iterable;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/google/common/collect/t9;->n(Ljava/lang/Iterable;)Lcom/google/common/collect/t9;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    xor-int/2addr v3, v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v5, "klkb-baliu peauyr ev"

    const-string/jumbo v5, "lu abkuvela kyri-epa"

    const/4 v8, 0x4

    const-string/jumbo v5, "pnr lkua e-uyaavkble"

    const-string v5, "blank key-value pair"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v3, v5}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v5, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-gt v3, v5, :cond_0

    const/4 v7, 0x0

    shr-int/2addr v8, v7

    move v3, v4

    move v3, v4

    const/4 v8, 0x6

    move v3, v4

    move v3, v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    move v3, v6

    move v3, v6

    const/4 v8, 0x4

    move v3, v6

    move v3, v6

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v5, "lp%wae psyu egr  ktt iam raih elnas ophsn-eoeivu"

    const-string v5, " qyale popiah  se agum %enil-kvuohre twra itnsse"

    const/4 v8, 0x5

    const-string v5, " u syeniqghhmwe %n staaoto-ea erralplne ikv  uis"

    const-string/jumbo v5, "key-value pair %s with more than one equals sign"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v3, v5, v1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget-object v3, Lcom/google/common/cache/h;->q:Lcom/google/common/collect/w9;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v3, v1}, Lcom/google/common/collect/w9;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    check-cast v3, Lcom/google/common/cache/h$m;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eqz v3, :cond_1

    const/4 v7, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    move v6, v4

    move v6, v4

    const/4 v8, 0x0

    move v6, v4

    move v6, v4

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v5, "n soe%k nsnyuw"

    const-string/jumbo v5, "unknown key %s"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v6, v5, v1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-ne v5, v4, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_2

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    check-cast v2, Ljava/lang/String;

    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-interface {v3, v0, v1, v2}, Lcom/google/common/cache/h$m;->a(Lcom/google/common/cache/h;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x0

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-ne p0, p1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    return v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    instance-of v1, p1, Lcom/google/common/cache/h;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    return v2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    check-cast p1, Lcom/google/common/cache/h;

    const/4 v7, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v3, p1, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v6, 0x2

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    const/4 v7, 0x5

    const/4 v6, 0x7

    iget-object v3, p1, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_2

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/common/cache/h;->c:Ljava/lang/Long;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v3, p1, Lcom/google/common/cache/h;->c:Ljava/lang/Long;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v3, p1, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v3, p1, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/common/cache/h;->f:Lcom/google/common/cache/v$u;

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, p1, Lcom/google/common/cache/h;->f:Lcom/google/common/cache/v$u;

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v3, p1, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v7, 0x7

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-wide v3, p0, Lcom/google/common/cache/h;->h:J

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/common/cache/h;->i:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-static {v3, v4, v1}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-wide v3, p1, Lcom/google/common/cache/h;->h:J

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v5, p1, Lcom/google/common/cache/h;->i:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v3, v4, v5}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-wide v3, p0, Lcom/google/common/cache/h;->j:J

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/common/cache/h;->k:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x2

    move v7, v6

    invoke-static {v3, v4, v1}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-wide v3, p1, Lcom/google/common/cache/h;->j:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v5, p1, Lcom/google/common/cache/h;->k:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x2

    move v7, v6

    invoke-static {v3, v4, v5}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-wide v3, p0, Lcom/google/common/cache/h;->l:J

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v3, v4, v1}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v3, p1, Lcom/google/common/cache/h;->l:J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object p1, p1, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v3, v4, p1}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v1, p1}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz p1, :cond_2

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    move v0, v2

    move v0, v2

    const/4 v7, 0x5

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    return v0
.end method

.method f()Lcom/google/common/cache/g;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/common/cache/g;->H()Lcom/google/common/cache/g;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/google/common/cache/g;->A(I)Lcom/google/common/cache/g;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/common/cache/g;->F(J)Lcom/google/common/cache/g;

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/cache/h;->c:Ljava/lang/Long;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/common/cache/g;->G(J)Lcom/google/common/cache/g;

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/google/common/cache/g;->f(I)Lcom/google/common/cache/g;

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v3, Lcom/google/common/cache/h$a;->a:[I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget v1, v3, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne v1, v2, :cond_4

    invoke-virtual {v0}, Lcom/google/common/cache/g;->S()Lcom/google/common/cache/g;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw v0

    :cond_5
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/common/cache/h;->f:Lcom/google/common/cache/v$u;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_8

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v3, Lcom/google/common/cache/h$a;->a:[I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    aget v1, v3, v1

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-ne v1, v2, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/google/common/cache/g;->O()Lcom/google/common/cache/g;

    const/4 v4, 0x1

    and-int/2addr v5, v4

    goto :goto_1

    :cond_6
    const/4 v5, 0x6

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw v0

    :cond_7
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/common/cache/g;->T()Lcom/google/common/cache/g;

    :cond_8
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/common/cache/g;->I()Lcom/google/common/cache/g;

    :cond_9
    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/common/cache/h;->i:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/h;->h:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v3, v1}, Lcom/google/common/cache/g;->i(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    :cond_a
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/common/cache/h;->k:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_b

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/common/cache/h;->j:J

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v3, v1}, Lcom/google/common/cache/g;->g(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    :cond_b
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_c

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/google/common/cache/h;->l:J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v3, v1}, Lcom/google/common/cache/g;->J(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    :cond_c
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/h;->n:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public hashCode()I
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/16 v0, 0xa

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    aput-object v2, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/common/cache/h;->b:Ljava/lang/Long;

    aput-object v2, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/common/cache/h;->c:Ljava/lang/Long;

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput-object v2, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/common/cache/h;->d:Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    aput-object v2, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    aput-object v2, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/common/cache/h;->f:Lcom/google/common/cache/v$u;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    aput-object v2, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x6

    or-int/2addr v5, v1

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    iget-object v2, p0, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    aput-object v2, v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/google/common/cache/h;->h:J

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/google/common/cache/h;->i:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1, v2, v3}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v2, 0x7

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    aput-object v1, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-wide v1, p0, Lcom/google/common/cache/h;->j:J

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/common/cache/h;->k:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v1, v2, v3}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v2, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    iget-wide v1, p0, Lcom/google/common/cache/h;->l:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1, v2, v3}, Lcom/google/common/cache/h;->c(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/16 v2, 0x9

    const/4 v5, 0x5

    aput-object v1, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/google/common/base/y;->c(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/cache/h;->g()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/common/base/y$b;->s(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/common/base/y$b;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method
