.class Lcom/google/common/cache/h$l;
.super Lcom/google/common/cache/h$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "l"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/common/cache/h$d;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method protected b(Lcom/google/common/cache/h;JLjava/util/concurrent/TimeUnit;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "duration",
            "unit"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bs~~@~4- @b@l m~~@o~@1o @@~r@ i@@/o~@@~  d o@uyif~~~t@/@~Mno~ ~s @ a@o@@ c@ ~t .ibSK  fl~  ~~v~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p1, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const-string/jumbo v1, "f emlrt areyAtahisterserdseef"

    const-string/jumbo v1, "fasht tdyatserelrrrefAsi eree"

    const/4 v3, 0x3

    const-string v1, "eeerotirhrafldtf  tssrayWeere"

    const-string/jumbo v1, "refreshAfterWrite already set"

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-wide p2, p1, Lcom/google/common/cache/h;->l:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object p4, p1, Lcom/google/common/cache/h;->m:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method
