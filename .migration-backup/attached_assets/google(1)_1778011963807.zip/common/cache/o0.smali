.class interface abstract synthetic Lcom/google/common/cache/o0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lv7/j;
.end annotation

.annotation runtime Ly4/b;
.end annotation
