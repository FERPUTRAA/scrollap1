.class public final synthetic Lcom/google/common/cache/i0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/google/common/cache/h0;

.field public final synthetic b:Lcom/google/common/cache/l0;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/cache/i0;->a:Lcom/google/common/cache/h0;

    iput-object p2, p0, Lcom/google/common/cache/i0;->b:Lcom/google/common/cache/l0;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s ot  4 -1fm b@  ~~ ~@@~ldlt~ @@o c ~M/ o y~~~~.i~~o@@vr ~ K~b~iu@~nb@@o@~f~@~~ iS@o~@ @@@a/@s"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/cache/i0;->a:Lcom/google/common/cache/h0;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/cache/i0;->b:Lcom/google/common/cache/l0;

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/cache/k0;->a(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
