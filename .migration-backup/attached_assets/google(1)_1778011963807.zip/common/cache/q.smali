.class public final synthetic Lcom/google/common/cache/q;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/function/BiPredicate;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~o~@4iS~K fb tt o@l /@~  b @ @~@@n@~~v.@@s 1@y@rm d~~a~@@~ociM~bo   @~@ -u/ @@~o~i~~l ~~ fo@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-interface {p0, p1, p2}, Ljava/util/function/BiPredicate;->test(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p0
.end method
