.class final Lcom/google/common/cache/v$i;
.super Lcom/google/common/cache/v$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/cache/v<",
        "TK;TV;>.c<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final synthetic b:Lcom/google/common/cache/v;


# direct methods
.method constructor <init>(Lcom/google/common/cache/v;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/cache/v$c;-><init>(Lcom/google/common/cache/v;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public static synthetic a(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s~~ ai@~ ~r@myiMl1@ b~ @ 4Kf~ ~@/~  ~v@@ @ut~@~~/ @@obl @@@~~c~@ o .@~os d@~f@i-~~oS~~ ~o@tbon"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/google/common/cache/v$i;->b(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method private static synthetic b(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lcom/google/common/collect/uc;->O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/google/common/cache/w;->a(Ljava/util/function/Predicate;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    return p0
.end method


# virtual methods
.method public contains(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    instance-of v0, p1, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2, v0}, Lcom/google/common/cache/v;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, v2, Lcom/google/common/cache/v;->f:Lcom/google/common/base/m;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v2, p1, v0}, Lcom/google/common/base/m;->d(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return v1
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/google/common/cache/v$h;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/common/cache/v$h;-><init>(Lcom/google/common/cache/v;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    instance-of v0, p1, Ljava/util/Map$Entry;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget-object v2, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v2, v0, p1}, Lcom/google/common/cache/v;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method public removeIf(Ljava/util/function/Predicate;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "filter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/Predicate<",
            "-",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;)Z"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/cache/v$i;->b:Lcom/google/common/cache/v;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v1, Lcom/google/common/cache/x;

    const/4 v3, 0x5

    invoke-direct {v1, p1}, Lcom/google/common/cache/x;-><init>(Ljava/util/function/Predicate;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/common/cache/v;->Z(Ljava/util/function/BiPredicate;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p1
.end method
