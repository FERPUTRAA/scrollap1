.class public final synthetic Lcom/google/common/cache/z;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/google/common/cache/v$s;

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:I

.field public final synthetic d:Lcom/google/common/cache/v$n;

.field public final synthetic e:Lcom/google/common/util/concurrent/o2;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/cache/v$s;Ljava/lang/Object;ILcom/google/common/cache/v$n;Lcom/google/common/util/concurrent/o2;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/cache/z;->a:Lcom/google/common/cache/v$s;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/cache/z;->b:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p3, p0, Lcom/google/common/cache/z;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/google/common/cache/z;->d:Lcom/google/common/cache/v$n;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/google/common/cache/z;->e:Lcom/google/common/util/concurrent/o2;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~s@@b @fb /@   ~~~ @dc~~lo.@ lro@~ it @u M~/onb-1i~fo@~ as~o~@@ @@4m@~ yv@~S ~@~@~K@o  ~ ~~i~@~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/common/cache/z;->a:Lcom/google/common/cache/v$s;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/common/cache/z;->b:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v2, p0, Lcom/google/common/cache/z;->c:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/common/cache/z;->d:Lcom/google/common/cache/v$n;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/google/common/cache/z;->e:Lcom/google/common/util/concurrent/o2;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v1, v2, v3, v4}, Lcom/google/common/cache/v$s;->a(Lcom/google/common/cache/v$s;Ljava/lang/Object;ILcom/google/common/cache/v$n;Lcom/google/common/util/concurrent/o2;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    return-void
.end method
