.class final Lcom/google/common/cache/c0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/cache/c0$c;
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final a:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "Lcom/google/common/cache/b0;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/cache/d0;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/cache/d0;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    new-instance v0, Lcom/google/common/cache/c0$a;

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/cache/c0$a;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/cache/c0$b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/cache/c0$b;-><init>()V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lcom/google/common/cache/c0;->a:Lcom/google/common/base/h1;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a()Lcom/google/common/cache/b0;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ibso@~btd@~u~ ~@  ~@@of4~@~~@l~-fi@ ~ ~1~/~o@~i  @o@K @S~@Mt/c @~m@  @ na~.o@   o@s ~~lv~r@~@b ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/cache/c0;->a:Lcom/google/common/base/h1;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Lcom/google/common/cache/b0;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
