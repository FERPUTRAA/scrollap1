.class Lcom/google/common/cache/c0$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/c0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lcom/google/common/base/h1<",
        "Lcom/google/common/cache/b0;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Lcom/google/common/cache/b0;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bst  @  4@nr~oo@@  @do /@i ~ ~@vm~@M~ ~~ o~fo@1l@l ~/ ~ ~~bc@i~@-.i ~~~sf@@K@@~a~S ~~@o@@tyb@u "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/cache/c0$c;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/common/cache/c0$c;-><init>(Lcom/google/common/cache/c0$a;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/cache/c0$b;->a()Lcom/google/common/cache/b0;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-object v0
.end method
