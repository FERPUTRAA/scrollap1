.class abstract Lcom/google/common/cache/v$j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x400
    name = "j"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation


# instance fields
.field a:I

.field b:I

.field c:Lcom/google/common/cache/v$s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field d:Ljava/util/concurrent/atomic/AtomicReferenceArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReferenceArray<",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field e:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field f:Lcom/google/common/cache/v$m0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/v<",
            "TK;TV;>.m0;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field g:Lcom/google/common/cache/v$m0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/v<",
            "TK;TV;>.m0;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field final synthetic h:Lcom/google/common/cache/v;


# direct methods
.method constructor <init>(Lcom/google/common/cache/v;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p1, p1, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    array-length p1, p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput p1, p0, Lcom/google/common/cache/v$j;->a:I

    const/4 v1, 0x7

    const/4 p1, -0x1

    const/4 v1, 0x4

    and-int/2addr v0, p1

    iput p1, p0, Lcom/google/common/cache/v$j;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->a()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method final a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "f so~~f ii~ u  @@@@ o~lKst ~ S~oln@@~~/ ~@~@~@~@/M~b@a bc m@1di@ ~~~@@ ~y~~. v@@bo-ot~ ~@@ 4~r o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/common/cache/v$j;->f:Lcom/google/common/cache/v$m0;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->d()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->e()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/common/cache/v$j;->a:I

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ltz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v4, 0x4

    iget-object v1, v1, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v2, v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/common/cache/v$j;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    aget-object v0, v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/common/cache/v$j;->c:Lcom/google/common/cache/v$s;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v0, v0, Lcom/google/common/cache/v$s;->count:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v$j;->c:Lcom/google/common/cache/v$s;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/google/common/cache/v$s;->table:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/common/cache/v$j;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->length()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/common/cache/v$j;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->e()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    :cond_2
    const/4 v4, 0x0

    return-void
.end method

.method b(Lcom/google/common/cache/f0;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)Z"
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, v0, Lcom/google/common/cache/v;->p:Lcom/google/common/base/l1;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/common/base/l1;->a()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p1}, Lcom/google/common/cache/f0;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget-object v3, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v3, p1, v0, v1}, Lcom/google/common/cache/v;->x(Lcom/google/common/cache/f0;J)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Lcom/google/common/cache/v$m0;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v0, v1, v2, p1}, Lcom/google/common/cache/v$m0;-><init>(Lcom/google/common/cache/v;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/google/common/cache/v$j;->f:Lcom/google/common/cache/v$m0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/common/cache/v$j;->c:Lcom/google/common/cache/v$s;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/v$s;->L()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x7

    or-int/2addr v5, v4

    return p1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/common/cache/v$j;->c:Lcom/google/common/cache/v$s;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/common/cache/v$s;->L()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$j;->c:Lcom/google/common/cache/v$s;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/google/common/cache/v$s;->L()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    throw p1
.end method

.method c()Lcom/google/common/cache/v$m0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/v<",
            "TK;TV;>.m0;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$j;->f:Lcom/google/common/cache/v$m0;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/cache/v$j;->g:Lcom/google/common/cache/v$m0;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->a()V

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v$j;->g:Lcom/google/common/cache/v$m0;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw v0
.end method

.method d()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/cache/v$j;->e:Lcom/google/common/cache/f0;

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-eqz v0, :cond_1

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/google/common/cache/f0;->c()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/common/cache/v$j;->e:Lcom/google/common/cache/f0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v$j;->e:Lcom/google/common/cache/f0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v$j;->b(Lcom/google/common/cache/f0;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/cache/v$j;->e:Lcom/google/common/cache/f0;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method e()Z
    .locals 5

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/common/cache/v$j;->b:I

    const/4 v3, 0x4

    const/4 v3, 0x1

    if-ltz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/common/cache/v$j;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x2

    const/4 v3, 0x7

    add-int/lit8 v2, v0, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v2, p0, Lcom/google/common/cache/v$j;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast v0, Lcom/google/common/cache/f0;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/google/common/cache/v$j;->e:Lcom/google/common/cache/f0;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v$j;->b(Lcom/google/common/cache/f0;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v$j;->d()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v0
.end method

.method public hasNext()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$j;->f:Lcom/google/common/cache/v$m0;

    const/4 v1, 0x2

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    move v2, v1

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    return v0
.end method

.method public abstract next()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v$j;->g:Lcom/google/common/cache/v$m0;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v0, 0x1

    move v2, v0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/cache/v$j;->h:Lcom/google/common/cache/v;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/common/cache/v$j;->g:Lcom/google/common/cache/v$m0;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1}, Lcom/google/common/cache/v$m0;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/common/cache/v;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/common/cache/v$j;->g:Lcom/google/common/cache/v$m0;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method
