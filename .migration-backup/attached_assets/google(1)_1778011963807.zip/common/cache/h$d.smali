.class abstract Lcom/google/common/cache/h$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/h$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "d"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/h;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8
    .param p3    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "key",
            "value"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " ost~@t n~ i@d@  b@  @o@f/r~~c @l~@@ s@ ~@ ~  ~@Ko~~i~~~~i-@ol~1v@o@ b~u.@ o~@m~4f~y ~@~S/~@aM @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    invoke-static {p3}, Lcom/google/common/base/g1;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v0, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v0, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v2, 0x1

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    sub-int/2addr v3, v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p3, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/16 v4, 0x64

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eq v3, v4, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/16 v4, 0x68

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eq v3, v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v4, 0x6d

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eq v3, v4, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/16 v4, 0x73

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ne v3, v4, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object v3, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v3, "wftmhds   o[nw nse h%:euiy %  asitil vo kssimau]ne,tsmdn"

    const-string v3, " ns mi s[%d sey,]ueninns   ftwthto %slds eawovu iimh: ak"

    const/4 v7, 0x5

    const-string v3, " s  ountdkin y:i  tif  hmd%ee,wdoamnl hsw eu %vao]nssits"

    const-string/jumbo v3, "key %s invalid unit: was %s, must end with one of [dhms]"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-array v4, v0, [Ljava/lang/Object;

    const/4 v7, 0x1

    aput-object p2, v4, v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    aput-object p3, v4, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v3, v4}, Lcom/google/common/cache/h;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {p1, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    throw p1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->HOURS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v3, Ljava/util/concurrent/TimeUnit;->DAYS:Ljava/util/concurrent/TimeUnit;

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    sub-int/2addr v4, v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p3, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0, p1, v4, v5, v3}, Lcom/google/common/cache/h$d;->b(Lcom/google/common/cache/h;JLjava/util/concurrent/TimeUnit;)V
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    return-void

    :catch_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    aput-object p2, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-object p3, v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo p2, "y koebttmiev,mee  eb %tnasu   esstrl ug"

    const-string/jumbo p2, "noemm  %esretli%savu bgsuetety , ekt   "

    const/4 v7, 0x4

    const-string/jumbo p2, "ial ,euuvymbttgs e ste%e runke s %s te "

    const-string/jumbo p2, "key %s value set to %s, must be integer"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p2, v0}, Lcom/google/common/cache/h;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    throw p1

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string v0, " uofle pvoeya"

    const-string/jumbo v0, "fukeov laeoy "

    const/4 v7, 0x5

    const-string/jumbo v0, "v y efkuqal o"

    const-string/jumbo v0, "value of key "

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const-string/jumbo p2, "mes doit"

    const-string p2, "eoitdbm "

    const/4 v7, 0x0

    const-string p2, " omitted"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    throw p1
.end method

.method protected abstract b(Lcom/google/common/cache/h;JLjava/util/concurrent/TimeUnit;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "duration",
            "unit"
        }
    .end annotation
.end method
