.class final Lcom/google/common/cache/d0;
.super Lcom/google/common/cache/m0;

# interfaces
.implements Ljava/io/Serializable;
.implements Lcom/google/common/cache/b0;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x6499de12a37d0a3dL


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/cache/m0;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "s"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/common/cache/m0;->busy:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readLong()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "s"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Ljava/io/ObjectOutputStream;->writeLong(J)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/google/common/cache/d0;->add(J)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public add(J)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "x"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    const/4 v7, 0x0

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    iget-wide v1, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-long v3, v1, p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v1, v2, v3, v4}, Lcom/google/common/cache/m0;->d(JJ)Z

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez v1, :cond_2

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object v1, Lcom/google/common/cache/m0;->b:Ljava/lang/ThreadLocal;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast v1, [I

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    array-length v3, v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-lt v3, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    sub-int/2addr v3, v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    aget v4, v1, v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    and-int/2addr v3, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-object v0, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-wide v2, v0, Lcom/google/common/cache/m0$b;->value:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    add-long v4, v2, p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v2, v3, v4, v5}, Lcom/google/common/cache/m0$b;->a(JJ)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    if-nez v2, :cond_2

    :cond_1
    const/4 v7, 0x1

    invoke-virtual {p0, p1, p2, v1, v2}, Lcom/google/common/cache/m0;->i(J[IZ)V

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void
.end method

.method public b()J
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-wide v0, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v8, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v2, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    array-length v3, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-ge v4, v3, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    aget-object v5, v2, v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v5, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-wide v5, v5, Lcom/google/common/cache/m0$b;->value:J

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    add-long/2addr v0, v5

    :cond_0
    const/4 v8, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    return-wide v0
.end method

.method public doubleValue()D
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    long-to-double v0, v0

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    return-wide v0
.end method

.method final f(JJ)J
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "v",
            "x"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    add-long/2addr p1, p3

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-wide p1
.end method

.method public floatValue()F
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    long-to-float v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method public intValue()I
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    long-to-int v0, v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0
.end method

.method public j()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/google/common/cache/d0;->add(J)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public k()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/google/common/cache/m0;->h(J)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public l()J
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-wide v0, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/google/common/cache/m0;->a:[Lcom/google/common/cache/m0$b;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    iput-wide v3, p0, Lcom/google/common/cache/m0;->base:J

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz v2, :cond_1

    const/4 v10, 0x4

    const/4 v10, 0x5

    array-length v5, v2

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/4 v6, 0x0

    :goto_0
    const/4 v10, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-ge v6, v5, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    aget-object v7, v2, v6

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v7, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-wide v8, v7, Lcom/google/common/cache/m0$b;->value:J

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    add-long/2addr v0, v8

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iput-wide v3, v7, Lcom/google/common/cache/m0$b;->value:J

    :cond_0
    const/4 v10, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    return-wide v0
.end method

.method public longValue()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-wide v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/d0;->b()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method
