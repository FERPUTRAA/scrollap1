.class Lcom/google/common/cache/v;
.super Ljava/util/AbstractMap;

# interfaces
.implements Ljava/util/concurrent/ConcurrentMap;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/cache/v$o;,
        Lcom/google/common/cache/v$p;,
        Lcom/google/common/cache/v$m;,
        Lcom/google/common/cache/v$q;,
        Lcom/google/common/cache/v$i;,
        Lcom/google/common/cache/v$c0;,
        Lcom/google/common/cache/v$l;,
        Lcom/google/common/cache/v$c;,
        Lcom/google/common/cache/v$h;,
        Lcom/google/common/cache/v$m0;,
        Lcom/google/common/cache/v$a0;,
        Lcom/google/common/cache/v$k;,
        Lcom/google/common/cache/v$j;,
        Lcom/google/common/cache/v$e;,
        Lcom/google/common/cache/v$l0;,
        Lcom/google/common/cache/v$f;,
        Lcom/google/common/cache/v$n;,
        Lcom/google/common/cache/v$s;,
        Lcom/google/common/cache/v$j0;,
        Lcom/google/common/cache/v$i0;,
        Lcom/google/common/cache/v$k0;,
        Lcom/google/common/cache/v$y;,
        Lcom/google/common/cache/v$t;,
        Lcom/google/common/cache/v$g0;,
        Lcom/google/common/cache/v$e0;,
        Lcom/google/common/cache/v$h0;,
        Lcom/google/common/cache/v$d0;,
        Lcom/google/common/cache/v$f0;,
        Lcom/google/common/cache/v$w;,
        Lcom/google/common/cache/v$z;,
        Lcom/google/common/cache/v$v;,
        Lcom/google/common/cache/v$x;,
        Lcom/google/common/cache/v$d;,
        Lcom/google/common/cache/v$r;,
        Lcom/google/common/cache/v$b0;,
        Lcom/google/common/cache/v$g;,
        Lcom/google/common/cache/v$u;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/AbstractMap<",
        "TK;TV;>;",
        "Ljava/util/concurrent/ConcurrentMap<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field static final A:I = 0x10

.field static final B:Ljava/util/logging/Logger;

.field static final C:Lcom/google/common/cache/v$b0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/v$b0<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field static final D:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue<",
            "*>;"
        }
    .end annotation
.end field

.field static final w:I = 0x40000000

.field static final x:I = 0x10000

.field static final y:I = 0x3

.field static final z:I = 0x3f


# instance fields
.field final a:I

.field final b:I

.field final c:[Lcom/google/common/cache/v$s;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field final d:I

.field final e:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final f:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final g:Lcom/google/common/cache/v$u;

.field final h:Lcom/google/common/cache/v$u;

.field final i:J

.field final j:Lcom/google/common/cache/n0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/n0<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field final k:J

.field final l:J

.field final m:J

.field final n:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue<",
            "Lcom/google/common/cache/l0<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field final o:Lcom/google/common/cache/h0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/h0<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field final p:Lcom/google/common/base/l1;

.field final q:Lcom/google/common/cache/v$g;

.field final r:Lcom/google/common/cache/a$b;

.field final s:Lcom/google/common/cache/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/j<",
            "-TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field t:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    .annotation build Lf6/i;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field u:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Collection<",
            "TV;>;"
        }
    .end annotation

    .annotation build Lf6/i;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field v:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    .annotation build Lf6/i;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/cache/v;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/google/common/cache/v;->B:Ljava/util/logging/Logger;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/cache/v$a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/common/cache/v$a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/cache/v;->C:Lcom/google/common/cache/v$b0;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/cache/v$b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/cache/v$b;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lcom/google/common/cache/v;->D:Ljava/util/Queue;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(Lcom/google/common/cache/g;Lcom/google/common/cache/j;)V
    .locals 13
    .param p2    # Lcom/google/common/cache/j;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "builder",
            "loader"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/g<",
            "-TK;-TV;>;",
            "Lcom/google/common/cache/j<",
            "-TK;TV;>;)V"
        }
    .end annotation

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-direct {p0}, Ljava/util/AbstractMap;-><init>()V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {p1}, Lcom/google/common/cache/g;->m()I

    move-result v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    const/high16 v1, 0x10000

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    iput v0, p0, Lcom/google/common/cache/v;->d:I

    invoke-virtual {p1}, Lcom/google/common/cache/g;->r()Lcom/google/common/cache/v$u;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    iput-object v0, p0, Lcom/google/common/cache/v;->g:Lcom/google/common/cache/v$u;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/g;->y()Lcom/google/common/cache/v$u;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    iput-object v1, p0, Lcom/google/common/cache/v;->h:Lcom/google/common/cache/v$u;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/common/cache/g;->q()Lcom/google/common/base/m;

    move-result-object v1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    iput-object v1, p0, Lcom/google/common/cache/v;->e:Lcom/google/common/base/m;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/common/cache/g;->x()Lcom/google/common/base/m;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    iput-object v1, p0, Lcom/google/common/cache/v;->f:Lcom/google/common/base/m;

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/common/cache/g;->s()J

    move-result-wide v1

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    iput-wide v1, p0, Lcom/google/common/cache/v;->i:J

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {p1}, Lcom/google/common/cache/g;->z()Lcom/google/common/cache/n0;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    iput-object v3, p0, Lcom/google/common/cache/v;->j:Lcom/google/common/cache/n0;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/common/cache/g;->n()J

    move-result-wide v3

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    iput-wide v3, p0, Lcom/google/common/cache/v;->k:J

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {p1}, Lcom/google/common/cache/g;->o()J

    move-result-wide v3

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    iput-wide v3, p0, Lcom/google/common/cache/v;->l:J

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/g;->t()J

    move-result-wide v3

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    iput-wide v3, p0, Lcom/google/common/cache/v;->m:J

    const/4 v12, 0x4

    invoke-virtual {p1}, Lcom/google/common/cache/g;->u()Lcom/google/common/cache/h0;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    iput-object v3, p0, Lcom/google/common/cache/v;->o:Lcom/google/common/cache/h0;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    sget-object v4, Lcom/google/common/cache/g$c;->a:Lcom/google/common/cache/g$c;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x3

    if-ne v3, v4, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {}, Lcom/google/common/cache/v;->n()Ljava/util/Queue;

    move-result-object v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    goto :goto_0

    :cond_0
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance v3, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v11, 0x2

    move v12, v11

    invoke-direct {v3}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    :goto_0
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    iput-object v3, p0, Lcom/google/common/cache/v;->n:Ljava/util/Queue;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->T()Z

    move-result v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {p1, v3}, Lcom/google/common/cache/g;->w(Z)Lcom/google/common/base/l1;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    iput-object v3, p0, Lcom/google/common/cache/v;->p:Lcom/google/common/base/l1;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v;->d0()Z

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v;->i0()Z

    move-result v4

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {v0, v3, v4}, Lcom/google/common/cache/v$g;->e(Lcom/google/common/cache/v$u;ZZ)Lcom/google/common/cache/v$g;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    iput-object v0, p0, Lcom/google/common/cache/v;->q:Lcom/google/common/cache/v$g;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {p1}, Lcom/google/common/cache/g;->v()Lcom/google/common/base/h1;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-interface {v0}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    check-cast v0, Lcom/google/common/cache/a$b;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    iput-object v0, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    iput-object p2, p0, Lcom/google/common/cache/v;->s:Lcom/google/common/cache/j;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/common/cache/g;->p()I

    move-result p2

    const/4 v12, 0x3

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v;->o()Z

    move-result v0

    const/4 v12, 0x1

    const/4 v11, 0x3

    if-eqz v0, :cond_1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->k()Z

    move-result v0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-nez v0, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-long v3, p2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v12, 0x7

    long-to-int p2, v0

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v0, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/4 v1, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    move v3, v0

    move v3, v0

    const/4 v12, 0x5

    move v3, v0

    move v3, v0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    move v2, v1

    move v2, v1

    const/4 v12, 0x2

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    iget v4, p0, Lcom/google/common/cache/v;->d:I

    const/4 v12, 0x7

    const/4 v11, 0x1

    if-ge v2, v4, :cond_3

    const/4 v11, 0x0

    shl-int/2addr v12, v11

    invoke-virtual {p0}, Lcom/google/common/cache/v;->o()Z

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-eqz v4, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    mul-int/lit8 v4, v2, 0x14

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    int-to-long v4, v4

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-wide v6, p0, Lcom/google/common/cache/v;->i:J

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    cmp-long v4, v4, v6

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-gtz v4, :cond_3

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    shl-int/lit8 v2, v2, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x6

    goto :goto_1

    :cond_3
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    rsub-int/lit8 v3, v3, 0x20

    iput v3, p0, Lcom/google/common/cache/v;->b:I

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    add-int/lit8 v3, v2, -0x1

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    iput v3, p0, Lcom/google/common/cache/v;->a:I

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {p0, v2}, Lcom/google/common/cache/v;->J(I)[Lcom/google/common/cache/v$s;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    iput-object v3, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v12, 0x7

    div-int v3, p2, v2

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    mul-int v4, v3, v2

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-ge v4, p2, :cond_4

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    add-int/lit8 v3, v3, 0x1

    :cond_4
    :goto_2
    const/4 v11, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    if-ge v1, v3, :cond_5

    const/4 v12, 0x1

    const/4 v11, 0x3

    shl-int/lit8 v1, v1, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    goto :goto_2

    :cond_5
    const/4 v12, 0x6

    invoke-virtual {p0}, Lcom/google/common/cache/v;->o()Z

    move-result p2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eqz p2, :cond_7

    const/4 v11, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-wide v3, p0, Lcom/google/common/cache/v;->i:J

    const/4 v12, 0x7

    const/4 v11, 0x0

    int-to-long v5, v2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    div-long v7, v3, v5

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v12, 0x5

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    add-long/2addr v7, v9

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    rem-long/2addr v3, v5

    :goto_3
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object p2, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    array-length v2, p2

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-ge v0, v2, :cond_8

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    int-to-long v5, v0

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    cmp-long v2, v5, v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-nez v2, :cond_6

    const/4 v11, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    sub-long/2addr v7, v9

    :cond_6
    const/4 v12, 0x7

    invoke-virtual {p1}, Lcom/google/common/cache/g;->v()Lcom/google/common/base/h1;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v2}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    check-cast v2, Lcom/google/common/cache/a$b;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {p0, v1, v7, v8, v2}, Lcom/google/common/cache/v;->i(IJLcom/google/common/cache/a$b;)Lcom/google/common/cache/v$s;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    aput-object v2, p2, v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    goto :goto_3

    :cond_7
    :goto_4
    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object p2, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    array-length v2, p2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    if-ge v0, v2, :cond_8

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {p1}, Lcom/google/common/cache/g;->v()Lcom/google/common/base/h1;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-interface {v2}, Lcom/google/common/base/h1;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x4

    check-cast v2, Lcom/google/common/cache/a$b;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p0, v1, v3, v4, v2}, Lcom/google/common/cache/v;->i(IJLcom/google/common/cache/a$b;)Lcom/google/common/cache/v$s;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    aput-object v2, p2, v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    goto :goto_4

    :cond_8
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    return-void
.end method

.method private static synthetic D(Ljava/util/function/Function;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    if-nez p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/google/common/cache/p;->a(Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p3
.end method

.method private static synthetic E(Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    if-nez p2, :cond_0

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/google/common/cache/r;->a(Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method private static synthetic F(Ljava/lang/Object;Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p3, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x5

    const/4 v0, 0x4

    invoke-static {p1, p3, p0}, Lcom/google/common/cache/r;->a(Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method static L()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    sget-object v0, Lcom/google/common/cache/v$r;->a:Lcom/google/common/cache/v$r;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method static M(Lcom/google/common/cache/f0;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nulled"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-interface {p0, v0}, Lcom/google/common/cache/f0;->p(Lcom/google/common/cache/f0;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {p0, v0}, Lcom/google/common/cache/f0;->g(Lcom/google/common/cache/f0;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method static N(Lcom/google/common/cache/f0;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nulled"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p0, v0}, Lcom/google/common/cache/f0;->q(Lcom/google/common/cache/f0;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {p0, v0}, Lcom/google/common/cache/f0;->s(Lcom/google/common/cache/f0;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method static Y(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "h"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    shl-int/lit8 v0, p0, 0xf

    const/4 v3, 0x4

    xor-int/lit16 v0, v0, -0x3283

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/2addr p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    ushr-int/lit8 v0, p0, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x7

    xor-int/2addr p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    shl-int/lit8 v0, p0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/2addr p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    ushr-int/lit8 v0, p0, 0x6

    const/4 v3, 0x5

    const/4 v2, 0x2

    xor-int/2addr p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    shl-int/lit8 v0, p0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    shl-int/lit8 v1, p0, 0xe

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/2addr p0, v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    ushr-int/lit8 v0, p0, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    xor-int/2addr p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p0
.end method

.method public static synthetic a(Ljava/lang/Object;Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Lcom/google/common/cache/v;->F(Ljava/lang/Object;Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public static synthetic b(Ljava/util/function/Function;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    invoke-static {p0, p1, p2, p3}, Lcom/google/common/cache/v;->D(Ljava/util/function/Function;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-object p0
.end method

.method private static b0(Ljava/util/Collection;)Ljava/util/ArrayList;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "TE;>;)",
            "Ljava/util/ArrayList<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x2

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, p0}, Lcom/google/common/collect/yb;->a(Ljava/util/Collection;Ljava/util/Iterator;)Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public static synthetic c(Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lcom/google/common/cache/v;->E(Ljava/util/function/BiFunction;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-object p0
.end method

.method static c0()Lcom/google/common/cache/v$b0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/cache/v$b0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/cache/v;->C:Lcom/google/common/cache/v$b0;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic d(Ljava/util/Collection;)Ljava/util/ArrayList;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/common/cache/v;->b0(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method static f(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "previous",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-interface {p0, p1}, Lcom/google/common/cache/f0;->p(Lcom/google/common/cache/f0;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p1, p0}, Lcom/google/common/cache/f0;->g(Lcom/google/common/cache/f0;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-void
.end method

.method static g(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "previous",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/google/common/cache/f0;->q(Lcom/google/common/cache/f0;)V

    const/4 v1, 0x7

    invoke-interface {p1, p0}, Lcom/google/common/cache/f0;->s(Lcom/google/common/cache/f0;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static n()Ljava/util/Queue;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Ljava/util/Queue<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/cache/v;->D:Ljava/util/Queue;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object v0
.end method


# virtual methods
.method A(Ljava/lang/Iterable;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "keys"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method B(Lcom/google/common/cache/f0;J)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "now"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;J)Z"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {p0}, Lcom/google/common/cache/v;->q()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-interface {p1}, Lcom/google/common/cache/f0;->m()J

    move-result-wide v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    sub-long v2, p2, v2

    const/4 v7, 0x1

    iget-wide v4, p0, Lcom/google/common/cache/v;->k:J

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    cmp-long v0, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ltz v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    return v1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/common/cache/v;->r()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {p1}, Lcom/google/common/cache/f0;->j()J

    move-result-wide v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    sub-long/2addr p2, v2

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/v;->l:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    cmp-long p1, p2, v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-ltz p1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    return v1

    :cond_1
    const/4 v7, 0x0

    const/4 p1, 0x0

    const/4 v7, 0x7

    move v6, p1

    move v6, p1

    const/4 v7, 0x0

    return p1
.end method

.method C(Lcom/google/common/cache/f0;J)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "now"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;J)Z"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/google/common/cache/f0;->b()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/common/cache/v$s;->z(Lcom/google/common/cache/f0;J)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method G(Ljava/util/Set;Lcom/google/common/cache/j;)Ljava/util/Map;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "keys",
            "loader"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "+TK;>;",
            "Lcom/google/common/cache/j<",
            "-TK;TV;>;)",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {}, Lcom/google/common/base/f1;->c()Lcom/google/common/base/f1;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x2

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Lcom/google/common/cache/j;->e(Ljava/lang/Iterable;)Ljava/util/Map;

    move-result-object p1
    :try_end_0
    .catch Lcom/google/common/cache/j$e; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz p1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/common/base/f1;->m()Lcom/google/common/base/f1;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v5, :cond_1

    const/4 v6, 0x6

    move v7, v6

    if-nez v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0, v5, v4}, Lcom/google/common/cache/v;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v2, v1

    const/4 v7, 0x6

    move v2, v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v2, :cond_3

    iget-object p2, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/google/common/base/f1;->g(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {p2, v0, v1}, Lcom/google/common/cache/a$b;->e(J)V

    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-object p1

    :cond_3
    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lcom/google/common/base/f1;->g(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {p1, v0, v1}, Lcom/google/common/cache/a$b;->d(J)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p1, Lcom/google/common/cache/j$c;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo p2, "r slyarumeslAdtkol lref aeds l sv eonuln u"

    const-string p2, " es odae Allru lrvotllnyafss nr reekm udlu"

    const/4 v7, 0x5

    const-string/jumbo p2, "rlomrletl rudfoam   u lsylkreualnnosA eed "

    const-string p2, " returned null keys or values from loadAll"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p1, p2}, Lcom/google/common/cache/j$c;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    throw p1

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lcom/google/common/base/f1;->g(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {p1, v0, v1}, Lcom/google/common/cache/a$b;->d(J)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance p1, Lcom/google/common/cache/j$c;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string p2, "durlonud alfl e oalprtmmrAn eml"

    const-string p2, "ae m rd nrdlmpeat urlmonlAul lf"

    const/4 v7, 0x0

    const-string/jumbo p2, "fr nmbd lalun  oltelrelrmadouAp"

    const-string p2, " returned null map from loadAll"

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {p1, p2}, Lcom/google/common/cache/j$c;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    throw p1

    :catchall_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    move v1, v2

    move v1, v2

    const/4 v7, 0x6

    move v1, v2

    move v1, v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance p2, Lcom/google/common/util/concurrent/m1;

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-direct {p2, p1}, Lcom/google/common/util/concurrent/m1;-><init>(Ljava/lang/Error;)V

    const/4 v7, 0x2

    throw p2

    :catch_1
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance p2, Ljava/util/concurrent/ExecutionException;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p2, p1}, Ljava/util/concurrent/ExecutionException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    and-int/2addr v7, v6

    throw p2

    :catch_2
    move-exception p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p2, Lcom/google/common/util/concurrent/f4;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {p2, p1}, Lcom/google/common/util/concurrent/f4;-><init>(Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    throw p2

    :catch_3
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2}, Ljava/lang/Thread;->interrupt()V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance p2, Ljava/util/concurrent/ExecutionException;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p2, p1}, Ljava/util/concurrent/ExecutionException;-><init>(Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_4
    move-exception p1

    :try_start_2
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception p1

    :goto_2
    const/4 v7, 0x6

    if-nez v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object p2, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    sget-object v1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Lcom/google/common/base/f1;->g(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {p2, v0, v1}, Lcom/google/common/cache/a$b;->d(J)V

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    throw p1
.end method

.method H()J
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v8, 0x6

    array-length v1, v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-wide/16 v2, 0x0

    const/4 v8, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x6

    move v7, v4

    move v7, v4

    :goto_0
    const/4 v8, 0x5

    if-ge v4, v1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    aget-object v5, v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget v5, v5, Lcom/google/common/cache/v$s;->count:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    int-to-long v5, v5

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    add-long/2addr v2, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x7

    move v8, v7

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-wide v2
.end method

.method I(Ljava/lang/Object;ILcom/google/common/cache/f0;)Lcom/google/common/cache/f0;
    .locals 3
    .param p3    # Lcom/google/common/cache/f0;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "hash",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;I",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/common/cache/v$s;->I(Ljava/lang/Object;ILcom/google/common/cache/f0;)Lcom/google/common/cache/f0;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw p1
.end method

.method final J(I)[Lcom/google/common/cache/v$s;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ssize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)[",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-array p1, p1, [Lcom/google/common/cache/v$s;

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method K(Lcom/google/common/cache/f0;Ljava/lang/Object;I)Lcom/google/common/cache/v$b0;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "entry",
            "value",
            "weight"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;TV;I)",
            "Lcom/google/common/cache/v$b0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p1}, Lcom/google/common/cache/f0;->b()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/common/cache/v;->h:Lcom/google/common/cache/v$u;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, v0, p1, p2, p3}, Lcom/google/common/cache/v$u;->c(Lcom/google/common/cache/v$s;Lcom/google/common/cache/f0;Ljava/lang/Object;I)Lcom/google/common/cache/v$b0;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method

.method O()V
    .locals 6

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v;->n:Ljava/util/Queue;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Lcom/google/common/cache/l0;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/common/cache/v;->o:Lcom/google/common/cache/h0;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v1, v0}, Lcom/google/common/cache/h0;->a(Lcom/google/common/cache/l0;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v1, Lcom/google/common/cache/v;->B:Ljava/util/logging/Logger;

    const/4 v4, 0x1

    move v5, v4

    sget-object v2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v3, "w shlrumt ro beianoenpltncxreEeotoiv"

    const-string/jumbo v3, "rpltonetxnnve ehal Emoior w tcoibers"

    const/4 v5, 0x6

    const-string/jumbo v3, "rvbeetnpcailEet ox pyte o wsolhnnmir"

    const-string v3, "Exception thrown by removal listener"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void
.end method

.method P(Lcom/google/common/cache/f0;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/google/common/cache/f0;->b()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->P(Lcom/google/common/cache/f0;I)Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method R(Lcom/google/common/cache/v$b0;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "valueReference"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/v$b0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1}, Lcom/google/common/cache/v$b0;->c()Lcom/google/common/cache/f0;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/google/common/cache/f0;->b()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v1}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/common/cache/f0;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2, v0, v1, p1}, Lcom/google/common/cache/v$s;->Q(Ljava/lang/Object;ILcom/google/common/cache/v$b0;)Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method S()Z
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v;->q()Z

    move-result v0

    const/4 v2, 0x0

    return v0
.end method

.method T()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->U()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v;->S()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method U()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v;->r()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v;->W()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method V(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)V"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/common/cache/v;->s:Lcom/google/common/cache/j;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, p1, v0, v2, v3}, Lcom/google/common/cache/v$s;->U(Ljava/lang/Object;ILcom/google/common/cache/j;Z)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-void
.end method

.method W()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/google/common/cache/v;->m:J

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-lez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x2

    return v0
.end method

.method Z(Ljava/util/function/BiPredicate;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "filter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/BiPredicate<",
            "-TK;-TV;>;)Z"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/common/cache/v;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x0

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v2}, Lcom/google/common/cache/v;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1, v2, v3}, Lcom/google/common/cache/q;->a(Ljava/util/function/BiPredicate;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, v2, v3}, Lcom/google/common/cache/v;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v1
.end method

.method a0(I)Lcom/google/common/cache/v$s;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "hash"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/common/cache/v;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    ushr-int/2addr p1, v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/common/cache/v;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    and-int/2addr p1, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    aget-object p1, v0, p1

    const/4 v3, 0x1

    return-object p1
.end method

.method public clear()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    array-length v1, v0

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ge v2, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    aget-object v3, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v3}, Lcom/google/common/cache/v$s;->c()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method

.method public compute(Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Ljava/util/function/BiFunction<",
            "-TK;-TV;+TV;>;)TV;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1, p1, v0, p2}, Lcom/google/common/cache/v$s;->g(Ljava/lang/Object;ILjava/util/function/BiFunction;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1
.end method

.method public computeIfAbsent(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Ljava/util/function/Function<",
            "-TK;+TV;>;)TV;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/cache/s;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p2, p1}, Lcom/google/common/cache/s;-><init>(Ljava/util/function/Function;Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/common/cache/v;->compute(Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    return-object p1
.end method

.method public computeIfPresent(Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Ljava/util/function/BiFunction<",
            "-TK;-TV;+TV;>;)TV;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/cache/t;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0, p2}, Lcom/google/common/cache/t;-><init>(Ljava/util/function/BiFunction;)V

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/common/cache/v;->compute(Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method

.method public containsKey(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->h(Ljava/lang/Object;I)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1
.end method

.method public containsValue(Ljava/lang/Object;)Z
    .locals 19
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    :cond_0
    iget-object v3, v0, Lcom/google/common/cache/v;->p:Lcom/google/common/base/l1;

    invoke-virtual {v3}, Lcom/google/common/base/l1;->a()J

    move-result-wide v3

    iget-object v5, v0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    move v8, v2

    move v8, v2

    move v8, v2

    move v8, v2

    :goto_0
    const/4 v9, 0x3

    if-ge v8, v9, :cond_6

    array-length v9, v5

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    move v12, v2

    move v12, v2

    move v12, v2

    move v12, v2

    :goto_1
    if-ge v12, v9, :cond_4

    aget-object v13, v5, v12

    iget v14, v13, Lcom/google/common/cache/v$s;->count:I

    iget-object v14, v13, Lcom/google/common/cache/v$s;->table:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    move v15, v2

    move v15, v2

    move v15, v2

    move v15, v2

    :goto_2
    invoke-virtual {v14}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->length()I

    move-result v2

    if-ge v15, v2, :cond_3

    invoke-virtual {v14, v15}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/common/cache/f0;

    :goto_3
    if-eqz v2, :cond_2

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    invoke-virtual {v13, v2, v3, v4}, Lcom/google/common/cache/v$s;->z(Lcom/google/common/cache/f0;J)Ljava/lang/Object;

    move-result-object v5

    move-wide/from16 v17, v3

    if-eqz v5, :cond_1

    iget-object v3, v0, Lcom/google/common/cache/v;->f:Lcom/google/common/base/m;

    invoke-virtual {v3, v1, v5}, Lcom/google/common/base/m;->d(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v1, 0x1

    return v1

    :cond_1
    invoke-interface {v2}, Lcom/google/common/cache/f0;->c()Lcom/google/common/cache/f0;

    move-result-object v2

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-wide/from16 v3, v17

    goto :goto_3

    :cond_2
    move-wide/from16 v17, v3

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    add-int/lit8 v15, v15, 0x1

    goto :goto_2

    :cond_3
    move-wide/from16 v17, v3

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    iget v2, v13, Lcom/google/common/cache/v$s;->modCount:I

    int-to-long v2, v2

    add-long/2addr v10, v2

    add-int/lit8 v12, v12, 0x1

    move-wide/from16 v3, v17

    const/4 v2, 0x0

    goto :goto_1

    :cond_4
    move-wide/from16 v17, v3

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    cmp-long v2, v10, v6

    if-nez v2, :cond_5

    const/4 v1, 0x0

    goto :goto_4

    :cond_5
    add-int/lit8 v8, v8, 0x1

    move-wide v6, v10

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-wide/from16 v3, v17

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_6
    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :goto_4
    return v1
.end method

.method d0()Z
    .locals 3

    invoke-virtual {p0}, Lcom/google/common/cache/v;->f0()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v;->S()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public e()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v4, 0x1

    array-length v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x4

    if-ge v2, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    aget-object v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {v3}, Lcom/google/common/cache/v$s;->b()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method public entrySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v;->v:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    new-instance v0, Lcom/google/common/cache/v$i;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$i;-><init>(Lcom/google/common/cache/v;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/common/cache/v;->v:Ljava/util/Set;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method

.method f0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v;->q()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/common/cache/v;->o()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method g0()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/cache/v;->g:Lcom/google/common/cache/v$u;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v1, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->t(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1
.end method

.method public getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "defaultValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p2
.end method

.method h(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "original",
            "newNext"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/google/common/cache/f0;->b()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Lcom/google/common/cache/v$s;->j(Lcom/google/common/cache/f0;Lcom/google/common/cache/f0;)Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method h0()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v;->h:Lcom/google/common/cache/v$u;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v1, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    xor-int/2addr v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method i(IJLcom/google/common/cache/a$b;)Lcom/google/common/cache/v$s;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "initialCapacity",
            "maxSegmentWeight",
            "statsCounter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IJ",
            "Lcom/google/common/cache/a$b;",
            ")",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v6, Lcom/google/common/cache/v$s;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v2, p1

    move v2, p1

    move-wide v3, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v5}, Lcom/google/common/cache/v$s;-><init>(Lcom/google/common/cache/v;IJLcom/google/common/cache/a$b;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object v6
.end method

.method i0()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->j0()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/cache/v;->U()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    return v0
.end method

.method public isEmpty()Z
    .locals 13

    const/4 v11, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v;->c:[Lcom/google/common/cache/v$s;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    array-length v1, v0

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v4, 0x0

    const/4 v4, 0x0

    move-wide v6, v2

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    move v5, v4

    move v5, v4

    const/4 v12, 0x4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v12, 0x3

    const/4 v11, 0x5

    if-ge v5, v1, :cond_1

    const/4 v12, 0x2

    const/4 v11, 0x7

    aget-object v8, v0, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget v9, v8, Lcom/google/common/cache/v$s;->count:I

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    if-eqz v9, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    return v4

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget v8, v8, Lcom/google/common/cache/v$s;->modCount:I

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    int-to-long v8, v8

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    add-long/2addr v6, v8

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    goto :goto_0

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    cmp-long v1, v6, v2

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    const/4 v5, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-eqz v1, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    array-length v1, v0

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    move v8, v4

    move v8, v4

    const/4 v12, 0x6

    move v8, v4

    move v8, v4

    :goto_1
    const/4 v11, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-ge v8, v1, :cond_3

    const/4 v12, 0x7

    const/4 v11, 0x3

    aget-object v9, v0, v8

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    iget v10, v9, Lcom/google/common/cache/v$s;->count:I

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-eqz v10, :cond_2

    const/4 v11, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    return v4

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget v9, v9, Lcom/google/common/cache/v$s;->modCount:I

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    int-to-long v9, v9

    const/4 v12, 0x4

    const/4 v11, 0x7

    sub-long/2addr v6, v9

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    add-int/lit8 v8, v8, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    goto :goto_1

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    cmp-long v0, v6, v2

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-nez v0, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    move v4, v5

    const/4 v12, 0x6

    move v4, v5

    move v4, v5

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    return v4

    :cond_5
    const/4 v11, 0x0

    return v5
.end method

.method j0()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->r()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method k()Z
    .locals 4

    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Lcom/google/common/cache/v;->j:Lcom/google/common/cache/n0;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Lcom/google/common/cache/g$d;->a:Lcom/google/common/cache/g$d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public keySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v;->t:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/cache/v$l;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$l;-><init>(Lcom/google/common/cache/v;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/common/cache/v;->t:Ljava/util/Set;

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public merge(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "newValue",
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;",
            "Ljava/util/function/BiFunction<",
            "-TV;-TV;+TV;>;)TV;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    invoke-static {p3}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/cache/u;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p2, p3}, Lcom/google/common/cache/u;-><init>(Ljava/lang/Object;Ljava/util/function/BiFunction;)V

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/common/cache/v;->compute(Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method o()Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/google/common/cache/v;->i:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-ltz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v0
.end method

.method p()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/common/cache/v;->r()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/v;->q()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, p1, v0, p2, v2}, Lcom/google/common/cache/v$s;->O(Ljava/lang/Object;ILjava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object p1
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "m"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "+TK;+TV;>;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v1, v0}, Lcom/google/common/cache/v;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    return-void
.end method

.method public putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, p1, v0, p2, v2}, Lcom/google/common/cache/v$s;->O(Ljava/lang/Object;ILjava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1
.end method

.method q()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/v;->k:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-lez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    return v0
.end method

.method r()Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/v;->l:J

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-lez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v0
.end method

.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->V(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p1
.end method

.method public remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1, p1, v0, p2}, Lcom/google/common/cache/v$s;->W(Ljava/lang/Object;ILjava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p1

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p1
.end method

.method public replace(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, p1, v0, p2}, Lcom/google/common/cache/v$s;->c0(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p1
.end method

.method public replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "oldValue",
            "newValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;TV;)Z"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p3}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v2, 0x1

    move v3, v2

    const/4 p1, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1, p1, v0, p2, p3}, Lcom/google/common/cache/v$s;->d0(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p1
.end method

.method s(Ljava/lang/Object;Lcom/google/common/cache/j;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "loader"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Lcom/google/common/cache/j<",
            "-TK;TV;>;)TV;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1, p1, v0, p2}, Lcom/google/common/cache/v$s;->u(Ljava/lang/Object;ILcom/google/common/cache/j;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public size()I
    .locals 4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/v;->H()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/primitives/f0;->z(J)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method t(Ljava/lang/Iterable;)Lcom/google/common/collect/w9;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "keys"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+TK;>;)",
            "Lcom/google/common/collect/w9<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {}, Lcom/google/common/collect/uc;->c0()Ljava/util/LinkedHashMap;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {}, Lcom/google/common/collect/uf;->A()Ljava/util/LinkedHashSet;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    const/4 v8, 0x0

    move v3, v2

    move v3, v2

    :cond_0
    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v4, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0, v4}, Lcom/google/common/cache/v;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v0, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-nez v6, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-interface {v0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v5, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {v1, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_2
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-nez p1, :cond_4

    :try_start_1
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v4, p0, Lcom/google/common/cache/v;->s:Lcom/google/common/cache/j;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p0, p1, v4}, Lcom/google/common/cache/v;->G(Ljava/util/Set;Lcom/google/common/cache/j;)Ljava/util/Map;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v5, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v6, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x4

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_1

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance p1, Lcom/google/common/cache/j$c;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v6, "bae  verqrnfeAr ol duitl auod lf oatl"

    const-string v6, "dau  b erudtvnoAlleola  ti roaae fflr"

    const/4 v8, 0x7

    const-string/jumbo v6, "loadAll failed to return a value for "

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p1, v4}, Lcom/google/common/cache/j$c;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    throw p1
    :try_end_1
    .catch Lcom/google/common/cache/j$e; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v1, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    add-int/lit8 v3, v3, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v4, p0, Lcom/google/common/cache/v;->s:Lcom/google/common/cache/j;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, v1, v4}, Lcom/google/common/cache/v;->s(Ljava/lang/Object;Lcom/google/common/cache/j;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {v0, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    goto :goto_2

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/google/common/collect/w9;->g(Ljava/util/Map;)Lcom/google/common/collect/w9;

    move-result-object p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {v0, v2}, Lcom/google/common/cache/a$b;->a(I)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-interface {v0, v3}, Lcom/google/common/cache/a$b;->b(I)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-interface {v0, v2}, Lcom/google/common/cache/a$b;->a(I)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface {v0, v3}, Lcom/google/common/cache/a$b;->b(I)V

    const/4 v8, 0x7

    throw p1
.end method

.method u(Ljava/lang/Iterable;)Lcom/google/common/collect/w9;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "keys"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "*>;)",
            "Lcom/google/common/collect/w9<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/common/collect/w9;->b()Lcom/google/common/collect/w9$b;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0, v3}, Lcom/google/common/cache/v;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-nez v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v3, v4}, Lcom/google/common/collect/w9$b;->j(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9$b;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v5, 0x4

    const/4 v5, 0x0

    invoke-interface {p1, v1}, Lcom/google/common/cache/a$b;->a(I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p1, v2}, Lcom/google/common/cache/a$b;->b(I)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/common/collect/w9$b;->d()Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-object p1
.end method

.method v(Ljava/lang/Object;)Lcom/google/common/cache/f0;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->w(Ljava/lang/Object;I)Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1
.end method

.method public values()Ljava/util/Collection;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v;->u:Ljava/util/Collection;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/cache/v$c0;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$c0;-><init>(Lcom/google/common/cache/v;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/common/cache/v;->u:Ljava/util/Collection;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public w(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->z(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/cache/v;->a0(I)Lcom/google/common/cache/v$s;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1, p1, v0}, Lcom/google/common/cache/v$s;->t(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    shr-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v1, v0}, Lcom/google/common/cache/a$b;->b(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/cache/v;->r:Lcom/google/common/cache/a$b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v1, v0}, Lcom/google/common/cache/a$b;->a(I)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p1
.end method

.method x(Lcom/google/common/cache/f0;J)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "now"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;J)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p1}, Lcom/google/common/cache/f0;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v1

    :cond_0
    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/google/common/cache/f0;->a()Lcom/google/common/cache/v$b0;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/google/common/cache/v$b0;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/common/cache/v;->B(Lcom/google/common/cache/f0;J)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0
.end method

.method y(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TV;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v;->s:Lcom/google/common/cache/j;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/common/cache/v;->s(Ljava/lang/Object;Lcom/google/common/cache/j;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1
.end method

.method z(Ljava/lang/Object;)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v;->e:Lcom/google/common/base/m;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/base/m;->f(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/cache/v;->Y(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method
