.class public final synthetic Lcom/google/common/cache/f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/base/h1;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ast@1f@~o~@@@@~ ~ ~@~lmdK@o/~~@o~ /@ . b4@~~o@io~@ ~c@~b ~@@~~n~@ -byos@ ~ ~M v ri i~   @t@lSf~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/cache/g;->a()Lcom/google/common/cache/a$b;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method
