.class final enum Lcom/google/common/cache/g$d;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/cache/n0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/cache/g$d;",
        ">;",
        "Lcom/google/common/cache/n0<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/cache/g$d;

.field private static final synthetic b:[Lcom/google/common/cache/g$d;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x6

    new-instance v0, Lcom/google/common/cache/g$d;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v1, "TAsNSNsI"

    const-string v1, "TAsNCNIS"

    const/4 v4, 0x2

    const-string v1, "NESmCITN"

    const-string v1, "INSTANCE"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g$d;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    sput-object v0, Lcom/google/common/cache/g$d;->a:Lcom/google/common/cache/g$d;

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/cache/g$d;->b()[Lcom/google/common/cache/g$d;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    sput-object v0, Lcom/google/common/cache/g$d;->b:[Lcom/google/common/cache/g$d;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-void
.end method

.method private static synthetic b()[Lcom/google/common/cache/g$d;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "olt4oM ~~  u@t@o~  fl @@iSo@~~yb~o @@b-m@si @@v/~/~1~@~.@ f@~ ~r~@~ @~  oa@~db @~co~ @K  ~i@n~~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    new-array v0, v0, [Lcom/google/common/cache/g$d;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v2, Lcom/google/common/cache/g$d;->a:Lcom/google/common/cache/g$d;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x3

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/cache/g$d;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-class v0, Lcom/google/common/cache/g$d;

    const-class v0, Lcom/google/common/cache/g$d;

    const/4 v2, 0x7

    const-class v0, Lcom/google/common/cache/g$d;

    const-class v0, Lcom/google/common/cache/g$d;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    check-cast p0, Lcom/google/common/cache/g$d;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lcom/google/common/cache/g$d;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/cache/g$d;->b:[Lcom/google/common/cache/g$d;

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lcom/google/common/cache/g$d;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast v0, [Lcom/google/common/cache/g$d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    return p1
.end method
