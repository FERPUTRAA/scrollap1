.class public final Lcom/google/common/cache/k0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation build Lx4/c;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static synthetic a(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s@ ~@o~@~~@  1r~db@   ~ @ ~@~mo@@lo~~~l ~i~o@ -v~ S~o@~@ @ n~t4~~@ctbfuo~/aM@  s./bi@ ~@K@@fy "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/common/cache/k0;->d(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static synthetic b(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    invoke-static {p0, p1, p2}, Lcom/google/common/cache/k0;->e(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V

    const/4 v0, 0x1

    or-int/2addr v1, v0

    return-void
.end method

.method public static c(Lcom/google/common/cache/h0;Ljava/util/concurrent/Executor;)Lcom/google/common/cache/h0;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "listener",
            "executor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/h0<",
            "TK;TV;>;",
            "Ljava/util/concurrent/Executor;",
            ")",
            "Lcom/google/common/cache/h0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    move v2, v1

    new-instance v0, Lcom/google/common/cache/j0;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p1, p0}, Lcom/google/common/cache/j0;-><init>(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;)V

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method private static synthetic d(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/google/common/cache/h0;->a(Lcom/google/common/cache/l0;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method

.method private static synthetic e(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/cache/i0;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p1, p2}, Lcom/google/common/cache/i0;-><init>(Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
