.class Lcom/google/common/cache/h$k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/h$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "k"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/h;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p3    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "key",
            "value"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    move p3, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    move p3, v0

    move p3, v0

    const/4 v3, 0x6

    move p3, v0

    move p3, v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v1, "assko teascl rv t neSoesedrusadt"

    const-string v1, "eksersns etedSaatco lvt  aotrdus"

    const/4 v3, 0x2

    const-string/jumbo v1, "tusmnovaekdlaoeots a eSrte d cst"

    const-string/jumbo v1, "recordStats does not take values"

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-static {p3, v1}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p3, p1, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez p3, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    move p2, v0

    move p2, v0

    move p2, v0

    move p2, v0

    :goto_1
    const/4 v3, 0x1

    const-string p3, "ayeloarsedcttrdest maoS"

    const-string p3, "adsmcya etrteealSrtorsd"

    const-string/jumbo p3, "resy btraldeetSad csart"

    const-string/jumbo p3, "recordStats already set"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p2, p3}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object p2, p1, Lcom/google/common/cache/h;->g:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method
