.class public final synthetic Lcom/google/common/cache/e;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/time/Duration;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/~s~@f~i@ioK @~@~  ~~@@Mdb@@~@l a ~~ @.@ i@o cu mbb@~~fn/~o@ ~oto@~s~l~ @@~vo4~@ @  S~ry~- ~1@t "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/time/Duration;->isNegative()Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method
