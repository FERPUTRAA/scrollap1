.class final Lcom/google/common/cache/v$c0;
.super Ljava/util/AbstractCollection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "c0"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/AbstractCollection<",
        "TV;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/cache/v;


# direct methods
.method constructor <init>(Lcom/google/common/cache/v;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static synthetic a(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sr@.~ic u Kf /~o~-@y ~ S~ @@d@ @~io@l@it f~@bs@@  1  @~~4~@@t~~olb@~~bv@~o~@~/~   nMa @@om@~o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/google/common/cache/v$c0;->b(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method private static synthetic b(Ljava/util/function/Predicate;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p2}, Lcom/google/common/cache/w;->a(Ljava/util/function/Predicate;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method


# virtual methods
.method public clear()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/common/cache/v;->clear()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/common/cache/v;->containsValue(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/google/common/cache/v;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/cache/v$a0;

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lcom/google/common/cache/v$a0;-><init>(Lcom/google/common/cache/v;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public removeIf(Ljava/util/function/Predicate;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "filter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/Predicate<",
            "-TV;>;)Z"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance v1, Lcom/google/common/cache/a0;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v1, p1}, Lcom/google/common/cache/a0;-><init>(Ljava/util/function/Predicate;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/google/common/cache/v;->Z(Ljava/util/function/BiPredicate;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$c0;->a:Lcom/google/common/cache/v;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/common/cache/v;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/common/cache/v;->d(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->toArray()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    return-object v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)[TE;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/cache/v;->d(Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1
.end method
