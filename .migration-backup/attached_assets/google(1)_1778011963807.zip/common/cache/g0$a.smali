.class final enum Lcom/google/common/cache/g0$a;
.super Lcom/google/common/cache/g0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/g0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4010
    name = null
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    const/4 v0, 0x3

    move v2, v0

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/cache/g0;-><init>(Ljava/lang/String;ILcom/google/common/cache/g0$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method b()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ sK rSu1fi~t@~~~~yd~~am lf~s @tb@ c@@~~ @in@@~~@@  o/o@@/ ~4 @~~ ob@   -@o~.Mb@@~~o@ol@~~ ~  iv"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method
