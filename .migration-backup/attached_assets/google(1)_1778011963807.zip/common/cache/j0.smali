.class public final synthetic Lcom/google/common/cache/j0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/h0;


# instance fields
.field public final synthetic a:Ljava/util/concurrent/Executor;

.field public final synthetic b:Lcom/google/common/cache/h0;


# direct methods
.method public synthetic constructor <init>(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/cache/j0;->a:Ljava/util/concurrent/Executor;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/cache/j0;->b:Lcom/google/common/cache/h0;

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/common/cache/l0;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "d s~~ms~ ai @~ctf u ~ ~~~ ~~@ @~~/@ @ @ot@o~@ @nlrbi -@b~@4@ ~b~o~@~/   f oviy~@@~@@~@K1S@@lM.oo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/cache/j0;->a:Ljava/util/concurrent/Executor;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/cache/j0;->b:Lcom/google/common/cache/h0;

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1, p1}, Lcom/google/common/cache/k0;->b(Ljava/util/concurrent/Executor;Lcom/google/common/cache/h0;Lcom/google/common/cache/l0;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
