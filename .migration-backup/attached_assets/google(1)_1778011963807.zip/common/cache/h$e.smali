.class Lcom/google/common/cache/h$e;
.super Lcom/google/common/cache/h$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "e"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/cache/h$f;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected b(Lcom/google/common/cache/h;I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "spec",
            "value"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "oKs @~ ot~@~ o bo ~@@f~~rsbm@@@~b  iS@~ /t @l@v@ ~@-u1~yo ~~ 4~d@~@@~@ .~oiM~ c~@@a~~@li  f/ n~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p1, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v2, " l ma%a tatdssysairpcowtnecayiit   esl"

    const-string/jumbo v2, "scsattnylidsota  ep %is cweyrliaaita  "

    const/4 v4, 0x4

    const-string v2, "asciosesya  pd natayi%ieciowltat t  rl"

    const-string/jumbo v2, "initial capacity was already set to %s"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object p2, p1, Lcom/google/common/cache/h;->a:Ljava/lang/Integer;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method
