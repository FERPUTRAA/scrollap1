.class interface abstract Lcom/google/common/cache/b0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation build Lx4/b;
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract add(J)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "x"
        }
    .end annotation
.end method

.method public abstract b()J
.end method
