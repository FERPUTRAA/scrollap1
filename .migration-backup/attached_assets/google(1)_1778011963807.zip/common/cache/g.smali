.class public final Lcom/google/common/cache/g;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/cache/g$d;,
        Lcom/google/common/cache/g$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final q:I = 0x10

.field private static final r:I = 0x4

.field private static final s:I = 0x0

.field private static final t:I = 0x0

.field static final u:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "+",
            "Lcom/google/common/cache/a$b;",
            ">;"
        }
    .end annotation
.end field

.field static final v:Lcom/google/common/cache/k;

.field static final w:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "Lcom/google/common/cache/a$b;",
            ">;"
        }
    .end annotation
.end field

.field static final x:Lcom/google/common/base/l1;

.field private static final y:Ljava/util/logging/Logger;

.field static final z:I = -0x1


# instance fields
.field a:Z

.field b:I

.field c:I

.field d:J

.field e:J

.field f:Lcom/google/common/cache/n0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/n0<",
            "-TK;-TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field g:Lcom/google/common/cache/v$u;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field h:Lcom/google/common/cache/v$u;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field i:J

.field j:J

.field k:J

.field l:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field m:Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field n:Lcom/google/common/cache/h0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/h0<",
            "-TK;-TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field o:Lcom/google/common/base/l1;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field p:Lcom/google/common/base/h1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/h1<",
            "+",
            "Lcom/google/common/cache/a$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x0

    new-instance v0, Lcom/google/common/cache/g$a;

    const/4 v14, 0x4

    invoke-direct {v0}, Lcom/google/common/cache/g$a;-><init>()V

    const/4 v14, 0x1

    invoke-static {v0}, Lcom/google/common/base/i1;->d(Ljava/lang/Object;)Lcom/google/common/base/h1;

    move-result-object v0

    const/4 v14, 0x1

    sput-object v0, Lcom/google/common/cache/g;->u:Lcom/google/common/base/h1;

    const/4 v14, 0x2

    new-instance v0, Lcom/google/common/cache/k;

    const/4 v14, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v14, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v14, 0x6

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v14, 0x2

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const/4 v14, 0x5

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v14, 0x4

    invoke-direct/range {v1 .. v13}, Lcom/google/common/cache/k;-><init>(JJJJJJ)V

    const/4 v14, 0x4

    sput-object v0, Lcom/google/common/cache/g;->v:Lcom/google/common/cache/k;

    new-instance v0, Lcom/google/common/cache/f;

    const/4 v14, 0x7

    invoke-direct {v0}, Lcom/google/common/cache/f;-><init>()V

    const/4 v14, 0x5

    sput-object v0, Lcom/google/common/cache/g;->w:Lcom/google/common/base/h1;

    const/4 v14, 0x3

    new-instance v0, Lcom/google/common/cache/g$b;

    const/4 v14, 0x2

    invoke-direct {v0}, Lcom/google/common/cache/g$b;-><init>()V

    const/4 v14, 0x2

    sput-object v0, Lcom/google/common/cache/g;->x:Lcom/google/common/base/l1;

    const/4 v14, 0x7

    const-class v0, Lcom/google/common/cache/g;

    const-class v0, Lcom/google/common/cache/g;

    const-class v0, Lcom/google/common/cache/g;

    const-class v0, Lcom/google/common/cache/g;

    const/4 v14, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x4

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v14, 0x1

    sput-object v0, Lcom/google/common/cache/g;->y:Ljava/util/logging/Logger;

    const/4 v14, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/google/common/cache/g;->a:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/common/cache/g;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/common/cache/g;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/common/cache/g;->d:J

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/google/common/cache/g;->e:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/google/common/cache/g;->i:J

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/google/common/cache/g;->j:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/google/common/cache/g;->k:J

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v0, Lcom/google/common/cache/g;->u:Lcom/google/common/base/h1;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/common/cache/g;->p:Lcom/google/common/base/h1;

    return-void
.end method

.method private static synthetic D()Lcom/google/common/cache/a$b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@-  @@~~ ~@ ~yi bo~ @@~~~~~uoi1~@@r~ ~tv ~4a/f t~c bo~s@/@.~~MSolo@  @ o~n~ ~lm@i@@~b@@@K  @d"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/cache/a$a;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/cache/a$a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static H()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/cache/g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/cache/g;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method private static Q(Ljava/time/Duration;)J
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "duration"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/google/common/cache/d;->a(Ljava/time/Duration;)J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/ArithmeticException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/google/common/cache/e;->a(Ljava/time/Duration;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x6

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    :goto_0
    const/4 v3, 0x3

    return-wide v0
.end method

.method public static synthetic a()Lcom/google/common/cache/a$b;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/common/cache/g;->D()Lcom/google/common/cache/a$b;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method private d()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    iget-wide v0, p0, Lcom/google/common/cache/g;->k:J

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const-string v1, "afsCer horrtitesarr qcs LeueneehfWigrdaAe"

    const/4 v5, 0x4

    const-string v1, "egLmarufe rrri t iotcdsWAfereanhhrCqeeisa"

    const-string/jumbo v1, "refreshAfterWrite requires a LoadingCache"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v5, 0x1

    return-void
.end method

.method private e()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x7

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez v0, :cond_1

    const/4 v8, 0x0

    iget-wide v5, p0, Lcom/google/common/cache/g;->e:J

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    cmp-long v0, v5, v3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    move v1, v2

    move v1, v2

    const/4 v8, 0x1

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v8, 0x4

    const-string/jumbo v0, "xh homusimeeta mmerriuwgiWeeqi"

    const-string/jumbo v0, "ew mehWmex aiurhsuerimemgqiirt"

    const/4 v8, 0x1

    const-string/jumbo v0, "tegixbeshrwauqmeermge  mhiWiru"

    const-string/jumbo v0, "maximumWeight requires weigher"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v1, v0}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_2

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-boolean v0, p0, Lcom/google/common/cache/g;->a:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eqz v0, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-wide v5, p0, Lcom/google/common/cache/g;->e:J

    const/4 v7, 0x7

    move v8, v7

    cmp-long v0, v5, v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_1

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    move v1, v2

    move v1, v2

    const/4 v8, 0x7

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v0, " rmrWeuwhesiaitmureogqhgeimex "

    const-string/jumbo v0, "ushiomewxWaqmerimeh reritegg i"

    const/4 v8, 0x4

    const-string/jumbo v0, "gre remp rxmeWitmqiwiaihsehueu"

    const-string/jumbo v0, "weigher requires maximumWeight"

    const/4 v8, 0x1

    invoke-static {v1, v0}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_2

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/g;->e:J

    const/4 v8, 0x2

    const/4 v7, 0x6

    cmp-long v0, v0, v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-nez v0, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget-object v0, Lcom/google/common/cache/g;->y:Ljava/util/logging/Logger;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    sget-object v1, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v2, "eiuienhpqr ig oifhndtggrhmxteemocw iwgmiiaib Wut"

    const-string/jumbo v2, "odneibmminxoierhWigwefgiu   ehwitrctmhe gauitpig"

    const-string v2, "dussewoxwtetguiigegiteiihaogcmnWfimmrrii np  eh "

    const-string/jumbo v2, "ignoring weigher specified without maximumWeight"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V

    :cond_4
    :goto_2
    const/4 v7, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    return-void
.end method

.method public static k(Lcom/google/common/cache/h;)Lcom/google/common/cache/g;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "spec"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/h;",
            ")",
            "Lcom/google/common/cache/g<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/h;->f()Lcom/google/common/cache/g;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/common/cache/g;->E()Lcom/google/common/cache/g;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method public static l(Ljava/lang/String;)Lcom/google/common/cache/g;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "spec"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/google/common/cache/g<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/cache/h;->e(Ljava/lang/String;)Lcom/google/common/cache/h;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/cache/g;->k(Lcom/google/common/cache/h;)Lcom/google/common/cache/g;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method


# virtual methods
.method public A(I)Lcom/google/common/cache/g;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "initialCapacity"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v0, p0, Lcom/google/common/cache/g;->b:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v1, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v3, 0x3

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    move v1, v2

    move v1, v2

    const/4 v6, 0x7

    move v1, v2

    move v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    move v1, v3

    move v1, v3

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v4, " aomdawiia seeiatstsu a  ti lytnla%prc"

    const-string v4, "  ioslu cata yt%eeaawliti say rndtpsai"

    const-string/jumbo v4, "iindoastip  w% eayactt aialy ocraselst"

    const-string/jumbo v4, "initial capacity was already set to %s"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1, v4, v0}, Lcom/google/common/base/u0;->n0(ZLjava/lang/String;I)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ltz p1, :cond_1

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    move v2, v3

    move v2, v3

    const/4 v6, 0x1

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput p1, p0, Lcom/google/common/cache/g;->b:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p0
.end method

.method B()Z
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/cache/g;->p:Lcom/google/common/base/h1;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v1, Lcom/google/common/cache/g;->w:Lcom/google/common/base/h1;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method C(Lcom/google/common/base/m;)Lcom/google/common/cache/g;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "equivalence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/cache/g;->l:Lcom/google/common/base/m;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, "a l sbnui ees pt vkaocyey%ewea radetl"

    const-string/jumbo v2, "eyealaipd aro ket nyelst a swvu% esce"

    const/4 v4, 0x7

    const-string/jumbo v2, "ucdey uva eaasn wtitrqeels%kose  ael "

    const-string/jumbo v2, "key equivalence was already set to %s"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->x0(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast p1, Lcom/google/common/base/m;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/common/cache/g;->l:Lcom/google/common/base/m;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p0
.end method

.method E()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/common/cache/g;->a:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public F(J)Lcom/google/common/cache/g;
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "maximumSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-wide v0, p0, Lcom/google/common/cache/g;->d:J

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x5

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x4

    cmp-long v4, v0, v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v5, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-nez v4, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    move v4, v5

    move v4, v5

    const/4 v9, 0x2

    move v4, v5

    move v4, v5

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    move v4, v6

    const/4 v9, 0x3

    move v4, v6

    move v4, v6

    :goto_0
    const/4 v9, 0x4

    const-string/jumbo v7, "saaemm%piareutyxow mqst zs  s eild"

    const-string/jumbo v7, "ewtz eiaqa astos muis drxmay%m les"

    const/4 v9, 0x5

    const-string/jumbo v7, "sm  mtaeqsa isla mxwet szu dr%ayie"

    const-string/jumbo v7, "maximum size was already set to %s"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v4, v7, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-wide v0, p0, Lcom/google/common/cache/g;->e:J

    const/4 v9, 0x0

    cmp-long v2, v0, v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    move v2, v5

    move v2, v5

    const/4 v9, 0x3

    move v2, v5

    move v2, v5

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    move v2, v6

    move v2, v6

    const/4 v9, 0x1

    move v2, v6

    move v2, v6

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v3, "yss roeaml umxtatast%swa  is whegie "

    const-string/jumbo v3, "resexhts a %maogldt a i swmisue ywat"

    const/4 v9, 0x4

    const-string v3, "a%mme eyl  mmaswuai dxtseg wha stirt"

    const-string/jumbo v3, "maximum weight was already set to %s"

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    invoke-static {v2, v3, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-nez v0, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    move v0, v5

    move v0, v5

    const/4 v9, 0x6

    move v0, v5

    move v0, v5

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto :goto_2

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    move v0, v6

    move v0, v6

    const/4 v9, 0x6

    move v0, v6

    move v0, v6

    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string v1, "c wmoimiennhaxd rsmtbi atwmeeo cnz   ghboueim"

    const-string v1, "easmbe inmticcor iu nbwee hod ahi mmn wiztxgm"

    const/4 v9, 0x3

    const-string v1, "ba ztb wiiei eg iomaebec mmwhcsnr ehiunn mxdt"

    const-string/jumbo v1, "maximum size can not be combined with weigher"

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x3

    cmp-long v0, p1, v0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-ltz v0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_3

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    move v5, v6

    move v5, v6

    move v5, v6

    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x3

    const-string v0, "aeieiauumistg tme n mnszvxb oetuo"

    const-string v0, " xmmous ienitaonembzmteusa tevig "

    const/4 v9, 0x0

    const-string/jumbo v0, "matsaibpvmiusengeti z oxnme  utm "

    const-string/jumbo v0, "maximum size must not be negative"

    const/4 v8, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v5, v0}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    iput-wide p1, p0, Lcom/google/common/cache/g;->d:J

    const/4 v9, 0x4

    return-object p0
.end method

.method public G(J)Lcom/google/common/cache/g;
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "maximumWeight"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x4

    iget-wide v0, p0, Lcom/google/common/cache/g;->e:J

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    cmp-long v4, v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v5, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/4 v6, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-nez v4, :cond_0

    const/4 v9, 0x7

    move v4, v5

    move v4, v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    move v4, v6

    move v4, v6

    const/4 v9, 0x1

    move v4, v6

    move v4, v6

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo v7, "w ewmas qmai%ud yta emtl shisxgrt be"

    const-string v7, "e  tlb aiho%m weaeumgsatis wsxtdymr "

    const/4 v9, 0x3

    const-string/jumbo v7, "s sy ads  teeamtarewuth%l xgawimo si"

    const-string/jumbo v7, "maximum weight was already set to %s"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v4, v7, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v8, 0x6

    and-int/2addr v9, v8

    iget-wide v0, p0, Lcom/google/common/cache/g;->d:J

    const/4 v9, 0x2

    cmp-long v2, v0, v2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v2, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    move v2, v5

    const/4 v9, 0x6

    move v2, v5

    move v2, v5

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    move v2, v6

    move v2, v6

    const/4 v9, 0x0

    move v2, v6

    move v2, v6

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string/jumbo v3, "muamzewataes lymior%ts es   xsmuda"

    const-string/jumbo v3, "memsu%usirzw  e aa eslysam x otadt"

    const/4 v9, 0x3

    const-string/jumbo v3, "sdazo  itwar maoeelxem%s  tmsiau s"

    const-string/jumbo v3, "maximum size was already set to %s"

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v2, v3, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    cmp-long v0, p1, v0

    if-ltz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_2

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    move v5, v6

    :goto_2
    const/4 v9, 0x5

    const-string v0, "  umebatiwtaeumi nno t etisgghevmbx"

    const-string/jumbo v0, "maximum weight must not be negative"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5, v0}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    iput-wide p1, p0, Lcom/google/common/cache/g;->e:J

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-object p0
.end method

.method public I()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/cache/g;->w:Lcom/google/common/base/h1;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    iput-object v0, p0, Lcom/google/common/cache/g;->p:Lcom/google/common/base/h1;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public J(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "duration",
            "unit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/concurrent/TimeUnit;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p3}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-wide v0, p0, Lcom/google/common/cache/g;->k:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    cmp-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v3, 0x1

    const/4 v7, 0x4

    shl-int/2addr v6, v3

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x2

    move v6, v4

    move v6, v4

    const/4 v7, 0x3

    if-nez v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    move v2, v3

    move v2, v3

    const/4 v7, 0x0

    move v2, v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v2, v4

    move v2, v4

    const/4 v7, 0x1

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v5, "r etoeuy rlntsrdsaesaafh% p ws s"

    const-string/jumbo v5, "olsh eepsn%aeftsra dr w ty sresa"

    const/4 v7, 0x3

    const-string/jumbo v5, "lay ssrp% saeest ehw ofresan r d"

    const-string/jumbo v5, "refresh was already set to %s ns"

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-static {v2, v5, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x3

    const-wide/16 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    cmp-long v0, p1, v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-lez v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    move v3, v4

    move v3, v4

    const/4 v7, 0x4

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v0, "tutenvbsq siod o riq%msp iea% :s"

    const-string/jumbo v0, "msn:% t qis ardoeu tsbiv %poeist"

    const/4 v7, 0x3

    const-string/jumbo v0, "ois:auiiom%tn  rss  esepds%vt tb"

    const-string v0, "duration must be positive: %s %s"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v3, v0, p1, p2, p3}, Lcom/google/common/base/u0;->t(ZLjava/lang/String;JLjava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-wide p1, p0, Lcom/google/common/cache/g;->k:J

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-object p0
.end method

.method public K(Ljava/time/Duration;)Lcom/google/common/cache/g;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "duration"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/time/Duration;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/google/common/cache/g;->Q(Ljava/time/Duration;)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    sget-object p1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/common/cache/g;->J(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method public L(Lcom/google/common/cache/h0;)Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "listener"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>(",
            "Lcom/google/common/cache/h0<",
            "-TK1;-TV1;>;)",
            "Lcom/google/common/cache/g<",
            "TK1;TV1;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/cache/g;->n:Lcom/google/common/cache/h0;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v1, 0x6

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Lcom/google/common/cache/h0;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/common/cache/g;->n:Lcom/google/common/cache/h0;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method M(Lcom/google/common/cache/v$u;)Lcom/google/common/cache/g;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "strength"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/v$u;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/cache/g;->g:Lcom/google/common/cache/v$u;

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "ee msa % yrwagntKysth sdrst leost "

    const-string/jumbo v2, "nes stKygse rersod shtatal y% e tw"

    const-string v2, "ee not attsr as hawsK sgrl yye%det"

    const-string v2, "Key strength was already set to %s"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->x0(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast p1, Lcom/google/common/cache/v$u;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/google/common/cache/g;->g:Lcom/google/common/cache/v$u;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0
.end method

.method N(Lcom/google/common/cache/v$u;)Lcom/google/common/cache/g;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "strength"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/v$u;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/cache/g;->h:Lcom/google/common/cache/v$u;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "nrhembta  tauetssg y  s ldVteeoswlar"

    const-string v2, " ormn ttayeaashrsVldetegsa tsue w  l"

    const/4 v4, 0x6

    const-string v2, "%gdwtyu aeeslhassenVatl t  strea uo "

    const-string v2, "Value strength was already set to %s"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->x0(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p1, Lcom/google/common/cache/v$u;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/common/cache/g;->h:Lcom/google/common/cache/v$u;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p0
.end method

.method public O()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    sget-object v0, Lcom/google/common/cache/v$u;->b:Lcom/google/common/cache/v$u;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/common/cache/g;->N(Lcom/google/common/cache/v$u;)Lcom/google/common/cache/g;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public P(Lcom/google/common/base/l1;)Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ticker"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/l1;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/g;->o:Lcom/google/common/base/l1;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p1, Lcom/google/common/base/l1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/common/cache/g;->o:Lcom/google/common/base/l1;

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method R(Lcom/google/common/base/m;)Lcom/google/common/cache/g;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "equivalence"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/cache/g;->m:Lcom/google/common/base/m;

    const/4 v3, 0x3

    move v4, v3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v2, "luouqe pe aeosec%vwslatvre  ei ydasnata"

    const-string v2, "%utaoneloe aaleq rswdesviaav  csy te ue"

    const/4 v4, 0x2

    const-string v2, " e sutveqalnteyeasle   qvu iarsdclaoaew"

    const-string/jumbo v2, "value equivalence was already set to %s"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Lcom/google/common/base/u0;->x0(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p1, Lcom/google/common/base/m;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object p1, p0, Lcom/google/common/cache/g;->m:Lcom/google/common/base/m;

    const/4 v4, 0x0

    const/4 v3, 0x5

    return-object p0
.end method

.method public S()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/cache/g;->M(Lcom/google/common/cache/v$u;)Lcom/google/common/cache/g;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public T()Lcom/google/common/cache/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/cache/g;->N(Lcom/google/common/cache/v$u;)Lcom/google/common/cache/g;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public U(Lcom/google/common/cache/n0;)Lcom/google/common/cache/g;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "weigher"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>(",
            "Lcom/google/common/cache/n0<",
            "-TK1;-TV1;>;)",
            "Lcom/google/common/cache/g<",
            "TK1;TV1;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    move v0, v1

    move v0, v1

    const/4 v8, 0x0

    move v0, v1

    move v0, v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    move v0, v2

    move v0, v2

    const/4 v8, 0x2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-boolean v0, p0, Lcom/google/common/cache/g;->a:Z

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v0, :cond_2

    iget-wide v3, p0, Lcom/google/common/cache/g;->d:J

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v8, 0x3

    const-wide/16 v5, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    cmp-long v0, v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-nez v0, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    move v1, v2

    move v1, v2

    const/4 v8, 0x3

    move v1, v2

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string v0, " dso wcihmuxedtm ipgoebr%iea  bendcitnzi bvns (aw )hemre so"

    const-string/jumbo v0, "m euob ie%hm  n im)s eao ora i dcxiwtwcbbnregipnedevithsd(z"

    const/4 v8, 0x4

    const-string v0, " zdmi otgthsv) a oedr iwmidcmcwiheimep  bamo%snbnu(ee r xni"

    const-string/jumbo v0, "weigher can not be combined with maximum size (%s provided)"

    const/4 v8, 0x0

    invoke-static {v1, v0, v3, v4}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    check-cast p1, Lcom/google/common/cache/n0;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    iput-object p1, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-object p0
.end method

.method public b()Lcom/google/common/cache/c;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>()",
            "Lcom/google/common/cache/c<",
            "TK1;TV1;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/cache/g;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/common/cache/g;->d()V

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/cache/v$p;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/cache/v$p;-><init>(Lcom/google/common/cache/g;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public c(Lcom/google/common/cache/j;)Lcom/google/common/cache/o;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "loader"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>(",
            "Lcom/google/common/cache/j<",
            "-TK1;TV1;>;)",
            "Lcom/google/common/cache/o<",
            "TK1;TV1;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/cache/g;->e()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/cache/v$o;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/common/cache/v$o;-><init>(Lcom/google/common/cache/g;Lcom/google/common/cache/j;)V

    const/4 v2, 0x1

    return-object v0
.end method

.method public f(I)Lcom/google/common/cache/g;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "concurrencyLevel"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v0, p0, Lcom/google/common/cache/g;->c:I

    const/4 v6, 0x3

    const/4 v1, -0x1

    const/4 v6, 0x6

    xor-int/2addr v5, v1

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x1

    move v6, v5

    const/4 v3, 0x0

    move v6, v3

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ne v0, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    const/4 v6, 0x2

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const-string/jumbo v4, "seero lc%a ncorweotu vn ss lyeetalrydac"

    const-string/jumbo v4, "lcsnacue%wlyuy csets rot neeav d oaerrl"

    const/4 v6, 0x7

    const-string v4, "aaonrbr%lcaycwensr e sc t es uetyeldlov"

    const-string v4, "concurrency level was already set to %s"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1, v4, v0}, Lcom/google/common/base/u0;->n0(ZLjava/lang/String;I)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-lez p1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    move v2, v3

    move v2, v3

    const/4 v6, 0x5

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    iput p1, p0, Lcom/google/common/cache/g;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object p0
.end method

.method public g(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "duration",
            "unit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/concurrent/TimeUnit;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-wide v0, p0, Lcom/google/common/cache/g;->j:J

    const/4 v6, 0x4

    or-int/2addr v7, v6

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    cmp-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v4, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    move v2, v3

    move v2, v3

    const/4 v7, 0x0

    move v2, v3

    move v2, v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v2, v4

    move v2, v4

    const/4 v7, 0x0

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v5, "%rydp ueaAstpAe ft stnlsrosecawe  csa eexi"

    const-string/jumbo v5, "y at lAp %ad rrefreAt  cespssswaseneoceitx"

    const/4 v7, 0x2

    const-string v5, " dAscaipneAxeeyl erst cfss%er rwsa totpsae"

    const-string/jumbo v5, "expireAfterAccess was already set to %s ns"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v2, v5, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    cmp-long v0, p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ltz v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    move v3, v4

    move v3, v4

    const/4 v7, 0x2

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const-string v0, " etsa:toq %i naseqntv god%ecuin bn"

    const-string v0, "%sbnevaoqtn tr i d%nusget:no eca i"

    const-string/jumbo v0, "tos:einrsia   n%%vst oa cetangudbn"

    const-string v0, "duration cannot be negative: %s %s"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v3, v0, p1, p2, p3}, Lcom/google/common/base/u0;->t(ZLjava/lang/String;JLjava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    iput-wide p1, p0, Lcom/google/common/cache/g;->j:J

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-object p0
.end method

.method public h(Ljava/time/Duration;)Lcom/google/common/cache/g;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "duration"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/time/Duration;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/common/cache/g;->Q(Ljava/time/Duration;)J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/common/cache/g;->g(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public i(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "duration",
            "unit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/concurrent/TimeUnit;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-wide v0, p0, Lcom/google/common/cache/g;->i:J

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x5

    cmp-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x6

    if-nez v2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    move v2, v3

    move v2, v3

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    move v2, v4

    move v2, v4

    const/4 v7, 0x4

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v5, "erssasd eew% yiip tx olrW artseA rtesatef"

    const/4 v7, 0x6

    const-string/jumbo v5, "s sme  %l Wiatsteyre ap wtriedxoafArsnree"

    const-string/jumbo v5, "expireAfterWrite was already set to %s ns"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v2, v5, v0, v1}, Lcom/google/common/base/u0;->s0(ZLjava/lang/String;J)V

    const/4 v7, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    cmp-long v0, p1, v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ltz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_1

    :cond_1
    move v3, v4

    const/4 v7, 0x4

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v0, "crn oegb sn%ni ateutanvoiam :ts d%"

    const-string/jumbo v0, "invmct s %g nta ot%daun:ree baenis"

    const/4 v7, 0x6

    const-string v0, "et onbauogt:a%es tdbierv ni%nsa cn"

    const-string v0, "duration cannot be negative: %s %s"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v3, v0, p1, p2, p3}, Lcom/google/common/base/u0;->t(ZLjava/lang/String;JLjava/lang/Object;)V

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-wide p1, p0, Lcom/google/common/cache/g;->i:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-object p0
.end method

.method public j(Ljava/time/Duration;)Lcom/google/common/cache/g;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "duration"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/time/Duration;",
            ")",
            "Lcom/google/common/cache/g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/common/cache/g;->Q(Ljava/time/Duration;)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object p1, Ljava/util/concurrent/TimeUnit;->NANOSECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/common/cache/g;->i(JLjava/util/concurrent/TimeUnit;)Lcom/google/common/cache/g;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1
.end method

.method m()I
    .locals 4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/common/cache/g;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x4

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v0
.end method

.method n()J
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/google/common/cache/g;->j:J

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x3

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    cmp-long v2, v0, v2

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-wide v0
.end method

.method o()J
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/google/common/cache/g;->i:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    cmp-long v2, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-wide v0
.end method

.method p()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/common/cache/g;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v0, 0x10

    :cond_0
    const/4 v3, 0x0

    return v0
.end method

.method q()Lcom/google/common/base/m;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/cache/g;->l:Lcom/google/common/base/m;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/common/cache/g;->r()Lcom/google/common/cache/v$u;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/common/cache/v$u;->b()Lcom/google/common/base/m;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/google/common/base/m;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method r()Lcom/google/common/cache/v$u;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/cache/g;->g:Lcom/google/common/cache/v$u;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/google/common/cache/v$u;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method

.method s()J
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-wide v0, p0, Lcom/google/common/cache/g;->i:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/common/cache/g;->j:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/g;->d:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/google/common/cache/g;->e:J

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-wide v0

    :cond_2
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-wide v2
.end method

.method t()J
    .locals 6

    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/common/cache/g;->k:J

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-wide v0
.end method

.method public toString()Ljava/lang/String;
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/google/common/base/y;->c(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget v1, p0, Lcom/google/common/cache/g;->b:I

    const/4 v7, 0x6

    move v8, v7

    const/4 v2, -0x3

    const/4 v2, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eq v1, v2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v3, "anolpyuCiititaa"

    const-string/jumbo v3, "naaioiyciCatptl"

    const/4 v8, 0x0

    const-string v3, "citaCaipnpiayit"

    const-string/jumbo v3, "initialCapacity"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, v3, v1}, Lcom/google/common/base/y$b;->d(Ljava/lang/String;I)Lcom/google/common/base/y$b;

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget v1, p0, Lcom/google/common/cache/g;->c:I

    const/4 v8, 0x7

    if-eq v1, v2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v2, "rnorbuleqcevncey"

    const-string v2, "ecnulbceyrLrneov"

    const/4 v8, 0x7

    const-string/jumbo v2, "uoselnccnyrrLevc"

    const-string v2, "concurrencyLevel"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0, v2, v1}, Lcom/google/common/base/y$b;->d(Ljava/lang/String;I)Lcom/google/common/base/y$b;

    :cond_1
    const/4 v7, 0x3

    move v8, v7

    iget-wide v1, p0, Lcom/google/common/cache/g;->d:J

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    cmp-long v5, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v5, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v5, "muemiimumzx"

    const-string/jumbo v5, "mmamiiuexzu"

    const/4 v8, 0x2

    const-string/jumbo v5, "ixSioauemmm"

    const-string/jumbo v5, "maximumSize"

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0, v5, v1, v2}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-wide v1, p0, Lcom/google/common/cache/g;->e:J

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    cmp-long v5, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v5, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo v5, "gtiWebmmpauix"

    const-string v5, "agmeutxpmWihi"

    const/4 v8, 0x0

    const-string/jumbo v5, "gxmmaiuWtmuih"

    const-string/jumbo v5, "maximumWeight"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v5, v1, v2}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/common/cache/g;->i:J

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    cmp-long v1, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v2, "ns"

    const-string/jumbo v2, "sn"

    const-string/jumbo v2, "ns"

    const-string/jumbo v2, "ns"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v1, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    iget-wide v5, p0, Lcom/google/common/cache/g;->i:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string/jumbo v5, "reixiAfprWrptete"

    const-string/jumbo v5, "expireAfterWrite"

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0, v5, v1}, Lcom/google/common/base/y$b;->f(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-wide v5, p0, Lcom/google/common/cache/g;->j:J

    const/4 v8, 0x5

    const/4 v7, 0x2

    cmp-long v1, v5, v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    if-eqz v1, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-wide v3, p0, Lcom/google/common/cache/g;->j:J

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v2, "csrseAftqAreeqepi"

    const-string/jumbo v2, "sreiertsqAepAccfe"

    const/4 v8, 0x5

    const-string v2, "cAseeitpecrseAfsx"

    const-string/jumbo v2, "expireAfterAccess"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Lcom/google/common/base/y$b;->f(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_5
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/google/common/cache/g;->g:Lcom/google/common/cache/v$u;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v1, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/google/common/base/c;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v2, "hgtmnekrets"

    const-string/jumbo v2, "ttsgeehykrn"

    const/4 v8, 0x2

    const-string v2, "Sttyohenkeg"

    const-string/jumbo v2, "keyStrength"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Lcom/google/common/base/y$b;->f(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_6
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/common/cache/g;->h:Lcom/google/common/cache/v$u;

    const/4 v8, 0x2

    if-eqz v1, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1}, Lcom/google/common/base/c;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v2, "mhetubnrlSgtv"

    const-string/jumbo v2, "htSmuegrltnva"

    const/4 v8, 0x1

    const-string/jumbo v2, "guehevutrSlnt"

    const-string/jumbo v2, "valueStrength"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, v2, v1}, Lcom/google/common/base/y$b;->f(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_7
    const/4 v8, 0x2

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/common/cache/g;->l:Lcom/google/common/base/m;

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v1, :cond_8

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v1, "cvlykuEpqeeein"

    const-string/jumbo v1, "keyEquivalence"

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Lcom/google/common/base/y$b;->s(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_8
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/google/common/cache/g;->m:Lcom/google/common/base/m;

    const/4 v7, 0x3

    and-int/2addr v8, v7

    if-eqz v1, :cond_9

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v1, "ucEaelalqvqevuni"

    const-string v1, "eqevoluilavacEun"

    const/4 v8, 0x4

    const-string/jumbo v1, "valueEquivalence"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Lcom/google/common/base/y$b;->s(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_9
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/common/cache/g;->n:Lcom/google/common/cache/h0;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v1, :cond_a

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo v1, "nssieaoeLlrvmeb"

    const-string/jumbo v1, "iLeotbmvlaesren"

    const/4 v8, 0x2

    const-string/jumbo v1, "malmsvrinreeLot"

    const-string/jumbo v1, "removalListener"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Lcom/google/common/base/y$b;->s(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    :cond_a
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/google/common/base/y$b;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object v0
.end method

.method u()Lcom/google/common/cache/h0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>()",
            "Lcom/google/common/cache/h0<",
            "TK1;TV1;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/cache/g;->n:Lcom/google/common/cache/h0;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v1, Lcom/google/common/cache/g$c;->a:Lcom/google/common/cache/g$c;

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/common/cache/h0;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method v()Lcom/google/common/base/h1;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/base/h1<",
            "+",
            "Lcom/google/common/cache/a$b;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/cache/g;->p:Lcom/google/common/base/h1;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method w(Z)Lcom/google/common/base/l1;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "recordsTime"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/cache/g;->o:Lcom/google/common/base/l1;

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/base/l1;->b()Lcom/google/common/base/l1;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object p1, Lcom/google/common/cache/g;->x:Lcom/google/common/base/l1;

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1
.end method

.method x()Lcom/google/common/base/m;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/cache/g;->m:Lcom/google/common/base/m;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/g;->y()Lcom/google/common/cache/v$u;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/google/common/cache/v$u;->b()Lcom/google/common/base/m;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v0, Lcom/google/common/base/m;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method y()Lcom/google/common/cache/v$u;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/cache/g;->h:Lcom/google/common/cache/v$u;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v1, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/google/common/cache/v$u;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method z()Lcom/google/common/cache/n0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K1:TK;V1:TV;>()",
            "Lcom/google/common/cache/n0<",
            "TK1;TV1;>;"
        }
    .end annotation

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/cache/g;->f:Lcom/google/common/cache/n0;

    const/4 v3, 0x5

    const/4 v2, 0x7

    sget-object v1, Lcom/google/common/cache/g$d;->a:Lcom/google/common/cache/g$d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Lcom/google/common/cache/n0;

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-object v0
.end method
