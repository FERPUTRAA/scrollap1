.class public final Lcom/google/common/cache/k;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/cache/l;
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field private final a:J

.field private final b:J

.field private final c:J

.field private final d:J

.field private final e:J

.field private final f:J


# direct methods
.method public constructor <init>(JJJJJJ)V
    .locals 18
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "hitCount",
            "missCount",
            "loadSuccessCount",
            "loadExceptionCount",
            "totalLoadTime",
            "evictionCount"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move-wide/from16 v3, p3

    move-wide/from16 v5, p5

    move-wide/from16 v7, p7

    move-wide/from16 v9, p9

    move-wide/from16 v11, p11

    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    cmp-long v15, v1, v13

    const/16 v16, 0x1

    const/16 v17, 0x0

    if-ltz v15, :cond_0

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    goto :goto_0

    :cond_0
    move/from16 v15, v17

    move/from16 v15, v17

    :goto_0
    invoke-static {v15}, Lcom/google/common/base/u0;->d(Z)V

    cmp-long v15, v3, v13

    if-ltz v15, :cond_1

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    goto :goto_1

    :cond_1
    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    :goto_1
    invoke-static {v15}, Lcom/google/common/base/u0;->d(Z)V

    cmp-long v15, v5, v13

    if-ltz v15, :cond_2

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    goto :goto_2

    :cond_2
    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    :goto_2
    invoke-static {v15}, Lcom/google/common/base/u0;->d(Z)V

    cmp-long v15, v7, v13

    if-ltz v15, :cond_3

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    goto :goto_3

    :cond_3
    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    :goto_3
    invoke-static {v15}, Lcom/google/common/base/u0;->d(Z)V

    cmp-long v15, v9, v13

    if-ltz v15, :cond_4

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    move/from16 v15, v16

    goto :goto_4

    :cond_4
    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    move/from16 v15, v17

    :goto_4
    invoke-static {v15}, Lcom/google/common/base/u0;->d(Z)V

    cmp-long v13, v11, v13

    if-ltz v13, :cond_5

    goto :goto_5

    :cond_5
    move/from16 v16, v17

    move/from16 v16, v17

    :goto_5
    invoke-static/range {v16 .. v16}, Lcom/google/common/base/u0;->d(Z)V

    iput-wide v1, v0, Lcom/google/common/cache/k;->a:J

    iput-wide v3, v0, Lcom/google/common/cache/k;->b:J

    iput-wide v5, v0, Lcom/google/common/cache/k;->c:J

    iput-wide v7, v0, Lcom/google/common/cache/k;->d:J

    iput-wide v9, v0, Lcom/google/common/cache/k;->e:J

    iput-wide v11, v0, Lcom/google/common/cache/k;->f:J

    return-void
.end method


# virtual methods
.method public a()D
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "v sfo@ i @~r~1 @~ ~cy ~@@u@@bo@d ~~oS~  ll~@.  @Mi ~ nis@4m@@@fo~~~@a ~K~ b~@~~@~ /@ -~~bott/o~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/k;->c:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0, v1, v2, v3}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x6

    or-int/2addr v5, v4

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v2, :cond_0

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/common/cache/k;->e:J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    long-to-double v2, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    long-to-double v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    div-double v0, v2, v0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-wide v0
.end method

.method public b()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/google/common/cache/k;->f:J

    const/4 v3, 0x4

    return-wide v0
.end method

.method public c()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/google/common/cache/k;->a:J

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide v0
.end method

.method public d()D
    .locals 6

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/common/cache/k;->m()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    cmp-long v2, v0, v2

    if-nez v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    const/4 v5, 0x0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->a:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    long-to-double v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    long-to-double v0, v0

    const/4 v5, 0x4

    div-double v0, v2, v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-wide v0
.end method

.method public e()J
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/google/common/cache/k;->c:J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v1, v2, v3}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-wide v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    instance-of v0, p1, Lcom/google/common/cache/k;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    check-cast p1, Lcom/google/common/cache/k;

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->a:J

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-wide v4, p1, Lcom/google/common/cache/k;->a:J

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    cmp-long v0, v2, v4

    const/4 v6, 0x3

    move v7, v6

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->b:J

    const/4 v7, 0x1

    iget-wide v4, p1, Lcom/google/common/cache/k;->b:J

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    cmp-long v0, v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v2, p0, Lcom/google/common/cache/k;->c:J

    iget-wide v4, p1, Lcom/google/common/cache/k;->c:J

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    cmp-long v0, v2, v4

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-wide v4, p1, Lcom/google/common/cache/k;->d:J

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    cmp-long v0, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/google/common/cache/k;->e:J

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-wide v4, p1, Lcom/google/common/cache/k;->e:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    cmp-long v0, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/google/common/cache/k;->f:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-wide v4, p1, Lcom/google/common/cache/k;->f:J

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    cmp-long p1, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez p1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v1, 0x1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    return v1
.end method

.method public f()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/k;->d:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-wide v0
.end method

.method public g()D
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    iget-wide v0, p0, Lcom/google/common/cache/k;->c:J

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v5, 0x3

    invoke-static {v0, v1, v2, v3}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    cmp-long v2, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const/4 v5, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    move v5, v4

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    long-to-double v2, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    long-to-double v0, v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    div-double v0, v2, v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    return-wide v0
.end method

.method public h()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/google/common/cache/k;->c:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-wide v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x6

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x0

    iget-wide v1, p0, Lcom/google/common/cache/k;->a:J

    const/4 v4, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/google/common/cache/k;->b:J

    const/4 v3, 0x3

    move v4, v3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    shl-int/2addr v4, v2

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/google/common/cache/k;->c:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/google/common/cache/k;->d:J

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    aput-object v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/google/common/cache/k;->e:J

    const/4 v4, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v3, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/google/common/cache/k;->f:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object v1, v0, v2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/base/m0;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method public i(Lcom/google/common/cache/k;)Lcom/google/common/cache/k;
    .locals 17
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    new-instance v14, Lcom/google/common/cache/k;

    iget-wide v2, v0, Lcom/google/common/cache/k;->a:J

    iget-wide v4, v1, Lcom/google/common/cache/k;->a:J

    invoke-static {v2, v3, v4, v5}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    iget-wide v6, v0, Lcom/google/common/cache/k;->b:J

    iget-wide v8, v1, Lcom/google/common/cache/k;->b:J

    invoke-static {v6, v7, v8, v9}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v6

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v6

    iget-wide v8, v0, Lcom/google/common/cache/k;->c:J

    iget-wide v10, v1, Lcom/google/common/cache/k;->c:J

    invoke-static {v8, v9, v10, v11}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v8

    invoke-static {v4, v5, v8, v9}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v8

    iget-wide v10, v0, Lcom/google/common/cache/k;->d:J

    iget-wide v12, v1, Lcom/google/common/cache/k;->d:J

    invoke-static {v10, v11, v12, v13}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v10

    invoke-static {v4, v5, v10, v11}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v10

    iget-wide v12, v0, Lcom/google/common/cache/k;->e:J

    move-wide v15, v10

    iget-wide v10, v1, Lcom/google/common/cache/k;->e:J

    invoke-static {v12, v13, v10, v11}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v10

    invoke-static {v4, v5, v10, v11}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v10

    iget-wide v12, v0, Lcom/google/common/cache/k;->f:J

    iget-wide v0, v1, Lcom/google/common/cache/k;->f:J

    invoke-static {v12, v13, v0, v1}, Lcom/google/common/math/h;->A(JJ)J

    move-result-wide v0

    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v12

    move-object v1, v14

    move-object v1, v14

    move-object v1, v14

    move-object v1, v14

    move-wide v4, v6

    move-wide v6, v8

    move-wide v8, v15

    invoke-direct/range {v1 .. v13}, Lcom/google/common/cache/k;-><init>(JJJJJJ)V

    return-object v14
.end method

.method public j()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    iget-wide v0, p0, Lcom/google/common/cache/k;->b:J

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-wide v0
.end method

.method public k()D
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/common/cache/k;->m()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    cmp-long v2, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/common/cache/k;->b:J

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    long-to-double v2, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    long-to-double v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    div-double v0, v2, v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-wide v0
.end method

.method public l(Lcom/google/common/cache/k;)Lcom/google/common/cache/k;
    .locals 15
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    new-instance v14, Lcom/google/common/cache/k;

    iget-wide v2, v0, Lcom/google/common/cache/k;->a:J

    iget-wide v4, v1, Lcom/google/common/cache/k;->a:J

    invoke-static {v2, v3, v4, v5}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v2

    iget-wide v4, v0, Lcom/google/common/cache/k;->b:J

    iget-wide v6, v1, Lcom/google/common/cache/k;->b:J

    invoke-static {v4, v5, v6, v7}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v4

    iget-wide v6, v0, Lcom/google/common/cache/k;->c:J

    iget-wide v8, v1, Lcom/google/common/cache/k;->c:J

    invoke-static {v6, v7, v8, v9}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v6

    iget-wide v8, v0, Lcom/google/common/cache/k;->d:J

    iget-wide v10, v1, Lcom/google/common/cache/k;->d:J

    invoke-static {v8, v9, v10, v11}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v8

    iget-wide v10, v0, Lcom/google/common/cache/k;->e:J

    iget-wide v12, v1, Lcom/google/common/cache/k;->e:J

    invoke-static {v10, v11, v12, v13}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v10

    iget-wide v12, v0, Lcom/google/common/cache/k;->f:J

    iget-wide v0, v1, Lcom/google/common/cache/k;->f:J

    invoke-static {v12, v13, v0, v1}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v12

    move-object v1, v14

    move-object v1, v14

    move-object v1, v14

    move-object v1, v14

    invoke-direct/range {v1 .. v13}, Lcom/google/common/cache/k;-><init>(JJJJJJ)V

    return-object v14
.end method

.method public m()J
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/google/common/cache/k;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->b:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v1, v2, v3}, Lcom/google/common/math/h;->x(JJ)J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-wide v0
.end method

.method public n()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/google/common/cache/k;->e:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-wide v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/google/common/base/y;->c(Ljava/lang/Object;)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v1, "oCumttis"

    const-string/jumbo v1, "itsCutho"

    const/4 v5, 0x1

    const-string/jumbo v1, "nitooCuh"

    const-string/jumbo v1, "hitCount"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->a:J

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "soimtbsum"

    const-string/jumbo v1, "tusmnioms"

    const/4 v5, 0x2

    const-string/jumbo v1, "mtisCuuno"

    const-string/jumbo v1, "missCount"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/google/common/cache/k;->b:J

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "uosSneCpcatolucd"

    const-string/jumbo v1, "loadSuccessCount"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-wide v2, p0, Lcom/google/common/cache/k;->c:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "CoitdcEaqxootplnon"

    const-string/jumbo v1, "oxClotpndcEnaootui"

    const/4 v5, 0x1

    const-string/jumbo v1, "uistndlEonpocaetxC"

    const-string/jumbo v1, "loadExceptionCount"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/common/cache/k;->d:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "iommTodeblLta"

    const-string/jumbo v1, "tamoTbaLldeoi"

    const/4 v5, 0x5

    const-string v1, "aTmlooteidaLo"

    const-string/jumbo v1, "totalLoadTime"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/common/cache/k;->e:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "tnonituCievco"

    const/4 v5, 0x3

    const-string/jumbo v1, "tutnibneoiCoc"

    const-string/jumbo v1, "evictionCount"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/google/common/cache/k;->f:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/common/base/y$b;->e(Ljava/lang/String;J)Lcom/google/common/base/y$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/common/base/y$b;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v0
.end method
