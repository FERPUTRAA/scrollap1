.class final enum Lcom/google/common/cache/g$c;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/common/cache/h0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/cache/g$c;",
        ">;",
        "Lcom/google/common/cache/h0<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/cache/g$c;

.field private static final synthetic b:[Lcom/google/common/cache/g$c;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lcom/google/common/cache/g$c;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "SIsTNCNE"

    const-string v1, "TNsICSNE"

    const/4 v4, 0x4

    const-string v1, "SNEmACIN"

    const-string v1, "INSTANCE"

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/g$c;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    sput-object v0, Lcom/google/common/cache/g$c;->a:Lcom/google/common/cache/g$c;

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/cache/g$c;->b()[Lcom/google/common/cache/g$c;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    sput-object v0, Lcom/google/common/cache/g$c;->b:[Lcom/google/common/cache/g$c;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method

.method private static synthetic b()[Lcom/google/common/cache/g$c;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "S 4yo -@@~ ~ ~@ ~@l~~oi~~1~@@@i d@f@  ~@~ @n~  b~u@@aot~~r~v@~b/@@oMKi~o/.@bs@c  lo~ f ~@ o@~ t~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x2

    new-array v0, v0, [Lcom/google/common/cache/g$c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    sget-object v2, Lcom/google/common/cache/g$c;->a:Lcom/google/common/cache/g$c;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/cache/g$c;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-class v0, Lcom/google/common/cache/g$c;

    const-class v0, Lcom/google/common/cache/g$c;

    const/4 v2, 0x4

    const-class v0, Lcom/google/common/cache/g$c;

    const-class v0, Lcom/google/common/cache/g$c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/google/common/cache/g$c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lcom/google/common/cache/g$c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/common/cache/g$c;->b:[Lcom/google/common/cache/g$c;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/google/common/cache/g$c;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, [Lcom/google/common/cache/g$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public a(Lcom/google/common/cache/l0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "notification"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/l0<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method
