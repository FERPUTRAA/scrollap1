.class Lcom/google/common/cache/h$g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/h$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "g"
.end annotation


# instance fields
.field private final a:Lcom/google/common/cache/v$u;


# direct methods
.method public constructor <init>(Lcom/google/common/cache/v$u;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "strength"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/cache/h$g;->a:Lcom/google/common/cache/v$u;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/h;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .param p3    # Ljava/lang/String;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "key",
            "value"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, ". s d~~~@bo@/ s-~ @ ~n@@~o~o@bir @ mt~@~@~@~ b   @4@M@~~~o@@l/ o1 f~ ~~~K@ y @a@t~cul@f@ii v~~So"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    if-nez p3, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    move p3, v0

    move p3, v0

    const/4 v4, 0x7

    move p3, v0

    move p3, v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    move p3, v1

    move p3, v1

    const/4 v4, 0x1

    move p3, v1

    move p3, v1

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v2, "tekm  d oasss tnule aeo%kys"

    const-string v2, "a sl%eskeseutsva ooknt d  y"

    const/4 v4, 0x1

    const-string v2, "e naoasu  dstoko%evtl kyee "

    const-string/jumbo v2, "key %s does not take values"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p3, v2, p2}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    iget-object p3, p1, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez p3, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    const/4 v4, 0x7

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "ls%srbdstea ywtm eaa  os"

    const-string v1, "aeameo  d%lrasytsts  %ws"

    const/4 v4, 0x1

    const-string v1, " aedt%u e  %syrtsoslws a"

    const-string v1, "%s was already set to %s"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0, v1, p2, p3}, Lcom/google/common/base/u0;->y(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/google/common/cache/h$g;->a:Lcom/google/common/cache/v$u;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object p2, p1, Lcom/google/common/cache/h;->e:Lcom/google/common/cache/v$u;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method
