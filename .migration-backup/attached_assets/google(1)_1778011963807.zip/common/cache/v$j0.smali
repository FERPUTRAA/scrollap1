.class final Lcom/google/common/cache/v$j0;
.super Lcom/google/common/cache/v$y;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "j0"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/cache/v$y<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field final b:I


# direct methods
.method constructor <init>(Ljava/lang/Object;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "referent",
            "weight"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/cache/v$y;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput p2, p0, Lcom/google/common/cache/v$j0;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public e()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s S~~ ~@.@ ~~b/ou@-  s~bal~ @1 @@fv4 l@~t@ @@/@@ K~o y~~mdo@~b~ ~~~ic @ ~@o @ o~nt~ ~ri~@f@Mio"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/common/cache/v$j0;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method
