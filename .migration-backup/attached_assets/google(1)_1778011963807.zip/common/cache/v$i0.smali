.class final Lcom/google/common/cache/v$i0;
.super Lcom/google/common/cache/v$t;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "i0"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/cache/v$t<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field final b:I


# direct methods
.method constructor <init>(Ljava/lang/ref/ReferenceQueue;Ljava/lang/Object;Lcom/google/common/cache/f0;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "queue",
            "referent",
            "entry",
            "weight"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/ReferenceQueue<",
            "TV;>;TV;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/common/cache/v$t;-><init>(Ljava/lang/ref/ReferenceQueue;Ljava/lang/Object;Lcom/google/common/cache/f0;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p4, p0, Lcom/google/common/cache/v$i0;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public e()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tos@~@@m coo   lf~~ ~t@~il4My~ia~~~  @~1  ~ f@K b@@~o~@@d~~@-/ @ovu@. i~@@~s~ b@@~S~@/b ~@nr ~@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/common/cache/v$i0;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public f(Ljava/lang/ref/ReferenceQueue;Ljava/lang/Object;Lcom/google/common/cache/f0;)Lcom/google/common/cache/v$b0;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "queue",
            "value",
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/ReferenceQueue<",
            "TV;>;TV;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)",
            "Lcom/google/common/cache/v$b0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/cache/v$i0;

    const/4 v3, 0x7

    const/4 v2, 0x2

    iget v1, p0, Lcom/google/common/cache/v$i0;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-direct {v0, p1, p2, p3, v1}, Lcom/google/common/cache/v$i0;-><init>(Ljava/lang/ref/ReferenceQueue;Ljava/lang/Object;Lcom/google/common/cache/f0;I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-object v0
.end method
