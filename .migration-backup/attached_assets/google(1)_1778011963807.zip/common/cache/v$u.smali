.class abstract enum Lcom/google/common/cache/v$u;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4408
    name = "u"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/common/cache/v$u;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/common/cache/v$u;

.field public static final enum b:Lcom/google/common/cache/v$u;

.field public static final enum c:Lcom/google/common/cache/v$u;

.field private static final synthetic d:[Lcom/google/common/cache/v$u;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Lcom/google/common/cache/v$u$a;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "RNsGSO"

    const/4 v4, 0x2

    const-string v1, "GRsSNT"

    const-string v1, "STRONG"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/v$u$a;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    sput-object v0, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Lcom/google/common/cache/v$u$b;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, "SOTF"

    const-string v1, "OSTF"

    const/4 v4, 0x4

    const-string v1, "SOFT"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/v$u$b;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    sput-object v0, Lcom/google/common/cache/v$u;->b:Lcom/google/common/cache/v$u;

    const/4 v4, 0x2

    new-instance v0, Lcom/google/common/cache/v$u$c;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v1, "EKWA"

    const/4 v4, 0x0

    const-string v1, "AWKE"

    const-string v1, "WEAK"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/google/common/cache/v$u$c;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    sput-object v0, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/cache/v$u;->a()[Lcom/google/common/cache/v$u;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    sput-object v0, Lcom/google/common/cache/v$u;->d:[Lcom/google/common/cache/v$u;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;ILcom/google/common/cache/v$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/cache/v$u;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method private static synthetic a()[Lcom/google/common/cache/v$u;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~bmn@ yo ~@~ Kttoi@/~~@1@~ @~s~~cal-@l~f~@@u~~ @   ~@@~r@ mM  ~4i@d/@bi~f~v~~o @@o o@.S@~@ ~ o "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x7

    new-array v0, v0, [Lcom/google/common/cache/v$u;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    sget-object v2, Lcom/google/common/cache/v$u;->a:Lcom/google/common/cache/v$u;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    sget-object v2, Lcom/google/common/cache/v$u;->b:Lcom/google/common/cache/v$u;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x0

    sget-object v2, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x3

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/common/cache/v$u;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-class v0, Lcom/google/common/cache/v$u;

    const-class v0, Lcom/google/common/cache/v$u;

    const/4 v2, 0x1

    const-class v0, Lcom/google/common/cache/v$u;

    const-class v0, Lcom/google/common/cache/v$u;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p0, Lcom/google/common/cache/v$u;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lcom/google/common/cache/v$u;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/common/cache/v$u;->d:[Lcom/google/common/cache/v$u;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0}, [Lcom/google/common/cache/v$u;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, [Lcom/google/common/cache/v$u;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method abstract b()Lcom/google/common/base/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/base/m<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end method

.method abstract c(Lcom/google/common/cache/v$s;Lcom/google/common/cache/f0;Ljava/lang/Object;I)Lcom/google/common/cache/v$b0;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "segment",
            "entry",
            "value",
            "weight"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/cache/v$s<",
            "TK;TV;>;",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;TV;I)",
            "Lcom/google/common/cache/v$b0<",
            "TK;TV;>;"
        }
    .end annotation
.end method
