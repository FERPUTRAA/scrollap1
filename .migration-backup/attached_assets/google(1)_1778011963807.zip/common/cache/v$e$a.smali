.class Lcom/google/common/cache/v$e$a;
.super Lcom/google/common/cache/v$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v$e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/cache/v$d<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field a:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field b:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/cache/v$e;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/cache/v$d;-><init>()V

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p0, p0, Lcom/google/common/cache/v$e$a;->a:Lcom/google/common/cache/f0;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p0, p0, Lcom/google/common/cache/v$e$a;->b:Lcom/google/common/cache/f0;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public d()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oisS@~@ o@~@.bd~~tf4@ ~st/ ~@bK@~l   @r  l@M~~o~~u~@@ ~~c@~@@@o y~  @  b@ io~m~~~~1@n~-f @/@voai"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/cache/v$e$a;->b:Lcom/google/common/cache/f0;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public f()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v$e$a;->a:Lcom/google/common/cache/f0;

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-object v0
.end method

.method public g(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "previous"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/cache/v$e$a;->b:Lcom/google/common/cache/f0;

    const/4 v0, 0x0

    const/4 v0, 0x2

    return-void
.end method

.method public l(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "time"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public m()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-wide v0
.end method

.method public p(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/cache/v$e$a;->a:Lcom/google/common/cache/f0;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
