.class final Lcom/google/common/cache/m0$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/m0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation


# static fields
.field private static final UNSAFE:Lsun/misc/Unsafe;

.field private static final valueOffset:J


# instance fields
.field volatile p0:J

.field volatile p1:J

.field volatile p2:J

.field volatile p3:J

.field volatile p4:J

.field volatile p5:J

.field volatile p6:J

.field volatile q0:J

.field volatile q1:J

.field volatile q2:J

.field volatile q3:J

.field volatile q4:J

.field volatile q5:J

.field volatile q6:J

.field volatile value:J


# direct methods
.method static constructor <clinit>()V
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    invoke-static {}, Lcom/google/common/cache/m0;->c()Lsun/misc/Unsafe;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v0, Lcom/google/common/cache/m0$b;->UNSAFE:Lsun/misc/Unsafe;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-class v1, Lcom/google/common/cache/m0$b;

    const/4 v4, 0x7

    const-class v1, Lcom/google/common/cache/m0$b;

    const-class v1, Lcom/google/common/cache/m0$b;

    const/4 v4, 0x3

    const-string/jumbo v2, "vasel"

    const/4 v4, 0x5

    const-string/jumbo v2, "vasue"

    const-string/jumbo v2, "value"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    sput-wide v0, Lcom/google/common/cache/m0$b;->valueOffset:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/Error;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v1, v0}, Ljava/lang/Error;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    throw v1
.end method

.method constructor <init>(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "x"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/google/common/cache/m0$b;->value:J

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method final a(JJ)Z
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "cmp",
            "val"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~i@m@ @fM~~ oo ib~~@ o@@@@/~1@~~~ vfu S~@@@Kd@ ~  omr~b~ ~y-n @ @@ls~@~ lt~@~t coab ~@ @o/ .4~~~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    sget-object v0, Lcom/google/common/cache/m0$b;->UNSAFE:Lsun/misc/Unsafe;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    sget-wide v2, Lcom/google/common/cache/m0$b;->valueOffset:J

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-wide v4, p1

    move-wide v6, p3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual/range {v0 .. v7}, Lsun/misc/Unsafe;->compareAndSwapLong(Ljava/lang/Object;JJJ)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    return p1
.end method
