.class final Lcom/google/common/cache/c0$c;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lcom/google/common/cache/b0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/c0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/cache/c0$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/common/cache/c0$c;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ofs~b@~bt vo@~t@~  /o~-~l@do1@~  a4Kr  ~m@@il @~b @@/ns~@c@i@@~.  @~o~S~i @ ~~y ~~@M~~  @ofu ~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public add(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "x"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->getAndAdd(J)J

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public b()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method
