.class Lcom/google/common/cache/m0$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/security/PrivilegedExceptionAction;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/cache/m0;->g()Lsun/misc/Unsafe;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/security/PrivilegedExceptionAction<",
        "Lsun/misc/Unsafe;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Lsun/misc/Unsafe;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "t s  a@l4~o@on b  l@@o~~Kb@~~~r~@@/.Sf @d@o /yu @@ obos~  ~~M~@@ mi~if@-v@@@1~@~c~~~~~  ~~@i t @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    const-class v0, Lsun/misc/Unsafe;

    const-class v0, Lsun/misc/Unsafe;

    const/4 v7, 0x6

    const-class v0, Lsun/misc/Unsafe;

    const-class v0, Lsun/misc/Unsafe;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    array-length v2, v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v3, 0x0

    move v7, v3

    :goto_0
    if-ge v3, v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    aget-object v4, v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v5, 0x1

    and-int/2addr v7, v5

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v4, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    check-cast v0, Lsun/misc/Unsafe;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    return-object v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/NoSuchFieldError;

    const/4 v6, 0x7

    xor-int/2addr v7, v6

    const-string v1, " eUmnfahts"

    const-string v1, " asftUnesh"

    const/4 v7, 0x6

    const-string v1, "enUeoasf t"

    const-string/jumbo v1, "the Unsafe"

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    invoke-direct {v0, v1}, Ljava/lang/NoSuchFieldError;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    throw v0
.end method

.method public bridge synthetic run()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/cache/m0$a;->a()Lsun/misc/Unsafe;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method
