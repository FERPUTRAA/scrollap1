.class abstract Lcom/google/common/cache/h$f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/cache/h$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "f"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/cache/h;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "spec",
            "key",
            "value"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s@@@~t@@o~ i v~ y~.@~~~m@i~of~@~@s o~l~~~@ f @ ~b M~r-u/@ta~ ~ c@b@ o@oi~@d@  ~S 1 @~n~K/o@4 l"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {p3}, Lcom/google/common/base/g1;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/common/cache/h$f;->b(Lcom/google/common/cache/h;I)V
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    aput-object p2, v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 p2, 0x1

    shr-int/2addr v4, p2

    const/4 v3, 0x0

    or-int/2addr v4, v3

    aput-object p3, v1, p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string p2, "e am  usl ttsb,u %yr m eti%gts eskeeove"

    const-string/jumbo p2, "key %s value set to %s, must be integer"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p2, v1}, Lcom/google/common/cache/h;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v0, "euafooke y ls"

    const-string v0, "a sylfeukov e"

    const/4 v4, 0x1

    const-string/jumbo v0, "fyla beu evk "

    const-string/jumbo v0, "value of key "

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo p2, "moiettum"

    const-string/jumbo p2, "omimtedt"

    const-string/jumbo p2, "omidt ep"

    const-string p2, " omitted"

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    throw p1
.end method

.method protected abstract b(Lcom/google/common/cache/h;I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "spec",
            "value"
        }
    .end annotation
.end method
