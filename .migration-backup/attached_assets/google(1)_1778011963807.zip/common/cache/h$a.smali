.class synthetic Lcom/google/common/cache/h$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/common/cache/v$u;->values()[Lcom/google/common/cache/v$u;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    array-length v0, v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array v0, v0, [I

    const/4 v4, 0x1

    sput-object v0, Lcom/google/common/cache/h$a;->a:[I

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v1, Lcom/google/common/cache/v$u;->c:Lcom/google/common/cache/v$u;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v0, Lcom/google/common/cache/h$a;->a:[I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v1, Lcom/google/common/cache/v$u;->b:Lcom/google/common/cache/v$u;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    return-void
.end method
