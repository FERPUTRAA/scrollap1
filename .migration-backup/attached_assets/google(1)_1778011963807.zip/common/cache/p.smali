.class public final synthetic Lcom/google/common/cache/p;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@Ss @il~i~~n@@@~t boao l@b v o-@ @ ~/ @m4~~~ ~~@~@~~~ 1o~o@y@~ib ~@fs@~ @~.uc~f ~tM@  ~r @o@Kd @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p0, p1}, Ljava/util/function/Function;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method
