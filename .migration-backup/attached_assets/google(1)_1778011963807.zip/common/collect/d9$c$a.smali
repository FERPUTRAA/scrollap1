.class Lcom/google/common/collect/d9$c$a;
.super Lcom/google/common/collect/d9$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/d9$c;->a()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/d9$c$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/d9<",
        "TK;TV;>.e<",
        "Ljava/util/Map$Entry<",
        "TV;TK;>;>;"
    }
.end annotation


# instance fields
.field final synthetic f:Lcom/google/common/collect/d9$c;


# direct methods
.method constructor <init>(Lcom/google/common/collect/d9$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$1"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/d9$c$a;->f:Lcom/google/common/collect/d9$c;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p1, p1, Lcom/google/common/collect/d9$c;->this$0:Lcom/google/common/collect/d9;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/d9$e;-><init>(Lcom/google/common/collect/d9;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method bridge synthetic a(Lcom/google/common/collect/d9$b;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "entry"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Ss@@to@ ~@i~~  b1 @~n-@@ o M orlK~   bl~ @.b@ ofos~~f ~ ~m4@@@~/~@i~@~@dv ~oc au~/~@@~~ty@ ~@@i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Lcom/google/common/collect/d9$c$a;->b(Lcom/google/common/collect/d9$b;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method b(Lcom/google/common/collect/d9$b;)Ljava/util/Map$Entry;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;)",
            "Ljava/util/Map$Entry<",
            "TV;TK;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/d9$c$a$a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/d9$c$a$a;-><init>(Lcom/google/common/collect/d9$c$a;Lcom/google/common/collect/d9$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method
