.class final Lcom/google/common/collect/d9$c$b;
.super Lcom/google/common/collect/uc$b0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/d9$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/uc$b0<",
        "TV;TK;>;"
    }
.end annotation


# instance fields
.field final synthetic b:Lcom/google/common/collect/d9$c;


# direct methods
.method constructor <init>(Lcom/google/common/collect/d9$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$1"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/common/collect/d9$c$b;->b:Lcom/google/common/collect/d9$c;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/uc$b0;-><init>(Ljava/util/Map;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@fb  / ~s~i~o@ 4 ~i@~~@Si @df @~M~t ~l c   ~o@~ u ~bv@~a~ @t~. @/~K~@ @@n@o@@r1ml@bo@y~-o~~o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/d9$c$b$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/collect/d9$c$b$a;-><init>(Lcom/google/common/collect/d9$c$b;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/d9$c$b;->b:Lcom/google/common/collect/d9$c;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, v0, Lcom/google/common/collect/d9$c;->this$0:Lcom/google/common/collect/d9;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, p1, v1}, Lcom/google/common/collect/d9;->h(Lcom/google/common/collect/d9;Ljava/lang/Object;I)Lcom/google/common/collect/d9$b;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/d9$c$b;->b:Lcom/google/common/collect/d9$c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, v0, Lcom/google/common/collect/d9$c;->this$0:Lcom/google/common/collect/d9;

    const/4 v2, 0x2

    move v3, v2

    invoke-static {v0, p1}, Lcom/google/common/collect/d9;->f(Lcom/google/common/collect/d9;Lcom/google/common/collect/d9$b;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return p1
.end method
