.class final Lcom/google/common/collect/b6;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field static final a:B = 0x0t

.field private static final b:I = 0x5

.field static final c:I = 0x20

.field static final d:I = 0x1f

.field static final e:I = 0x3fffffff

.field static final f:I = 0x3

.field private static final g:I = 0x4

.field private static final h:I = 0x100

.field private static final i:I = 0xff

.field private static final j:I = 0x10000

.field private static final k:I = 0xffff


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method static a(I)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "buckets"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~os/s. ti~@@ @~ @i~@bl~o r- @K~ f@o@o~ 4@cb@@m/~ ~@l~tv~~M @@S@~ b~~~1 ~~u~o@o  @a@ @@~ n~ f~yd "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x0

    if-lt p0, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-gt p0, v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne v0, p0, :cond_2

    const/4 v4, 0x5

    const/16 v0, 0x100

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-gt p0, v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array p0, p0, [B

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/high16 v0, 0x10000

    const/4 v3, 0x4

    move v4, v3

    if-gt p0, v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-array p0, p0, [S

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array p0, p0, [I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object p0

    :cond_2
    const/4 v4, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v2, "se2m:f t^e 2 robn se13  wpd^ tmae2bwe  uo"

    const-string/jumbo v2, "ewswp1 a 2en^m2 os  b oeu^r f  23ed:bettn"

    const/4 v4, 0x7

    const-string v2, "a2noo1fn3e: u  te wdbb 2 2mor^ teew0 sep "

    const-string/jumbo v2, "must be power of 2 between 2^1 and 2^30: "

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    throw v0
.end method

.method static b(II)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "value",
            "mask"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    not-int p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    and-int/2addr p0, p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method static c(II)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "mask"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    and-int/2addr p0, p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0
.end method

.method static d(III)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "prefix",
            "suffix",
            "mask"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    not-int v0, p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    and-int/2addr p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/2addr p1, p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    or-int/2addr p0, p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method

.method static e(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mask"
        }
    .end annotation

    const/4 v2, 0x2

    const/16 v0, 0x20

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ge p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x2

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    add-int/lit8 p0, p0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    mul-int/2addr v0, p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method static f(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I
    .locals 8
    .param p0    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p6    # [Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "value",
            "mask",
            "table",
            "entries",
            "keys",
            "values"
        }
    .end annotation

    invoke-static {p0}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v0

    and-int v1, v0, p2

    invoke-static {p3, v1}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v2

    const/4 v3, -0x1

    if-nez v2, :cond_0

    return v3

    :cond_0
    invoke-static {v0, p2}, Lcom/google/common/collect/b6;->b(II)I

    move-result v0

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_0
    add-int/lit8 v2, v2, -0x1

    aget v5, p4, v2

    invoke-static {v5, p2}, Lcom/google/common/collect/b6;->b(II)I

    move-result v6

    if-ne v6, v0, :cond_3

    aget-object v6, p5, v2

    invoke-static {p0, v6}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    if-eqz p6, :cond_1

    aget-object v6, p6, v2

    invoke-static {p1, v6}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    :cond_1
    invoke-static {v5, p2}, Lcom/google/common/collect/b6;->c(II)I

    move-result p0

    if-ne v4, v3, :cond_2

    invoke-static {p3, v1, p0}, Lcom/google/common/collect/b6;->i(Ljava/lang/Object;II)V

    goto :goto_1

    :cond_2
    aget p1, p4, v4

    invoke-static {p1, p0, p2}, Lcom/google/common/collect/b6;->d(III)I

    move-result p0

    aput p0, p4, v4

    :goto_1
    return v2

    :cond_3
    invoke-static {v5, p2}, Lcom/google/common/collect/b6;->c(II)I

    move-result v4

    if-nez v4, :cond_4

    return v3

    :cond_4
    move v7, v4

    move v7, v4

    move v7, v4

    move v7, v4

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    move v2, v7

    move v2, v7

    move v2, v7

    move v2, v7

    goto :goto_0
.end method

.method static g(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    instance-of v0, p0, [B

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    check-cast p0, [B

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, v1}, Ljava/util/Arrays;->fill([BB)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    instance-of v0, p0, [S

    const/4 v2, 0x4

    move v3, v2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast p0, [S

    const/4 v3, 0x4

    invoke-static {p0, v1}, Ljava/util/Arrays;->fill([SS)V

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast p0, [I

    const/4 v3, 0x6

    invoke-static {p0, v1}, Ljava/util/Arrays;->fill([II)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method static h(Ljava/lang/Object;I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "table",
            "index"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    instance-of v0, p0, [B

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, [B

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    aget-byte p0, p0, p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    and-int/lit16 p0, p0, 0xff

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p0, [S

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    check-cast p0, [S

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    aget-short p0, p0, p1

    const/4 v2, 0x5

    const p1, 0xffff

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    and-int/2addr p0, p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0

    :cond_1
    check-cast p0, [I

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    aget p0, p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p0
.end method

.method static i(Ljava/lang/Object;II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "table",
            "index",
            "entry"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    instance-of v0, p0, [B

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    check-cast p0, [B

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    int-to-byte p2, p2

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    aput-byte p2, p0, p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    instance-of v0, p0, [S

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p0, [S

    int-to-short p2, p2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    aput-short p2, p0, p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p0, [I

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    aput p2, p0, p1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method static j(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v3, 0x1

    add-int/lit8 p0, p0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lcom/google/common/collect/i9;->a(ID)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 v3, 0x2

    return p0
.end method
