.class Lcom/google/common/collect/a6;
.super Ljava/util/AbstractSet;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/AbstractSet<",
        "TE;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field static final f:D = 0.001
    .annotation build Lx4/e;
    .end annotation
.end field

.field private static final g:I = 0x9


# instance fields
.field private transient a:Ljava/lang/Object;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient b:[I
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field transient c:[Ljava/lang/Object;
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field private transient d:I

.field private transient e:I


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/util/AbstractSet;-><init>()V

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/collect/a6;->t(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/AbstractSet;-><init>()V

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a6;->t(I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method private A()[I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sK  @@n@@~ @ o~ ~ ~@~~~s~~l~So-~ ii ~ bf~lro @~~bM@@i~~@bt/.uao ~ @oyfcot@ @@~1@/ 4@@ ~@mv~@  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/a6;->b:[I

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, [I

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object v0
.end method

.method private B()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method private E(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "newSize"
        }
    .end annotation

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    array-length v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-le p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    ushr-int/lit8 p1, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    or-int/2addr p1, v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const v1, 0x3fffffff    # 1.9999999f

    const/4 v3, 0x0

    invoke-static {v1, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eq p1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a6;->C(I)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method private F(IIII)I
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "oldMask",
            "newCapacity",
            "targetHash",
            "targetEntryIndex"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-static {p2}, Lcom/google/common/collect/b6;->a(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    add-int/lit8 p2, p2, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz p4, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    and-int/2addr p3, p2

    const/4 v9, 0x2

    add-int/lit8 p4, p4, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v0, p3, p4}, Lcom/google/common/collect/b6;->i(Ljava/lang/Object;II)V

    :cond_0
    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object p3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object p4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-gt v1, p1, :cond_2

    const/4 v9, 0x4

    invoke-static {p3, v1}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v2

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v2, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    add-int/lit8 v3, v2, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    aget v4, p4, v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v4, p1}, Lcom/google/common/collect/b6;->b(II)I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    or-int/2addr v5, v1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    and-int v6, v5, p2

    const/4 v8, 0x0

    move v9, v8

    invoke-static {v0, v6}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v7

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v0, v6, v2}, Lcom/google/common/collect/b6;->i(Ljava/lang/Object;II)V

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v5, v7, p2}, Lcom/google/common/collect/b6;->d(III)I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    aput v2, p4, v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v4, p1}, Lcom/google/common/collect/b6;->c(II)I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v9, 0x7

    iput-object v0, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {p0, p2}, Lcom/google/common/collect/a6;->K(I)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    return p2
.end method

.method private G(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "i",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    aput-object p2, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method private I(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "i",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    aput p2, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method private K(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mask"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    rsub-int/lit8 p1, p1, 0x20

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v3, 0x5

    const/16 v1, 0x1f

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p1, v1}, Lcom/google/common/collect/b6;->d(III)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic a(Lcom/google/common/collect/a6;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget p0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic b(Lcom/google/common/collect/a6;I)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/a6;->m(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static g()Lcom/google/common/collect/a6;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/a6<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/a6;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/collect/a6;-><init>()V

    const/4 v2, 0x0

    return-object v0
.end method

.method public static h(Ljava/util/Collection;)Lcom/google/common/collect/a6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "collection"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "+TE;>;)",
            "Lcom/google/common/collect/a6<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/common/collect/a6;->k(I)Lcom/google/common/collect/a6;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static varargs i([Ljava/lang/Object;)Lcom/google/common/collect/a6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)",
            "Lcom/google/common/collect/a6<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Ljava/lang/SafeVarargs;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    array-length v0, p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/common/collect/a6;->k(I)Lcom/google/common/collect/a6;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method private j(I)Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "tableSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Ljava/util/LinkedHashSet;-><init>(IF)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static k(I)Lcom/google/common/collect/a6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(I)",
            "Lcom/google/common/collect/a6<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/a6;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/common/collect/a6;-><init>(I)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-object v0
.end method

.method private m(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TE;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    aget-object p1, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1
.end method

.method private n(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    aget p1, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p1
.end method

.method private q()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    and-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    shl-int v0, v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readInt()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ltz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/collect/a6;->t(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ge v1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, v2}, Lcom/google/common/collect/a6;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "slimIesan  z:d"

    const-string v2, " lsdiez :iaIsn"

    const/4 v4, 0x2

    const-string/jumbo v2, "i zdo: eIaisln"

    const-string v2, "Invalid size: "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw p1
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, v1}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method private z()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/a6;->c:[Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast v0, [Ljava/lang/Object;

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method C(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "newCapacity"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/common/collect/a6;->b:[I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/common/collect/a6;->c:[Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public L()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, v1}, Lcom/google/common/collect/a6;->j(I)Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v1, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    array-length v1, v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ge v0, v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/collect/a6;->C(I)V

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/common/collect/b6;->j(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/a6;->q()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ge v0, v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    invoke-direct {p0, v1, v0, v2, v2}, Lcom/google/common/collect/a6;->F(IIII)I

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method public add(Ljava/lang/Object;)Z
    .locals 14
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v13, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v13, 0x0

    if-eqz v0, :cond_0

    const/4 v13, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->e()I

    :cond_0
    const/4 v13, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v13, 0x7

    if-eqz v0, :cond_1

    const/4 v13, 0x3

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v13, 0x2

    return p1

    :cond_1
    const/4 v13, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v13, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v1

    const/4 v13, 0x3

    iget v2, p0, Lcom/google/common/collect/a6;->e:I

    add-int/lit8 v3, v2, 0x1

    const/4 v13, 0x5

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v4

    const/4 v13, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6;->q()I

    move-result v5

    const/4 v13, 0x7

    and-int v6, v4, v5

    const/4 v13, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v7

    const/4 v13, 0x1

    invoke-static {v7, v6}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v7

    const/4 v13, 0x5

    const/4 v8, 0x1

    const/4 v13, 0x4

    if-nez v7, :cond_3

    const/4 v13, 0x7

    if-le v3, v5, :cond_2

    const/4 v13, 0x5

    invoke-static {v5}, Lcom/google/common/collect/b6;->e(I)I

    move-result v0

    const/4 v13, 0x0

    invoke-direct {p0, v5, v0, v4, v2}, Lcom/google/common/collect/a6;->F(IIII)I

    move-result v5

    const/4 v13, 0x0

    goto :goto_1

    :cond_2
    const/4 v13, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x0

    invoke-static {v0, v6, v3}, Lcom/google/common/collect/b6;->i(Ljava/lang/Object;II)V

    const/4 v13, 0x4

    goto :goto_1

    :cond_3
    invoke-static {v4, v5}, Lcom/google/common/collect/b6;->b(II)I

    move-result v6

    const/4 v13, 0x2

    const/4 v9, 0x0

    const/4 v13, 0x3

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    :goto_0
    const/4 v13, 0x3

    sub-int/2addr v7, v8

    const/4 v13, 0x7

    aget v11, v0, v7

    const/4 v13, 0x3

    invoke-static {v11, v5}, Lcom/google/common/collect/b6;->b(II)I

    move-result v12

    const/4 v13, 0x4

    if-ne v12, v6, :cond_4

    const/4 v13, 0x0

    aget-object v12, v1, v7

    const/4 v13, 0x1

    invoke-static {p1, v12}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    const/4 v13, 0x6

    if-eqz v12, :cond_4

    const/4 v13, 0x6

    return v9

    :cond_4
    const/4 v13, 0x5

    invoke-static {v11, v5}, Lcom/google/common/collect/b6;->c(II)I

    move-result v12

    const/4 v13, 0x2

    add-int/2addr v10, v8

    const/4 v13, 0x7

    if-nez v12, :cond_7

    const/4 v13, 0x2

    const/16 v1, 0x9

    const/4 v13, 0x5

    if-lt v10, v1, :cond_5

    const/4 v13, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->f()Ljava/util/Set;

    move-result-object v0

    const/4 v13, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v13, 0x5

    return p1

    :cond_5
    const/4 v13, 0x0

    if-le v3, v5, :cond_6

    const/4 v13, 0x4

    invoke-static {v5}, Lcom/google/common/collect/b6;->e(I)I

    move-result v0

    const/4 v13, 0x1

    invoke-direct {p0, v5, v0, v4, v2}, Lcom/google/common/collect/a6;->F(IIII)I

    move-result v5

    const/4 v13, 0x5

    goto :goto_1

    :cond_6
    const/4 v13, 0x6

    invoke-static {v11, v3, v5}, Lcom/google/common/collect/b6;->d(III)I

    move-result v1

    const/4 v13, 0x3

    aput v1, v0, v7

    :goto_1
    invoke-direct {p0, v3}, Lcom/google/common/collect/a6;->E(I)V

    const/4 v13, 0x2

    invoke-virtual {p0, v2, p1, v4, v5}, Lcom/google/common/collect/a6;->u(ILjava/lang/Object;II)V

    const/4 v13, 0x0

    iput v3, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v13, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->s()V

    const/4 v13, 0x6

    return v8

    :cond_7
    move v7, v12

    move v7, v12

    goto :goto_0
.end method

.method public clear()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->s()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v4, 0x3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const v5, 0x3fffffff    # 1.9999999f

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v3, v4, v5}, Lcom/google/common/primitives/f0;->g(III)I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput v3, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-object v1, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v7, 0x6

    iput v2, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget v3, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/google/common/collect/b6;->g(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput v2, p0, Lcom/google/common/collect/a6;->e:I

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    return v1

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v0, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    return p1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->q()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    and-int v4, v0, v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v3, v4}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v3, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    return v1

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v0, v2}, Lcom/google/common/collect/b6;->b(II)I

    move-result v0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    sub-int/2addr v3, v4

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {p0, v3}, Lcom/google/common/collect/a6;->n(I)I

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v5, v2}, Lcom/google/common/collect/b6;->b(II)I

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-ne v6, v0, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p0, v3}, Lcom/google/common/collect/a6;->m(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    if-eqz v3, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    return v4

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v5, v2}, Lcom/google/common/collect/b6;->c(II)I

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    if-nez v3, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    return v1
.end method

.method d(II)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "indexBeforeRemove",
            "indexRemoved"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x2

    return p1
.end method

.method e()I
    .locals 5
    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "ryadAbt layeralarsc eald"

    const-string v1, "Arrays already allocated"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/collect/b6;->j(I)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/google/common/collect/b6;->a(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object v2, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, v1}, Lcom/google/common/collect/a6;->K(I)V

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v1, v0, [I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/common/collect/a6;->b:[I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/common/collect/a6;->c:[Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return v0
.end method

.method f()Ljava/util/Set;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a6;->q()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lcom/google/common/collect/a6;->j(I)Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->o()I

    move-result v1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ltz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, v1}, Lcom/google/common/collect/a6;->m(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, v1}, Lcom/google/common/collect/a6;->p(I)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/google/common/collect/a6;->b:[I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/google/common/collect/a6;->c:[Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->s()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method

.method public forEach(Ljava/util/function/Consumer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "action"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/Consumer<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/google/common/collect/x5;->a(Ljava/util/Set;Ljava/util/function/Consumer;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->o()I

    move-result v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    if-ltz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/common/collect/a6;->m(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v1}, Lcom/google/common/collect/h4;->a(Ljava/util/function/Consumer;Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/collect/a6;->p(I)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/a6$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-direct {v0, p0}, Lcom/google/common/collect/a6$a;-><init>(Lcom/google/common/collect/a6;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method l()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    check-cast v0, Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method

.method o()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v0, -0x2

    const/4 v0, -0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    return v0
.end method

.method p(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entryIndex"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    move v2, v1

    iget v0, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v2, 0x1

    if-ge p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p1
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 11
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-eqz v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    return v1

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v0, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x5

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    return p1

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/a6;->q()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v8, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v4, v0

    move v4, v0

    const/4 v10, 0x6

    move v4, v0

    move v4, v0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static/range {v2 .. v8}, Lcom/google/common/collect/b6;->f(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v2, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-ne p1, v2, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    return v1

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/a6;->x(II)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget p1, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    const/4 v0, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    sub-int/2addr p1, v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    iput p1, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->s()V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    return v0
.end method

.method s()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v2, 0x0

    add-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    iget v0, p0, Lcom/google/common/collect/a6;->e:I

    :goto_0
    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public spliterator()Ljava/util/Spliterator;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v1, 0x11

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/google/common/collect/y5;->a([Ljava/lang/Object;I)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/google/common/collect/j;->a(Ljava/util/Set;)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    iget v3, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v2, v3, v1}, Lcom/google/common/collect/z5;->a([Ljava/lang/Object;III)Ljava/util/Spliterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v0
.end method

.method t(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ltz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v1, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const-string v2, "epxe eu0s  m dzeEti>c=bmtu"

    const-string v2, "empmi 0de u>cezs =eExt t b"

    const/4 v4, 0x4

    const-string/jumbo v2, "tdp it>pEzee=0  s  ucesxem"

    const-string v2, "Expected size must be >= 0"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const v1, 0x3fffffff    # 1.9999999f

    const/4 v3, 0x3

    move v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/common/primitives/f0;->g(III)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput p1, p0, Lcom/google/common/collect/a6;->d:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/util/Set;->toArray()[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    array-length v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-lez v0, :cond_0

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x3

    xor-int/2addr v3, v0

    const/4 v4, 0x6

    aput-object v0, p1, v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0, p1}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/common/collect/a6;->e:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-static {v0, v1, v2, p1}, Lcom/google/common/collect/ke;->n([Ljava/lang/Object;II[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p1
.end method

.method u(ILjava/lang/Object;II)V
    .locals 3
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "entryIndex",
            "object",
            "hash",
            "mask"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;II)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p3, v0, p4}, Lcom/google/common/collect/b6;->d(III)I

    move-result p3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, p1, p3}, Lcom/google/common/collect/a6;->I(II)V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/a6;->G(ILjava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method w()Z
    .locals 3
    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method x(II)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "dstIndex",
            "mask"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/a6;->B()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/a6;->A()[I

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/a6;->z()[Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    add-int/lit8 v3, v3, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v5, 0x0

    const/4 v7, 0x3

    shl-int/2addr v8, v7

    if-ge p1, v3, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    aget-object v6, v2, v3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-object v6, v2, p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    aput-object v5, v2, v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    aget v2, v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    aput v2, v1, p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput v4, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v6}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    and-int/2addr v2, p2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v2}, Lcom/google/common/collect/b6;->h(Ljava/lang/Object;I)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ne v4, v3, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v0, v2, p1}, Lcom/google/common/collect/b6;->i(Ljava/lang/Object;II)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v8, 0x6

    add-int/lit8 v4, v4, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    aget v0, v1, v4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v0, p2}, Lcom/google/common/collect/b6;->c(II)I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    if-ne v2, v3, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v0, p1, p2}, Lcom/google/common/collect/b6;->d(III)I

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    aput p1, v1, v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    move v4, v2

    const/4 v8, 0x3

    move v4, v2

    move v4, v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput-object v5, v2, p1

    const/4 v8, 0x3

    aput v4, v1, p1

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-void
.end method

.method y()Z
    .locals 3
    .annotation build Lx4/e;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/a6;->a:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method
