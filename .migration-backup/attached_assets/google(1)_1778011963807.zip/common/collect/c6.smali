.class Lcom/google/common/collect/c6;
.super Lcom/google/common/collect/v5;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/v5<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field private static final p:I = -0x2


# instance fields
.field private final accessOrder:Z

.field transient m:[J
    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field private transient n:I

.field private transient o:I


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/common/collect/c6;-><init>(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/common/collect/c6;-><init>(IZ)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method constructor <init>(IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "expectedSize",
            "accessOrder"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/common/collect/v5;-><init>(I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-boolean p2, p0, Lcom/google/common/collect/c6;->accessOrder:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static k0()Lcom/google/common/collect/c6;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/c6<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s@@~i~o  ~ii b~o~~~1@  tcoso~@~d4 @@o~@ @~MKr~@~~ @~t .@l~l@uf v Sf/@~ b~o @ ~mb~@@/~ -@na@y@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/c6;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/common/collect/c6;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public static l0(I)Lcom/google/common/collect/c6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(I)",
            "Lcom/google/common/collect/c6<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    new-instance v0, Lcom/google/common/collect/c6;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/google/common/collect/c6;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method private m0(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->n0(I)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/16 p1, 0x20

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    ushr-long/2addr v0, p1

    const/4 v3, 0x0

    long-to-int p1, v0

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    return p1
.end method

.method private n0(I)J
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/c6;->o0()[J

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    aget-wide v1, v0, p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-wide v1
.end method

.method private o0()[J
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/c6;->m:[J

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, [J

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object v0
.end method

.method private q0(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "i",
            "value"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/c6;->o0()[J

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    aput-wide p2, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method private t0(II)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "pred"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->n0(I)J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-wide v2, 0xffffffffL

    const-wide v2, 0xffffffffL

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    and-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 p2, p2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    int-to-long v2, p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/16 p2, 0x20

    const/4 v5, 0x0

    shl-long/2addr v2, p2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    or-long/2addr v0, v2

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p0, p1, v0, v1}, Lcom/google/common/collect/c6;->q0(IJ)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-void
.end method

.method private v0(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "pred",
            "succ"
        }
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    const/4 v0, -0x2

    or-int/2addr v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ne p1, v0, :cond_0

    const/4 v1, 0x0

    move v2, v1

    iput p2, p0, Lcom/google/common/collect/c6;->n:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/c6;->w0(II)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-ne p2, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/common/collect/c6;->o:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/c6;->t0(II)V

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private w0(II)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "succ"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->n0(I)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-wide v2, -0x100000000L

    const-wide v2, -0x100000000L

    const/4 v7, 0x1

    const-wide v2, -0x100000000L

    const-wide v2, -0x100000000L

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    and-long/2addr v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/lit8 p2, p2, 0x1

    int-to-long v2, p2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-wide v4, 0xffffffffL

    const-wide v4, 0xffffffffL

    const/4 v7, 0x1

    const-wide v4, 0xffffffffL

    const-wide v4, 0xffffffffL

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    and-long/2addr v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    or-long/2addr v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {p0, p1, v0, v1}, Lcom/google/common/collect/c6;->q0(IJ)V

    return-void
.end method


# virtual methods
.method A()Ljava/util/Collection;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/c6$c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/common/collect/c6$c;-><init>(Lcom/google/common/collect/c6;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method G()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/common/collect/c6;->n:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method H(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->n0(I)J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    long-to-int p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return p1
.end method

.method M(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/common/collect/v5;->M(I)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p1, -0x2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/common/collect/c6;->n:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/common/collect/c6;->o:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method N(ILjava/lang/Object;Ljava/lang/Object;II)V
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "entryIndex",
            "key",
            "value",
            "hash",
            "mask"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITK;TV;II)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super/range {p0 .. p5}, Lcom/google/common/collect/v5;->N(ILjava/lang/Object;Ljava/lang/Object;II)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget p2, p0, Lcom/google/common/collect/c6;->o:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p2, -0x2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method R(II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "dstIndex",
            "mask"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/v5;->size()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/v5;->R(II)V

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->m0(I)I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/c6;->H(I)I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p2, v1}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ge p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/common/collect/c6;->m0(I)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/common/collect/c6;->H(I)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/c6;->v0(II)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x4

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, v0, p1, p2}, Lcom/google/common/collect/c6;->q0(IJ)V

    const/4 v3, 0x4

    return-void
.end method

.method Z(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "newCapacity"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0, p1}, Lcom/google/common/collect/v5;->Z(I)V

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/c6;->o0()[J

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/common/collect/c6;->m:[J

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    return-void
.end method

.method public clear()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/v5;->S()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v0, -0x2

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/common/collect/c6;->n:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/common/collect/c6;->o:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/common/collect/c6;->m:[J

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/v5;->size()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-wide/16 v2, 0x0

    const/4 v6, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0, v4, v1, v2, v3}, Ljava/util/Arrays;->fill([JIIJ)V

    :cond_1
    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-super {p0}, Lcom/google/common/collect/v5;->clear()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void
.end method

.method s(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/common/collect/c6;->accessOrder:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/c6;->m0(I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/c6;->H(I)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, v0, v1}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/common/collect/c6;->o:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, v0, p1}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    const/4 v0, -0x3

    const/4 v0, -0x2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/common/collect/c6;->v0(II)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/common/collect/v5;->K()V

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method t(II)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "indexBeforeRemove",
            "indexRemoved"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/v5;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-lt p1, v0, :cond_0

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    move p1, p2

    move p1, p2

    const/4 v2, 0x4

    move p1, p2

    move p1, p2

    :cond_0
    const/4 v2, 0x3

    return p1
.end method

.method u()I
    .locals 4

    invoke-super {p0}, Lcom/google/common/collect/v5;->u()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-array v1, v0, [J

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/common/collect/c6;->m:[J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method v()Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-super {p0}, Lcom/google/common/collect/v5;->v()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/common/collect/c6;->m:[J

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method x()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/c6$a;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0, p0}, Lcom/google/common/collect/c6$a;-><init>(Lcom/google/common/collect/c6;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method y(I)Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "tableSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-boolean v2, p0, Lcom/google/common/collect/c6;->accessOrder:Z

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, p1, v1, v2}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0
.end method

.method z()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/c6$b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/collect/c6$b;-><init>(Lcom/google/common/collect/c6;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method
