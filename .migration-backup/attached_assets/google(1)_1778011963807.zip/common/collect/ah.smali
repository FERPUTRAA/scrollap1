.class public final synthetic Lcom/google/common/collect/ah;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Optional;Ljava/util/function/Supplier;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~@@@a4  @~@~ @ M-@~ ~ ot~~ so@ rb ~@@~ ~@~.filovoo @~ cb t ~@bi~@~f~ @@muK/@~@l1d~~/@y nio@~S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Ljava/util/Optional;->orElseGet(Ljava/util/function/Supplier;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method
