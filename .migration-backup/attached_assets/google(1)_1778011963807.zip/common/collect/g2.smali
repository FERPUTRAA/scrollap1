.class public final synthetic Lcom/google/common/collect/g2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s@  ~~.@  i~/~o4nuM@ l  ~b@r@oi  ~ b~@ Sso@~ ~@~@~c~~@~fta~1vb@@ot/~ ~@ y@l@o@~~@m ~ iKdf@~@- "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    check-cast p1, Lcom/google/common/collect/pa$d;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    check-cast p2, Lcom/google/common/collect/re;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Lcom/google/common/collect/pa$d;->a(Lcom/google/common/collect/re;)Lcom/google/common/collect/pa$d;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
