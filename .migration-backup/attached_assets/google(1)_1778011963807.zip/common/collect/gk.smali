.class public final synthetic Lcom/google/common/collect/gk;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/util/stream/LongStream;


# direct methods
.method public synthetic constructor <init>(Ljava/util/stream/LongStream;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/collect/gk;->a:Ljava/util/stream/LongStream;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/s ~~~~~s@ lf~-~~@f@oo1o@~~K    rM@@~~  tt~  @@co@m  u @vb~ @~lnb@So~yi@ ~@d~iob4@@ /@ a~i.@~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/gk;->a:Ljava/util/stream/LongStream;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/common/collect/jh;->a(Ljava/util/stream/BaseStream;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method
