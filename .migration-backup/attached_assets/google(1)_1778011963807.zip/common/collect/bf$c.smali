.class final Lcom/google/common/collect/bf$c;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/bf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/bf$c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/t9<",
        "TV;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field final map:Lcom/google/common/collect/bf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/bf<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/collect/bf;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "map"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/bf<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/bf$c;->map:Lcom/google/common/collect/bf;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method g()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@Mo@4 m~~o .@@~s d    ~@-ono@o1/@fl@i  y@c @ @@~  ~~b /~@ ~ tl~~~~K~~@boS~@it@@~iu@ b~~~@av~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public get(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TV;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/bf$c;->map:Lcom/google/common/collect/bf;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/google/common/collect/bf;->f:[Ljava/util/Map$Entry;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    aget-object p1, v0, p1

    const/4 v1, 0x5

    or-int/2addr v2, v1

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/bf$c;->map:Lcom/google/common/collect/bf;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/bf;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method
