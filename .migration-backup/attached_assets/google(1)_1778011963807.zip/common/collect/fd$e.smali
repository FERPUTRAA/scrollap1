.class Lcom/google/common/collect/fd$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/fd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private f:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TE;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private g:Z

.field final synthetic h:Lcom/google/common/collect/fd;


# direct methods
.method private constructor <init>(Lcom/google/common/collect/fd;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    iput v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/common/collect/fd;->d(Lcom/google/common/collect/fd;)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/common/collect/fd$e;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/fd;Lcom/google/common/collect/fd$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$e;-><init>(Lcom/google/common/collect/fd;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method private a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y~s o~~oo~/it   ~~@ i  @~bm@~~~o@@@@ s ~~~@~/ l~~  @bf@@o~@~iK@@@c ~a@~ f@u.~@@1 S@-~lotdvMrn  4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/common/collect/fd;->d(Lcom/google/common/collect/fd;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/common/collect/fd$e;->c:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Ljava/util/ConcurrentModificationException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw v0
.end method

.method private b(Ljava/lang/Iterable;Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "elements",
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "TE;>;TE;)Z"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-ne v0, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->remove()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    return p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x5

    return p1
.end method

.method private c(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v3, 0x0

    if-ge v0, p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/fd;->size()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ge p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lcom/google/common/collect/fd$e;->b(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    iput p1, p0, Lcom/google/common/collect/fd$e;->b:I

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method private d(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v2}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ge v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v2}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    aget-object v2, v2, v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ne v2, p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Lcom/google/common/collect/fd;->w(I)Lcom/google/common/collect/fd$d;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x1

    move v4, p1

    const/4 v3, 0x0

    move v4, v3

    return p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v0
.end method


# virtual methods
.method public hasNext()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/fd$e;->a()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    add-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$e;->c(I)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v2}, Lcom/google/common/collect/fd;->size()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-lt v0, v2, :cond_1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1
.end method

.method public next()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {p0}, Lcom/google/common/collect/fd$e;->a()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$e;->c(I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v2}, Lcom/google/common/collect/fd;->size()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-ge v0, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-boolean v1, p0, Lcom/google/common/collect/fd$e;->g:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/fd;->size()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/common/collect/fd$e;->f:Ljava/lang/Object;

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    iput-boolean v1, p0, Lcom/google/common/collect/fd$e;->g:Z

    const/4 v3, 0x7

    move v4, v3

    return-object v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string v1, ".etm eue li enotaqmm tevno drtltuaspairsse"

    const-string/jumbo v1, "tlsr  ea.m ueiiumtsee ptandneo lrt otsavqe"

    const/4 v4, 0x6

    const-string/jumbo v1, "iterator moved past last element in queue."

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw v0
.end method

.method public remove()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v0, p0, Lcom/google/common/collect/fd$e;->g:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/common/collect/e4;->e(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/fd$e;->a()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/google/common/collect/fd$e;->g:Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/common/collect/fd$e;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/common/collect/fd$e;->c:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-virtual {v1}, Lcom/google/common/collect/fd;->size()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ge v0, v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->h:Lcom/google/common/collect/fd;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/google/common/collect/fd;->w(I)Lcom/google/common/collect/fd$d;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v1, :cond_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    new-instance v1, Ljava/util/ArrayDeque;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, v0, Lcom/google/common/collect/fd$d;->a:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p0, v1, v2}, Lcom/google/common/collect/fd$e;->b(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v2, v0, Lcom/google/common/collect/fd$d;->a:Ljava/lang/Object;

    const/4 v3, 0x6

    move v4, v3

    invoke-interface {v1, v2}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->d:Ljava/util/Queue;

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, v0, Lcom/google/common/collect/fd$d;->b:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0, v1, v2}, Lcom/google/common/collect/fd$e;->b(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/collect/fd$e;->e:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x3

    iget-object v0, v0, Lcom/google/common/collect/fd$d;->b:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/common/collect/fd$e;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/common/collect/fd$e;->b:I

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/fd$e;->f:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$e;->d(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/common/collect/fd$e;->f:Ljava/lang/Object;

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method
