.class final Lcom/google/common/collect/de$l;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/de;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "l"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private final a:Lcom/google/common/collect/ae;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ae<",
            "TE;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation
.end field

.field private c:Lcom/google/common/collect/ae$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private d:I

.field private e:I

.field private f:Z


# direct methods
.method constructor <init>(Lcom/google/common/collect/ae;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "multiset",
            "entryIterator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ae<",
            "TE;>;",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/google/common/collect/de$l;->a:Lcom/google/common/collect/ae;

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/common/collect/de$l;->b:Ljava/util/Iterator;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public hasNext()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s uif@~l t.@~@n/~v~~@b~tM  @ sb~y~~ ~@old~4am~ ~ ro/i@@cf@1   o~ o~b ~~o @@@@@@@~i @ o~@-~K~S@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/common/collect/de$l;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-gtz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/de$l;->b:Ljava/util/Iterator;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/de$l;->hasNext()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/common/collect/de$l;->d:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/de$l;->b:Ljava/util/Iterator;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Lcom/google/common/collect/ae$a;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/common/collect/de$l;->c:Lcom/google/common/collect/ae$a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/common/collect/de$l;->d:I

    iput v0, p0, Lcom/google/common/collect/de$l;->e:I

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/common/collect/de$l;->d:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/common/collect/de$l;->d:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v1, p0, Lcom/google/common/collect/de$l;->f:Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$l;->c:Lcom/google/common/collect/ae$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Lcom/google/common/collect/ae$a;

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    throw v0
.end method

.method public remove()V
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    iget-boolean v0, p0, Lcom/google/common/collect/de$l;->f:Z

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/common/collect/e4;->e(Z)V

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/common/collect/de$l;->e:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ne v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/collect/de$l;->b:Ljava/util/Iterator;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Lcom/google/common/collect/de$l;->a:Lcom/google/common/collect/ae;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/collect/de$l;->c:Lcom/google/common/collect/ae$a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v2, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v2}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0, v2}, Lcom/google/common/collect/ae;->remove(Ljava/lang/Object;)Z

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/common/collect/de$l;->e:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/common/collect/de$l;->e:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/google/common/collect/de$l;->f:Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method
