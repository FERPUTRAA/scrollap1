.class abstract Lcom/google/common/collect/a0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/collect/ve;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<C::",
        "Ljava/lang/Comparable;",
        ">",
        "Ljava/lang/Object;",
        "Lcom/google/common/collect/ve<",
        "TC;>;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Comparable;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)Z"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a0;->k(Ljava/lang/Comparable;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 p1, 0x0

    move v1, p1

    :goto_0
    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method public b(Lcom/google/common/collect/re;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    throw p1
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/collect/re;->a()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/collect/a0;->b(Lcom/google/common/collect/re;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public d(Lcom/google/common/collect/re;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    throw p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-ne p1, p0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    instance-of v0, p1, Lcom/google/common/collect/ve;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    check-cast p1, Lcom/google/common/collect/ve;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p0}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-interface {p1}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    return p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p1
.end method

.method public f(Lcom/google/common/collect/re;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "otherRange"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)Z"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    invoke-interface {p0, p1}, Lcom/google/common/collect/ve;->n(Lcom/google/common/collect/re;)Lcom/google/common/collect/ve;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/ve;->isEmpty()Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    xor-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method public synthetic g(Ljava/lang/Iterable;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/common/collect/ue;->a(Lcom/google/common/collect/ve;Ljava/lang/Iterable;)V

    return-void
.end method

.method public h(Lcom/google/common/collect/ve;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-interface {p1}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a0;->g(Ljava/lang/Iterable;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public final hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p0}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-interface {v0}, Ljava/util/Set;->hashCode()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public synthetic i(Ljava/lang/Iterable;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/google/common/collect/ue;->c(Lcom/google/common/collect/ve;Ljava/lang/Iterable;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p0}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return v0
.end method

.method public j(Lcom/google/common/collect/ve;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)Z"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a0;->m(Ljava/lang/Iterable;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p1
.end method

.method public abstract k(Ljava/lang/Comparable;)Lcom/google/common/collect/re;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)",
            "Lcom/google/common/collect/re<",
            "TC;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end method

.method public abstract l(Lcom/google/common/collect/re;)Z
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "otherRange"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)Z"
        }
    .end annotation
.end method

.method public synthetic m(Ljava/lang/Iterable;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/google/common/collect/ue;->b(Lcom/google/common/collect/ve;Ljava/lang/Iterable;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p1
.end method

.method public q(Lcom/google/common/collect/ve;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-interface {p1}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/a0;->i(Ljava/lang/Iterable;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p0}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method
