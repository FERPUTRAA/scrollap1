.class public final synthetic Lcom/google/common/collect/fh;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Collection;)Ljava/util/stream/Stream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t@s@~y~@b @ M~v~nd@~o@   o/@o~oK ~~@~o r~fi~ -~~sc@~@i4  .@@ ~i@@u@~l~@~t  mSb~o~f@ ~b@ @@a1  ~l"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-interface {p0}, Ljava/util/Collection;->stream()Ljava/util/stream/Stream;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method
