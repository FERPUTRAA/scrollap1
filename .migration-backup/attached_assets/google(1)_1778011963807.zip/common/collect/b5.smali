.class public final synthetic Lcom/google/common/collect/b5;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Ljava/util/Spliterator$OfDouble;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@so@@@ ~~ io~m@S@f@t ~~~o/a@@ Kii@ ~lo~~fd~~ ~v~o -u@. @~~~M@ s@1o @~tn ~y@ b/ l4~r@~  b~c  @~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p0, Ljava/util/Spliterator$OfDouble;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method
