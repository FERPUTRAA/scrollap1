.class public final synthetic Lcom/google/common/collect/fk;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/util/stream/LongStream;


# direct methods
.method public synthetic constructor <init>(Ljava/util/stream/LongStream;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/fk;->a:Ljava/util/stream/LongStream;

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "Mls@~~~@~ 4c ~muoi t@@  vl1 ~ty~@r  @o/ ~@-@/b ~@K~@.~~  bfb~@~~a@o  s ~~f@ @~o @io@i@So@~~d@@~n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/fk;->a:Ljava/util/stream/LongStream;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/common/collect/jh;->a(Ljava/util/stream/BaseStream;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method
