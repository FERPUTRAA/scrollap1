.class public final synthetic Lcom/google/common/collect/g3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s.@ ~1@ldt~nb@v o~-y @4~K@~to @f~~/@ii  o~ ~So Mc  ~ m~~@ so@@  @@~@~ @bf~@@ @ubl/~@@@~~r~a~~i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/collect/c4$c;

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    invoke-virtual {p1}, Lcom/google/common/collect/c4$c;->c()Lcom/google/common/collect/qa;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-object p1
.end method
